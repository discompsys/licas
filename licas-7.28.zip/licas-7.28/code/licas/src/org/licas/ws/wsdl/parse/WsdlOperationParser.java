/*
 * WsdlOperationParser.java
 *
 * Created on 25 June 2009
 *
 * Version 1.2.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws.wsdl.parse;


import org.licas.ws.wsdl.WsdlConst;
import org.licas.ws.wsdl.model.*;
import org.jlog2.exception.ExceptionHandler;

import org.licas_text.util.HtmlConst;
import org.licas_xml.abs.*;
import org.jlog2.*;

import java.util.*;
import org.licas.ws.WsFactory;


/**
 * This class can be used to parse an operation to its Java equivalent.
 * This is from a WSDL script description and not from other Java objects.
 * @author Kieran Greer
 */
public class WsdlOperationParser
{
    /** The logger */
    private static Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(WsdlOperationParser.class.getName());
        logger.setDebug(true);
    }


    /**
     * Create a new instance of WsdlOperationParser.
     */
    public WsdlOperationParser()
    {}
    
    /**
     * Parse the element to retrieve the operation information.
     * @param rootElem the root element for the operation information.
     * @param wsdlModel the parsed model.
     * @throws java.lang.Exception any error.
     */
    public void parse(Element rootElem, WsdlModel wsdlModel) throws Exception
    {
        int i, j;
	String name;                            //name
        String pattern;                         //pattern
        String style;                           //style
        String soapAction;                      //soap action
        String use;                             //operation use
        WsdlOperation operation;                //wsdl operation
        WsdlParamInfo paramInfo;                //wsdl parameter
        WsdlFaultParser faultParser;            //wsdl fault parser
        Node nextNode;                          //next node
        Element nextElem;                       //next element
        Element nextElem2;                      //next element
        Vector elemList;                        //element list
        Vector elemList2;                       //element list

        try
        {
            faultParser = new WsdlFaultParser();
            name = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.NAME));
            pattern = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.PATTERN));
            style = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.STYLE));

            if ((name != null) && !name.equals(""))
            {
                operation = wsdlModel.getOperation(name);
                if (operation == null)
                {
                    operation = new WsdlOperation(wsdlModel, name);

                    if ((pattern != null) && !pattern.equals(""))
                        operation.setPattern(pattern);

                    if ((style != null) && !style.equals(""))
                        operation.setStyle(style);

                    wsdlModel.addOperation(operation);
                }

                elemList = rootElem.getChildren();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);

                    if (nextNode instanceof Element)
                    {
                        nextElem = (Element)nextNode;

                        if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.OPERATION))
                        {
                            soapAction = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.SOAPACTION));
                            style = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.STYLE));

                            if ((soapAction != null) && !soapAction.equals(""))
                                operation.setSoapAction(soapAction);

                            if ((style != null) && !style.equals(""))
                                operation.setStyle(style);
                        }
                        else if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.DOCUMENTATION))
                        {
                            operation.setDocumentation(nextElem.getText());
                        }
                        else if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.INPUT))
                        {
                            //check binding child elements
                            elemList2 = nextElem.getChildren();
                            for (j = 0; j < elemList2.size(); j++)
                            {
                                nextNode = (Node)elemList2.get(j);

                                if (nextNode instanceof Element)
                                {
                                    nextElem2 = (Element)nextNode;

                                    if (WsFactory.removePrefix(nextElem2.getName()).equalsIgnoreCase(HtmlConst.BODY))
                                    {
                                        use = WsFactory.removePrefix(nextElem2.getAttributeValue(WsdlConst.USE));
                                        if ((use != null) && !use.equals(""))
                                        {
                                            operation.setInputUse(use);
                                        }
                                    }
                                }
                            }

                            //check port child elements
                            name = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.MESSAGE));
                            if ((name != null) && !name.equals(""))
                            {
                                paramInfo = operation.getParameter(name);
                                if (paramInfo == null)
                                {
                                    paramInfo = new WsdlParamInfo(name);
                                    paramInfo.setInOut(WsdlConst.INPUT);
                                    operation.addParameter(paramInfo);
                                }
                            }
                        }
                        else if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.OUTPUT))
                        {
                            //check binding child elements
                            elemList2 = nextElem.getChildren();
                            for (j = 0; j < elemList2.size(); j++)
                            {
                                nextNode = (Node)elemList2.get(j);
                                if (nextNode instanceof Element)
                                {
                                    nextElem2 = (Element)nextNode;
                                    if (WsFactory.removePrefix(nextElem2.getName()).equalsIgnoreCase(HtmlConst.BODY))
                                    {
                                        use = WsFactory.removePrefix(nextElem2.getAttributeValue(WsdlConst.USE));
                                        if ((use != null) && !use.equals(""))
                                        {
                                            operation.setOutputUse(use);
                                        }
                                    }
                                }
                            }

                            //check port child elements
                            name = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.MESSAGE));
                            if ((name != null) && !name.equals(""))
                            {
                                paramInfo = operation.getParameter(name);
                                if (paramInfo == null)
                                {
                                    paramInfo = new WsdlParamInfo(name);
                                    paramInfo.setInOut(WsdlConst.OUTPUT);
                                    operation.addParameter(paramInfo);
                                }
                            }
                        }
                        else if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.INFAULT))
                        {
                            operation.setInFault(faultParser.parse(nextElem));
                        }
                        else if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.OUTFAULT))
                        {
                            operation.setOutFault(faultParser.parse(nextElem));
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parse", null, ex);
            
            if (logger.getDebug())
            {
                LoggerHandler.debugMessage(logger, LoggerHandler.ERROR , "parse", null);
                LoggerHandler.debugError(logger, LoggerHandler.ERROR , ex);
            }

            throw ex;
        }
    }
}
