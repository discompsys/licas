/*
 * DefaultServiceFactory.java
 *
 * Created on 27 October 2011
 *
 * Version 1.7
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service;


import org.ai_heuristic.model.FactoryInfo;
import org.licas.PasswordHandler;
import org.licas.def.ServiceDef;
import org.licas.def.gui.ServiceGuiDef;
import org.licas.meta.LicasConfig;
import org.licas.meta.model.ServiceModuleInfo;
import org.licas.parsers.admin.LicasConfigParser;
import org.licas.service.link.Link_M;
import org.licas.service.sci.LinkService;
import org.licas.util.*;
import org.licas.util.classloader.LoadObject;
import org.licas_xml.abs.Element;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.util.*;


/**
 * The default service factory for the licas services.
 * @author Kieran Greer
 */
public class DefaultServiceFactory extends ServiceFactory
{
    /** The logger */
    private static final Logger logger;
    
    /** 
     * The config handler that stores the service class names.
     */
    protected static LicasConfig licasConfig;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(DefaultServiceFactory.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Create a new instance of LiasServiceFactory. This constructor does not
     * initialise the service factory properly and should be used only to create
     * an instance of the object for type checking.
     */
    public DefaultServiceFactory()
    {}
    
    /**
     * Create a new instance of DefaultServiceFactory. You need to create an instance
     * with a password key for it to be initialised properly.
     * @param factoryKey the key to protect dynamic changes.
     */
    public DefaultServiceFactory(String factoryKey)
    {
        try 
        {
            //parse the gui interfaces
            LicasConfigParser guiParser = new LicasConfigParser();
            licasConfig = guiParser.parseFromFile();               
            ServiceFactory.setServiceFactory(this, factoryKey);
        } 
        catch (Exception ex) 
        {}
    }
    
    /**
     * Add a particular class to be loaded for the specified service type and function.
     * This will automatically overwrite any existing saved class name.
     * @param serviceFunction the function of the service.
     * @param factoryInfo the info object for the interface.
     */
    public void addServiceClass(String serviceFunction, FactoryInfo factoryInfo)
    {
        if (serviceFunction.equals(ServiceConst.DEFAULTSERVICES)) {
            licasConfig.addServiceInfo((ServiceModuleInfo)factoryInfo);
        }
        else {
            licasConfig.addInfo(serviceFunction, factoryInfo);
        }
    }
    
    /**
     * Remove class info for the specified service type and function.
     * @param serviceFunction the function of the service.
     * @param factoryInfo the info object for the interface.
     */
    public void removeServiceClass(String serviceFunction, FactoryInfo factoryInfo)
    {
        licasConfig.removeInfo(serviceFunction, factoryInfo);
    }
    
    /**
     * Return the initialised GUI interface for the specified service.
     * @param serviceType the type of service.
     * @return return a GUI interface that is compatible with the service methods.
     * @throws java.lang.Exception any error.
     */
    public ServiceGuiDef getServiceGui(String serviceType) throws Exception
    {
        int i;
        ArrayList<String> jarFileList;                      //jar file list
        FactoryInfo guiInfo;                                //gui info
        ServiceGuiDef serviceGui;                           //service gui
        ModuleServiceFactory moduleFactory;                 //module factory
        
        serviceGui = null;
        try {
            if (licasConfig.containsServiceType(ServiceConst.GUI, serviceType)) {
                guiInfo = licasConfig.getInfo(ServiceConst.GUI, serviceType);
                jarFileList = new ArrayList<>();
                jarFileList.add(LoadObject.addJarPrefix(guiInfo.filePath.get(0)));
                serviceGui = (ServiceGuiDef)LoadObject.loadObject(jarFileList,
                        guiInfo.className, new ArrayList<>());
            }
            else {
                //add from the modules
                for (i = 0; (serviceGui == null) && (i < serviceModules.size()); i++)
                {
                    moduleFactory = serviceModules.get(i);
                    serviceGui = moduleFactory.getServiceGui(serviceType);
                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "getServiceGui", null, ex);
        }
        
        return serviceGui;
    } 
    
    /**
     * Get a list of the default services that can be loaded.
     * @return the list of default services that can be loaded.
     */
    public ArrayList<ServiceModuleInfo> getDefaultServiceInfo()
    {
        return getDefaultServiceInfo(ServiceConst.ALLCATEGORIES);
    }
    
    /**
     * Get a list of the default services that can be loaded for the category type.
     * Also add related default parsers.
     * @param categoryType the type of category to retrieve default services for.
     * {@link ServiceConst}.{@code ALLCATEGORIES} means all services. If the licas config file
     * has overwritten an entry, then return that instead.
     * @return the list of default services that can be loaded.
     */
    public ArrayList<ServiceModuleInfo> getDefaultServiceInfo(String categoryType)
    {
        int i;
        String nextKey;                                     //next key
        ArrayList<String> allKeys;                          //all keys
        ArrayList<ServiceModuleInfo> defaultServices;       //default services list
        HashMap<String, ServiceModuleInfo> configServices;  //default config services
        ServiceModuleInfo serviceInfo;                      //service info
        ModuleServiceFactory moduleFactory;                 //module factory
        
        defaultServices = new ArrayList<>();
        configServices = licasConfig.getAllServiceInfo();
        changeServiceCategory(configServices);

        allKeys = new ArrayList(configServices.keySet());
        for (i = 0; i < allKeys.size(); i++)
        {
            nextKey = allKeys.get(i);
            serviceInfo = configServices.get(nextKey);
            defaultServices.add(serviceInfo);
        }
        
        if (categoryType.equals(ServiceConst.ALLCATEGORIES) ||
            categoryType.equals(ServiceConst.BUSINESSCATEGORY)) {
            if (!allKeys.contains(ServiceConst.INFORMATION)) {
                serviceInfo = new ServiceModuleInfo();
                serviceInfo.serviceType = ServiceConst.INFORMATION;
                serviceInfo.serviceCategory = ServiceConst.BUSINESSCATEGORY;
                serviceInfo.className = InformationService.class.getName();
                serviceInfo.description = "Service for processing text-based information.";
                serviceInfo.moduleName = "licas_services.jar";
                serviceInfo.iconFile = (ServiceConst.RESOURCESDIR + "iconInfoService.png");

                defaultServices.add(serviceInfo);
                licasConfig.addServiceInfo(serviceInfo);
            }
        }
        
        if (categoryType.equals(ServiceConst.ALLCATEGORIES) ||
            categoryType.equals(ServiceConst.SCIENCECATEGORY)) {
            if (!allKeys.contains(ServiceConst.BEHAVIOUR)) {
                serviceInfo = new ServiceModuleInfo();
                serviceInfo.serviceType = ServiceConst.BEHAVIOUR;
                serviceInfo.serviceCategory = ServiceConst.SCIENCECATEGORY;
                serviceInfo.className = LinkService.class.getName();
                serviceInfo.description = "Base service for evaluation tests. Has autonomous loop.";
                serviceInfo.moduleName = "licas_services.jar";

                defaultServices.add(serviceInfo);
                licasConfig.addServiceInfo(serviceInfo);
            }
        }
        
        if (categoryType.equals(ServiceConst.ALLCATEGORIES) ||
            categoryType.equals(ServiceConst.TESTCATEGORY)) {
            if (!allKeys.contains(Const.SERVICE)) {
                serviceInfo = new ServiceModuleInfo();
                serviceInfo.serviceType = Const.SERVICE;
                serviceInfo.className = DataService.class.getName();
                serviceInfo.serviceCategory = ServiceConst.TESTCATEGORY;
                serviceInfo.description = "Data service for single event testing purposes.";
                serviceInfo.moduleName = "licas_services.jar";

                defaultServices.add(serviceInfo);
                licasConfig.addServiceInfo(serviceInfo);
            }
        }
        
        //add from the modules
        for (i = 0; i < serviceModules.size(); i++)
        {
            moduleFactory = serviceModules.get(i);
            moduleFactory.getDefaultServiceInfo(categoryType, defaultServices, licasConfig);
        }
        
        return defaultServices;
    }
    
    /**
     * Get the class name for a specified service type.
     * @param serviceType the service type.
     * @return the default service class or null if it does not exist.
     */
    public String getDefaultServiceClassname(String serviceType)
    {
        int i;
        String serviceClass;                        //the service class
        ModuleServiceFactory moduleFactory;         //module factory
        
        serviceClass = null;
        switch (serviceType) {
            case Const.SERVICE:
                serviceClass = DataService.class.getName();
                break;
            case ServiceConst.INFORMATION:
                serviceClass = InformationService.class.getName();
                break;
            case ServiceConst.BEHAVIOUR:
                serviceClass = LinkService.class.getName();
                break;
            case ServiceConst.LINKER:
                serviceClass = Link_M.class.getName();
                break;
        }
        
        if (serviceClass == null) {
            //add from the modules
            for (i = 0; (serviceClass == null) && (i < serviceModules.size()); i++)
            {
                moduleFactory = serviceModules.get(i);
                serviceClass = moduleFactory.getDefaultServiceClassname(serviceType);
            }
        }
        
        return serviceClass;
    }
    
    /**
     * Create a new default service or module. This must be a recognised module from its
     * service type, for this service factory.
     * @param serviceUuid the uuid for the new default service to add.
     * @param serviceType the type of service to create. Note that a uuid is not set.
     * @param adminXml the admin info or description of the new service.
     * @param passwordHandler the password handler for the service that calls this method.
     * @return the service or module if it can be created, null otherwise.
     * @throws java.lang.Exception any error.
     */
    public ServiceDef createDefaultService(String serviceUuid, String serviceType,
            Element adminXml, PasswordHandler passwordHandler) throws Exception
    {
        int i;
        ServiceDef newService;                         //new service
        ModuleServiceFactory moduleFactory;         //module factory
        
        newService = null;
        switch (serviceType) {
            case Const.SERVICE:
                newService = new DataService(passwordHandler.getServicePassword(serviceUuid),
                        passwordHandler.getAdminKey(serviceUuid), adminXml);
                break;
            case ServiceConst.INFORMATION:
                newService = new InformationService(passwordHandler.getServicePassword(serviceUuid),
                        passwordHandler.getAdminKey(serviceUuid), adminXml);
                break;
            case ServiceConst.BEHAVIOUR:
                newService = new LinkService(passwordHandler.getServicePassword(serviceUuid),
                        passwordHandler.getAdminKey(serviceUuid), adminXml);
                break;
            case ServiceConst.LINKER:
                newService = new Link_M();
                break;
        }
        
        if (newService == null) {
            //add from the modules
            for (i = 0; (newService == null) && (i < serviceModules.size()); i++)
            {
                moduleFactory = serviceModules.get(i);
                newService = moduleFactory.createDefaultService(serviceUuid, serviceType,
                        adminXml, passwordHandler);
            }
        }
        
        return newService;
    }
    
    /**
     * Return the stored service class for the specified service type. This is only
     * for the known default service types, not any types added by a user. For the 
     * Linker service the most commonly used class is returned. The LinkConfig
     * class can be passed the linking method to return a more accurate result.
     * @param serviceType the type of service.
     * @return the service class stored for that type, or null if it is missing.
     * @throws java.lang.Exception any error.
     */
    public String getServiceClass(String serviceType) throws Exception
    {
        int i;
        String serviceClass;                        //service class
        ModuleServiceFactory moduleFactory;         //module factory
        
        serviceClass = null;
        switch (serviceType) {
            case Const.SERVICE:
                serviceClass = DataService.class.getName();
                break;
            case ServiceConst.INFORMATION:
                serviceClass = InformationService.class.getName();
                break;
            case ServiceConst.BEHAVIOUR:
                serviceClass = LinkService.class.getName();
                break;
            case ServiceConst.LINKER:
                serviceClass = Link_M.class.getName();
                break;
        }
        
        if (serviceClass == null) {
            //add from the modules
            for (i = 0; (serviceClass == null) && (i < serviceModules.size()); i++)
            {
                moduleFactory = serviceModules.get(i);
                serviceClass = moduleFactory.getServiceClass(serviceType);
            }
        }
        
        return serviceClass;
    }

    /**
     * Do some forced changes to the selected service category for some services.
     * @param configServices default services, maybe read from a file.
     */
    private void changeServiceCategory(HashMap<String, ServiceModuleInfo> configServices) {

        ServiceModuleInfo serviceInfo;          //service info

        for (String sKey : configServices.keySet())
        {
            serviceInfo = configServices.get(sKey);

            if (sKey.equals(ServiceConst.MESSAGE) ||
                    sKey.equals(ServiceConst.MESSAGEBOARD) ||
                    sKey.equals(ServiceConst.FILE)) {
                serviceInfo.serviceCategory = ServiceConst.PERSONALCATEGORY;
            }
        }
    }
}
