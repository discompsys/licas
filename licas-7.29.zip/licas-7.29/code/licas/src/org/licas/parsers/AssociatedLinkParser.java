/*
 * AssociatedLinkParser.java
 *
 * Created on 24 October 2025
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers;


import org.ai_heuristic.def.ParserDef;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.service.link.AssociatedLink;
import org.licas.service.link.PermanentLink;
import org.licas.util.Const;
import org.licas.util.ObjectHandler;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;

import java.util.*;


/**
 * This class serialises and parses the association links to or from XML.
 * The saved value is restricted to be xml path descriptions. not objects.
 * @author Kieran Greer
 */
public class AssociatedLinkParser implements ParserDef
{
    /** The logger */
    private static final Logger logger;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(AssociatedLinkParser.class.getName());
        logger.setDebug(false);
    }


    /** Creates a new instance of AssociatedLinkParser */
    public AssociatedLinkParser() {
    }

    /**
     * Serialize the permanent links into XML.
     * @param toSerialize the {@link PermanentLink} object to serialize.
     * @return the links in XML format.
     * @throws Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        int i;
        String nextKey;                         //next key
        ArrayList<String> idList;               //the ids
        AssociatedLink assocLinks;              //association links
        Element linkElem;                       //link element
        Element nextElem;                       //next link element
        Object nextLink;                        //next link

        assocLinks = (AssociatedLink)toSerialize;
        linkElem = XMLFactory.getInstance().createElement(Const.ASSOCIATEDLINKS);

        idList = assocLinks.getAllLinkIDs();
        for (i = 0; i < idList.size(); i++)
        {
            nextKey = idList.get(i);
            nextElem = XMLFactory.getInstance().createElement(Const.LINK);
            nextElem.setAttribute(Const.KEY, nextKey);

            nextLink = assocLinks.getLink(nextKey);
            if (!(nextLink instanceof Element)) {
                nextLink = ObjectHandler.getElementPath(nextLink);
            }

            nextElem.addContent((Element)((Element)nextLink).clone());
            linkElem.addContent(nextElem);
        }

        return linkElem;
    }

    /**
     * Parse the xml description back into a {@link PermanentLink} object.
     * @param toParse the XML-based description.
     * @return the parsed links.
     * @throws Exception any error.
     */
    public Object parse(Element toParse) throws Exception {
        int i;
        String nextKey;                         //next key
        AssociatedLink assocLinks;              //association links
        Element nextElem;                       //next link element
        Vector elemList;                        //element list

        assocLinks = new AssociatedLink();

        elemList = toParse.getChildren();
        for (i = 0; i < elemList.size(); i++) {
            nextElem = (Element) elemList.get(i);
            if (nextElem.getName().equalsIgnoreCase(Const.LINK)) {
                nextKey = nextElem.getAttributeValue(Const.KEY);
                assocLinks.addLink(nextKey, nextElem.getElementChildAtIndex(0));

            }
        }

        return assocLinks;
    }
}
