/*
 * PermanentLinkParser.java
 *
 * Created on 24 October 2025
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers;


import org.ai_heuristic.def.ParserDef;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.service.link.PermanentLink;
import org.licas.util.Const;
import org.licas.util.ObjectHandler;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;
import java.util.Vector;


/**
 * This class serialises and parses the permanent links to or from XML.
 * The saved value is restricted to be xml path descriptions. not objects.
 * @author Kieran Greer
 */
public class PermanentLinkParser implements ParserDef
{
    /** The logger */
    private static final Logger logger;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(PermanentLinkParser.class.getName());
        logger.setDebug(false);
    }


    /** Creates a new instance of PermanentLinkParser */
    public PermanentLinkParser() {
    }

    /**
     * Serialize the permanent links into XML.
     * @param toSerialize the {@link PermanentLink} object to serialize.
     * @return the links in XML format.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        int i;
        String nextKey;                         //next key
        ArrayList<String> idList;               //the ids
        PermanentLink permanentLink;            //permanent links
        Element linkElem;                       //link element
        Element nextElem;                       //next link element
        Element nextElem2;                      //next link element
        Object nextLink;                        //next link

        permanentLink = (PermanentLink)toSerialize;
        linkElem = XMLFactory.getInstance().createElement(Const.PERMANENTLINKS);

        //to-links
        nextElem = XMLFactory.getInstance().createElement(Const.TO);
        linkElem.addContent(nextElem);

        idList = permanentLink.getAllLinkToServiceIDs();
        for (i = 0; i < idList.size(); i++)
        {
            nextKey = idList.get(i);
            nextElem2 = XMLFactory.getInstance().createElement(Const.LINK);
            nextElem2.setAttribute(Const.KEY, nextKey);

            nextLink = permanentLink.getLinkToService(nextKey);
            if (!(nextLink instanceof Element)) {
                nextLink = ObjectHandler.getElementPath(nextLink);
            }

            nextElem2.addContent((Element)((Element)nextLink).clone());
            nextElem.addContent(nextElem2);
        }

        //from-links
        nextElem = XMLFactory.getInstance().createElement(Const.FROM);
        linkElem.addContent(nextElem);

        idList = permanentLink.getAllLinkFromServiceIDs();
        for (i = 0; i < idList.size(); i++)
        {
            nextKey = idList.get(i);
            nextElem2 = XMLFactory.getInstance().createElement(Const.LINK);
            nextElem2.setAttribute(Const.KEY, nextKey);

            nextLink = permanentLink.getLinkFromService(nextKey);
            if (!(nextLink instanceof Element)) {
                nextLink = ObjectHandler.getElementPath(nextLink);
            }

            nextElem2.addContent((Element)((Element)nextLink).clone());
            nextElem.addContent(nextElem2);
        }

        return linkElem;
    }

    /**
     * Parse the xml description back into a {@link PermanentLink} object.
     * @param toParse the XML-based description.
     * @return the parsed links.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception {
        int i, j;
        String nextKey;                         //next key
        PermanentLink permanentLink;            //permanent links
        Element nextElem;                       //next link element
        Element nextElem2;                      //next link element
        Vector elemList;                        //element list
        Vector elemList2;                       //element list

        permanentLink = new PermanentLink();

        elemList = toParse.getChildren();
        for (i = 0; i < elemList.size(); i++) {
            nextElem = (Element) elemList.get(i);
            if (nextElem.getName().equalsIgnoreCase(Const.TO)) {
                elemList2 = nextElem.getChildren();
                for (j = 0; j < elemList2.size(); j++) {
                    nextElem2 = (Element) elemList2.get(j);
                    if (nextElem2.getName().equalsIgnoreCase(Const.LINK)) {
                        nextKey = nextElem2.getAttributeValue(Const.KEY);
                        permanentLink.addLinkToService(nextKey, nextElem2.getElementChildAtIndex(0));
                    }
                }
            }
            else {
                elemList2 = nextElem.getChildren();
                for (j = 0; j < elemList2.size(); j++) {
                    nextElem2 = (Element) elemList2.get(j);
                    if (nextElem2.getName().equalsIgnoreCase(Const.LINK)) {
                        nextKey = nextElem2.getAttributeValue(Const.KEY);
                        permanentLink.addLinkFromService(nextKey, nextElem2.getElementChildAtIndex(0));
                    }
                }
            }
        }

        return permanentLink;
    }
}
