/*
 * ServiceWrapper.java
 *
 * Created on 15 October 2019
 *
 * Version 1.3
 *
 * Copyright (c) Kieran Greer
 *
 */

package org.licas;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.autonomic.AutonomicManager;
import org.licas.call.MethodInfo;
import org.licas.def.ServiceWrapperDef;
import org.licas.module.*;
import org.licas.security.Metrics;
import org.licas.service.model.Contract;
import org.licas.service.model.WorkInfo;
import org.licas.util.Const;
import org.licas.util.exception.ServiceException;
import org.licas_xml.abs.Element;

import java.lang.reflect.Method;
import java.util.ArrayList;


/**
 * This class is a wrapper to store any object that may be invoked as a service or from a service.
 * Any service that is loaded onto the network is wrapped first. It can then only be
 * accessed through using the correct password. There are two service wrappers - this
 * stores a licas {@link Service} object and a {@link ServiceWrapperLegacy} stores a {@code Legacy} object.
 * The autonomic manager is also an extension of this wrapper, but it only stores an
 * {@link Auto}-derived object and would also allow for autonomic monitoring capabilities.
 * This means that any object can actually be loaded and stored as a service. The wrapper
 * class extends either a {@link FrameworkModule} or a full {@code Service}, depending on
 * what additional functionality is required. This would mean that any object can be
 * used as part of the licas system and the object methods can be found and invoked.
 * @author Kieran Greer
 */
public class ServiceWrapper extends ServiceModule implements ServiceWrapperDef
{
    /** The logger */
    private static final Logger logger;

    /** True if structures for enclosed service object already set */
    protected boolean setStructures;

    /** Measurements of general message/transaction numbers */
    protected Metrics metrics;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServiceWrapper.class.getName());
        logger.setDebug(false);
    }

    /**
     * Creates a new instance of ServiceWrapper.
     * @param theService the service to monitor.
     * @throws Exception any error.
     */
    public ServiceWrapper(Service theService) throws Exception
    {
        super();
        setServiceDetails(theService, theService.getPasswordHandler());
        initialise();
    }

    /** Initialise some values. */
    private void initialise()
    {
        setStructures = false;
        metrics = null;
    }

    /**
     * Return true if the stored object is legacy code, false if a licas service.
     * @return false in this case.
     */
    public boolean storesLegacy()
    {
        return false;
    }

    /**
     * This run method tries to start the run method on the embedded object.
     * You should override run in the embedded object to include your own process.
     */
    public void run() {
        try {
            if (service != null) {
                service.start();
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "run", null, ex);
        }
    }

    /**
     * Copy and set certain settings between the service object and the wrapper.
     * @param parent the parent of the wrapper.
     * @throws Exception any error.
     */
    public final void copyToService(Object parent) throws Exception
    {
        try {
            if (!setStructures) {
                service.setUUID(getUUID());
                service.setServiceType(getServiceType());
                service.setJarFile(jarFile);

                if (ModuleHandler.isService(parent) && !ModuleHandler.isServer(parent)) {
                    service.setParent((Service) parent);
                }

                if (ModuleHandler.isAuto(service) && ModuleHandler.isAutoManager(this)) {
                    ((Auto) service).setAutonomicManager((AutonomicManager) this);
                }

                passwordHandler = service.getPasswordHandler();
            }
        }
        finally {
            setStructures = true;
        }
    }

    /**
     * Reset the wrapper settings based on the wrapped object if a service.
     */
    public final void copyFromService()
    {
        Service serviceObj;                     //object as a service

        try {
            if (!setStructures) {
                serviceObj = service;
                setUUID(serviceObj.getUUID());
                setServiceType(serviceObj.getServiceType());
                setJarFile(serviceObj.getJarFile());
                service.setParent(serviceObj.getParent());

                passwordHandler = serviceObj.getPasswordHandler();
                service.serviceAdmin.services = serviceObj.serviceAdmin.services;
                service.serviceAdmin.serviceTypes = serviceObj.serviceAdmin.serviceTypes;
            }
        }
        finally {
            setStructures = true;
        }
    }

    /**
     * Return true if the password allows the calling component
     * to access this component by a temp password.
     * @param thePassword the password to use.
     * @return true if the entered password is the valid.
     */
    public boolean canAccessTemp(String thePassword)
    {
        return service.canAccessTemp(thePassword);
    }

    /**
     * Return true if the wrapped object can be accessed by the password.
     * If the object is of type {@code Service} then its {@code canAccess} method is called,
     * otherwise true is automatically returned.
     * @param thePassword the password to use.
     * @return true if the wrapped object can be accessed or false otherwise.
     */
    public boolean canAccess(String thePassword)
    {
        return service.canAccess(thePassword);
    }

    /**
     * Return true if the method on the wrapped object can be accessed by the password.
     * If the object is of type {@code Service} then its {@code canAccess} method is called,
     * otherwise true is automatically returned.
     * @param thePassword the password to use.
     * @param theMethod the name of the method to call.
     * @return true if the wrapped object can be accessed or false otherwise.
     * @throws java.lang.Exception nay error.
     */
    public boolean canAccess(String thePassword, String theMethod) throws Exception
    {
        return service.canAccess(thePassword, theMethod);
    }

    /**
     * Return true if the method on the wrapped object can be accessed by the password.
     * If the object is of type {@code Service} then its {@code canAccess} method is called,
     * otherwise true is automatically returned.
     * @param thePassword the password to use.
     * @param theMethod the method reflection description.
     * @return true if the wrapped object can be accessed or false otherwise.
     * @throws java.lang.Exception nay error.
     */
    public boolean canAccess(String thePassword, Method theMethod) throws Exception
    {
        return service.canAccess(thePassword, theMethod);
    }

    /**
     * Get this service's password, depending on the calling component's contract description.
     * By default, a service is assigned a 'yes' contract, meaning that it is open and
     * will always return its password, to allow for method invocation. The other default
     * option is a 'no' contract, meaning that there is no negotiation and the password
     * must be known. This can also be changed by adding a different 'sla' contract for
     * each service level in the service. You can therefore override this method
     * to provide your own checks, using this as a guide.
     * @param clientID the clientID of the calling component.
     * @param clientContract the description of the calling component's contract proposal.
     * @return the value of the password for the specified service level if the contract
     * is accepted, or null if it is not accepted. The default 'yes' contract always
     * returns the password.
     * @throws Exception any error.
     */
    public String getPassword(String clientID, Contract clientContract) throws Exception
    {
        return service.getPassword(clientID, clientContract);
    }

    /**
     * Get the password for this service.
     * If the wrapped object is a service then its {@code getPassword} method is called,
     * otherwise this wrapper's getPassword method is called.
     * @param theAdminKey the service key.
     * @return the access password for this service.
     */
    public String getPassword(String theAdminKey)
    {
        return service.getPassword(theAdminKey);
    }

    /**
     * Get the password for the specified service.
     * If the wrapped object is a service then its {@code getPassword} method is called,
     * otherwise this wrapper's getPassword method is called.
     * @param serviceUuid the id of the service to ask the password for.
     * @param theAdminKey the service key.
     * @return the password for the specified service or null if it cannot be retrieved.
     * @throws Exception any error.
     */
    public String getPassword(String serviceUuid, String theAdminKey) throws Exception
    {
        return service.getPassword(serviceUuid, theAdminKey);
    }

    /**
     * Add some metrics values relating to the current message.
     * @param messageObj the message object.
     * @param theAdminKey the admin key for the parent service.
     */
    public void addMetrics(MethodInfo messageObj, String theAdminKey)
    {
        if (metrics == null) {
            metrics = Metrics.createMetrics(service);
        }
        if (service.getPasswordHandler().getAdminKey().equals(theAdminKey)) {
            metrics.addMetrics(messageObj);
        }
    }

    /**
     * Get the default message/transaction metrics.
     * @return the value of metrics.
     */
    public Metrics getMetrics()
    {
        return metrics;
    }

    /**
     * Store the commID with the related client URI, on the embedded service. Stored as {@link MessageInfo}
     * objects with timestamps. The method now also checks the timestamps and removes any communicationIDs
     * that are older than 3 days.
     * @param commID the communication id.
     * @param clientURI the URI/reference for the calling client. If {@code null} or a server URI,
     * then it is set to {@link Const}.{@code ANON} and only the commID is subsequently checked for.
     * @return true if the id is new and can be added, or false if the comm id already
     * exists, or cannot be added.
     * @throws Exception any error.
     */
    protected boolean addCommunicationID(String commID, Object clientURI) throws Exception
    {
        return service.addCommunicationID(commID, clientURI);
    }

    /**
     * Set the service grade or function class.
     * @param thisServiceGrade the service grade.
     */
    public void setServiceGrade(String thisServiceGrade)
    {
        service.setServiceGrade(thisServiceGrade);
    }

    /**
     * Get the grade for this service.
     * @return the value of serviceGrade.
     */
    public String getServiceGrade()
    {
        return service.getServiceGrade();
    }

    /**
     * Get the description value. This is just the description and not the full
     * set of admin rules.
     * @return the service description.
     */
    public Element getDescription()
    {
        return service.getDescription();
    }

    /**
     * Get the work protocol details for the service.
     * @return the service's {@code workInfo} details.
     */
    public WorkInfo getWorkInfo() { return service.serviceAdmin.workInfo; }

    /**
     * Set the password that will allow this service to access the server it runs on.
     * @param thePassword the server password.
     * @throws java.lang.Exception any error.
     */
    protected void setServerPassword(String thePassword) throws Exception
    {
        service.setServerPassword(thePassword);
    }

    /**
     * Set the parent component value. If the parent is the ESB server then it is
     * not added, so only for child services.
     * @return true if set, false if already set, or try to add server.
     * @param thisParent the parent component representation.
     */
    protected boolean setParent(Service thisParent)
    {
        return service.setParent(thisParent);
    }

    /**
     * Get the fully qualified uuid path back to the first parent object and server.
     * @return the fully qualified path to access this component on the server.
     * @throws java.lang.Exception any error.
     */
    public Element getFullPath() throws Exception
    {
        return service.getFullPath();
    }

    /**
     * Return the service for the related service name.
     * If the wrapped object is a service then its {@code getService} method is called,
     * otherwise this wrapper's getService method is called.
     * @param serviceName the name of the service.
     * @param thePassword the password to access the service to retrieve.
     * @return the wrapped service, or null if no service exists.
     * @throws ServiceException is access to any nested services is blocked.
     * @throws Exception any other error.
     */
    public ServiceWrapperDef getService(String serviceName, String thePassword)
            throws ServiceException, Exception
    {
        return service.getService(serviceName, thePassword);
    }

    /**
     * Return the service for the related service name.
     * If the wrapped object is a service then its {@code getService} method is called,
     * otherwise this wrapper's execute method is called.
     * This method requires the service key as well, but then returns a direct reference.
     * @param serviceName the name of the service.
     * @param thePassword the password to access the service.
     * @param adminKey the service key for this server.
     * @return the service object if it exists or null if it does not.
     * @throws ServiceException for service specific error.
     * @throws Exception any other error.
     */
    public Object getService(String serviceName, String thePassword, String adminKey)
        throws ServiceException, Exception
    {
        return service.getService(serviceName, thePassword, adminKey);
    }

    /**
     * Set the wrapped object that is typically derived from {@link Service},
     * but can be a legacy object of any type.
     * @param theObj the value of obj.
     */
    public void setObjService(Object theObj)
    {
        if (service == null) service = (Service)theObj;
    }

    /**
     * Get the stored object service.
     * @param adminKey the admin key for the object or wrapper.
     * @return the stored object, or null if not the admin key.
     */
    public Object getObjService(String adminKey)
    {
        if ((adminKey != null) &&
                service.getPasswordHandler().isAdminKey(adminKey))
        {
            return service;
        }

        return null;
    }

    /**
     * Get the class type of the stored object.
     * @return the stored object class name.
     */
    public Class getObjClass()
    {
        if (service != null) return service.getClass();
        else return null;
    }

    /**
     * Execute the specified method and return the result.
     * If the wrapped object is a service then its execute method is called,
     * otherwise this wrapper's execute method is called.
     * @param methodInfo the method call description with all of the required information.
     * @param addTempPassword if true add a temporary password to allow traversal
     * through this service. If the service is referenced directly as an object
     * then set this to false so that the caller must know this service's password.
     * @return the reply, any object.
     * @throws ServiceException any service specific error.
     * @throws Exception any other error.
     */
    public Object execute(MethodInfo methodInfo, boolean addTempPassword)
            throws ServiceException, Exception
    {
        if (canAccess(methodInfo.getPassword()))
        {
            return (service.execute(methodInfo, addTempPassword));
        }
        else
        {
            throw new ServiceException("ServiceWrapper.execute: incorrect password for service " +
                    service.getUUID());
        }
    }

    /**
     * Get a list of public methods that can be accessed through the service, not this wrapper.
     * @return a list of Reflection method descriptions, not the licas descriptions.
     */
    public ArrayList<Method> reflectionMethods()
    {
        return service.reflectionMethods();
    }

    /**
     * Invoke the method on the stored object with the specified parameters.
     * @param theMethod the method to invoke.
     * @param params the parameter list.
     * @return the result of the method invocation.
     * @throws Exception any error.
     */
    public Object invokeObj(Method theMethod, Object[] params) throws Exception
    {
        if (service != null) {
            return theMethod.invoke(service.reflectionObject(theMethod), params);
        }
        else {
            return null;
        }
    }

    /**
     * You must call this method to interrupt the thread.
     * This also interrupts all nested services.
     * You also need to implement an interrupt method in the wrapped object 
     * directly to shut it down if a running thread.
     * @param adminKey the key to identify unique loading of the service.
     * @return true if the service is stopped.
     */
    public boolean interrupt(String adminKey)
    {
        boolean isOK;                       //true if OK

        isOK = false;
        try
        {
            isOK = (service.interrupt(adminKey));
        } 
        catch (Exception ex) 
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "interrupt", null, ex);
        }

        return isOK;
    }
    
    /**
     * Return the thread state of the embedded object.
     * @return the embedded object state if a thread.
     */
    public String threadAliveState()
    {
        if (service != null) {
            String.valueOf(service.isAlive());
        }

        return String.valueOf(Boolean.FALSE);
    }
}
