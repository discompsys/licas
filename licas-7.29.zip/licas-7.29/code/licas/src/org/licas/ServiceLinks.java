/*
 * ServiceLinks.java
 *
 * Created on 9 September 2011
 *
 * Version 1.5.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.call.CallObject;
import org.licas.call.Handle;
import org.licas.call.MethodFactory;
import org.licas.call.MethodInfo;
import org.licas.service.link.AssociatedLink;
import org.licas.service.link.PermanentLink;
import org.licas.util.*;
import org.licas.util.exception.PasswordException;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * This class stores all of the different service link types and processes them as required.
 * This includes nested child services (not strictly links) and permanent or association links. 
 * The dynamic links are stored in the dynamic linking structure, but an XML-based description 
 * of that can be retrieved here as well.
 * @author Kieran Greer
 */
public class ServiceLinks
{
    /** The logger */
    private static final Logger logger;


    /** This is the ID of the parent component */
    protected String uuid;

    /** The parent service reference */
    protected Element serviceRef;

    /** The parent service's password handler */
    protected PasswordHandler passwordHandler;
    
    /** 
     * The child service ids. Values are the ids of type String.
     */
    public ArrayList<String> childServices;
    
    /** 
     * This stores references to other local services that are permanently linked
     * to this one. This forms the local network structure.
     */
    protected PermanentLink permanentLinks;

    /**
     * This stores references to other, probably remote, services that
     * this service knows about. Could be called a link or just an association.
     * The information is stored as String-based descriptions of the other
     * services' full path locations.
     */
    protected AssociatedLink serviceAssociations;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServiceLinks.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of ServiceLinks.
     * @param theUuid the uuid of the parent service.
     * @param theServiceRef the parent service reference.
     * @param ph the parent service password handler.
     */
    public ServiceLinks(String theUuid, Element theServiceRef, PasswordHandler ph)
    {
        uuid = theUuid;
        serviceRef = theServiceRef;
        passwordHandler = ph;
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        clearLinks(passwordHandler.getAdminKey());
        childServices = new ArrayList<>();
    }
    
    /** 
     * Reset the linking structures.
     * @param adminKey the parent service's admin key to allow access.
     */
    protected void clearLinks(String adminKey)
    {
        if (adminKey.equals(passwordHandler.getAdminKey())) {
            permanentLinks = new PermanentLink();
            serviceAssociations = new AssociatedLink();
        }
    }
    
    /** 
     * Reset the linking structures, by removing links for the specified services.
     * @param serviceIDs list of services to remove linking info for.
     * @param adminKey the parent service's admin key to allow access.
     * @throws java.lang.Exception any error.
     */
    protected void clearLinks(ArrayList<?> serviceIDs, String adminKey) throws Exception
    {
        String serviceID;                               //next service id
        
        if (adminKey.equals(passwordHandler.getAdminKey())) {
            for (Object keyObj: serviceIDs) {
                serviceID = ObjectHandler.getKey(keyObj);
                permanentLinks.removeLinkToService(serviceID);
                permanentLinks.removeLinkFromService(serviceID);
                serviceAssociations.removeLink(serviceID);
            }
        }
    }
    
    /**
     * Add a new uri for a link to a (probably remote) service. This is simply
     * an association link created from a single call. It is different to a permanent
     * link in the sense that it probably does not make up any permanent network structure.
     * It can act in the same way though. It is also different from a dynamic link
     * which is built up over time through reinforcement. Including this link type simply
     * covers the different types of service associations that you might want to make.
     * @param serviceKey the key value that the service association is stored under.
     * @param servicePath the service association reference. It might not contain the key value.
     * @throws java.lang.Exception any other error.
     * @return true if added or false if it already exists.
     */
    protected boolean addServiceAssociation(String serviceKey, Object servicePath) throws Exception
    {
        try {
            return serviceAssociations.addLink(serviceKey, servicePath);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "addServiceAssociation", null, ex);
        }
    }
    
    /**
     * Remove a uri for a link to a (probably remote) service association.
     * @param serviceKey the key value that the service association is stored under.
     * @throws java.lang.Exception any other error.
     */
    protected void removeServiceAssociation(String serviceKey) throws Exception
    {
        try {
            serviceAssociations.removeLink(serviceKey);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "removeServiceAssociation", null, ex);
        }
    }
    
    /**
     * Get the list of (probably remote) service links to other known about services.
     * @return the value of serviceAssociations, as a list of Elements.
     * @throws java.lang.Exception any error.
     */
    public ArrayList<Element> getServiceAssociations() throws Exception
    {
        int i;
        String assocStr;                        //next association path
        Element assocElem;                      //association element
        ArrayList<Element> linksList;           //links list
        ArrayList<Object> assocList;            //list of associations
        Object assocObj;                        //next association object
        
        try {
            linksList = new ArrayList<>();
            if (serviceAssociations != null) {
                assocList = new ArrayList<>(serviceAssociations.getAllLinks());
                for (i = 0; i < assocList.size(); i++)
                {
                    assocObj = assocList.get(i);                
                    if (ObjectHandler.isElement(assocObj)) {
                        linksList.add((Element)assocObj);
                    }
                    else {
                        try {
                            assocElem = ObjectHandler.getElementPath(assocObj);
                            linksList.add((Element)assocElem.clone());
                        }
                        catch (Exception ex2) {
                            assocStr = ObjectHandler.getValue(assocObj);
                            assocElem = XMLFactory.getInstance().createElement(Const.LINK);
                            assocElem.setText(assocStr);
                            linksList.add(assocElem);
                        }
                    }         
                }
            }

            return linksList;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "getServiceAssociations", null, ex);
        }
    }
    
    /**
     * Create a permanent link from this service to another service.
     * This method also calls the other service remotely to ask it to create
     * a link to this service as well.
     * @param serviceTo the unique ID of the service to create a link to.
     * @param servicePassword the password to call the other service.
     * @param servicePath the path to the other service.
     * @return true if the link is successfully created.
     * @throws java.lang.Exception any error.
     */
    public boolean createPermanentLinkTo(String serviceTo, String servicePassword, Element servicePath)
            throws Exception
    {
        boolean isOK;                       //true if OK
        String serverUri;                   //remote server uri
        String serverPassword;              //the server password
        ArrayList<Object> parameters;       //method info parameters
        MethodInfo methodInfo;              //method info
        CallObject call;                    //call object
        Object replyObj;                    //reply object
        
        isOK = false;

        try {
            //do not add the link if one already exists in the other direction
            if (permanentLinks.getLinkFromService(serviceTo) == null) {
                //retrieve server password
                //permanent links local, so only look for local server
                try {
                    serverPassword = passwordHandler.getServicePassword(Const.HTTPSERVER, null);
                }
                catch (Exception ex) {
                    serverUri = XmlHandler.xmlToString(Handle.addToHandle(Handle.createNewUrlHandle(Handle.getURL(servicePath)),
                        Handle.asHandleElement(Const.HTTPSERVER)));

                    serverPassword = passwordHandler.getServicePassword(serverUri, null);
                }

                if (serverPassword != null) {
                    passwordHandler.addServicePassword(serviceTo, servicePassword);
                    call = new CallObject();

                    parameters = new ArrayList<>();
                    parameters.add(uuid);
                    parameters.add(serviceRef);

                    methodInfo = MethodFactory.createMethodCall(MethodConst.ADDLINKFROMSERVICE, TypeConst.BOOLEAN,
                            servicePath, parameters, passwordHandler);
                    methodInfo.setServerPassword(serverPassword);
                    methodInfo.setCallTimeout((int)TimeConst.MILLIMINUTE);
                    replyObj = call.call(methodInfo);

                    if (!ObjectHandler.isNull(replyObj) && ObjectHandler.isBoolean(replyObj)) {
                        isOK = (Boolean)replyObj;
                        if (isOK) {
                            addLinkToService(serviceTo, servicePath);
                        }
                    }
                }
            }
        }
        catch (PasswordException pe) {
            //can process here to try and get the password?
        }
        
        return isOK;
    }
    
    /**
     * Remove a permanent link from this service to another service.
     * This method also calls the other service remotely to ask it to remove
     * the same link from reference to this service.
     * @param serviceTo the unique ID of the service to remove a link to.
     * @param servicePassword the password to call the other service.
     * @param servicePath the path to the other service.
     * @return true if the link is successfully removed.
     * @throws java.lang.Exception any error.
     */
    public boolean removePermanentLinkTo(String serviceTo, String servicePassword, Element servicePath)
            throws Exception
    {
        boolean isOK;                           //true if OK
        String serverUri;                       //remote server uri
        String serverPassword;                  //the server password
        ArrayList<Object> parameters;           //method info parameters
        Element serverPath;                     //server path
        MethodInfo methodInfo;                  //method info
        CallObject call;                        //call object
        
        isOK = true;
        
        try {
            serverUri = Handle.getURL(servicePath);
            serverPath = Handle.createNewUrlHandle(serverUri);
            serverPath = Handle.addToHandle(serverPath, Handle.asHandleElement(Const.HTTPSERVER));
            serverUri = XmlHandler.xmlToString(serverPath);
            serverPassword = passwordHandler.getServicePassword(serverUri, null);

            if (serverPassword != null) {
                passwordHandler.addServicePassword(serviceTo, servicePassword);
                call = new CallObject();

                parameters = new ArrayList<>();
                parameters.add(uuid);

                methodInfo = MethodFactory.createMethodCall(MethodConst.REMOVELINKFROMSERVICE, TypeConst.VOID,
                        servicePath, parameters, passwordHandler);
                methodInfo.setServerPassword(serverPassword);
                call.call(methodInfo);
                
                removeLinkToService(serviceTo);
            }
        }
        catch (PasswordException pe) {
            isOK = false;
            //can process here to try and get the password?
        }
        
        return isOK;
    }
    
    /**
     * Add a link reference to another service locally in this service.
     * @param serviceID a unique id to identify the service.
     * @param theReference the source reference (Object or XML URI).
     * @return true if the link is added or false if the id already exists.
     */
    protected boolean addLinkToService(String serviceID, Object theReference)
    {
        return permanentLinks.addLinkToService(serviceID, theReference);
    }
    
    /**
     * Remove the local link to the specified service if it exists.
     * This should not be called directly, but is called through the 
     * {@code removePermanentLinkTo} method.
     * @param serviceID the id of the service being linked to.
     */
    protected void removeLinkToService(String serviceID)
    {
        permanentLinks.removeLinkToService(serviceID);
    }
    
    /**
     * Get all source references for a links to another service.
     * @return a list of all source references, or null if no links exist.
     */
    protected ArrayList<Object> getAllLinkToService()
    {
        return permanentLinks.getAllLinkToService();
    }
    
    /**
     * Get the source reference for a link to another service.
     * @param serviceID the id of the service linked to.
     * @return the value of source or null if no link exists.
     */
    public Object getLinkToService(String serviceID)
    {
        return permanentLinks.getLinkToService(serviceID);
    }
    
    /**
     * Add a link from another service locally in this service.
     * This method should not be called directly, but is done through the
     * {@code createPermanentLinkTo} method on the remote service creating the link.
     * @param serviceID a unique id to identify the service.
     * @param theReference the source reference (Object or XML URI).
     * @return true if the link is added or false if the id already exists.
     */
    public boolean addLinkFromService(String serviceID, Object theReference)
    {
        return permanentLinks.addLinkFromService(serviceID, theReference);
    }
    
    /**
     * Remove the local link from the specified service if it exists.
     * This method should not be called directly, but is done through the
     * {@code removePermanentLinkTo} method on the remote service removing the link.
     * @param serviceID the id of the service being linked to.
     */
    public void removeLinkFromService(String serviceID)
    {
        permanentLinks.removeLinkFromService(serviceID);
    }
    
    /**
     * Get the source reference for a link from another service.
     * @param serviceID the id of the service linked to.
     * @return the value of source or null if no link exists.
     */
    public Object getLinkFromService(String serviceID)
    {
        return permanentLinks.getLinkFromService(serviceID);
    }
    
    /**
     * Get the list of permanent links.
     * @return the value of permanentLinks.
     */
    public PermanentLink getPermanentLinks()
    {
        return permanentLinks;
    }
    
    /**
     * Add the service id as a nested child service.
     * @param serviceID the service id for a nested child service.
     * @return true if added or false if the meta uuid already exists.
     */
    public boolean addChildService(String serviceID)
    {
        if (!childServices.contains(serviceID)) {
            childServices.add(serviceID);
            return true;
        }
        
        return false;
    }
    
    /**
     * Remove the child service id from the metadata.
     * @param serviceID the service id to remove.
     */
    public void removeChildService(String serviceID)
    {
        childServices.remove(serviceID);
    }
}
