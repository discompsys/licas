/*
 * ServiceHandler.java
 *
 * Created on 10 October 2019
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.def.ServiceDef;
import org.licas.meta.ServiceMeta;
import org.licas.module.*;
import org.licas.query.LinkQueryConfig;
import org.licas.util.*;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;

import java.util.*;


/**
 * This class manages basic creation and parsing for Service objects.
 * @author Kieran Greer
 */
public class ServiceHandler
{
    /** The logger */
    private static final Logger logger;

    /** To synchronize this service internally on */
    protected Object syncOn = new Object();


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServiceHandler.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of ServiceHandler.
     */
    public ServiceHandler()
    {}

    /**
     * Create a full metadata description of this service.
     * The description describes only this service and no nested services.
     * @param jarFile list of remote jar files if loaded remotely.
     * @param theAdminKey the unique service key for admin purposes.
     * @param service the service the operation is for.
     * @return a metadata description of this service.
     * @throws Exception any error.
     */
    public static ServiceMeta createMetaFull(ArrayList<String> jarFile, String theAdminKey, Service service)
            throws Exception
    {
        ServiceMeta serviceMeta;                    //metadata description

        serviceMeta = null;
        try
        {
            if (service.canAccessMeta && (service.getPasswordHandler().isAdminKey(theAdminKey) ||
                    ModuleHandler.isWrapper(service)))
            {
                serviceMeta = service.serviceAdmin.createFullServiceMeta(jarFile, theAdminKey);
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "createMetaFull", null, ex);
        }

        return serviceMeta;
    }

    /**
     * Create a metadata description of this service for the server repository.
     * Note that you can change this method in a derived class, to change the
     * metadata that is stored in the server repository to represent this service.
     * You can also dynamically update the contents. A Service also contains
     * a metadata description in its admin objects, that might be changed separately.
     * The description describes only this service and no nested services.
     * @param theAdminKey the unique service key for admin purposes.
     * @param service the service the operation is for.
     * @return a metadata description of this service.
     * @throws Exception any error.
     */
    public static ServiceMeta createMetaForRepos(String theAdminKey, Service service) throws Exception
    {
        ServiceMeta serviceMeta;                    //metadata description

        serviceMeta = null;
        try
        {
            if (service.canAccessMeta && (service.getPasswordHandler().isAdminKey(theAdminKey) ||
                    ModuleHandler.isWrapper(service)))
            {
                serviceMeta = service.serviceAdmin.createMetaForRepos();
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "createMetaForRepos", null, ex);
        }

        return serviceMeta;
    }

    /**
     * Serialize the service using the {@link ServiceSerialize} class.
     * @param adminKey the service admin key.
     * @param service the service the operation is for.
     * @return an XML representation of all named elements, or null if the admin key is incorrect.
     * @throws Exception any error.
     */
    public static Element serviceToXml(String adminKey, Service service) throws Exception
    {
        Element serviceXml;                         //service as XML
        ServiceSerialize serializer;                //to serialize

        serviceXml = null;
        if (service.getPasswordHandler().isAdminKey(adminKey))
        {
            serializer = new ServiceSerialize();
            serviceXml = serializer.serviceToXml(service);
        }

        return serviceXml;
    }

    /**
     * Serialize the service using the {@link ServiceSerialize} class.
     * @param adminKey the service admin key.
     * @param adminToRemove if any section is indicated here through the XML tag name, it is removed first.
     * @param partsToKeep list of service-local variable names to serialize.
     * @param toSerialize the service that is being serialized.
     * @return an XML representation of all named elements, or null if the admin key is incorrect.
     * @throws Exception any error.
     */
    public static Element serviceToXml(String adminKey, ArrayList<String> adminToRemove,
        ArrayList<String> partsToKeep, Service toSerialize) throws Exception
    {
        Element serviceXml;                         //service as XML
        ServiceSerialize serializer;                //to serialize

        serviceXml = null;
        if (toSerialize.getPasswordHandler().isAdminKey(adminKey))
        {
            serializer = new ServiceSerialize();
            serviceXml = serializer.serviceToXml(toSerialize, adminToRemove, partsToKeep);
        }

        return serviceXml;
    }

    /**
     * Create the service from the description using the {@link ServiceSerialize} class.
     * @param serviceXml a full XML description of the service.
     * @param password parent password, probably the server currently running. Need to
     * use this instead of the stored value if a server.
     * @return the re-created service, probably derived from {@link Service}, but it
     * might be a wrapped object.
     * @throws Exception any error.
     */
    public static Object xmlToService(Element serviceXml, String password) throws Exception
    {
        ServiceSerialize serializer;                //to serialize
        Object thisService;                         //this service

        //create the service from the description
        serializer = new ServiceSerialize();
        thisService = serializer.xmlToService(serviceXml, password);

        //can only add links after all services have been created
        //so a separate call for that is required afterwards
        return thisService;
    }

    /**
     * Serialize the stored passwords list and the service state, and return as an
     * XML-based description. This is used more internally, to save the whole server
     * or SOA to a file. You can also use {@link PasswordHandler}.{code toXml} or
     * {code fromXml} to serialize just the passwords.
     * @param adminKey the service admin key.
     * @param toSerialize the service being serialized.
     * @return an XML representation of all passwords, or null if the admin key is incorrect.
     * @throws Exception any error.
     */
    public static Element passwordsStateToXml(String adminKey, Service toSerialize) throws Exception
    {
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        ServiceInfo nextServiceInfo;                //next service info
        ServiceDef nextService;                     //next service

        rootElem = null;
        if (toSerialize.getPasswordHandler().isAdminKey(adminKey))
        {
            rootElem = XMLFactory.getInstance().createElement(Const.NEXTPASSWORDS);
            rootElem.setAttribute(Const.UUID, toSerialize.getUUID());

            nextElem = XMLFactory.getInstance().createElement(Const.THREADSTATE);
            nextElem.setText(toSerialize.threadAliveState());
            rootElem.addContent(nextElem);

            nextElem = XMLFactory.getInstance().createElement(MetaConst.PASSWORD);
            nextElem.setText(toSerialize.getPasswordHandler().getPassword());
            rootElem.addContent(nextElem);

            nextElem = XMLFactory.getInstance().createElement(Const.SERVICEKEY);
            nextElem.setText(toSerialize.getPasswordHandler().getAdminKey());
            rootElem.addContent(nextElem);

            if ((toSerialize.serviceAdmin.adminInfo.getAdminFilePath() != null) &&
                !toSerialize.serviceAdmin.adminInfo.getAdminFilePath().equals(""))
            {
                nextElem = XMLFactory.getInstance().createElement(Const.FILEURI);
                nextElem.setText(toSerialize.serviceAdmin.adminInfo.getAdminFilePath());
                rootElem.addContent(nextElem);
            }

            for (String nextKey : toSerialize.serviceAdmin.services.keySet())
            {
                nextServiceInfo = toSerialize.serviceAdmin.services.get(nextKey);
                nextService = nextServiceInfo.getService();

                //add nested set of passwords
                if (ModuleHandler.isService(nextService)) {
                    rootElem.addContent(((Service)nextService).passwordsStateToXml(toSerialize.getPasswordHandler().getAdminKey(nextKey)));
                }
            }
        }

        return rootElem;
    }

    /**
     * Perform a query over the link paths to return matching sources. Note that a
     * linking service must be added first.
     * @param queryConfig the query configuration.
     * @param s the service the operation is for.
     * @return a list of source uris that match with the query.
     * @throws Exception any error.
     */
    public static Element dynamicLinkQuery(LinkQueryConfig queryConfig, Service s) throws Exception
    {
        ServiceSerialize serializer;                    //the serializer

        serializer = new ServiceSerialize();
        return serializer.dynamicLinkQuery(s, queryConfig);
    }

    /**
     * Return all linked references in XML format.
     * @param adminKey the service admin key.
     * @param s the service the operation is for.
     * @return an XML representation of all linked source references.
     * @throws Exception any error.
     */
    public static Element linksToXml(String adminKey, Service s) throws Exception
    {
        Element rootElem;                           //root element
        ServiceSerialize serializer;                //the serializer

        rootElem = null;
        serializer = new ServiceSerialize();

        if (s.getPasswordHandler().isAdminKey(adminKey))
        {
            rootElem = serializer.allLinksToXml(s, true, true);
        }

        return rootElem;
    }

    /**
     * Return all permanent linked-t0 services in XML format.
     * @param s the service the operation is for.
     * @return an XML representation of all permanent links.
     * @throws Exception any error.
     */
    public static Element permanentLinksToXml(Service s) throws Exception
    {
        ServiceSerialize serializer;                    //the serializer

        serializer = new ServiceSerialize();
        return serializer.permanentLinksToXml(s.serviceLinks.permanentLinks);
    }

    /**
     * Return all linked sources in XML format. This returns a list of link URIs only.
     * To retrieve all information, try the linking service {@code dynamicLinksToXml(adminKey)}
     * or use {@code LinksParser} locally. Note that a linking service must be added first.
     * @param s the service the operation is for.
     * @return an XML representation of all linked sources.
     * @throws Exception any error.
     */
    public static Element dynamicLinksToXml(Service s) throws Exception
    {
        ServiceSerialize serializer;                    //the serializer

        serializer = new ServiceSerialize();
        return serializer.dynamicLinksToXml(s, false, false);
    }

    /**
     * Return all linked sources in XML format, including all link levels and the
     * source weight values. Note that a linking service must be added first.
     * @param adminKey the service admin key.
     * @param s the service the operation is for.
     * @return an full XML representation of all linked sources, or null if the admin
     * key is incorrect.
     * @throws Exception any error.
     */
    public static Element dynamicLinksToXml(String adminKey, Service s) throws Exception
    {
        ServiceSerialize serializer;                    //the serializer

        if (s.getPasswordHandler().isAdminKey(adminKey))
        {
            serializer = new ServiceSerialize();
            return serializer.dynamicLinksToXml(s, true, true);
        }

        return null;
    }

    /**
     * Parse the links descriptions and add to the service.
     * @param linksXml a full set of links descriptions for the service.
     * @param adminKey the admin key.
     * @param s the service the operation is for.
     * @return true if the links were parsed, false otherwise, for example,
     * incorrect admin key.
     * @throws Exception any error.
     */
    public static boolean xmlToDynamicLinks(Element linksXml, String adminKey, Service s) throws Exception
    {
        ServiceSerialize serializer;                //the serializer

        try
        {
            if (s.getPasswordHandler().isAdminKey(adminKey))
            {
                serializer = new ServiceSerialize();
                serializer.xmlToDynamicLinks(s, linksXml);
                return true;
            }

            return false;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "xmlToDynamicLinks", null, ex);
        }
    }
}
