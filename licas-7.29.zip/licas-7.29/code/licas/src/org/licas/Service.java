/*
 * Service.java
 *
 * Created on 12 June 2007
 *
 * Version 2.49
 *
 * Copyright (c) Kieran Greer
 */

package org.licas;


import org.licas.autonomic.AutonomicManager;
import org.licas.call.*;
import org.licas.call.client.CallHandler;
import org.licas.call.thread.CallExecutor;
import org.licas.def.*;
import org.licas.meta.MetaFactory;
import org.licas.meta.ServiceMeta;
import org.licas.module.*;
import org.licas.module.DataModule;
import org.licas.module.s_module.SM_Auto;
import org.licas.module.s_module.SM_Service;
import org.licas.parsers.DynamicLinkParser;
import org.licas.parsers.Parsers;
import org.licas.parsers.types.ReflectionParser;
import org.licas.query.LinkQueryConfig;
import org.licas.server.*;
import org.licas.server.esb.ServiceRepository;
import org.licas.service.*;
import org.licas.service.link.*;
import org.licas.service.model.Contract;
import org.licas.service.model.WorkInfo;
import org.licas.service.resource.Resource;
import org.licas.service.sci.LinkService;
import org.licas.util.*;
import org.licas.util.exception.*;

import org.licas_xml.abs.*;
import org.licas_xml.model.XmlHandler;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.Monitor;

import java.lang.reflect.*;
import java.util.*;


/**
 * <p>
 * This is the base class that can be used to create a licas service. This class provides the default functionality
 * for storing service details, such as admin and metadata ({@link ServiceAdmin}), or links ({@link ServiceLinks}),
 * and provides the communication framework for invoking service methods. The system is now more modular
 * and services that are stored can be either {@link FrameworkModule} modules or full {@code Service} services.
 * The modules would be for local actions only, inside of this service, and two default ones are the service
 * behaviour {@code sm} and data {@code dm} modules. Any other ones can be stored as child services (@code addService},
 * but would not be accessible externally.
 * </p>
 * <p>
 * This base class also has a built-in security mechanism through using wrappers and passwords, to protect the method invocation.
 * The {@link Auto} class then extends this class with more agent-based or autonomous functionality.
 * </p>
 * <p>
 * When a service is created, it passes some metadata to the {@link ESB} server, to be stored in a {@link ServiceRepository}.
 * This is used for query retrieval where only limited metadata allowing for the service to be found and described is stored.
 * This is returned as a {@link ServiceMeta} object, that has a number of metadata fields, including other external values,
 * notably in the {@link Const}.{@code OTHERMETA}, or {@code DATA} sections. The {@code Data} section
 * is transferred to the {@link DataModule} as a {@link Resource} object that can store static data
 * or reference online data, for example.
 * </p>
 * <p>
 * A service can also be initialised with specific metadata through an <i>admin script</i>. The script can
 * include the metadata fields and also an {@code INSTANCEVALUES} section that can be used to
 * initialise any internal service variable or field. If complex objects are declared, then the {@link Parsers}
 * object needs to have a related parser. There is also {@code PARAMETERS} section in the script that will set 
 * constructor parameters, as part of more advanced and dynamic programming. For this initialisation to work,
 * the service need to include some methods directly in its class code, as described in the documentation.
 * This can mostly be ignored however. See also the code section that needs to be added to use this advanced metadata.
 * </p>
 * <p>
 * Any {@code Service-derived} class that is loaded, is added to the server with a {@link ServiceWrapper} wrapper.
 * If the object is not a licas service ({@code legacy code}) then a {@link ServiceWrapperLegacy} wrapper is
 * used instead. Any service that is added to another service should probably be considered as a utility service
 * to that one and is added with one of these wrappers. A base {@link Auto}-derived service however gets wrapped with
 * an {@link AutonomicManager}, which by default is empty. The service wrapper is still useful however because it can
 * add the licas-framework functionality to a wrapped legacy object and gives some added protection.
 * </p>
 * <p>
 * Three types of link are available: Permanent links are static and made only between services on the same server.
 * Each one can be created through a single call to the {@code createPermanentLinkTo} method. The permanent links are
 * stored as a list of references in the {@link ServiceLinks}.{@code permanentLinks} structure. Dynamic links can
 * then span across servers and are reference-only. They can be created through a novel linking mechanism that can
 * be added to any service, as a module. In particular, there are two implementations called {@link Link} or {@link Link_M}.
 * These would typically be added with the <i>uuid</i> of {@link ServiceConst}.{@code LINKER}. Dynamic links then build
 * up over time through reinforcement, where they can be created and also destroyed. There are also simply service
 * associations, or references to any service from any other service. These are added or removed in one go, can be
 * used for anything and are stored again as a list of references in {@code ServiceLinks}.{@code serviceAssociations}.
 * </p>
 * <p>
 * Any communication IDs saved in the service that are older than 3 days are automatically removed.
 * This is checked in {@code addCommunicationID}.
 * This class also extends {@code Thread}, but that is only used first in the {@code Auto} class.
 * </p>
 * @author Kieran Greer
 */
public abstract class Service extends ServiceModule implements AutoCloseable
{
    /** The logger */
    private static final Logger logger;
    
    
    /**
     * True if allow to return the service metadata, false if force to hide the metadata. 
     * The default value is true.
     */
    protected boolean canAccessMeta;
    
    /**
     * True if allow access to nested services, false otherwise. If true then
     * the nested service's password is still required. If false then the call is
     * blocked regardless of what password is used. Nested services could typically
     * be utility services of this one, when allowing access to them from a client
     * might not be suitable. The default value is true.
     */
    protected boolean canAccessNested;
    
    /**
     * True if services can be added, false if do not allow services to be added.
     */
    private boolean allowAddService;
    
    /** True if {@code finaliseInitialisation} already called, in case construction is different */
    protected boolean finalised;

    /** The service grade, for example {@link ServiceConst}.{code BASE} or {@code UTILITY} */
    protected String serviceGrade;

    /** The current state of the service if known */
    protected String serviceState;

    /** The last script part used to load a service, through the initialisation process */
    protected Element toLoadScript;
    
    /**
     * Module to manage the service behaviour, allows for a more flexible plugin system.
     * Service has the most lightweight set of variables.
     */
    protected SM_Service sm;

    /**
     * Module to manage the service's data object.
     * This is stored as a {@link Resource} to some local or remote data.
     */
    protected DataModule dm;
    
    /** Lookup facility for this service */
    protected ServiceAdmin serviceAdmin;
    
    /** Permanent links between services */
    protected ServiceLinks serviceLinks;
    
    /** To perform some final automatic initialisations */
    protected ServiceInitialiseDef serviceInitialise;
    
    /** 
     * Communication IDs to identify the calling components and replies
     * for stored method results.
     */
    protected MessageStore messageStore;

    /**
     * True if the current call to the object being invoked is remote. By remote
     * it is meant that the call is for a service on a different server. A call to
     * a service on the same server can be made through local references and
     * does not require a RPC mechanism.
     */
    protected boolean isRemoteCall;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(Service.class.getName());
        logger.setDebug(false);
    }
    
    
    /** 
     * Creates a new instance of Service.
     * @throws java.lang.Exception any error.
     */
    public Service() throws Exception
    {
        super();
        initialise(null);
    }
    
    /** 
     * Creates a new instance of Service.
     * @param thisPassword password to invoke this service.
     * @param thisAdminKey admin key for protected access.
     * @throws java.lang.Exception any error.
     */
    public Service(String thisPassword, String thisAdminKey) throws Exception
    {
        super(thisPassword, thisAdminKey);
        initialise(null);
    }
    
    /** 
     * Creates a new instance of Service.
     * @param thisPassword password to invoke this service.
     * @param thisAdminKey admin key for this service.
     * @param adminXml the admin info or description of this service.
     * @throws java.lang.Exception any error.
     */
    public Service(String thisPassword, String thisAdminKey, Element adminXml)
            throws Exception
    {
        super(thisPassword, thisAdminKey);
        initialise(adminXml);
    }

    /** 
     * Initialise some values. This parses the admin script and also sets actual values
     * if that script part is present.
     * @param adminXml the service admin description.
     * @throws java.lang.Exception any error.
     */
    private void initialise(Element adminXml) throws Exception
    {
        finalised = false;
        canAccessMeta = true;
        canAccessNested = true;
        allowAddService = true;
        toLoadScript = null;
        isRemoteCall = false;
        shutDown = false;

        //ready to start the thread
        serviceState = Const.READY;

        //update to utility if added to other service
        serviceGrade = ServiceConst.BASE;

        //add base service module at start so can add admin values to it
        setServiceModule();

        //for security and metadata
        serviceAdmin = new ServiceAdmin(this, passwordHandler.getAdminKey(), adminXml);

        //create the service links with a false path,
        //which is changed after the service is added, as part of 'finaliseInitialisation'
        serviceLinks = new ServiceLinks(uuid, MetaFactory.createMeta(uuid), passwordHandler);

        //finalise the initialisation by adding other variables and services described in the script
        serviceInitialise = new ServiceInitialise(this, serviceAdmin, passwordHandler);
        passwordHandler.setService(this);
        messageStore = new MessageStore();

        //add data module at end after admin data parsed
        setDataModule();
    }

    /**
     * Set the outer-most module that provides the essential service methods.
     * This should extend {@link SM_Service} for Service or {@link SM_Auto} for {@link Auto}.
     * @throws java.lang.Exception any error.
     */
    protected void setServiceModule() throws Exception
    {
        sm = ModuleHandler.serviceModule(this, passwordHandler);
    }

    /**
     * Set the data module to process a {@link Resource}, as described in the admin document.
     * If there is no data processing then set the module to {@code null}.
     * @param adminKey the service admin key.
     * @return true if set, false if not set.
     * @throws java.lang.Exception any error.
     */
    public boolean setDataModule(String adminKey) throws Exception
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            setDataModule();
            return true;
        }

        return false;
    }

    /**
     * Set the data module to process a {@link Resource}, as described in the admin document.
     * If there is no data processing then set the module to {@code null}.
     * @throws java.lang.Exception any error.
     */
    protected void setDataModule() throws Exception
    {
        Element dataXml;            //data element

        dataXml = null;
        if (serviceAdmin.adminInfo != null) {
            dataXml = serviceAdmin.adminInfo.getData();

            if (dataXml != null) {
                if (dataXml.getChild(Const.DATASET) != null) {
                    dataXml = dataXml.getChild(Const.DATASET);
                    dataXml = (Element)dataXml.detach();
                }
            }
        }

        dm = ModuleHandler.dataModule(this, passwordHandler, dataXml);
        if (sm != null) sm.setDataModule(dm);
    }
    
    /**
     * Finalise the initialisation of this service. If an admin document has been
     * passed to the constructor, it might contain information on additional services
     * or operations. As these might involve registering utility or other services, 
     * both with this service or the server, they should be loaded only after this
     * service has been fully registered itself. This method therefore gets called 
     * automatically, but at a different place in the code, at the end of the {@code addService}
     * methods. It uses an implementation of the {@link ServiceInitialise} class to finalise 
     * the initialisation process. To override, reset the {@code serviceInitialise} variable
     * in your derived class (see {@link LinkService}, for example) to your new version 
     * and implement the default method as required.
     * @throws java.lang.Exception any error.
     */
    protected void finaliseInitialisation() throws Exception
    {
        ServiceDef childService;                //child service
        Element servicesXml;                    //services to load xml
    
        try
        {
            if (!finalised) {
                if (serviceAdmin.getAdminInfo() != null) {
                    servicesXml = serviceAdmin.getAdminInfo().getLoadServices();
                    finaliseThisConfig();
                    finaliseInitialisation(servicesXml);
                }
                
                //finalise initialisation for this service
                setInstanceValues(serviceAdmin.getInstanceValues());
                setSerializeValues(serviceAdmin.getAdminInfo().getSerializeValues());
                
                //also finalise initialisation for any child service 
                //that may have been loaded directly
                for (ServiceInfo serviceInfo : serviceAdmin.services.values()) {
                    childService = serviceInfo.getService();

                    if (ModuleHandler.isService(childService)) {
                        ((Service) childService).finaliseInitialisation();
                    }
                }
            }
        }
        finally
        {
            //if service links initialised then update default reference for the service
            if (serviceLinks != null) serviceLinks.serviceRef = this.getFullPath();

            //so only initialise once
            finalised = true;
        }
    }
    
    /**
     * Finalise the initialisation of this service. If an admin document has been
     * passed to the constructor, it might contain information on additional services
     * or operations. As these might involve registering utility or other services, 
     * both with this service or the server, they should be loaded only after this
     * service has been fully registered itself. This method therefore gets called 
     * automatically, but at a different place in the code, at the end of the {@code addService}
     * methods. It uses an implementation of the {@link ServiceInitialise} class to finalise 
     * the initialisation process. To override, reset the {@code serviceInitialise} variable
     * in your derived class (see {@link LinkService}, for example) to your new version 
     * and implement the default method as required.
     * @param servicesXml services to load XML section. This is so that initialisation
     * can be done from somewhere other than the exact registration place, for other
     * loaded objects, for example.
     * @throws java.lang.Exception any error.
     */
    protected void finaliseInitialisation(Element servicesXml) throws Exception
    {
        try
        {
            if (!finalised) {
                if (servicesXml != null) {
                    while (!servicesXml.getChildren().isEmpty()) {
                        toLoadScript = (Element)servicesXml.getChildren().get(0).detach();
                        serviceInitialise.finaliseInitialisation(toLoadScript);
                    }
                }
            }
        }
        finally
        {
            finalised = true;
        }
    }
    
    /**
     * Finalise the configuration of this service, for specific variable values.
     * @throws java.lang.Exception any error.
     */
    protected void finaliseThisConfig() throws Exception
    {
        int i;
        long timeStamp;                             //timestamp
        String commID;                              //comm id
        String nextValue;                           //next value
        HashMap<String, Element> additional;        //additional metadata
        Element varConfigXml;                       //service default config
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Vector<Node> elemList;                      //element list
        MessageInfo messageInfo;                    //message info

        additional = serviceAdmin.getAdminInfo().getAdditional();
        if (serviceAdmin.getAdminInfo() != null) {
            if (additional.containsKey(Const.METAACCESSALLOWED)) {
                varConfigXml = additional.remove(Const.METAACCESSALLOWED);
                nextValue = varConfigXml.getText();
                this.canAccessMeta = Boolean.parseBoolean(nextValue);
            }
            if (additional.containsKey(Const.NESTEDACCESSALLOWED)) {
                varConfigXml = additional.remove(Const.NESTEDACCESSALLOWED);
                nextValue = varConfigXml.getText();
                this.canAccessNested = Boolean.parseBoolean(nextValue);
            }
            if (additional.containsKey(Const.COMMUNICATIONID)) {
                varConfigXml = additional.remove(Const.COMMUNICATIONID);
                nextValue = varConfigXml.getText();
                sm.setCommID(nextValue);
            }
            if (additional.containsKey(Const.COMMUNICATIONIDS)) {
                varConfigXml = additional.remove(Const.COMMUNICATIONIDS);
                elemList = varConfigXml.getChildren();

                for (i = 0; i < elemList.size(); i++) {
                    nextElem = (Element)elemList.get(i);
                    commID = nextElem.getAttributeValue(Const.VALUE);

                    nextElem2 = nextElem.getChild(Const.TIMESTAMP);
                    nextValue = nextElem2.getText();
                    timeStamp = Long.parseLong(nextValue);

                    nextElem2 = nextElem.getChild(Const.CLIENTURI);
                    if (nextElem2.hasChildren()) {
                        messageInfo = new MessageInfo(commID, nextElem2.getElementChildAtIndex(1));
                    }
                    else {
                        messageInfo = new MessageInfo(commID, nextElem2.getText());
                    }

                    messageInfo.setTimeStamp(timeStamp);
                    messageStore.addCommID(commID, messageInfo);
                }
            }
        }
    }

    /**
     * Finalise the module initialisation. The module can probably be created with
     * an empty parameter list.
     * @param module the module to check.
     * @throws java.lang.Exception any error.
     */
    protected void finaliseModule(ServiceDef module) throws Exception
    {
        if (!ModuleHandler.isService(module)) {
            if (ModuleHandler.isFrameworkModule(module)) {
                ((FrameworkModule) module).setServiceDetails(this, this.getPasswordHandler());
            }
        }
    }
    
    /**
     * Set actual values for variable instances if they are defined.
     * <p>
     * {@code NOTE:} you must add this method to your own derived class if you use it,
     * so that the private variables in that class can be accessed.
     * @param instanceValues the admin script part that defines instance values.
     * @throws java.lang.Exception any error.
     */
    protected void setInstanceValues(Element instanceValues) throws Exception
    {
        int i;
        String varName;                             //variable name
        Element instanceValue;                      //instance value
        Element nextElem;                           //next element
        Vector<Node> elemList;                      //list of elements
        Field instField;                            //instance field
        Object valueObj;                            //value object
        
        if (instanceValues != null) {
            elemList = instanceValues.getChildren();
            for (i = 0; i < elemList.size(); i++) {
                instanceValue = (Element)elemList.get(i);  
                varName = instanceValue.getAttributeValue(Const.NAME);               
                nextElem = instanceValue.getElementChildAtIndex(0);
                valueObj = Parsers.parse(nextElem);

                if (valueObj != null) {
                    instField = ReflectionHandler.getInstanceField(this, varName);
                    if (instField != null) {
                        try {
                            instField.set(this, valueObj);
                        }
                        catch (Exception ex) {}
                    }
                }
            }
        }
    }
    
    /**
     * Get the value of the specified variable if it exists.
     * <p>
     * {@code NOTE:} you must add this method to your own derived class if you use it,
     * so that the private variables in that class can be accessed. It is ignored
     * unless it gets called through the script initialisation process.
     * @param varName the name of the variable to check for.
     * @return the variable value, or null if it does not exist.
     * @throws java.lang.Exception any error.
     */
    protected Object getInstanceValue(String varName) throws Exception
    {
        int i;
        Field nextField;                            //next field
        Field[] fields;                             //fields from this class
        Object fieldValue;                          //field value

        fieldValue = null;
        if ((varName != null) && !varName.equals("")) {
            fields = this.getClass().getDeclaredFields();
            for (i = 0; (fieldValue == null) && (i < fields.length); i++) {
                nextField = fields[i];
                if (nextField.getName().equalsIgnoreCase(varName)) {
                    try {
                        fieldValue = fields[i].get(this);
                    }
                    catch (Exception ex) {
                        fieldValue = null;
                    }
                }
            }

            if (fieldValue == null) {
                fields = this.getClass().getFields();
                for (i = 0; (fieldValue == null) && (i < fields.length); i++) {
                    nextField = fields[i];
                    if (nextField.getName().equalsIgnoreCase(varName)) {
                        try {
                            fieldValue = fields[i].get(this);
                        }
                        catch (Exception ex) {
                            fieldValue = null;
                        }
                    }
                }
            }
        }

        return fieldValue;
    }
    
    /**
     * Set actual values for serialized variable instances if they are defined.
     * <p>
     * {@code NOTE:} you must add this method to your own derived class if you
     * use it, so that the private variables in that class can be accessed.
     * @param serializeXml the admin script part that defines serialize instance
     * values.
     * @throws java.lang.Exception any error.
     */
    protected void setSerializeValues(Element serializeXml) throws Exception
    {
        int i;
        String varName;                             //variable name
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Vector<Node> elemList;                      //element list
        Field instField;                            //instance field
        Object valueObj;                            //value object

        if (serializeXml != null) {
            elemList = serializeXml.getChildren();
            for (i = 0; i < elemList.size(); i++) {
                nextElem = (Element) elemList.get(i);
                if (nextElem.getName().equals(Const.SERIALISEVALUE)) {
                    varName = nextElem.getAttributeValue(Const.NAME);
                    if (!varName.equals(MetaConst.ADMIN)) {
                        if (nextElem.hasChildren()) {
                            nextElem2 = nextElem.getElementChildAtIndex(0);
                            valueObj = Parsers.parse(nextElem2);
                            if (valueObj != null) {
                                instField = ReflectionHandler.getInstanceField(this, varName);
                                if (instField != null) {
                                    try {
                                        instField.set(this, valueObj);
                                    } catch (Exception ex)
                                    {}
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    /**
     * This is a method to be invoked by something like a RESTFul or HTTP Server call.
     * It is supposed to copy the HTTP GET protocol method and return the content of
     * this service, as a String. This default version returns an empty String, so
     * you need to override this method in your own classes to return any values.
     * The {@link InformationService}, for example, should have a specific implementation.
     * @return a String-based value representing the content of the service.
     * @throws java.lang.Exception any error.
     */
    public String GET() throws Exception
    {
        return sm.getServiceType();
    }
    
    /**
     * Add metric or stat values for the message object. The metrics are added to the
     * base service only, or the service directly loaded onto the ESB, not any utility
     * service, so this firstly traverses back o the base service before adding any stats.
     * @param messageInfo the message info with the message object.
     * @param thePassword the password for this service.
     * @throws java.lang.Exception any error.
     */
    protected void addMessageMetrics(MethodInfo messageInfo, String thePassword)
            throws Exception
    {
        Service parentService;                      //parent service
        ServiceWrapperDef aWrapper;                 //service wrapper

        if (passwordHandler.isPassword(thePassword)) {
            aWrapper = null;

            //trace back to parent on server and only use base service for metrics
            parentService = this;
            while (true) {
                if (parentService.getParent() != null)
                    parentService = parentService.getParent();
                else
                    break;
            }

            //if not properly registered with a server, then the password can be missing
            //and the server metrics do not need to be used
            if (hasServerPassword()) {
                aWrapper = Objects.requireNonNull(LocalServer.getApi(getServerPassword())).getServiceWrapper(parentService.getUUID(),
                        parentService.passwordHandler.getPassword(), parentService.passwordHandler.getAdminKey());
            }

            if (aWrapper != null) {
                aWrapper.addMetrics(messageInfo, parentService.passwordHandler.getAdminKey());
            }
        }
    }

    /**
     * Return the thread value indicating if the thread is currently running.
     * @return true if thread state is anything but new, false otherwise.
     */
    public boolean isStarted()
    {
        return !(this.getState() == State.NEW);
    }

    /**
     * Return the thread value indicating if the thread can be run.
     * @return true if thread state is new, false otherwise.
     */
    public boolean canRun()
    {
        return (this.getState() == State.NEW);
    }
    
    /**
     * Return true if the password is the correct one to call the method.
     * @param methodName the name of the method.
     * @param thePassword the password used to call the method.
     * @return true if the method can be called using the password.
     * @throws java.lang.Exception any error.
     */
    public boolean isCorrectPassword(String methodName, String thePassword) throws Exception
    {
        return (passwordHandler.canAccess(thePassword, methodName));
    }
    
    /**
     * Return true if the method is a public method that can be freely called,
     * without a password even.
     * @param methodName the name of the method.
     * @return true if the method can be freely called.
     */
    public boolean isPublicMethod(String methodName)
    {
        return (!isPrivateMethod(methodName) &&
                (passwordHandler.isPublicMethod(methodName) ||
                getPublicMethods().contains(methodName)));
    }

    /**
     * Return true if the method is a public-level method that should not be accessed externally.
     * @param methodName the name of the method.
     * @return true if the method should not be called.
     */
    protected boolean isPrivateMethod(String methodName)
    {
        return (getPrivateMethods().contains(methodName));
    }
    
    /**
     * Return true if a service with the specified id is running on this one.
     * @param serviceID the service uuid to check for.
     * @return true if a service with that ID is running, false otherwise.
     */
    public boolean hasService(String serviceID)
    {
        return serviceAdmin.getServiceNames().contains(serviceID);
    }
    
    /**
     * Return true if a service with the specified type is running on this one.
     * @param serviceType the service type to check for.
     * @return true if a service of that type is running, false otherwise.
     */
    public boolean hasServiceType(String serviceType)
    {
        return serviceAdmin.getServiceTypes().contains(serviceType);
    }
    
    /**
     * Return true if this service currently stores a conversation with the specified communication ID.
     * @param commID the communication ID to check for.
     * @return true if the communication ID, false otherwise.
     */
    public boolean hasCommunicationID(String commID)
    {
        return messageStore.hasCommID(commID);
    }

    /**
     * Get this service's service admin, including its metadata info.
     * @param adminKey the admin key for this service.
     * @return the value of serviceAdmin.
     */
    public ServiceAdmin getServiceAdmin(String adminKey)
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            return serviceAdmin;
        }
        
        return null;
    }

    /**
     * Get this service's linking structure.
     * @param adminKey the admin key for this service.
     * @return the value of serviceLinks.
     */
    public ServiceLinks getServiceLinks(String adminKey)
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            return serviceLinks;
        }

        return null;
    }

    /**
     * If the service has an admin document, check it for an autonomic manager section.
     * @param theAdminKey the service key for this service.
     * @return the auto man config document if it exists, null otherwise.
     */
    public Element getAutonomicManagerConfig(String theAdminKey)
    {
        Element autoManXml;                             //auto man config

        autoManXml = null;
        if (passwordHandler.getAdminKey().equals(theAdminKey)) {
            if (serviceAdmin.adminInfo != null) {
                autoManXml = serviceAdmin.adminInfo.getAutonomicManagerAdmin();
            }
        }

        return autoManXml;
    }

    /**
     * Start this service's thread running.
     * @param adminKey the admin key for this service.
     * @return true if started, false otherwise.
     */
    public boolean startThread(String adminKey)
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            start();
            return true;
        }

        return false;
    }
    
    /**
     * Start the threads for all child services of the specified component type.
     * If {@link Const}.{@code ALLSERVICES}, then any child service can be started.
     * @param serviceType the service type. Can be general or a specific uuid.
     * @param adminKey the service key for this service.
     * @return true if all services could be accessed or false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean startAllThreads(String serviceType, String adminKey) throws Exception
    {
        ServiceInfo nextServiceInfo;            //next service info
        FrameworkModule nextService;              //next service

        try {
            if (adminKey.equals(passwordHandler.getAdminKey())) {
                for (String key : serviceAdmin.services.keySet())
                {
                    nextServiceInfo = serviceAdmin.services.get(key);
                    nextService = getServiceOrWrapper(key, passwordHandler.getServicePassword(key),
                            passwordHandler.getAdminKey(key));

                    if (ModuleHandler.isService(nextService)) {
                        //start child services if required
                        ((Service)nextService).startAllThreads(serviceType, passwordHandler.getAdminKey(key));
                    }
                    
                    //start this thread if required
                    if (serviceType.equals(Const.ALLSERVICES)) {
                        Monitor.restartThread(nextService, true);
                    }
                    else if (nextServiceInfo.getServiceType().equals(serviceType)) {
                        Monitor.restartThread(nextService, true);
                    }
                    else if (nextServiceInfo.getName().equals(serviceType)) {
                        Monitor.restartThread(nextService, true);
                    }
                }

                return true;
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "startAllThreads", null, ex);
        }
        
        return false;
    }
    
    /**
     * Stop the threads for all child services of the specified component type.
     * If {@link Const}.{@code ALLSERVICES}, then any child service can be stopped.
     * @param serviceType the service type. Can be general or a specific uuid.
     * @param adminKey the service key for this service.
     * @return true if all services could be accessed or false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean stopAllThreads(String serviceType, String adminKey) throws Exception
    {
        ServiceInfo nextServiceInfo;            //next service info
        FrameworkModule nextService;              //next service

        if (adminKey.equals(passwordHandler.getAdminKey())) {
            for (String key : serviceAdmin.services.keySet())
            {
                nextServiceInfo = serviceAdmin.services.get(key);
                nextService = getServiceOrWrapper(key, passwordHandler.getServicePassword(key),
                        passwordHandler.getAdminKey(key));

                try {
                    //set shutdown if required
                    if (serviceType.equals(Const.ALLSERVICES) ||
                            nextServiceInfo.getServiceType().equals(serviceType) ||
                            nextServiceInfo.getName().equals(serviceType)) {
                        ModuleComm.shutDown(nextService);
                    }
                }
                catch (Exception ex) {
                    ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                            "stopAllThreads", null, ex);
                }

                try {
                    //stop child services if required
                    if (ModuleHandler.isService(nextService)) {
                        ((Service)nextService).stopAllThreads(serviceType, passwordHandler.getAdminKey(key));
                    }
                }
                catch (Exception ex) {
                    ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                            "stopAllThreads", null, ex);
                }
            }

            return true;
        }
        
        return false;
    }

    /**
     * Return the value indicating if a service can be added to this one.
     * @return the value of allowAddService.
     */
    public boolean getAllowAddService()
    {
        return allowAddService;
    }
    
    /**
     * Set the {@code allowAddService} variable to allow services to be added.
     * @param adminKey the admin key for this service.
     * @param allow true if reset to allow adding of services, false to reset
     * to block of adding services.
     * @return true if the variable is set (adminKey OK), false otherwise.
     */
    public boolean allowAddService(String adminKey, boolean allow)
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            allowAddService = allow;
            return true;
        }
        
        return false;
    }
    
    /**
     * Set the variable indicating if the service metadata can be accessed.
     * @param thisCanAccessMeta true if can access metadata, false if cannot.
     * @param adminKey the service key for this service.
     * @throws java.lang.Exception any error.
     */
    public void setCanAccessMeta(boolean thisCanAccessMeta, String adminKey) throws Exception
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            canAccessMeta = thisCanAccessMeta;
            if ((serviceAdmin != null) && (LocalServer.getServerURL() != null)) {
                if (canAccessMeta)
                    Objects.requireNonNull(LocalServer.getApi(getServerPassword())).addServiceMeta(passwordHandler.getPassword(),
                        passwordHandler.getAdminKey(), createMetaForRepos(passwordHandler.getAdminKey()));
                else
                    Objects.requireNonNull(LocalServer.getApi(getServerPassword())).removeServiceMeta(passwordHandler.getPassword(),
                        passwordHandler.getAdminKey());
            }
        }
            
    }

    /**
     * Return true if the service allows you to access its metadata, or false if
     * access is not allowed.
     * @return the value of canAccessMeta.
     */
    public boolean canAccessMeta()
    {
        return canAccessMeta;
    }
    
    /**
     * Set the variable indicating if nested child services can be directly accessed.
     * If set to false, the services are not accessible, even if the password is known.
     * @param thisCanAccessNested true if can access nested services, false if cannot.
     * @param adminKey the service key for this service.
     * @throws java.lang.Exception any error.
     */
    public void setCanAccessNested(boolean thisCanAccessNested, String adminKey) throws Exception
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            canAccessNested = thisCanAccessNested;
            if ((serviceAdmin != null) && (LocalServer.getServerURL() != null)) {
                Objects.requireNonNull(LocalServer.getApi(getServerPassword())).addServiceMeta(passwordHandler.getPassword(),
                    passwordHandler.getAdminKey(), createMetaForRepos(passwordHandler.getAdminKey()));
            }
        }
    }

    /**
     * Return true if the service allows you to access any of its nested services.
     * @return true if the nested services can be called directly, or false if
     * access is not allowed.
     */
    public boolean canAccessNested()
    {
        return canAccessNested;
    }
    
    /**
     * Get the password for this service.
     * @param theAdminKey the service key.
     * @return the access password for this service.
     */
    public String getPassword(String theAdminKey)
    {
        return passwordHandler.getPassword(theAdminKey);
    }
    
    /**
     * Get the password for the specified service.
     * @param serviceUuid the id of the service to ask the password for.
     * @param theAdminKey the service key.
     * @return the password for the specified service or null if it cannot be retrieved.
     * @throws java.lang.Exception any error.
     */
    public String getPassword(String serviceUuid, String theAdminKey) throws Exception
    {
        return passwordHandler.getPassword(serviceUuid, theAdminKey);
    }
    
    /**
     * Get this service's password, depending on the calling component's contract description.
     * By default, a service is assigned a 'yes' contract, meaning that it is open and
     * will always return its password to allow for method invocation. The other default
     * option is a 'no' contract, meaning that there is no negotiation and the password
     * must be known. This can also be changed by adding a different 'sla' contract for
     * each service level in the service. You can therefore override this method 
     * to provide your own checks, using this as a guide.
     * @param clientID the clientID of the calling component.
     * @param clientContract the description of the calling component's contract proposal.
     * Note that the default {@link Contract}.{@code getYesContract()} can often be used.
     * @return the value of the password for the specified service level if the contract 
     * is accepted, or null if it is not accepted. The default 'yes' contract always
     * returns the password.
     * @throws java.lang.Exception any error.
     */
    public String getPassword(String clientID, Contract clientContract) throws Exception
    {
        String servicePassword;                          //the service password
        String serviceLevel;                             //service level
        
        servicePassword = null;
        if(serviceAdmin.contractManager.contractIsOK(clientContract)) {
            serviceLevel = Contract.getElementValue(MetaConst.SERVICELEVEL, clientContract);
            servicePassword = passwordHandler.getLevelPassword(serviceLevel);
        }

        return servicePassword;
    }

    /**
     * Set the password that will allow this service to access the server it runs on.
     * @param thePassword the server password.
     * @throws java.lang.Exception any error.
     */
    protected void setServerPassword(String thePassword) throws Exception
    {
        passwordHandler.addServicePassword(Handle.getLocalServerURI(), thePassword);
    }
    
    /**
     * Return true if the local server password is stored. This would imply a running
     * server and the service has been registered with it.
     * @return true if the local server password is saved, false otherwise.
     * @throws java.lang.Exception any error.
     */
    protected boolean hasServerPassword() throws Exception
    {
        return ((Handle.getLocalServerURI() != null) &&
            passwordHandler.hasServicePassword(Handle.getLocalServerURI()));
    }
    
    /**
     * Get the local server password if it is stored.
     * @return the local server password.
     * @throws java.lang.Exception any error.
     */
    protected String getServerPassword() throws Exception
    {
        return super.getServerPassword();
    }

    /**
     * Return true if the password allows the calling component to access this component.
     * @param thePassword the password to use.
     * @param methodName the method name that needs to be called.
     * @return true if the entered password is the correct password or
     * there is no password.
     * @throws java.lang.Exception any error.
     */
    public boolean canAccess(String thePassword, String methodName) throws Exception
    {
        return canAccess(thePassword, methodName, null);
    }
    
    /**
     * Return true if the password allows the calling component to access this component.
     * @param thePassword the password to use.
     * @param theMethod the method that needs to be called.
     * @return true if the entered password is the correct password or
     * there is no password.
     * @throws java.lang.Exception any error.
     */
    public boolean canAccess(String thePassword, Method theMethod) throws Exception
    {
        if (theMethod != null) {
            return canAccess(thePassword, theMethod.getName(), theMethod);
        }
        
        return false;
    }

    /**
     * Return true if the password allows the calling component to access this component.
     * @param thePassword the password to use.
     * @param theMethods a list of possible legal methods to call.
     * @return true if the entered password is the correct password or
     * there is no password.
     * @throws java.lang.Exception any error.
     */
    public boolean canAccess(String thePassword, ArrayList<Method> theMethods) throws Exception
    {
        int i;
        boolean canAccessMethod;                //true if can access the method
        Method nextMethod;                      //the next method to try

        canAccessMethod = false;
        for (i = 0; !canAccessMethod && (i < theMethods.size()); i++)
        {
            nextMethod = theMethods.get(i);
            canAccessMethod = canAccess(thePassword, nextMethod.getName(), nextMethod);
        }

        return canAccessMethod;
    }
    
    /**
     * Return true if the password allows the calling component to access this component.
     * The {@code execute} method is always allowed because it will invoke another method.
     * @param thePassword the password to use.
     * @param methodName the method name that needs to be called.
     * @param theMethod the method that needs to be called.
     * @return true if the entered password is the correct password or
     * there is no password.
     * @throws java.lang.Exception any error.
     */
    protected boolean canAccess(String thePassword, String methodName, Method theMethod) throws Exception
    {
        boolean access;                         //true if can access
        
        access = false;
        if (methodName != null) {
            access = (isPublicMethod(methodName) || Handle.isExecuteMethod(methodName));
        } 
        
        //if not global method, can check admin settings, full description more accurate
        if (!access) {
            if (theMethod != null) {
                access = passwordHandler.canAccess(thePassword, theMethod.getName(), 
                    ReflectionParser.methodToXML(theMethod));
            }
            else if (methodName != null) {
                access = passwordHandler.canAccess(thePassword, methodName);
            }
        }
        
        return access;
    }

    /**
     * Return true if the password allows the calling component
     * to access this component by a temporary password.
     * @param thePassword the password to use.
     * @return true if the entered password is the valid.
     */
    public boolean canAccessTemp(String thePassword)
    {
        boolean access = false;                     //true if can access

        if (thePassword != null) {
            access = super.canAccessTemp(thePassword);
            if (!access && (service != null)) {
                access = service.canAccessTemp(thePassword);
            }
        }

        passwordHandler.getTempPasswords().remove(thePassword);

        return access;
    }

    /**
     * Allow a client to negotiate with this service about a contract agreement.
     * @param id the id of the calling component.
     * @param clientContract the description of the calling component's contract proposal.
     * @return the reply to the proposed contract. If this is OK, it then needs to 
     * be sent to the {@code getPassword} method as the agreed contract, to retrieve
     * the service password.
     * @throws java.lang.Exception any error.
     */
    public Contract serviceNegotiate(String id, Contract clientContract) throws Exception
    {
        Contract contractReply;                          //reply to the current contract

        contractReply = serviceAdmin.contractManager.processClientContract(id, clientContract);
        return contractReply;
    }
    
    /**
     * Add a new service password to this service.
     * @param serviceUuid the full uuid description of the service the password is for.
     * @param servicePassword the service password.
     * @param adminKey the admin key for this service.
     */
    public void addServicePassword(String serviceUuid, String servicePassword, String adminKey)
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            passwordHandler.addServicePassword(serviceUuid, servicePassword);
        }
    }

    /**
     * Add a new temporary password to the temp passwords list.
     * @param addPassword true if add a password.
     * @return the newly created password or null if do not add.
     * @throws java.lang.Exception any error.
     */
    protected String addTempPassword(boolean addPassword) throws Exception
    {
        String tempPassword;                //the temporary password

        tempPassword = null;
        if (addPassword) {
            tempPassword = PasswordHandler.getNewPassword();
            passwordHandler.getTempPasswords().add(tempPassword);
        }

        return tempPassword;
    }

    /**
     * Remove the temporary password from the list if it exists.
     * @param tempPassword the temporary password.
     */
    protected void removeTempPassword(String tempPassword) {
        if (tempPassword != null) {
            passwordHandler.getTempPasswords().remove(tempPassword);
        }
    }

    /**
     * Get the fully qualified uuid path back to the first parent object and server.
     * @return the fully qualified path to access this component on the server.
     * @throws java.lang.Exception any error.
     */
    public Element getFullPath() throws Exception
    {
        int i;
        String fullUUID;                    //uuid
        Element handle;                     //full path specification
        Service nextParent;                 //next parent service
        ArrayList<String> allUUIDs;         //list of all uuids

        allUUIDs = new ArrayList<>();
        fullUUID = getUUID();
        allUUIDs.add(0, fullUUID);

        nextParent = service;
        while (nextParent != null)
        {
            if (!(nextParent instanceof ESB)) {
                fullUUID = nextParent.getUUID();
                allUUIDs.add(0, fullUUID);

                nextParent = nextParent.getParent();
            }
            else {
                nextParent = null;
            }
        }

        handle = Handle.createNewUrlHandle(LocalServer.getServerURL());

        for (i = 0; i < allUUIDs.size(); i++)
        {
            fullUUID = allUUIDs.get(i);
            handle = Handle.addToHandle(handle, Handle.asHandleElement(fullUUID));
        }

        return handle;
    }
    
    /**
     * Add a default service to this service. The new service must be one of the known 
     * default services. This method will then automatically create a new instance of the 
     * correct class type and add it with the same password and admin key as this service,
     * and with a uuid name equal to the service type. 
     * The new service will therefore not have unique passwords and so will have less security.
     * Setting {@code canAccessNested} to false however, can block access from an external 
     * service to any nested service no matter what password is used.
     * @param serviceType the type of service to create. This is also used as the service uuid.
     * @param adminKey the admin key for this service.
     * @return true if the service as added, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public final boolean addDefaultService(String serviceType, String adminKey) throws Exception
    {
        if (allowAddService) {
            return addDefaultService(serviceType, serviceType, adminKey);
        }
        
        return false;
    }
    
    /**
     * Add a default service to this service. The new service must be one of the known 
     * default services. This method will then automatically create a new instance of the 
     * correct class type and add it with the same password and admin key as this service,
     * but also with a unique uuid. 
     * The new service will therefore not have unique passwords and so will have less security.
     * Setting {@code canAccessNested} to false however, can block access from an external 
     * service to any nested service no matter what password is used.
     * @param serviceUuid the uuid for the new default service to add. This is not
     * used for a linking service, which is assigned the 'LINKER' uuid name.
     * @param serviceType the type of service to create.
     * @param adminKey the admin key for this service.
     * @return true if the service as added, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public final boolean addDefaultService(String serviceUuid, String serviceType,
            String adminKey) throws Exception
    {
        if (allowAddService) {
            return addDefaultService(serviceUuid, serviceType, null, adminKey);
        }
        
        return false;
    }
    
    /**
     * Add a default service to this service. The new service must be one of the known 
     * default services. This method will then automatically create a new instance of the 
     * correct class type and add it, but with the password and admin key specified in the
     * constructor params list. The new service will therefore have unique passwords as well.
     * @param serviceUuid the uuid for the new default service to add. This is not
     * used for a linking service, which is assigned the {@link ServiceConst}.{@code LINKER} uuid name.
     * @param serviceType the type of service to create.
     * @param params list of constructor parameters - should be password and admin key.
     * @param adminKey the admin key for this service.
     * @return true if the service as added, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public final boolean addDefaultService(String serviceUuid, String serviceType,
            ArrayList<?> params, String adminKey) throws Exception
    {
        if (allowAddService) {
            return addDefaultService(serviceUuid, serviceType, params, null, adminKey);
        }
        
        return false;
    }
    
    /**
     * Add a default service to this service. The new service must be one of the known 
     * default services. This method will then automatically create a new instance of the 
     * correct class type and add it, but with the password and admin key specified in the
     * constructor params list. The new service will therefore have unique passwords as well.
     * Setting {@code canAccessNested} to false however, can block access from an external 
     * service to any nested service no matter what password is used.
     * @param serviceUuid the uuid for the new default service to add. This is not
     * used for a linking service, which is assigned the {@link ServiceConst}.{@code LINKER} uuid name.
     * @param serviceType the type of service to create.
     * @param params list of constructor parameters - should be password and admin key.
     * @param adminXml the admin info or description of the new service.
     * @param adminKey the admin key for this service.
     * @return true if the service as added, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public final boolean addDefaultService(String serviceUuid, String serviceType, ArrayList<?> params,
            Element adminXml, String adminKey) throws Exception
    {
        PasswordHandler ph;                         //password handler
        ServiceDef newService;                      //new service

        ph = this.getPasswordHandler();

        if (allowAddService && adminKey.equals(ph.getAdminKey())) {
            if (!this.getServiceNames().contains(serviceUuid)) {
                if (serviceType.equals(ServiceConst.LINKER)) serviceUuid = serviceType;
                if (params != null) {
                    ph.addServicePassword(serviceUuid, (String)params.get(0));
                    ph.addAdminKey(serviceUuid, (String)params.get(1));
                }
                else {
                    ph.addServicePassword(serviceUuid, ph.getPassword());
                    ph.addAdminKey(serviceUuid, ph.getAdminKey());
                }

                newService = ServiceFactory.getInstance().createDefaultService(serviceUuid,
                        serviceType, adminXml, ph);

                if (newService != null) {
                    //if a module not a service, then need to complete the initialisation
                    if (!ModuleHandler.isService(newService)) finaliseModule(newService);

                    //can add and retrieve the module as a service
                    this.addService(ph.getPassword(), serviceUuid, serviceType, newService);
                    return true;
                }
                else {
                    if (ph.hasServicePassword(serviceUuid))
                        ph.removeServicePassword(serviceUuid);

                    if (ph.hasAdminKey(serviceUuid))
                        ph.removeAdminKey(serviceUuid);
                }
            }
        }

        return false;
    }
    
    /**
     * Load the service class and add as a service, but do not start its thread.
     * @param thePassword the password to protect access to this component.
     * @param serviceName the name of the service.
     * @param serviceType the type of the service.
     * @param jarFile the jar files for a remote loading. Values are jar paths
     * of type String.
     * @param className the name of the service class.
     * @param params a list of initialisation parameters.
     * @return true if the service has been added, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public final boolean addService(String thePassword, String serviceName, String serviceType,
        ArrayList<String> jarFile, String className, ArrayList<Object> params) throws Exception
    {
        if (allowAddService) {
            return addService(thePassword, serviceName, serviceType, jarFile,
                className, false, params);
        }
        
        return false;
    }
    
    /**
     * Load the service class and add as a service. Start the thread if indicated.
     * @param thePassword the password to protect access to this component.
     * @param serviceName the name of the service.
     * @param serviceType the type of the service.
     * @param jarFile the jar files for a remote loading. Values are jar paths
     * of type String.
     * @param className the name of the service class.
     * @param startService true if start the service thread or false if do not.
     * @param params a list of initialisation parameters.
     * @return true if the service has been added, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public final boolean addService(String thePassword, String serviceName, String serviceType, ArrayList<String> jarFile,
                                    String className, boolean startService, ArrayList<Object> params) throws Exception
    {
        Object nextObj;                         //next object
        
        if (allowAddService && canAccess(thePassword) && !serviceAdmin.services.containsKey(serviceName)) {
            if (classNameOK(className)) {
                nextObj = sm.loadObject(jarFile, className, params);
                return addService(thePassword, serviceName, serviceType, jarFile,
                        nextObj, startService);
            }
        }
        
        return false;
    }
    
    /**
     * Add the service Object to this one. It can then be accessed directly if it extends the
     * {@code Service} class. If it is a different object, then it can be accessed through the
     * wrapper using Java Reflection. Do not start its thread.
     * @param thePassword the password to protect access to this component.
     * @param serviceName the name of the service.
     * @param serviceType the type of the service.
     * @param theService the service to add.
     * @return true if the service has been added, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public final boolean addService(String thePassword, String serviceName, String serviceType,
        Object theService) throws Exception
    {
        if (allowAddService) {
            return addService(thePassword, serviceName, serviceType, jarFile,
                theService, false);
        }
        
        return false;
    }
    
    /**
     * Add the service Object to this one. It can then be accessed directly if it extends the
     * {@code Service} class. If it is a different object, then it can be accessed through the
     * wrapper using Java Reflection. Do not start its thread.
     * Also, if it is a {@code Service}, then after it is added and initialised, its {@code finaliseInitialisation}
     * method gets called from this method.
     * Note services cannot be added to the {@link HttpServer}, apart from the {@link ESB}
     * service that is added only once and with the name of {@link Const}.{@code HTTPSERVER}.
     * @param thePassword the password to protect access to this component.
     * @param serviceName the name of the service.
     * @param serviceType the type of the service.
     * @param jarFile the jar files for a remote loading. Values are jar paths
     * of type String.
     * @param theService the service to add.
     * @param startService true if start the service thread or false if do not.
     * @return true if the service has been added, false otherwise.
     * @throws ServiceException if the service should not be added.
     * @throws java.lang.Exception any other error.
     */
    public final boolean addService(String thePassword, String serviceName, String serviceType,
                                    ArrayList<String> jarFile, Object theService, boolean startService) throws ServiceException, Exception
    {
        boolean canAdd;                             //true if can add as utility service
        String password;                            //service password
        String adminKey;                            //service admin key
        Element description;                        //service description
        Element servicePath;                        //path description
        ArrayList<String> theseServices;            //other services of this type
        Element serviceUri;                         //service uri
        PasswordHandler ph;                         //password handler
        WorkInfo workInfo;                          //work protocol details
        ServiceWrapperDef aWrapper;                 //service wrapper
        ServiceInfo serviceInfo;                    //service info
        ServiceMeta serviceMeta;                    //service metadata

        try {
            //shorten the name
            ph = this.getPasswordHandler();

            //can add if extends ServiceModule, Service, or is legacy object
            canAdd = ModuleHandler.isServiceModule(theService);
            if (!canAdd) {
                canAdd = !ModuleHandler.isLicasModule(theService);
            }
            if (canAdd) {
                canAdd = (LocalServer.getApi(getServerPassword()) != null);
            }

            if (canAdd) {
                if (allowAddService && this.classNameOK(theService.getClass().getName()) &&
                        this.canAccess(thePassword) && !this.serviceAdmin.services.containsKey(serviceName)) {
                    // 1. If added to the ESB, then a base service is wrapped with an autonomic manager
                    // if the service is Auto-derived and simply a wrapper otherwise.
                    // 2. If not added to the ESB, then gets wrapped with a Service wrapper.
                    if (ModuleHandler.isServer(this)) {
                        //autonomic manager if Auto-derived, wrapper otherwise
                        if (ModuleHandler.isAuto(theService)) {
                            //autonomic manager version
                            aWrapper = this.createServiceWrapper(theService, serviceName, serviceType, jarFile,
                                    ((Service) theService).getAutonomicManagerConfig(((Service) theService).getPasswordHandler().getAdminKey()));
                        } else {
                            //service wrapper
                            aWrapper = this.createServiceWrapper(theService, serviceName,
                                    serviceType, jarFile, null);
                        }
                    } else {
                        //service wrapper   //are not wrapped, but if legacy code then again better to wrap
                        aWrapper = this.createServiceWrapper(theService, serviceName,
                                serviceType, jarFile, null);
                    }

                    //need to set parent if this is a child service
                    //but if base service, then do not set ESB as parent
                    if (ModuleHandler.isServer(this)) {
                        ServiceComm.setParent(null, aWrapper);
                    } else {
                        ServiceComm.setParent(this, aWrapper);
                    }

                    //add passwords and other meta
                    serviceName = aWrapper.getUUID();
                    serviceType = aWrapper.getServiceType();
                    password = ModuleComm.getPassword((FrameworkModule) aWrapper);
                    adminKey = ModuleComm.getAdminKey((FrameworkModule) aWrapper);
                    description = aWrapper.getDescription();
                    servicePath = aWrapper.getFullPath();
                    workInfo = aWrapper.getWorkInfo();

                    //if this is not the base server, then set as utility service
                    if (!ModuleHandler.isServer(this)) {
                        ServiceComm.setServiceGrade(ServiceConst.UTILITY, aWrapper);
                    }

                    //add passwords using full URI handles
                    serviceUri = Handle.createServiceHandle(serviceName);
                    ph.addServicePassword(serviceUri, password);
                    ph.addAdminKey(serviceUri, adminKey);

                    if (this.serviceAdmin.serviceTypes.containsKey(serviceType)) {
                        theseServices = this.serviceAdmin.serviceTypes.get(serviceType);
                    } else {
                        theseServices = new ArrayList<>();
                        this.serviceAdmin.serviceTypes.put(serviceType, theseServices);
                    }

                    //store in appropriate lists
                    if (!theseServices.contains(serviceName)) {
                        theseServices.add(serviceName);
                    }

                    serviceInfo = new ServiceInfo(serviceName, serviceType, description, workInfo, aWrapper);
                    if (servicePath != null) serviceInfo.setServicePath(servicePath);
                    this.serviceAdmin.services.put(serviceName, serviceInfo);
                    this.serviceLinks.addChildService(serviceName);

                    //if running on the server, this service should always have the server password
                    //and setup can be completed, if not running on the server, it may be missing
                    if (this.hasServerPassword()) {
                        ServiceComm.setServerPassword(this.getServerPassword(), aWrapper);

                        //finalise the initialisation of the service Object,
                        if (ModuleHandler.isService(theService)) {
                            //include loading in child services
                            ((Service) theService).finaliseInitialisation();
                        } else if (ModuleHandler.isFrameworkModule(theService)) {
                            //if a module not a service, then need to complete the initialisation
                            finaliseModule((FrameworkModule) theService);
                        }

                        //register the new service's metadata with the server
                        if (ModuleHandler.isService(theService)) {
                            serviceMeta = ((Service) theService).createMetaForRepos(adminKey);
                        } else if (ModuleHandler.isService(aWrapper)) {
                            serviceMeta = ((Service) aWrapper).createMetaForRepos(adminKey);
                        } else {
                            serviceMeta = null;
                        }

                        //can be null if force to hide the metadata - service.canAccessMeta
                        if (serviceMeta != null) {
                            serviceMeta.uuid = serviceName;
                            serviceMeta.serviceType = serviceType;
                            serviceMeta.serviceClass = theService.getClass().getName();
                            serviceMeta.serviceGrade = aWrapper.getServiceGrade();
                            serviceMeta.serviceUri = aWrapper.getFullPath();

                            Objects.requireNonNull(LocalServer.getApi(getServerPassword())).addServiceMeta(password,
                                    adminKey, serviceMeta);
                        }
                    }

                    //start the thread if requested
                    if (ModuleHandler.isService(theService)) {
                        if (startService && !((Service) theService).isAlive()) {
                            ((Service) theService).start();
                        }
                    }

                    return true;
                }

                return false;
            }
            else {
                throw new ServiceException("A utility service should derive from 'Service', 'ServiceModule', " +
                        "or be a legacy object. For identification, it is better not to extend 'FrameworkModule' only. " +
                        "This class is " + theService.getClass().getName() + ".");
            }
        }
        finally {
            toLoadScript = null;
        }
    }

    /**
     * Create a service wrapper for storing the service object. This version returns a
     * {@link ServiceWrapper} if the object is a licas {@link Service}, or a {@link ServiceWrapperLegacy}
     * if the object is not a licas service. An autonomic manager is not added here, only
     * at the ESB level.
     * @param serviceObj the service object that is wrapped and managed.
     * @param serviceName the name of the service.
     * @param serviceType the type of the service.
     * @param jarFiles the jar files for a remote loading. Values are jar paths
     * of type String.
     * @param adminXml the admin document describing the service wrapper.
     * @return the correct service wrapper type.
     * @throws Exception any error.
     */
    protected ServiceWrapperDef createServiceWrapper(Object serviceObj, String serviceName,
        String serviceType, ArrayList<String> jarFiles, Element adminXml) throws Exception
    {
        ServiceWrapperDef aWrapper;                         //service wrapper

        if (ModuleHandler.isService(serviceObj)) {
            aWrapper = new ServiceWrapper((Service)serviceObj);
        }
        else {
            aWrapper = new ServiceWrapperLegacy(serviceObj);
        }

        aWrapper.setJarFile(jarFile);
        if (serviceName != null) aWrapper.setUUID(serviceName);
        if (serviceType == null) {
            serviceType = Const.SERVICE;
        }

        aWrapper.setServiceType(serviceType);
        aWrapper.copyToService(this);

        return aWrapper;
    }

    /**
     * Check that the class name path is not illegal.
     * @param className full class name of service to load.
     * @return true if safe path. Defaults to true here.
     */
    protected boolean classNameOK(String className)
    {
        return true;
    }
    
    /**
     * Create a full metadata description of this service.
     * The description describes only this service and no nested services.
     * @param jarFile list of remote jar files if loaded remotely.
     * @param theAdminKey the unique service key for admin purposes.
     * @return a metadata description of this service.
     * @throws java.lang.Exception any error.
     */
    public ServiceMeta createMetaFull(ArrayList<String> jarFile, String theAdminKey)
            throws Exception
    {
        return ServiceHandler.createMetaFull(jarFile, theAdminKey, this);
    }
    
    /**
     * Create a metadata description of this service for the server repository. 
     * Note that you can change this method in a derived class, to change the 
     * metadata that is stored in the server repository to represent this service.
     * You can also dynamically update the contents. A Service also contains
     * a metadata description in its admin objects, that might be changed separately.
     * The description describes only this service and no nested services.
     * @param theAdminKey the unique service key for admin purposes.
     * @return a metadata description of this service.
     * @throws java.lang.Exception any error.
     */
    public ServiceMeta createMetaForRepos(String theAdminKey) throws Exception
    {
        return ServiceHandler.createMetaForRepos(theAdminKey, this);
    }

    /**
     * Return the service or module for the related service name. This method returns
     * a wrapper for the service with limited functionality. It should be used only to
     * allow access to nested services on the called service or for invoking methods.
     * @param serviceName the name of the service you want to retrieve.
     * @param thePassword the password for the service you want to retrieve.
     * @return a wrapper containing the service that is retrieved.
     * @throws org.licas.util.exception.ServiceException for service specific error.
     * @throws java.lang.Exception any other error.
     */
    public ServiceWrapperDef getService(String serviceName, String thePassword)
        throws ServiceException, Exception
    {
        return serviceAdmin.getService(serviceName, thePassword);
    }
    
    /**
     * Return the service, module or its wrapper for the related service name. This method
     * requires the admin key as well, so that it can try to return a direct reference to the
     * service object. If the service object is not derived from {@code Service}, then the
     * wrapper is returned. If it is derived from Service, then a direct reference is returned.
     * @param serviceName the name of the service you want to retrieve.
     * @param thePassword the password for the service you want to retrieve.
     * @param adminKey the admin key for the service you want to retrieve.
     * @return the service object if it exists or null if it does not.
     * @throws org.licas.util.exception.ServiceException for service specific error.
     * @throws java.lang.Exception any other error.
     */
    public FrameworkModule getServiceOrWrapper(String serviceName, String thePassword, String adminKey)
        throws ServiceException, Exception
    {
        return serviceAdmin.getServiceOrWrapper(serviceName, thePassword, adminKey);
    }

    /**
     * Return the service or module for the related service name. This method requires
     * the service admin key as well, but then returns a direct reference to the service object,
     * no matter what the object type is.
     * @param serviceName the name of the service you want to retrieve.
     * @param thePassword the password for the service you want to retrieve.
     * @param adminKey the admin key for the service you want to retrieve.
     * @return the service object if it exists or null if it does not.
     * @throws org.licas.util.exception.ServiceException for service specific error.
     * @throws java.lang.Exception any other error.
     */
    public Object getService(String serviceName, String thePassword, String adminKey)
        throws ServiceException, Exception
    {
        return serviceAdmin.getService(serviceName, thePassword, adminKey);
    }
    
    /**
     * Clear all existing services and service modules.
     * @param adminKey this service's admin key.
     * @return true if services cleared.
     * @throws java.lang.Exception any error. 
     */
    public boolean clearServices(String adminKey) throws Exception
    {
        try {
            if (isAdminKey(adminKey)) {
                removeAllServices(adminKey);
                clearServiceLinks(null, adminKey);
                return true;
            }
            else {
                return false;
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "clearServices", null, ex);
        }
    }
    
    /**
     * Clear all existing services or service modules, with names on the list.
     * @param serviceIDs list of IDs for services to remove. Should be String key or Element path.
     * @param adminKey this service's admin key.
     * @return true if services cleared.
     * @throws java.lang.Exception any error. 
     */
    public boolean clearServices(ArrayList<?> serviceIDs, String adminKey)
            throws Exception
    {
        try {
            if (isAdminKey(adminKey)) {
                removeAllServices(serviceIDs, adminKey);
                clearServiceLinks(serviceIDs, adminKey);
                return true;
            }
            else {
                return false;
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "clearServices", null, ex);
        }
    }

    /**
     * Clear the links for the named services.
     * @param serviceIDs List of IDs for services to clear. Should be String key or Element path,
     * {@code Null} for all services.
     * @param adminKey this service's admin key.
     * @throws java.lang.Exception any error.
     */
    protected void clearServiceLinks(ArrayList<?> serviceIDs, String adminKey) throws Exception
    {
        if (serviceIDs == null) {
            passwordHandler.clearLinkedServicePasswords(adminKey);
            serviceLinks.clearLinks(adminKey);
        }
        else {
            passwordHandler.clearLinkedServicePasswords(serviceIDs, adminKey);
            serviceLinks.clearLinks(serviceIDs, adminKey);
        }
    }

    /**
     * Remove all child services and modules from this service and terminate their threads.
     * @param adminKey this service's admin key.
     * @throws PasswordException incorrect admin key.
     * @throws java.lang.Exception any error.
     */
    protected void removeAllServices(String adminKey) throws PasswordException, Exception
    {
        serviceAdmin.removeAllServices(adminKey);
    }
    
    /**
     * Remove all child services and modules on the service list from this service
     * and terminate their threads.
     * @param serviceIDs id list for service passwords to remove. Should be String key or Element path.
     * @param adminKey this service's admin key.
     * @throws PasswordException incorrect admin key.
     * @throws java.lang.Exception any error.
     */
    public void removeAllServices(ArrayList<?> serviceIDs, String adminKey)
            throws PasswordException, Exception
    {
        serviceAdmin.removeAllServices(serviceIDs, adminKey);
    }
    
    /**
     * Remove the service or module with the indicated ID from the list and terminate it.
     * @param serviceUuid the uuid of the stored service to remove.
     * @param adminKey this service's admin key.
     * @return true if the service has been removed.
     * @throws java.lang.Exception any error.
     */
    public boolean removeServiceID(String serviceUuid, String adminKey) throws Exception
    {
        return serviceAdmin.removeService(serviceUuid, adminKey, true);
    }
    
    /**
     * Remove the service or module with the indicated path from the list and terminate it.
     * @param servicePath the path to the service.
     * @param adminKey this service's admin key.
     * @return true if the service has been removed.
     * @throws java.lang.Exception any error.
     */
    public boolean removeServicePath(Element servicePath, String adminKey) throws Exception
    {
        return removeServicePath(servicePath, adminKey, true);
    }

    /**
     * Remove the service or module with the indicated path from the list.
     * @param servicePath the path to the service.
     * @param adminKey this service's admin key.
     * @param stopThread true if stop the thread running.
     * @return true if the service has been removed.
     * @throws java.lang.Exception any error.
     */
    public boolean removeServicePath(Element servicePath, String adminKey, boolean stopThread)
            throws Exception
    {
        return serviceAdmin.removeService(servicePath, adminKey, stopThread);
    }

    /**
     * Get all child service and module names.
     * @return all service ids, of type String.
     */
    public ArrayList<String> getServiceNames()
    {
        ArrayList<String> serviceNames;                 //service names
        
        serviceNames = serviceAdmin.getServiceNames();
        if (serviceNames != null) {
            serviceNames = (ArrayList)serviceNames.clone();
        }
        
        return serviceNames;
    }
    
    /**
     * Return all child or module service names for a list of service types.
     * @param thisServiceTypes the service types list.
     * @return the service names for the service types list.
     * @throws LicasException if the service types input is {@code null}.
     */
    public ArrayList<String> getServiceNames(ArrayList<String> thisServiceTypes) throws LicasException
    {
        ArrayList<String> serviceNames;                 //service names

        serviceNames = getServiceNames(thisServiceTypes, false);
        if (serviceNames != null) {
            serviceNames = (ArrayList)serviceNames.clone();
        }
        
        return serviceNames;
    }

    /**
     * Return all child or module service names for a list of service types.
     * @param thisServiceTypes the service types list.
     * @param reciprocal is false return all service names of the service types,
     * if true return all service names of all other types.
     * @return the service names for the service types list.
     * @throws LicasException if the service types input is {@code null}.
     */
    public ArrayList<String> getServiceNames(ArrayList<String> thisServiceTypes, boolean reciprocal) throws LicasException
    {
        ArrayList<String> serviceNames;                 //service names

        serviceNames = serviceAdmin.getServiceNames(thisServiceTypes, reciprocal);
        if (serviceNames != null) {
            serviceNames = (ArrayList)serviceNames.clone();
        }
        
        return serviceNames;
    }
    
    /**
     * Return all service types for all stored services and modules.
     * @return all service types.
     */
    public ArrayList<String> getServiceTypes()
    {
        ArrayList<String> serviceTypes;                 //service types

        serviceTypes = serviceAdmin.getServiceTypes();
        if (serviceTypes != null) {
            serviceTypes = (ArrayList)serviceTypes.clone();
            serviceTypes.remove(Const.HTTPSERVER);
        }
        
        return serviceTypes;
    }
    
    /**
     * Get the service type for the named child service if it exists.
     * @param serviceName the name of the service to look for.
     * @return the service type if it exists, or null otherwise. 
     */
    public String getServiceType(String serviceName)
    {
        return serviceAdmin.getServiceType(serviceName);
    }

    /**
     * Return a count of how many services of the specified type are on this service.
     * @param serviceType the service type. Can be {@link Const}.{@code }ALLSERVICES} for all services.
     * @return the service names for the service types list.
     * @throws LicasException if the service types input is {@code null}.
     */
    public int getServiceNumber(String serviceType) throws LicasException
    {
        int count;                                      //service count
        ArrayList<String> serviceNames;                 //service names

        count = 0;
        if (serviceType != null) {
            if (serviceType.equalsIgnoreCase(Const.ALLSERVICES)) {
                for (String key : serviceAdmin.serviceTypes.keySet()) {
                    count += serviceAdmin.getServiceNames(key).size();
                }
            } else {
                serviceNames = serviceAdmin.getServiceNames(serviceType);
                if (serviceNames != null) {
                    count = serviceNames.size();
                }
            }
        }

        return count;
    }

    /**
     * Get the class type for a standard default service, known by the service factory
     * or this service. This is assumed to be public information.
     * @param serviceType the service type.
     * @return the class name for the default service.
     */
    public String getPublicServiceClassname(String serviceType)
    {
        if (ServiceFactory.getInstance() != null) {
            return ServiceFactory.getInstance().getDefaultServiceClassname(serviceType);
        }
        
        return null;
    }

    /**
     * Get the class types for all services that are stored.
     * @param theAdminKey the unique admin service key of this service.
     * @return the service handles with the class types for the services
     * of this component.
     */
    public HashMap<String, String> getServiceClasses(String theAdminKey)
    {
        HashMap<String, String> serviceClasses;             //service classes
        
        if (passwordHandler.isAdminKey(theAdminKey)) {
            serviceClasses = serviceAdmin.getServiceClasses();
            if (serviceClasses != null) {
                serviceClasses = (HashMap)serviceClasses.clone();
            }
            
            return serviceClasses;
        }
        
        return null;
    }
    
    /**
     * Create a permanent link from this service to another service.
     * This method also calls the other service remotely to ask it to create
     * a link to this service as well.
     * @param adminKey the unique admin key of this service.
     * @param serviceTo the unique ID of the service to create a link to.
     * @param servicePassword the password to call the other service.
     * @param serviceUri the path to the other service.
     * @return true if the link is successfully created.
     * @throws LicasException if the link is to a remote service.
     * @throws java.lang.Exception any error.
     */
    public boolean createPermanentLinkTo(String adminKey, String serviceTo,
        String servicePassword, Element serviceUri) throws LicasException, Exception
    {
        boolean isOK;                           //true if OK
        String localUrl;                        //local url address
        String serviceUrl;                      //remote url address
        
        isOK = false;
        try {
            //do not add the link if one already exists in the other direction
            if (serviceLinks.getLinkFromService(serviceTo) == null) {
                if (passwordHandler.isAdminKey(adminKey)) {
                    localUrl = LocalServer.getServerURL();
                    serviceUrl = Handle.getURL(serviceUri);
                    
                    if ((localUrl != null) && localUrl.equals(serviceUrl)) {
                        serviceLinks.createPermanentLinkTo(serviceTo, servicePassword, serviceUri);
                        isOK = true;
                    }
                    else {
                        throw new LicasException("Trying to create a permanent link to a remote service.");
                    }
                }
            }
        }
        catch (PasswordException pe) {
            //can process here to try and get the password?
        }
        
        return isOK;
    }
    
    /**
     * Remove a permanent link from this service to another service.
     * This method also calls the other service remotely to ask it to remove
     * the same link from reference to this service.
     * @param adminKey the unique admin key of this service.
     * @param serviceTo the unique ID of the service to remove a link to.
     * @param servicePassword the password to call the other service.
     * @param serviceUri the path to the other service.
     * @return true if the link is successfully removed.
     * @throws java.lang.Exception any error.
     */
    public boolean removePermanentLinkTo(String adminKey, String serviceTo,
        String servicePassword, Element serviceUri) throws Exception
    {
        boolean isOK;                       //true if OK
        
        isOK = true;   
        try {
            if (passwordHandler.isAdminKey(adminKey)) {
                serviceLinks.removePermanentLinkTo(serviceTo, servicePassword, serviceUri);
            }
        }
        catch (PasswordException pe) {
            isOK = false;
            //can process here to try and get the password?
        }
        
        return isOK;
    }
    
    /**
     * Convert any dynamic links to permanent ones, or remove any permanent links
     * that do not now exist as dynamic ones. Before converting to a permanent link,
     * this also checks that the link is between services running on the same server.
     * @param adminKey the unique admin key of this service.
     * @throws java.lang.Exception any error.
     */
    public void dynamicLinksToPermanent(String adminKey) throws Exception
    {
        int i, j, k;
        boolean linkExists;                         //true if the link exists
        String linkUuid;                            //link uuid
        String permUuid;                            //permanent link uuid
        String localIP;                             //local ip address
        String serviceIP;                           //service ip address
        ArrayList<Element> linkedSources;           //linked sources
        ArrayList<Object> currentLinks;             //current permanent links list
        DynamicLinkParser dlp;                      //dynamic links parser
        Vector<Node> linkedPaths;                   //linked paths
        Element linkElem;                           //link info
        Element pathElem;                           //path info
        Element nextElem;                           //next info
        Element nextLink;                           //next link
        Element permLink;                           //permanent link
        Link_M linker;                              //linking service

        if (isAdminKey(adminKey)) {
            localIP = LocalServer.getServerURL();
            if (localIP != null) {
                linker = (Link_M) getService(ServiceConst.LINKER,
                        passwordHandler.getServicePassword(ServiceConst.LINKER),
                        passwordHandler.getAdminKey(ServiceConst.LINKER));

                dlp = new DynamicLinkParser();
                linkElem = dlp.serialize("", linker, false, false);
                linkedPaths = linkElem.getChildren();

                if (linkedPaths != null) {
                    for (i = 0; i < linkedPaths.size(); i++)
                    {
                        pathElem = (Element)linkedPaths.get(i);
                        linkedSources = linker.getLinkElements(pathElem);

                        for (j = 0; j < linkedSources.size(); j++)
                        {
                            linkElem = linkedSources.get(j);

                            nextElem = linkElem.getChild(Const.HANDLE);
                            if (nextElem != null) {
                                //only link if on same server
                                serviceIP = Handle.getURL(nextElem);
                                if (localIP.equals(serviceIP)) {
                                    nextLink = (Element) nextElem.clone();
                                    linkUuid = Handle.getLastServiceHandle(nextLink);

                                    createPermanentLinkTo(passwordHandler.getAdminKey(), linkUuid,
                                            getServicePassword(linkUuid, null), nextLink);
                                }
                            } else {
                                //check for a source uuid only
                                nextElem = linkElem.getChild(Const.SOURCE);
                                if (nextElem != null) {
                                    linkUuid = nextElem.getText();
                                    nextLink = Handle.createNewUrlHandle(LocalServer.getServerURL());
                                    nextLink = Handle.addToHandle(nextLink, Handle.asHandleElement(linkUuid));

                                    createPermanentLinkTo(passwordHandler.getAdminKey(), linkUuid,
                                            getServicePassword(linkUuid, null), nextLink);
                                }
                            }
                        }
                    }

                    //also remove permanent links that are not now part of the linking structure
                    currentLinks = getAllLinkToService();
                    if (currentLinks != null) {
                        for (i = 0; i < currentLinks.size(); i++)
                        {
                            linkExists = false;
                            nextLink = null;

                            permUuid = ObjectHandler.getKey(currentLinks.get(i));
                            try {
                                permLink = XmlHandler.stringToElement(permUuid);
                                permUuid = Handle.getLastServiceHandle(permLink);
                            }
                            catch (Exception ex) {}

                            for (j = 0; !linkExists && (j < linkedPaths.size()); j++)
                            {
                                pathElem = (Element)linkedPaths.get(j);
                                linkedSources = linker.getLinkElements(pathElem);

                                for (k = 0; k < linkedSources.size(); k++)
                                {
                                    linkElem = linkedSources.get(k);
                                    nextElem = linkElem.getChild(Const.HANDLE);

                                    if (nextElem != null) {
                                        nextLink = (Element) linkElem.getChild(Const.HANDLE).clone();
                                        linkUuid = Handle.getLastServiceHandle(nextLink);

                                        if (linkUuid.equals(permUuid)) linkExists = true;
                                    }
                                }

                                if (!linkExists && (nextLink != null)) {
                                    removePermanentLinkTo(passwordHandler.getAdminKey(), permUuid,
                                            getServicePassword(permUuid, null), nextLink);
                                }
                            }
                        }
                    }
                }
            } else {
                throw new LicasException("Local server ip is null.");
            }
        }
    }
    
    /**
     * Return true if this service has a permanent local link ({@link PermanentLink} only)
     * to the service with the specified service ID.
     * @param serviceID the ID of the local service to check for a link with.
     * @return true if a permanent link exists.
     */
    public boolean hasLinkTo(String serviceID)
    {
        return (getLinkToService(serviceID) != null);
    }
    
    /**
     * Add a link reference to another service locally in this service.
     * @param serviceID a unique id to identify the service.
     * @param theReference the source reference (Object or XML URI).
     * @return true if the link is added or false if the id already exists.
     */
    protected boolean addLinkToService(String serviceID, Object theReference)
    {
        return serviceLinks.addLinkToService(serviceID, theReference);
    }
    
    /**
     * Remove the local link to the specified service if it exists.
     * This should not be called directly, but is called through the 
     * {@code removePermanentLinkTo} method.
     * @param serviceID the id of the service being linked to.
     */
    protected void removeLinkToService(String serviceID)
    {
        serviceLinks.removeLinkToService(serviceID);
    }
    
    /**
     * Get all source references for a links to another service.
     * @return a list of all source references, or null if no links exist.
     */
    protected ArrayList<Object> getAllLinkToService()
    {
        return serviceLinks.getAllLinkToService();
    }
    
    /**
     * Get the source reference for a link to another service.
     * @param serviceID the id of the service linked to.
     * @return the value of source or null if no link exists.
     */
    public Object getLinkToService(String serviceID)
    {
        return serviceLinks.getLinkToService(serviceID);
    }
    
    /**
     * Add a link from another service locally in this service.
     * This method should not be called directly, but is done through the
     * {@code createPermanentLinkTo} method on the remote service creating the link.
     * @param serviceID a unique id to identify the service.
     * @param theReference the source reference (Object or XML URI).
     * @return true if the link is added or false if the id already exists.
     */
    public boolean addLinkFromService(String serviceID, Object theReference)
    {
        return serviceLinks.addLinkFromService(serviceID, theReference);
    }
    
    /**
     * Remove the local link from the specified service if it exists.
     * This method should not be called directly, but is done through the
     * {@code removePermanentLinkTo} method on the remote service removing the link.
     * @param serviceID the id of the service being linked to.
     */
    public void removeLinkFromService(String serviceID)
    {
        serviceLinks.removeLinkFromService(serviceID);
    }
    
    /**
     * Get the source reference for a link from another service.
     * @param serviceID the id of the service linked to.
     * @return the value of source or null if no link exists.
     */
    public Object getLinkFromService(String serviceID)
    {
        return serviceLinks.getLinkFromService(serviceID);
    }
    
    /**
     * Serialize the service using the {@link ServiceSerialize} class.
     * @param adminKey the service admin key.
     * @return an XML representation of all named elements, or null if the admin key is incorrect.
     * @throws Exception any error.
     */
    public Element serviceToXml(String adminKey) throws Exception
    {
        return ServiceHandler.serviceToXml(adminKey, this);
    }
    
    /**
     * Serialize the service using the {@link ServiceSerialize} class.
     * @param adminKey the service admin key.
     * @param adminToRemove if any section is indicated here through the XML tag name, it is removed first.
     * @param toSerialize list of service-local variable names to serialize.
     * @return an XML representation of all named elements, or null if the admin key is incorrect.
     * @throws Exception any error.
     */
    public Element serviceToXml(String adminKey, ArrayList<String> adminToRemove, ArrayList<String> toSerialize)
            throws Exception
    {
        return ServiceHandler.serviceToXml(adminKey, adminToRemove, toSerialize, this);
    }
    
    /**
     * Create the service from the description using the {@link ServiceSerialize} class.
     * @param serviceXml a full XML description of the service.
     * @param password parent password, probably the server currently running. Need to
     * use this instead of the stored value if a server.
     * @return the re-created service, probably derived from {@link Service}, but it
     * might be a wrapped object.  
     * @throws java.lang.Exception any error.
     */
    public static Object xmlToService(Element serviceXml, String password) throws Exception
    {
        return ServiceHandler.xmlToService(serviceXml, password);
    }
    
    /**
     * Serialize the stored passwords list and the service state, and return as an 
     * XML-based description. This is used more internally, to save the whole server
     * or SOA to a file. You can also use {@link PasswordHandler}.{code toXml} or
     * {code fromXml} to serialize just the passwords.
     * @param adminKey the service admin key.
     * @return an XML representation of all passwords, or null if the admin key is incorrect.
     * @throws Exception any error.
     */
    public Element passwordsStateToXml(String adminKey) throws Exception
    {
        return ServiceHandler.passwordsStateToXml(adminKey, this);
    }
    
    /**
     * Perform a query over the link paths to return matching sources. Note that a 
     * linking service must be added first.
     * @param queryConfig the query configuration.
     * @return a list of source uris that match with the query.
     * @throws java.lang.Exception any error.
     */
    public Element dynamicLinkQuery(LinkQueryConfig queryConfig) throws Exception
    {
        return ServiceHandler.dynamicLinkQuery(queryConfig, this);
    }
    
    /**
     * Return all linked references in XML format.
     * @param adminKey the service admin key.
     * @return an XML representation of all linked source references.
     * @throws Exception any error.
     */
    public Element linksToXml(String adminKey) throws Exception
    {
        return ServiceHandler.linksToXml(adminKey, this);
    }
    
    /**
     * Return all permanent linked-t0 services in XML format. 
     * @return an XML representation of all permanent links.
     * @throws Exception any error.
     */
    public Element permanentLinksToXml() throws Exception
    {
        return ServiceHandler.permanentLinksToXml(this);
    }
    
    /**
     * Return all linked sources in XML format. This returns a list of link URIs only. 
     * To retrieve all information, try the linking service {@code dynamicLinksToXml(adminKey)} 
     * or use {@code LinksParser} locally. Note that a linking service must be added first.
     * @return an XML representation of all linked sources.
     * @throws Exception any error.
     */
    public Element dynamicLinksToXml() throws Exception
    {
        return ServiceHandler.dynamicLinksToXml(this);
    }
    
    /**
     * Return all linked sources in XML format, including all link levels and the
     * source weight values. Note that a linking service must be added first.
     * @param adminKey the service admin key.
     * @return an full XML representation of all linked sources, or null if the admin 
     * key is incorrect.
     * @throws Exception any error.
     */
    public Element dynamicLinksToXml(String adminKey) throws Exception
    {
        return ServiceHandler.dynamicLinksToXml(adminKey, this);
    }
    
    /**
     * Parse the links descriptions and add to the service.
     * @param linksXml a full set of links descriptions for the service.
     * @param adminKey the admin key.
     * @return true if the links were parsed, false otherwise, for example,
     * incorrect admin key.
     * @throws java.lang.Exception any error.
     */
    public boolean xmlToDynamicLinks(Element linksXml, String adminKey) throws Exception
    {
        return ServiceHandler.xmlToDynamicLinks(linksXml, adminKey, this);
    }
    
    /**
     * Add a new URI for a link to a (probably remote) service. This is simply
     * an association link created from a single call. It is different to a permanent
     * link in the sense that it probably does not make up any permanent network structure.
     * It can act in the same way though. It is also different from a dynamic link
     * which is built up over time through reinforcement. Including this link type simply
     * covers the different types of service associations that you might want to make.
     * @param adminKey the unique admin key of this service.
     * @param serviceUri the URI of the service to link to, as a Handle Element.
     * @param servicePassword the password for the service being linked to, so that
     * it can be invoked.
     * @throws java.lang.Exception any other error.
     * @return true if added or false if it already exists.
     */
    public boolean addServiceAssociation(String adminKey, Element serviceUri,
            String servicePassword) throws Exception
    {
        boolean isOK;                               //true if OK
        String serviceKey;                          //created service key
          
        isOK = false;
        if (passwordHandler.isAdminKey(adminKey)) {
            serviceKey = getLocalRemoteID(serviceUri);
            isOK = serviceLinks.addServiceAssociation(serviceKey, serviceUri);
            
            if (isOK) {
                passwordHandler.addServicePassword(serviceUri, servicePassword);
            }
        }
        
        return isOK;
    }

    /**
     * Remove a URI for a link to a (probably remote) service.
     * @param serviceUri the URI of the service to remove the link to, as a {@link Handle} Element.
     * @throws java.lang.Exception any other error.
     */
    public void removeServiceAssociation(Element serviceUri) throws Exception
    {
        String serviceKey;                          //created service key
          
        serviceKey = getLocalRemoteID(serviceUri);
        serviceLinks.removeServiceAssociation(serviceKey);
    }
    
    /**
     * Remove all non-dynamic links to the specified service from all other services.
     * @param serviceID the id of the service to remove links to.
     * @param adminKey the admin key for the service to change.
     * @return true if the admin key allows access, false otherwise.
     * @throws java.lang.Exception any error. 
     */
    public boolean removeAllLinksTo(String serviceID, String adminKey) throws Exception
    {
        if (passwordHandler.getAdminKey().equals(adminKey)) {
            //permanent link
            serviceLinks.removeLinkToService(serviceID);
            
            //service association
            serviceLinks.removeServiceAssociation(serviceID);
            return true;
        }
        
        return false;
    }

    /**
     * Get the client URI stored in the message info for a communication ID.
     * @param commID the communication ID.
     * @return URI for the client in the conversation, or {@code null} if not exists.
     */
    protected Object getCommunicationClientURI(String commID)
    {
        if (hasCommunicationID(commID)) {
            return messageStore.getCommClient(commID).getMessage();
        }

        return null;
    }

    /**
     * Store the commID with the related client URI, stored as {@link MessageInfo} objects
     * with timestamps. The method now also checks the timestamps and removes any 
     * communicationIDs that are older than 3 days.
     * @param commID the communication id.
     * @param clientURI the URI/reference for the calling client. If {@code null} or a server URI,
     * then it is set to {@link Const}.{@code ANON} and only the commID is subsequently checked for.
     * @return true if the id is new and can be added, or false if the comm id already 
     * exists, or cannot be added.
     * @throws java.lang.Exception any error.
     */
    protected boolean addCommunicationID(String commID, Object clientURI) throws Exception
    {
        int i;
        long lastCallTime;                          //last allowed call time
        String nextCommID;                          //next communication id
        ArrayList<String> allKeys;                  //all keys
        Object storedClientUri;                     //stored client uri
        MessageInfo messageInfo;                    //message info

        try {
            sm.setCommID(null);

            if (commID != null) {
                sm.setCommID(commID);
                messageInfo = new MessageInfo(clientURI);
                messageInfo.setTimeStamp();

                if (!messageStore.hasCommID(commID)) {
                    messageStore.addCommID(commID, messageInfo);
                    return true;
                }
                else {
                    storedClientUri = messageStore.getCommClient(commID).getMessage();
                    if (storedClientUri.equals(Const.ANON) ||
                        ObjectHandler.equals(messageInfo.getMessage(), storedClientUri)) {
                        messageStore.addCommID(commID, messageInfo);
                        return true;
                    }
                }

                return false;
            }

            return false;
        }
        finally {
            lastCallTime = new Date().getTime();
            lastCallTime -= (TimeConst.MILLIDAY * 3);
            
            //remove any communications that are older than 3 days
            allKeys = messageStore.getCommIDs();
            for (i = 0; i < allKeys.size(); i++)
            {
                nextCommID = allKeys.get(i);
                messageInfo = messageStore.getCommClient(nextCommID);
                if (messageInfo.getTimeStamp() < lastCallTime) {
                    removeCommunicationID(nextCommID);
                }
            }
        }
    }
    
    /**
     * Remove the communication ID reference.
     * @param communicationID the communication ID.
     */
    protected void removeCommunicationID(String communicationID)
    {
        if (communicationID != null) {
            messageStore.removeCommID(communicationID);
        }
    }
    
    /**
     * This method can be invoked by a client that maybe does not have constant access to
     * the server. You pass this method the full {@code MethodInfo} description of the
     * method that you want to call on the service. This gets processed as normal and 
     * if allowed, the method is invoked, but the reply is then saved in a store instead 
     * of being returned. You therefore need to include a unique {@code communicationID} in
     * the method info, to reference the stored object. After completion, you can call 
     * {@code messageRetrieve} to get and remove the method reply from the store.
     * @param methodInfo full description of the method to invoke. So this is the
     * parameter to the MethodInfo that is actually executed on the service. It is
     * then passed through this service's execution process as normal.
     * @throws java.lang.Exception any error.
     */
    public void syncToAsync(MethodInfo methodInfo) throws Exception
    {
        String replyID;                     //communication id
        Object reply;                       //message reply

        try {
            replyID = methodInfo.getCommunicationID();

            if ((replyID != null) && !replyID.equals(Const.NULL)) {
                methodInfo.setPassword(passwordHandler.getPassword());

                //comm id should already be added
                if (messageStore.hasCommID(replyID)) {
                    messageStore.addMethodTransit(replyID);

                    if (!methodInfo.getRtnType().equalsIgnoreCase(TypeConst.VOID)) {
                        reply = this.execute(methodInfo, false);
                        messageStore.addSavedReply(replyID, reply);
                    } else {
                        messageStore.removeReplyID(replyID);
                        this.execute(methodInfo, false);
                    }
                }
                else {
                    throw new LicasException("Asynchronous message communication ID " + replyID + " with " + getUUID() + " already exists.");
                }
            } else {
                throw new LicasException("Asynchronous message communication ID not set with " + getUUID() + ".");
            }
        }
        catch (LicasException liex) {
            throw liex;
        }
        catch (Exception ex) {
            replyID = methodInfo.getCommunicationID();
            if ((replyID != null) && !replyID.equals(Const.NULL)) {
                messageStore.removeReplyID(replyID);
            }

            throw ex;
        }
    }
    
    /**
     * Return true if a reply id for a method invocation has been registered
     * and the method execution is still on-going.
     * @param replyID id for the method reply.
     * @return true if the method for the id has not completed yet.
     */
    public boolean syncToAsyncTransit(String replyID)
    {
        return (messageStore.inTransit(replyID) && !messageStore.hasSavedReply(replyID));
    }
    
    /**
     * Retrieve a stored method reply.
     * @param replyID id for the method reply. Similar to a comm id.
     * @return the reply object, or null if one is not stored.
     */
    public MessageInfo syncToAsyncReply(String replyID)
    {
        MessageInfo reply;                      //wrapped reply object

        reply = messageStore.getSavedReply(replyID);
        return reply;
    }
    
    /**
     * Set the value indicating a remote call.
     * @param thisIsRemoteCall true if current call is remote.
     */
    public void setIsRemoteCall(boolean thisIsRemoteCall)
    {
        isRemoteCall = thisIsRemoteCall;
    }
    
    /**
     * Return a value indicating if current call is remote.
     * @return the value of isRemoteCall.
     */
    public boolean getIsRemoteCall()
    {
        return isRemoteCall;
    }

    /**
     * Execute the specified method and return the result.
     * @param methodInfo the method call description with all of the required information.
     * @param addTempPassword if true add a temporary password to allow traversal
     * through this service. If the service is referenced directly as an object
     * then set this to false so that the caller must know this service's password.
     * @return the reply, any object.
     * @throws java.lang.Exception any error.
     */
    public Object execute(MethodInfo methodInfo, boolean addTempPassword) throws Exception
    {

        String tempPassword;                    //a temp password
        String replyClass;                      //reply type
        MethodHandler mHandler;                 //method handler
        MethodInfo toExecute;                   //to execute in the thread
        Object reply;                           //the reply

        tempPassword = null;
        try {
            //add the message details to the am stats
            addMessageMetrics(methodInfo, passwordHandler.getPassword());

            tempPassword = addTempPassword(addTempPassword);
            mHandler = new MethodHandler(tempPassword, this);
            isRemoteCall = methodInfo.getIsRemote();

            toExecute = new MethodInfo();
            toExecute.setName(MethodConst.EXECUTE);
            toExecute.setRtnType(TypeConst.OBJECT);
            toExecute.setServiceObj(mHandler);
            toExecute.addParam(methodInfo);

            replyClass = methodInfo.getRtnType();
            if (replyClass.equals(TypeConst.VOID)) {
                //execute the method without a reply
                CallExecutor.getInstance().execute(toExecute);
                reply = null;
            }
            else {
                //execute the method to return the reply
                reply = CallExecutor.getInstance().execute(toExecute);
            }

            return reply;
        }
        catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        }
        finally {
            isRemoteCall = false;
            if (tempPassword != null) {
                removeTempPassword(tempPassword);
            }
        }
    }

    /**
     * You must call this method to interrupt the thread.
     * This also interrupts all nested services.
     * @param adminKey the key to identify unique loading of the service.
     * @return true if the service is stopped.
     */
    public boolean interrupt(String adminKey)
    {
        boolean isOK;                           //true if OK
        ServiceDef nextService;                 //next service
        ServiceInfo nextServiceInfo;            //next service info

        isOK = false;
        try {
            if (!isInterrupted() && isAdminKey(adminKey)) {
                for (String key : serviceAdmin.services.keySet())
                {
                    nextServiceInfo = serviceAdmin.services.get(key);

                    nextService = nextServiceInfo.getService();
                    if (ModuleHandler.isService(nextService)) {
                        ((Service)nextService).interrupt(passwordHandler.getAdminKey(key));
                    }
                }
                
                isOK = super.interrupt(adminKey);
            }
        } 
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "interrupt", null, ex);
        }

        return isOK;
    }

    /**
     * Get the password handler.
     * @return the value of passwordHandler.
     */
    protected PasswordHandler getPasswordHandler()
    {
        return passwordHandler;
    }

    /**
     * Set a full admin info description for the service.
     * @param adminXml the full admin description.
     * @param adminKey the service key for this service.
     * @throws java.lang.Exception any error.
     */
    public void setAdminInfo(Element adminXml, String adminKey) throws Exception
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            serviceAdmin.setAdminInfo(adminXml);
        }
    }

    /**
     * Set the service grade or function class.
     * @param thisServiceGrade the service grade.
     */
    protected void setServiceGrade(String thisServiceGrade)
    {
        serviceGrade = thisServiceGrade;
    }

    /**
     * Get the grade for this service.
     * @return the value of serviceGrade.
     */
    public String getServiceGrade()
    {
        return serviceGrade;
    }

    /**
     * This sets a value indicating the current service state.
     * @param theServiceState the service state.
     * @param adminKey the admin key for this service..
     */
    public void setServiceState(String theServiceState, String adminKey)
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            serviceState = theServiceState;
        }
    }

    /**
     * This method returns a value indicating the what current service state is.
     * This default implementation returns {@link Const}.{@code READY} or 'Ready',
     * meaning that it is ready for use. Any derived class can change this evaluation
     * and set it to a value reflecting the current service state.
     * @param adminKey the admin key for this service.
     * @return the value of serviceState, or null if access is not allowed.
     */
    public String getServiceState(String adminKey)
    {
        if (passwordHandler.isAdminKey(adminKey)) return serviceState;
        else return null;
    }

    /**
     * Set the service description value only.
     * @param descriptionXml the description. This is only the service description
     * and is not the full set of admin info values.
     * @param adminKey the service key for this service.
     * @return true if access is allowed or false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean setDescription(Element descriptionXml, String adminKey) throws Exception
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            serviceAdmin.getAdminInfo().setDescription(descriptionXml);

            //update the server repos with the new definition
            Objects.requireNonNull(LocalServer.getApi(getServerPassword())).removeServiceMeta(getUUID(), passwordHandler.getAdminKey());
            Objects.requireNonNull(LocalServer.getApi(getServerPassword())).addServiceMeta(passwordHandler.getPassword(),
                    passwordHandler.getAdminKey(), createMetaForRepos(passwordHandler.getAdminKey()));

            return true;
        }

        return false;
    }

    /**
     * Get the description value. This is just the description and not the full
     * set of admin rules.
     * @return the service description.
     */
    public Element getDescription()
    {
        if (serviceAdmin.adminInfo != null) {
            return serviceAdmin.adminInfo.getDescription();
        }

        return null;
    }

    /**
     * Set the additional metadata value.
     * @param otherMetaXml the additional metadata not included as default.
     * @param adminKey the service key for this service.
     * @return true if access is allowed or false otherwise.
     */
    public boolean setOtherMeta(Element otherMetaXml, String adminKey)
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            serviceAdmin.getAdminInfo().setOtherMeta(otherMetaXml);
            return true;
        }

        return false;
    }

    /**
     * Set the value that this service will use as its data source. This method parses the data
     * XML description to create the appropriate data {@link Resource} in the {@link DataModule}.
     * @param dataXml the data description to parse.
     * @param adminKey the admin key for the service.
     * @return true if set OK, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean setData(Element dataXml, String adminKey) throws Exception
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            dm.setData(dataXml);
            return true;
        }

        return false;
    }

    /**
     * Get the data value only, as a java object.
     * @return the data value only, not wrapped in an XML element.
     * @throws java.lang.Exception any error.
     */
    public Object getData() throws Exception
    {
        return getData(null);
    }

    /**
     * Get the data value only, not converted into XML, based on some condition.
     * @param dataDescr a description of the data part that should be retrieved,
     * but can be null and needs to be implemented in the resource.
     * @return the data value only, not wrapped in an XML element.
     * @throws java.lang.Exception any error.
     */
    public Object getData(Element dataDescr) throws Exception
    {
        if (dm != null) {
            return dm.getData(dataDescr);
        }

        return null;
    }

    /**
     * Set the parent component value. If the parent is the ESB server then it is
     * not added, so only for child services.
     * @param thisParent the parent component representation.
     * @param adminKey the admin key for this service.
     * @return true if set, false if key incorrect, already set, or try to add server.
     */
    public boolean setParent(Service thisParent, String adminKey)
    {
        if ((service == null) && passwordHandler.isAdminKey(adminKey)) {
            if (!ModuleHandler.isServer(thisParent)) {
                service = thisParent;
                return true;
            }
        }

        return false;
    }

    /**
     * Set the parent component value. If the parent is the ESB server then it is
     * not added, so only for child services.
     * @param thisParent the parent component representation.
     * @return true if set, false if already set, or try to add server.
     */
    protected boolean setParent(Service thisParent)
    {
        if (service == null) {
            if (!ModuleHandler.isServer(thisParent)) {
                service = thisParent;
                return true;
            }
        }

        return false;
    }

    /**
     * Get the parent component representation.
     * @param adminKey the admin key to access this information.
     * @return the value of parent.
     */
    public Service getParent(String adminKey)
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            return service;
        }

        return null;
    }

    /**
     * Get the parent component representation.
     * @return the value of parent.
     */
    protected Service getParent()
    {
        return service;
    }
    
    /**
     * If the Handle-style URI is for a local service running on the same server,
     * then just return its ID, otherwise convert the whole URI to a string.
     * @param serviceUri the full service URI path.
     * @return the service ID (local) or full path (remote).
     * @throws java.lang.Exception any error.
     */
    protected String getLocalRemoteID(Element serviceUri) throws Exception
    {
        String serviceKey;                  //parsed service key
        
        if (Handle.isLocalURI(serviceUri)) {
            serviceKey = Handle.getLastServiceHandle(serviceUri);
        }
        else {
            serviceKey = XmlHandler.xmlToString(serviceUri);
        }
        
        return serviceKey;
    }

    /**
     * Checks if the calling client exists and can connect with it. Performs some of
     * the default operations.
     * @param serverURI uri of remote server to contact.
     * @param serverPassword server password.
     * @param serviceID uuid of service running on the server.
     * @param servicePassword service password.
     * @return true if service can be contacted, false otherwise.
     */
    public boolean handshake(Element serverURI, String serverPassword, String serviceID,
                             String servicePassword)
    {
        boolean isOK;                           //true if OK
        Element serviceUri;                     //service uri
        MethodInfo methodInfo;                  //method info
        CallObject callObject;                  //the call object

        isOK = false;

        //try to ping first
        if (CallHandler.testServerConnection(serverURI, serverPassword)) {
            callObject = new CallObject();
            serviceUri = Handle.createServiceHandle(serverURI, serviceID);

            try {
                //check if legal to access using known settings
                methodInfo = new MethodInfo();
                methodInfo.setClientURI(getFullPath());
                methodInfo.setName(MethodConst.CANACCESS);
                methodInfo.setRtnType(TypeConst.BOOLEAN);
                methodInfo.setServiceURI(serviceUri);
                methodInfo.setServerPassword(serverPassword);
                methodInfo.setPassword(servicePassword);
                methodInfo.setCallTimeout(5000);
                methodInfo.addParam(servicePassword);
                isOK = (Boolean)callObject.call(methodInfo);
            }
            catch (Exception ex) {
                isOK = false;
            }
        }

        return isOK;
    }

    /**
     * Get a list of public methods that can be accessed through the service.
     * @return a list of Reflection method descriptions, not the licas descriptions.
     */
    public ArrayList<Method> reflectionMethods()
    {
        int i;
        Method[] cMethods;                          //class methods
        ArrayList<Method> methods;                  //allowed methods

        methods = new ArrayList<>();

        cMethods = this.getClass().getMethods();
        for (i = 0; i < cMethods.length; i++) {
            if (!getPrivateMethods().contains(cMethods[i].getName())) {
                methods.add(cMethods[i]);
            }
        }
        cMethods = sm.getClass().getMethods();
        for (i = 0; i < cMethods.length; i++) {
            if (!getPrivateMethods().contains(cMethods[i].getName())) {
                methods.add(cMethods[i]);
            }
        }

        return methods;
    }

    /**
     * Get which object in the service is able to execute the method.
     * @param method reflection description of the method.
     * @return this object or an inherited module that can execute the method, or null if false.
     */
    protected Object reflectionObject(Method method)
    {
        int i;
        Method[] cMethods;                          //class methods

        cMethods = this.getClass().getMethods();
        for (i = 0; i < cMethods.length; i++) {
            if (cMethods[i].getName().equals(method.getName())) {
                return this;
            }
        }
        cMethods = sm.getClass().getMethods();
        for (i = 0; i < cMethods.length; i++) {
            if (cMethods[i].getName().equals(method.getName())) {
                return sm;
            }
        }

        return null;
    }

    /**
     * Get the list of methods that can be freely called on a Service in general,
     * without even requiring a password.
     * @return the list of safe method names, but might still require passwords.
     */
    public ArrayList<String> getPublicMethods()
    {
        ArrayList<String> methodNames;                  //list of method names

        methodNames = new ArrayList<>();
        methodNames.add(MethodConst.EXECUTE);
        methodNames.add(MethodConst.GETPASSWORD);
        methodNames.add(MethodConst.HASSERVICE);
        methodNames.add(MethodConst.GETSERVICENAMES);
        methodNames.add("isPublicMethod");
        methodNames.add("getPublicMethods");
        methodNames.add("getServiceClasses");
        methodNames.add("getLinksFromServices");
        methodNames.add("getLinksToServices");
        methodNames.add("serviceNegotiate");

        return methodNames;
    }

    /**
     * Get the list of public-level methods that should not be invoked externally, maybe from an interface.
     * @return the list of public-level method names that should not be accessible externally.
     */
    protected ArrayList<String> getPrivateMethods()
    {
        ArrayList<String> methodNames;                  //list of method names

        methodNames = new ArrayList<>();
        methodNames.add("close");

        return methodNames;
    }

    /**
     * Create and return a list of admin info that should probably not be
     * returned to a user for display purposes.
     * @return a list of admin info element types not to return.
     */
    public static ArrayList<String> defaultAdminToRemove()
    {
        ArrayList<String> toRemove;                     //element to remove

        toRemove = new ArrayList<>();
        toRemove.add(Const.HANDLE);
        toRemove.add(Const.METHODS);
        toRemove.add(MetaConst.PERMANENTLINKSERVICEMETA);
        toRemove.add(MetaConst.DYNAMICLINKSERVICEMETA);
        toRemove.add(MetaConst.ASSOCIATEDLINKSERVICEMETA);

        return toRemove;
    }

    /**
     * Clean-up before shutting down the service.
     */
    @Override
    public void close() {
        setShutDown(true);
        sm = null;
        dm = null;
    }
}
