/*
 * MethodHandler.java
 *
 * Created on 12 December 2006
 *
 * Version 1.11.5
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.call;



import org.licas.*;
import org.licas.call.client.CallHandler;
import org.licas.def.*;
import org.licas.module.*;
import org.licas.parsers.Parsers;
import org.licas.server.*;
import org.licas.util.*;
import org.licas.util.exception.*;
import org.licas_xml.abs.Element;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.Monitor;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;


/**
 * This class parses a {@link Service} method specification and tests at each step if the
 * calling sequence is allowed. This is the main class for controlling the traversal
 * through the nested services and also checks if the specified method exists and can be
 * legally called with the specified passwords. The comparison check tests for the method name,
 * return type and also all of the input parameter types. If the call is to a remote object,
 * then this class will construct the remote calling object and try to make the remote call
 * automatically as well.
 * @author Kieran Greer
 */
public final class MethodHandler 
{
    /** The logger */
    private static final Logger logger;
    
    /** True if a direct call, that is, execute the specified method on the retrieved service */
    private boolean directCall;

    /** True if a wrapper method */
    private boolean wrapperMethod;

    /** A temporary password to access a service */
    private final String tempPassword;

    /** A list of parameter indexes */
    private ArrayList<Integer> indexes;

    /** Final list of parameters for making the method call */
    private Object[] paramObj;

    /** The parent component */
    private final Service parent;
    
    /** An object to synchronize on */
    private final Object syncOn = new Object();
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(MethodHandler.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Creates a new instance of MethodHandler.
     * @param thisTempPassword a temporary password.
     * @param thisParent the parent service that the service to invoke is retrieved
     * from. This can get traversed through a path description, from the server
     * to the final parent service, but the final password is always required.
     */
    public MethodHandler(String thisTempPassword, Service thisParent)
    {
        tempPassword = thisTempPassword;
        parent = thisParent;
        directCall = true;
    }
    

    /**
     * Parse the method info to determine the next path stage and return the next method call.
     * @param methodInfo the method call description with all of the required information.
     * @return true if need to re-route.
     * @throws java.lang.Exception any error.
     */
    public final boolean reRoute(MethodInfo methodInfo) throws Exception
    {
        boolean reRoute;                        //true if re-route
        boolean isRemote;                       //true if remote call
        String uri;                             //the server uri
        Element handle;                         //component handle
        Element thisRoute;                      //current route
        Element newRoute;                       //new route
        Object serviceUri;                      //the service uri
        
        reRoute = false;
        isRemote = false;

        methodInfo.updateServiceURIs();
        serviceUri = methodInfo.getServiceURI();

        if (ObjectHandler.isElement(serviceUri)) {
            thisRoute = (Element)methodInfo.getServiceURI();

            if (Handle.hasURL(thisRoute)) {
                uri = Handle.getURL(thisRoute);
                thisRoute = Handle.removeURL(thisRoute);

                if (!LocalServer.isLocalIPAddress(uri)) {
                    isRemote = true;

                    if (Handle.hasHandleSeparator(thisRoute)) {
                        handle = Handle.createNewHandleHandle(Handle.getFirstServiceHandle(thisRoute));
                        handle = Handle.addExecute(handle);
                        newRoute = Handle.getRestOfCall(thisRoute);

                        methodInfo.setServiceURI(handle);
                        methodInfo.setRestOfServiceURI(newRoute);
                        methodInfo.setRtnType(Object.class.getName());
                        methodInfo.setIfRemote();
                        reRoute = true;
                    }
                }
            }
        
            if (!isRemote) {
                directCall = Handle.isDirectMethodCall(thisRoute);

                if (!directCall) {
                    handle = Handle.createNewHandleHandle(Handle.getFirstServiceHandle(thisRoute));
                    handle = Handle.addExecute(handle);
                    newRoute = Handle.getRestOfCall(thisRoute);

                    methodInfo.setServiceURI(handle);
                    methodInfo.setRestOfServiceURI(newRoute);
                    methodInfo.setRtnType(Object.class.getName());
                }

                methodInfo.setIfRemote();
            }
        }
        else {
            directCall = true;
        }
        
        return reRoute;
    }
    
    /**
     * Execute a call using the invoke method of Java {@code Reflection}.
     * @param methodInfo the method call description with all of the required information.
     * @return Object the reply to the call.
     * @throws ServiceException access to the service is not allowed.
     * @throws ServiceNotFoundException the service has not been found.
     * @throws PasswordException password is not correct.
     * @throws java.lang.Exception any other error.
     */
    public final Object execute(MethodInfo methodInfo) throws ServiceException,
            ServiceNotFoundException, PasswordException, Exception
    {
        int i;
        boolean isRemote;                   //true if parent call is remote
        boolean canAccess;                  //true if can access
        String serviceName;                 //service name
        String methodName;                  //method name
        String password;                    //password
        String communicationID;             //communication id
        String replyClass;                  //reply class
        Element clientUri;                  //client uri
        Element thisRoute;                  //current route
        Method theMethod;                   //the method to call
        RemoteCallDef remoteCommObj;        //remote communication object
        ServiceDef service;                 //the service to invoke
        Object nextParamObj;                //next parameter object
        Object replyObj;                    //reply to the call

        serviceName = null;
        replyObj = null;
        wrapperMethod = true;
        paramObj = null;
        indexes = new ArrayList<>();

        //retrieve the service, checking for direct references as well
        isRemote = methodInfo.getIsRemote();

        if (reRoute(methodInfo)) {
            //remote call - use the call object to invoke the method
            remoteCommObj = CallHandler.getRemoteCommunicationObject(methodInfo);
            replyObj = remoteCommObj.execute(methodInfo);
        } else {

            //call on this server - try to retrieve the service and execute on it
            //retrieve the service
            if (ObjectHandler.isElement(methodInfo.getServiceURI())) {
                thisRoute = (Element) methodInfo.getServiceURI();

                serviceName = Handle.getFirstServiceHandle(thisRoute);
                if (directCall) methodName = methodInfo.getName();
                else methodName = Handle.getMethod(thisRoute);

                if ((serviceName != null) && serviceName.equals(Const.HTTPSERVER)) {
                    password = methodInfo.getServerPassword();
                    replyClass = methodInfo.getRtnType();
                } else {
                    password = methodInfo.getPassword();
                    if (directCall) replyClass = methodInfo.getServiceRtnType();
                    else replyClass = methodInfo.getRtnType();
                }

                //try to retrieve the service
                service = retrieveService(serviceName, methodName, password);
            } else {
                service = null;
                if (ModuleHandler.isService(methodInfo.getServiceURI())) {
                    service = (Service) methodInfo.getServiceURI();
                }

                methodName = methodInfo.getName();
                replyClass = methodInfo.getRtnType();
                password = methodInfo.getPassword();
            }

            if (service != null) {

                if (canAccessService(service, methodInfo.getServerPassword())) {
                    canAccess = canAccessMethod(service, methodName, password);

                    //retrieve method if access is allowed
                    if (canAccess) {
                        //get some call settings
                        clientUri = methodInfo.getClientURI();
                        communicationID = methodInfo.getCommunicationID();

                        //create the reflection method and execute
                        theMethod = retrieveMethod(service, methodName, replyClass, methodInfo);
                        if (theMethod != null) {
                            //parse parameters that should be converted
                            for (i = 0; i < indexes.size(); i++) {
                                nextParamObj = Parsers.parseObject(paramObj[indexes.get(i)]);
                                paramObj[indexes.get(i)] = nextParamObj;
                            }

                            //set if remote value
                            if (ModuleHandler.isService(service) && ModuleHandler.isService(parent)) {
                                if (parent.getIsRemoteCall()) {
                                    parent.setIsRemoteCall(false);
                                    ((Service) service).setIsRemoteCall(true);
                                }
                            }

                            //to make sure the communication IDs are used with the same method invocation
                            synchronized (syncOn) {
                                //add communication id for the service, null client translates to anon
                                if (!communicationID.equals(Const.ANON)) {
                                    if (ModuleHandler.isService(service)) {
                                        //only try to add id, may already exist from earlier call in samee mssage invocation
                                        ServiceComm.addCommunicationID(communicationID, clientUri, (Service) service);
                                    } else if (ModuleHandler.isWrapper(service)) {
                                        //only try to add id, may already exist from earlier call in samee mssage invocation
                                        ServiceComm.addCommunicationID(communicationID, clientUri, (ServiceWrapper) service);
                                    }
                                }

                                //only licas service is concerned with method-specific access
                                if (!ModuleHandler.isService(service) ||
                                        ((Service) service).canAccess(password, theMethod)) {
                                    //set the current service path to null so that it is
                                    //updated on the next iteration if part of a sequence
                                    methodInfo.setServiceURI(null);

                                    //then make call
                                    if (methodName.equals(MethodConst.RUN)) {
                                        Monitor.restartThread((Service) service, true);
                                    } else {
                                        try {
                                            //access embedded object or service as appropriate
                                            if (!wrapperMethod && ModuleHandler.isWrapper(service)) {
                                                //legacy wrapper so invoke on wrapper itself
                                                replyObj = ((ServiceWrapperDef) service).invokeObj(theMethod, paramObj);
                                            } else {
                                                replyObj = theMethod.invoke(service, paramObj);
                                            }
                                        } catch (InvocationTargetException itex) {
                                            itex.getTargetException().printStackTrace();
                                            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                                                    "execute", "InvocationTargetException", itex);
                                        } catch (Exception iex) {
                                            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                                                    "execute", null, iex);
                                        }
                                    }

                                    //convert reply if required
                                    if (isRemote && (replyObj != null)) {
                                        if (TypeConst.isSimpleType(replyClass)) {
                                            replyObj = Parsers.createObject(replyClass, String.valueOf(replyObj));
                                        } else {
                                            replyObj = Parsers.serializeToString(replyObj);
                                        }
                                    }
                                } else {
                                    throw new PasswordException("MethodHandler.execute: Incorrect password for service and method: " +
                                            service.getUUID() + ":" + serviceName + ":" + methodName + ":" + password);
                                }
                            }
                        } else {
                            throw new MethodNotFoundException("MethodHandler.execute: Error method not found: " +
                                    service.getUUID() + ":" + serviceName + ":" + methodName);
                        }
                    } else {
                        throw new LicasException("MethodHandler.execute: Access to " +
                                service.getUUID() + ":" + serviceName + ":" + methodName + ":" + password +
                                " is not allowed. The password or settings might be incorrect.");
                    }
                } else {
                    throw new ServiceException("MethodHandler.execute: Service not found or cannot access: " +
                            service.getUUID() + ":" + serviceName);
                }
            } else {
                throw new ServiceNotFoundException("MethodHandler.execute: Service not found: " + serviceName);
            }
        }

        return replyObj;
    }

    /**
     * Try to retrieve the service object from the network.
     * @param serviceName the service name.
     * @param methodName the method name.
     * @param password the service password.
     * @return the retrieved service or null if it cannot be accessed or does not exist.
     * @throws ServiceException any error specific to the service retrieval.
     * @throws java.lang.Exception any other error.
     */
    private ServiceDef retrieveService(String serviceName, String methodName, String password)
            throws ServiceException, Exception
    {
        ServiceDef service;                     //the service reference

        if ((serviceName == null) || serviceName.equals("")) {
            service = parent;
        }
        else if (directCall) {
            if (serviceName.equals(Const.HTTPSERVER) || serviceName.equals(parent.getUUID())) {
                    service = parent;
            }
            else {
                if (parent.isPublicMethod(methodName)) {
                    service = parent.getService(serviceName, ModuleComm.getPassword(parent));
                }
                else {
                    service = parent.getService(serviceName, password);
                }
            }
        }
        else {
            if (serviceName.equals(Const.HTTPSERVER)) {
                service = parent;
            }
            else {
                service = parent.getService(serviceName, tempPassword);
            }
        }

        return service;
    }

    /**
     * Try to retrieve the method from the service.
     * @param service the service that executes the method.
     * @param methodName the method name.
     * @param replyClass the reply type.
     * @param methodInfo the other method info.
     * @return the method that matches the spec or null if none exists.
     * @throws java.lang.Exception any error.
     */
    private Method retrieveMethod(Object service, String methodName, String replyClass, MethodInfo methodInfo)
            throws Exception
    {
        int i, j;
        boolean isMatch;                        //true if a match
        boolean allStrings;                     //true if all strings
        String nextType;                        //next type
        ArrayList<String> paramTypeList;        //parameter types for method info
        ArrayList<Object> newParams;            //new set of parameters
        ArrayList<Method> methods;              //list of accessible methods
        Method theMethod;                       //the method to call
        Method nextMethod;                      //next method to call
        Class[] methodParamTypes;               //parameter types for method
        Class c;                                //the class
        
        isMatch = false;
        theMethod = null;
        nextMethod = null;
        allStrings = true;

        //check if all method info types are declared as strings, for a web server call, for example
        //if this is the case then only the parameter numbers are matched
        //still OK for RPC call, because either all String or Object params to match
        paramTypeList = methodInfo.objParameterTypes();                            
        for (i = 0; allStrings && (i < paramTypeList.size()); i++)
        {
            try {
                nextType = paramTypeList.get(i);
                if (!nextType.equals(TypeConst.STRING)) allStrings = false;
            }
            catch (Exception ex) {
                allStrings = false;
            }
        }
                            
        //if a wrapper then can call on the embedded object or the wrapper itself
        //try to call on the embedded object first and then the wrapper
        if (ModuleHandler.isWrapper(service)) {
            c = ((ServiceWrapperDef)service).getObjClass();

            if (c != null) {
                //if wrapper of service, can then retrieve for modules as well
                //otherwise, do reflection on the object only
                if (service instanceof ServiceWrapper) {
                    methods = ((ServiceWrapper) service).reflectionMethods();
                }
                else {
                    methods = new ArrayList(Arrays.asList(c.getMethods()));
                }

                for (i = 0; !isMatch && (i < methods.size()); i++)
                {
                    theMethod = null;
                    nextMethod = methods.get(i);

                    if (nextMethod.getName().equals(methodName)) {
                        if ((replyClass == null) || replyClass.equals(TypeConst.OBJECT) ||
                            nextMethod.getReturnType().getName().equals(replyClass)) {

                            methodParamTypes = nextMethod.getParameterTypes();
                            paramObj = methodInfo.getParamValues().toArray();
                            
                            if (methodParamTypes.length == paramObj.length) {
                                isMatch = true;
                                if (allStrings) {
                                    //convert parameter types from string to method type
                                    //only simple types should be included
                                    for (j = 0; j < methodParamTypes.length; j++)
                                    {
                                        indexes.add(j);
                                        paramObj[j] = (ObjectHandler.valueFromString(methodParamTypes[j].getName(),
                                            (String)paramObj[j]));
                                    }
                                }
                                else {
                                    for (j = 0; isMatch && (j < methodParamTypes.length); j++)
                                    {
                                        if (!ObjectHandler.classInstance(methodParamTypes[j], paramObj[j])) {
                                            isMatch = false;
                                        }
                                        else if (Parsers.shouldConvert(methodParamTypes[j], paramObj[j])) {
                                            indexes.add(new Integer(j));
                                        }
                                    }
                                    
                                    if (!isMatch) indexes.clear();
                                }
                            }
                        }
                    }
                }
            }
        }

        if (isMatch) {
            //if a match then invoke the selected method
            theMethod = nextMethod;
            wrapperMethod = false;
        }
        else {
            //if no match then check service wrapper itself for a method match
            isMatch = false;
            paramObj = null;
            nextMethod = null;
            wrapperMethod = true;
            
            c = service.getClass();           
            methods = new ArrayList(Arrays.asList(c.getMethods()));

            for (i = 0; !isMatch &&(i < methods.size()); i++)
            {
                theMethod = null;
                nextMethod = methods.get(i);

                if (nextMethod.getName().equals(methodName)) {
                    if ((
                        ((replyClass == null) ||
                                ObjectHandler.toObjectClass(nextMethod.getReturnType().getName()).equals(
                                        ObjectHandler.toObjectClass(replyClass))) &&
                                Handle.isExecuteMethod(methodName)
                        ) ||
                        ((replyClass == null) || replyClass.equals(TypeConst.OBJECT) ||
                                ObjectHandler.toObjectClass(nextMethod.getReturnType().getName()).equals(
                                        ObjectHandler.toObjectClass(replyClass)))
                        ) {
                        
                        methodParamTypes = nextMethod.getParameterTypes();
                        if (!directCall || Handle.isExecuteMethod(methodName)) {
                            allStrings = false;
                            newParams = new ArrayList();
                            newParams.add(methodInfo);
                            newParams.add(Boolean.valueOf(!directCall));
                            paramObj = newParams.toArray();
                        }
                        else {
                            paramObj = methodInfo.getParamValues().toArray();
                        }

                        if (methodParamTypes.length == paramObj.length) {
                            isMatch = true;

                            if (allStrings) {
                                //convert parameter types from string to method type
                                //only simple types should be included
                                for (j = 0; j < methodParamTypes.length; j++)
                                {
                                    try {
                                        indexes.add(j);
                                        paramObj[j] = (ObjectHandler.valueFromString(methodParamTypes[j].getName(),
                                            (String)paramObj[j]));
                                    }
                                    catch (Exception pobex) {}
                                }
                            }
                            else {
                                for (j = 0; isMatch && (j < methodParamTypes.length); j++)
                                {
                                    if (!ObjectHandler.classInstance(methodParamTypes[j], paramObj[j])) {
                                        isMatch = false;
                                    }
                                    else if (Parsers.shouldConvert(methodParamTypes[j], paramObj[j])) {
                                        indexes.add(new Integer(j));
                                    }

                                    if (!isMatch) indexes.clear();
                                }
                            }
                        }
                    }
                }
            }
            
            if (isMatch) theMethod = nextMethod;
        }

        return theMethod;
    }
    
    /**
     * Check if the service can be accessed, that is, it is not blocked.
     * @param service the service that executes the method.
     * @param serverPassword server password, to check locally the API access.
     * @return true if the method can be accessed, false otherwise.
     */
    private boolean canAccessService(ServiceDef service, String serverPassword)
    {
        boolean canAccess;              //true if can access the service
        String serviceUuid;             //the service uuid
        
        serviceUuid = null;
        canAccess = true;

        if (service != null) {
            if (service instanceof ServiceWrapper) {
                serviceUuid = ((ServiceWrapper) service).getUUID();
            }
            else if (service instanceof Service) {
                serviceUuid = ((Service) service).getUUID();
            }
        }

        if ((serviceUuid != null) && LocalServer.getApi(serverPassword).hasServer()) {
            canAccess = !LocalServer.getApi(serverPassword).isBlockedService(serviceUuid);
        }
        
        return canAccess;
    }

    /**
     * Check if the method on the service can be accessed.
     * @param service the service that executes the method.
     * @param methodName the method name.
     * @param password the service password.
     * @return true if the method can be accessed, false otherwise.
     * @throws java.lang.Exception any error.
     */
    private boolean canAccessMethod(Object service, String methodName, String password)
            throws Exception
    {
        boolean canAccess;              //true if can access the service method

        canAccess = false;
        if (directCall) {
            if (service instanceof ESB) {
                canAccess = ((ESB)service).canAccess(password, methodName);
            }
            else if (service instanceof HttpServer) {
                canAccess = ((HttpServer)service).canAccess(password, methodName);
            }
            else if (service instanceof ServiceWrapper) {
                canAccess = ((ServiceWrapper)service).canAccess(password, methodName);
            }
            else if (service instanceof Service) {
                canAccess = ((Service)service).canAccess(password, methodName);
            }
        }
        else {
            canAccess = true;
        }

        return canAccess;
    }
}
