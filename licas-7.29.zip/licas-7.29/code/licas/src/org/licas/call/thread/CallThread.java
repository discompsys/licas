/*
 * CallThread.java
 *
 * Created on 30 June 2015
 *
 * Version 1.5.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.call.thread;


import org.licas.*;
import org.licas.call.*;
import org.licas.call.client.CallHandler;
import org.licas.def.RemoteCallDef;
import org.licas.module.ModuleHandler;
import org.licas.parsers.Parsers;
import org.licas.parsers.types.Base64;
import org.licas.server.LocalServer;
import org.licas.server.model.PacketInfo;
import org.licas.util.*;
import org.licas.util.exception.*;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.io.DataInputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeoutException;


/**
 * This class implements the {@code Callable} interface, to allow execution of
 * the client method on an {@code Executor} thread pool.
 * @author Kieran Greer
 */
public final class CallThread implements Callable
{
    /** The logger */
    private static final Logger logger;
    
    /* The method to execute */
    private final MethodInfo methodInfo;
    
    /** Object to synchronize on */
    private final Object syncOn = new Object();
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(CallThread.class.getName());
        logger.setDebug(false);       
    }
    
    /**
     * Create a new instance of CallThread.
     * @param theMethodInfo the method to execute.
     */
    public CallThread(MethodInfo theMethodInfo)
    {
        methodInfo = theMethodInfo;
    }
    
    /**
     * Class-defined call method. This is invoked by the executor to execute the method.
     * @return the reply object.
     * @throws java.lang.Exception any error.
     */
    public Object call() throws Exception
    {
        int i;
        boolean isOK;                       //true if OK
        String serverPassword;              //the server password
        String replyClass;                  //reply class
        String methodName;                  //method name
        String uuid;                        //uuid of a service
        String commID;                      //communication id
        Element handle;                     //handle path
        Element restOfCall;                 //the rest of the call
        ArrayList<Object> params;           //parameters
        Method theMethod;                   //reflection method
        MethodInfo copyInfo;                //clone of the method info
        Object[] paramObj;                  //params list
        Object component;                   //reference for the component to invoke
        Object replyObj;                    //the reply
        
        copyInfo = (MethodInfo)methodInfo.clone();
        try {
            if (methodInfo == null) throw new LicasException("Error: method to call is null");

            component = methodInfo.getServiceURI();
            serverPassword = methodInfo.getServerPassword();
            replyClass = methodInfo.getServiceRtnType();
            params = methodInfo.getParamValues();
            commID = methodInfo.getCommunicationID();
            methodInfo.setIfRemote();
            replyObj = null;

            if (logger.getDebug())
            {
                LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "call",
                        "call path: " + ObjectHandler.getValue(component));
                
                for (i = 0; i < params.size(); i++)
                {
                    LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "call",
                            "next converted param: " + ObjectHandler.getValue(params.get(i)));
                }
            }

            if (component != null) {
                //check if a string-based path description can be parsed
                if (ObjectHandler.isString(component)) {
                    try {
                        component = XmlHandler.stringToElement((String)component);
                        methodInfo.setServiceURI(component);
                    }
                    catch (Exception ex) {}
                }
            
                //test for component type and try to call
                if (ModuleHandler.isService(component)) {
                    if (((Service)component).isCorrectPassword(methodInfo.getName(), methodInfo.getPassword())) {
                        //to make sure the communication IDs are used with the same method invocation
                        synchronized(syncOn)
                        {
                            isOK = true;                   
                            if (ModuleHandler.isAuto(component) && (commID != null) &&
                                !commID.equals(Const.ANON) && (methodInfo.getClientURI() != null)) {
                                isOK = ServiceComm.addCommunicationID(commID, methodInfo.getClientURI(), (Auto)component);
                            }

                            if (isOK) {
                                //execute the method using reflection
                                if (replyClass.equals(TypeConst.VOID)) {
                                    ((Service)component).execute(methodInfo, false);
                                }
                                else {
                                    replyObj = ((Service)component).execute(methodInfo, false);
                                }
                            }
                            else {
                                throw new ServiceException("Error: could not configure properly, communication id may already exist");
                            }
                        }
                    }
                    else {
                        throw new PasswordException("Error: password does not allow access to the method");
                    }
                }
                else if (ObjectHandler.isElement(component)) {
                    handle = (Element)component;
                    if (methodInfo.getIsRemote() || !LocalServer.hasServer()) {
                        if (logger.getDebug()) LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "call",
                                "handle for remote call initially: " + ObjectHandler.getValue(handle));

                        methodName = Handle.getMethod(handle);
                        if (methodName == null) {
                            handle = Handle.addToHandle(handle, Handle.asMethodElement(methodInfo.getName()));
                            methodInfo.setServiceURI(handle);
                        }

                        //add the remote server password
                        methodInfo.setServerPassword(serverPassword);

                        if (replyClass.equals(TypeConst.VOID)) {
                            executeCall(methodInfo);
                        }
                        else {
                            replyObj = executeCall(methodInfo);
                        }
                    }
                    else {
                        //try to make direct invocation
                        if (Handle.hasURL(handle)) {
                            handle = Handle.removeURL(handle);
                        }

                        if (logger.getDebug()) 
                        {
                            LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "call",
                                    "local handle" + ObjectHandler.getValue(handle));
                        }

                        //is local object
                        if (Handle.hasHandleSeparator(handle)) {
                            uuid = Handle.getFirstServiceHandle(handle);
                            if (uuid.equals(Const.HTTPSERVER)) {
                                restOfCall = Handle.getRestOfCall(handle);
                            }
                            else {
                                restOfCall = handle;
                            }
                        }
                        else {
                            uuid = Handle.getFirstServiceHandle(handle);
                            restOfCall = null;
                        }

                        if (uuid != null) {
                            //this call should be on the ESB only, so only need one invocation attempt
                            //so make second call if first one fails
                            methodName = methodInfo.getName();
                            if (restOfCall != null) {
                                restOfCall = Handle.addToHandle(restOfCall, Handle.asMethodElement(methodName));
                            }
                            else {
                                restOfCall = Handle.addToHandle(handle, Handle.asMethodElement(methodName));
                            }

                            methodInfo.setServiceURI(restOfCall);
                            if (LocalServer.hasServer()) {
                                //execute the method using reflection
                                if (replyClass.equals(TypeConst.VOID)) {
                                    LocalServer.getApi(serverPassword).execute(methodInfo);
                                }
                                else {
                                    replyObj = LocalServer.getApi(serverPassword).execute(methodInfo);
                                }
                            }
                        }
                        else {
                            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "call",
                                null, new LicasException("Handle not properly specified"));
                        }
                    }
                }
                else if (!TypeConst.isSimpleType(component.getClass().getName())) {
                    //try direct reflection invocation on the object
                    //this can include service modules
                    methodName = methodInfo.getName();
                    theMethod = ReflectionHandler.retrieveMethod(component.getClass(), methodName, 
                            replyClass, methodInfo.objParameterTypes());

                    if (theMethod != null) {
                        paramObj = new Object[params.size()];
                        for (i = 0; i < params.size(); i++) paramObj[i] = params.get(i);

                        if (replyClass.equals(TypeConst.VOID)) {
                            theMethod.invoke(component, paramObj);
                        }
                        else {
                            replyObj = theMethod.invoke(component, paramObj);
                        }
                    }
                }
            }
            else {
                if (replyClass.equals(TypeConst.VOID)) {
                    executeCall(methodInfo);
                }
                else {
                    replyObj = executeCall(methodInfo);
                }
            }

            if (!replyClass.equals(TypeConst.VOID)) {
                replyObj = Parsers.parseObject(replyClass, replyObj);
            }
        }
        catch (ServiceNotFoundException exsnf) {
            methodInfo.copyValues(copyInfo);
            throw exsnf;
        }
        catch (ServiceException exs) {
            methodInfo.copyValues(copyInfo);
            throw exs;
        }
        catch (Exception ex) {
            throw ex;
        }
        finally {
            methodInfo.copyValues(copyInfo);
        }

        return replyObj;
    }
    
    /**
     * Determine the best type of execution protocol and invoke the method.
     * @param rMethodInfo description of the method to invoke.
     * @return the method reply.
     * @throws TimeoutException if the call was timed-out.
     * @throws java.lang.Exception any error.
     */
    private Object executeCall(MethodInfo rMethodInfo) throws TimeoutException, Exception
    {
        int packetSize;                     //maximum allowed size of a data packet
        String replyClass;                  //reply class
        RemoteCallDef remoteCommObj;        //remote communication object
        Object reply;                       //the reply
        
        replyClass = rMethodInfo.getServiceRtnType();
        packetSize = rMethodInfo.getPacketSize();
        remoteCommObj = CallHandler.getRemoteCommunicationObject(rMethodInfo);
        reply = null;
       
        if (replyClass.equals(TypeConst.VOID)) {
            if (CallHandler.isXMLRPC(rMethodInfo.getCallType())) {
                if ((packetSize == Const.ONEPACKET) || (packetSize <= 0)) {
                    remoteCommObj.execute(rMethodInfo);
                }
                else {
                    sendInPackets(rMethodInfo);
                }
            }
            else {
                //could be a soap call to a web service, when packets not possible
                remoteCommObj.execute(rMethodInfo);
            }
        }
        else {
            if (CallHandler.isXMLRPC(rMethodInfo.getCallType())) {
                if ((packetSize == Const.ONEPACKET) || (packetSize <= 0)) {
                    reply = remoteCommObj.execute(rMethodInfo);
                }
                else {
                    reply = sendInPackets(rMethodInfo);
                }
            }
            else {
                //could be a soap call to a web service, when packets not possible
                reply = remoteCommObj.execute(rMethodInfo);
            }
        }

        if ((reply != null) && (reply instanceof String)) {
            if (((String) reply).equalsIgnoreCase(TimeoutException.class.getName())) {
                throw new TimeoutException("");
            }
        }
        
        return reply;
    }
    
    /**
     * Write the method to a file and then send it in parts, of size {@link MethodInfo}.{@code packetSize}.
     * @param pMethodInfo the method to invoke.
     * @return the method reply.
     * @throws java.lang.Exception any error.
     */
    private Object sendInPackets(MethodInfo pMethodInfo) throws Exception
    {
        boolean isOK;                                   //true if OK
        int packetSize;                                 //packet size
        int callTimeout;                                //call timeout
        int charsRead;                                  //number of characters read
        byte nextByte;                                  //next byte
        String serverPassword;                          //the server password
        String commID;                                  //communication id
        String replyClass;                              //reply class
        String uri;                                     //server uri
        StringBuilder nextPacket;                       //next packet
        Element handle;                                 //handle path
        PacketInfo packetInfo;                          //packet info
        MethodInfo nextMethodInfo;                      //next method info
        CallObject callObj;                             //call object
        Object reply;                                   //reply to the call
        DataInputStream inputStream;                    //input stream
        
        packetInfo = null;
        inputStream = null;
        reply = null;

        try {
            //serialize to xml and write to file, 
            //then read file parts of packet size and send
            uri = pMethodInfo.getServerURL();
            serverPassword = pMethodInfo.getServerPassword();
            callTimeout = pMethodInfo.getCallTimeout();
            packetSize = pMethodInfo.getPacketSize();
            commID = pMethodInfo.getCommunicationID();
            replyClass = pMethodInfo.getRtnType();
                        
            //call server to indicate and send message in packets
            packetInfo = Parsers.serializeToFile(pMethodInfo);
            inputStream = packetInfo.getInputStream();
            handle = Handle.createNewServerHandle(uri);
            callObj = new CallObject();

            nextMethodInfo = new MethodInfo();
            nextMethodInfo.setName(MethodConst.ADDPACKETCOMMUNICATIONID);
            nextMethodInfo.setRtnType(TypeConst.BOOLEAN);
            nextMethodInfo.setServiceURI(handle);
            nextMethodInfo.setServerPassword(serverPassword);
            nextMethodInfo.setPassword(serverPassword);
            nextMethodInfo.setCallTimeout(callTimeout);
            nextMethodInfo.getParams().add(new ParamInfo(commID));
            nextMethodInfo.getParams().add(new ParamInfo(new Integer(packetSize)));
            isOK = ((Boolean)callObj.call(nextMethodInfo)).booleanValue();

            if (logger.getDebug()) LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "sendInPackets",
                    "CallThread: sent comm id: " + commID);

            if (isOK) {
                if (logger.getDebug()) LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "sendInPackets",
                        "CallThread: sending packets");

                //read file in max packet size and send
                charsRead = inputStream.available();
                while (isOK && (charsRead > 0))
                {
                    charsRead = packetSize;
                    nextPacket = new StringBuilder(String.valueOf(""));

                    while((inputStream.available() > 0) && (charsRead > 0))
                    {
                        try {
                            nextByte = inputStream.readByte();
                            nextPacket.append((char) nextByte);
                            charsRead--;
                        }
                        catch (Exception eofex) {
                            //end of file might occur before the end of the packet size
                            charsRead = -1;
                        }
                    }

                    if (logger.getDebug()) LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "sendInPackets",
                            "CallThread: next packet: " + nextPacket);

                    if (!nextPacket.toString().equals("")) {
                        nextMethodInfo = new MethodInfo();
                        nextMethodInfo.setName(MethodConst.ADDMESSAGEPACKET);
                        nextMethodInfo.setRtnType(TypeConst.BOOLEAN);
                        nextMethodInfo.setServiceURI(handle);
                        nextMethodInfo.setServerPassword(serverPassword);
                        nextMethodInfo.setPassword(serverPassword);
                        nextMethodInfo.setCallTimeout(callTimeout);
                        nextMethodInfo.getParams().add(new ParamInfo(commID));
                        nextMethodInfo.getParams().add(new ParamInfo(Base64.encodeBytes(nextPacket.toString().getBytes())));
                        isOK = (Boolean)callObj.call(nextMethodInfo);

                        if (isOK)
                        {
                            if (logger.getDebug()) LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "sendInPackets",
                                    "CallThread: next packet sent.");

                            charsRead = inputStream.available();
                        }
                    }
                    else {
                        charsRead = -1;
                    }
                }

                //close the stream
                inputStream.close();

                //need to mark the end of the message
                if (isOK) {
                    nextMethodInfo = new MethodInfo();
                    nextMethodInfo.setName(MethodConst.ENDOFMESSAGE);
                    nextMethodInfo.setRtnType(TypeConst.OBJECT);
                    nextMethodInfo.setServiceURI(handle);
                    nextMethodInfo.setServerPassword(serverPassword);
                    nextMethodInfo.setPassword(serverPassword);
                    nextMethodInfo.setCallTimeout(callTimeout);
                    nextMethodInfo.getParams().add(new ParamInfo(commID));

                    if (logger.getDebug()) LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "sendInPackets",
                            "CallThread: end of packets");

                    
                    //execute the method using reflection
                    if (replyClass.equals(TypeConst.VOID)) {
                        callObj.call(nextMethodInfo);
                        reply = null;
                    }
                    else {
                        reply = callObj.call(nextMethodInfo);
                    }
                }
            }
        }
        finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                }
                catch (Exception ex) {}

                try {
                    packetInfo.closeFileChannel();
                }
                catch (Exception ex) {}

                try {
                    packetInfo.deleteFile();
                }
                catch (Exception ex) {}
            }
        }

        return reply;
    }
}
