/*
 * PermanentLink.java
 *
 * Created on 8 December 2008
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.link;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class stores information about a service's permanent links list. These are 
 * links from one source to another that are specified once and are permanent until 
 * they are specifically removed.
 * @author Kieran Greer
 */
public class PermanentLink 
{
    /** 
     * Permanent links from this service to other ones. 
     * The keys are the source ids of type String and values are the source
     * references of type Object. Can be a direct reference or a String/Element URI path.
     */
    protected HashMap<String, Object> linksToService;
    
    /** 
     * Permanent links from other services to this one. 
     * The keys are the source ids of type String and values are the source
     * references of type Object. Can be a direct reference or a String/Element URI path.
     */
    protected HashMap<String, Object> linksFromService;
    
    /**
     * Create a new instance of PermanentLink
     */
    public PermanentLink()
    {
        linksToService = new HashMap<>();
        linksFromService = new HashMap<>();
    }
    
    /**
     * Add a link to another service.
     * @param serviceID a unique id to identify the service.
     * @param theReference the source reference (Object or Element/String URI).
     * @return true if the link is added or false if the id already exists.
     */
    public boolean addLinkToService(String serviceID, Object theReference)
    {
        if (!linksToService.containsKey(serviceID)) {
            linksToService.put(serviceID, theReference);
            return true;
        }
        
        return false;
    }
    
    /**
     * Remove the link to the specified service if it exists.
     * @param serviceID the id of the service being linked to.
     */
    public void removeLinkToService(String serviceID)
    {
        linksToService.remove(serviceID);
    }
    
    /**
     * Get the source reference for a link to another service.
     * @param serviceID the id of the service linked to.
     * @return the value of source or null if no link exists.
     */
    public Object getLinkToService(String serviceID)
    {
        Object reference = null;                    //source reference
        
        if (linksToService.containsKey(serviceID)) {
            reference = linksToService.get(serviceID);
        }
        
        return reference;
    }

    /**
     * Get the ID list for all links to another service.
     * @return a list of all ID references of links to other services.
     */
    public ArrayList<String> getAllLinkToServiceIDs()
    {
        ArrayList<String> allLinks;             //list of links

        allLinks = new ArrayList<>();
        if (!linksToService.isEmpty()) {
            allLinks = new ArrayList(linksToService.keySet());
        }

        return allLinks;
    }

    /**
     * Get all source references for all links to another service.
     * @return a list of all sources references of links to other services.
     */
    public ArrayList<Object> getAllLinkToService()
    {
        ArrayList<Object> allLinks;             //list of links

        allLinks = new ArrayList<>();
        if (!linksToService.isEmpty()) {
            allLinks = new ArrayList(linksToService.values());
        }
        
        return allLinks;
    }
    
    /**
     * Add a link from another service.
     * @param serviceID a unique id to identify the service.
     * @param theReference the source reference (Object or Element/String URI).
     * @return true if the link is added or false if the id already exists.
     */
    public boolean addLinkFromService(String serviceID, Object theReference)
    {
        if (!linksFromService.containsKey(serviceID)) {
            linksFromService.put(serviceID, theReference);
            return true;
        }
        
        return false;
    }
    
    /**
     * Remove the link from the specified service if it exists.
     * @param serviceID the id of the service being linked to.
     */
    public void removeLinkFromService(String serviceID)
    {
        linksFromService.remove(serviceID);
    }
    
    /**
     * Get the source reference for a link from another service.
     * @param serviceID the id of the service linked to.
     * @return the value of source or null if no link exists.
     */
    public Object getLinkFromService(String serviceID)
    {
        Object reference = null;                //source reference
        
        if (linksFromService.containsKey(serviceID)) {
            reference = linksFromService.get(serviceID);
        }
        
        return reference;
    }

    /**
     * Get the ID list for all links from other services.
     * @return a list of all ID references of links from other services.
     */
    public ArrayList<String> getAllLinkFromServiceIDs()
    {
        ArrayList<String> allLinks;             //list of links

        allLinks = new ArrayList<>();
        if (!linksFromService.isEmpty()) {
            allLinks = new ArrayList(linksFromService.keySet());
        }

        return allLinks;
    }

    /**
     * Get all source references for all links from another service.
     * @return a list of all sources references of links from other services.
     */
    public ArrayList<Object> getAllLinkFromService()
    {
        ArrayList<Object> allLinks;             //list of links

        allLinks = new ArrayList<>();
        if (!linksFromService.isEmpty()) {
            allLinks = new ArrayList(linksFromService.values());
        }
        
        return allLinks;
    }
}
