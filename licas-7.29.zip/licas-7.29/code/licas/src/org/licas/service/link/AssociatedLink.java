/*
 * AssociatedLink.java
 *
 * Created on 24 October 2025
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.link;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class stores information about a service's associated links list. These are
 * links from one source to another that have any association, and not of the structural types.
 * @author Kieran Greer
 */
public class AssociatedLink
{
    /**
     * Associated links.
     * The keys are the source ids of type String and values are the source
     * references of type Object. Can be a direct reference or a String/Element URI path.
     */
    protected HashMap<String, Object> associatedLinks;

    /**
     * Create a new instance of AssociatedLink.
     */
    public AssociatedLink()
    {
        associatedLinks = new HashMap<>();
    }

    /**
     * Add a link to some object/reference.
     * @param serviceID a unique id to identify the service.
     * @param theReference the source reference (Object or Element/String URI).
     * @return true if the link is added or false if the id already exists.
     */
    public boolean addLink(String serviceID, Object theReference)
    {
        if (!associatedLinks.containsKey(serviceID)) {
            associatedLinks.put(serviceID, theReference);
            return true;
        }
        
        return false;
    }
    
    /**
     * Remove the link if it exists.
     * @param linkID the id of the link being linked to.
     */
    public void removeLink(String linkID)
    {
        associatedLinks.remove(linkID);
    }
    
    /**
     * Get the source reference for a link.
     * @param linkID the id of the link.
     * @return the value of source or null if no link exists.
     */
    public Object getLink(String linkID)
    {
        Object reference = null;                    //source reference
        
        if (associatedLinks.containsKey(linkID)) {
            reference = associatedLinks.get(linkID);
        }
        
        return reference;
    }

    /**
     * Get the ID list for all linkss.
     * @return a list of all ID references of links.
     */
    public ArrayList<String> getAllLinkIDs()
    {
        ArrayList<String> allLinks;             //list of links

        allLinks = new ArrayList<>();
        if (!associatedLinks.isEmpty()) {
            allLinks = new ArrayList(associatedLinks.keySet());
        }

        return allLinks;
    }

    /**
     * Get all source references for all links.
     * @return a list of all sources references of links.
     */
    public ArrayList<Object> getAllLinks()
    {
        ArrayList<Object> allLinks;             //list of links

        allLinks = new ArrayList<>();
        if (!associatedLinks.isEmpty()) {
            allLinks = new ArrayList(associatedLinks.values());
        }
        
        return allLinks;
    }

    /**
     * Get the full associated links structure.
     * @return the value of associatedLinks.
     */
    public HashMap<String, Object> getLinks() {
        return associatedLinks;
    }
}
