/*
 * InformationMediator.java
 *
 * Created on 6 June 2011
 *
 * Version 1.8
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.FileLoader;
import org.jlog2.util.UuidHandler;
import org.licas.PasswordHandler;
import org.licas.call.*;
import org.licas.meta.MetaFactory;
import org.licas.server.model.BusEntity;
import org.licas.service.spec.QueryUpdate;
import org.licas.service.spec.ServiceSpec;
import org.licas.util.*;
import org.licas.util.exception.LicasException;
import org.licas.util.exception.ServiceException;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.*;


/**
 * This class can be used to mediate between the information services that are created,
 * the information sources and any related centralised problem solver. A service can be 
 * created by itself, or initialised with an information source. The service then runs 
 * on the network and communicates with the problem solver classes through the licas framework.
 * @author Kieran Greer
 */
public class InformationMediator extends ServiceMediator
{
    /** The logger */
    private static final Logger logger;

    
    /** The source info urls */
    protected ArrayList<String> sourceURLs;
    
    /** Retrieved data from each source */
    protected ArrayList<String> sourceData;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(InformationMediator.class.getName());
        logger.setDebug(false);
    }
    
    
    /**
     * Create a new instance of InformationMediator.
     * @param thePasswordHandler the password handler.
     * @throws java.lang.Exception any error.
     */
    public InformationMediator(PasswordHandler thePasswordHandler) throws Exception
    {
        super(thePasswordHandler);
        initialise();
    }

    /**
     * Creates a new instance of InformationMediator.
     * @param thisPassword the component password.
     * @param thisAdminKey the unique service key.
     * @param thePasswordHandler the password handler.
     * @throws java.lang.Exception any error.
     */
    public InformationMediator(String thisPassword, String thisAdminKey,
            PasswordHandler thePasswordHandler) throws Exception
    {
        super(thisPassword, thisAdminKey, thePasswordHandler);
        initialise();
    }
    
    /**
     * Initialise some values.
     */
    private void initialise()
    {
        serviceSpec = null;
        sourceURLs = new ArrayList<>();
        sourceData = new ArrayList<>();
    }
    
    /**
     * Initialise the information mediator with the server details. Also clear the 
     * network of any existing services and the password handler for this service.
     * @param theServiceSpec the service spec or test script, with all of the config details.
     * @return true if initialised OK, false otherwise. Most likely, it would be
     * missing server initialisation information.
     * @throws java.lang.Exception any error.
     */
    public boolean initialiseServerInfo(ServiceSpec theServiceSpec) throws Exception
    {
        MethodInfo methodInfo;                          //method info
        CallObject callObject;                          //call object
        
        try {
            initialiseInfo(theServiceSpec);
            
            callObject = new CallObject();
            methodInfo = new MethodInfo();
            methodInfo.setName(MethodConst.CLEARNETWORK);
            methodInfo.setRtnType(TypeConst.VOID);
            methodInfo.setServiceURI(serverUri);
            methodInfo.setServerPassword(passwordHandler.getServicePassword(serverUri));
            methodInfo.setPassword(passwordHandler.getServicePassword(serverUri));
            methodInfo.addParam(new ParamInfo(passwordHandler.getAdminKey(serverUri)));
            callObject.call(methodInfo);

            return true;          
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, 
                    "initialiseServerInfo", null, ex);
        }
    }
    
    /**
     * Initialise the services, primarily adding and initialising linking 
     * structures if they are included. The initialisation could be application
     * specific and so it is done in each version of this class.
     * @param serviceType the type of service to initialise.
     * @throws java.lang.Exception any error.
     */
    public void initialiseServices(String serviceType) throws Exception 
    {
        int i;
        boolean isOK;                               //true if OK
        String serviceUuid;                         //service uuid
        String thisServiceType;                     //this service type
        String serverUriStr;                        //server uri as a string
        Element serviceUri;                         //service uri
        ArrayList<String> serviceUuids;             //list of service uuids
        ArrayList<String> serviceTypes;             //service types
        Callable callableTask;                      //callable method
        ScheduledExecutorService scheduler;         //thread scheduler
        ArrayList<Object> params;                   //parameters list
        MethodInfo methodInfo;                      //method info
        CallObject callObject;                      //call object
        Object replyObj;                            //reply object

        try {
            callObject = new CallObject();
            thisServiceType = serviceType;
            serverUriStr = XmlHandler.xmlToString(serverUri);
            isOK = true;

            //retrieve the information services
            params = new ArrayList<>();
            serviceTypes = new ArrayList<>();
            serviceTypes.add(thisServiceType);
            params.add(serviceTypes);
                
            methodInfo = MethodFactory.createMethodCall(MethodConst.GETSERVICENAMES, TypeConst.ARRAYLIST, 
                    serverUri, params, passwordHandler);
            replyObj = callObject.call(methodInfo);

            if (replyObj != null) {
                serviceUuids = (ArrayList) replyObj;

                //add linker services if included
                if (serviceSpec.linkSpec.linkMethod != null) {
                    for (i = 0; isOK && (i < serviceUuids.size()); i++) {
                        serviceUuid = serviceUuids.get(i);
                        serviceUri = Handle.createNewUrlHandle(serverIP);
                        serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceUuid));

                        params = new ArrayList<>();
                        params.add(ServiceConst.LINKER);
                        params.add(passwordHandler.getAdminKey(serviceUuid));

                        methodInfo = MethodFactory.createMethodCall(MethodConst.ADDDEFAULTSERVICE, TypeConst.BOOLEAN,
                                serviceUri, params, passwordHandler);
                        replyObj = callObject.call(methodInfo);

                        if (replyObj != null) {
                            isOK = ((Boolean) replyObj).booleanValue();
                            if (isOK) {
                                serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(ServiceConst.LINKER));

                                methodInfo = new MethodInfo();
                                methodInfo.setName(MethodConst.SETTHRESHOLDS);
                                methodInfo.setRtnType(TypeConst.VOID);
                                methodInfo.setServiceURI(serviceUri);
                                methodInfo.setServerPassword(passwordHandler.getServicePassword(serverUriStr));
                                methodInfo.setPassword(passwordHandler.getServicePassword(serviceUuid));
                                methodInfo.addParam(new ParamInfo(serviceSpec.linkSpec));
                                callObject.call(methodInfo);
                            }
                        } else {
                            isOK = false;
                        }
                    }
                }
            }
            else {
                isOK = false;
            }

            if (isOK) {
                //start service threads if specified
                if (serviceSpec.serverSpec.startThreads) {
                    scheduler = Executors.newSingleThreadScheduledExecutor();
                    callableTask = () -> {
                        startServices(thisServiceType);
                        return null;
                    };

                    Future future = scheduler.schedule(callableTask, ServiceConst.INITSLEEP, TimeUnit.MILLISECONDS);
                    future.get();
                }
            }
            else {
                throw new ServiceException("There was an error initialising the services. It could be configuration or the server address, for example.");
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, 
                    "initialiseServices", "", ex);
        }
    }
        
    /**
     * Create an information service for each of the listed sources and initiate each
     * one with the source information.
     * @param serviceType the type to assign to each main or base service.
     * @throws java.lang.Exception any error.
     */
    public void createServices(String serviceType) throws Exception
    {
        int i;
        boolean isOK;                                   //true if OK
        String serviceUuid;                             //service uuid
        String serviceClass;                            //service class
        String servicePassword;                         //service password
        String adminKey;                                //service key
        String nextURL;                                 //next url
        String serverUriStr;                            //server uri as a string
        Element serviceUri;                             //service uri
        Element adminXml;                               //admin XML
        Element otherXml;                               //other XML
        Element nextElem;                               //next element
        ArrayList<String> jarFiles;                     //list of jar files
        ArrayList<Object> params;                       //parameters
        Object conParam;                                //constructor parameter
        Object[] fileParam;                             //file parameter
        MethodInfo methodInfo;                          //method info
        CallObject callObject;                          //call object
        
        try {
            callObject = new CallObject();
            serverUriStr = XmlHandler.xmlToString(serverUri);            
                
            for (i = 0; i < sourceURLs.size(); i++)
            {
                nextURL = sourceURLs.get(i);
                
                //try to create the uuid from the file or url path
                //if not then use a random uuid
                serviceUuid = UriHandler.getFileName(nextURL);
                if (serviceUuid == null) {
                    serviceUuid = (ServiceConst.IINDEX + "_" + 
                        UuidHandler.getUuid(3, System.currentTimeMillis()));               
                }
                
                //admin document construction
                if (serviceSpec.constructorParams.size() > 0) {
                    servicePassword = (String)serviceSpec.constructorParams.get(0);
                    if (serviceSpec.constructorParams.size() > 1)
                        adminKey = (String)serviceSpec.constructorParams.get(1);
                    else
                        adminKey = UuidHandler.getUuid(10, System.currentTimeMillis());
                }
                else {
                    servicePassword = UuidHandler.getUuid(10, System.currentTimeMillis());
                    adminKey = UuidHandler.getUuid(10, System.currentTimeMillis());
                }

                if (serviceSpec.constructorParams.size() > 2) {
                    conParam = serviceSpec.constructorParams.get(2);
                    if (conParam instanceof Object[]) {
                        fileParam = (Object[])conParam;
                        if ((fileParam.length > 1) && (fileParam[1] instanceof Element)) {
                            adminXml = (Element)fileParam[1];
                        }
                        else {
                            conParam = fileParam[0];
                            adminXml = XmlHandler.stringToElement(FileLoader.getInputStream((String)conParam));
                        }
                    }
                    else {
                        adminXml = (Element)conParam;
                    }
                }
                else {
                    adminXml = MetaFactory.createAdmin();
                }
                
                passwordHandler.addServicePassword(serviceUuid, servicePassword);
                passwordHandler.addAdminKey(serviceUuid, adminKey);
                
                //check for external script and add
                if (serviceSpec.externalScript != null) {
                    otherXml = adminXml.getChild(Const.OTHERMETA);
                    if (otherXml == null) {
                        otherXml = XMLFactory.getInstance().createElement(Const.OTHERMETA);
                        adminXml.addContent(otherXml);
                    }
                    
                    nextElem = XMLFactory.getInstance().createElement(Const.OTHERSCRIPT);
                    nextElem.setText(serviceSpec.externalScript);
                    otherXml.addContent(nextElem);
                }
                
                //parameters for service itself
                params = new ArrayList<>();
                params.add(servicePassword);
                params.add(adminKey);
                if ((adminXml != null) && adminXml.hasChildren()) params.add(adminXml);                      
                serviceClass = (String)serviceSpec.serviceClasses.get(ServiceConst.INFORMATION);
                jarFiles = (ArrayList)serviceSpec.serviceJarFiles.get(ServiceConst.INFORMATION);

                //add new information service
                methodInfo = new MethodInfo();
                methodInfo.setName(MethodConst.ADDSERVICE);
                methodInfo.setRtnType(TypeConst.BOOLEAN);
                methodInfo.setServiceURI(serverUri);
                methodInfo.setServerPassword(passwordHandler.getServicePassword(serverUriStr));
                methodInfo.setPassword(passwordHandler.getServicePassword(serverUriStr));
                methodInfo.addParam(new ParamInfo(passwordHandler.getServicePassword(serverUriStr)));
                methodInfo.addParam(new ParamInfo(serviceUuid));
                methodInfo.addParam(new ParamInfo(serviceType));
                methodInfo.addParam(new ParamInfo(jarFiles));
                methodInfo.addParam(new ParamInfo(serviceClass));
                methodInfo.addParam(new ParamInfo(params));
                isOK = ((Boolean)callObject.call(methodInfo)).booleanValue();
                
                if (isOK) {
                    passwordHandler.addServicePassword(serviceUuid, servicePassword);
                    passwordHandler.addAdminKey(serviceUuid, adminKey);
                    
                    //load the data onto the information service
                    serviceUri = Handle.createNewUrlHandle(serverIP);
                    serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceUuid));

                    methodInfo = new MethodInfo();
                    methodInfo.setName(MethodConst.LOADDATACONTENTS);
                    methodInfo.setRtnType(TypeConst.VOID);
                    methodInfo.setServiceURI(serviceUri);
                    methodInfo.setServerPassword(passwordHandler.getServicePassword(serverUriStr));
                    methodInfo.setPassword(passwordHandler.getServicePassword(serviceUuid));
                    methodInfo.addParam(new ParamInfo(nextURL));
                    callObject.call(methodInfo);
                }
                else {
                    throw new LicasException("Service " + serviceUuid + " could not be loaded.");
                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "createInformationServices",
                null, ex);
        }
    }
    
    /**
     * Apply a set of query update options to the list of services returned
     * by the query result.
     * @param queryUpdate a description of the update process and links.
     * @throws java.lang.Exception any error.
     */
    public void updateQueryInfo(QueryUpdate queryUpdate) throws Exception
    {
        HashMap[] sortedServices;                 //sorted services list
        
        sortedServices = sortGroupsForEach(queryUpdate);
        
        //use sorted list for updating based on the query results
        if (queryUpdate.localUpdates.contains(Const.DYNTOPERMLINKS) &&
            queryUpdate.remoteUpdates.contains(Const.DYNLINKS)) {
            updateDynamicLinks(sortedServices[0], true);
        }
        else {
            if (queryUpdate.localUpdates.contains(Const.PERMLINKS)) {
                createPermanentLinks(sortedServices[0]);
            }
            if (queryUpdate.localUpdates.contains(Const.DYNTOPERMLINKS)) {
                updateDynamicLinks(sortedServices[0], true);
            }
            if (queryUpdate.remoteUpdates.contains(Const.DYNLINKS)) {
                updateDynamicLinks(sortedServices[1], false);
            }
            if (queryUpdate.remoteUpdates.contains(Const.ASSOCLINKS)) {
                createAssociationLinks(sortedServices[1]);
            }
        }
    }
    
    /**
     * Re-sort the service list for using to update links or other based on the
     * specification of the update model.
     * @param queryUpdate an update spec with separate local or remote update
     * possibilities.
     * @return the same lists sorted for creating links.
     * For this implementation, the key in the hashtable is an entity name and 
     * the value is a list of all other entity ids. For compatibility, need to
     * group the list inside of another one, with only that single element.
     * For example: key: http://a1, value: [http://b1, http://c1, http://d1, http://e1, etc].
     */
    protected HashMap[] sortGroupsForEach(QueryUpdate queryUpdate)
    {
        int i, j;
        String keyValue;                                                //key value
        String nextValue;                                               //next value
        ArrayList<String> sortKeys;                                     //key values list
        ArrayList<String> sortValues;                                   //sort values list
        ArrayList<String> valueList;                                    //value list
        ArrayList<ArrayList<String>> groupList;                         //group list
        HashMap<String, ArrayList<ArrayList<String>>>[] groupForEntity; //group for each entity
        
        if ((queryUpdate.localUpdates.contains(Const.DYNTOPERMLINKS) &&
            !queryUpdate.localURIs.isEmpty()) &&
            (queryUpdate.remoteUpdates.contains(Const.DYNLINKS) &&
            !queryUpdate.remoteURIs.isEmpty())) {
            groupForEntity = new HashMap[1];
            groupForEntity[0] = new HashMap();
        
            sortKeys = (ArrayList)queryUpdate.localURIs.clone();
            sortValues = (ArrayList)queryUpdate.localURIs.clone();
            sortValues.addAll(queryUpdate.remoteURIs);
            
            for (i = 0; i < sortKeys.size(); i++)
            {
                keyValue = sortKeys.get(i);
                valueList = new ArrayList<>();

                for (j = 0; j < sortValues.size(); j++)
                {
                    nextValue = sortValues.get(j);
                    if (!keyValue.equals(nextValue)) {
                        valueList.add(nextValue);
                    }
                }

                groupList = new ArrayList<>();
                groupList.add(valueList);
                groupForEntity[0].put(keyValue, groupList);
            }
        }
        else {
            groupForEntity = new HashMap[2];
            groupForEntity[0] = new HashMap<>();
            groupForEntity[1] = new HashMap<>();
        
            //sort local and remote separately
            if (!queryUpdate.localURIs.isEmpty()) {
                sortKeys = (ArrayList)queryUpdate.localURIs.clone();
                sortValues = (ArrayList)queryUpdate.localURIs.clone();

                for (i = 0; i < sortKeys.size(); i++)
                {
                    keyValue = sortKeys.get(i);
                    valueList = new ArrayList<>();

                    for (j = 0; j < sortValues.size(); j++)
                    {
                        nextValue = sortValues.get(j);
                        if (!keyValue.equals(nextValue)) {
                            valueList.add(nextValue);
                        }
                    }

                    groupList = new ArrayList<>();
                    groupList.add(valueList);
                    groupForEntity[0].put(keyValue, groupList);
                }
            
                if (!queryUpdate.remoteURIs.isEmpty()) {
                    sortKeys = (ArrayList)queryUpdate.localURIs.clone();
                    sortValues = (ArrayList)queryUpdate.remoteURIs.clone();

                    for (i = 0; i < sortKeys.size(); i++)
                    {
                        keyValue = sortKeys.get(i);
                        valueList = new ArrayList<>();

                        for (j = 0; j < sortValues.size(); j++)
                        {
                            nextValue = sortValues.get(j);
                            if (!keyValue.equals(nextValue)) {
                                valueList.add(nextValue);
                            }
                        }

                        groupList = new ArrayList<>();
                        groupList.add(valueList);
                        groupForEntity[1].put(keyValue, groupList);
                    }
                }
            }
        }
        
        return groupForEntity;
    }
}
