/*
 * HM_SingleLink.java
 *
 * Created on 3 July 2013
 *
 * Version 1.5.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module.h_module.cluster;


import org.ai_heuristic.functs.FunctionMetric;
import org.ai_heuristic.algo.cluster.link.SingleLinkCluster;
import org.ai_heuristic.eval.metric.*;
import org.ai_heuristic.functs.metric.EuclideanDistance;
import org.licas.data.DataQueryModel;
import org.licas.module.h_module.HM_Cluster;
import org.licas.service.sci.SolverMetrics;
import org.licas.util.*;
import org.licas_xml.abs.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;

import java.util.*;


/**
 * Provides one implementation of a clustering process. This class can be used to evaluate two values
 * of a simple type (int, float, string) and records the closest distance. The parent service can then
 * use this to create a permanent link between itself and the service that the matching dataset belongs to.
 * <p>
 * If there is no overlap in the datasets, a zero result is returned, meaning that
 * no clustering is possible. A {@code Euclidean} distance metric is used to measure closeness.
 * This service then tries to link its parent service with all other ones that are part 
 * of the linked set, or cluster group.
 * @author Kieran Greer
 */
public class HM_SingleLink extends HM_Cluster
{
    /** The logger */
    private static final Logger logger;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(HM_SingleLink.class.getName());
        logger.setDebug(false);
    }

    /**
     * Create a new instance of HM_SingleLink.
     * @throws java.lang.Exception any error.
     */
    public HM_SingleLink() throws Exception
    {
        super();
    }

    /**
     * Create a new instance of HM_SingleLink.
     * @param adminXml configuration parameters, including metric type and setup.
     * @throws java.lang.Exception any error.
     */
    public HM_SingleLink(Element adminXml) throws Exception
    {
        super(adminXml);
    }

    /**
     * Evaluate the data.
     * @param dataInfo initialisation dataInfo for the evaluator.
     * @return the evaluation reply.
     * @throws java.lang.Exception and error.
     */
    public Element evaluate(DataQueryModel dataInfo) throws Exception
    {
        int i;
        int isLinked;                               //return linked value
        int bestIndex;                              //best matching index
        Object bestValue;                           //best value
        String metricType;                          //the metric type
        String nextKey;                             //next key
        String serviceID;                           //service id
        ArrayList<String> serviceIDs;               //list of all service ids
        ArrayList<String> allKeys;                  //all keys
        ArrayList<String> datasetsToUse;            //dataset to use list
        HashMap<String, MetricDataset> nextData;    //next data
        Element dataElem;                           //evaluation element
        Element reply;                              //the reply
        MetricDataset serviceDataset;               //service dataset
        MetricValue serviceValue;                   //service value
        SingleLinkCluster linkCluster;              //single link cluster

        try
        {
            reply = null;

            //recieve datasets from the controlling behaviour
            //when get repeat in dataset means all recieved, so can then evaluate the data
            if ((allData == null) || allData.isEmpty()) {
                allData = (HashMap)dataInfo.getParams().get(Const.DATASETS);
            }
            else {
                serviceIDs = new ArrayList(allData.keySet());
                nextData = (HashMap) dataInfo.getParams().get(Const.DATASETS);

                allKeys = new ArrayList(nextData.keySet());
                for (i = 0; i < allKeys.size(); i++) {
                    nextKey = allKeys.get(i);
                    if (!allData.containsKey(nextKey)) {
                        allData.put(nextKey, nextData.get(nextKey));
                    }
                }

                allKeys = new ArrayList(allData.keySet());
                if (serviceIDs.size() == allKeys.size()) {
                    if (!allData.isEmpty()) {
                        //create and run the clustering algorithm
                        serviceValue = MetricValue.toValue(service.getUUID(), dataInfo.getDataType(), dataInfo.getDataset());
                        serviceDataset = MetricDataset.toDataset(service.getUUID(), dataInfo.getDataType(), serviceValue);

                        if (evalMetric == null) {
                            metricType = getMetricType();
                            if (metricType != null) {
                                evalMetric = (new SolverMetrics()).getEvaluationFunction(dataInfo.getDataType(),
                                        metricType);
                            }
                            else {
                                evalMetric = new EuclideanDistance(dataInfo.getDataType());
                            }
                        }

                        //use AI clustering algorithm to measure the closest distance
                        datasetsToUse = (ArrayList) (new ArrayList(allData.values())).clone();
                        linkCluster = new SingleLinkCluster(dataInfo.getDataType(), (FunctionMetric) evalMetric);
                        linkCluster.setDataset(serviceDataset);
                        bestIndex = ((Integer) linkCluster.evaluate(MetricDataset.toDataset(dataInfo.getDataType(), datasetsToUse)).getValue()).intValue();

                        //return the result
                        if (bestIndex >= 0) {
                            serviceID = (String) serviceIDs.get(bestIndex);
                            try {
                                isLinked = alreadyLinkedTo(serviceID);

                                //check that a link as part of the cluster does not already exist
                                //if service not yet installed, return null but keep the service id
                                if (isLinked != -1) {
                                    //if dynamic links then add to, even if already linked to
                                    bestValue = linkCluster.getBestEvaluation();

                                    dataElem = XMLFactory.getInstance().createElement(Const.DATASET);
                                    dataElem.setAttribute(Const.SERVICE, serviceID);
                                    dataElem.setAttribute(Const.DATATYPE, dataInfo.getDataType());
                                    dataElem.setText(String.valueOf(bestValue));

                                    reply = XMLFactory.getInstance().createElement(Const.RESULT);
                                    reply.addContent(dataElem);
                                }
                            }
                            finally {
                                allData.clear();
                            }
                        }
                    }
                    else {
                        reply = XMLFactory.getInstance().createElement(AiConst.TESTENDED);
                        resetValues();
                    }
                }
            }
            
            return reply;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "evaluate", null, ex);
        }
    }
}
