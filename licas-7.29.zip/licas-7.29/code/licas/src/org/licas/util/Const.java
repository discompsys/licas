/*
 * Const.java
 *
 * Created on 12 December 2006.
 *
 * Version 1.31.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util;


import java.io.File;


/**
 * Some constant values relating to the licas library.
 * @author Kieran Greer
 */
public class Const 
{ 
    /** Operating system type. This will change file paths before compilation. */
    private static final String OS;
    
    /** Windows operating system type. */
    public static final String WINDOWS = "win";
    
    /** Apple Mac operating system type. */
    public static final String MAC = "mac";
    
    /** Linux operating system type. */
    public static final String LINUX = "linux";
    
    /** Android operating system type. */
    public static final String ANDROID = "android";
    
    /** Defines a jar file prefix */
    public static final String JARFILEURI;
    
    /** Defines a file uri prefix */
    public static final String FILEURIPREFIX;
    
    /** The directory separator character */
    public static final String DIRSEP;
    
    /** The array element separator character */
    public static final String ARRAYSEP;
       
    static
    {
        DIRSEP = File.separator;
        ARRAYSEP = "|";
        
        if (System.getProperty("type.os") == null)
        {
            System.setProperty("type.os", WINDOWS);
        }

        OS = System.getProperty("type.os");
        if (OS.equals(MAC) || OS.equals(LINUX))
        {
            JARFILEURI = "file:";        
            FILEURIPREFIX = "file://";
        }
        else
        {
            JARFILEURI = "file:/";        
            FILEURIPREFIX = "file://localhost/";
        }
    }
    
    /** Defines the ESB component UUID */
    public static final String HTTPSERVER = "HttpServer";
    
    /** Servers tag */
    public static final String SERVERS = "Servers";
    
    /** Server tag */
    public static final String SERVER = "Server";
    
    /** Server contact tag */
    public static final String SERVERCONTACT = "Server_Contact";
    
    /** Defines the server id for display */
    public static final String SERVERID = "Server";
    
    /** Defines a port number tag name */
    public static final String PORT = "Port";
    
    /** Defines a component's name */
    public static final String NAME = "Name";

    /** This defines the sources tag */
    public static final String SOURCES = "Sources";

    /** This defines the source value tag */
    public static final String SOURCE = "Source";

    /** Defines a path parameter type */
    public static final String PATH = "Path";
    
    /** Defines a concepts tag */
    public static final String CONCEPTS = "Concepts";
    
    /** Defines a concept tag */
    public static final String CONCEPT = "Concept";

    /** Defines a language tag */
    public static final String LANGUAGE = "Language";
    
    /** Defines a component's keywords */
    public static final String KEYWORDS = "Keywords";

    /** Defines keyword tag */
    public static final String KEYWORD = "Keyword";
    
    /** Defines keyword tag */
    public static final String KEYWORDINFO = "Keyword_Info";
    
    /** Defines a component's keyword */
    public static final String KEY = "Key";
    
    /** Defines a component's type */
    public static final String TYPE = "Type";
    
    /** Defines a component's category */
    public static final String CATEGORY = "Category";
    
    /** Defines a data type */
    public static final String DATATYPE = "DataType";
    
    /** Defines a resource type */
    public static final String RESOURCETYPE = "ResourceType";
    
    /** Defines a conversion type shorthand */
    public static final String CONVERSIONTYPE = "C";
    
    /** Defines a component's value shorthand */
    public static final String VALUES = "Vs";
    
    /** Defines a component's value */
    public static final String VALUE = "Value";
    
    /** Defines parameter nodes */
    public static final String PARAMETERS = "Params";
    
    /** Defines a parameter type node */
    public static final String PARAMETER = "Param";
    
    /** Defines a WSDL parameter type node */
    public static final String WSDLPARAMETER = "wParam";
    
    /** Defines a child elements type node */
    public static final String CHILDELEMENTS = "Child_Elements";
    
    /** Defines an anonymous password */
    public static final String ANON = "anon";
    
    /** Defines all services */
    public static final String ALLSERVICES = "All Services";
    
    /** Defines a service wrapper */
    public static final String SERVICEWRAPPER = "ServiceWrapper";
    
    /** Defines a auto wrapper */
    public static final String AUTOWRAPPER = "AutoWrapper";
    
    /** Defines a thresholds element */
    public static final String THRESHOLDS = "Thresholds";

    /** The Links tag */
    public static final String LINKS = "Links";

    /** Dynamic link tag */
    public static final String DYNAMICLINKS = "Dynamic_Links";

    /** Dynamic link tag */
    public static final String PERMANENTLINKS = "Permanent_Links";

    /** Defines the association links tag name */
    public static final String ASSOCIATEDLINKS = "Associated_Links";

    /** Defines a link element */
    public static final String LINK = "Link";
    
    /** Defines a next link element */
    public static final String NEXTLINK = "Next_Link";
    
    /** Defines a link key element */
    public static final String LINKKEY = "Link_Key";
    
    /** Defines a link value element */
    public static final String LINKVALUE = "Link_Value";
    
    /** Defines the dynamic link query config */
    public static final String LINKQUERY = "Link_Query";
    public static final String MAXNUMBER = "Max_Number";
    
    /** Defines the linking thresholds structure config values */
    public static final String MONITOR = "Monitor";
    public static final String POSSIBLE = "Possible";
    public static final String THRESHOLDSCONFIG = "Thresholds_Config";
    public static final String MONITORTHRESHOLD = "Monitor_Threshold";
    public static final String LINKTHRESHOLD = "Link_Threshold";
    public static final String POSSIBLENUMBER = "Possible_Number";
    public static final String MONITORNUMBER = "Monitor_Number";
    public static final String LINKNUMBER = "Link_Number";
    public static final String LINKINCREMENT = "Link_Increment";
    public static final String LINKWEIGTDECREMENT = "Link_Weight_Decrement";
    public static final String LINKMETHOD = "Link_Method";
    public static final int DEFAULTMAXNEGATIVE = 10;
    
    //Options for using linking during query or update processes
    /** Local links tag name */
    public static final String LOCALLINKS = "Local_links";
    
    /** Remote links tag name */
    public static final String REMOTELINKS = "Remote_links";
    
    /** Linking types */
    public static final String PERMLINKS = "Permanent links";
    public static final String DYNTOPERMLINKS = "Dynamic to Permanent links";
    public static final String DYNLINKS = "Dynamic links";
    public static final String ASSOCLINKS = "Association links";

    
    /** Defines the root handle element for a path description */
    public static final String HANDLE = "Handle";
    
    /** Defines a from element */
    public static final String FROM = "From";
    
    /** Defines a to element */
    public static final String TO = "To";

    /** Defines a timeout tag */
    public static final String TIMEOUT = "Timeout";
    
    /** Defines a timestamp tag */
    public static final String TIMESTAMP = "Timestamp";
    
    /** Defines weight tag */
    public static final String WEIGHT = "Weight";
    
    
    //Network Parsing Tags
    /** The Network tag */
    public static final String NETWORK = "Network";
    
    /** The SOA tag */
    public static final String SOA = "SOA";
    
    /** The Services tag */
    public static final String SERVICES = "Services";

    /** The Service tag */
    public static final String SERVICE = "Service";
    
    /** The Auto tag */
    public static final String AUTO = "Auto";
    
    /** The Modules tag */
    public static final String MODULES = "Modules";
    
    /** The Module tag */
    public static final String MODULE = "Module";
    
    /** The Include tag */
    public static final String INCLUDE = "Include";

    /** The Password tag */
    public static final String PASSWORD = "Password";
    
    /** The Passwords tag */
    public static final String PASSWORDS = "Passwords";
    
    /** The Next passwords tag */
    public static final String NEXTPASSWORDS = "Next_Passwords";
    
    /** The Service Keys tag */
    public static final String SERVICEKEYS = "Service_Keys";

    /** The Service Key tag */
    public static final String SERVICEKEY = "Service_Key";
    
    /** The Thread State tag */
    public static final String THREADSTATE = "Thread_State";
    
    /** Scientific tag */
    public static final String SCIENTIFIC = "Scientific";

    /** Defines a network url address */
    public static final String URL = "URL";
    
    /** Defines a jar file address */
    public static final String JARFILE = "Jar File";
    
    /** Defines a graphic component width tag */
    public static final String COMPONENTWIDTH = "Component_Width";
    
    /** Defines a graphic horizontal gap tag */
    public static final String HORIZONTALGAP = "Horizontal_Gap";
    
    /** Defines a graphic vertical gap tag */
    public static final String VERTICALGAP = "Vertical_Gap";
    
    /** Defines a graphic network depth tag */
    public static final String NETWORKDEPTH = "Network_Depth";
    
    /** Defines a graphic maximum nodes tag */
    public static final String MAXNODES = "Max_Nodes";
    
    /** Defines a graphic redraw delay tag */
    public static final String REDRAWDELAY = "Redraw_Delay";
    
    
    //For RESTful-style messages
    /** The short Service name tag */
    public static final String SERVICESHORT = "sn";
    
    /** Defines short service password tag */
    public static final String SERVERPASSWORDSHORT = "spw";
    
    /** Defines short service password tag */
    public static final String SERVICEPASSWORDSHORT = "pw";
    
    /** Defines short method name tag */
    public static final String METHODNAMESHORT = "mn";
    
    /** Defines short return type tag */
    public static final String RETURNTYPESHORT = "rt";
    
    /** Defines a short parameter tag */
    public static final String PARAMETERSHORT = "p";
    
    /** Defines short param types tag */
    public static final String PARAMTYPESSHORT = "pts";
    
    /** Defines short timeout tag - in seconds not milliseconds */
    public static final String TIMEOUTSHORT = "t";
    
    /** Defines short communication ID tag */
    public static final String COMMIDSHORT = "cid";
    
    /** Defines short web service username tag */
    public static final String WSUSERNAME = "username";
    
    /** Defines short web service password tag */
    public static final String WSPASSWORD = "password";
    
    /** Defines short web service username tag */
    public static final String WSUSERNAMESHORT = "wsun";
    
    /** Defines short web service password tag */
    public static final String WSPASSWORDSHORT = "wspw";
    
    
    //Service descriptions
    /** Defines a class name */
    public static final String UUID = "UUID";
    
    /** Defines a service type */
    public static final String SERVICETYPE = "Service_Type";
    
    /** Defines a service grade */
    public static final String SERVICEGRADE = "Service_Grade";
    
    /** Defines a service category */
    public static final String SERVICECATEGORY = "Service_Category";
    
    /** Defines a class name */
    public static final String CLASSNAME = "Class_Name";
    
    /** Defines a service path */
    public static final String SERVICEPATH = "Service_Path";
    
    /** Defines a service description */
    public static final String DESCRIPTION = "Description";

    /** Defines an icon file tag */
    public static final String ICON = "Icon";

    /** Defines any other metadata related to a service */
    public static final String OTHERMETA = "Other_Meta";
    
    /** Defines some Object tag */
    public static final String OBJECT = "Object";
    
    /** Defines licas-specific service tag */
    public static final String LICASSERVICE = "Licas_Service";
    
    /** Defines instance values metadata part */
    public static final String INSTANCEVALUES = "Instance_Values";
    
    /** Defines single instance value metadata part */
    public static final String INSTANCEVALUE = "Instance_Value";
    
    /** Defines serialise values metadata part */
    public static final String SERIALISEVALUES = "Serialise_Values";
    
    /** Defines single serialise value metadata part */
    public static final String SERIALISEVALUE = "Serialise_Value";
    
    /** Defines any other script values related to a service */
    public static final String OTHERSCRIPT = "Other_Script";
    
    /** Defines a service data */
    public static final String DATA = "Data";
    
    /** Defines dataset tag */
    public static final String DATASET = "Dataset";
    
    /** Defines datasets tag */
    public static final String DATASETS = "Datasets";
    
    /** Defines local dataset tag */
    public static final String LOCALDATASET = "Local Dataset";
    
    /** Defines dataset type tag */
    public static final String DATASETTYPE = "Dataset_Type";
    
    /** Defines input type tag */
    public static final String INPUT = "Input";
    
    /** Defines output type tag */
    public static final String OUTPUT = "Output";
    
    /** Defines tokenizer type tag */
    public static final String TOKENIZER = "Tokenizer";
    
    /** Defines number of (service)solutions tag */
    public static final String SOLUTIONS = "Solutions";
    
    /** Defines next service tag */
    public static final String NEXTSERVICE = "Next_Service";
    
    /** Defines child services tag */
    public static final String CHILDSERVICES = "Child_Services";
    
    /** Defines meta xml descriptions for constructors */
    public static final String CONSTRUCTORS = "Constructors";

    /** Defines meta xml descriptions for one constructor */
    public static final String CONSTRUCTOR = "Constructor";

    /** Defines result element tag */
    public static final String RESULT = "Result";
    
    /** Defines query condition */
    public static final String QUERY = "Query";
    
    /** Defines a reply tag */
    public static final String REPLY = "Reply";
    
    /** Defines a next reply */
    public static final String NEXTREPLY = "Next_Reply";

    /** Defines time element tag */
    public static final String TIME = "Time";
    
    /** Defines a default metadata search query */
    public static final String METASEARCH = "Meta_Search";
    
    /** Defines MessageInfo object tag */
    public static final String MESSAGEINFO = "Message_Info";
    
    /** Defines a message type tag */
    public static final String MESSAGETYPE = "Message_Type";
    
    /** Defines a message state tag */
    public static final String MESSAGESTATE = "Message_State";
    
    /** Defines a service state tag */
    public static final String SERVICESTATE = "Service_State";
    
    /** Test script tag */
    public static final String TESTSCRIPT = "Test_Script";
    
    /** Behaviour script tag */
    public static final String BEHAVIOURSCRIPT = "Behaviour_Script";
    
    
    //Different types of service state
    /** Defines a service ready for use */
    public static final String READY = "Ready";
    
    /** Defines a service not ready for use */
    public static final String NOTREADY = "Not Ready";
    
    /** Defines an initialised service */
    public static final String INITIALISED = "Initialised";
    
    /** Local file call tag */
    public static final String LOCALFILECALL = "localFileCall";
    
    /** Defines the parser handle */
    public static final String PARSER = "Parser";
        
    /** Defines the parser handle */
    public static final String PARSERCLASS = "Parser_Class";
        
    /** Defines the parser handle */
    public static final String TOPARSECLASS = "To_Parser_Class";
        
    /** Defines include parent object as a parameter */
    public static final String PARENT = "Parent_Param";
    
              
    //Service parsers
    /** Defines character encoding */
    public static final String CHARENCODING = "ISO-8859-1";
    
    /** Defines XML header information */
    public static final String XMLHEADER = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>";

    /** Pass the whole message in one go */
    public static final int ONEPACKET = -1;
    
    /** Defines services to load tag */
    public static final String SERVICESTOLOAD = "Services_To_Load";
    
    /** Defines an access permission tag */
    public static final String ACCESS = "Access";
    
    /** Defines access level tag */
    public static final String ACCESSLEVEL = "Access_Level";
    
    /** Defines level type tag */
    public static final String LEVELTYPE = "Level_Type";
    
    /** Defines group tag */
    public static final String GROUP = "Group";
    
    /** Defines exclude tag */
    public static final String EXCLUDE = "Exclude";
    
    /** Defines global value */
    public static final String GLOBAL = "Global";

    /** Defines local value */
    public static final String LOCAL = "Local";

    /** Defines allow add services value */
    public static final String ALLOWADDSERVICES = "Allow_Add_Services";
    
    /** Defines allow add services value */
    public static final String ALLOWEXTERNALJARS = "Allow_External_Jars";
    
    /** Defines access to metadata allowed value */
    public static final String METAACCESSALLOWED = "Meta_Access_Allowed";

    /** Defines access to nested services allowed value */
    public static final String NESTEDACCESSALLOWED = "Nested_Access_Allowed";


    //MethodInfo tags
    /** Defines MethodInfo object tag */
    public static final String METHODINFO = "Method_Info";

    /** Defines packet size value */
    public static final String PACKETSIZE = "Packet_Size";

    /** Defines is remote call tag */
    public static final String ISREMOTE = "Is_Remote";

    /** Defines call type value */
    public static final String CALLTYPE = "Call_Type";

    /** Defines a protocol type */
    public static final String PROTOCOL = "Protocol";
    
    /** Create services tag */
    public static final String CREATESERVICES = "Create_Services";
    
    /** Start threads tag */
    public static final String STARTTHREADS = "Start_Threads";
    
    /** Server address tag */
    public static final String SERVERADDRESS = "Server_Address";

    /** Defines server password tag */
    public static final String SERVERPASSWORD = "Server_Password";
    
    /** Defines server (admin) key */
    public static final String SERVERKEY = "Server_Key";
    
    /** Defines service password tag */
    public static final String SERVICEPASSWORD = "Service_Password";

    /** Defines server passwords required tag */
    public static final String PASSWORDSREQUIRED = "Passwords_Required";

    /** Defines As HTTPS protocol tag */
    public static final String ASHTTPS = "As_Https";

    /** Defines communication id tag */
    public static final String COMMUNICATIONIDS = "Communication_IDS";

    /** Defines communication id tag */
    public static final String COMMUNICATIONID = "Communication_ID";

    /** Defines service return type tag */
    public static final String SERVICERETURNTYPE = "Service_Return_Type";

    /** Defines client uri tag */
    public static final String CLIENTURI = "Client_Uri";

    /** Defines service uri tag */
    public static final String SERVICEURI = "Service_Uri";

    /** Defines rest of service uri tag */
    public static final String RESTOFSERVICEURI = "Rest_Of_Service_Uri";
    
    
    //DataInfo tags
    /** Defines DataInfo object tag */
    public static final String DATAINFO = "Data_Info";
    public static final String EVALUATORCLASS = "Evaluator_Class";
    
    
    // Other services tag
    /** Defines methods tag */
    public static final String METHODS = "Methods";
    
    /** Defines method tag */
    public static final String METHOD = "Method";
    
    /** Defines method name tag */
    public static final String METHODNAME = "Method_Name";
    
    /** Defines return type tag */
    public static final String RETURNTYPE = "Return_Type";
    
    /** Defines next parameter tag */
    public static final String NEXTPARAMETER = "Next_Parameter";
    
    /** Defines parameter name tag */
    public static final String PARAMETERNAME = "Parameter_Name";
    
    /** Defines parameter type tag */
    public static final String PARAMETERTYPE = "Parameter_Type";
    
    /** Defines parameter description tag */
    public static final String PARAMETERDESCRIPTION = "Parameter_Description";
    
    /** Defines meta xml description for a jar files list */
    public static final String JARFILESXML = "Jar_Files";
    
    /** Defines meta xml description for one jar file */
    public static final String JARFILEXML = "Jar_File";
    
    /** Defines an Element to be loaded from a file description */
    public static final String ELEMENTFILE = "Element: specify XML file";
    
    /** Defines a jar uri url type */
    public static final String URIURL = ":url:";
    
    /** Defines a jar uri password type */
    public static final String URIPASSWORD = ":password:";
    
    /** Defines a jar uri jar file type */
    public static final String URIJAR = ":jar:";
    
    /** Defines a local jar factory file type */
    public static final String LICASJARFILE = "licasjar:";
    
    /** Defines a jar file prefix */
    public static final String JAR = "jar:";
    
    /** Defines a jar file postfix */
    public static final String ENDJAR = "!/";
    
    /** Defines the licas server jar file */
    public static final String LICASJARSERVER = "licas.jar";
    
    
    //Parameter types
    /** Defines the file object tag */
    public static final String FILEOBJECT = "File_Object";
    
    /** Defines the file object content tag */
    public static final String FILEURI = "File_Uri";
    
    /** Defines the file object content tag */
    public static final String FILECONTENT = "File_Content";
    
    /** Defines the contents as bytes only tag */
    public static final String ASBYTES = "As_Bytes";
    

    //Web Service tags
    /** Defines web service tag */
    public static final String WEBSERVICEMETHODINFO = "Web_Service_MethodInfo";

    /** Defines web service tag */
    public static final String WEBSERVICE = "Web_Service";

    /** Defines endpoint address tag */
    public static final String ENDPOINT = "Endpoint";

    /** Defines soap action tag */
    public static final String SOAPACTION = "Soap_Action";

    /** Defines namespace tag */
    public static final String NAMESPACE = "Namespace";
    
    /** Defines local web service tag */
    public static final String LOCALWS = "LocalWS";
    
    
    //HTTP server parsing
    /** Defines the http entity/request/response object tag */
    public static final String HTTPENTITY = "Http_Entity";

    /** Defines entity headers tag */
    public static final String HEADERS = "Headers";

    /** Defines status code tag */
    public static final String STATUS = "Status";
    
    /** Defines a response tag */
    public static final String RESPONSE = "Response";

    /** Defines HTTP comm buffer size */
    public static final int BUFFERSIZE = (4 * 1024);
    
    
    //Linking levels
    /** Indicates not currently stored as a source */
    public static final int NOSOURCE = 0;
    
    /** Possible source indicator */
    public static final int POSSIBLESOURCE = 1;
    
    /** Monitor source indicator */
    public static final int MONITORSOURCE = 2;
    
    /** Link source indicator */
    public static final int LINKSOURCE = 3;    
    
    
    /** CustomLogger details */
    /** Log class */
    public static final String LOGCLASS = "licas";
    
    /** Log file */
    public static final String LOGFILE = "CustomLogger.txt";

    /** Remote communication types */
    /** XML-RPC type */
    public static final String XMLRPC = "xml-rpc";

    /** REST type */
    public static final String REST = "rest";
    
    /** SOAP type */
    public static final String SOAP = "soap";
    
    /** Web Service RPC protocol */
    public static final String WSRPC = "RPC";

    /** SOAP lite type */
    public static final String SOAPLITE = "soaplite";

      
    
    /** Mathematical operators */
    /** This defines the minimum value tag */
    public static final String MINVALUE = "Min_Value";
    
    /** This defines the maximum value tag */
    public static final String MAXVALUE = "Max_Value";
    
    /** This defines the range tag */
    public static final String RANGE = "Range";
    
    /** This defines the seed tag */
    public static final String SEED = "Seed";
    
    
    /** Other tags */
    /** Defines a service data */
    public static final String ERROR = "Error";
    
    /** Null indicator */
    public static final String NULL = "d8edc800-55cc";
    
    /** Token separtor of random char sequence */
    public static final String SEPCHARS = "hdf3gb5D92uw7";
    
    /** Decode attribute */
    public static final String DECODE = "addcode";
    
    /** True indicator */
    public static final String TRUE = "true";
    
    /** Tab amount */
    public static final String TAB = "\t";
    
    /** The colon symbol */
    public static final String COLON = ":";

    
    /** For debugging */
    public static long counter = 0;


    /** Creates a new instance of Const */
    public Const() {
    }
    
    /**
     * Return true if linux or android OS is specified.
     * @return true if Linux, false if other or null.
     */
    public static boolean isLinux()
    {
        return ((OS != null) && (OS.equalsIgnoreCase(Const.LINUX) ||
                OS.equalsIgnoreCase(Const.ANDROID)));
    }

    /**
     * Return true if a mobile (android) OS is specified.
     * @return true if mobile, false if other or null.
     */
    public static boolean isMobile()
    {
        return ((OS != null) && OS.equalsIgnoreCase(Const.ANDROID));
    }
}
