/*
 * ServiceAdminHandler.java
 *
 * Created on 10 October 2019
 *
 * Version 1.1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.StringHandler;
import org.licas.def.ServiceWrapperDef;
import org.licas.meta.ServiceMeta;
import org.licas.parsers.WorkInfoParser;
import org.licas.parsers.admin.AdminParser;
import org.licas.parsers.admin.KeywordHandlerParser;
import org.licas.parsers.types.ReflectionParser;
import org.licas.server.LocalServer;
import org.licas.service.model.Contract;
import org.licas.service.model.KeywordHandler;
import org.licas.service.model.WorkInfo;
import org.licas.util.Const;
import org.licas.util.MetaConst;
import org.licas.util.ReflectionHandler;
import org.licas.util.classloader.LoadObject;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Vector;


/**
 * This class manages basic creation and parsing for Service Admin objects.
 * @author Kieran Greer
 */
public class ServiceAdminHandler
{
    /** The logger */
    private static final Logger logger;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServiceAdminHandler.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of ServiceAdminHandler.
     */
    public ServiceAdminHandler()
    {}

    /**
     * Parse the admin info XML to create the service admin info.
     * @param adminXml the xml-based description of the service.
     * @param sa the ServiceAdmin the operation is for.
     * @throws Exception any error.
     */
    public static void parseAdminInfo(Element adminXml, ServiceAdmin sa) throws Exception
    {
        if (adminXml != null)
        {
            parseAdminXml(adminXml, sa);
            sa.contractManager = new ContractManager(sa.adminInfo.getServicelevelContracts());
        }
        else
        {
            sa.contractManager = new ContractManager(null);
        }
    }

    /**
     * Parse the adminXml element to determine what information it contains.
     * @param adminXml the metadata adminXml.
     * @param sa the ServiceAdmin the operation is for.
     * @throws Exception any error.
     */
    public static void parseAdminXml(Element adminXml, ServiceAdmin sa) throws Exception
    {
        int i;
        String elemName;                                //element name
        Element keywordElem;                            //keyword element
        Element workElem;                               //work info element
        Element nextElem;                               //next element
        Vector<Node> elemList;                          //element list
        AdminParser adminParser;                        //the admin parser
        KeywordHandlerParser keywordParser;             //keyword parser
        WorkInfoParser wiParser;                        //work protocol parser

        if (adminXml != null) {
            adminParser = new AdminParser();
            sa.adminInfo = adminParser.parse(adminXml);

            if (sa.adminInfo != null) {
                if (sa.adminInfo.getUuid() != null) sa.service.setUUID(sa.adminInfo.getUuid());
                if (sa.adminInfo.getType() != null) sa.service.setServiceType(sa.adminInfo.getType());

                sa.service.setCanAccessNested(sa.adminInfo.getNestedAccessAllowed(), sa.serviceAdminKey);
                sa.service.getPasswordHandler().setLevelOrder(sa.adminInfo.getLevelOrder());
                sa.service.getPasswordHandler().setLevelMethods(sa.adminInfo.getAccessLevels());
                sa.service.getPasswordHandler().setLevelPasswords(sa.adminInfo.getLevelPasswords());
                sa.service.getPasswordHandler().setLevelGroups(sa.adminInfo.getLevelGroups());
                sa.service.getPasswordHandler().setAllGroups(sa.adminInfo.getAllGroups());
                sa.service.getPasswordHandler().setAllExclude(sa.adminInfo.getAllExclude());
            }

            keywordElem = adminXml.getChild(Const.KEYWORDS);
            if (keywordElem != null) {
                keywordParser = new KeywordHandlerParser();
                sa.keywordHandler = (KeywordHandler)keywordParser.parse(keywordElem);
            }

            workElem = adminXml.getChild(MetaConst.WORKINFO);
            if (workElem != null) {
                wiParser = new WorkInfoParser();
                sa.workInfo = (WorkInfo)wiParser.parse(workElem);
            }

            elemList = (Vector)adminXml.getChildren().clone();
            for (i = 0; i < elemList.size(); i++)
            {
                nextElem = (Element)elemList.get(i);
                elemName = nextElem.getName();

                if (!AdminInfo.isDistinctAdminTag(elemName)) {
                    sa.adminInfo.getAdditional().put(elemName, (Element)nextElem.detach());
                }
            }
        }
    }

    /**
     * Create a full metadata description of this service. If this is a wrapper
     * for a legacy object, then ask the server for any stored metadata
     * description and use that if available. It may have been created or initialised
     * from one. If it is derived from {@link Service} then create a new one so
     * that the settings are the most recent.
     * The description describes only this service and no nested services.
     * @param jarFile list of remote jar files if loaded remotely.
     * @param theAdminKey the unique service key for admin purposes.
     * @param sa the ServiceAdmin the operation is for.
     * @return a metadata description of this service.
     * @throws Exception any error.
     */
    public static ServiceMeta createServiceMeta(ArrayList<String> jarFile, String theAdminKey, ServiceAdmin sa)
            throws Exception
    {
        String thisClassName;               //the class name
        ServiceMeta serviceMeta;            //metadata description

        serviceMeta = null;
        try
        {
            if (sa.service.getPasswordHandler().isAdminKey(theAdminKey) || (sa.service instanceof ServiceWrapperDef))
            {
                if (sa.service instanceof ServiceWrapperDef)
                {
                    serviceMeta = Objects.requireNonNull(LocalServer.getApi(sa.service.getServerPassword())).getServiceMeta(sa.service.getUUID(), theAdminKey);
                }

                if (serviceMeta == null)
                {
                    if (sa.service instanceof ServiceWrapperDef)
                    {
                        thisClassName = ((ServiceWrapperDef)sa.service).getObjClass().getName();
                    }
                    else
                    {
                        thisClassName = sa.service.getClass().getName();
                    }
                    thisClassName = StringHandler.replaceFirst(thisClassName, "class", "").trim();

                    serviceMeta = new ServiceMeta();
                    if (sa.adminInfo == null)
                    {
                        serviceMeta.setServiceMeta(sa.service.getUUID(), sa.service.getServiceType(),
                                sa.service.getServiceGrade(), thisClassName, sa.service.getFullPath(),
                                jarFile);
                    }
                    else
                    {
                        serviceMeta.setServiceMeta(sa.service.getUUID(), sa.service.getServiceType(),
                                sa.service.getServiceGrade(), thisClassName, sa.service.getFullPath(),
                                jarFile, sa.adminInfo);
                    }
                }

                serviceMeta.setKeywordHandler(sa.keywordHandler);
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "createServiceMeta", null, ex);
        }

        return serviceMeta;
    }

    /**
     * Create a full metadata description of this service.
     * The description describes only this service and no nested services.
     * @param jarFile list of remote jar files if loaded remotely.
     * @param theAdminKey the unique service key for admin purposes.
     * @param sa the ServiceAdmin the operation is for.
     * @return a metadata description of this service.
     * @throws Exception any error.
     */
    public static ServiceMeta createFullServiceMeta(ArrayList<String> jarFile, String theAdminKey, ServiceAdmin sa)
            throws Exception
    {
        ServiceMeta serviceMeta;                    //metadata description
        ServiceSerialize serializer;                //the serializer

        serializer = new ServiceSerialize();
        try
        {
            serviceMeta = createServiceMeta(jarFile, theAdminKey, sa);
            if (serviceMeta != null)
            {
                serviceMeta.childServiceMeta = serializer.childServiceMetaToXml(sa.service);
                serviceMeta.linkServiceMeta = serializer.permanentLinksToXml(sa.service.serviceLinks.permanentLinks);
                serviceMeta.serviceAssociations = serializer.associationLinksToXml(sa.service.serviceLinks.serviceAssociations);
                serviceMeta.constructorMeta = getConstructorInfo(serviceMeta.serviceClass, jarFile);
                serviceMeta.methodMeta = getMethodInfo(serviceMeta.serviceClass, jarFile, sa);

                if (sa.adminInfo != null)
                {
                    serviceMeta.meta = sa.adminInfo.getOtherMeta();
                    serviceMeta.data = sa.adminInfo.getData();
                }
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "createFullServiceMeta", null, ex);
        }

        return serviceMeta;
    }

    /**
     * Create a metadata description of the parent service for the server repository.
     * The description describes only this service and no nested services.
     * @param sa the ServiceAdmin the operation is for.
     * @return a metadata description of this service.
     * @throws Exception any error.
     */
    public static ServiceMeta createMetaForRepos(ServiceAdmin sa) throws Exception
    {
        ServiceMeta serviceMeta;            //metadata description

        try
        {
            serviceMeta = new ServiceMeta();
            serviceMeta.setServiceMeta(sa.service.getUUID(), sa.service.getServiceType(),
                    sa.service.getServiceGrade(), null, sa.service.getFullPath(), null);

            serviceMeta.description = sa.service.getDescription();
            serviceMeta.setKeywordHandler(sa.keywordHandler);
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "createMetaForRepos", null, ex);
        }

        return serviceMeta;
    }

    /**
     * Retrieve information on the public methods for the class.
     * @param serviceClass the service class name.
     * @param jarFile additional jar files for the loader.
     * @param sa the ServiceAdmin the operation is for.
     * @return the parsed reflection method metadata.
     * @throws Exception any error.
     */
    private static ArrayList<Element> getMethodInfo(String serviceClass, ArrayList<String> jarFile, ServiceAdmin sa)
            throws Exception
    {
        int i;
        String nextClassName;                           //next class name
        Class nextServiceClass;                         //next service class
        Method[] methods;                               //the method list
        ArrayList<Element> allMethods;                  //all methods
        ArrayList<Element> methodMeta;                  //method meta
        AdminParser adminParser;                        //admin parser

        try
        {
            methodMeta = new ArrayList<>();
            nextClassName = ReflectionParser.unformatClassName(serviceClass);

            nextServiceClass = LoadObject.getClass(nextClassName);
            if (nextServiceClass == null)
            {
                try
                {
                    LoadObject.addLoader(jarFile);
                    nextServiceClass = LoadObject.getClass(nextClassName);
                }
                catch (Exception cnfex)
                {}
            }

            adminParser = new AdminParser();
            allMethods = adminParser.getAllMethods(sa.adminInfo, true);

            if (allMethods.size() > 0)
            {
                methodMeta.addAll(allMethods);
            }
            else
            {
                if (nextServiceClass != null)
                {
                    methods = ReflectionHandler.getMethods(nextServiceClass);
                    for (i = 0; i < methods.length; i++)
                    {
                        if (!ReflectionParser.objectMethods.contains(methods[i].getName()))
                            methodMeta.add(ReflectionParser.methodToShortXML(methods[i]));
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "getMethodInfo", "", ex);
        }

        return methodMeta;
    }

    /**
     * Retrieve information on the constructors for the class.
     * @param serviceClass the service class name.
     * @param jarFile additional jar files for the loader.
     * @throws Exception any error.
     */
    private static ArrayList<Element> getConstructorInfo(String serviceClass, ArrayList<String> jarFile)
            throws Exception
    {
        int i;
        String nextClassName;                       //next class name
        Class nextServiceClass;                     //next service class
        Constructor[] constructors;                 //the constructor list
        ArrayList<Element> constructorMeta;         //constructor meta

        try
        {
            constructorMeta = new ArrayList<>();
            nextClassName = ReflectionParser.unformatClassName(serviceClass);

            nextServiceClass = LoadObject.getClass(nextClassName);
            if (nextServiceClass == null)
            {
                try
                {
                    LoadObject.addLoader(jarFile);
                    nextServiceClass = LoadObject.getClass(nextClassName);
                }
                catch (Exception cnfex)
                {}
            }

            if (nextServiceClass != null)
            {
                constructors = ReflectionHandler.getConstructors(nextServiceClass);
                for (i = 0; i < constructors.length; i++)
                {
                    constructorMeta.add(ReflectionParser.constructorToShortXML(constructors[i]));
                }
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "getConstructorInfo", "", ex);
        }

        return constructorMeta;
    }

    /**
     * Create an admin document with only a yes contract section.
     * @return an xml-based description of the admin document.
     */
    public static Element createAdminOnlyContractYes()
    {
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        Element adminXml;                               //the admin document

        adminXml = XMLFactory.getInstance().createElement(MetaConst.ADMIN);
        nextElem = XMLFactory.getInstance().createElement(MetaConst.SERVICELEVELCONTRACTS);
        adminXml.addContent(nextElem);

        nextElem2 = Contract.getYesContract().getContract();
        nextElem.addContent(nextElem2);

        return adminXml;
    }

    /**
     * Create an admin document with only a yes contract section.
     * @return an xml-based description of the admin document.
     */
    public static Element createAdminOnlyContractNo()
    {
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        Element adminXml;                               //the admin document

        adminXml = XMLFactory.getInstance().createElement(MetaConst.ADMIN);
        nextElem = XMLFactory.getInstance().createElement(MetaConst.SERVICELEVELCONTRACTS);
        adminXml.addContent(nextElem);

        nextElem2 = Contract.getNoContract().getContract();
        nextElem.addContent(nextElem2);

        return adminXml;
    }
}
