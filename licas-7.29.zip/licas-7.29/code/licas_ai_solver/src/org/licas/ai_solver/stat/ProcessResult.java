/*
 * ProcessResult.java
 *
 * Created on 3 June 2011
 *
 * Version 1.2.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.stat;


import org.ai_heuristic.eval.result.*;
import org.licas.ai_solver.model.result.*;
import org.licas.ai_solver.util.NameHandler;
import org.licas.service.link.AnalyseLinks;
import org.ai_heuristic.util.AiHeuristicConst;
import org.jlog2.util.CollectionHandler;

import java.util.*;


/**
 * This class can be used for some additional processing of the results.
 * @author Kieran Greer
 */
public class ProcessResult 
{
    /** Groups of clusters as determined by the processing */
    public ArrayList<ArrayList<String>> clusters;
    
    /** Maximum evaluation value */
    public static Object max;
    
    /** Minimum evaluation value */
    public static Object min;
    
    /** Maximum evaluation bound value */
    public static Object maxB;
    
    /** Minimum evaluation bound value */
    public static Object minB;
    
    /** To analyse dynamic links */
    protected static AnalyseLinks analyseLinks;
    
    
    static
    {
        try {
            max = null;
            min = null;
            maxB = null;
            minB = null;
            analyseLinks = new AnalyseLinks();
        }
        catch (Exception ex) {}
    }
    
    
    /** 
     * Create a new instance of ProcessResult.
     */
    public ProcessResult()
    {
        clusters = new ArrayList<>();
    }
    
    /**
     * Clear the analysis values for this object and the dynamic {@link AnalyseLinks} object.
     * @throws java.lang.Exception any error.
     */
    public static void clearAnalysis() throws Exception
    {
        max = null;
        min = null;
        maxB = null;
        minB = null;
        analyseLinks.resetValues();
    }
    
    /**
     * Remove any duplicate groups of clusters. This is also down to interpretation of
     * what should be removed. This implementation only keeps one instance of each group.
     * @param serviceGroups the cluster groups to check. This is of
     * the form [[a1, b1, c2],[a2, b2, c2],[a3, b3, c3], etc].
     * @return the same groups in a similar structure, but only one instance of each.
     */
    public ArrayList<ArrayList<String>> removeDuplicateGroups(ArrayList<ArrayList<String>> serviceGroups)
    {
        int i, j, k;
        boolean contains;                       //true if contains value
        String nextName;                        //next name
        ArrayList<String> nextList1;            //next list
        ArrayList<String> nextList2;            //next list
        ArrayList<String> tempList;             //temp list
        
        for (i = 0; i < (serviceGroups.size()-1); i++)
        {
            nextList1 = serviceGroups.get(i);
            
            j = i+1;
            while (j < serviceGroups.size())
            {
                nextList2 = serviceGroups.get(j);
                if (nextList2.size() > nextList1.size()) {
                    tempList = nextList1;
                    nextList1 = nextList2;
                    nextList2 = tempList;
                }
                
                contains = true;
                for (k = 0; contains && (k < nextList2.size()); k++)
                {
                    nextName = nextList2.get(k);
                    contains = nextList1.contains(nextName);
                }
                
                if (contains) serviceGroups.remove(j);
                else j++;
            }
        }
        
        return serviceGroups;
    }
    
    /**
     * Given a list of cluster groups, sort for each individual entity where no
     * entity name is repeated.
     * @param allGroups a list of lists of entities in different groups. This is of
     * the form [[a1, b1, c2],[a2, b2, c2],[a3, b3, c3], etc].
     * @return the same list with repeated names removed and sorted for creating links.
     * For this implementation, the key in the hashtable is an entity name and 
     * the value is a list of all groups it belongs to (or other entity ids it was 
     * clustered with). For example: key: a4, value: [[a1, b1, c2],[a2, b2, c2],[a3, b3, c3], etc].
     */
    public HashMap<String, ArrayList<ArrayList<String>>> sortGroupsForLinks(ArrayList<ArrayList<String>> allGroups)
    {
        int i, j;
        String entityUuid;                                              //entity uuid
        ArrayList<String> nextList;                                     //next list
        ArrayList<String> uuidList;                                     //uuid list
        ArrayList<ArrayList<String>> groupList;                         //entity groups list
        ArrayList<String> singleUuid;                                   //single uuid list
        HashMap<String, ArrayList<ArrayList<String>>> groupsForEntity;  //separate groups for each entity
        
        groupsForEntity = new HashMap<>();
        for (i = 0; i < allGroups.size(); i++)
        {
            nextList = allGroups.get(i);
            for (j = 0; j < nextList.size(); j++)
            {
                entityUuid = nextList.get(j);
                uuidList = (ArrayList)nextList.clone();
                uuidList.remove(j);
                
                if (!groupsForEntity.containsKey(entityUuid)) {
                    groupsForEntity.put(entityUuid, new ArrayList());
                }
                
                groupList = groupsForEntity.get(entityUuid);
                NameHandler.removeDuplicateNames(uuidList);
                singleUuid = new ArrayList<>();
                singleUuid.add(entityUuid);
                CollectionHandler.removeAll(uuidList, singleUuid);
                groupList.add(uuidList);
            }
        }
        
        return groupsForEntity;
    }
    
    /**
     * Remove any key in any group that starts with {@code AiHeuristicConst.DUMMYKEY}.
     * These keys are for id only and do not relate to any service.
     * @param allGroups a list of lists of entities in different groups. This is of
     * the form [[a1, b1, c2],[a2, b2, c2],[a3, b3, c3], etc].
     * @return the same list with dummy keys removed, or the whole list removed if
     * it is empty.
     */
    public ArrayList<ArrayList<String>> removeDummyKeys(ArrayList<ArrayList<String>> allGroups)
    {
        int i, j;
        String entityUuid;                              //entity uuid
        ArrayList<String> nextList;                     //next list
        ArrayList<ArrayList<String>> serviceGroups;     //separate groups
        
        serviceGroups = new ArrayList<>();
        for (i = 0; i < allGroups.size(); i++)
        {
            nextList = allGroups.get(i);
            j = 0;
            while (j < nextList.size())
            {
                entityUuid = nextList.get(j);
                if (entityUuid.startsWith(AiHeuristicConst.DUMMYKEY)) {
                    nextList.remove(j);
                }
                else {
                    j++;
                }
            }
            
            if (!nextList.isEmpty()) {
                serviceGroups.add(nextList);
            }
        }
        
        return serviceGroups;
    }
    
    /**
     * Calculate clusters of solution names from each solution result.
     * @param result the problem solver result.
     * @return the lists of solution names.
     */
    public ArrayList<ArrayList<String>> solutionNamesInGroups(Result result)
    {
        int i;
        MatchPairName matchPair;                        //next solution match
        MatchResult solutionSet;                        //match result set
        ArrayList<? extends MatchPair> solutionPairs;   //solution pairs
        ArrayList<String> parsedNames;                  //parsed names
        ArrayList<ArrayList<String>> categoryGroups;    //names in same category
        HashMap<String, Cluster> clusters;              //clusters
        Cluster cluster;                                //cluster

        categoryGroups = new ArrayList<>();
        if (result != null) {
            if (result.isMatchType()) {
                solutionSet = (MatchResult)result;
                solutionPairs = solutionSet.getSolutionMatches();

                for (i = 0; i < solutionPairs.size(); i++)
                {
                    matchPair = (MatchPairName) solutionPairs.get(i);

                    parsedNames = new ArrayList<>();
                    parsedNames.addAll(NameHandler.parseCompoundName(matchPair.firstName));
                    parsedNames.addAll(NameHandler.parseCompoundName(matchPair.secondName));
                    categoryGroups.add(parsedNames);
                }
            }
            else if (result.isClusterType()) {
                clusters = ((ClusterResult)result).clusters;
                for (String key: clusters.keySet())
                {
                    cluster = clusters.get(key);
                    categoryGroups.add((ArrayList) cluster.list.clone());
                }
            }
        }
        
        return categoryGroups;
    }
    
    /**
     * A string-based description of the dynamic analysis.
     * @return a string-based description.
     */
    protected String dynamicLinksAnalysis()
    {
        String statsStr;                        //stats as a string
        
        statsStr = "";
        if (max != null) {
            statsStr += ("\nBest evaluation: " + String.valueOf(max));
        }
        if (min != null) {
            statsStr += ("\nWorst evaluation: " + String.valueOf(min));
        }
        if (maxB != null) {
            statsStr += ("\nBest bounds evaluation: " + String.valueOf(maxB));
        }
        if (minB != null) {
            statsStr += ("\nWorst bounds evaluation: " + String.valueOf(minB));
        }
        
        if ((analyseLinks.getBestLinks() != null) && !analyseLinks.getBestLinks().isEmpty()) {
            statsStr += ("\nDynamic links analysis: " + analyseLinks.toString());
        }
        else {
            statsStr += ("\nNo dynamic links analysis.");
        }
        
        return statsStr;
    }
    
    /**
     * Get the dynamic links analysis object.
     * @return the value of analyseLinks.
     */
    public AnalyseLinks getAnalyseLinks()
    {
        return analyseLinks;
    }
    
    /**
     * Convert the stats values into a string-based description.
     * @return a String-based description of the stats object.
     */
    public String toString() 
    {
        String statsStr;                        //stats as a string
        
        statsStr = ("Stats groups: " + String.valueOf(clusters));    
        try {
            statsStr += ("\n" + dynamicLinksAnalysis());
        }
        catch (Exception ex) {
            statsStr += ("\nError processing the dynamic links.");
        }
        
        return statsStr;
    }
}
