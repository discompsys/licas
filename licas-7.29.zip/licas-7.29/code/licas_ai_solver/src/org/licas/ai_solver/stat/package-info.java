/**
 * For making some basic statistical calculations over the results. 
 */
package org.licas.ai_solver.stat;