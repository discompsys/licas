/*
 * TestRunsScript.java
 *
 * Created on 29 July 2014
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.spec;

import java.util.HashMap;


/**
 * This class reads an XML file and loads in a specification for a set of test runs.
 * This class relates specifically to configuring the number of test iterations, the
 * stopping criteria for that, rollbacks if the results are not better, and so on.
 * @author Kieran Greer
 */
public class TestRunsScript
{
    /** True if add the clusters as dynamic links to the services */
    public boolean addLinks;
    
    /** True if new test run on existing services. Different to continue run on existing services. */
    public boolean sameServices;
    
    /** If true output a full test trace, if false output only the test results */
    public boolean fullTrace;
    
    /** Number of clustering runs to perform */
    public int testRuns;
    
    
    /** 
     * Create a new instance of TestRunsScript.
     */
    public TestRunsScript()
    {
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        addLinks = true;
        sameServices = false;
        fullTrace = false;
        testRuns = 0;
    }
    
    /**
     * Return true if the test can end based on spec param values.
     * @param testValues set of current test parameter values as key-value pairs.
     * Can be empty if not used.
     * @return this base version returns false.
     */
    public boolean testCanEnd(HashMap<String, ?> testValues)
    {
        return false;
    }
}
