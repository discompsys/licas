/*
 * SingleSolution.java
 *
 * Created on 3 July 2017.
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.model.central;


import org.ai_heuristic.eval.result.EvalBounds;
import org.licas.ai_solver.def.SolutionSolveDef;
import org.licas.ai_solver.model.Solution;
import org.ai_heuristic.functs.Function;
import org.ai_heuristic.eval.metric.*;

import java.util.*;


/**
 * This class can be used for modelling single problem solutions.
 * It includes the evaluator, the dataset to evaluate and must implement a {@code solve} method.
 * @author Kieran Greer
 */
public class SingleSolution extends Solution implements SolutionSolveDef
{
    /** Used to evaluate the datasets */
    protected Function evaluator;
    
    /** The dataset to evaluate */
    protected MetricDataset dataset;
    
    
    /**
     * Create a new instance of SingleSolution.
     * @param thisName the solution name.
     * @throws java.lang.Exception any error.
     */
    public SingleSolution(String thisName) throws Exception
    {
        super();
        initialise();
        name = thisName;
    }

    /** Initialise some values */
    private void initialise()
    {
        evaluator = null;
        dataset = null;
    }

    /**
     * Calculate the result of this solution over the dataset. The input variables are not used.
     * @param inputVariables an additional set of input variables or constraints. This can be null or empty.
     * Use {@code setDataset} and {@code setEvaluator} to set the parameters.
     * @throws java.lang.Exception any error.
     */
    public void solve(HashMap<String, ?> inputVariables) throws Exception
    {
        evaluation = new EvalBounds();
        evaluation.evaluation = evaluator.evaluate(dataset);
    }
    
    /**
     * Set the evaluator used to evaluate the datasets.
     * @param thisEvaluator the function evaluator.
     */
    public void setEvaluator(Function thisEvaluator)
    {
        evaluator = thisEvaluator;
    }
    
    /**
     * Set the dataset to be evaluated as this solution.
     * @param thisDataset the dataset to evaluate.
     */
    public void setDataset(MetricDataset thisDataset)
    {
        dataset = thisDataset;
    }
    
    /**
     * Get the stored dataset.
     * @return the value of dataset.
     */
    public MetricDataset getDataset()
    {
        return dataset;
    }
    
    /**
     * Create and return a copy of this solution.
     * @return a shallow copy of this solution.
     */
    public Object clone()
    {
        SingleSolution cloneSolution;           //copy of the solution
        
        try {
            cloneSolution = new SingleSolution(this.name);
            cloneSolution.setEvaluator(evaluator);
            cloneSolution.setDataset(dataset);
            return cloneSolution;
        }
        catch (Exception ex) {
            return null;
        }
    }
}
