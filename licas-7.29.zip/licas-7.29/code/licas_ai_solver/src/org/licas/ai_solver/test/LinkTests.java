/*
 * LinkTests.java
 *
 * Created on 11 October 2014
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.test;


import org.licas.ai_solver.eval.EvaluatorDistributed;
import org.licas.ai_solver.spec.*;

import org.licas.PasswordHandler;
import org.licas_xml.abs.Element;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;

import java.util.*;
import org.licas.util.Const;


/**
 * The main class for running distributed linking tests. this is similar to running
 * behaviours, but the number of iterations can be controlled.
 * @author Kieran Greer
 */
public class LinkTests extends RunTests
{
    /** For logging */
    private static final Logger logger;
    
    
    /** True if initialised */
    private boolean initialised;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(LinkTests.class.getName());
        logger.setDebug(false);
    }
    
    /** 
     * Create a new instance of LinkTests.
     * @param thePasswordHandler for storing passwords.
     */
    public LinkTests(PasswordHandler thePasswordHandler) 
    {
        super(thePasswordHandler);
        initialised = false;
    }
    
    /**
     * Run a set of tests based on an already created script object and initialised
     * environment.
     * @return a description of the execution trace.
     * @throws java.lang.Exception any error.
     */
    public String runTestSet() throws Exception
    {
        int i;
        String resultStr;                           //result string
        String exeDescr;                            //description of the test execution
        ArrayList<String> serviceTypes;             //list of service types
        HashMap<String, Object> varList;            //list of variables
        Element finalResult;                        //the final result
        ProblemScript testScript;                   //the test specification
        
        try {
            testScript = testSpec.getTestScript();
            exeDescr = "";
            
            //create new set of solutions each new iteration,
            //but remove existing linked ones for each new test run
            if (!initialised) {
                evalMediator.initialiseMediator(testSpec, problemMediator);
                initialised = true;
            }

            varList = new HashMap<>();
            serviceTypes = new ArrayList<>();
            serviceTypes.add(testSpec.getTestScript().serviceType);
            varList.put(Const.SERVICETYPE, serviceTypes);
            
            problemMediator.resetForNextRun(varList);
            for (i = 0; i < testScript.testRunsScript.testRuns; i++)
            {
                ((EvaluatorDistributed)evalMediator).evaluateSolutions(testSpec, problemMediator);
                Thread.sleep(10);
            }

            //display final result
            finalResult = evalMediator.getTestResult();
            if (finalResult != null) {
                resultStr = finalResult.getText();                          
                if ((resultStr == null) || resultStr.equals("")) {
                    resultStr = xmlToTaggedString(finalResult);
                }
            }
            else {
                resultStr = "Final result is null.";
            }
            
            //store the final test result
            result = evalMediator.getResult();
            
            exeDescr += ("\nFinal result:\n" + resultStr);
            return exeDescr;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "runTestSet",
                null, ex);
        }
    }
}