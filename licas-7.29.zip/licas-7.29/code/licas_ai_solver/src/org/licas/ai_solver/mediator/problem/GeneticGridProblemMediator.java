/*
 * GeneticGridProblemMediator.java
 *
 * Created on 30 August 2010
 *
 * Version 1.10.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.mediator.problem;


import org.ai_heuristic.eval.result.*;
import org.licas.ai_solver.*;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.central.grid.GeneticGrid;
import org.licas.ai_solver.model.*;
import org.licas.ai_solver.model.result.*;
import org.licas.ai_solver.model.comp.HyperCompoundSolution;
import org.licas.ai_solver.model.genetic.genes.*;
import org.licas.ai_solver.model.genetic.HeuristicGeneticSolution;
import org.licas.ai_solver.model.genetic.*;
import org.licas.ai_solver.util.*;

import org.licas.PasswordHandler;
import org.licas.data.DataQueryModel;
import org.licas.util.TypeConst;
import org.licas.util.exception.LicasException;
import org.ai_heuristic.eval.metric.*;
import org.ai_heuristic.eval.*;
import org.ai_heuristic.functs.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;

import java.util.*;
import org.licas.util.MetaConst;


/**
 * This class models the hyper-heuristic grid problem to be solved based on genetic algorithms.
 * The solution is hyper in the respect that a new framework tries to match solutions
 * in a randomising way, to add some level of robustness to the solution.
 * The framework combines solutions based on genetic algorithms.
 * @author Kieran Greer
 */
public class GeneticGridProblemMediator extends GridProblemMediator
{
    /** For logging errors */
    private static final Logger logger;

    /** 
     * The amount of gene to crossover for an evolution. This is just an entry
     * slot for storing this information, which is not automatically used, but 
     * is available for any used defined evolution process. Default is 0.5.
     */
    protected float crossoverFraction;
    
    /** 
     * The amount of gene to mutate for an evolution. This is just an entry
     * slot for storing this information, which is not automatically used, but 
     * is available for any used defined evolution process. Default is 0.5.
     */
    protected float mutateFraction;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(GeneticGridProblemMediator.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of GeneticGridProblemMediator.
     * @param thePasswordHandler for storing passwords.
     */
    public GeneticGridProblemMediator(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        crossoverFraction = (float)0.0;
        mutateFraction = (float)0.0;
    }
       
    /**
     * Optimise the solutions using the appropriate framework.
     * @param testSpec the model of the tests to perform.
     * @return clusters of solutions or references from the latest optimisation phase.
     * @throws java.lang.Exception any error.
     */
    public Result solve(TestSpec testSpec) throws Exception
    {
        int i, j;
        int rowNumber;                                  //number of rows
        int colNumber;                                  //number of columns
        Object[][] solutionArray;                       //solution array
        String nextKey;                                 //next solution key
        ArrayList<String> solutionNames;                //list of solution names
        ArrayList<MatchPair> newSolutions;              //new solution pairs
        HashMap<String, EvalBounds> solutionResults;    //set of solution results
        EvaluationSet nextResultSet;                    //next result set
        DataQueryModel dataInfo;                        //stores evaluator parameters
        FunctionMetric valueCompare;                    //to compare values
        GeneticGrid optimiseGrid;                       //to optimise the grid
        MatchPairIndex matchPairIndex;                  //index match pair
        MatchPairName matchPairName;                    //name match pair
        MatchResult gridSolution;                       //grid solution
        EvalBounds nextEvalBounds;                      //next evaluation
        EvalBounds resultBounds;                        //solution result bounds
        HyperCompoundSolution compoundSolution;         //compound solution
                
        try
        {
            //re-initialise the solutions and calculate their values first
            sortProblems(testSpec, true);
            compoundSolution =
                    HyperCompoundSolution.toHyperCompoundSolution(solutionHierarc.get(solutionHierarc.size()-1));
        
            compoundSolution.calculateSolution(MetaConst.ALL, inputVariables);
            resultBounds = compoundSolution.getSolutionResult();
            if (resultBounds.evaluation != null) {
                intermediateBounds.evaluation = resultBounds.evaluation;
            }
            
            //use the new value to determine what solutions need to be combined
            //in this implementation there is only ever one level
            rowNumber = 0;
            gridSolution = null;

            try {
                dataInfo = new DataQueryModel();
                dataInfo.setDataType(SolverFactory.getInstance().getSolverData().dataClassFromType(testSpec.getTestScript().datasetType));
                
                valueCompare = (FunctionMetric)SolverFactory.getInstance().getSolverMetrics().getEvaluationFunction(SolverFactory.getInstance().getSolverData().dataClassFromType(testSpec.getTestScript().datasetType),
                    testSpec.getTestScript().metricType,
                    SolverFactory.getInstance().getSolverData().getEvaluateData(dataInfo), 
                    testSpec.getTestScript().heuristicOptions);
            }
            catch (Exception fex) {
                valueCompare = null;
            }

            if (valueCompare != null) {
                optimiseGrid = new GeneticGrid(testSpec, valueCompare.lib());
            }
            else {
                optimiseGrid = new GeneticGrid(testSpec, true);
            }
            solutionResults = (HashMap)intermediateBounds.evaluation.getValue();
            
            //generate 2-d array representing the solutions and results
            if (solutionResults != null) {
                //order the solution names
                if ((solutionOrder != null) && !solutionOrder.isEmpty())
                {
                    solutionNames = (ArrayList) solutionOrder.clone();

                    i = 0;
                    while (i < solutionNames.size())
                    {
                        if (!solutionResults.containsKey(solutionNames.get(i))) {
                            solutionNames.remove(i);
                        }
                        else {
                            i++;
                        }
                    }
                }
                else {
                    solutionNames = problem.getProblemNames();
                }

                for (i = 0; i < solutionNames.size(); i++)
                {
                    nextKey = solutionNames.get(i);
                    if (solutionResults.containsKey(nextKey)) {
                        nextEvalBounds = solutionResults.get(nextKey);
                        nextResultSet = EvaluationSet.toSet(nextEvalBounds.evaluation);
                        if (nextResultSet.size() > rowNumber) rowNumber = nextResultSet.size();
                    }
                }

                colNumber = solutionResults.size();
                solutionArray = new Object[colNumber][rowNumber];

                //initialise array with empty values
                for (i = 0; i < solutionArray.length; i++)
                {
                    for (j = 0; j < solutionArray[i].length; j++)
                    {
                        solutionArray[i][j] = Double.NaN;
                    }
                }

                for (i = 0; i < solutionNames.size(); i++)
                {
                    nextKey = solutionNames.get(i);
                    
                    nextEvalBounds = solutionResults.get(nextKey);
                    nextResultSet = EvaluationSet.toSet(nextEvalBounds.evaluation);

                    for (j = 0; j < nextResultSet.size(); j++)
                    {
                        try {
                            if (datasetType.equalsIgnoreCase(TypeConst.STRING)) {
                                solutionArray[i][j] =
                                    (EvaluateBase.valueFromString(Double.class.getName(),
                                    EvaluateBase.valueToString(TypeConst.INTEGER,
                                    MathString.stringToNum((String)nextResultSet.get(j).evalValue()))));
                            }
                            else {
                                solutionArray[i][j] = (EvaluateBase.valueFromString(Double.class.getName(),
                                    EvaluateBase.valueToString(datasetType, nextResultSet.get(j).evalValue())));
                            }
                        }
                        catch (Exception nex) {
                            solutionArray[i][j] = ((Double)EvaluateBase.valueFromString(Double.class.getName(),
                                String.valueOf(nextResultSet.get(j).evalValue()))).doubleValue();
                        }
                    }
                }

                optimiseGrid.setGridCells(solutionArray);
                optimiseGrid.solve(optimiseGrid.getMetric(datasetType));
                gridSolution = (MatchResult)optimiseGrid.getGridSolution();

                if (gridSolution != null) {
                    currentOptValue = gridSolution.getBestScore();

                    //retrieve solution or problem indexes and convert to names
                    if (gridSolution.getSolutionMatches() != null) {
                        newSolutions = new ArrayList<>();

                        for (j = 0; j < gridSolution.getSolutionMatches().size(); j++)
                        {
                            matchPairIndex = (MatchPairIndex) gridSolution.getSolutionMatches().get(j);

                            matchPairName = new MatchPairName();
                            matchPairName.firstName = solutionNames.get(matchPairIndex.firstIndex);
                            matchPairName.secondName = solutionNames.get(matchPairIndex.secondIndex);
                            newSolutions.add(matchPairName);
                        }

                        gridSolution.setSolutionMatches(newSolutions);
                    }

                    result = gridSolution;
                }
                else {
                    currentOptValue = new Double(0.0);
                    result = new ErrorResult(optimiseGrid.getErrorFeedback());
                    testEnded = true;
                }
            }
            
            return gridSolution;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "solve", null, ex);
        }
    }
    
    /**
     * Create a new genetic solution with chromosomes, etc. This is a default implementation
     * for the default genetic algorithms that are provided with this package. This includes
     * creating solutions from the simple types of {@code Integer}, {@code Float}, or 
     * {@code String}, primarily for testing purposes only.
     * @param solutionType the type of solution to create.
     * @param problemDataset the problem dataset to create the solution with.
     * @return the new solution.
     * @throws java.lang.Exception any error.
     */
    public Solution createNewSolution(String solutionType, MetricDataset problemDataset) 
            throws Exception
    {
        String solutionName;                    //solution name
        DataQueryModel dataInfo;                //stores evaluator parameters
        GeneticSolution solution;               //solution
        Chromosome chromosome;                  //chromosome
        EvolveInfo evolveInfo;                  //evolution info
        EvolveGenes mutateGenes;                //how genes will mutate
        Function evalMetric;                    //the solution evaluation metric
        
        evolveInfo = new EvolveInfo();
        evolveInfo.geneType = datasetType;
        evolveInfo.copyEvolveTypes(heuristicOptions);
        evolveInfo.mutatePercent = this.mutateFraction;
        evolveInfo.crossoverPercent = this.crossoverFraction;
        
        //create a new solution
        solutionName = problemDataset.getName();       
        solution = new HeuristicGeneticSolution(solutionName);
        dataInfo = new DataQueryModel();
        dataInfo.setDataType(datasetType);
        
        evalMetric = SolverFactory.getInstance().getSolverMetrics().getEvaluationFunction(datasetType,
                solutionType, SolverFactory.getInstance().getSolverData().getEvaluateData(dataInfo), heuristicOptions);

        //seed each initial chromosome with one of the problem datasets
        //then each evaluation will compare that with all other datasets
        mutateGenes = EvolveGenes.getEvolveGeneType(evolveInfo);
        chromosome = Chromosome.getChromosome(null, solutionName, problemDataset, evalMetric, mutateGenes);
        solution.setChromosome(chromosome);

        return solution;
    }
    
    /**
     * This can be used to combine existing solutions to evolve new ones.
     * This implementation is genetic and mutates the existing solutions to create new ones.
     * It creates new solutions based on the specified {@code heuristicOptions} object. 
     * If this is empty, then it will create two new types - one through crossover and one 
     * through mutation. If heuristicOptions specifies specific types on evolution, then it 
     * will perform those only. It then tries to space the new solutions around the existing 
     * solutions for the new grid structure.
     * @param result the result generated by the problem solver. 
     * Can be more solutions, references, or an error..
     * @return true if solutions were combined, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean updateSolutions(Result result) throws Exception
    {
        int i;
        int index1;                                 //first index
        int index2;                                 //second index
        int tempIndex;                              //temporary index
        int pos1;                                   //first position
        int removeWhich;                            //which to remove
        int mutateWhich;                            //which to mutate
        int[] remove;                               //number to remove
        int[] mutate;                               //number of mutations
        String solutionName;                        //solution name         
        String newSolutionName;                     //new solution name
        String mutateType;                          //mutate type
        ArrayList<String> namesList;                //list of names
        ArrayList<Solution> solutionList;           //new solution list
        ArrayList<MatchPair> resultList;            //list of matched solutions
        ArrayList<int[]> rm;                        //remove or mutate
        MatchPairName solutionMatch;                //solution match
        MatchResult solutionSet;                    //solutions result
        GeneticSolution solution1;                  //next solution
        GeneticSolution solution2;                  //next solution
        GeneticSolution newSolution1;               //new solution
        GeneticSolution newSolution2;               //new solution
        HyperCompoundSolution newCompSoln;          //new compound solution
        Random rnd;                                 //random number generator
        
        try {
            if ((result != null) && result.isMatchType()) {
                solutionSet = (MatchResult)result;
                
                rnd = new Random(System.currentTimeMillis());
                index1 = 0;
                index2 = 0;

                namesList = new ArrayList<>();
                solutionList = new ArrayList<>();
                solutionOrder = new ArrayList<>();

                newSolutionName = (heuristicType + "_" + SolverConst.COMPOUNDSOLUTION);
                newCompSoln = new HyperCompoundSolution(newSolutionName);
                resultList = solutionSet.getSolutionMatches();

                if (resultList.size() > 0) {
                    //calculate how many mutations are allowed based on current solution
                    //number and the maximum allowed solution number
                    rm = calculateRM(resultList);
                    remove = rm.get(0);
                    mutate = rm.get(1);

                    //perform the allowed number of mutations
                    for (i = 0; i < resultList.size(); i++)
                    {
                        solution1 = null;
                        solution2 = null;
                        newSolution1 = null;
                        newSolution2 = null;
                        if (remove[i] > 0) removeWhich = rnd.nextInt(2);
                        else removeWhich = -1;                   
                        if (mutate[i] < 2) mutateWhich = rnd.nextInt(2);
                        else mutateWhich = -1;

                        solutionMatch = (MatchPairName) resultList.get(i);
                        solutionName = solutionMatch.firstName;
                        if (solutionName != null) {
                            solution1 = (GeneticSolution) this.solutionSet.get(solutionName);

                            if ((removeWhich != 0) && !solutionOrder.contains(solutionName)) {
                                solutionOrder.add(solutionName);
                                namesList.add(solutionName);
                                solutionList.add(solution1);
                            }

                            index1 = solutionOrder.indexOf(solutionName);
                        }

                        solutionName = solutionMatch.secondName;
                        if (solutionName != null) {
                            solution2 = (GeneticSolution) this.solutionSet.get(solutionName);

                            if ((removeWhich != 1) && !solutionOrder.contains(solutionName)) {
                                solutionOrder.add(solutionName);
                                namesList.add(solutionName);
                                solutionList.add(solution2);
                            }

                            index2 = solutionOrder.indexOf(solutionName);
                        }

                        //sort the indexes
                        if (index2 < index1) {
                            tempIndex = index1;
                            index1 = index2;
                            index2 = tempIndex;
                        }

                        //add 2 to index2 because of index1 entry before this is added
                        //also needs to be added at least one entry after existing solution
                        index2 += 2;
                        if ((solution1 != null) && (solution2 != null)) {
                            if (!solution1.getChromosome().sameAs(solution2.getChromosome())) {
                                newSolutionName = NameHandler.createSolutionName(solution1.getName(),
                                        solution2.getName(), namesList);

                                if (heuristicOptions.isEmpty() || (getCrossover(heuristicOptions) != null) || 
                                        (getMutate(heuristicOptions) != null)) {
                                    if ((mutateWhich == 1) && (heuristicOptions.isEmpty() || 
                                            (getCrossover(heuristicOptions) != null))) {
                                        solution1.getChromosome().getEvolveGenes().clearEvolveTypes();                                    
                                        solution1.getChromosome().getEvolveGenes().addEvolveType(getCrossover(heuristicOptions));                                   
                                        newSolution1 = (GeneticSolution)solution1.evolve(newSolutionName, solution2);
                                        newSolution1.addCreatedFrom(solution1.getName());
                                        newSolution1.addCreatedFrom(solution2.getName());
                                        namesList.add(newSolutionName);

                                        newSolutionName = NameHandler.createSolutionName(solution1.getName(),
                                            solution2.getName(), namesList);
                                    }

                                    if ((mutateWhich == 0) && (heuristicOptions.isEmpty() || 
                                            (getMutate(heuristicOptions) != null))) {
                                        //throw an exception if no evolve type is registered
                                        mutateType = getMutate(heuristicOptions);

                                        if (mutateType == null) {
                                            throw new LicasException("Genetic Hyper Problem: No evolve types have been specified.");
                                        }

                                        solution1.getChromosome().getEvolveGenes().clearEvolveTypes();                             
                                        solution1.getChromosome().getEvolveGenes().addEvolveType(mutateType);
                                        newSolution2 = (GeneticSolution)solution1.evolve(newSolutionName, solution2);
                                        newSolution2.addCreatedFrom(solution1.getName());
                                        newSolution2.addCreatedFrom(solution2.getName());
                                        namesList.add(newSolutionName);
                                    }
                                }
                                else {
                                    //no evolution options available, so solve using only
                                    //solve using only one mutate type, selected randomly
                                    if (rnd.nextInt(2) == 0) {
                                        mutateType = getMutate(heuristicOptions);
                                        if (mutateType == null) mutateType = getCrossover(heuristicOptions);
                                    }
                                    else {
                                        mutateType = getCrossover(heuristicOptions);
                                        if (mutateType == null) mutateType = getMutate(heuristicOptions);
                                    }                            

                                    //throw an exception if no evolve type is registered
                                    if (mutateType == null) {
                                        throw new LicasException("Genetic Hyper Problem: No evolve types have been specified.");
                                    }

                                    solution1.getChromosome().getEvolveGenes().clearEvolveTypes();
                                    solution1.getChromosome().getEvolveGenes().addEvolveType(mutateType);                                
                                    newSolution1 = (GeneticSolution)solution1.evolve(newSolutionName, solution2);
                                    newSolution1.addCreatedFrom(solution1.getName());
                                    newSolution1.addCreatedFrom(solution2.getName());
                                    namesList.add(newSolutionName);
                                }

                                if (newSolution1 == null) {
                                    newSolution1 = newSolution2;
                                }

                                if (newSolution1 != null) {
                                    if (index1 > 0)
                                        pos1 = rnd.nextInt(index1); 
                                    else
                                        pos1 = 0;

                                    solutionList.add(pos1, newSolution1);
                                    solutionOrder.add(pos1, newSolution1.getName());
                                }
                            }
                        }
                        else {
                            return false;
                        }
                    }

                    for (i = 0; i < solutionList.size(); i++)
                    {
                        solution1 = (GeneticSolution)solutionList.get(i);
                        newCompSoln.addSolution(solution1);
                        this.solutionSet.put(solution1.getName(), solution1);
                    }
                }

                solutionHierarc.add(newCompSoln);
                if (calcResultsBetter(solutionSet)) {
                    bestResult = solutionSet;
                }

                calcTestEnded(solutionSet);            
                return !newCompSoln.getSolutions().isEmpty();
            }
            
            return false;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "updateSolutions", null, ex);
        }
    }
    
    /**
     * Calculate for each solution pair, whether to remove or mutate the
     * solution pair for the next processing stage.
     * @param matchPairs list of existing solution pairs.
     * @return a value for each solution pair that defines what to do.
     */
    private ArrayList<int[]> calculateRM(ArrayList<MatchPair> matchPairs)
    {
        int i;
        int nextIndex;                          //next index
        int solutionNumber;                     //number of existing solutions
        int newSolutionNumber;                  //new solutions number
        int[] remove;                           //number to remove
        int[] mutate;                           //number of mutations
        String solutionName;                    //solution name
        ArrayList<Integer> numberList;          //list of numbers
        ArrayList<String> nameList;             //list of names
        ArrayList<int[]> rm;                    //remove or mutate
        MatchPairName solutionMatch;            //solution matches
        Random rnd;                             //random number generator
        
        rnd = new Random(System.currentTimeMillis());
        solutionNumber = matchPairs.size();
        remove = new int[solutionNumber];
        mutate = new int[solutionNumber];        
        numberList = new ArrayList<>();
        rm = new ArrayList<>();

        for (i = 0; i < solutionNumber; i++)
        {
            remove[i] = 0;
            mutate[i] = 2;
            numberList.add(new Integer(i));
        }
        
        //new solutions ideally original solutions plus (2 x list for both mutations)
        //count number of unique original solutions
        nameList = new ArrayList<>();
        for (i = 0; i < matchPairs.size(); i++)
        {
            solutionMatch = (MatchPairName) matchPairs.get(i);

            solutionName = solutionMatch.firstName;
            if (!nameList.contains(solutionName)) {
                nameList.add(solutionName);
            }

            solutionName = solutionMatch.secondName;
            if (!nameList.contains(solutionName)) {
                nameList.add(solutionName);
            }
        }
        
        newSolutionNumber = (numberList.size() + (matchPairs.size() * 2));
        if (newSolutionNumber > maxSolutionsNumber) {
            for (i = maxSolutionsNumber; (i < newSolutionNumber) && !numberList.isEmpty(); i += 2)
            {
                nextIndex = rnd.nextInt(numberList.size());
                remove[numberList.get(nextIndex).intValue()]++;
                mutate[numberList.get(nextIndex).intValue()]--;
                numberList.remove(nextIndex);
            }
        }
        
        rm.add(remove);
        rm.add(mutate);       
        return rm;
    }
    
    /**
     * Get the crossover type or null if none exist.
     * @param mutateTypes the list of evolve types.
     * @return the specified crossover type if it exists.
     */
    private String getCrossover(HashMap<String, ?> mutateTypes)
    {
        if (mutateTypes.containsKey(SolverConst.CROSSOVERPERCENT))
            return SolverConst.CROSSOVERPERCENT;                                   
        else if (mutateTypes.containsKey(SolverConst.CROSSOVER))
            return SolverConst.CROSSOVER;
        
        return null;
    }
    
    /**
     * Get the mutate type or null if none exist.
     * @param mutateTypes the list of evolve types.
     * @return the specified mutate type if it exists.
     */
    private String getMutate(HashMap<String, ?> mutateTypes)
    {
        if (mutateTypes.containsKey(SolverConst.MUTATEPERCENT))
            return SolverConst.MUTATEPERCENT;                                   
        else if (mutateTypes.containsKey(SolverConst.MUTATE))
            return SolverConst.MUTATE;
        
        return null;
    }
    
    /**
     * Set the fraction of gene to crossover with another gene.
     * @param thisCrossoverFraction the fraction of gene to crossover.
     */
    public void setCrossoverFraction(float thisCrossoverFraction)
    {
        crossoverFraction = thisCrossoverFraction;
    }
    
    /**
     * Get the fraction of gene to crossover with another gene.
     * @return the value of crossoverFraction.
     */
    public float getCrossoverFraction()
    {
        return crossoverFraction;
    }
    
    /**
     * Set the fraction of gene to mutate with another gene.
     * @param thisMutateFraction the fraction of gene to mutate.
     */
    public void setMutateFraction(float thisMutateFraction)
    {
        mutateFraction = thisMutateFraction;
    }
    
    /**
     * Get the fraction of gene to mutate with another gene.
     * @return the value of mutateFraction.
     */
    public float getMutateFraction()
    {
        return mutateFraction;
    }
}
