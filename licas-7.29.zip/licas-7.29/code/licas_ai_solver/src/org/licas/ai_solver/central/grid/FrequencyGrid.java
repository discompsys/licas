/*
 * FrequencyGrid.java
 *
 * Created on 21 February 2017
 *
 * Version 1.4.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.central.grid;


import org.ai_heuristic.eval.result.Cluster;
import org.ai_heuristic.eval.result.ClusterResult;
import org.ai_heuristic.eval.result.Result;
import org.licas.ai_solver.central.grid.metric.GridMetric;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.util.SolverConst;
import org.licas.util.HeuristicConst;
import org.licas.util.ObjectHandler;
import org.licas.util.TypeConst;

import org.ai_heuristic.eval.metric.MetricDataset;
import org.ai_heuristic.eval.metric.MetricValue;
import org.ai_heuristic.util.SymbolHandler;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.StringHandler;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * This grid compares data rows of objects for similarity and creates an entropy-style cluster set
 * based on objects with the same count value.
 * <p>
 * The Input can be an ArrayList of ArrayList of: strings (concepts) or {@link MetricValue}s 
 * that are concepts (getName()) with scores (getValue() of type Double).
 * If scores are present, the count in incremented by the score, if concepts only, then the increment is 1.
 * Memory use is a problem, but it should be OK for 5000 or more concepts, or a 5000 x 5000 grid.
 * </p><p>
 *  There are two clustering versions, labelled as {@link SolverConst}.{@code FREQGRIDV1} or .{@code FREQGRIDV2}.
 * The first version probably produces more clusters but maybe also more isolated rows.
 * The second version probably produces fewer clusters but also fewer isolated rows.
 * </p>
 * @author Kieran Greer
 */
public class FrequencyGrid<T> extends HyperHeuristicGrid
{
    /** For logging errors */
    private static final Logger logger;


    /** The name of the grid */
    protected String gridName;

    /**
     * Which version to use. Can be {@link SolverConst}.{@code FREQGRIDV1} or {@code FREQGRIDV2}.
     */
    protected String version;

    /** List of unique categories in the input data. Also used for the ordering. */
    protected ArrayList<T> categories;

    /** List of input events to count for comparisons */
    private ArrayList<ArrayList<T>> gridEvents;

    /** The grid with cumulated association counts, may have different structure to the event rows */
    protected ArrayList<ArrayList<Double>> grid;

    /**
     * May be useful to store a numerical value for each category, so if input is MetricDataset, can do this.
     * Key would be dataset name or category and value can be the related numerical value, preferably of type double.
     */
    private HashMap<String, T> cellValue;
    
    /** Category clusters, each row is a separate cluster */
    private ArrayList<ArrayList<CellCount>> clusters;
    
    /** Dataset value tokenizer */
    private String tokenizer;
    

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(FrequencyGrid.class.getName());
        logger.setDebug(false);
    }
    
    
    /**
     * Create a new instance of FrequencyGrid. Larger value assumed to be better.
     * @param testSpec the test specification. The only required fields are:<br>
     * 1. {@code testSpec.getTestScript().tokenizer} is the dta tokenizer, e.g. {@link SymbolHandler}.{@code CA}, and <br>
     * 2. {@code testSpec.getTestScript().metricType} is the cluster algorithm choice, e.g. {@link SolverConst}.{@code FREQGRIDV1}.
     */
    public FrequencyGrid(TestSpec testSpec)
    {
        super();
        initialise(testSpec);
    }

    /** 
     * Initialise some values. 
     * @param testSpec the test specification.
     */
    private void initialise(TestSpec testSpec)
    {
        gridType = HeuristicConst.FREQUENCY;
        tokenizer = testSpec.getTestScript().tokenizer;
        version = testSpec.getTestScript().metricType;
        resetValues();
    }
    
    /** Reset some values */
    public void resetValues()
    {
        gridEvents = new ArrayList<>();
        grid = new ArrayList<>();
        categories = new ArrayList<>();
        clusters = new ArrayList<>();
        cellValue = new HashMap<>();
        gridSolution = new ClusterResult();
    }

    /**
     * Initialise the data for solving.
     * @throws Exception any error.
     */
    protected void initialiseData() throws Exception
    {
        int i;
        ArrayList<T> dataRow;                       //data row

        try {
            reFormat();

            //sort the category list for all data rows
            for (i = 0; i < gridEvents.size(); i++)
            {
                dataRow = gridEvents.get(i);
                newCategories(dataRow);
            }

            //initialise the grid to have a row for each category type
            newGridRows();
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "initialiseData", null, ex);
        }
    }

    /**
     * Check if the data row contains new categories and add to {@code categories} list.
     * @param catRow the data row with category names.
     * @return true if any new categories are added.
     */
    public boolean newCategories(ArrayList<T> catRow)
    {
        int i;
        boolean isNew = false;              //true if new
        T nextConcept;                      //next concept

        for (i = 0; i < catRow.size(); i++)
        {
            nextConcept = catRow.get(i);
            if (!categories.contains(nextConcept)) {
                categories.add(nextConcept);
                isNew = true;
            }
        }

        if (isNew) {
            newGridRows();
        }

        return isNew;
    }

    /**
     * Add new row and column cells for any new categories.
     */
    protected void newGridRows()
    {
        int i, j;
        ArrayList<Double> gridRow;                  //grid row
        ArrayList<ArrayList<Double>> newGridRows;   //new grid rows

        //add to end of existing rows or create completely new rows
        newGridRows = new ArrayList<>();
        for (i = 0; i < categories.size(); i++)
        {
            if (grid.size() > i) {
                gridRow = grid.get(i);
            }
            else {
                gridRow = new ArrayList<>();
                newGridRows.add(gridRow);
            }

            for (j = gridRow.size(); j < categories.size(); j++)
            {
                gridRow.add(0.0);
            }
        }

        //add the completely new rows to the grid
        for (i = 0; i < newGridRows.size(); i++)
        {
            grid.add(newGridRows.get(i));
        }
    }


    /**
     * Solve the currently saved grid.
     * @param theGridMetric the comparison metric to use.
     * @throws java.lang.Exception any error.
     */
    public void solve(GridMetric theGridMetric) throws Exception
    {
        int i;
        ArrayList<T> dataRow;                       //data row

        try {
            gridMetric = theGridMetric;
            initialiseData();
            
            //add the counts first if data is entered as a single gridCells block
            //the alternative is to add incrementally using newCategories and frequencyCounts
            for (i = 0; i < gridEvents.size(); i++)
            {
                dataRow = gridEvents.get(i);
                frequencyCounts(dataRow);
            }

            //then calculate the best matching groups based on frequency counts
            clusters();
        }    
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "solve", null, ex);
        }
    }

    /**
     * Update the frequency counts for the cells in the data row - rows and columns.
     * @param dataRow the data row with the cell names.
     * @throws Exception any error.
     */
    public void frequencyCounts(ArrayList<T> dataRow) throws Exception
    {
        int i, j;
        int d1, d2;                                 //array indexes
        T nextConcept;                              //next concept
        T nextConcept2;                             //next concept
        ArrayList<Double> gridRow;                  //grid row

        try {
            for (i = 0; i < dataRow.size(); i++)
            {
                nextConcept = dataRow.get(i);
                d1 = categories.indexOf(nextConcept);

                gridRow = grid.get(d1);
                for (j = 0; j < dataRow.size(); j++)
                {
                    if (j != i) {
                        nextConcept2 = dataRow.get(j);
                        d2 = categories.indexOf(nextConcept2);
                        gridRow.set(d2, (gridRow.get(d2) + 1.0));
                    }
                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "frequencyCounts", null, ex);
        }
    }

    /**
     * Determine the best clusters based on the frequency counts and the selected {@code version}.
     * @throws java.lang.Exception any error.
     */
    public void clusters() throws Exception
    {
        if (version.equals(SolverConst.FREQGRIDV1)) clustersV1();
        else clustersV2();
    }

    /**
     * Determine the best clusters based on the frequency counts.
     * This is the first version that probably produces more clusters but maybe also more isolated rows.
     * @throws java.lang.Exception any error.
     */
    protected void clustersV1() throws Exception
    {
        int i, j, k;
        boolean isLarger;                               //true if larger count
        int d1, d11, d2;                                //array indexes
        int bestIndex;                                  //best index
        double nextCount;                               //next count
        double bestCount;                               //best count
        double count;                                   //count value
        double count2;                                  //count value
        ArrayList<T> catList;                           //category list
        ArrayList<T> dataRow;                           //data row
        ArrayList<ArrayList<Integer>> clusterIndexes;   //cluster indexes
        ArrayList<Integer> nextClusterIndexes;          //next cluster indexes
        ArrayList<CellCount> nextCluster;               //next cluster
        CellCount cellCount;                            //cell count
        Object keyConcept;                              //key concept
        Object nextConcept;                             //next concept
        Object nextConcept2;                            //next concept

        try {
            //need to add the matching counts first
            catList = (ArrayList<T>)categories.clone();
            clusters = new ArrayList<>();
            clusterIndexes = new ArrayList<>();

            while (!catList.isEmpty())
            {
                keyConcept = catList.get(0);
                d1 = categories.indexOf(keyConcept);

                nextCluster = new ArrayList<>();
                count = grid.get(d1).get(d1);
                cellCount = new CellCount();
                cellCount.value = keyConcept;
                cellCount.count = count;
                nextCluster.add(cellCount);

                clusters.add(nextCluster);
                clusterIndexes.add(new ArrayList());

                //sort all other concepts in the group
                for (i = 1; i < catList.size(); i++)
                {
                    nextConcept = catList.get(i);
                    if (!nextConcept.equals(keyConcept)) {
                        isLarger = false;
                        d2 = categories.indexOf(nextConcept);
                        count = grid.get(d1).get(d2);

                        if (count > 0) {
                            //if category has larger count with something else then do not add
                            for (j = 0; !isLarger && (j < catList.size()); j++)
                            {
                                nextConcept2 = catList.get(j);
                                if (!keyConcept.equals(nextConcept2)) {
                                    d11 = categories.indexOf(nextConcept2);
                                    count2 = grid.get(d11).get(d2);
                                    isLarger = (count2 > count);
                                }
                            }

                            if (!isLarger) {
                                cellCount = new CellCount();
                                cellCount.value = nextConcept;
                                cellCount.count = count;
                                nextCluster.add(cellCount);
                            }
                        }
                    }
                }

                //remove the concepts from the cloned concepts list
                for (i = 0; i < nextCluster.size(); i++)
                {
                    cellCount = nextCluster.get(i);
                    catList.remove(cellCount.value);
                }
            }

            //sort the rows into which contain numerically the most of each category,
            //matching with larger category counts is favoured, not based on percentages
            for (i = 0; i < gridEvents.size(); i++)
            {
                bestIndex = -1;
                bestCount = -1;
                dataRow = gridEvents.get(i);

                for (j = 0; j < clusters.size(); j++)
                {
                    nextCount = 0;
                    nextCluster = clusters.get(j);

                    for (k = 0; k < nextCluster.size(); k++)
                    {
                        cellCount = nextCluster.get(k);
                        if (contains((T) cellCount.value, dataRow)) {
                            nextCount++;
                        }
                    }

                    if (nextCount > bestCount) {
                        bestCount = nextCount;
                        bestIndex = j;
                    }
                }

                if (bestIndex >= 0) {
                    nextClusterIndexes = clusterIndexes.get(bestIndex);
                    nextClusterIndexes.add(new Integer(i+1));
                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "clustersV1", null, ex);
        }
    }

    /**
     * Determine the best clusters based on the frequency counts.
     * This is the second version that probably produces fewer clusters but also fewer isolated rows.
     * @throws java.lang.Exception any error.
     */
    protected void clustersV2() throws Exception
    {
        int i, j, k;
        int index1, index2;                             //indexes
        int listIndex;                                  //list index
        int nameIndex;                                  //name index
        double count, count2;                           //count value
        ArrayList<Integer> indexList;                   //index list
        ArrayList<CellCount> countList;                 //list of counts
        ArrayList<ArrayList<CellCount>> bestCounts;     //nodes with top count for each node
        ArrayList<ArrayList<Integer>> clusterIndexes;   //cluster indexes
        CellCount cellCount;                            //count and value

        try {
            clusters = new ArrayList<>();
            clusterIndexes = new ArrayList<>();
            bestCounts = new ArrayList<>();

            for (i = 0; i < grid.size(); i++)
            {
                countList = new ArrayList<>();
                bestCounts.add(countList);

                for (j = 0; j < grid.get(i).size(); j++)
                {
                    if (i != j) {
                        count = grid.get(i).get(j);
                        listIndex = -1;

                        for (k = 0; k < countList.size(); k++)
                        {
                            count2 = (int)countList.get(k).count;
                            if (count > count2) {
                                listIndex = j;
                                break;
                            }
                        }

                        if ((listIndex == -1) && countList.isEmpty()) {
                            cellCount = new CellCount();
                            cellCount.count = count;
                            cellCount.value = j;
                            countList.add(cellCount);
                        }
                        else if (listIndex >= 0) {
                            cellCount = new CellCount();
                            cellCount.count = count;
                            cellCount.value = listIndex;

                            countList.clear();
                            countList.add(cellCount);
                        }
                    }
                }
            }

            //add each node to a cluster that contains the first ordered count
            for (i = 0; i < bestCounts.size(); i++)
            {
                countList = bestCounts.get(i);
                cellCount = countList.get(0);
                count = cellCount.count;
                nameIndex = (int)cellCount.value;
                index1 = -1;
                index2 = -1;

                for (j = 0; (index1 == -1) && (j < clusterIndexes.size()); j++)
                {
                    indexList = clusterIndexes.get(j);
                    for (k = 0; k < indexList.size(); k++)
                    {
                        if (indexList.get(k) == i) {
                            index1 = j;
                        }
                    }
                }

                for (j = 0; (index2 == -1) && (j < clusterIndexes.size()); j++)
                {
                    indexList = clusterIndexes.get(j);
                    for (k = 0; k < indexList.size(); k++)
                    {
                        if (indexList.get(k) == nameIndex) {
                            index2 = j;
                        }
                    }
                }

                if (index1 >= 0) {
                    indexList = clusterIndexes.get(index1);
                    countList = clusters.get(index1);

                    if (!indexList.contains(nameIndex)) {
                        indexList.add(new Integer(nameIndex));
                        cellCount = new CellCount();
                        cellCount.count = count;
                        cellCount.value = categories.get(nameIndex);
                        countList.add(cellCount);
                    }

                    if ((index2 != index1) && (index2 >= 0)) {
                        indexList = clusterIndexes.get(index2);
                        countList = clusters.get(index2);

                        for (k = 0; k < indexList.size(); k++) {
                            if (!clusterIndexes.get(index1).contains(indexList.get(k))) {
                                clusterIndexes.get(index1).add(indexList.get(k));
                                clusters.get(index1).add(countList.get(k));
                            }
                        }

                        clusterIndexes.remove(index2);
                        clusters.remove(index2);
                    }
                }
                else if (index2 >= 0) {
                    indexList = clusterIndexes.get(index2);
                    countList = clusters.get(index2);

                    if (!indexList.contains(i)) {
                        indexList.add(new Integer(i));
                        cellCount = new CellCount();
                        cellCount.count = count;
                        cellCount.value = categories.get(i);
                        countList.add(cellCount);
                    }
                }
                else {
                    indexList = new ArrayList<>();
                    indexList.add(new Integer(i));
                    indexList.add(new Integer(nameIndex));
                    clusterIndexes.add(indexList);

                    countList = new ArrayList<>();
                    cellCount = new CellCount();
                    cellCount.count = 0;
                    cellCount.value = categories.get(i);
                    countList.add(cellCount);
                    cellCount = new CellCount();
                    cellCount.count = count;
                    cellCount.value = categories.get(nameIndex);
                    countList.add(cellCount);
                    clusters.add(countList);
                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "clustersV2", null, ex);
        }
    }
    
    /**
     * Convert the clustered cell lists into {@link Cluster} objects as the solution
     * and store in a {@link ClusterResult}.
     * @throws Exception any error.
     */
    private void clustersToSolutions() throws Exception
    {
        int i, j;
        ArrayList<CellCount> nextCluster;           //next cluster
        CellCount cellCount;                        //cell count
        Cluster cluster;                            //new cluster
        
        gridSolution = new ClusterResult();
        for (i = 0; i < clusters.size(); i++)
        {
            cluster = new Cluster(Cluster.toKey(i));
            
            nextCluster = clusters.get(i);
            for (j = 0; j < nextCluster.size(); j++)
            {
                cellCount = nextCluster.get(j);
                cluster.list.add(cellCount.value);
            }

            if (!((ClusterResult)gridSolution).containsKey(cluster.name) &&
                !((ClusterResult)gridSolution).containsCluster(cluster.list)) {
                ((ClusterResult) gridSolution).addCluster(cluster);
            }
        }
    }
    
    /**
     * Return true if the data row contains the object value.
     * @param value the data value.
     * @param dataRow the data row.
     * @return true if the row contains the value.
     * @throws Exception any error.
     */
    private boolean contains(T value, ArrayList<T> dataRow) throws Exception
    {
        int i;
        Object v1, v2;                      //values

        for (i = 0; i < dataRow.size(); i++)
        {
            try {
                if (gridMetric.isSame(dataRow.get(i), value)) return true;
            }
            catch (Exception ex) {
                v1 = ObjectHandler.valueFromString(gridMetric.dataType(),
                        ObjectHandler.valueToString(gridMetric.dataType(), dataRow.get(i)));
                v2 = ObjectHandler.valueFromString(gridMetric.dataType(),
                        ObjectHandler.valueToString(gridMetric.dataType(), value));
                if (gridMetric.isSame(v1, v2)) return true;
            }
        }
        
        return false;
    }
    
    /**
     * Re-format the grid cells, maybe creating the cellValue list if appropriate.
     * The result should be a list of categorical names from the input. 
     * This would also require a uniform input of values for all concepts in each row, 
     * so probably not useful at the moment.
     */
    private void reFormat()
    {
        int i;
        ArrayList<T> dataRow;                       //data row
        ArrayList<ArrayList<T>> catRows;            //categorical rows
        ArrayList<ArrayList<T>> dataset;            //whole dataset
        MetricDataset md;                           //metric dataset
        Object valueObj;                            //value object
        
        dataset = new ArrayList<>();
        catRows = new ArrayList<>();
        
        for (i = 0; i < gridEvents.size(); i++)
        {
            valueObj = gridEvents.get(i);
            dataRow = new ArrayList<>();

            if (valueObj instanceof MetricDataset) {
                md = (MetricDataset)valueObj;

                if (md.getValueType().equals(TypeConst.STRING)) {
                    //if value type is string, can then add list as category list
                    //can also try to convert to tokenized list from CSV, if stored that way
                    if (md.isSingleValue()) {
                        valueObj = md.getFirstValue();
                        dataRow = (ArrayList<T>) StringHandler.tokenize((String)valueObj, tokenizer, false);

                        //add to cell-value list for possible processing (research)
                        cellValue.put(md.getName(), (T)valueObj);
                    }
                    else {
                        md.resetValueIterator();
                        while (md.hasNextValue())
                        {
                            dataRow.add((T) md.getNextValue());
                        }
                    }

                }
                else {
                    //if value type is numerical, then this is dummy execution to allow process to complete
                    dataRow.add((T) md.getName());
                }

                catRows.add(dataRow);
            }
        }
        
        if (!catRows.isEmpty()) {
            dataset = catRows;
        }
        else {
            for (i = 0; i < gridEvents.size(); i++)
            {
                dataRow = gridEvents.get(i);
                dataset.add(dataRow);
            }
        }
        
        gridEvents = dataset;
    }
    
    /**
     * Set the name of the grid.
     * @param theGridName the name of the grid.
     */
    public void setGridName(String theGridName)
    {
        gridName = theGridName;
    }

    /**
     * Set the array of grid of cell values to process.
     * @param theGridCells the array of cell values.
     */
    public void copyGridCells(ArrayList<MetricDataset> theGridCells)
    {
        int i;
        ArrayList<T> dataRow;                   //data row
        Object dataObj;                         //data object

        gridEvents.clear();
        for (i = 0; i < theGridCells.size(); i++) {
            dataObj = theGridCells.get(i).getFirstValue();
            if (dataObj instanceof MetricValue) {
                dataRow = (ArrayList<T>)((MetricValue)dataObj).getValue();
            }
            else {
                dataRow = (ArrayList<T>)dataObj;
            }

            gridEvents.add(dataRow);
        }
    }

    /**
     * Set the list of event values to convert into the grid of frequency counts.
     * @param theGridEvents the array of event values.
     */
    public void setGridEvents(ArrayList<ArrayList<T>> theGridEvents)
    {
        gridEvents = theGridEvents;
    }

    /**
     * Get the list of event values, before they have been converted into frequency counts.
     * @return the value of gridEvents.
     */
    public ArrayList<ArrayList<T>> getGridEvents()
    {
        return gridEvents;
    }

    /**
     * Set the grid of frequency counts and related list of categories directly.
     * @param theCategories the list of row or column categories, instead of extracting from the events.
     * @param theGrid the grid of frequency counts - relates to after processing the events.
     */
    public void setCategoriesGrid(ArrayList<T> theCategories, ArrayList<ArrayList<Double>> theGrid)
    {
        categories = theCategories;
        grid = theGrid;
    }
    
    /**
     * Get the list of concepts grouped together into each cluster.
     * @return the value of clusters.
     */
    public ArrayList<ArrayList<CellCount>> getClusters()
    {
        return clusters;
    }
    
    /**
     * Get the list of solutions that are part of a best match.
     * @return the best matching solutions that optimise the score.
     * @throws Exception any error.
     */
    public Result getGridSolution() throws Exception
    {
        clustersToSolutions();
        return gridSolution;
    }
    
    /**
     * Get a string-based representation of the grid.
     * @return string-based description.
     */
    private String gridToString()
    {
        int i, j;
        StringBuilder gridStr;              //grid as string
        ArrayList<Double> gridRow;          //grid row
        
        gridStr = new StringBuilder((String.valueOf(categories) + "\n"));
        for (i = 0; i < grid.size(); i++)
        {
            gridRow = grid.get(i);
            for (j = 0; j < gridRow.size(); j++)
            {
                gridStr.append(String.valueOf(gridRow.get(j) + ", "));
            }
            
            gridStr.append("\n");
        }
        
        return gridStr.toString();
    }
}
