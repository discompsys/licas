/*
 * EvaluationSet.java
 *
 * Created on 11 March 2013
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.model;


import org.ai_heuristic.eval.metric.ReplySet;
import org.ai_heuristic.eval.result.EvalBounds;

import java.util.ArrayList;


/**
 * A list of {@link EvalBounds} objects representing a larger evaluation set.
 * @author Kieran Greer
 */
public class EvaluationSet
{
    /** List of {@link EvalBounds} evaluations */
    protected ArrayList<EvalBounds> evaluationList;
    
    
    /**
     * Create a new instance of EvalutionSet.
     * @param thisEvalSet a list of {@link EvalBounds} objects representing a set of evaluations.
     */
    protected EvaluationSet(ArrayList<EvalBounds> thisEvalSet)
    {
        evaluationList = thisEvalSet;
    }
    
    
    /**
     * Get the {@code EvalBounds} object at the specified index.
     * @param index the index in the list.
     * @return the evaluation object at that index.
     */
    public EvalBounds get(int index)
    {
        return evaluationList.get(index);
    }
    
    /**
     * Get the number of elements in the list.
     * @return the size of {@code evaluationList}.
     */
    public int size()
    {
        return evaluationList.size();
    }
    
    /**
     * Create a new instance of EvalutionSet.
     * @param thisEvalSet a list, preferably of {@link EvalBounds} objects representing a set of evaluations.
     * If the objects are a different type, an EvalBounds wrapper is created.
     * @return the created EvaluatonSet.
     */
    public static EvaluationSet toSet(ArrayList<?> thisEvalSet)
    {
        int i;
        ArrayList<EvalBounds> setList;          //set list
        Object objType;                         //object type
        
        setList = new ArrayList();
        for (i = 0; i < thisEvalSet.size(); i++)
        {
            objType = thisEvalSet.get(i);
            if (objType instanceof EvalBounds) {
                setList.add((EvalBounds) objType);
            }
            else {
                setList.add(new EvalBounds(objType));
            }
        }

        return new EvaluationSet(setList);
    }
    
    /**
     * Create a new instance of EvalutionSet.
     * @param replySet a reply set that should store a {@code ArrayList} of objects. 
     * If the objects are a different type, an EvalBounds wrapper is created.
     * @return the created EvaluatonSet.
     */
    public static EvaluationSet toSet(ReplySet replySet)
    {
        int i;
        ArrayList<EvalBounds> setList;          //set list
        ArrayList<Object> thisEvalSet;          //reply list
        Object objType;                         //object type
        
        try
        {
            setList = new ArrayList<>();
            thisEvalSet = (ArrayList)replySet.getValue();

            for (i = 0; i < thisEvalSet.size(); i++)
            {
                objType = thisEvalSet.get(i);
                if (objType instanceof EvalBounds) {
                    setList.add((EvalBounds) objType);
                }
                else {
                    setList.add(new EvalBounds(objType));
                }
            }

            return new EvaluationSet(setList);
        }
        catch (Exception ex) {}
        
        return null;
    }
}
