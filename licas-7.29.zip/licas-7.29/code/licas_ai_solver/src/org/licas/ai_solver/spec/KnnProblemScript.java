/*
 * KnnProblemScript.java
 *
 * Created on 29 March 2016
 *
 * Version 1.0.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.spec;


import org.ai_heuristic.algo.cluster.knn.KnnConfig;
import org.ai_heuristic.util.AiHeuristicConst;

import org.licas.service.spec.BehaviourScript;
import org.licas.PasswordHandler;
import org.licas.data.gen.DataGenerator;
import org.licas.util.HeuristicConst;
import org.licas.util.ServiceConst;


/**
 * This class reads an XML file and loads in a specification for a set of test runs.
 * This includes some additional variables for the KNN nearest neighbour-type of tests.
 * @author Kieran Greer
 */
public class KnnProblemScript extends ProblemScript
{
    /** Configuration values specific to the knn */
    public KnnConfig knnConfig;
    
    
    /** 
     * Create a new instance of KnnProblemScript.
     * @param thePasswordHandler for storing passwords.
     */
    public KnnProblemScript(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        knnConfig = new KnnConfig();
    }
    
    /**
     * Convert the set of values into the structure to be used to initialise the test services.
     * this depends on the framework, or solver type. The script is already setup for the 
     * centralised problem-solving and so does not need to be changed for that, for example,
     * but the distributed linking can be more easily initialised as the behaviour tests.
     * @return true if converted OK.
     */
    public boolean convertForInitialise()
    {
        String generatorClass;                      //generator class
        
        //only add data generator, do not add evaluator, as that is part of the nn
        if (datasetType != null)
        {
            generatorClass = DataGenerator.getGeneratorClass(datasetType);
            if (generatorClass != null)
            {
                serviceClasses.put(ServiceConst.DATAGENERATORTYPE, generatorClass);
            }
        }
                
        return true;
    }
    
    
    /**
     * Copy the behaviour script values into this object.
     * @param behaviourScript the behaviour script.
     */
    public void copy(BehaviourScript behaviourScript)
    {
        if (behaviourScript != null)
        {
            super.copy(behaviourScript);
            
            //som problem script variables
            if (behaviourScript instanceof KnnProblemScript)
            {
                knnConfig = (KnnConfig)((KnnProblemScript)behaviourScript).knnConfig.clone();            
            }
        }
    }
    
    /**
     * Validate the whole script and return a description of any errors.
     * @return a description of any errors or null if OK.
     */
    public String validateScript()
    {
        boolean knnMatch;                       //true if knn solver type
        String validateReply;                   //validation errors
        
        knnMatch = solverType.equals(HeuristicConst.NEARESTNEIGHBOUR);
        validateReply = super.validateScript();
        if (validateReply == null) validateReply = "";
        else validateReply += "\n";
        
        if (knnMatch)
        {
            validateReply += validateVariable(AiHeuristicConst.BS);
            validateReply += validateVariable(AiHeuristicConst.KNN);
        }
        
        validateReply = validateReply.trim();        
        if (validateReply.equals("")) validateReply = null;
        return validateReply;
    }
    
    /**
     * Validate the script variable and return a description if invalid.
     * @param varType the variable type.
     * @return a description of any error, of null if OK.
     */
    protected String validateVariable(String varType)
    {
        String validateError;                   //validate error
        
        validateError = super.validateVariable(varType);
        if ((validateError == null) || validateError.equals(""))
        {
            if (varType.equals(AiHeuristicConst.KNN))
            {
                if (knnConfig.k < 1)
                    validateError = (AiHeuristicConst.KNN + ": must be greater than 0.\n");
            }
        }
        
        return validateError;
    }
}
