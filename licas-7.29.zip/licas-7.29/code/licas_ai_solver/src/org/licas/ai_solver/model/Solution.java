/*
 * Solution.java
 *
 * Created on 6 April 2010
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */


package org.licas.ai_solver.model;


import org.ai_heuristic.eval.result.EvalBounds;
import org.licas.ai_solver.def.SolutionDef;

/**
 * This is the abstract base class for modelling any type of solution. Solutions can store
 * information and results, evolve new solutions or solve the solution.
 * @author Kieran Greer
 */
public abstract class Solution implements SolutionDef
{
    /** The solution name */
    protected String name;
    
    /**
     * The result of evaluating this solution.
     */
    protected EvalBounds evaluation;


    /**
     * Create a new instance of Solution.
     * @throws java.lang.Exception any error.
     */
    public Solution() throws Exception
    {
        super();
    }

    /**
     * Create a new instance of Solution.
     * @param thisName this solution name or ID.
     */
    public Solution(String thisName)
    {
        name = thisName;
    }
    
    /**
     * Set the solution name.
     * @param thisName the solution name.
     */
    public void setName(String thisName)
    {
        name = thisName;
    }
    
    /**
     * Get the solution name.
     * @return the value of name.
     */
    public String getName()
    {
        return name;
    }

    /**
     * Set the evaluation value for the result.
     * @param theEvaluation the evaluation value.
     */
    public void setEvaluation(EvalBounds theEvaluation)
    {
        evaluation = theEvaluation;
    }

    /**
     * Get the result that this solution has produced.
     * @return the value of evaluation.
     */
    public EvalBounds getEvaluation()
    {
        return evaluation;
    }
}
