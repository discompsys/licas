/*
 * HyperCompoundSolution.java
 *
 * Created on 10 August 2010
 *
 * Version 1.3
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.model.comp;


import org.ai_heuristic.eval.result.EvalBounds;
import org.licas.ai_solver.def.SolutionSolveDef;
import org.licas.ai_solver.model.*;
import org.licas.ai_solver.model.central.SingleSolution;
import org.licas.util.MetaConst;
import org.ai_heuristic.eval.metric.ReplySet;
import org.jlog2.*;

import java.util.*;


/**
 * This is a complete implementation of a compound solution for a hyper-heuristic framework.
 * The solutions are solved hthrough the {@code calculateSolution} method.
 * @author Kieran Greer
 */
public class HyperCompoundSolution extends CompoundSolution
{
    /** For logging */
    private static final Logger logger;
    
    /** 
     * The result of evaluating this compound solution. This is optional.
     * For the matching framework, the evaluation object in this can be a {@code HashMap} 
     * where the key is a solution name and the value is a solution result defined as a {@code ArrayList} 
     * of {@code Double} objects, where each value is the result of an evaluation.
     * For other evaluators, it provides a slot to store a combined solution result.
     */
    protected EvalBounds compoundSolutionResult;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(HyperCompoundSolution.class.getName());
        logger.setDebug(false);
    }
        
    /** 
     * Create a new instance of HyperCompoundSolution.
     * @param thisName the solution name or ID.
     */
    public HyperCompoundSolution(String thisName)
    {
        super(thisName);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {}

    
    /**
     * Calculate the result for the solution with the specified solution name.
     * @param solutionName the solution name. Use {@code Const.ALL} for all solutions.
     * @param inputVariables an additional set of input variables or constraints.
     * @throws java.lang.Exception any error.
     */
    public void calculateSolution(String solutionName, HashMap<String, ?> inputVariables) throws Exception
    {
        int i;
        String nextKey;                                     //next key
        HashMap<String, EvalBounds> allSolutionResults;     //all solution results
        SolutionSolveDef nextSolution;                      //next solution
        EvalBounds evalBounds;                              //sub-solution result
        
        allSolutionResults = new HashMap<>();
        compoundSolutionResult = new EvalBounds();
        
        for (i = 0; i < solutionNames.size(); i++)
        {
            nextKey = solutionNames.get(i);
            if (nextKey.equals(solutionName) || solutionName.equals(MetaConst.ALL)) {
                nextSolution = (SolutionSolveDef) solutions.get(nextKey);
                nextSolution.solve(inputVariables);
                evalBounds = nextSolution.getEvaluation();
                allSolutionResults.put(nextKey, evalBounds);
            }
        }

        compoundSolutionResult.evaluation = new ReplySet(allSolutionResults);
    }   
    
    /**
     * Get the result that this compound solution has produced.
     * @return the value of compoundSolutionResult.
     */
    public EvalBounds getSolutionResult()
    {
        return compoundSolutionResult;
    }
    
    /**
     * Clone this object to create a copy of the main features.
     * @return a cloned copy of this object.
     */
    public Object clone()
    {
        HyperCompoundSolution newSolution;          //new compound solution
        
        newSolution = new HyperCompoundSolution(name);
        newSolution.solutionNames = (ArrayList)this.solutionNames.clone();
        newSolution.solutions = (LinkedHashMap)this.solutions.clone();
        return newSolution;
    }
    
    /**
     * Convert the solution container into a hyper compound solution.
     * @param compSoln the solution container to convert.
     * @return a cloned copy of the solution list as a hyper compound one.
     */
    public static HyperCompoundSolution toHyperCompoundSolution(SolutionContainer compSoln)
    {
        HyperCompoundSolution newSolution;          //new compound solution
        
        newSolution = new HyperCompoundSolution(compSoln.getName());
        newSolution.solutionNames = (ArrayList)compSoln.getSolutionNames().clone();
        newSolution.solutions = (LinkedHashMap)compSoln.getSolutions().clone();
        return newSolution;
    }
}
