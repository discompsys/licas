/*
 * ProblemMediatorDef.java
 *
 * Created on 21 November 2015
 *
 * Version 1.1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.def;


import org.ai_heuristic.eval.result.Result;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.stat.ProcessResult;
import org.licas_xml.abs.Element;


/**
 * Additional interface classes for a base solver mediator.
 * @author Kieran Greer
 */
public interface ProblemMediatorDef
{
    /**
     * Copy any values specific to the problem solver classes to the related specific
     * structures, from the more general list of variables from the Problem Spec itself.
     * @param testSpec the model of the tests to perform.
     * @throws java.lang.Exception any error.
     */
    void copyToConfig(TestSpec testSpec) throws Exception;
    
    /**
     * Optimise the solutions using the appropriate framework.
     * @param testSpec the model of the tests to perform.
     * @return clusters of solutions or references from the latest optimisation phase.
     * @throws java.lang.Exception any error.
     */
    Result solve(TestSpec testSpec) throws Exception;
    
    /**
     * Get the results of the test.
     * @return the test results in XML format.
     * @throws java.lang.Exception any error.
     */
    Element getResultXml() throws Exception;
    
    /**
     * Process the result. Also calculate any stats on the clustered solutions.
     * @param solverType the solver used to create the result.
     * @return the results of analysing the clusters.
     * @throws java.lang.Exception any error.
     */
    ProcessResult processResult(String solverType) throws Exception;
}
