/*
 * SomProblemMediator.java
 *
 * Created on 21 October 2014
 *
 * Version 1.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.mediator.problem;


import org.ai_heuristic.eval.result.Result;
import org.licas.ai_solver.central.SomNN;
import org.licas.ai_solver.central.SomConfig;
import org.licas.ai_solver.spec.*;
import org.licas.ai_solver.SolverFactory;
import org.licas.ai_solver.mediator.ProblemSolverMediator;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.util.*;

import org.licas.PasswordHandler;
import org.licas.util.*;
import org.ai_heuristic.data.Dataset;
import org.licas_xml.abs.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;

import java.util.*;
import org.ai_heuristic.eval.metric.MetricDataset;
import org.licas.server.LocalServer;


/**
 * This class models the problem to be solved based on a centralised SOM neural network.
 * This version receives a single input dataset that it then clusters, without solution updates. 
 * It receives its dataset from a single service and suggests links through optimising its self-organising map.
 * @author Kieran Greer
 */
public class SomProblemMediator extends ProblemMediatorCentral
{
    /** For logging errors */
    private static final Logger logger;

    
    /** Configuration values specific to the SOM neural network */
    protected SomConfig somConfig;
    
    /** The SOM neural network */
    protected SomNN somNN;
    
    /** Set of existing weights, maybe from a previous test run */
    protected ArrayList<Double> weights;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SomProblemMediator.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of SomProblemMediator.
     * @param thePasswordHandler for storing passwords.
     */
    public SomProblemMediator(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        somConfig = new SomConfig();
        somNN = new SomNN();
        weights = null;
    }
    
    /**
     * Copy any related values to the som config structure.
     * @param testSpec the model of the tests to perform.
     * @throws java.lang.Exception any error.
     */
    public void copyToConfig(TestSpec testSpec) throws Exception
    {
        SomProblemScript testScript;                           //test script
        
        super.copyToConfig(testSpec);
        testScript = (SomProblemScript)testSpec.getTestScript();
        solverType = testScript.solverType;
        
        somConfig = (SomConfig)testScript.somConfig.clone();       
        somConfig.dataType = TypeConst.DOUBLE;
        somConfig.iterations = testScript.testRunsScript.testRuns;
        somConfig.learningFunction = testScript.heuristicType;
        somConfig.metric = testScript.metricType;
        somConfig.lfParams.putAll((HashMap)testScript.heuristicOptions.clone());
    }
    
    /**
     * Optimise the solutions using the appropriate framework.
     * @param testSpec the model of the tests to perform.
     * @return clusters of solutions or references from the latest optimisation phase.
     * @throws java.lang.Exception any error.
     */
    public Result solve(TestSpec testSpec) throws Exception
    {
        ProblemSolverMediator solverMediator;       //solver mediator
        
        try {
            //retrieve the dataset values and initialise the som nn
            solverMediator = (ProblemSolverMediator)SolverFactory.getInstance().getSolverMediators().createServiceMediator(solverType);
            serviceNames = solverMediator.getServiceNames();
            
            //create the problems with the data
            if (LocalServer.isRunning()) {
                dataHash = solverMediator.getServicesData(testSpec);
            }
            else {
                //can be central file-only test with no server or services
                dataHash = new LinkedHashMap<>();
            }

            createSomData(testSpec, ",");

            //run tests on the neural network
            somNN.initialiseSom(somConfig);
            result = somNN.train();
            weights = somNN.getWeights();
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "solve", null, ex);
        }
        finally {
            //for linking services, the test number is used as the number of
            //datasets or distributed services to compare with and this is carried
            //out during one test iteration, so always end after one iteration
            testEnded = true;
        }
        
        return result;
    }
    
    /**
     * Reset the problem-solving structures for the next run. In this case, remove
     * the named solutions from the list of current ones.
     * @param varList a list of variables as key-value pairs. Can be null in this case.
     * @return true if all are removed, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean resetForNextRun(HashMap<String, ?> varList) throws Exception
    { return true; }
    
    /**
     * Create a new som with the problem datasets. Assumes a single file path for
     * a dataset to load. Also assumes CSV {@code ','}-style separator in the file.
     * @param testSpec the model of the tests to perform.
     * @param separator the tokenizer character.
     * @throws java.lang.Exception any error.
     */
    protected void createSomData(TestSpec testSpec, String separator) throws Exception
    {
        int i;
        String filePath;                                        //dataset file path
        ArrayList<MetricDataset> datasets;                      //list of datasets
        ArrayList<LinkedHashMap<String, Object>> somDataset;    //som dataset
        LinkedHashMap<String, Object> somDataValue;             //som data values
        Element dataElem;                                       //data element
        Element valueElem;                                      //value element
        MetricDataset metricDataset;                            //metric dataset
        Dataset somData;                                   //som data model
        
        filePath = null;
        
        //if only 1 data entry, then maybe a file path to read, so try that first
        if (dataHash.size() == 1) {
            //look for URL address
            try {
                dataElem = (Element)dataHash.values().iterator().next();
                valueElem = dataElem.getChild(Const.VALUE);
                if (valueElem != null) {
                    filePath = valueElem.getText();
                    filePath = UriHandler.removeLocalFileUriPrefix(filePath);
                }
            }
            catch (Exception fex) {}
        }
        
        //add to config
        if (filePath != null) {
            somData = new Dataset(filePath, separator, 0);
        }
        else {
            //data entries are the actual value sets so convert to knn format
            datasets = getProblemsList(testSpec);
            
            somDataset = new ArrayList();
            for (i = 0; i < datasets.size(); i++)
            {
                metricDataset = datasets.get(i);
                somDataValue = new LinkedHashMap();
                somDataset.add(somDataValue);
                
                //should in fact be only 1 entry, for the data row
                metricDataset.resetValueIterator();
                somDataValue.put(metricDataset.getName(), metricDataset.getFirstValue());
            }
            
            somData = new Dataset(somDataset, null);
        }
                
        somConfig.somData = somData;
        
        //if weights set from earlier run then add that as well
        if (weights != null) somConfig.neuronWeights = weights;
    }
    
    /**
     * Get the results of the test.
     * @return the test results in XML format.
     * @throws java.lang.Exception any error.
     */
    public Element getResultXml() throws Exception
    {
        Element resultElem;                         //result element

        resultElem = XMLFactory.getInstance().createElement(SolverConst.BESTSOLUTIONSET);
        resultElem.setText(ResultFormatter.convertToString(result));
        return resultElem;
    }
}
