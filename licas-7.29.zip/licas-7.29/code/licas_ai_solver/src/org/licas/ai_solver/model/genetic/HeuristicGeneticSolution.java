/*
 * HeuristicGeneticSolution.java
 *
 * Created on 26 August 2010
 *
 * Version 1.5
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.model.genetic;


import org.ai_heuristic.eval.result.EvalBounds;
import org.licas.ai_solver.model.*;
import org.ai_heuristic.eval.metric.*;
import org.ai_heuristic.util.AiHeuristicConst;

import org.jlog2.*;

import java.util.*;


/**
 * This is a solution that can solve problems using a heuristic-based genetic algorithm.
 * @author Kieran Greer
 */
public class HeuristicGeneticSolution extends GeneticSolution
{
    /** For logging */
    private static final Logger logger;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(HeuristicGeneticSolution.class.getName());
        logger.setDebug(false);
    }

    /**
     * Create a new instance of HeuristicGeneticSolution.
     * @param thisName the solution name.
     */
    public HeuristicGeneticSolution(String thisName)
    {
        super(thisName);
        initialise();
    }

    /**
     * Initialise some values.
     */
    private void initialise()
    {
        chromosome = null;
    }

    /**
     * Calculate the result of this solution over all problem datasets. The
     * results are then put in a list and stored in the evaluation object.
     * @param inputVariables an additional set of input variables or constraints. This can be null or empty.
     * @throws java.lang.Exception any error.
     */
    public void solve(HashMap<String, ?> inputVariables) throws Exception
    {
        LinkedHashMap<String, MetricDataset> problemSet;    //set of problem to solve
        ArrayList<ReplySet> resultSet;                      //result set
        EvalBounds nextResult;                              //next result
        
        evaluation = new EvalBounds();
        resultSet = new ArrayList<>();
        
        problemSet = (LinkedHashMap)inputVariables.get(AiHeuristicConst.PROBLEMS);
        for (String key: problemSet.keySet())
        {
            nextResult = solveNextSolution(problemSet.get(key));
            if (nextResult.evaluation != null) resultSet.add(nextResult.evaluation);
        }
        
        evaluation.name = name;
        evaluation.evaluation = new ReplySet(resultSet);
    }
    
    /**
     * Calculate the result of this solution over the specified problem dataset.
     * @param problemDataset the problem dataset to evaluate.
     * @return the entity solution, or null if the entity does not perform the solution.
     * The solution evaluation includes an upper and lower bound on the possible values.
     * @throws java.lang.Exception any error.
     */
    protected EvalBounds solveNextSolution(MetricDataset problemDataset) throws Exception
    {
        ReplySet evalResult;                            //next result
        EvalBounds result;                              //the result
        
        chromosome.setCompareDataset(problemDataset);
        evalResult = chromosome.evaluateFitness();        
        result = new EvalBounds(evalResult);
        
        return result;
    }

    /**
     * Combine the existing solution with the new solution.
     * @param solutionName the name for the new solution.
     * @param evolveWith the solution to evolve with.
     * @return a new solution that is a mutation of both solutions.
     * @throws java.lang.Exception any error.
     */
    public Solution evolve(String solutionName, Solution evolveWith)
            throws Exception
    {
        Chromosome evolveChrom;                         //evolve chromosome
        HeuristicGeneticSolution genSolution;           //genetic solution
        
        genSolution = (HeuristicGeneticSolution)evolveWith;
        evolveChrom = chromosome.evolve(genSolution.getChromosome());
        genSolution = new HeuristicGeneticSolution(solutionName);
        genSolution.setChromosome(evolveChrom);

        return genSolution;
    }
}
