/*
 * EvaluatorCentral.java
 *
 * Created on 8 January 2020
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.eval;


import org.ai_heuristic.eval.result.EvalBounds;
import org.ai_heuristic.eval.result.MatchPair;
import org.ai_heuristic.eval.result.MatchResult;
import org.licas.ai_solver.mediator.problem.ProblemMediatorCentral;
import org.licas.ai_solver.model.Solution;
import org.licas.ai_solver.model.result.MatchPairName;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.stat.ProcessResult;

import java.util.ArrayList;


/**
 * This class should be implemented by any evaluation framework, to mediate between
 * the problem-solver and the services that are part of a central problem solving process.
 * @author Kieran Greer
 */
public abstract class EvaluatorCentral extends Evaluator
{
    /** Create a new instance of EvaluatorCentral */
    public EvaluatorCentral()
    {
        super();
    }
    
    /**
     * Run a set of tests based on the test specification.
     * @param testSpec the specification describing the tests to run.
     * @param probMediator the model of the problem with all required elements.
     * @return true if the current test results are better than the previous set.
     * @throws Exception any error.
     */
    public abstract boolean evaluateSolutions(TestSpec testSpec, ProblemMediatorCentral probMediator)
            throws Exception;


    /**
     * Process the returned solution results, for some stat values.
     * @param testSpec the test specification.
     * @param probMediator the model of the problem with all required elements.
     * @throws java.lang.Exception any error.
     */
    protected void evaluateStats(TestSpec testSpec, ProblemMediatorCentral probMediator) throws Exception
    {
        int i, j;
        Solution nextSolution;                          //next solution
        MatchPairName matchPair;                        //solution matches
        MatchResult solnResult;                         //solution result
        ArrayList<? extends MatchPair> matchPairs;      //list of solution matches
        EvalBounds evalBounds;                          //result evaluation

        if (createFunctionMetric(testSpec)) {
            if ((result != null) && result.isMatchType()) {
                solnResult = (MatchResult)result;
                matchPairs = solnResult.getSolutionMatches();

                for (i = 0; i < matchPairs.size(); i++)
                {
                    matchPair = (MatchPairName) matchPairs.get(i);
                    for (j = 0; j < 2; j++)
                    {
                        if (j == 0) {
                            nextSolution = probMediator.getSolutionSet().get(matchPair.firstName);
                        }
                        else {
                            nextSolution = probMediator.getSolutionSet().get(matchPair.secondName);
                        }

                        evalBounds = nextSolution.getEvaluation();
                        if (evalBounds != null) {
                            if (evalBounds.evaluation != null) {
                                if (ProcessResult.max == null) {
                                    ProcessResult.max = evalBounds.evaluation;
                                }
                                else {
                                    if (isBetter(ProcessResult.max, evalBounds.evaluation)) {
                                        ProcessResult.max = evalBounds.evaluation;
                                    }
                                }

                                if (ProcessResult.min == null) {
                                    ProcessResult.min = evalBounds.evaluation;
                                }
                                else {
                                    if (isBetter(evalBounds.evaluation, ProcessResult.min)) {
                                        ProcessResult.min = evalBounds.evaluation;
                                    }
                                }
                            }

                            if (evalBounds.upper != null) {
                                if (ProcessResult.maxB == null) {
                                    ProcessResult.maxB = evalBounds.upper;
                                }
                                else {
                                    if (isBetter(ProcessResult.maxB, evalBounds.upper)) {
                                        ProcessResult.maxB = evalBounds.upper;
                                    }
                                }
                            }

                            if (evalBounds.lower != null) {
                                if (ProcessResult.minB == null) {
                                    ProcessResult.minB = evalBounds.lower;
                                }
                                else {
                                    if (isBetter(evalBounds.lower, ProcessResult.minB)) {
                                        ProcessResult.minB = evalBounds.lower;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
