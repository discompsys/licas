/*
 * SingleGridProblemMediator.java
 *
 * Created on 3 July 2017
 *
 * Version 1.1.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.mediator.problem;


import org.ai_heuristic.eval.result.ErrorResult;
import org.ai_heuristic.eval.result.Result;
import org.licas.ai_solver.*;
import org.licas.ai_solver.central.grid.FrequencyGrid;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.model.central.SingleSolution;
import org.licas.ai_solver.model.*;
import org.licas.ai_solver.model.result.*;

import org.licas.PasswordHandler;
import org.licas.data.DataQueryModel;
import org.ai_heuristic.eval.metric.*;
import org.ai_heuristic.functs.Function;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;
import org.licas.util.HeuristicConst;

import java.util.*;


/**
 * This class models the hyper-heuristic grid problem to be solved using a single centralised
 * approach of solving the grid or table of data values, possibly in one pass.
 * This version does not necessarily use genetic algorithms to evolve solutions.<br>
 * Note that the input problem set should be a list of {@link MetricDataset}s, where the
 * data type is {@code AiTypeConst.ARRAYLIST}. This is so that it is stored and returned
 * as a single list and not as individual elements.
 * @author Kieran Greer
 */
public class SingleGridProblemMediator extends GridProblemMediator
{
    /** For logging errors */
    private static final Logger logger;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SingleGridProblemMediator.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of SingleGridProblemMediator.
     * @param thePasswordHandler for storing passwords.
     */
    public SingleGridProblemMediator(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {}
     
    /**
     * Optimise the solutions using the appropriate framework.
     * @param testSpec the model of the tests to perform.
     * @return clusters of solutions or references from the latest optimisation phase.
     * @throws java.lang.Exception any error.
     */
    public Result solve(TestSpec testSpec) throws Exception
    {
        ArrayList<MetricDataset> gridCells;                 //grid cells
        FrequencyGrid optimiseGrid;                         //to optimise the grid
        
        try
        {
            //use the new value to determine what solutions need to be combined
            //in this implementation there is only ever one level
            sortProblems(testSpec, false);
            
            optimiseGrid = new FrequencyGrid(testSpec);
            heuristicType = testSpec.getTestScript().heuristicType;

            gridCells = new ArrayList<>();
            for (String key: problem.getProblemNames()) {
                gridCells.add(problem.getProblem(key));
            }
            
            if (gridCells != null) {
                optimiseGrid.copyGridCells(gridCells);
                optimiseGrid.solve(optimiseGrid.getMetric(datasetType));
                result = optimiseGrid.getGridSolution();
                
                if (result == null) {
                    result = new ErrorResult(optimiseGrid.getErrorFeedback());
                }
            }
            
            testEnded = true;
            bestResult = result;
            return result;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "solve", null, ex);
        }
        finally {
            testEnded = true;
        }
    }
    
    /**
     * Create a new genetic solution with chromosomes, etc. This is a default implementation
     * for the default genetic algorithms that are provided with this package. This includes
     * creating solutions from the simple types of {@code Integer}, {@code Float}, or 
     * {@code String}, primarily for testing purposes only.
     * @param solutionType the type of solution to create.
     * @param problemDataset the problem dataset to create the solution with.
     * @return the new solution.
     * @throws java.lang.Exception any error.
     */
    public Solution createNewSolution(String solutionType, MetricDataset problemDataset) 
            throws Exception
    {
        String solutionName;                            //solution name
        DataQueryModel dataInfo;                        //stores evaluator parameters
        SingleSolution solution;                        //solution
        Function evalMetric;                            //the solution evaluation metric
        
        //create a new solution
        solutionName = problemDataset.getName();       
        solution = new SingleSolution(solutionName);
        dataInfo = new DataQueryModel();
        dataInfo.setDataType(datasetType);
        
        evalMetric = SolverFactory.getInstance().getSolverMetrics().getEvaluationFunction(datasetType,
                solutionType, SolverFactory.getInstance().getSolverData().getEvaluateData(dataInfo), heuristicOptions);

        //add the evaluator and the dataset to the solution
        solution.setEvaluator(evalMetric);
        solution.setDataset(problemDataset);

        return solution;
    }
    
    /**
     * This can be used to combine existing solutions to evolve new ones.
     * This implementation is genetic and mutates the existing solutions to create new ones.
     * It creates new solutions based on the specified {@code heuristicOptions} object. 
     * If this is empty, then it will create two new types - one through crossover and one 
     * through mutation. If heuristicOptions specifies specific types on evolution, then it 
     * will perform those only. It then tries to space the new solutions around the existing 
     * solutions for the new grid structure.
     * @param result the result generated by the problem solver. 
     * Can be more solutions, references, or an error..
     * @return true if solutions were combined, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean updateSolutions(Result result) throws Exception
    {        
        try {
            if (result != null) {
                if ((heuristicType != null) && heuristicType.equals(HeuristicConst.FREQUENCY)) {
                    return false;
                }
            }
            
            return false;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "updateSolutions", null, ex);
        }
    }
}
