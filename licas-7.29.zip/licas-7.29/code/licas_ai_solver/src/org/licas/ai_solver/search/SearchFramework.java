/*
 * SearchFramework.java
 *
 * Created on 8 July 2015
 *
 * Version 1.0.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.search;


import org.ai_heuristic.eval.result.MatchPair;
import org.licas.ai_solver.SolverFactory;
import org.licas.ai_solver.model.Solution;
import org.licas.ai_solver.model.central.SearchSolution;
import org.licas.ai_solver.spec.test.TestSpec;

import org.licas.data.DataQueryModel;
import org.ai_heuristic.eval.EvaluateBase;
import org.ai_heuristic.functs.FunctionMetric;
import org.jlog2.*;

import java.util.ArrayList;


/**
 * Abstract base class for centralised search algorithms for finding a solution.
 * @author Kieran Greer.
 */
public abstract class SearchFramework 
{
    /** For logging */
    private static final Logger logger;
    
    
    /** The type of dataset to evaluate */
    protected String datasetType;
    
    /** 
     * True if the similarity range is measured as a percentage of the largest score.
     * If false then the exact value is used instead. Default is false.
     */
    protected boolean similarityRangeAsPercentage;
    
    /** Range for which values are considered to be the same */
    protected double similarityRange;
    
    /** The stopping criterion */
    protected Object stopping;
    
    /** List of solutions to evaluate */
    protected ArrayList<Solution> solutions;
    
    /** To compare two solution results */
    protected FunctionMetric valueCompare;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SearchFramework.class.getName());
        logger.setDebug(false);
    }
    
    
    /** 
     * Create a new instance of SearchFramework.
     * @param testSpec with any other test spec parameters.
     * @throws java.lang.Exception any error.
     */
    public SearchFramework(TestSpec testSpec) throws Exception
    {
        initialise(testSpec);
    }
    
    /** 
     * Initialise some values.
     * @param testSpec with any other test spec parameters, such as a beam width.
     * @throws java.lang.Exception any error.
     */
    private void initialise(TestSpec testSpec) throws Exception
    {
        DataQueryModel dataInfo;                      //stores evaluator parameters
        
        //stopping = ???
        if (testSpec != null) {
            datasetType = testSpec.getTestScript().datasetType;
            dataInfo = new DataQueryModel();
            dataInfo.setDataType(SolverFactory.getInstance().getSolverData().dataClassFromType(testSpec.getTestScript().datasetType));
                
            valueCompare = (FunctionMetric)SolverFactory.getInstance().getSolverMetrics().getEvaluationFunction(SolverFactory.getInstance().getSolverData().dataClassFromType(testSpec.getTestScript().datasetType),
                    testSpec.getTestScript().metricType, 
                    SolverFactory.getInstance().getSolverData().getEvaluateData(dataInfo), 
                    testSpec.getTestScript().heuristicOptions);
            similarityRange = testSpec.getTestScript().rangeValue; 
        }
        else {
            datasetType = null;
            similarityRange = 0;
            valueCompare = null;
        }
        
        solutions = null;
    }
    
   /**
    * Search for the best solution set to the problem.
    * @return the list of best solutions.
    * @throws java.lang.Exception any error.
    */
    public abstract ArrayList<MatchPair> solve() throws Exception;
    
    /**
     * If a similarity range has been specified, then measure if the value is inside of it.
     * @param value the value to measure. This must be convertible to a float.
     * @return true if inside the range or there is no range (0). False if outside of the 
     * range, or the object cannot be converted to a float.
     */
    protected boolean insideRange(Object value)
    {
        float floatValue;                           //float value
        
        try {
            if (similarityRange > 0) {
                if (datasetType == null) datasetType = value.getClass().getName();
                try {
                    floatValue = ((Float)EvaluateBase.valueFromString(Float.class.getName(),
                        EvaluateBase.valueToString(datasetType, value))).floatValue();
                }
                catch (Exception nex) {
                    floatValue = ((Float)EvaluateBase.valueFromString(Float.class.getName(),
                        String.valueOf(value))).floatValue();
                }
                
                if (valueCompare.lib())
                    return (floatValue <= similarityRange);
                else
                    return (floatValue >= similarityRange);
            }
            else {
                return true;
            }
        }
        catch (Exception ex) {}
        
        return false;
    }
    
    /**
     * Set the solutions list to solve.
     * @param thisSolutions the list of {@link SearchSolution} to solve.
     */
    public void setSolutions(ArrayList<Solution> thisSolutions)
    {
        solutions = thisSolutions;
    }
}
