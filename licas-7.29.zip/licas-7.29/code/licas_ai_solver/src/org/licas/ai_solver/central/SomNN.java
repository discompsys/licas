/*
 * SomNN.java
 *
 * Created on 21 October 2014.
 *
 * Version 1.1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.central;


import org.ai_heuristic.data.Dataset;
import org.ai_heuristic.eval.metric.ReplySet;
import org.ai_heuristic.eval.result.Cluster;
import org.ai_heuristic.eval.result.ClusterResult;
import org.ai_heuristic.data.DatasetModel;
import org.ai_heuristic.algo.cluster.som.kohonen.*;
import org.ai_heuristic.algo.cluster.som.network.DefaultNetwork;
import org.ai_heuristic.algo.cluster.som.network.NetworkModel;
import org.ai_heuristic.algo.cluster.som.topology.*;
import org.ai_heuristic.algo.cluster.som.neighbourhood.NeighbourhoodFunctionModel;
import org.ai_heuristic.functs.*;

import org.ai_heuristic.util.AiHeuristicConst;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;

import java.util.*;


/**
 * This class can be used to create and run a Self-Organising Map Neural Network
 * from a configuration specification.
 * @author Kieran Greer
 */
public class SomNN
{
    /** For logging errors */
    private static final Logger logger;

    
    /** The learning framework that runs the tests. */
    protected LearningFunction learning;
    
    /** The neural network model */
    protected NetworkModel network;
    
    /** Training datasets */
    protected DatasetModel somData;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SomNN.class.getName());
        logger.setDebug(false);
    }
        
    /**
     * Create a new instance of SomNN.
     */
    public SomNN()
    {
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        learning = null;
        network = null;
        somData = null;
    }
    
    /**
     * Initialise the SOM neural network.
     * @param somConfig the configuration setup.
     * @throws java.lang.Exception any error.
     */
    public void initialiseSom(SomConfig somConfig) throws Exception
    {
        int iterations;                                 //number of iterations
        int weightNumber;                               //number of weights
        double[] maxWeights;                            //list of weights
        String funcType;                                //function type
        String dataType;                                //data type
        ArrayList<Object> params;                       //constructor params
        HashMap<String, Object> configParams;           //learning function parameters
        FunctionLearn funcLearn;                        //learning function
        FunctionActivate funcActive;                    //activation function
        FunctionMetric distanceMetric;                  //distance metric
        NeighbourhoodFunctionModel nFuncModel;          //neighbourhood function model
        TopologyModel topology;                         //som topology
                
        try {
            weightNumber = somConfig.weightNumber;
            dataType = somConfig.dataType;
            
            configParams = somConfig.lfParams;           
            funcType = somConfig.learningFunction;
            funcLearn = (FunctionLearn)Function.createFunction(funcType, dataType, configParams);
            
            funcType = somConfig.metric;
            distanceMetric = (FunctionMetric)Function.createFunction(funcType, dataType, configParams);
                       
            funcType = somConfig.activationFunction;
            funcActive = (FunctionActivate)Function.createFunction(funcType, dataType, configParams);
                       
            funcType = somConfig.topology;
            topology = SomConst.createTopology(funcType, somConfig.topologyRow, 
                    somConfig.topologyCol, somConfig.topologyRadius);
                  
            if (somConfig.neuronWeights == null) {
                maxWeights = somConfig.weights;
                if ((maxWeights != null) && (maxWeights.length > 0)) weightNumber = maxWeights.length;
                network = new DefaultNetwork(weightNumber, maxWeights, topology, distanceMetric, funcLearn, funcActive);
            }
            else {
                network = new DefaultNetwork((ArrayList)somConfig.neuronWeights.clone(), topology, distanceMetric, funcLearn, funcActive);
            }
            
            funcType = somConfig.learningFramework;
            iterations = somConfig.iterations;
            somData = somConfig.somData;
            
            params = new ArrayList();
            if (SomConst.isWTA(funcType)) {
                params.add(network);
                params.add(new Integer(iterations));
                params.add(somData);
            }
            else {
                nFuncModel = SomConst.createNeighbourhoodFunctionModel(somConfig.neighbourhoodFunctionModel, configParams);
                params.add(network);
                params.add(new Integer(iterations));
                params.add(distanceMetric);
                params.add(somData);
                params.add(funcLearn);
                params.add(nFuncModel);
            }
            
            learning = SomConst.createLearningFramework(funcType, params);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "initialiseSom", 
                    null, ex);
        }
    }
    
    /**
     * Run the SOM neural network test.
     * @return the neuron connections list. Indexed by neuron numerical order.
     * Each entry is an int[2], indicating the 2 best neurons for each dataset row entry.
     * @throws java.lang.Exception any error.
     */
    public ClusterResult train() throws Exception
    {
        int i;
        int bestIndex;                                  //best output neuron index
        double[] dataRow;                               //data row
        String clusterKey;                              //cluster key
        Iterator<String> allKeys;                       //all keys
        ArrayList<Integer> clusterGroup;                //all connections
        HashMap<String, ArrayList<Integer>> clusters;   //sorted clusters
        Cluster nextCluster;                            //next cluster
        ClusterResult result;                           //cluster result
        
        //train the neural network
        result = new ClusterResult();
        learning.learn();
        
        //retrieve the cluster groups from the training phase
        clusters = new HashMap<>();
        for (i = 0; i < somData.getDataSize(); i++)
        {
            dataRow = somData.getData(i);
            bestIndex = network.bestNeuronIndex(dataRow);
            clusterKey = String.valueOf(bestIndex);
            
            if (!clusters.containsKey(clusterKey)) {
                clusters.put(clusterKey, new ArrayList());
            }
            
            clusterGroup = clusters.get(clusterKey);
            clusterGroup.add(i);
        }
        
        allKeys = clusters.keySet().iterator();
        while (allKeys.hasNext())
        {
            clusterKey = allKeys.next();
            clusterGroup = clusters.get(clusterKey);
            nextCluster = new Cluster(clusterKey, clusterGroup);           
            result.addCluster(nextCluster);
        }
        
        return result;
    }

    /**
     * Run the knn algorithm and return a list with the nearest indexes from the train dataset.
     * @return the nearest neighbour clusters.
     * Each entry is a cluster group of data row names.
     * @throws Exception any error.
     */
    public ClusterResult test(Dataset testDataset) throws Exception
    {
        int i;
        int bestIndex;                                  //best output neuron index
        double[] dataRow;                               //data row
        String clusterKey;                              //cluster key
        Iterator<String> allKeys;                       //all keys
        ArrayList<Integer> clusterGroup;                //all connections
        HashMap<String, ArrayList<Integer>> clusters;   //sorted clusters
        Cluster nextCluster;                            //next cluster
        ClusterResult result;                           //cluster result

        //train the neural network
        result = new ClusterResult();

        //retrieve the cluster groups from the training phase
        clusters = new HashMap<>();
        for (i = 0; i < testDataset.getDataSize(); i++)
        {
            dataRow = testDataset.getData(i);
            bestIndex = network.bestNeuronIndex(dataRow);
            clusterKey = String.valueOf(bestIndex);

            if (!clusters.containsKey(clusterKey)) {
                clusters.put(clusterKey, new ArrayList());
            }

            clusterGroup = clusters.get(clusterKey);
            clusterGroup.add(i);
        }

        allKeys = clusters.keySet().iterator();
        while (allKeys.hasNext())
        {
            clusterKey = allKeys.next();
            clusterGroup = clusters.get(clusterKey);
            nextCluster = new Cluster(clusterKey, clusterGroup);
            result.addCluster(nextCluster);
        }

        return result;
    }
    
    /**
     * Get the current set of weight values.
     * @return all weight lists for the neurons, in listed order.
     */
    public ArrayList getWeights()
    {
        int i;
        double[] connections;                       //list of connections
        ArrayList<double[]> neuronWeights;          //all weight lists
        
        neuronWeights = new ArrayList();
        for (i = 0; i < network.getNumbersOfNeurons(); i++)
        {
            connections = network.getNeuron(i).getWeight();
            neuronWeights.add(connections);
        }
        
        return neuronWeights;
    }
}
