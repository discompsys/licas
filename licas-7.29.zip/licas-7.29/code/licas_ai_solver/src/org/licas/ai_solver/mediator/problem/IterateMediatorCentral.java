/*
 * IterateMediatorCentral.java
 *
 * Created on 25 November 2015
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.mediator.problem;


import org.ai_heuristic.eval.result.MatchResult;
import org.licas.ai_solver.def.IterateMediatorDef;

import org.licas.PasswordHandler;
import org.jlog2.*;


/**
 * This is the abstract base class for modelling a solver that iterates over more than
 * one test runs, as part of a centralised problem solver.
 * @author Kieran Greer
 */
public abstract class IterateMediatorCentral extends ProblemMediatorCentral implements IterateMediatorDef
{
    /** For logging errors */
    private static final Logger logger;

    
    /** True if the current set of results are better than the previous set */
    protected boolean resultsBetter;

    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(IterateMediatorCentral.class.getName());
        logger.setDebug(false);
    }
    
    
    /**
     * Create a new instance of IterateProblemMediator.
     * @param thePasswordHandler for storing passwords.
     */
    public IterateMediatorCentral(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        resetValues();
    }
    
    /** Reset to starting values */
    public void resetValues()
    {
        super.resetValues();      
        resultsBetter = true;
    }
    
    /**
     * Return true if this spec still has solutions to process.
     * This default version checks that the solutions list is not empty.
     * @return true if there are still solutions that can be solved.
     */
    public boolean solutionsToProcess()
    {
        return (!getSolutionSet().isEmpty());
    }
    
    /**
     * This method checks for conditions that indicate that the test runs
     * have or should be terminated. This method should be called internally
     * by any derived class of ProblemMediator. It is included here with a default
     * evaluation that checks that there are still solutions to evaluate.
     * @param solutionSet the last solution set to evaluate.
     * @throws java.lang.Exception any error.
     */
    protected void calcTestEnded(MatchResult solutionSet) throws Exception
    {
        testEnded = solutionSet.getSolutionMatches().isEmpty();
    }
    
    /**
     * Return true if the current set of results are better than the previous
     * set of results. This is not set automatically and needs to be implemented
     * by any derived class.
     * @return the value of resultsNotBetter.
     */
    public boolean getResultsBetter()
    {
        return resultsBetter;
    }
}
