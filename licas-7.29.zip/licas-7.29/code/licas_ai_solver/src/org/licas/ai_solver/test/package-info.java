/**
 * The problem-solving tests are set-up from the classes of this package that typically
 * read and create test specifications first and translate those over to the problem specifications,
 * before executing the tests. 
 */
package org.licas.ai_solver.test;