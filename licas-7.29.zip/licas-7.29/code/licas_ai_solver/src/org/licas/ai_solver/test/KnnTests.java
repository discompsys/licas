/*
 * KnnTests.java
 *
 * Created on 29 March 2016
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.test;


import org.licas.ai_solver.SolverFactory;
import org.licas.ai_solver.eval.EvaluatorCentral;
import org.licas.ai_solver.mediator.problem.ProblemMediatorCentral;
import org.licas.ai_solver.spec.KnnProblemScript;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.stat.ProcessResult;
import org.licas.ai_solver.util.SolverConst;
import org.licas.PasswordHandler;

import org.ai_heuristic.util.AiHeuristicConst;
import org.licas_xml.abs.Element;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;
import org.jlog2.util.StringHandler;

import java.util.*;


/**
 * The main class for running tests using the k nearest neighbour framework. This retrieves
 * sets of best solutions for every other solution and returns the result to each service.
 * @author Kieran Greer
 */
public class KnnTests extends RunTests
{
    /** For logging */
    private static final Logger logger;
    
    
    /** True if initialised */
    private boolean initialised;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(KnnTests.class.getName());
        logger.setDebug(false);
    }
    
    /** 
     * Create a new instance of KnnTests.
     * @param thePasswordHandler for storing passwords.
     */
    public KnnTests(PasswordHandler thePasswordHandler) 
    {
        super(thePasswordHandler);
        initialised = false;
    }
    
    /**
     * Run a set of tests based on an already created script object and initialised
     * environment.
     * @return a description of the execution trace.
     * @throws java.lang.Exception any error.
     */
    public String runTestSet() throws Exception
    {
        String resultStr;                                           //result string
        String exeDescr;                                            //description of the test execution
        ArrayList<ArrayList<String>> servicesList;                  //services list
        HashMap<String, TestSpec> resetList;                        //reset variables list
        HashMap<String, ArrayList<ArrayList<String>>> sortedList;   //sorted services list
        Element finalResult;                                        //the final result
        KnnProblemScript testScript;                                //the test specification
        ProcessResult statResults;                                  //stat results
        
        try {
            testScript = (KnnProblemScript)testSpec.getTestScript();
            exeDescr = "";
            
            //create new set of solutions each new iteration,
            //but remove existing linked ones for each new test run
            if (!initialised) {
                evalMediator.initialiseMediator(testSpec, problemMediator);
                initialised = true;
            }

            //create new set of solutions each new iteration and reset for each test run
            resetList = new HashMap<>();
            resetList.put(SolverConst.TESTOPTIONS, testSpec);
            problemMediator.resetForNextRun(resetList);
                
            //testScript.testRunsScript.testRuns translated over to neural network iterations,
            //so only one test run phase here
            ((EvaluatorCentral)evalMediator).evaluateSolutions(testSpec, (ProblemMediatorCentral)problemMediator);
            statResults = problemMediator.processResult(testScript.solverType);
                        
            //update the service links based on the newly created clusters
            if ((statResults != null) && (problemMediator.serverSpec.serviceMediator != null)) {
                //calculate the links score and use as an additional evaluation criterion
                if (testScript.testRunsScript.addLinks) {
                    //if read from a file, then there are no services and dummy keys should be used
                    //removes these first to determine if any services are running
                    servicesList = SolverFactory.getInstance().getSolverData().getProcessResult(testScript.solverType).removeDummyKeys(statResults.clusters);
                    if (!servicesList.isEmpty()) {
                        sortedList = SolverFactory.getInstance().getSolverData().getProcessResult(testScript.solverType).sortGroupsForLinks(servicesList);
                        problemMediator.serverSpec.serviceMediator.updateDynamicLinks(sortedList, true);
                    }
                }
            }
                    
            //display final result
            finalResult = evalMediator.getTestResult();
            if (finalResult != null) {
                resultStr = finalResult.getText();                          
                if ((resultStr == null) || resultStr.equals("")) {
                    resultStr = xmlToTaggedString(finalResult);
                }
            }
            else {
                resultStr = "Final result is null.";
            }
            
            //store the final test result
            result = evalMediator.getResult();           
            if (resultStr != null) {
                resultStr = StringHandler.replaceAll(resultStr, AiHeuristicConst.DUMMYKEY, "r_");
            }

            exeDescr += ("\nFinal result:\n" + resultStr);
            return exeDescr;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "runTestSet",
                null, ex);
        }
    }
}