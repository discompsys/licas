/*
 * GeneticGrid.java
 *
 * Created on 29 June 2017
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.central.grid;


import org.ai_heuristic.eval.result.MatchPair;
import org.ai_heuristic.eval.result.MatchResult;
import org.ai_heuristic.eval.result.Result;
import org.licas.ai_solver.central.grid.metric.GridMetric;
import org.licas.ai_solver.model.result.*;
import org.licas.ai_solver.spec.GridProblemScript;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.util.*;

import org.licas.util.HeuristicConst;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;

import java.util.*;


/**
 * This optimises the solution for solving the grid. This process tries to optimise an
 * existing grid that represents a set of solution values and must be passed in using the 
 * {@code setGridCells} method. The solutions themselves can be evaluated independently of this,
 * but the grid can suggest what the better ones are, or what ones to combine or evolve. 
 * The {@code solve} method then optimises the solution based on the entered
 * parameter values. This is closely linked with the {@code genetic algorithms}, as the grid result
 * will suggest solutions to evolve further. 
 * <p>
 * For example, the {@code hyperMatch} variable can be used to choose between solving using 
 * a hill-climbing approach (false) that simply {@code maximises} the sum of any two solutions, to 
 * {@code matching} similar scores in the new hyper-heuristic process (true). These values 
 * are passed in using the {@link TestSpec} specification.
 * @author Kieran Greer
 */
public class GeneticGrid<T> extends HyperHeuristicGrid
{
    /** For logging errors */
    private static final Logger logger;

    
    /**
     * True if try the hyper-heuristic matching approach.
     * The alternative is a hill climbing approach that simply selects the best
     * solutions from anywhere.
     */
    protected boolean hyperMatch;
    
    /** Maximum number of solutions or rows, for the matching or the hill-climbing version */
    protected int maxSolutions;

    /** The array for grid cells */
    protected T[][] gridCells;
    
    /** 
     * True if the similarity range is measured as a percentage of the largest score.
     * If false then the exact value is used instead. Default is false.
     */
    protected boolean similarityRangeAsPercentage;
    
    /** Range for which values are considered to be the same */
    protected double similarityRange;
    
    
    
    /** The best single match score obtained over the whole grid */
    protected double bestScore;
    
    /** 
     * The best summed score for all matches over the whole grid.
     * This is returned as an average value for a single match.
     */
    protected double bestTotalScore;

    /** Best cell matches. */
    protected ArrayList<RowMatch> rowMatches;

    /** Best row matches. Of type {@link MatchPairIndex}. */
    protected ArrayList<MatchPair> matchPairs;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(GeneticGrid.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of GeneticGrid. Larger value assumed to be better.
     * @param testSpec the test specification. Can be null for default values.
     */
    public GeneticGrid(TestSpec testSpec)
    {
        super();
        initialise(testSpec);
        lib = true;
    }
    
    /**
     * Create a new instance of GeneticGrid.
     * @param testSpec the test specification. Can be null for default values.
     * @param thisLib true if larger value is better, false if smaller value is better.
     */
    public GeneticGrid(TestSpec testSpec, boolean thisLib)
    {
        super();
        initialise(testSpec);
        lib = thisLib;
    }

    /** 
     * Initialise some values. 
     * @param testSpec the test specification.
     */
    private void initialise(TestSpec testSpec)
    {
        gridType = HeuristicConst.GENETICALGORITHM;        
        if (testSpec != null) {
            hyperMatch = testSpec.getTestScript().solverType.equals(HeuristicConst.GRIDMATCH);
            similarityRangeAsPercentage = testSpec.getTestScript().similarityRangeAsPercentage;
            similarityRange = testSpec.getTestScript().rangeValue;             
            maxSolutions = ((GridProblemScript)testSpec.getTestScript()).maxMatches;
        }
        else {
            hyperMatch = true;
            similarityRangeAsPercentage = false;
            similarityRange = 0.0;
            maxSolutions = Integer.MAX_VALUE;
        }
        
        gridCells = null;
        resetValues();
    }
    
    /** Reset some values */
    public void resetValues()
    {
        bestScore = Double.MIN_VALUE;
        bestTotalScore = Double.MIN_VALUE;
        errorFeedback = null;
        rowMatches = new ArrayList<>();
        matchPairs = new ArrayList<>();
        gridSolution = new MatchResult();
    }

    /**
     * Solve the currently saved grid.
     * @param theGridMetric the comparison metric to use.
     * @throws java.lang.Exception any error.
     */
    public void solve(GridMetric theGridMetric) throws Exception
    {
        ArrayList<RowMatch> solnMatches;            //initial solution matches
        ArrayList<RowMatch> summedRows;             //summed row matches
        
        try {
            solnMatches = new ArrayList<>();
            resetValues();
            gridMetric = theGridMetric;
            
            //calculate optimal matches separately for rows and columns                     
            determineMatches(gridCells, solnMatches);
            if (hyperMatch) solnMatches = reduceMatchSets(solnMatches);
            summedRows = sumMatches(solnMatches);
            
            if (hyperMatch && (summedRows.size() > maxSolutions)) {
                gridSolution = null;
                errorFeedback = SolverConst.TOOMANYMATCHES;
            }
            else {
                //the arrays are set to empty and added to in the method calls
                optimiseCells(summedRows, rowMatches);
                matchPairs = cellsToSolutions(rowMatches, solnMatches);
                ((MatchResult)gridSolution).setBestScore(bestScore);
                ((MatchResult)gridSolution).setSolutionMatches(matchPairs);

                if (bestTotalScore > 0)
                    ((MatchResult)gridSolution).setTotalScore(bestTotalScore);
                else
                    ((MatchResult)gridSolution).setTotalScore(0.0);
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "solve", null, ex);
        }
    }

    /**
     * Calculate what all of the possible matching indices are in the list of cells.
     * Only include a match if all columns or cells are inside the similarity score.
     * @param thisGridCells the grid of cells to match over.
     * @param rowMatches all matching options over the grid. Each row is a separate
     * set of possible matches.
     */
    protected void determineMatches(T[][] thisGridCells, ArrayList<RowMatch> rowMatches)
    {
        int i, j;
        boolean isMatch;                            //true if a match
        RowMatch gridEntry;                         //grid entry
        
        //Match cells, there does not need to be a gap of at least 1 row/col between
        //any matching pair for the hyper-heuristic, so can be same as for hill climbing.
        //Match rows across columns, so trace each column in turn to match rows.
        if ((rowMatches != null) && (thisGridCells.length > 0)) {
            for (i = 0; i < thisGridCells.length-1; i++)
            {
                for (j = i+1; j < thisGridCells.length; j++)
                {
                    isMatch = (gridMetric.listsMatch(thisGridCells[i], thisGridCells[j],
                                hyperMatch, similarityRangeAsPercentage, similarityRange) > 0);

                    if (isMatch) {
                        gridEntry = new RowMatch();
                        gridEntry.firstIndex = i;
                        gridEntry.secondIndex = j;
                        gridEntry.position = 0;
                        gridEntry.value = gridMetric.listSum(thisGridCells[i], thisGridCells[j],
                                hyperMatch, similarityRangeAsPercentage, similarityRange);

                        rowMatches.add(gridEntry);
                    }
                }
            }
        }
    }
    
    /**
     * Optimise the cells by only keeping the ones that produce the largest
     * overall total as determined by the row/col removal rules.
     * @param rowMatches the cells to optimise.
     * @param bestMatches the structure to store the optimised matches in.
     */
    protected void optimiseCells(ArrayList<RowMatch> rowMatches, ArrayList<RowMatch> bestMatches)
    {
        ArrayList<RowMatch> nextBestMatches;               //next best matches
        
        if (bestMatches != null) {
            if (hyperMatch) {
                nextBestMatches = new ArrayList<>();
                optimiseMatches(rowMatches, 0, bestMatches, nextBestMatches);
            }
            else {
                optimiseHillClimbing(rowMatches, bestMatches);
            }
        }
    }

    /**
     * Optimise the cell matches by only keeping the ones that produce the largest
     * overall total as determined by the row/col removal rules.
     * @param rowMatches the cells to optimise. These should already be summed, so only
     * one column.
     * @param currentScore the current score total.
     * @param finalBestMatches list of final best matches.
     * @param currentBestMatches list of current best matches.
     * @return the best total score from evaluating this node.
     */
    protected double optimiseMatches(ArrayList<RowMatch> rowMatches, double currentScore,
                                   ArrayList<RowMatch> finalBestMatches, ArrayList<RowMatch> currentBestMatches)
    {
        int i;
        double entryValue;                      //selected entry value
        double thisScore;                       //this score
        double thisBestScore;                   //this best score
        RowMatch gridEntry;                    //next entry
        RowMatch bestEntry;                    //best entry
        ArrayList<RowMatch> cellsClone;        //copy of the rowMatches
        ArrayList<RowMatch> thisMatches;       //matching indexes for this iteration
        ArrayList<RowMatch> newBestMatches;    //new best matches
        
        //pick a match and remove all lists between
        thisBestScore = Double.MIN_VALUE;
        newBestMatches = new ArrayList<>();
        thisMatches = (ArrayList)rowMatches.clone();

        LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "optimiseMatches",
                "Next index set: " + String.valueOf(thisMatches));

        for (i = 0; i < thisMatches.size(); i++)
        {
            gridEntry = thisMatches.get(i);
            if (gridEntry != null) {
                entryValue = gridEntry.value;
                if ((bestScore == Double.MIN_VALUE) || isBetter(entryValue, bestScore)) {
                    bestScore = entryValue;
                }

                //if best score increased then save new match
                thisScore = (currentScore + entryValue);
                if ((thisBestScore == Double.MIN_VALUE) || isBetter(thisScore, thisBestScore)) {
                    thisBestScore = thisScore;
                    bestEntry = gridEntry;

                    newBestMatches.clear();
                    newBestMatches.addAll(currentBestMatches);
                    newBestMatches.add(bestEntry);

                    LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "optimiseMatches",
                            "Currect score now: " + String.valueOf(thisScore));
                    LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "optimiseMatches",
                            "New best matches now: " + String.valueOf(newBestMatches));

                    //to keep this match need to remove the ones incompatable with it
                    //and then search again with the match itself also removed
                    cellsClone = (ArrayList)thisMatches.clone();
                    removeIndexes(cellsClone, bestEntry);

                    if (hasEntries(cellsClone)) {
                        thisScore = optimiseMatches(cellsClone, thisScore, finalBestMatches, 
                                newBestMatches);
                    }

                    if ((bestTotalScore == Double.MIN_VALUE) || isBetter(thisScore, bestTotalScore)) {
                        bestTotalScore = thisScore;

                        finalBestMatches.clear();
                        finalBestMatches.addAll(newBestMatches);

                        LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "optimiseMatches",
                            "Best score now: " + String.valueOf(bestTotalScore));
                        LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "optimiseMatches",
                            "Final best matches now: " + String.valueOf(finalBestMatches));
                    }
                }
            }
        }
        
        return thisBestScore;
    }
    
    /**
     * Keep only the allowed maximum number of row match sets. If there are more matching
     * sets than this, then remove the lower values ones and only keep the allowed number.
     * @param rowMatches the list of matches to prune.
     */
    protected ArrayList<RowMatch> reduceMatchSets(ArrayList<RowMatch> rowMatches)
    {
        int i;
        int bestIndex;                                  //best index
        double nextValue;                               //next value
        double bestValue;                               //best value
        Integer[] indexes;                              //first-second indexes
        ArrayList<Integer[]> indexList;                 //index list
        ArrayList<RowMatch> newrowMatches;              //maximum allowed cell matches
        RowMatch gridEntry;                             //grid entry
        
        newrowMatches = new ArrayList<>();
        indexList = new ArrayList<>();
        removeNulls(rowMatches);

        if (rowMatches != null) {
            while ((newrowMatches.size() < maxSolutions) && !rowMatches.isEmpty())
            {
                bestValue = Double.MIN_VALUE;
                bestIndex = -1;
                
                for (i = 0; i < rowMatches.size(); i++)
                {
                    gridEntry = rowMatches.get(i);
                    nextValue = gridEntry.value;
                    
                    if (((bestValue == Double.MIN_VALUE) || isBetter(nextValue, bestValue)) &&
                        !indexesUsed(gridEntry, indexList)) {
                        bestValue = nextValue;
                        bestIndex = i;
                    }
                }

                if (bestIndex >= 0) {
                    gridEntry = rowMatches.get(bestIndex);
                    newrowMatches.add(gridEntry);
                    rowMatches.remove(bestIndex);

                    indexes = new Integer[2];
                    indexes[0] = (gridEntry.firstIndex);
                    indexes[1] = (gridEntry.secondIndex);
                    indexList.add(indexes);
                }
                else {
                    rowMatches.clear();
                }
            }
        }
        else {
            newrowMatches = rowMatches;
        }
        
        return newrowMatches;
    }

    /**
     * Remove any list entries that are null.
     * @param rowMatches list of entries to inspect.
     */
    protected void removeNulls(ArrayList<RowMatch> rowMatches) {
        int i;

        i = 0;
        while (i < rowMatches.size()) {
            if (rowMatches.get(i) == null) {
                rowMatches.remove(i);
            }
            else {
                i++;
            }
        }
    }

    /**
     * Return true if the indexes have been used already in another match.
     * @param rowMatch row of matching cells.
     * @param indexList list of all index pairs used so far.
     * @return true if either index is in the list.
     */
    protected boolean indexesUsed(RowMatch rowMatch, ArrayList<Integer[]> indexList) {
        for (Integer[] indexes: indexList) {
            if ((rowMatch.firstIndex == indexes[0]) &&
                    (rowMatch.secondIndex == indexes[1]))
            {
                return true;
            }
        }

        return false;
    }
    
    /**
     * Optimise the cell matches by only keeping the two that are summed together to produce 
     * the largest total.
     * @param rowMatches the cells to optimise.
     * @param finalBestMatches list of final best matches.
     */
    protected void optimiseHillClimbing(ArrayList<RowMatch> rowMatches, ArrayList<RowMatch> finalBestMatches)
    {
        int i;
        int bestIndex;                          //best index
        double nextValue;                       //next value
        double currentBestScore;                //current best score
        RowMatch gridEntry;                    //grid entry
        RowMatch bestEntry;                    //best entry
        ArrayList<RowMatch> thisMatches;       //matching indexes for this iteration
        
        finalBestMatches.clear();
        thisMatches = (ArrayList) this.rowMatches.clone();

        while ((finalBestMatches.size() < maxSolutions) && !thisMatches.isEmpty())
        {
            bestEntry = null;
            bestIndex = -1;
            currentBestScore = Double.MIN_VALUE;
            
            for (i = 0; i < thisMatches.size(); i++)
            {
                gridEntry = thisMatches.get(i);
                nextValue = gridEntry.value;
                
                if ((bestScore == Double.MIN_VALUE) || isBetter(nextValue, bestScore)) {
                    bestScore = nextValue;
                }                
                if ((currentBestScore == Double.MIN_VALUE) || isBetter(nextValue, currentBestScore)) {
                    currentBestScore = nextValue;
                    bestIndex = i;
                    bestEntry = gridEntry;
                }
            }
            
            if (bestEntry != null) {
                finalBestMatches.add(bestEntry);
                thisMatches.remove(bestIndex);
            }
        }
    }
    
    /**
     * Sum all cell values for similar matching indexes.
     * @param thisRowMatches all of the matching indexes and related values.
     * @return a single column list of values for each matching indexes group.
     */
    protected ArrayList<RowMatch> sumMatches(ArrayList<RowMatch> thisRowMatches)
    {
        int i;
        RowMatch gridEntry;                         //grid entry
        ArrayList<RowMatch> rowMatches;             //clone of cell matches
        ArrayList<RowMatch> summedMatches;          //list of summed matches
        
        summedMatches = new ArrayList<>();
        rowMatches = new ArrayList<>();

        try {
            for (i = 0; i < thisRowMatches.size(); i++) {
                rowMatches.add((RowMatch)thisRowMatches.get(i).clone());
            }
        }
        catch (Exception ex) {
            int abc = 10;
        }
        
        for (i = 0; i < rowMatches.size(); i++)
        {
            gridEntry = rowMatches.get(i);
            if (gridEntry != null) {
                summedMatches.add(gridEntry);
            }
        }
        
        return summedMatches;
    }
    
    /**
     * Return true if value1 is better than value2. Can use the function to check
     * is larger or smaller is better.
     * @param val1 the first value.
     * @param val2 the second value.
     * @return true if val1 is better than val2, false otherwise.
     */
    protected boolean isBetter(double val1, double val2)
    {
        if (lib) return (val1 > val2);
        else return (val1 < val2);
    }
    
    /**
     * Convert the best cell matches into solution matches that includes the problem indexes.
     * @param bestMatches the best solution matches that were found, as summed cell matches.
     * @param solnMatches the initial set of solution matches, with all columns of data.
     * @return the best solution matches including problem dataset indexes as a {@link MatchPair} list.
     */
    protected ArrayList<MatchPair> cellsToSolutions(ArrayList bestMatches, ArrayList<RowMatch> solnMatches)
    {
        int i, j;
        int bestIndex;                                  //best index
        double bestValue;                               //best value
        ArrayList<MatchPair> solutionMatches;           //all solution matches
        ArrayList<MatchPair> sortSolutionMatches;       //to sort solution matches
        RowMatch gridEntry;                            //cell match
        RowMatch gridEntry2;                           //cell match
        MatchPairIndex solutionMatch;                   //solution match
        
        solutionMatches = new ArrayList<>();
        for (i = 0; i < bestMatches.size(); i++)
        {
            gridEntry = (RowMatch)bestMatches.get(i);
            
            solutionMatch = new MatchPairIndex();
            solutionMatch.firstIndex = gridEntry.firstIndex;
            solutionMatch.secondIndex = gridEntry.secondIndex;
            solutionMatch.totalValue = gridEntry.value;
            
            for (j = 0; j < solnMatches.size(); j++)
            {
                gridEntry2 = solnMatches.get(j);

                if ((gridEntry2 != null) &&
                    (gridEntry2.firstIndex == gridEntry.firstIndex) &&
                    (gridEntry2.secondIndex == gridEntry.secondIndex)) {

                    solutionMatch.problems.add(gridEntry2.position);
                    solutionMatch.problemEvals.add(gridEntry2.value);
                }
            }
            
            solutionMatches.add(solutionMatch);          
        }
        
        //re-sort solution matches into descending order
        sortSolutionMatches = solutionMatches;
        solutionMatches = new ArrayList<>();
        
        while (!sortSolutionMatches.isEmpty())
        {
            bestIndex = -1;
            bestValue = Double.MIN_VALUE;
            
            for (i = 0; i < sortSolutionMatches.size(); i++)
            {
                solutionMatch = (MatchPairIndex) sortSolutionMatches.get(i);
                if ((bestValue == Double.MIN_VALUE) || isBetter(solutionMatch.totalValue, bestValue)) {
                    bestValue = solutionMatch.totalValue;
                    bestIndex = i;
                }
            }
            
            if (bestIndex >= 0) {
                solutionMatches.add(sortSolutionMatches.get(bestIndex));
                sortSolutionMatches.remove(bestIndex);
            }
        }
        
        return solutionMatches;
    }

    /**
     * Return true if the grid cells still have any match entries.
     * @param cells the grid to check.
     * @return true if it still has any entries.
     */
    protected boolean hasEntries(ArrayList cells)
    {
        return ((cells != null) && !cells.isEmpty());
    }

    /**
     * Remove from all index sets any indexes that require any indexes that 
     * intersect the first and last index values of the entered set.
     * @param cells the cells to adjust.
     * @param gridEntry the entry with the cell indexes.
     */
    protected void removeIndexes(ArrayList cells, RowMatch gridEntry)
    {
        int i;
        int firstIndex;                                 //first index
        int secondIndex;                                //second index
        RowMatch matchEntry;                           //match entry

        firstIndex = gridEntry.firstIndex;
        secondIndex = gridEntry.secondIndex;

        i = 0;
        while (i < cells.size())
        {
            matchEntry = (RowMatch)cells.get(i);
            if (matchEntry != null) {
                if (!isInsideBounds(matchEntry, firstIndex, secondIndex) &&
                    !isOutsideBounds(matchEntry, firstIndex, secondIndex)) {
                    cells.remove(i);
                }
                //this needs updating - maybe config option or allow same solution row with different cols
                else if ((matchEntry.firstIndex == firstIndex) ||
                        (matchEntry.secondIndex == firstIndex) ||
                        (matchEntry.firstIndex == secondIndex) ||
                        (matchEntry.secondIndex == secondIndex)) {
                    cells.remove(i);
                }
                else {
                    i++;
                }
            }
            else {
                i++;
            }
        }
    }

    /**
     * Return true if the indexes are inside of the bounds of start and end.
     * @param indexes the indexes to consider.
     * @param start the start index of the bounds.
     * @param end the end index of the bounds.
     * @return true if the indexes would need to be removed.
     */
    protected boolean isInsideBounds(RowMatch indexes, int start, int end)
    {
        //if both indexes lies inside or equal to the bounds but not 
        //exactly the bounds themselves
        return (((indexes.firstIndex != start) || (indexes.secondIndex != end)) &&
                (((indexes.firstIndex >= start) && (indexes.firstIndex <= end))&&
                ((indexes.secondIndex >= start) && (indexes.secondIndex <= end))));
    }
    
    /**
     * Return true if the indexes are outside of the bounds of start and end.
     * @param indexes the indexes to consider.
     * @param start the start index of the bounds.
     * @param end the end index of the bounds.
     * @return true if the indexes would need to be removed.
     */
    protected boolean isOutsideBounds(RowMatch indexes, int start, int end)
    {
        //if both indexes lies outside or equal to the bounds but not 
        //exactly the bounds themselves
        return (((indexes.firstIndex != start) || (indexes.secondIndex != end)) &&
                (((indexes.firstIndex <= start) || (indexes.firstIndex >= end))&&
                ((indexes.secondIndex <= start) || (indexes.secondIndex >= end))));
    }

    /**
     * Convert the cell totalValue matches to string format for displaying.
     * This converts the bestMatches object that stores results for either
     * the row or column sets separately.
     * @param bestMatches the list of matching cells to display.
     * @return the information in a string for displaying.
     */
    protected String bestMatchesToString(ArrayList<ArrayList<RowMatch>> bestMatches)
    {
        int i, j;
        int index;                                  //index
        ArrayList<RowMatch> nextRow;               //next row
        RowMatch gridEntry;                        //next entry
        String posStr;                              //cols in string format
        String valStr;                              //vals in string format
        String matchesStr;                          //matches in string format
        
        matchesStr = "All matches:\n";
        if (bestMatches.size() > 0) {
            for (i = 0; i < bestMatches.size(); i++)
            {
                nextRow = bestMatches.get(i);
                
                index = 0;
                gridEntry = null;
                for (j = 0; (gridEntry == null) && (j < nextRow.size()); j++)
                {
                    gridEntry = nextRow.get(j);
                    index = j+1;
                }
                
                posStr = String.valueOf(gridEntry.position);
                valStr = String.valueOf(gridEntry.value);
                
                for (j = index; j < nextRow.size(); j++)
                {
                    gridEntry = nextRow.get(j);
                    if (gridEntry != null) {
                        posStr += (", " + String.valueOf(gridEntry.position));
                        valStr += (", " + String.valueOf(gridEntry.value));
                    }
                }

                matchesStr += ("Next: " + String.valueOf(i) + 
                        ", first index: " + String.valueOf(gridEntry.firstIndex) + 
                        ", second index: " + String.valueOf(gridEntry.secondIndex) + 
                        ", position: " + posStr + ", value: " + valStr + "\n");
            }
        }
        else {
            matchesStr = "No current matches";
        }

        return matchesStr;
    }
    
    /**
     * Remove the specified row from the grid and return.
     * Remove from the initial grid.
     * @param row the row to remove.
     * @return the row values that have been removed.
     */
    public T[] removeRow(int row)
    {
        return removeRow(row, gridCells);
    }

    /**
     * Remove the specified row from the grid and return.
     * @param row the row to remove.
     * @param thisGridCells the grid cells to process.
     * @return the row values that have been removed.
     */
    private T[] removeRow(int row, T[][] thisGridCells)
    {
        int i, j;
        Object[] removedRow;                //the removed row

        removedRow = new Object[thisGridCells[0].length];
        for (i = 0; i < thisGridCells[0].length; i++)
        {
            removedRow[i] = thisGridCells[row][i];
        }

        for (i = row; i < thisGridCells.length-1; i++)
        {
            for (j = 0; j < thisGridCells[0].length; j++)
            {
                thisGridCells[i][j] = thisGridCells[i+1][j];
            }
        }

        for (i = 0; i < thisGridCells[0].length; i++)
        {
            thisGridCells[thisGridCells.length-1][i] = (T) gridMetric.getNull();
        }

        return (T[]) removedRow;
    }
    
    /**
     * Insert the specified row into the grid at the specified position.
     * Insert into the initial grid.
     * @param row the position to insert the row at.
     * @param insertRow the row totalValue to insert.
     */
    public void insertRow(int row, T[] insertRow)
    {
        insertRow(row, insertRow, gridCells);
    }

    /**
     * Insert the specified row into the grid at the specified position.
     * @param row the position to insert the row at.
     * @param insertRow the row totalValue to insert.
     * @param thisGridCells the grid cells to process.
     */
    private void insertRow(int row, T[] insertRow, T[][] thisGridCells)
    {
        int i, j;

        for (i = (thisGridCells.length-1); i > row; i--)
        {
            for (j = 0; j < thisGridCells[0].length; j++)
            {
                thisGridCells[i][j] = thisGridCells[i-1][j];
            }
        }

        for (i = 0; i < thisGridCells[0].length; i++)
        {
            thisGridCells[row][i] = insertRow[i];
        }
    }
    
    /**
     * Remove the specified column from the grid and return.
     * Remove from the initial grid.
     * @param col the column to remove.
     * @return the column values that have been removed.
     */
    public T[] removeColumn(int col)
    {
        return removeColumn(col, gridCells);
    }

    /**
     * Remove the specified column from the grid and return.
     * @param col the column to remove.
     * @param thisGridCells the grid cells to process.
     * @return the column values that have been removed.
     */
    private T[] removeColumn(int col, T[][] thisGridCells)
    {
        int i, j;
        Object[] removedCol;                        //the removed column

        removedCol = new Object[thisGridCells.length];
        for (i = 0; i < thisGridCells.length; i++)
        {
            removedCol[i] = thisGridCells[i][col];
        }

        for (i = col; i < thisGridCells[0].length-1; i++)
        {
            for (j = 0; j < thisGridCells.length; j++)
            {
                thisGridCells[j][i] = thisGridCells[j][i+1];
            }
        }

        for (i = 0; i < thisGridCells.length; i++)
        {
            thisGridCells[i][thisGridCells.length-1] = (T) gridMetric.getNull();
        }

        return (T[]) removedCol;
    }
    
    /**
     * Insert the specified column into the grid at the specified position.
     * Insert into the initial grid.
     * @param col the position to insert the column at.
     * @param insertCol the column totalValue to insert.
     */
    public void insertColumn(int col, T[] insertCol)
    {
        insertColumn(col, insertCol, gridCells);
    }

    /**
     * Insert the specified column into the grid at the specified position.
     * @param col the position to insert the column at.
     * @param insertCol the column totalValue to insert.
     * @param thisGridCells the grid cells to process.
     */
    private void insertColumn(int col, T[] insertCol, T[][] thisGridCells)
    {
        int i, j;

        for (i = (thisGridCells[0].length-1); i > col; i--)
        {
            for (j = 0; j < thisGridCells.length; j++)
            {
                thisGridCells[j][i] = thisGridCells[j][i-1];
            }
        }

        for (i = 0; i < thisGridCells.length; i++)
        {
            thisGridCells[i][col] = insertCol[i];
        }
    }

    /**
     * Set the array of grid of cell values to process.
     * @param theGridCells the array of cell values.
     */
    public void setGridCells(T[][] theGridCells)
    {
        gridCells = theGridCells;
    }

    /**
     * Get the array of grid cell values.
     * @return the value of gridCells.
     */
    public T[][] getGridCells()
    {
        return gridCells;
    }
    
    /**
     * Get the list of solutions that are part of a best match.
     * @return the best matching solutions that optimise the score.
     */
    public Result getGridSolution()
    {
        return gridSolution;
    }
}
