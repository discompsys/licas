/*
 * GridTests.java
 *
 * Created on 21 August 2012
 *
 * Version 1.6.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.test;


import org.ai_heuristic.eval.result.Cluster;
import org.ai_heuristic.eval.result.ClusterResult;
import org.licas.ai_solver.*;
import org.licas.ai_solver.eval.EvaluatorCentral;
import org.licas.ai_solver.mediator.problem.IterateMediatorCentral;
import org.licas.ai_solver.mediator.problem.ProblemMediatorCentral;
import org.licas.ai_solver.spec.*;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.stat.*;
import org.licas.ai_solver.model.result.*;
import org.licas.ai_solver.util.SolverConst;

import org.licas.query.LinkQueryConfig;
import org.licas.PasswordHandler;
import org.jlog2.exception.ExceptionHandler;

import org.licas_xml.abs.Element;
import org.jlog2.*;
import org.jlog2.util.*;

import java.util.*;


/**
 * The main class for running tests on the grid matching hyper-heuristic or hill-climbing framework.
 * @author Kieran Greer
 */
public class GridTests extends RunTests
{
    /** For logging */
    private static final Logger logger;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(GridTests.class.getName());
        logger.setDebug(false);
    }
    
    /** 
     * Create a new instance of GridTests.
     * @param thePasswordHandler for storing passwords.
     */
    public GridTests(PasswordHandler thePasswordHandler) 
    {
        super(thePasswordHandler);
    }
    
    /**
     * Run a set of tests based on an already created script object and initialised
     * environment.
     * @return a description of the execution trace.
     * @throws java.lang.Exception any error.
     */
    public String runTestSet() throws Exception
    {
        int i;
        boolean testsEnded;                                         //true if tests ended
        int linksRollbackCount;                                     //rollback for links
        double thisLinkScore;                                       //this link score
        double prevLinkScore;                                       //previous link score
        String resultStr;                                           //result string
        StringBuilder exeDescr;                                     //description of the test execution
        ArrayList<Object> linkedSources;                            //all linked sources
        ArrayList<String> newLinkedSources;                         //new linked sources
        ArrayList<ArrayList<String>> solutionClusters;              //solution clusters
        ArrayList<ArrayList<String>> finalSolutionClusters;         //list of final solution clusters
        HashMap<String, TestSpec> resetList;                        //reset variables list
        HashMap<String, ArrayList<ArrayList<String>>> sortedList;   //sorted services list
        HashMap<String, Integer> testRunVars;                       //test run variables
        Element nextResult;                                         //next result
        Element finalResult;                                        //the final result
        Element linksElem;                                          //dynamic links
        ProcessResult statResults;                                  //stat results
        GridProblemScript testScript;                               //the test specification

        try {
            testsEnded = false;
            linksRollbackCount = 0;
            prevLinkScore = 0;
            finalSolutionClusters = new ArrayList<>();
            linkedSources = new ArrayList<>();
            testScript = (GridProblemScript)testSpec.getTestScript();
            exeDescr = new StringBuilder();
            
            while (!testsEnded && ((IterateMediatorCentral)problemMediator).solutionsToProcess())
            {
                //create new set of solutions each new iteration,
                //but remove existing linked ones for each new test run
                resetList = new HashMap<>();
                resetList.put(SolverConst.TESTOPTIONS, testSpec);
                problemMediator.resetForNextRun(resetList);
                
                for (i = 0; !testsEnded && (i < testScript.testRunsScript.testRuns); i++)
                {
                    if (!((EvaluatorCentral)evalMediator).evaluateSolutions(testSpec, (ProblemMediatorCentral)problemMediator)) {
                        exeDescr.append("Current tests not better, rollback to previous:\n");
                        exeDescr.append(testSpec.getMessage()).append("\n");
                        testsEnded = problemMediator.getTestEnded();
                    }
                    else {
                        if (problemMediator.getFullTrace()) {
                            nextResult = evalMediator.getTestResult();

                            if (nextResult != null) {
                                resultStr = nextResult.getText();

                                if ((resultStr == null) || resultStr.equals("")) {
                                    resultStr = xmlToTaggedString(nextResult);
                                }
                                
                                exeDescr.append("\nIntermediate test result:\n");
                                exeDescr.append(resultStr).append("\n");
                            }
                        }
                    }

                    //calculate the statistical groupings
                    testsEnded = problemMediator.getTestEnded();
                    statResults = problemMediator.processResult(testScript.solverType);
                        
                    //update the service links based on the newly created clusters
                    if ((statResults != null) && (problemMediator.serverSpec.serviceMediator != null)) {
                        //calculate the links score and use as an additional evaluation criterion
                        if (testScript.testRunsScript.addLinks) {
                            sortedList = SolverFactory.getInstance().getSolverData().getProcessResult(testScript.solverType).sortGroupsForLinks(statResults.clusters);
                            problemMediator.serverSpec.serviceMediator.updateDynamicLinks(sortedList, true);
                        }
                        if (testScript.okIfLinkInc) {
                            linksElem = problemMediator.serverSpec.serviceMediator.dynamicLinksToXml();                       
                            thisLinkScore = totalLinkScore(linksElem);
                            if (thisLinkScore < 0) thisLinkScore = 0;

                            //can still run new tests if links being updated
                            if (testsEnded) {
                                testsEnded = (thisLinkScore <= prevLinkScore);
                            }

                            prevLinkScore = thisLinkScore;
                        }
                    }
                    
                    nextResult = problemMediator.getResultXml();
                    resultStr = nextResult.getText();                          
                    if ((resultStr == null) || resultStr.equals("")) {
                        resultStr = xmlToTaggedString(nextResult);
                    }
                    
                    exeDescr.append("\nNext Problem Solution Set:\n");
                    exeDescr.append(resultStr).append("\n");
                    Thread.sleep(10);
                }

                if (!testsEnded) {
                    testsEnded = (i == testScript.testRunsScript.testRuns);
                }
                
                //display final result
                finalResult = evalMediator.getTestResult();
                if (finalResult != null) {
                    resultStr = finalResult.getText();

                    if ((resultStr == null) || resultStr.equals("")) {
                        resultStr = xmlToTaggedString(finalResult);
                    }
                }
                else {
                    resultStr = "Final result is null.";
                }

                problemDatasets = problemMediator.getProblem().getProblemSet();
                exeDescr.append("\nFinal result:\n").append(resultStr);
                
                //calculate the statistical groupings
                statResults = problemMediator.processResult(testScript.solverType);
                if (statResults != null) {
                    //update cluster links - all solutions grouped together can be used to
                    //determine the linked services, while the stat clusters can be used to
                    //check that the correct solutions are being grouped together
                    solutionClusters = statResults.clusters;
                    CollectionHandler.addAll(finalSolutionClusters, solutionClusters);
                    finalSolutionClusters = SolverFactory.getInstance().getSolverData().getProcessResult(testScript.solverType).removeDuplicateGroups(finalSolutionClusters);
                }
                             
                if (problemMediator.serverSpec.serviceMediator != null) {
                    //if no linked sources then tests ended
                    newLinkedSources = problemMediator.serverSpec.serviceMediator.getLinkedServiceUuids();
                    if (statResults != null) {
                        statResults.getAnalyseLinks().analyseLinks(newLinkedSources, new LinkQueryConfig());
                    }
                    
                    if (!testsEnded) {
                        //if current and previous linked sets the same then tests ended
                        for (i = 0; i < newLinkedSources.size(); i++)
                        {
                            if (!linkedSources.contains(newLinkedSources.get(i))) break;
                        }
                        
                        testsEnded = ((newLinkedSources.isEmpty() || testScript.testRunsScript.testCanEnd(null)) || 
                                (i == newLinkedSources.size()));
                        
                        if (testsEnded) {
                            linksRollbackCount++;
                            testRunVars = new HashMap<>();
                            testRunVars.put(SolverConst.ROLLBACKS, new Integer(linksRollbackCount));
                            testsEnded = testScript.testRunsScript.testCanEnd(testRunVars);
                        }
                        else {
                            linksRollbackCount = 0;
                        }
                    }

                    for (i = 0; i < newLinkedSources.size(); i++)
                    {
                        if (!linkedSources.contains(newLinkedSources.get(i))) {
                            linkedSources.add(newLinkedSources.get(i));
                        }
                    }
                }
                else {
                    testsEnded = true;
                }
                
                if (statResults != null) {
                    exeDescr.append("\nStats results:\n").append(statResults.toString());
                }
            }
            
            //store the final test result
            result = toClusters(finalSolutionClusters);
            return exeDescr.toString();
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "runTestSet",
                null, ex);
        }
    }
    
    /**
     * Convert the cluster lists into a cluster object.
     * @param finalSolutions list of clusters. ArrayList or Vectors.
     * @return clusters as cluster objects.
     */
    protected ClusterResult toClusters(ArrayList<ArrayList<String>> finalSolutions)
    {
        int i;
        ArrayList nextCluster;                  //next cluster
        Cluster cluster;                        //next cluster
        ClusterResult cResult;                  //cluster result
        
        cResult = new ClusterResult();
        for (i = 0; i < finalSolutions.size(); i++)
        {
            nextCluster = finalSolutions.get(i);
            cluster = new Cluster(Cluster.toKey(i+1), nextCluster);
            cResult.addCluster(cluster);
        }
        
        return cResult;
    }
}