/*
 * GridProblemMediator.java
 *
 * Created on 9 August 2010
 *
 * Version 1.14
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.mediator.problem;


import org.ai_heuristic.eval.metric.MetricDataset;
import org.ai_heuristic.eval.result.EvalBounds;
import org.ai_heuristic.eval.result.MatchResult;
import org.licas.ai_solver.model.comp.CompoundSolution;
import org.licas.ai_solver.model.*;
import org.licas.ai_solver.spec.GridProblemScript;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.util.*;

import org.licas.PasswordHandler;
import org.licas.server.LocalServer;
import org.ai_heuristic.util.AiHeuristicConst;

import org.licas.ai_solver.SolverFactory;
import org.licas.ai_solver.mediator.ProblemSolverMediator;
import org.licas_xml.abs.*;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.util.*;


/**
 * This is the abstract base class for modelling the grid problem.
 * A grid framework will try to combine the solutions to find the optimal one, 
 * and in this case, it is setup for the new hyper-heuristic type of grid.
 * @author Kieran Greer
 */
public abstract class GridProblemMediator extends IterateMediatorEvolve
{
    /** For logging errors */
    private static final Logger logger;

    
    /** Intermediate solution results */
    protected EvalBounds intermediateBounds;

    /** The current optimal value */
    protected Object currentOptValue;

    /** The best optimal value */
    protected Object bestOptValue;

    /** Maximum allowed number of solutions */
    protected int maxSolutionsNumber;
    
    /** The maximum size for a whole problem if required */
    protected int wholeProblemSize;

    /** The maximum size for part of a problem if required */
    protected int partProblemSize;

    /** The maximum number of problem parts if required */
    protected int partProblemNumber;

    /** The previous grid solution, before this one */
    protected MatchResult lastGridSolution;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(GridProblemMediator.class.getName());
        logger.setDebug(false);
    }
    
    
    /**
     * Create a new instance of GridProblemMediator.
     * @param thePasswordHandler for storing passwords.
     */
    public GridProblemMediator(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        currentOptValue = null;
        bestOptValue = null;
        maxSolutionsNumber = -1;
        wholeProblemSize = 0;
        partProblemSize = 0;
        partProblemNumber = 0;
        resetValues();
    }
    
    /** Reset to starting values */
    public void resetValues()
    {
        super.resetValues();     
        intermediateBounds = null;
        lastGridSolution = null;
    }
    
    /**
     * Copy any values specific to the problem solver classes to the related specific
     * structures, from the more general list of variables from the Problem Spec itself.
     * @param testSpec the model of the tests to perform.
     * @throws java.lang.Exception any error.
     */
    public void copyToConfig(TestSpec testSpec) throws Exception
    {
        GridProblemScript testScript;                  //test script
        
        super.copyToConfig(testSpec);
        testScript = (GridProblemScript)testSpec.getTestScript();
        setMaxSolutionsNumber(testScript.maxSolutionNum);               
    }
    
    /**
     * Try to (re)sort the problem list after making appropriate changes.
     * @param testSpec the test specification describing the test run.
     * @param reOrder true if randomise the ordering for the next test iteration.
     * @throws java.lang.Exception any error.
     */
    protected void sortProblems(TestSpec testSpec, boolean reOrder) throws Exception
    {
        ProblemSolverMediator solverMediator;       //solver mediator
        
        intermediateBounds = new EvalBounds();
        inputVariables = new HashMap();
        
        //retrieve the dataset values and initialise the knn
        solverMediator = (ProblemSolverMediator)SolverFactory.getInstance().getSolverMediators().createServiceMediator(solverType);
        serviceNames = solverMediator.getServiceNames();
            
        //create the problems with the data
        if (LocalServer.isRunning()) {
            dataHash = solverMediator.getServicesData(testSpec);
            createStoreData(testSpec);
        }
        else {
            //can be central file-only test with no server or services
            dataHash = new LinkedHashMap<>();
            createStoreData(testSpec);
        }
        
        //randomise the problem dataset order and then sync with the solutions list                    
        if (reOrder) reOrderSolutionsAndProblems();
            
        //add problems list to data and calculate solution in correct order for grid
        inputVariables.put(AiHeuristicConst.PROBLEMS, problem.getProblemSet());
    }
    
    /**
     * Try to reorder the solutions and the problems but also keep a consistent
     * ordering between them for any grid conversion.
     */
    private void reOrderSolutionsAndProblems()
    {
        int i, j, k;
        boolean nameExists;                             //true if a name exists
        int index1;                                     //index
        int index2;                                     //index
        int minIndex;                                   //minimum index value
        String nextName;                                //next name
        String probName1;                               //problem name
        String probName2;                               //problem name
        ArrayList<String> sortedNames;                  //list of sorted names
        ArrayList<String> solutionNamesOrder;           //current solutions order
        HashMap<String, MetricDataset> problemsList;    //problems list
        SolutionContainer solutionContainer;            //solution container
        
        //randomise problems order and then set solutions in the same order
        //just need to re-order names list and then solve based on this
        nameExists = true;
        sortedNames = new ArrayList();
        minIndex = Integer.MAX_VALUE;

        problemsList = problem.getProblemSet();
        solutionContainer = solutionHierarc.get(solutionHierarc.size()-1);
        solutionNamesOrder = solutionContainer.getSolutionNames();
        problem.clearProblemSet();
        problem.getProblemSet().putAll((Map<String, MetricDataset>) randomiseHashtableOrder(problemsList));

        problemsList = problem.getProblemSet();
        for (i = 0; nameExists && (i < problemsList.size()-1); i++)
        {
            index1 = -1;
            probName1 = NameHandler.checkforName(problemsList.get(i));
            nameExists = (probName1 != null);
            
            if (nameExists) {
                minIndex = Integer.MAX_VALUE;
                sortedNames.add(probName1);

                for (j = 0; j < solutionNamesOrder.size(); j++)
                {
                    nextName = solutionNamesOrder.get(j);
                    if (nextName.equals(probName1)) {
                        index1 = j;
                        break;
                    }
                }
                
                for (j = i+1; nameExists && (j < problemsList.size()); j++)
                {
                    probName2 = NameHandler.checkforName(problemsList.get(j));
                    nameExists = (probName2 != null);

                    if (nameExists) {
                        index2 = -1;
                        for (k = 0; k < solutionNamesOrder.size(); k++)
                        {
                            nextName = solutionNamesOrder.get(k);
                            if (!sortedNames.contains(nextName) && nextName.equals(probName2)) {
                                index2 = k;
                                break;
                            }
                        }
                        
                        if ((index1 >= 0) && (index2 >= 0)) {
                            if (minIndex > index2) minIndex = index2;
                        }
                    }
                }
            }
            
            //move name to minimum index position if less than current position
            if ((index1 >= 0) && (minIndex >= 0)) {
                if (minIndex < index1) {
                    nextName = solutionNamesOrder.get(index1);
                    solutionNamesOrder.remove(index1);
                    solutionNamesOrder.add(minIndex, nextName);
                }
            }
        }             
    }
    
    /**
     * Reset the problem-solving structures for the next run. In this case, remove
     * the named solutions from the list of current ones.
     * @param varList a list of variables as key-value pairs. Needs to include the test spec.
     * @return true if all are removed, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean resetForNextRun(HashMap varList) throws Exception
    {
        TestSpec testSpec;                      //test spec
       
        testSpec = (TestSpec)varList.get(SolverConst.TESTOPTIONS);
        firstSolutionsAndProblems(testSpec);        
        return true;
    }
    
    /**
     * Rollback to the previous solution set. This sets testEnded to true if the
     * rollback was unsuccessful.
     * @param randomise if true also randomise the new solutions in the previous
     * solution set with regard to their positions.
     * @throws java.lang.Exception any error.
     */
    public void restorePreviousSolutionSet(boolean randomise) throws Exception
    {
        CompoundSolution newSolutionLevel;                      //new solution level
        CompoundSolution thisSolutionLevel;                     //this solution level
        CompoundSolution prevSolutionLevel;                     //previous solution level
        
        try {
            thisSolutionLevel = CompoundSolution.toCompoundSolution(solutionHierarc.get(solutionHierarc.size()-1));
            prevSolutionLevel = CompoundSolution.toCompoundSolution(solutionHierarc.get(solutionHierarc.size()-2));
            
            if (randomise) {
                newSolutionLevel = thisSolutionLevel.randomiseNewSolutionOrder(prevSolutionLevel);
                if (newSolutionLevel != null) {
                    solutionHierarc.remove(solutionHierarc.size()-1);
                    solutionHierarc.add(newSolutionLevel);
                }
            }
            else {
                newSolutionLevel = prevSolutionLevel;
                solutionHierarc.remove(solutionHierarc.size()-1);
            }
            
            if (newSolutionLevel == null) testEnded = true;
            else testEnded = newSolutionLevel.getSolutions().isEmpty();
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "restorePreviousSolutionSet", null, ex);
        }
    }
    
    /**
     * This method checks for conditions that indicate that the current set of
     * results are better than the previous set.
     * @param solutionSet the solution set to evaluate.
     * @return true if the current result set is better, false otherwise.
     * @throws java.lang.Exception any error.
     */
    protected boolean calcResultsBetter(MatchResult solutionSet) throws Exception
    {
        //if the current solution has either a better average score or a better
        //best score then these results are better
        if (lastGridSolution != null) {
            resultsBetter = (!solutionSet.getSolutionMatches().isEmpty() &&
                            (solutionSet.getAverageScore() >
                            lastGridSolution.getAverageScore()) ||
                            (solutionSet.getBestScore() >
                            lastGridSolution.getBestScore()));
        }
        else {
            resultsBetter = true;
        }

        return resultsBetter;
    }
    
    /**
     * Check for conditions that indicate that the test runs have or should be
     * terminated. This also resets the previous solution results that are stored.
     * @param solutionSet the last solution set to evaluate.
     * @throws java.lang.Exception any error.
     */
    protected void calcTestEnded(MatchResult solutionSet) throws Exception
    {
        testEnded = solutionSet.getSolutionMatches().isEmpty();
        lastGridSolution = solutionSet;
    }
    
    /**
     * Get the results of the test.
     * @return the test results in XML format.
     * @throws java.lang.Exception any error.
     */
    public Element getResultXml() throws Exception
    {
        Element resultElem;                     //result element

        resultElem = XMLFactory.getInstance().createElement(SolverConst.SUCCESS_PROBABILITY);
        resultElem.setText(ResultFormatter.convertToString(result));

        return resultElem;
    }

    /**
     * Randomise the order of the entries in the hashtable.
     * @param toRandomise the hashtable to randomise.
     * @return the same values but in a different order.
     */
    public HashMap<String, ?> randomiseHashtableOrder(HashMap toRandomise)
    {
        int i;
        int index;                                      //index totalValue
        String nextKey;                                 //next key totalValue
        ArrayList<String> keyList;                      //list of keys
        ArrayList<String> newKeyList;                   //new list of keys
        HashMap randomised;                             //randomised values
        Random rnd;                                     //random number generator

        rnd = new Random();
        randomised = new HashMap<>();
        newKeyList = new ArrayList<>();
        keyList = new ArrayList(toRandomise.keySet());

        //create random order
        while (!keyList.isEmpty())
        {
            index = rnd.nextInt(keyList.size());
            newKeyList.add(keyList.get(index));
            keyList.remove(index);
        }

        //add to new hashtable in ramdon order
        for (i = 0; i < newKeyList.size(); i++)
        {
            nextKey = newKeyList.get(i);
            randomised.put(nextKey, toRandomise.get(nextKey));
        }

        return randomised;
    }
    
    /**
     * Set the maximum allowed number of solutions. This can be optional.
     * @param thisMaxSolutionsNumber the maximum number of solutions.
     */
    public void setMaxSolutionsNumber(int thisMaxSolutionsNumber)
    {
        maxSolutionsNumber = thisMaxSolutionsNumber;
    }

    /**
     * Get the maximum number of allowed solutions. This can be optional.
     * @return the value of maxSolutionsNumber.
     */
    public int getMaxSolutionsNumber()
    {
        return maxSolutionsNumber;
    }
    
    /**
     * Set the maximum size for a whole problem.
     * @param thisWholeProblemSize the maximum size for a whole problem.
     */
    public void setWholeProblemSize(int thisWholeProblemSize)
    {
        wholeProblemSize = thisWholeProblemSize;
    }

    /**
     * Get the maximum size for a whole problem.
     * @return the totalValue of wholeProblemSize.
     */
    public int getWholeProblemSize()
    {
        return wholeProblemSize;
    }

    /**
     * Set the maximum size for part of a problem.
     * @param thisPartProblemSize the maximum size for a problem part.
     */
    public void setPartProblemSize(int thisPartProblemSize)
    {
        partProblemSize = thisPartProblemSize;
    }

    /**
     * Get the maximum size for part of a problem.
     * @return the totalValue of partProblemSize.
     */
    public int getPartProblemSize()
    {
        return partProblemSize;
    }

    /**
     * Set the maximum number of problem parts.
     * @param thisPartProblemNumber the maximum number of problem parts.
     */
    public void setPartProblemNumber(int thisPartProblemNumber)
    {
        partProblemNumber = thisPartProblemNumber;
    }

    /**
     * Get the maximum number of problem parts.
     * @return the totalValue of partProblemNumber.
     */
    public int getPartProblemNumber()
    {
        return partProblemNumber;
    }

    /**
     * Return true if the current set of results are better than the previous
     * set of results. This is not set automatically and needs to be implemented
     * by any derived class.
     * @return the value of resultsNotBetter.
     */
    public boolean getResultsBetter()
    {
        return resultsBetter;
    }
}
