/*
 * ClusterStats.java
 *
 * Created on 3 June 2011
 *
 * Version 1.2.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.stat;


import org.ai_heuristic.eval.result.MatchResult;
import org.licas.ai_solver.def.ClusterStatsDef;
import org.licas.ai_solver.mediator.problem.GridProblemMediator;
import org.licas.ai_solver.util.*;
import org.licas.util.exception.LicasException;

import java.util.*;


/**
 * This class can be used to compare solutions and calculate some stats relating
 * to ones that are grouped together. The solution names are assumed to be in the
 * format specified in the {@link NameHandler} class. These stats are not proper clusters
 * but show what solutions from the correct cluster groups have been clustered together
 * by the problem solving process.
 * @author Kieran Greer
 */
public class ClusterStats extends ProcessResult implements ClusterStatsDef
{
    /** Other key-value pairs for output */
    public HashMap<String, ?> otherStats;
        
    /**
     * Create a new instance of ClusterStats.
     */
    public void ClusterStats()
    {
        otherStats = new HashMap<>();
    }
    
    /**
     * Calculate the stats. These should be calculated based on the clusters that
     * have been generated from the problem-solving process. The stats results can then
     * be used to define network links, or the final cluster values, etc.
     * @param problemSpec the whole problem specification with a list of all solutions.
     * @param solutionSet the problem solving solution set. This is the object that
     * the problem solver returns and contains the problem solver clustering solution.
     * @throws java.lang.Exception any error.
     */
    public void calcStats(GridProblemMediator problemSpec, MatchResult solutionSet) throws Exception
    {
        calcNameStats(solutionSet);
    }
    
    /**
     * Calculate stats based on the solution names.
     * @param gridSolution the final grid solution.
     * @throws java.lang.Exception any error.
     */
    protected void calcNameStats(MatchResult gridSolution) throws Exception
    {
        int i, j, k;
        boolean namesCombined;                          //true if name are combined
        boolean namesAdded;                             //true if name are added
        int groupIndex;                                 //group index
        String solutionName;                            //solution name
        String sourceName;                              //source name
        String nextName;                                //next name
        ArrayList<String> nextList;                     //next list
        ArrayList<ArrayList<String>> categoryGroups;    //names in same category
        ArrayList<String> nameCounts;                   //names in order
        ArrayList<ArrayList<String>> allGroups;         //all cluster groups
        
        if (gridSolution != null) {
            categoryGroups = solutionNamesInGroups(gridSolution);
            
            //process the groups
            groupIndex = -1;
            clusters = categoryGroups;
            nameCounts = mostPopularCount(categoryGroups);
            categoryGroups = sameCategoryCount(categoryGroups);

            //select top names that are from same source
            if (!nameCounts.isEmpty()) {
                sourceName = nameCounts.get(0);
                sourceName = NameHandler.getNameSource(sourceName);

                for (i = 1; i < nameCounts.size(); i++)
                {
                    nextName = nameCounts.get(i);
                    if (!sourceName.equals(NameHandler.getNameSource(nextName))) {
                        groupIndex = i;
                        break;
                    }
                }
            }

            //remove all of the name counts after the index value
            if (groupIndex > 0) {
                while (nameCounts.size() > groupIndex) nameCounts.remove(groupIndex);
            }

            //always include category groups
            //if sequence of popular counts of same type then also include
            //or add to existing category group if it enlarges it
            namesCombined = false;
            allGroups = categoryGroups;

            if (nameCounts.size() > 1) {
                for (i = 0; i < allGroups.size(); i++)
                {
                    namesAdded = false;
                    nextList = allGroups.get(i);

                    for (j = 0; !namesAdded && (j < nextList.size()); j++)
                    {
                        solutionName = nextList.get(j);
                        if (nameCounts.contains(solutionName)) {
                            namesCombined = true;
                            namesAdded = true;

                            for (k = 0; k < nameCounts.size(); k++)
                            {
                                nextName = nameCounts.get(k);
                                if (!nextList.contains(nextName)) nextList.add(nextName);
                            }
                        }
                    }
                }

                if (!namesCombined) allGroups.add(nameCounts);
            }
        }
    }
    
    /**
     * Count the number of times each name is used.
     * @param nameList the name lists to count.
     * @return the number of times each name is used as part of a solution from
     * the most to the least.
     * @throws java.lang.Exception any error.
     */
    protected ArrayList<String> mostPopularCount(ArrayList<ArrayList<String>> nameList) throws Exception
    {
        int i, j;
        int maxIndex;                               //max index
        int maxCount;                               //max category count
        Integer nextCount;                          //next count
        String maxName;                             //max name
        String nextName;                            //next name
        ArrayList<String> currentCounts;            //current counts list
        ArrayList<String> orderCounts;              //counts in order
        ArrayList<String> nextList;                 //next category list
        HashMap<String, Integer> nameCounts;        //name counts
        
        nameCounts = new HashMap<>();
        
        for (i = 0; i < nameList.size(); i++)
        {
            nextList = nameList.get(i);
            for (j = 0; j < nextList.size(); j++)
            {
                nextName = nextList.get(j);
                if (!nameCounts.containsKey(nextName)) {
                    nameCounts.put(nextName, 0);
                }

                nextCount = nameCounts.get(nextName);
                nameCounts.put(nextName, nextCount.intValue()+1);
            }
        }
        
        //re-order from most to least counts
        orderCounts = new ArrayList<>();
        currentCounts = new ArrayList<>(nameCounts.keySet());
        
        while (!currentCounts.isEmpty())
        {
            maxCount = 0;
            maxIndex = -1;
            maxName = null;
            
            for (i = 0; i < currentCounts.size(); i++)
            {
                nextName = currentCounts.get(i);
                nextCount = nameCounts.get(nextName);
                
                if (nextCount.intValue() > maxCount) {
                    maxName = nextName;
                    maxCount = nextCount.intValue();
                    maxIndex = i;
                }
            }
            
            if (maxIndex >= 0) {
                orderCounts.add(maxName);
                currentCounts.remove(maxIndex);
            }
            else {
                throw new LicasException("ClusterStats.mostPopularCount: Error with stats: " + 
                        "count value not retrieved.");
            }
        }     
        
        return orderCounts;
    }
    
    /**
     * Count the number of names from the same category in the list.
     * @param nameList the list of names to compare.
     * @return the largest group(s) of names from the same category. Key is the
     * name and category, while value is the list of complete names.
     */
    protected ArrayList<ArrayList<String>> sameCategoryCount(ArrayList<ArrayList<String>> nameList)
    {
        int i, j;
        boolean isSame;                                 //true if is same
        int maxCount;                                   //max category count
        String keyName;                                 //key name
        String nextName;                                //next name
        String newName;                                 //new name
        ArrayList<String> nextList;                     //next category list
        ArrayList<String> newList;                      //new category list
        ArrayList<ArrayList<String>> sameCategories;    //same categories lists
        ArrayList<ArrayList<String>> maxCategories;     //max same categories lists
        
        maxCount = 0;
        sameCategories = new ArrayList<>();
        
        for (i = 0; i < nameList.size(); i++)
        {
            //add first name in the list to mark generic category key value
            newList = new ArrayList<>();
            nextList = nameList.get(i);
            
            nextName = nextList.get(0);
            keyName = NameHandler.getNameSource(nextName);
            newList.add(nextList.get(0));

            //add all other names but must be under same generic key value
            isSame = true;
            for (j = 1; isSame && (j < nextList.size()); j++)
            {
                nextName = nextList.get(j);
                newName = NameHandler.getNameSource(nextName);
                
                if (keyName.equals(newName)) {
                    newName = nextList.get(j);
                    if (!newList.contains(newName)) newList.add(newName);
                }
                else {
                    newList.clear();
                    isSame = false;
                }
            }
            
            if (isSame && !newList.isEmpty()) sameCategories.add(newList);
        }
        
        //count and keep categories with most list entries
        maxCategories = new ArrayList<>();
        for (i = 0; i < sameCategories.size(); i++)
        {
            nextList = sameCategories.get(i);
            
            if (nextList.size() > maxCount) {
                maxCount = nextList.size();
                maxCategories.clear();
                maxCategories.add(nextList);
            }
            else if (nextList.size() == maxCount) {
                maxCategories.add(nextList);
            }
        }

        return maxCategories;
    }
    
    /**
     * Convert the stats values into a string-based description.
     * @return a String-based description of the stats object.
     */
    public String toString()
    {
        String statsStr;                    //stats as a string
        
        statsStr = ("Stats groups: " + String.valueOf(clusters));
        if (otherStats != null) statsStr += ("\nOther stats: " + String.valueOf(otherStats));
        try {
            statsStr += ("\n" + dynamicLinksAnalysis());
        }
        catch (Exception ex) {
            statsStr += ("\nError processing the dynamic links.");
        }
        
        return statsStr;
    }
}
