/*
 * DefaultEvolveGenes.java
 *
 * Created on 8 April 2011
 *
 * Version 1.1.4
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.model.genetic.genes;


import org.licas.ai_solver.SolverFactory;
import org.licas.ai_solver.eval.EvaluateSolverData;

import org.licas.data.DataQueryModel;
import org.ai_heuristic.util.AiHeuristicConst;
import org.ai_heuristic.eval.metric.MetricValue;

import java.util.*;


/**
 * This is the default implementation for combining two different gene lists through
 * crossover or mutation to generate a new one. This will only evolve one gene value
 * at a time
 * @author Kieran Greer
 */
public class DefaultEvolveGenes extends EvolveGenes
{
    /**
     * Create a new instance of DefaultEvolveGenes.
     * @param thisGeneType the type of gene as the object classname.
     * @param thisEvolveTypes the different ways that a crossover or mutation can be performed.
     */
    public DefaultEvolveGenes(String thisGeneType, ArrayList<String> thisEvolveTypes)
    {
        super(thisGeneType, thisEvolveTypes);
    }
    
    
    /**
     * Return true if the two sets of genes are the same.
     * @param geneList1 the first list of consider.
     * @param geneList2 the second list to consider.
     * @return true if the genes are the same. This implementation returns false by
     * default. You need to override this implementation to make any real comparison.
     * @throws java.lang.Exception any error.
     */
    public boolean areSame(ArrayList<?> geneList1, ArrayList<?> geneList2) throws Exception
    {
        return false;
    }
    
    /**
     * Generate a crossover between this gene list and the variable passed in.
     * This version randomly selects a gene from list 2 and swaps a gene from
     * list 1 in the same position with it.
     * @param geneList1 the first list of consider.
     * @param geneList2 the second list to consider.
     * @return the result of the crossover. Can return null.
     * @throws java.lang.Exception any error.
     */
    protected ArrayList<?> crossover(ArrayList<?> geneList1, ArrayList<?> geneList2) throws Exception
    {
        int index;                                      //index value
        ArrayList combinedGenes;                        //combined gene sequence
        Random rnd;                                     //random number generator

        rnd = new Random(System.currentTimeMillis());
        if (geneList2.size() <= geneList1.size()) index = rnd.nextInt(geneList2.size());
        else index = rnd.nextInt(geneList1.size());

        combinedGenes = (ArrayList)geneList1.clone();
        combinedGenes.set(index, geneList2.get(index));
        return combinedGenes;
    }

    /**
     * Generate a mutation between this gene list and the variable passed in.
     * This version randomly selects a gene from list 1 and list 2. It adds them
     * together, removes the selected gene from list 1 and replaces it with the 
     * mutated gene. This uses the default evaluation service to add the gene
     * values together.
     * @param geneList1 the first list of consider.
     * @param geneList2 the second list to consider.
     * @return the result of the mutation. Can return null.
     * @throws java.lang.Exception any error.
     */
    protected ArrayList<?> mutate(ArrayList<?> geneList1, ArrayList<?> geneList2) throws Exception
    {
        boolean usesMetricValue;                //true if uses metric value
        int index;                              //index value
        ArrayList combinedGenes;                //combined gene sequence
        Object gene1;                           //first gene
        Object gene2;                           //second gene
        Object newGene;                         //new gene
        Object divTwo;                          //new gene represntation of 2
        DataQueryModel dataInfo;                //stores evaluator parameters
        EvaluateSolverData eval;                //evaluation service
        MetricValue metricValue;                //metric value
        Random rnd;                             //random number generator
        
        usesMetricValue = false;
        rnd = new Random(System.currentTimeMillis());
        
        dataInfo = new DataQueryModel();
        dataInfo.setDataType(geneType);               
        eval = SolverFactory.getInstance().getSolverData().getEvaluateData(dataInfo);
        
        if (geneList2.size() <= geneList1.size()) index = rnd.nextInt(geneList2.size());
        else index = rnd.nextInt(geneList1.size());

        gene1 = geneList1.get(0);
        if (gene1 instanceof MetricValue) {
            gene1 = ((MetricValue)gene1).getValue();
            usesMetricValue = true;
        }
        
        gene2 = geneList2.get(0);
        if (gene2 instanceof MetricValue) gene2 = ((MetricValue)gene2).getValue();
        
        //want to average the two object values, but what is this for arbitrary objects?
        //to get the value 2 to divide with, divide two of the new gene by one of it.
        //then divide the new gene by that value to get the averqge over the original two genes
        newGene = eval.mathOperation(geneType, gene1, gene2, AiHeuristicConst.ADD);        
        divTwo = eval.mathOperation(geneType, newGene, newGene, AiHeuristicConst.ADD);       
        divTwo = eval.mathOperation(geneType, divTwo, newGene, AiHeuristicConst.DIVIDE);       
        newGene = eval.mathOperation(geneType, newGene, divTwo, AiHeuristicConst.DIVIDE);       
               
        if (usesMetricValue) {
            metricValue = MetricValue.toValue(((MetricValue)geneList1.get(0)).getName(),
                ((MetricValue)geneList1.get(0)).getValueType(), newGene);
            
            newGene = metricValue;
        }
        
        combinedGenes = (ArrayList)geneList1.clone();
        combinedGenes.set(index, newGene);
        return combinedGenes;
    }
}
