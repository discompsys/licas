/*
 * SolverData.java
 *
 * Created on 29 January 2016
 *
 * Version 1.0.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.licas.ai_solver.eval.*;
import org.licas.ai_solver.stat.ProcessResult;
import org.licas.data.DataQueryModel;

import java.util.*;


/**
 * This class describes the methods used by the solver data. A copy is stored in the
 * {@link SolverFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public abstract class SolverData
{
    /** 
     * List of modules automatically loaded in during startup. Of type {@link ModuleSolverFactory}.
     */
    protected static ArrayList<ModuleSolverFactory> solverModules;
    
    /**
     * Create a new instance of SolverData.
     * @param theSolverModules list of solver modules.
     */
    public SolverData(ArrayList<ModuleSolverFactory> theSolverModules)
    {
        solverModules = theSolverModules;
    }
    
    
    /**
     * Create and return the correct data evaluator.
     * @param dataInfo a full info description for the evaluator to be created.
     * Must include the dataset type at least.
     * @return the appropriate object to evaluate the values directly.
     * @throws java.lang.Exception any error.
     */
    public abstract EvaluateSolverData getEvaluateData(DataQueryModel dataInfo) throws Exception;
    
    /**
     * Get the object used to process the solver result, maybe to create lists of links.
     * @param solverType the type of test framework to solve the problem.
     * @return the result processor.
     */
    public abstract ProcessResult getProcessResult(String solverType);
    
    // Variables and and Types settings for each heuristic type below this comment
    
    /**
     * Get a list of available data types for a heuristic type.
     * @param heuristicType the heuristic type, or a data type.
     * @return the list of allowed data types.
     */
    public abstract ArrayList<String> getDatasetTypes(String heuristicType);
    
    /**
     * Get the object class name from the type name, for the known data object types.
     * @param datasetType the dataset type name.
     * @return the object class name. If not recognised, return {@code datasetType}.
     */
    public abstract String dataClassFromType(String datasetType);
    
    /**
     * Get the data type name, for the known data class name.
     * @param datasetType the dataset type class name.
     * @return the object type name. If not recognised, return {@code datasetType}.
     */
    public abstract String dataTypeFromClass(String datasetType);
}
