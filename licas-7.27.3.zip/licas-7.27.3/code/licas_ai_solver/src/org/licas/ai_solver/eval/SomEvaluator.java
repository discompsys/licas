/*
 * SomEvaluator.java
 *
 * Created on 10 October 2014
 *
 * Version 1.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.eval;


import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.mediator.problem.*;
import org.licas.ai_solver.util.SolverConst;

import org.jlog2.exception.ExceptionHandler;
import org.licas_xml.abs.*;
import org.jlog2.*;


/**
 * This class generates and solves problems using a SOM neural network.
 * @author Kieran Greer
 */
public class SomEvaluator extends EvaluatorCentral
{
    /** For logging */
    private static final Logger logger;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SomEvaluator.class.getName());
        logger.setDebug(false);
    }

    /** Create a new instance of SomEvaluator */
    public SomEvaluator()
    {
        super();
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {}

    /**
     * Create or initialise the original problem and solution values. As this is a
     * distributed test with services already setup, this method only sets a start message.
     * @param testSpec the specification describing the tests to run.
     * @param proMediator the model of the problem with all required elements.
     * @return true if initialised OK, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean initialiseMediator(TestSpec testSpec, ProblemMediator proMediator) throws Exception
    {
        Element origProblem;                                //original problem

        try
        {
            //add original problem to the result element
            origProblem = XMLFactory.getInstance().createElement(SolverConst.PROBLEM);           
            origProblem.setText("Original Problem Specification: generate from new set");            
            testResults.addContent(origProblem);

            return true;
        }
        catch (Exception ex)
        {
             throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "initialiseMediator", null, ex);
        }
    }
    
    /**
     * Run a set of tests based on the test specification.
     * @param testSpec the specification describing the tests to run.
     * @param probMediator the model of the problem with all required elements.
     * @return true if the current test results are better than the previous set.
     * @throws java.lang.Exception any error.
     */
    public boolean evaluateSolutions(TestSpec testSpec, ProblemMediatorCentral probMediator) throws Exception
    {
        SomProblemMediator somProbSpec;             //som problem spec
        
        try
        {
            //run tests on the problems - does not use the rollback, repeats, etc.
            //default always return true
            testResults = XMLFactory.getInstance().createElement(SolverConst.ALLRESULTS);           
            somProbSpec = (SomProblemMediator)probMediator;
            result = somProbSpec.solve(testSpec);
                
            lastTestResult = somProbSpec.getResultXml();
            testResults.addContent(lastTestResult);
          
            //always return results better as only 1 iteration
            return true;
        }
        catch (Exception ex)
        {
             throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "evaluateSolutions", null, ex);
        }
    }
}
