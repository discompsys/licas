/*
 * EvolveMediatorDef.java
 *
 * Created on 20 November 2015
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.def;


import org.licas.ai_solver.model.*;
import org.ai_heuristic.eval.metric.MetricDataset;


/**
 * Additional interface classes for a solver that evolves solutions.
 * @author Kieran Greer
 */
public interface EvolveMediatorDef
{
    /**
     * Create a new solution of the solution type, initialised with the problem dataset.
     * @param solutionType the type of solution to create.
     * @param problemDataset the problem dataset to create the solution with.
     * @return the new solution.
     * @throws java.lang.Exception any error.
     */
    Solution createNewSolution(String solutionType, MetricDataset problemDataset)
            throws Exception;
}
