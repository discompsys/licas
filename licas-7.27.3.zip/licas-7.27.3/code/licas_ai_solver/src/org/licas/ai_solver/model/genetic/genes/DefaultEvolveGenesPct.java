/*
 * EvolveGenesPct.java
 *
 * Created on 12 June 2013
 *
 * Version 1.1.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.model.genetic.genes;


import org.licas.ai_solver.SolverFactory;
import org.licas.ai_solver.eval.EvaluateSolverData;
import org.licas.data.DataQueryModel;
import org.ai_heuristic.util.AiHeuristicConst;
import org.ai_heuristic.eval.metric.MetricValue;

import java.util.*;


/**
 * This is the default implementation for combining two different gene lists through
 * crossover or mutation to generate a new one. This also allows the percentage of 
 * change, to create the evolved gene, to be specified. The ordering in the lists is maintained.
 * @author Kieran Greer
 */
public class DefaultEvolveGenesPct extends EvolveGenes
{
    /** Percentage of gene to mutate. In the range 0 to 1. */
    private float mutatePct;
    
    /** Percentage of gene to crossover. In the range 0 to 1. */
    private float crossoverPct;
    
    /**
     * Create a new instance of DefaultEvolveGenesPct.
     * @param thisGeneType the type of gene as the object classname.
     * @param thisEvolveTypes the different ways that a crossover or mutation can be performed.
     * @param thisMutatePct percentage of gene to mutate. In the range 0 to 1.
     * @param thisCrossoverPct percentage of gene to crossover. In the range 0 to 1.
     */
    public DefaultEvolveGenesPct(String thisGeneType, ArrayList<String> thisEvolveTypes, float thisMutatePct,
            float thisCrossoverPct)
    {
        super(thisGeneType, thisEvolveTypes);       
        mutatePct = thisMutatePct;
        crossoverPct = thisCrossoverPct;
    }
    
    
    /**
     * Return true if the two sets of genes are the same.
     * @param geneList1 the first list of consider.
     * @param geneList2 the second list to consider.
     * @return true if the genes are the same. This implementation returns false by
     * default. You need to override this implementation to make any real comparison.
     * @throws java.lang.Exception any error.
     */
    public boolean areSame(ArrayList<?> geneList1, ArrayList<?> geneList2) throws Exception
    {
        return false;
    }
    
    /**
     * Generate a crossover between this gene list and the variable passed in.
     * This version randomly selects a gene from list 2 and swaps a gene from
     * list 1 in the same position with it.
     * @param geneList1 the first list of consider.
     * @param geneList2 the second list to consider.
     * @return the result of the crossover. Can return null.
     * @throws java.lang.Exception any error.
     */
    protected ArrayList<?> crossover(ArrayList<?> geneList1, ArrayList<?> geneList2) throws Exception
    {
        int i;
        int index;                                      //index value
        int geneNumber;                                 //number of genes to crossover
        String indexStr;                                //index as a string
        ArrayList indexList;                            //list of indexes
        ArrayList combinedGenes;                        //combined gene sequence
        Random rnd;                                     //random number generator

        indexList = new ArrayList();
        rnd = new Random(System.currentTimeMillis());

        if (geneList2.size() <= geneList1.size()) {
            geneNumber = (int)((float)geneList2.size() * mutatePct);
        }
        else {
            geneNumber = (int)((float)geneList1.size() * mutatePct);
        }
        
        for (i = 0; i < geneList2.size(); i++)
        {
            indexList.add(null);
        }

        for (i = 0; i < geneNumber; i++)
        {
            index = -1;
            indexStr = "abc";

            while (!indexList.contains(indexStr))
            {
                index = rnd.nextInt(geneList2.size());
                indexStr = String.valueOf(index);
            }

            if (index > -1) {
                indexList.set(index, indexStr);
            }
        }

        combinedGenes = (ArrayList)geneList1.clone();
        for (i = 0; i < indexList.size(); i++)
        {
            indexStr = (String)indexList.get(i);
            if (indexStr != null) {
                index = Integer.parseInt(indexStr);
                combinedGenes.set(index, geneList2.get(index));
            }
        }
        
        return combinedGenes;
    }

    /**
     * Generate a mutation between this gene list and the variable passed in.
     * This version randomly selects a gene from list 1 and list 2. It adds them
     * together, removes the selected gene from list 1 and replaces it with the 
     * mutated gene. This uses the default evaluation service to add the gene
     * values together.
     * @param geneList1 the first list of consider.
     * @param geneList2 the second list to consider.
     * @return the result of the mutation. Can return null.
     * @throws java.lang.Exception any error.
     */
    protected ArrayList<?> mutate(ArrayList<?> geneList1, ArrayList<?> geneList2) throws Exception
    {
        int i;
        boolean usesMetricValue;                //true if uses metric value
        int index;                              //index value
        int geneNumber;                         //number of genes to crossover
        String indexStr;                        //index as a string
        ArrayList indexList;                       //list of indexes
        ArrayList combinedGenes;                   //combined gene sequence
        Object gene1;                           //first gene
        Object gene2;                           //second gene
        Object newGene;                         //new gene
        Object divTwo;                          //new gene represntation of 2
        DataQueryModel dataInfo;                      //stores evaluator parameters
        EvaluateSolverData eval;                //evaluation service
        MetricValue metricValue;                //metric value
        Random rnd;                             //random number generator
        
        usesMetricValue = false;
        indexList = new ArrayList();
        rnd = new Random(System.currentTimeMillis());
        
        dataInfo = new DataQueryModel();
        dataInfo.setDataType(geneType);               
        eval = (EvaluateSolverData)SolverFactory.getInstance().getSolverData().getEvaluateData(dataInfo);
        
        if (geneList2.size() <= geneList1.size()) 
        {
            geneNumber = (int)((float)geneList2.size() * crossoverPct);
        }
        else 
        {
            geneNumber = (int)((float)geneList1.size() * crossoverPct);
        }
        
        for (i = 0; i < geneList2.size(); i++)
        {
            indexList.add(null);
        }

        for (i = 0; i < geneNumber; i++)
        {
            index = -1;
            indexStr = "abc";

            while (!indexList.contains(indexStr))
            {
                index = rnd.nextInt(geneList2.size());
                indexStr = String.valueOf(index);
            }

            if (index > -1) 
            {
                indexList.set(index, indexStr);
            }
        }
               
        combinedGenes = (ArrayList)geneList1.clone();
        for (i = 0; i < indexList.size(); i++)
        {
            indexStr = (String)indexList.get(i);
            if (indexStr != null)
            {
                index = Integer.parseInt(indexStr);
                
                gene1 = geneList1.get(index);
                if (gene1 instanceof MetricValue)
                {
                    gene1 = ((MetricValue)gene1).getValue();
                    usesMetricValue = true;
                }

                gene2 = geneList2.get(index);
                if (gene2 instanceof MetricValue) 
                {
                    gene2 = ((MetricValue)gene2).getValue();
                }

                //want to average the two object values, but what is this for arbitrary objects?
                //to get the value 2 to divide with, divide two of the new gene by one of it.
                //then divide the new gene by that value to get the averqge over the original two genes
                newGene = eval.mathOperation(geneType, gene1, gene2, AiHeuristicConst.ADD);        
                divTwo = eval.mathOperation(geneType, newGene, newGene, AiHeuristicConst.ADD);       
                divTwo = eval.mathOperation(geneType, divTwo, newGene, AiHeuristicConst.DIVIDE);       
                newGene = eval.mathOperation(geneType, newGene, divTwo, AiHeuristicConst.DIVIDE);       

                if (usesMetricValue)
                {
                    metricValue = MetricValue.toValue(((MetricValue)geneList1.get(0)).getName(),
                        ((MetricValue)geneList1.get(0)).getValueType(), newGene);

                    newGene = metricValue;
                }

                combinedGenes.set(index, newGene);
            }
        }
        
        return combinedGenes;
    }
}
