/**
 * Classes for the genetic algorithm solutions. 
 */
package org.licas.ai_solver.model.genetic;