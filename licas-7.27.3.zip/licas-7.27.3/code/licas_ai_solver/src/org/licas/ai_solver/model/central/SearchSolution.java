/*
 * SearchSolution.java
 *
 * Created on 14 July 2015.
 *
 * Version 1.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.model.central;


import org.licas.ai_solver.model.EvalBounds;
import org.ai_heuristic.eval.metric.*;


/**
 * This class can be used for modelling single problem solutions.
 * It includes the evaluator, the dataset to evaluate and implements a second {@code solve} method,
 * to compare solutions.
 * @author Kieran Greer
 */
public class SearchSolution extends SingleSolution
{
    /**
     * Create a new instance of SearchSolution.
     * @param thisName the solution name.
     * @throws java.lang.Exception any error.
     */
    public SearchSolution(String thisName) throws Exception
    {
        super(thisName);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {}
    
    /**
     * Calculate the result of this solution over all problem datasets. The results are 
     * then put in a list and stored in the evaluation object.
     * @param compareTo the dataset to compare with.
     * @throws java.lang.Exception any error.
     */
    public void solve(SearchSolution compareTo) throws Exception
    {
        MetricCompare metricCompare;                //to compare datasets
        
        metricCompare = new MetricCompare(dataset, compareTo.getDataset());
        evaluation = new EvalBounds();
        evaluation.evaluation = evaluator.evaluate(metricCompare);
    }
    
    /**
     * Create and return a copy of this solution.
     * @return a shallow copy of this solution.
     */
    public Object clone()
    {
        SearchSolution cloneSolution;           //copy of the solution
        
        try {
            cloneSolution = new SearchSolution(this.name);
            cloneSolution.setEvaluator(evaluator);
            cloneSolution.setDataset(dataset);
            return cloneSolution;
        }
        catch (Exception ex) {
            return null;
        }
    }
}
