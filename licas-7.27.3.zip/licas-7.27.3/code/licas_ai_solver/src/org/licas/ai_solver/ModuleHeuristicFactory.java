/*
 * ModuleHeuristicFactory.java
 *
 * Created on 12 November 2015
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver;


import org.jlog2.*;


/**
 * This heuristic factory is read automatically by the GUI when loaded, to store a
 * pre-programmed script of the services it provides. The settings listed here are
 * added to the default list.
 * @author Kieran Greer.
 */
public abstract class ModuleHeuristicFactory extends HeuristicFactory
{
    /** The logger */
    private static Logger logger;
    
    static
    {
        try
        {
            // get the logger
            logger = LoggerHandler.getLogger(ModuleHeuristicFactory.class.getName());
            logger.setDebug(false);
        }
        catch (Exception ex) {}
    }

    /**
     * Create a new instance of ModuleHeuristicFactory.
     */
    public ModuleHeuristicFactory()
    {}
}
