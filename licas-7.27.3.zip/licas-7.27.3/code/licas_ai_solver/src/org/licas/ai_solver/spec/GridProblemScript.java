/*
 * GridProblemScript.java
 *
 * Created on 27 October 2014
 *
 * Version 1.1.5
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.spec;


import org.licas.service.spec.BehaviourScript;
import org.licas.PasswordHandler;
import org.licas.ai_solver.HeuristicFactory;
import org.licas.data.gen.DataGenerator;
import org.licas.util.*;

import org.licas.ai_solver.util.*;
import org.licas.util.HeuristicConst;


/**
 * This class reads an XML file and loads in a specification for a set of test runs.
 * This includes some additional variables for the hyper-heuristic or grid-type of tests.
 * @author Kieran Greer
 */
public class GridProblemScript extends ProblemScript
{
    /** If true, use link weight values still increasing as a stopping criterion */
    public boolean okIfLinkInc;
    
    /** If true, when rollback also randomise the order again for the next run */
    public boolean randomise;
        
    /** 
     * The maximum number of matches to carry over to the next solution phase.
     * For example, the maximum number of grid rows in HH comparisons (relating to solutions), 
     * or hill climb solutions.
     */
    public int maxMatches;
    
    
    /** 
     * Create a new instance of GridProblemScript.
     * @param thePasswordHandler for storing passwords.
     */
    public GridProblemScript(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        okIfLinkInc = true;
        randomise = true;
        maxMatches = 1000;
        testRunsScript = new GridTestRunsScript();
    }
    
    /**
     * Convert the set of values into the structure to be used to initialise the test services.
     * this depends on the framework, or solver type. The script is already setup for the 
     * centralised problem-solving and so does not need to be changed for that, for example,
     * but the distributed linking can be more easily initialised as the behaviour tests.
     * @return true if converted OK.
     */
    public boolean convertForInitialise()
    {
        String generatorClass;                      //generator class
        
        if (datasetType != null) {
            generatorClass = DataGenerator.getGeneratorClass(datasetType);
            if (generatorClass != null) {
                serviceClasses.put(ServiceConst.DATAGENERATORTYPE, generatorClass);
            }
        }
        
        return true;
    }
    
    
    /**
     * Copy the behaviour script values into this object.
     * @param behaviourScript the behaviour script.
     */
    public void copy(BehaviourScript behaviourScript)
    {
        if (behaviourScript != null) {
            super.copy(behaviourScript);
            
            //problem script variables
            if (behaviourScript instanceof GridProblemScript) {
                maxMatches = ((GridProblemScript)behaviourScript).maxMatches;
                randomise = ((GridProblemScript)behaviourScript).randomise;
                okIfLinkInc = ((GridProblemScript)behaviourScript).okIfLinkInc;
            }
        }
    }
    
    /**
     * Validate the whole script and return a description of any errors.
     * @return a description of any errors or null if OK.
     */
    public String validateScript()
    {
        boolean hhMatch;                        //true if hh solver type
        boolean geneticMatch;                   //true if genetic heuristic
        String validateReply;                   //validation errors
        
        hhMatch = (solverType.equals(HeuristicConst.GRIDHILL) || solverType.equals(HeuristicConst.GRIDMATCH));
        geneticMatch = HeuristicFactory.getInstance().getHeuristicData().canBeGeneticType(heuristicType);
        
        validateReply = super.validateScript();
        if (validateReply == null) validateReply = "";
        else validateReply += "\n";
        
        if (hhMatch && geneticMatch) {
            validateReply += validateVariable(SolverConst.MAXSOLUTIONS);
            validateReply += validateVariable(SolverConst.MUTATETYPES);
            validateReply += validateVariable(SolverConst.MAXMATCHES);
            validateReply += validateVariable(SolverConst.RANDOMISE);
            validateReply += validateVariable(SolverConst.OKLINKINC);
            validateReply += validateVariable(SolverConst.ROLLBACKS);
            validateReply += validateVariable(SolverConst.NONEWCLUSTERS);
        }
        
        validateReply = validateReply.trim();        
        if (validateReply.equals("")) validateReply = null;
        return validateReply;
    }
    
    /**
     * Validate the script variable and return a description if invalid.
     * @param varType the variable type.
     * @return a description of any error, of null if OK.
     */
    protected String validateVariable(String varType)
    {
        String validateError;                   //validate error
        
        validateError = super.validateVariable(varType);
        if ((validateError == null) || validateError.equals("")) {
            if (varType.equals(SolverConst.MUTATETYPES)) {
                if (heuristicOptions.isEmpty())
                    validateError = (SolverConst.MUTATETYPES + ": no values entered.\n");
            }
            else if (varType.equals(SolverConst.MAXMATCHES)) {
                try {
                    if (maxMatches <= 0.0)
                        validateError = (SolverConst.MAXMATCHES + ": must be greater than 0.\n");
                }
                catch (Exception ex) {
                    validateError = (SolverConst.MAXMATCHES + ": has incorrect format.\n");
                }
            }
            else if (varType.equals(SolverConst.OKLINKINC)) {
                //link increment - no check here
            }
            else if (varType.equals(SolverConst.RANDOMISE)) {
                //randomise - no check here
            }
            else if (varType.equals(SolverConst.ROLLBACKS)) {
                try {
                    if (((GridTestRunsScript)testRunsScript).rollbacks < 0)
                        validateError = (SolverConst.ROLLBACKS + ": must be greater than (or equal to) 0 if used.\n");
                }
                catch (Exception ex) {
                    validateError = (SolverConst.ROLLBACKS + ": has incorrect format.\n");
                }
            }
            else if (varType.equals(SolverConst.NONEWCLUSTERS)) {
                try {
                    if (((GridTestRunsScript)testRunsScript).noNewClusters < 0)
                        validateError = (SolverConst.NONEWCLUSTERS + ": must be greater than (or equal to) 0 if used.\n");
                }
                catch (Exception ex) {
                    validateError = (SolverConst.NONEWCLUSTERS + ": has incorrect format.\n");
                }
            }
        }
        
        return validateError;
    }
}
