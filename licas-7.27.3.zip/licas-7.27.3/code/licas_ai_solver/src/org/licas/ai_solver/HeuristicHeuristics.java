/*
 * HeuristicHeuristics.java
 *
 * Created on 30 January 2016
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.ai_heuristic.model.FactoryInfo;

import java.util.*;


/**
 * This class describes the methods used by the heuristic heuristics. A copy is stored in the
 * {@link HeuristicFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public abstract class HeuristicHeuristics 
{
    /** The default heuristic classifications */
    protected HeuristicClassification heuristicClassif;
    
    /** 
     * List of modules automatically loaded in during startup. Of type {@link ModuleHeuristicFactory}.
     */
    protected static ArrayList<ModuleHeuristicFactory> heuristicModules = new ArrayList<>();
    
    /** 
     * Create a new instance of HeuristicHeuristics. 
     * @param theHeuristicClassif the heuristic classifications.
     * @param theHeuristicModules list of heuristic modules.
     */
    public HeuristicHeuristics(HeuristicClassification theHeuristicClassif, ArrayList<ModuleHeuristicFactory> theHeuristicModules)
    {
        heuristicClassif = theHeuristicClassif;
        heuristicModules = theHeuristicModules;
    }
    
    
    /**
     * Get a list of available heuristic types - genetic, linking type, etc. Can include
     * actual classnames for specific types.
     * @param solverType the type of problem solving framework - hyper-compare, 
     * hill-climb, links, etc.
     * @return the list of relevant heuristic types. All types are returned if the 
     * solver type is not recognised.
     * This base class version returns and empty list. See {@link DefaultHeuristicHeuristics} for an example.
     */
    public HashMap<String, FactoryInfo> getHeuristicTypes(String solverType) {
        return new HashMap<>();
    }
    
    /**
     * Get a list of all available heuristic types that can be added to a framework in general.
     * @return the list of avaliable heuristic types.
     * This base class version returns and empty list. See {@link DefaultHeuristicHeuristics} for an example.
     */
    public HashMap<String, FactoryInfo> getAllHeuristicTypes() {
        return new HashMap<>();
    }
}
