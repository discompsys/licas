/*
 * SearchEvaluator.java
 *
 * Created on 21 July 2015
 *
 * Version 1.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.eval;


import org.licas.ai_solver.spec.test.*;
import org.licas.ai_solver.mediator.problem.*;
import org.licas.ai_solver.util.SolverConst;

import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;
import org.licas_xml.abs.*;


/**
 * This class runs a set of tests on the specified search problem model.
 * This class generates and solves problems based on a generic framework, with a centralised
 * problem-solver that evaluates and evolves solutions architecture.
 * @author Kieran Greer
 */
public class SearchEvaluator extends EvaluatorCentral
{
    /** For logging */
    private static final Logger logger;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SearchEvaluator.class.getName());
        logger.setDebug(false);
    }

    /** Create a new instance of SearchEvaluator */
    public SearchEvaluator()
    {
        super();
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {}

    /**
     * Create or initialise the original problem and solution values.
     * @param testSpec the specification describing the tests to run.
     * @param probMediator the model of the problem with all required elements.
     * @return true if initialised OK, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean initialiseMediator(TestSpec testSpec, ProblemMediator probMediator) throws Exception
    {
        SearchProblemMediator searchProbMediator;           //problem spec
        Element origProblem;                                //original problem

        try
        {
            //add original problem to the result element
            searchProbMediator = (SearchProblemMediator)probMediator;
            origProblem = XMLFactory.getInstance().createElement(SolverConst.PROBLEM);           
            origProblem.setText("Original Problem Specification: generate from new set");
            
            testResults.addContent(origProblem);
            searchProbMediator.firstSolutionsAndProblems(testSpec);

            return true;
        }
        catch (Exception ex)
        {
             throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "initialiseMediator", null, ex);
        }
    }
    
    /**
     * Run a set of tests based on the test specification.
     * @param testSpec the specification describing the tests to run.
     * @param probMediator the model of the problem with all required elements.
     * @return true if the current test results are better than the previous set.
     * @throws java.lang.Exception any error.
     */
    public boolean evaluateSolutions(TestSpec testSpec, ProblemMediatorCentral probMediator) throws Exception
    {
        SearchProblemMediator searchProbMediator;       //search problem mediator
        
        try
        {
            //run tests on the problems
            searchProbMediator = (SearchProblemMediator)probMediator;           
            testResults = XMLFactory.getInstance().createElement(SolverConst.ALLRESULTS);   
            
            result = searchProbMediator.solve(testSpec);            
            if (result != null)
            {
                evaluateStats(testSpec, probMediator);
                if (searchProbMediator.updateSolutions(result))
                {                  
                    lastTestResult = searchProbMediator.getResultXml();
                    testResults.addContent(lastTestResult);
                }
            }
            else
            {
                lastTestResult = searchProbMediator.getResultXml();
                testResults.addContent(lastTestResult);
            }
            
            return true;
        }
        catch (Exception ex)
        {
             throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "evaluateSolutions", null, ex);
        }
    }
}
