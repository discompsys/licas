/*
 * DefaultSolverSpecs.java
 *
 * Created on 29 January 2016
 *
 * Version 1.0.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.licas.ai_solver.parser.ProblemScriptParser;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.spec.ProblemScript;
import org.licas.ai_solver.parser.*;
import org.licas.ai_solver.central.SomConst;
import org.licas.ai_solver.spec.*;
import org.licas.ai_solver.spec.test.GridTestSpec;
import org.licas.ai_solver.util.*;

import org.licas.PasswordHandler;
import org.licas.service.link.LinkConfig;
import org.licas.util.Const;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas.util.HeuristicConst;

import java.util.*;


/**
 * This class describes the methods used by the solver test specification. A copy is stored in the
 * {@link DefaultSolverFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public class DefaultSolverSpecs extends SolverSpecs
{
    /**
     * Create a new instance of DefaultSolverSpecs.
     * @param thePasswordHandler the password handler.
     * @param theSolverModules list of solver modules.
     */
    public DefaultSolverSpecs(PasswordHandler thePasswordHandler, ArrayList theSolverModules)
    {
        super(thePasswordHandler, theSolverModules);
    }
    
    
    /**
     * Get the test specification object related to the current problem type.
     * @param solverType the type of test framework to solve the problem.
     * @return the related test specification object.
     */
    public TestSpec getTestSpec(String solverType)
    {
        int i;
        TestSpec testSpec;                          //test specification
        ModuleSolverFactory moduleFactory;          //module factory
        
        testSpec = null;
        if (solverType.equals(HeuristicConst.GRIDHILL) ||
            solverType.equals(HeuristicConst.GRIDMATCH))
        {
            testSpec = new GridTestSpec(passwordHandler);
        }
        else if (solverType.equals(HeuristicConst.SEARCHHILL))
        {
            testSpec = new TestSpec(passwordHandler);
        }
        else if (solverType.equals(HeuristicConst.LINKDISTRIBUTED))
        {
            testSpec = new TestSpec(passwordHandler);
        }
        else if (solverType.equals(HeuristicConst.NEARESTNEIGHBOUR))
        {
            testSpec = new TestSpec(passwordHandler);
        }
        else if (solverType.equals(HeuristicConst.SOMNN))
        {
            testSpec = new TestSpec(passwordHandler);
        }
        
        if (testSpec == null)
        {
            //add from the modules
            for (i = 0; (testSpec == null) && (i < solverModules.size()); i++)
            {
                moduleFactory = (ModuleSolverFactory)solverModules.get(i);
                if (moduleFactory.hasSolverSpecs())
                {
                    testSpec = moduleFactory.getSolverSpecs().getTestSpec(solverType);
                }
            }
        }

        return testSpec;
    }
    
    /**
     * Get the problem script object related to the current problem type.
     * @param solverType the type of test framework to solve the problem.
     * @return the related problem script object.
     */
    public ProblemScript getProblemScript(String solverType)
    {
        int i;
        ProblemScript problemScript;                //problem script
        ModuleSolverFactory moduleFactory;          //module factory
        
        problemScript = null;
        if (solverType.equals(SolverConst.PROBLEMSCRIPT) ||
            solverType.equals(HeuristicConst.GRIDMATCH) ||
            solverType.equals(HeuristicConst.GRIDHILL))
        {
            problemScript = new GridProblemScript(passwordHandler);
        }
        else if (solverType.equals(HeuristicConst.SEARCHHILL))
        {
            problemScript = new ProblemScript(passwordHandler);
        }
        else if (solverType.equals(HeuristicConst.LINKDISTRIBUTED))
        {
            problemScript = new ProblemScript(passwordHandler);
        }
        else if (solverType.equals(HeuristicConst.NEARESTNEIGHBOUR))
        {
            problemScript = new KnnProblemScript(passwordHandler);
        }
        else if (solverType.equals(HeuristicConst.SOMNN))
        {
            problemScript = new SomProblemScript(passwordHandler);
        }
        
        if (problemScript == null)
        {
            //add from the modules
            for (i = 0; (problemScript == null) && (i < solverModules.size()); i++)
            {
                moduleFactory = (ModuleSolverFactory)solverModules.get(i);
                if (moduleFactory.hasSolverSpecs())
                {
                    problemScript = moduleFactory.getSolverSpecs().getProblemScript(solverType);
                }
            }
        }

        return problemScript;
    }
    
    /**
     * Get the parser to create the problem script from an XML description.
     * @param solverType the type of test framework to solve the problem.
     * @return the related problem script parser.
     */
    public ProblemScriptParser getProblemScriptParser(String solverType)
    {
        int i;
        ProblemScriptParser problemScriptParser;    //problem script parser
        ModuleSolverFactory moduleFactory;          //module factory
        
        problemScriptParser = null;
        if (solverType.equals(SolverConst.PROBLEMSCRIPT) ||
            solverType.equals(HeuristicConst.GRIDMATCH) ||
            solverType.equals(HeuristicConst.GRIDHILL))
        {
            problemScriptParser = new GridProblemScriptParser(passwordHandler);
        }
        else if (solverType.equals(HeuristicConst.SEARCHHILL))
        {
            problemScriptParser = new ProblemScriptParser(passwordHandler);
        }
        else if (solverType.equals(HeuristicConst.LINKDISTRIBUTED))
        {
            problemScriptParser = new ProblemScriptParser(passwordHandler);
        }
        else if (solverType.equals(HeuristicConst.NEARESTNEIGHBOUR))
        {
            problemScriptParser = new KnnProblemScriptParser(passwordHandler);
        }
        else if (solverType.equals(HeuristicConst.SOMNN))
        {
            problemScriptParser = new SomProblemScriptParser(passwordHandler);
        }
        
        if (problemScriptParser == null)
        {
            //add from the modules
            for (i = 0; (problemScriptParser == null) && (i < solverModules.size()); i++)
            {
                moduleFactory = (ModuleSolverFactory)solverModules.get(i);
                if (moduleFactory.hasSolverSpecs())
                {
                    problemScriptParser = moduleFactory.getSolverSpecs().getProblemScriptParser(solverType);
                }
            }
        }

        return problemScriptParser;
    }
    
    /**
     * Get a list of test config script variables, for display purposes.
     * @param scriptType the type of script part. The default package is covered, for example
     * {@code TESTRUNSSCRIPT, GRIDHILL, GRIDMATCH, LINKDISTRIBUTED}, but you can add
     * others to derived classes.
     * @return the list of variable names.
     */
    public ArrayList<String> getTestScriptVariables(String scriptType)
    {
        int i;
        ArrayList typeList;                            //list of types
        ArrayList nextTypeList;                        //list of types
        ModuleSolverFactory moduleFactory;          //module factory
        
        typeList = new ArrayList();
        if (scriptType.equals(SolverConst.TESTRUNSSCRIPT) ||
            scriptType.equals(SolverConst.TESTRUNSSCRIPTGRID))
        {
            typeList.add(SolverConst.ADDINKS);
            typeList.add(SolverConst.OKLINKINC);
            typeList.add(SolverConst.ROLLBACKS);
            typeList.add(SolverConst.NONEWCLUSTERS);
            typeList.add(SolverConst.RANDOMISE);
        }
        else if (scriptType.equals(SolverConst.TESTRUNSSCRIPTSEARCH))
        {
            typeList.add(SolverConst.ADDINKS);
        }
        else if (scriptType.equals(HeuristicConst.GRIDHILL) || 
                scriptType.equals(HeuristicConst.GRIDMATCH))
        {
            typeList.add(SolverConst.MAXSOLUTIONS);
            typeList.add(SolverConst.RANGETYPE);
            typeList.add(SolverConst.RANGEVALUE);
            typeList.add(SolverConst.MAXMATCHES);           
        }
        else if (scriptType.equals(HeuristicConst.LINKDISTRIBUTED))
        {}
        else if (scriptType.equals(HeuristicConst.SOMNN))
        {
            typeList.add(SomConst.LEARNFRAMEWORK);
            typeList.add(SomConst.TOPOLOGY);
            typeList.add(SomConst.TOPOLOGYROW);
            typeList.add(SomConst.TOPOLOGYCOL);
            typeList.add(SomConst.TOPOLOGYRADIUS);
            typeList.add(SomConst.NEIGHBOURHOODFUNCION);
            typeList.add(SomConst.ACTIVATIONFUNCION);
            typeList.add(SomConst.WEIGHTSNUMBER);
        }
        else if (scriptType.equals(HeuristicConst.NEARESTNEIGHBOUR))
        {
            typeList.add(AiHeuristicConst.BS);
            typeList.add(AiHeuristicConst.KNN);
        }
        else
        {
            typeList.add(SolverConst.MAXSOLUTIONS);
            typeList.add(SolverConst.RANGEVALUE);
        }
        
        //add from the modules
        for (i = 0; i < solverModules.size(); i++)
        {
            moduleFactory = (ModuleSolverFactory)solverModules.get(i);
            if (moduleFactory.hasSolverSpecs())
            {
                nextTypeList = moduleFactory.getSolverSpecs().getTestScriptVariables(scriptType);            
                if (nextTypeList != null)
                {
                    typeList.addAll(nextTypeList);
                }
            }
        }

        return typeList;
    }
    
    /**
     * Get a list of test config script heuristic types.
     * This needs to be a list with all variables added, identified by the key name.
     * @return the list of names with types. Key is the var name, value is the class type.
     */
    public HashMap<String, String> getTestScriptVariableTypes()
    {
        int i;
        String nextKey;                                 //next key
        Iterator allKeys;                               //all keys
        HashMap typeList;                             //list of types
        HashMap nextTypeList;                         //list of types
        ModuleSolverFactory moduleFactory;              //module factory
               
        typeList = new HashMap();
        typeList.put(SolverConst.MUTATE, Float.class.getName());
        typeList.put(SolverConst.CROSSOVER, Float.class.getName());
        typeList.put(SolverConst.MUTATEPERCENT, Float.class.getName());
        typeList.put(SolverConst.CROSSOVERPERCENT, Float.class.getName());
        typeList.put(AiHeuristicConst.MKP, Integer.class.getName());
        typeList.put(AiHeuristicConst.CFC, Double.class.getName());
        typeList.put(AiHeuristicConst.EFN, Double.class.getName());
        typeList.put(AiHeuristicConst.EFC, Double.class.getName());
        typeList.put(AiHeuristicConst.GFR, Double.class.getName());
        typeList.put(AiHeuristicConst.HFC, Double.class.getName());
        typeList.put(AiHeuristicConst.HFC2, Double.class.getName());
        typeList.put(AiHeuristicConst.HLT, Double.class.getName());
        typeList.put(AiHeuristicConst.SHLT, Double.class.getName());
        typeList.put(AiHeuristicConst.LPFA, Double.class.getName());
        typeList.put(AiHeuristicConst.LPFB, Double.class.getName());
        typeList.put(AiHeuristicConst.MIN, Integer.class.getName());
        typeList.put(AiHeuristicConst.MAX, Integer.class.getName());

        //add from the modules
        for (i = 0; i < solverModules.size(); i++)
        {
            moduleFactory = (ModuleSolverFactory)solverModules.get(i);
            if (moduleFactory.hasSolverSpecs())
            {
                nextTypeList = moduleFactory.getSolverSpecs().getTestScriptVariableTypes();                
                if (nextTypeList != null) 
                {
                    allKeys = nextTypeList.keySet().iterator();
                    while (allKeys.hasNext())
                    {
                        nextKey = (String)allKeys.next();
                        if (!typeList.containsKey(nextKey))
                        {
                            typeList.put(nextKey, nextTypeList.get(nextKey));
                        }
                    }
                }
            }
        }
        
        return typeList;
    }
    
    /**
     * Get a list of test config script variable descriptions, for display purposes.
     * This needs to be a list with all variables added, identified by the key name.
     * @return the list of variable descriptions. Key is the var name, value is the description.
     */
    public HashMap<String, String> getTestScriptVariableDescriptions()
    {
        int i;
        String nextKey;                                 //next key
        Iterator allKeys;                               //all keys
        HashMap typeList;                             //list of types
        HashMap nextTypeList;                         //list of types
        ModuleSolverFactory moduleFactory;              //module factory
        
        typeList = new HashMap();
        typeList.put(SolverConst.MAXSOLUTIONS, "Maximum number of solutions in the final result, or beam width.");
        typeList.put(SolverConst.RANDOMISE, "Randomise the ordering of the solutions in the grid.");
        typeList.put(SolverConst.RANGETYPE, "Similarity measurement type when comparing solutions.");
        typeList.put(SolverConst.RANGEVALUE, "Maximum amount similar solutions can vary by.");
        typeList.put(SolverConst.MAXMATCHES, "Maximum number of solutions allowed during an evaluation process.");
        typeList.put(SolverConst.OKLINKINC, "Continue if dynamic links better, even if solution score is not.");
        typeList.put(SolverConst.ROLLBACKS, "Repeat times with same solutions if result not better. 0 is OK.");
        typeList.put(SolverConst.NONEWCLUSTERS, "Repeat times with solution subset if no new clusters. 0 is OK.");
        typeList.put(SolverConst.ADDINKS, "Add the clusters as links to the services.");
        typeList.put(SolverConst.MUTATE, "Default mutate operation. No value needed.");
        typeList.put(SolverConst.CROSSOVER, "Default crossover operation. No value needed.");
        typeList.put(SolverConst.MUTATEPERCENT, "Percentage of gene to mutate. Needs percent fraction.");
        typeList.put(SolverConst.CROSSOVERPERCENT, "Percentage of gene for crossover. Needs percent fraction.");
        typeList.put(AiHeuristicConst.MKP, "Minkowski function power value. Integer value required.");
        typeList.put(AiHeuristicConst.CFC, "Function Constant Factor value. Double value required.");
        typeList.put(AiHeuristicConst.EFN, "Function Exponential Factor scale value. Double value required.");
        typeList.put(AiHeuristicConst.EFC, "Function Exponential Factor power value. Double value required.");
        typeList.put(AiHeuristicConst.GFR, "Function Gauss Factor power value. Double value required.");
        typeList.put(AiHeuristicConst.HFC, "Function Hyperbolic Factor scale value. Double value required.");
        typeList.put(AiHeuristicConst.HFC2, "Function Hyperbolic Factor division value. Double value required.");
        typeList.put(AiHeuristicConst.HLT, "Function Hard Limit Threshold value. Double value probably.");
        typeList.put(AiHeuristicConst.SHLT, "Function Symmetric Hard Limit Threshold value. Double value.");
        typeList.put(AiHeuristicConst.LPFA, "Function Linear Plus scale value. Double value required.");
        typeList.put(AiHeuristicConst.LPFB, "Function Linear Plus add value. Double value required.");
        typeList.put(AiHeuristicConst.MIN, "Minimum value for a range. Integer value required.");
        typeList.put(AiHeuristicConst.MAX, "Maximum value for a range. Integer value required.");

        //som-related
        typeList.put(SomConst.TOPOLOGY, "SOM Neural Network Topology structure.");
        typeList.put(SomConst.TOPOLOGYROW, "Topology row number. Integer value required.");
        typeList.put(SomConst.TOPOLOGYCOL, "Topology column number. Integer value required.");
        typeList.put(SomConst.TOPOLOGYRADIUS, "Topology radius value. Integer value required.");
        typeList.put(SomConst.LEARNFRAMEWORK, "SOM Neural Network Learning framework model.");
        typeList.put(SomConst.NEIGHBOURHOODFUNCION, "SOM Neural Network Neighbourhood function model.");
        typeList.put(SomConst.ACTIVATIONFUNCION, "SOM Neural Network neuron activation function.");
        typeList.put(SomConst.WEIGHTSNUMBER, "SOM Neural Network initialisation weights number.");
            
        //nearest neighbour-related
        typeList.put(AiHeuristicConst.KNN, "Number of nearest neighbours to return.");
        typeList.put(AiHeuristicConst.BS, "Maximum bucket size or capacity for each tree node.");
        
        
        //add from the modules
        for (i = 0; i < solverModules.size(); i++)
        {
            moduleFactory = (ModuleSolverFactory)solverModules.get(i);
            if (moduleFactory.hasSolverSpecs())
            {
                nextTypeList = moduleFactory.getSolverSpecs().getTestScriptVariableDescriptions();
                if (nextTypeList != null) 
                {
                    allKeys = nextTypeList.keySet().iterator();
                    while (allKeys.hasNext())
                    {
                        nextKey = (String)allKeys.next();
                        if (!typeList.containsKey(nextKey))
                        {
                            typeList.put(nextKey, nextTypeList.get(nextKey));
                        }
                    }
                }
            }
        }
        
        return typeList;
    }
    
    /**
     * Get a list of allowed values for a test script variable.
     * @param variableType the variable type.
     * @return the list of allowed values for the variable.
     */
    public ArrayList<String> getTestScriptVarValues(String variableType)
    {
        int i;
        ArrayList typeList;                            //list of types
        ArrayList nextTypeList;                        //list of types
        ModuleSolverFactory moduleFactory;          //module factory
        
        typeList = new ArrayList();
        if (variableType != null)
        {
            if (variableType.equals(SolverConst.RANGETYPE))
            {
                typeList.add(SolverConst.ACTUAL);
                typeList.add(SolverConst.PERCENTAGE);
            }
            else if (variableType.equals(Const.LINKMETHOD))
            {
                typeList.add(LinkConfig.MEMORY);
                typeList.add(LinkConfig.RESERVE);
            }
            else if (variableType.equals(Const.CREATESERVICES) ||
                    variableType.equals(SolverConst.RANDOMISE) ||
                    variableType.equals(SolverConst.OKLINKINC) ||
                    variableType.equals(SolverConst.ADDINKS))
            {
                typeList.add(SolverConst.TRUE);
                typeList.add(SolverConst.FALSE);
            }
            else if (variableType.equals(SomConst.TOPOLOGY))
            {
                typeList.add(SomConst.MATRIXTOPOLOGY);
                typeList.add(SomConst.HEXTOPOLOGY);
            }
            else if (variableType.equals(SomConst.NEIGHBOURHOODFUNCION))
            {
                typeList.add(SomConst.FRACTIONNEIGHBOURHOOD);
                typeList.add(SomConst.GAUSSNEIGHBOURHOOD);
            }
            else if (variableType.equals(SomConst.LEARNFRAMEWORK))
            {
                typeList = SomConst.somLearnFrameworks();
            }
            else if (variableType.equals(SomConst.ACTIVATIONFUNCION))
            {
                typeList = AiHeuristicConst.activationFunctions();
            }
        }
        
        //add from the modules
        for (i = 0; i < solverModules.size(); i++)
        {
            moduleFactory = (ModuleSolverFactory)solverModules.get(i);
            if (moduleFactory.hasSolverSpecs())
            {
                nextTypeList = moduleFactory.getSolverSpecs().getTestScriptVarValues(variableType);            
                if (nextTypeList != null)
                {
                    typeList.addAll(nextTypeList);
                }
            }
        }

        return typeList;
    }
}
