/*
 * CompoundSolution.java
 *
 * Created on 26 February 2010
 *
 * Version 1.3
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.model.comp;


import org.licas.ai_solver.model.*;
import java.util.*;


/**
 * This class can be used to store a set of solutions that are related, or that should be processed together.
 * Unlike a container, these solutions then need to be solved.
 * @author Kieran Greer
 */
public class CompoundSolution extends SolutionContainer
{
    /**
     * Create a new instance of CompoundSolution.
     * @param thisName this compound solution name or ID.
     */
    public CompoundSolution(String thisName)
    {
        super(thisName);
    }

    /**
     * Randomise the order of any new solutions since the previous solution set and
     * return in a new compound solution. This implementation assumes that the list
     * of solution names exactly matches the order of all stored solutions in the object.
     * Note that a solution is always returned even if the order cannot be changed.
     * @param previousSolution the previous compound solution to compare with.
     * @return a new compound solution with the new solution order.
     */
    public CompoundSolution randomiseNewSolutionOrder(CompoundSolution previousSolution)
    {
        int i;
        int index1;                                 //index
        int index2;                                 //index
        int indexPosition;                          //index position
        String nextName1;                           //next name
        String nextName2;                           //next name
        ArrayList<Integer> indexes;                 //indexes of new solutions
        ArrayList<String> namesList1;               //list of names
        ArrayList<String> namesList2;               //list of names
        CompoundSolution newSolution;               //new compound solution
        Random rnd;                                 //random number generator
        
        rnd = new Random(System.currentTimeMillis());
        indexes = new ArrayList<>();
        
        //copy to the compound solution
        newSolution = (CompoundSolution)this.clone();
        namesList1 = newSolution.getSolutionNames();
        namesList2 = previousSolution.getSolutionNames();
        
        for (i = 0; i < namesList1.size(); i++)
        {
            nextName1 = namesList1.get(i);
            
            //if name not in previous set then new solution
            if (!namesList2.contains(nextName1)) {
                indexes.add(new Integer(i));
            }
        }
        
        //randomise the order by swapping two arbitrary solutions each time
        while (indexes.size() > 1)
        {
            indexPosition = rnd.nextInt(indexes.size());
            
            index1 = indexes.get(indexPosition).intValue();
            nextName1 = namesList1.get(index1);
            indexes.remove(indexPosition);
            
            if (indexes.size() > 1) indexPosition = rnd.nextInt(indexes.size());
            else indexPosition = 0;
            
            index2 = indexes.get(indexPosition).intValue();
            nextName2 = namesList1.get(index2);
            indexes.remove(indexPosition);
            
            newSolution.getSolutionNames().set(index1, nextName2);
            newSolution.getSolutionNames().set(index2, nextName1);
        }
 
        return newSolution;
    }
    
    /**
     * Clone this object to create a copy of the main features.
     * @return a cloned copy of this object.
     */
    public Object clone()
    {
        CompoundSolution newSolution;               //new compound solution
        
        newSolution = new CompoundSolution(name);
        newSolution.solutionNames = (ArrayList)this.solutionNames.clone();
        newSolution.solutions = (LinkedHashMap)this.solutions.clone();
        return newSolution;
    }

    /**
     * Convert the solution container into a compound solution.
     * @param compSoln the solution container to convert.
     * @return a cloned copy of the solution list as a compound one.
     */
    public static CompoundSolution toCompoundSolution(SolutionContainer compSoln)
    {
        CompoundSolution newSolution;           //new compound solution

        newSolution = new HyperCompoundSolution(compSoln.getName());
        newSolution.solutionNames = (ArrayList)compSoln.getSolutionNames().clone();
        newSolution.solutions = (LinkedHashMap)compSoln.getSolutions().clone();
        return newSolution;
    }
}
