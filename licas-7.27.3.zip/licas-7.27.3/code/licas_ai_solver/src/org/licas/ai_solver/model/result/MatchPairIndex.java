/*
 * MatchPairIndex.java
 *
 * Created on 8 January 2021
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.model.result;


import org.licas.ai_solver.central.grid.HyperHeuristicGrid;

import java.util.ArrayList;


/**
 * This class stores the details of two matching solution indexes. The other fields may not be required
 * and are used by the new {@link HyperHeuristicGrid} hyper-heuristic/grid frameworks.
 * @author Kieran Greer
 */
public class MatchPairIndex extends MatchPair
{
    /**
     * The first solution index. This relates to the index of the solution in the
     * list of solutions in the related compound solution.
     */
    public int firstIndex;

    /**
     * The second solution index. This relates to the index of the solution in the
     * list of solutions in the related compound solution.
     */
    public int secondIndex;


    /**
     * Create a new instance of MatchPairIndex.
     */
    public MatchPairIndex()
    {
        super();
        firstIndex = -1;
        secondIndex = -1;
    }
    
    /**
     * Get a string-based description of this solution match.
     * @return a string-based description of this object.
     */
    public String toString()
    {
        String solutionStr;                                 //solution as a string
        
        solutionStr = "\nNEXT SOLUTION PAIR:\n";
        solutionStr += ("Soln 1 index: " + String.valueOf(firstIndex));
        solutionStr += (", soln 2 index: " + String.valueOf(secondIndex));
        solutionStr += (", value: " + String.valueOf(totalValue));
        solutionStr += ("\nProblem indexes: " + String.valueOf(problems));
        solutionStr += ("\nProblem evaluations: " + String.valueOf(problemEvals));
        solutionStr += "\n";
               
        return solutionStr;
    }
}
