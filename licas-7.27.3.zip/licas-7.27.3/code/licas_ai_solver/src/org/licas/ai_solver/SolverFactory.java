/*
 * SolverFactory.java
 *
 * Created on 11 July 2011
 *
 * Version 1.8.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.licas.service.*;
import org.licas.PasswordHandler;
import org.licas.service.sci.SolverMetrics;
import org.licas.util.*;

import java.util.*;


/**
 * This factory can be used to return sets of legal definitions, based on the user input 
 * configuration for problem-solving classes. To change the default value sets, create a new 
 * SolverFactory derived class and then set it in the main code using {@code SolverFactory.setSolverFactory}.
 * @author Kieran Greer
 */
public abstract class SolverFactory
{
    /** The password handler */
    protected PasswordHandler passwordHandler;
    
    /** Solver Factory methods lists */
    protected SolverMetrics solverMetric = null;
    protected SolverHeuristics solverHeuristic = null;
    protected SolverData solverData = null;
    protected SolverSpecs solverSpec = null;
    protected SolverMediators solverMediator = null;
    
    /** 
     * List of modules automatically loaded in during startup. Of type {@link ModuleSolverFactory}.
     */
    protected static ArrayList<ModuleSolverFactory> solverModules = new ArrayList<>();


    /** Single instance of the factory that is used to generate all analysis models */
    private static volatile SolverFactory solverFactory = null;


    /**
     * Create a new instance of SolverFactory.
     * @param thePasswordHandler the password handler.
     */
    public SolverFactory(PasswordHandler thePasswordHandler)
    {
        passwordHandler = thePasswordHandler;
    }
    
    /**
     * Get the created instance of the analysis model factory.
     * @return the value of solverFactory.
     */
    public static SolverFactory getInstance()
    {
        return solverFactory;
    }

    /**
     * Set the instance of the solver factory to be used.
     * @param thisSolverFactory the solver factory to use.
     */
    public static void setInstance(SolverFactory thisSolverFactory)
    {
        solverFactory = thisSolverFactory;
    }
    
    /**
     * Return true if the factory has a solver metrics implementation.
     * @return true if solverMetric is not null.
     */
    public boolean hasSolverMetrics()
    {
        return (solverMetric != null);
    }
    
    /**
     * Return true if the factory has a solver heuristics implementation.
     * @return true if solverHeuristic is not null.
     */
    public boolean hasSolverHeuristics()
    {
        return (solverHeuristic != null);
    }
    
    /**
     * Return true if the factory has a solver data implementation.
     * @return true if solverData is not null.
     */
    public boolean hasSolverData()
    {
        return (solverData != null);
    }
    
    /**
     * Return true if the factory has a solver specification implementation.
     * @return true if solverSpec is not null.
     */
    public boolean hasSolverSpecs()
    {
        return (solverSpec != null);
    }
    
    /**
     * Return true if the factory has a solver mediator implementation.
     * @return true if solverMediator is not null.
     */
    public boolean hasSolverMediators()
    {
        return (solverMediator != null);
    }
    
    /**
     * Set the solver factory metrics.
     * @param theSolverMetric the solver metrics description.
     */
    public void setSolverMetrics(SolverMetrics theSolverMetric)
    {
        if (solverMetric == null) {
            solverMetric = theSolverMetric;
        }
    }
    
    /**
     * Get the solver factory metrics methods.
     * @return the value of solverMetric.
     */
    public SolverMetrics getSolverMetrics()
    {
        return solverMetric;
    }
    
    /**
     * Set the solver factory heuristics.
     * @param theSolverHeuristic the solver heuristics description.
     */
    public void setSolverHeuristics(SolverHeuristics theSolverHeuristic)
    {
        if (solverHeuristic == null) {
            solverHeuristic = theSolverHeuristic;
        }
    }
    
    /**
     * Get the solver factory heuristic methods.
     * @return the value of solverHeuristic.
     */
    public SolverHeuristics getSolverHeuristics()
    {
        return solverHeuristic;
    }
    
    /**
     * Set the solver factory data.
     * @param theSolverData the solver data description.
     */
    public void setSolverData(SolverData theSolverData)
    {
        if (solverData == null) {
            solverData = theSolverData;
        }
    }
    
    /**
     * Get the solver factory data methods.
     * @return the value of solverData.
     */
    public SolverData getSolverData()
    {
        return solverData;
    }
    
    /**
     * Set the solver factory specification.
     * @param theSolverSpec the solver spec description.
     */
    public void setSolverSpecs(SolverSpecs theSolverSpec)
    {
        if (solverSpec == null) {
            solverSpec = theSolverSpec;
        }
    }
    
    /**
     * Get the solver factory specification methods.
     * @return the value of solverSpec.
     */
    public SolverSpecs getSolverSpecs()
    {
        return solverSpec;
    }
    
    /**
     * Set the solver factory mediators.
     * @param theSolverMediator the solver mediators description.
     */
    public void setSolverMediators(SolverMediators theSolverMediator)
    {
        if (solverMediator == null) {
            solverMediator = theSolverMediator;
        }
    }
    
    /**
     * Get the solver factory mediator methods.
     * @return the value of solverMediator.
     */
    public SolverMediators getSolverMediators()
    {
        return solverMediator;
    }
    
    /**
     * Add a solver module to the list of modules.
     * @param solverModule the solver module to add.
     */
    public void addSolverModule(ModuleSolverFactory solverModule)
    {
        solverModules.add(solverModule);
    }
    
    /**
     * Get an appropriate service type from the service class. For backwards compatibility
     * and the local packages only.
     * @param serviceClass the full java class name.
     * @return an appropriate type. Might be Information for the information one.
     */
    public static String getServiceType(String serviceClass)
    {
        if (serviceClass.equals(InformationService.class.getName())) {
            return ServiceConst.INFORMATION;
        }
        
        return ServiceConst.BEHAVIOUR;
    }
    
    /**
     * For backwards compatibility, the object type has been used to describe a
     * previous version of the script.
     * @param valueName the object type name.
     * @return the current object name. If not recognised, return {@code valueName}.
     */
    public static String checkHeuristic(String valueName)
    {
        String currentName;                         //the current name

        currentName = valueName;
        if (currentName.equals("Hyper_Compare")) {
            return HeuristicConst.GRIDMATCH;
        }
        else if (currentName.equals("Hill_Climb")) {
            return HeuristicConst.GRIDHILL;
        }
        
        return currentName;
    }
    
    /**
     * For backwards compatibility, the dataset type has been used to describe a
     * genetic algorithm heuristic. This method converts that back to the genetic
     * algorithm heuristic name.
     * @param datasetType the dataset type name.
     * @return the genetic algorithm name. If not recognised, return {@code datasetType}.
     */
    public static String checkGeneticDatasetHeuristic(String datasetType)
    {
        String className;                       //the class name

        className = datasetType;
        if (className != null) {
            if (className.equals(HeuristicConst.BAGOFWORDSTYPE) ||
                    className.equals(HeuristicConst.METABAGOFWORDSTYPE) ||
                    className.equals(HeuristicConst.STRINGTYPE) ||
                    className.equals(HeuristicConst.INTEGERTYPE) ||
                    className.equals(HeuristicConst.FLOATTYPE)) {
                return HeuristicConst.GENETICALGORITHM;
            }
        }
        
        return className;
    }
}
