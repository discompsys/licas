/*
 * DefaultSolverFactory.java
 *
 * Created on 11 July 2011
 *
 * Version 1.9
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.licas.ai_solver.mediator.*;
import org.licas.PasswordHandler;
import org.jlog2.*;


/**
 * This is the default implementation of the factory that is required to return all of 
 * the user defined and default classes for solving the problems. It is initialised in
 * the main code through the call {@code SolverFactory.setSolverFactory(new DefaultSolverFactory(passwordHandler))}
 * @author Kieran Greer
 */
public class DefaultSolverFactory extends SolverFactory
{
    /** For logging */
    private static Logger logger;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(DefaultSolverFactory.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Create a new instance of DefaultSolverFactory.
     * @param thePasswordHandler the password handler.
     * @throws java.lang.Exception any error.
     */
    public DefaultSolverFactory(PasswordHandler thePasswordHandler) throws Exception
    { 
        super(thePasswordHandler);
        
        solverMetric = new DefaultSolverMetrics(solverModules);
        solverHeuristic = new DefaultSolverHeuristics(solverModules);
        solverData = new DefaultSolverData(solverModules);
        solverSpec = new DefaultSolverSpecs(passwordHandler, solverModules);
        solverMediator = new DefaultSolverMediators(passwordHandler, solverModules);
        solverMediator.setServiceMediator(new ProblemSolverMediator(passwordHandler));
    }
}
