/**
 * Problem-solving packages, including base factory classes, the problem-solving framework
 * and more centralised solutions, where services send their data to the solver, while the
 * core licas package includes the distributed linking solutions.
 */
package org.licas.ai_solver;