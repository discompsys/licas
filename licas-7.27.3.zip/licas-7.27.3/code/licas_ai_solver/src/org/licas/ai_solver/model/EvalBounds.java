/*
 * EvalBounds.java
 *
 * Created on 10 August 2009
 *
 * Version 1.1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.model;


import org.ai_heuristic.eval.metric.ReplySet;


/**
 * Evaluation boundaries for a single solution result. This is used to store the
 * results of an evaluation which can be in any format as they are stored as objects.
 * As well as the evaluation itself, upper and lower bounds on the evaluation can 
 * also be saved.
 * @author Kieran Greer
 */
public class EvalBounds
{
    /** Solution id or name */
    public String name;
    
    /** 
     * If evaluation supports or prevents the result. This is not typically used 
     * but is useful for evaluating more autonomous actions.
     */
    public String posNeg;
    
    /** Evaluation */
    public ReplySet evaluation;

    /** Upper bound on the evaluation */
    public ReplySet upper;

    /** Lower bound on the evaluation */
    public ReplySet lower;
   

    /** 
     * Create a new instance of EvalBounds.
     */
    public EvalBounds()
    {
        name = null;
        evaluation = null;
        upper = null;
        lower = null;
        posNeg = null;
    }
    
    /** 
     * Create a new instance of EvalBounds.
     * @param theEvaluation the evaluation result. If not of type {@link ReplySet}
     * it gets wrapped in that object first.
     */
    public EvalBounds(Object theEvaluation)
    {
        if (theEvaluation instanceof ReplySet) {
            evaluation = (ReplySet)theEvaluation;
        }
        else {
            evaluation = new ReplySet(theEvaluation);
        }
        
        name = null;
        upper = null;
        lower = null;
        posNeg = null;
    }
    
    /**
     * Get the evaluation value object, not the {@code ReplySet} wrapper.
     * @return the value object.
     */
    public Object evalValue()
    {
        return evaluation.getValue();
    }
    
    /**
     * Get the lower value object, not the {@code ReplySet} wrapper.
     * @return the value object.
     */
    public Object lowerValue()
    {
        return evaluation.getValue();
    }
    
    /**
     * Get the upper value object, not the {@code ReplySet} wrapper.
     * @return the value object.
     */
    public Object upperValue()
    {
        return evaluation.getValue();
    }
    
    /**
     * Return a string-based description of this evaluation.
     * @return a string-based description of each object. Should
     * be able to parse each object with the toString method.
     */
    public String toString()
    {
        String descr;                                   //description
        
        descr = ("EvalBounds: name: " + String.valueOf(name));
        if (evaluation != null) {
            descr += "\nevaluation: " + String.valueOf(evaluation.getValue());
        }
        if (upper != null) {
            descr += "\nupper: " + String.valueOf(upper.getValue());
        }
        if (lower != null) {
            descr += "\nlower: " + String.valueOf(lower.getValue());
        }
        if (posNeg != null) {
            descr += "\nposNeg: " + String.valueOf(posNeg);
        }
        
        return descr;
    }
}
