/*
 * HyperHeuristicGrid.java
 *
 * Created on 21 August 2010
 *
 * Version 1.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.central.grid;


import org.licas.ai_solver.central.grid.metric.*;
import org.licas.ai_solver.model.result.Result;
import org.ai_heuristic.model.*;
import org.licas.util.TypeConst;
import org.licas.util.exception.LicasException;


/**
 * This is a base class for the new grid-style of solver. 
 * @author Kieran Greer
 */
public abstract class HyperHeuristicGrid
{
    /** The name of the grid */
    protected String gridName;
    
    /** The name of the grid */
    protected String gridType;

    /** The comparison metric to use */
    protected GridMetric gridMetric;
    
    /** The solution to the grid */
    protected Result gridSolution;
    
    /** True if larger value is better, false if smaller value is better */
    protected boolean lib;
    
    /** Stores feedback on any non-critical errors that have stopped the search */
    protected String errorFeedback;

    /**
     * Create a new instance of HyperHeuristicGrid. Larger value assumed to be better.
     */
    public HyperHeuristicGrid()
    {}
   
    /**
     * Solve the currently saved grid.
     * @param theGridMetric the comparison metric to use.
     * @throws java.lang.Exception any error.
     */
    public abstract void solve(GridMetric theGridMetric) throws Exception;
    
    /**
     * Get the list of solutions that are part of a best match.
     * @return the best matching solutions.
     * @throws java.lang.Exception any error.
     */
    public abstract Result getGridSolution() throws Exception;
    
    
    /**
     * Set the name of the grid.
     * @param theGridName the name of the grid.
     */
    public void setGridName(String theGridName)
    {
        gridName = theGridName;
    }
    
    /**
     * Get the name for the grid.
     * @return the value of gridName.
     */
    public String getGridName()
    {
        return gridName;
    }
    
    /**
     * Get the grid type.
     * @return the value of gridType.
     */
    public String getGridType()
    {
        return gridType;
    }
    
    /**
     * Get any feedback related to a non-critical stopping condition.
     * @return a string-based description of an error trace.
     */
    public String getErrorFeedback()
    {
        return errorFeedback;
    }


    /**
     * Create and return a comparison metric for the specified class data type.
     * @param dataType the data type, can be double or String, for example.
     * @return the default metric for this type.
     * @throws java.lang.Exception any error.
     */
    public GridMetric getMetric(String dataType) throws Exception
    {
        if (dataType.equalsIgnoreCase(TypeConst.DOUBLE) ||
                dataType.equalsIgnoreCase(TypeConst.DOUBLEOBJ)  ||
                dataType.equalsIgnoreCase(BagOfWords.class.getName())  ||
                dataType.equalsIgnoreCase(MetaBagOfWords.class.getName()))
        {
            return new GridMetricDouble();
        }
        else if (dataType.equalsIgnoreCase(TypeConst.STRING))
        {
            return new GridMetricString();
        }
        else
        {
            throw new LicasException("Grid Metric type " + dataType + " not recognised.");
        }
    }
}
