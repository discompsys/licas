/*
 * TestDef.java
 *
 * Created on 21 August 2012
 *
 * Version 1.2.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.def;


import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.spec.*;
import org.licas.ai_solver.test.RunTests;


/**
 * This is the interface that all test controlling classes ({@link RunTests} derived) should implement.
 * @author Kieran Greer
 */
public interface TestDef 
{
    /** 
     * Set the environment up for running a test.
     * @param testScriptFile the file path to the test script to read.
     * @return true if configured OK, false otherwise.
     * @throws java.lang.Exception any error.
     */
    boolean configureTest(String testScriptFile) throws Exception;
    
    /** 
     * Set the environment up for running a test.
     * @param thisTestSpec the test specification object.
     * @return true if configured OK, false otherwise.
     * @throws java.lang.Exception any error.
     */
    boolean configureTest(TestSpec thisTestSpec) throws Exception;
    
    /**
     * Run a set of tests based on an already created script object and initialised
     * environment.
     * @return a description of the execution trace.
     * @throws java.lang.Exception any error.
     */
    String runTestSet() throws Exception;
}
