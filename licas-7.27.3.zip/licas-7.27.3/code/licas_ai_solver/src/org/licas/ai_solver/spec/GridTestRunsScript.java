/*
 * GridTestRunsScript.java
 *
 * Created on 14 July 2015
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.spec;


import org.licas.ai_solver.util.SolverConst;

import java.util.HashMap;


/**
 * This class reads an XML file and loads in a specification for a set of test runs.
 * This class relates specifically to configuring the number of test iterations, the
 * stopping criteria for that, rollbacks if the results are not better, and so on.
 * @author Kieran Greer
 */
public class GridTestRunsScript extends TestRunsScript
{
    /** Number of times to rollback to previous solution set if current not better */
    public int rollbacks;
    
    /** Number of times to repeat test runs without new clusters */
    public int noNewClusters;
    
    
    /** 
     * Create a new instance of GridTestRunsScript.
     */
    public GridTestRunsScript()
    {
        super();
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        addLinks = true;
        rollbacks = 0;
        noNewClusters = 0;
    }
    
    /**
     * Return true if the test can end based on spec param values.
     * @param testValues set of current test parameter values as key-value pairs.
     * Can be empty if not used.
     * @return this base version returns false.
     */
    public boolean testCanEnd(HashMap<String, ?> testValues)
    {
        int rollbackCount;                  //current rollback count
        
        if (noNewClusters == 0) {
            return true;
        }
        else if ((testValues != null) && (testValues.containsKey(SolverConst.ROLLBACKS))) {
            rollbackCount = ((Integer)testValues.get(SolverConst.ROLLBACKS)).intValue();
            return (rollbackCount >= noNewClusters);
        }
        
        return false;
    }
}
