/*
 * EvaluateGenData.java
 *
 * Created on 5 May 2011
 *
 * Version 1.4
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.eval;


import org.ai_heuristic.functs.Function;
import org.ai_heuristic.eval.metric.*;


/**
 * This is the base class for evaluating problem data, more specifically using the
 * genetic algorithms classes, but can be used for other types as well. This would typically 
 * be done by comparing input data with this object's seed, or {@code evalSeed} object. This
 * evaluator also stores the evaluation function that is used to compare its seed
 * object with the problem dataset {@code dataObject}.
 * @author Kieran Greer
 */
public class EvaluateGenData 
{
    /** The evaluator name or id */
    protected String name;

    /** Function used to do the evaluation */
    protected Function evalFunction;

    /** 
     * The seed that this evaluator uses for comparing problem datasets.
     * This corresponds to the value set that defines the objective value.
     * This could be a single object or a list of objects, but it must be stored
     * in a MetricDataset object. A single value is a list of length 1.
     */
    protected MetricDataset evalSeed;


    /**
     * Create a new instance of EvaluateData.
     * @param thisName a name for the evaluator.
     * @param thisEvalSeed the object to seed the evaluation with.
     * @param thisEvalFunction the evaluation function. Can be set later instead.
     */
    public EvaluateGenData(String thisName, MetricDataset thisEvalSeed, Function thisEvalFunction)
    {
        name = thisName;
        evalSeed = thisEvalSeed;
        evalFunction = thisEvalFunction;
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {}
    
    
    /**
     * Evaluate the problem dataset and return the result.
     * @param dataset to evaluate. Can also be of type {@link MetricCompare},
     * but might then behave differently, depending on the evaluation function.
     * @return the result of this evaluation.
     * @throws java.lang.Exception any error.
     */
    public ReplySet evaluate(MetricDataset dataset) throws Exception
    {
        return evalFunction.evaluate(dataset);
    }
    
    /**
     * Get the evaluator id or name.
     * @return the value of name.
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Get the object that seeded this evaluator.
     * @return the value of evalSeed.
     */
    public MetricDataset getEvalSeed()
    {
        return evalSeed;
    }
    
    /**
     * Set the function used to evaluate the problem data.
     * @param thisEval the evaluation function.
     */
    public void setEvaluationFunction(Function thisEval)
    {
        evalFunction = thisEval;
    }
}
