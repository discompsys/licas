/*
 * HeuristicMetrics.java
 *
 * Created on 30 January 2016
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.ai_heuristic.model.FactoryInfo;

import java.util.*;


/**
 * This class describes the methods used by the heuristic metrics. A copy is stored in the
 * {@link HeuristicFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public abstract class HeuristicMetrics 
{
    /** The default heuristic classifications */
    protected HeuristicClassification heuristicClassif;
    
    /** 
     * List of modules automatically loaded in during startup. Of type {@link ModuleHeuristicFactory}.
     */
    protected static ArrayList<ModuleHeuristicFactory> heuristicModules = new ArrayList<>();
    
    /** 
     * Create a new instance of HeuristicMetrics. 
     * @param theHeuristicClassif the heuristic classifications.
     * @param theHeuristicModules list of heuristic modules.
     */
    public HeuristicMetrics(HeuristicClassification theHeuristicClassif, ArrayList<ModuleHeuristicFactory> theHeuristicModules)
    {
        heuristicClassif = theHeuristicClassif;
        heuristicModules = theHeuristicModules;
    }
    
    
    /**
     * Get a list of available versions of an evaluation metric type.
     * @param heuristicType the heuristic type.
     * @return the list of versions of the metric evaluator the heuristic can use.
     * This base class version returns an empty list. See {@link DefaultHeuristicMetrics} for an example.
     */
    public HashMap<String, FactoryInfo> getMetricVersions(String heuristicType) {
        return new HashMap<>();
    }
}
