/*
 * HeuristicFactory.java
 *
 * Created on 12 November 2015
 *
 * Version 1.1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.ai_heuristic.model.FactoryInfo;
import java.util.*;


/**
 * This class stores some constant values. These define what base heuristics or algorithms
 * are available for the problem solving. Each list that is returned is made of a key
 * identifier value and a {@link FactoryInfo} object with related information.
 * @author Kieran Greer
 */
public abstract class HeuristicFactory 
{
    /** 
     * List of modules automatically loaded in during startup. Of type {@link ModuleHeuristicFactory}.
     */
    protected static ArrayList<ModuleHeuristicFactory> heuristicModules = new ArrayList<>();
    
    /** Heuristic Factory methods lists */
    protected HeuristicClassification heuristicClassif = null;
    protected HeuristicMetrics heuristicMetric = null;
    protected HeuristicHeuristics heuristicHeuristic = null;
    protected HeuristicData heuristicData = null;
    protected HeuristicFrameworks heuristicFramework = null;


    /** Single instance of the factory that is used to generate all analysis models */
    private static volatile HeuristicFactory heuristicFactory = null;
    
    
    /** Create a new instance of HeuristicFactory */
    public HeuristicFactory()
    {}
    
    /**
     * Get the created instance of the analysis model factory.
     * @return the value of solverFactory.
     */
    public static HeuristicFactory getInstance()
    {
        return heuristicFactory;
    }

    /**
     * Set the instance of the heuristic factory to be used.
     * @param thisHeuristicFactory the solver factory to use.
     */
    public static void setInstance(HeuristicFactory thisHeuristicFactory)
    {
        heuristicFactory = thisHeuristicFactory;
    }
    
    /**
     * Return true if the factory has a heuristic classification implementation.
     * @return true if heuristicClassif is not null.
     */
    public boolean hasHeuristicClassification()
    {
        return (heuristicClassif != null);
    }
    
    /**
     * Return true if the factory has a heuristic metrics implementation.
     * @return true if heuristicMetric is not null.
     */
    public boolean hasHeuristicMetrics()
    {
        return (heuristicMetric != null);
    }
    
    /**
     * Return true if the factory has a heuristic heuristics implementation.
     * @return true if heuristicHeuristic is not null.
     */
    public boolean hasHeuristicHeuristics()
    {
        return (heuristicHeuristic != null);
    }
    
    /**
     * Return true if the factory has a heuristic data implementation.
     * @return true if heuristicData is not null.
     */
    public boolean hasHeuristicData()
    {
        return (heuristicData != null);
    }
    
    /**
     * Return true if the factory has a heuristic frameworks implementation.
     * @return true if heuristicFramework is not null.
     */
    public boolean hasHeuristicFrameworks()
    {
        return (heuristicFramework != null);
    }
    
    /**
     * Set the heuristic factory classifications.
     * @param theHeuristicClassif the heuristic classifications description.
     */
    public void setHeuristicClassification(HeuristicClassification theHeuristicClassif)
    {
        if (heuristicClassif == null) {
            heuristicClassif = theHeuristicClassif;
        }
    }
    
    /**
     * Get the heuristic factory classification methods.
     * @return the value of heuristicClassif.
     */
    public HeuristicClassification getHeuristicClassification()
    {
        return heuristicClassif;
    }
    
    /**
     * Set the heuristic factory metrics.
     * @param theHeuristicMetric the heuristic metrics description.
     */
    public void setHeuristicMetrics(HeuristicMetrics theHeuristicMetric)
    {
        if (heuristicMetric == null) {
            heuristicMetric = theHeuristicMetric;
        }
    }
    
    /**
     * Get the heuristic factory metrics methods.
     * @return the value of heuristicMetric.
     */
    public HeuristicMetrics getHeuristicMetric()
    {
        return heuristicMetric;
    }
    
    /**
     * Set the heuristic factory heuristics.
     * @param theHeuristicHeuristic the heuristic heuristics description.
     */
    public void setHeuristicHeuristics(HeuristicHeuristics theHeuristicHeuristic)
    {
        if (heuristicHeuristic == null) {
            heuristicHeuristic = theHeuristicHeuristic;
        }
    }
    
    /**
     * Get the heuristic factory heuristic methods.
     * @return the value of heuristicHeuristic.
     */
    public HeuristicHeuristics getHeuristicHeuristics()
    {
        return heuristicHeuristic;
    }
    
    /**
     * Set the heuristic factory data.
     * @param theHeuristicData the heuristic data description.
     */
    public void setHeuristicData(HeuristicData theHeuristicData)
    {
        if (heuristicData == null) {
            heuristicData = theHeuristicData;
        }
    }
    
    /**
     * Get the heuristic factory data methods.
     * @return the value of heuristicData.
     */
    public HeuristicData getHeuristicData()
    {
        return heuristicData;
    }
    
    /**
     * Set the heuristic factory framework descriptions.
     * @param theHeuristicFramework the heuristic framework descriptions.
     */
    public void setHeuristicFrameworks(HeuristicFrameworks theHeuristicFramework)
    {
        if (heuristicFramework == null) {
            heuristicFramework = theHeuristicFramework;
        }
    }
    
    /**
     * Get the heuristic factory framework methods.
     * @return the value of heuristicFramework.
     */
    public HeuristicFrameworks getHeuristicFrameworks()
    {
        return heuristicFramework;
    }
        
    /**
     * Add a heuristic module to the list of modules.
     * @param heuristicModule the heuristic module to add.
     */
    public void addHeuristicModule(ModuleHeuristicFactory heuristicModule)
    {
        heuristicModules.add(heuristicModule);
    }
}
