/*
 * ProblemScript.java
 *
 * Created on 8 June 2011
 *
 * Version 1.4.7
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.spec;


import org.licas.ai_solver.HeuristicFactory;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.mediator.problem.ProblemMediator;
import org.licas.ai_solver.util.*;

import org.licas.service.spec.BehaviourScript;
import org.licas.PasswordHandler;
import org.licas.data.gen.DataGenerator;
import org.licas.util.*;
import org.ai_heuristic.model.FactoryInfo;
import org.ai_heuristic.util.AiHeuristicConst;

import java.util.*;


/**
 * This class reads an XML file and loads in a specification for a set of test runs.
 * The {@link TestSpec} and {@link ProblemMediator} classes can then be created from this script specification.
 * Some of the values need to be hard coded as part of a test class, but the ones that repeat
 * or are changed can be included in this script.
 * @author Kieran Greer
 */
public class ProblemScript extends BehaviourScript
{
    /** 
     * The solver framework is the controlling framework in which the heuristics are run.
     * It can include {@link SolverConst}.{@code GRIDMATCH} or {@code GRIDHILL}, for example.
     */
    public String solverType;
    
    /** 
     * Maximum number of solutions or possibly a beam width. 
     * Especially if evolving solutions, the number can grow, so this is a maximum 
     * total number that is allowed.
     */
    public int maxSolutionNum;
    
    /** 
     * The value for considering scores as the same. This is defined as actual or a 
     * percentage and is used when comparing, to determine that two values are close 
     * enough to be considered the same.
     */
    public double rangeValue;
    
    /** 
     * If true, then the comparison range is a percentage of the value, if false,
     * then it is an exact amount.
     */
    public boolean similarityRangeAsPercentage;
    
    /**
     * Configuration for the test runs themselves.
     */
    public TestRunsScript testRunsScript;
    
    
    /** 
     * Create a new instance of ProblemScript.
     * @param thePasswordHandler for storing passwords.
     */
    public ProblemScript(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        solverType = null;
        maxSolutionNum = 0;
        similarityRangeAsPercentage = false;
        rangeValue = 0.0;
        testRunsScript = new TestRunsScript();
    }
    
    /**
     * Convert the set of values into the structure to be used to initialise the test services.
     * this depends on the framework, or solver type. The script is already setup for the 
     * centralised problem-solving and so does not need to be changed for that, for example,
     * but the distributed linking can be more easily initialised as the behaviour tests.
     * @return true if converted OK.
     * @throws java.lang.Exception any error.
     */
    public boolean convertForInitialise() throws Exception
    {
        String generatorClass;                      //generator class
        FactoryInfo factoryInfo;                    //factory info
        
        if (datasetType != null) {
            generatorClass = DataGenerator.getGeneratorClass(datasetType);
            if (generatorClass != null) {
                serviceClasses.put(ServiceConst.DATAGENERATORTYPE, generatorClass);
            }
        }
        
        if ((heuristicType != null) && HeuristicFactory.getInstance().getHeuristicClassification().isHeuristic(heuristicType)) {
            factoryInfo = HeuristicFactory.getInstance().getHeuristicClassification().getFactoryInfo(heuristicType);
            if (factoryInfo != null) {
                serviceClasses.put(AiHeuristicConst.EVALUATOR, factoryInfo.className);
            }
        }
        
        return true;
    }
    
    
    /**
     * Copy the behaviour script values into this object.
     * @param behaviourScript the behaviour script.
     */
    public void copy(BehaviourScript behaviourScript)
    {
        if (behaviourScript != null) {
            //behaviour script variables
            scriptType = behaviourScript.scriptType;
            serviceType = behaviourScript.serviceType;
            servicesNum = behaviourScript.servicesNum;
            createServices = behaviourScript.createServices;
            constructorParams = behaviourScript.constructorParams;
            minValue = behaviourScript.minValue;
            maxValue = behaviourScript.maxValue;
            datasetType = behaviourScript.datasetType;
            dirPath = behaviourScript.dirPath;
            tokenizer = behaviourScript.tokenizer;
            dataConditions = behaviourScript.dataConditions;
            externalScript = behaviourScript.externalScript;
            linkSpec = behaviourScript.linkSpec;
            serverSpec = behaviourScript.serverSpec;
            heuristicType = behaviourScript.heuristicType;
            metricType = behaviourScript.metricType;
            heuristicOptions = (HashMap)behaviourScript.heuristicOptions.clone();

            if (!behaviourScript.serviceClasses.isEmpty()) {
                serviceClasses = (HashMap) behaviourScript.serviceClasses.clone();
            }
            if (!behaviourScript.serviceJarFiles.isEmpty()) {
                serviceJarFiles = (HashMap) behaviourScript.serviceJarFiles.clone();
            }
            
            //problem script variables
            if (behaviourScript instanceof ProblemScript) {
                solverType = ((ProblemScript)behaviourScript).solverType;
                maxSolutionNum = ((ProblemScript)behaviourScript).maxSolutionNum;
                similarityRangeAsPercentage = ((ProblemScript)behaviourScript).similarityRangeAsPercentage;
                rangeValue = ((ProblemScript)behaviourScript).rangeValue;
                testRunsScript = ((ProblemScript)behaviourScript).testRunsScript;
            }
        }
    }
    
    /**
     * Validate the whole script and return a description of any errors.
     * @return a description of any errors or null if OK.
     */
    public String validateScript()
    {
        String validateReply;                   //validation errors
        
        validateReply = super.validateScript();
        if (validateReply == null) validateReply = "";
        else validateReply += "\n";
        
        validateReply += validateVariable(SolverConst.FRAMEWORK);
        validateReply += validateVariable(AiConst.HEURISTICTYPE);
        validateReply += validateVariable(AiConst.METRICTYPE);        
        validateReply += validateVariable(SolverConst.RANGETYPE);
        validateReply += validateVariable(SolverConst.RANGEVALUE);
        validateReply += validateVariable(SolverConst.FULLTRACE);
        validateReply += validateVariable(AiConst.TESTRUNS);
        validateReply = validateReply.trim();
        
        if (validateReply.equals("")) validateReply = null;
        return validateReply;
    }
    
    /**
     * Validate the script variable and return a description if invalid.
     * @param varType the variable type.
     * @return a description of any error, of null if OK.
     */
    protected String validateVariable(String varType)
    {
        String validateError;                   //validate error
        
        validateError = super.validateVariable(varType);
        if ((validateError == null) || validateError.equals("")) {
            if (varType.equals(SolverConst.FRAMEWORK) || varType.equals(SolverConst.MATCHTYPE)) {
                try {
                    if ((solverType == null) || solverType.equals(MetaConst.NONE))
                        validateError = (SolverConst.FRAMEWORK + ": value not entered.\n");
                }
                catch (Exception ex) {
                    validateError = (SolverConst.FRAMEWORK + ": has incorrect format.\n");
                }
            }
            else if (varType.equals(AiConst.HEURISTICTYPE)) {
                try {
                    if ((heuristicType == null) || heuristicType.equals(MetaConst.NONE))
                        validateError = (AiConst.HEURISTICTYPE + ": value not entered.\n");
                }
                catch (Exception ex) {
                    validateError = (AiConst.HEURISTICTYPE + ": has incorrect format.\n");
                }
            }
            else if (varType.equals(AiConst.METRICTYPE)) {
                try {
                    if (metricType == null)
                        validateError = (AiConst.METRICTYPE + ": value not entered.\n");
                }
                catch (Exception ex) {
                    validateError = (AiConst.METRICTYPE + ": has incorrect format.\n");
                }
            }
            else if (varType.equals(SolverConst.MAXSOLUTIONS)) {
                try {
                    if (maxSolutionNum <= 0.0)
                        validateError = (SolverConst.MAXSOLUTIONS + ": must be greater than 0.\n");
                }
                catch (Exception ex) {
                    validateError = (SolverConst.MAXSOLUTIONS + ": has incorrect format.\n");
                }
            }
            else if (varType.equals(SolverConst.RANGETYPE)) {
                //similarityRangeAsPercentage - no check here
            }
            else if (varType.equals(SolverConst.RANGEVALUE)) {
                if (similarityRangeAsPercentage) {
                    if ((rangeValue < 0.0) || (rangeValue > 100.0))
                        validateError += (SolverConst.RANGEVALUE + ": must be between 0.0 and 100.0 inclusive.\n");
                }
                else if (rangeValue < 0.0) {
                    validateError += (SolverConst.RANGEVALUE + ": must be greater than or equal to 0.0.\n");
                }
            }
            else if (varType.equals(AiConst.TESTRUNS)) {
                try {
                    if (testRunsScript.testRuns < 1)
                        validateError = (AiConst.TESTRUNS + ": must be at least 1.\n");
                }
                catch (Exception ex) {
                    validateError = (AiConst.TESTRUNS + ": has incorrect format.\n");
                }
            }
        }
        
        return validateError;
    }
}
