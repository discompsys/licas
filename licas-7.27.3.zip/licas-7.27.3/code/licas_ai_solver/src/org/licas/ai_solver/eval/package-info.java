/**
 * Problem-solving evaluations, to initialise or start the process and perform some actual
 * default evaluation types, including generic object indentification and then related evaluation service. 
 */
package org.licas.ai_solver.eval;