/*
 * ProblemMediatorDistributed.java
 *
 * Created on 21 November 2015
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.mediator.problem;


import org.licas.PasswordHandler;
import org.jlog2.*;

import java.util.*;


/**
 * This is a base reference class for problems solved in a distributed manner over 
 * the network.
 * @author Kieran Greer
 */
public abstract class ProblemMediatorDistributed extends ProblemMediator
{
    /** For logging errors */
    private static final Logger logger;

    
    /** List of names of the distributed services */
    protected ArrayList<String> serviceNames;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ProblemMediatorDistributed.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of ProblemMediatorDistributed.
     * @param thePasswordHandler for storing passwords.
     */
    public ProblemMediatorDistributed(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        serviceNames = new ArrayList<>();
    }
}
