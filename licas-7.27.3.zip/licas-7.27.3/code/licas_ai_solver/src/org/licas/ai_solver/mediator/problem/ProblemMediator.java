/*
 * ProblemMediator.java
 *
 * Created on 18 March 2010
 *
 * Version 1.5
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.mediator.problem;


import org.licas.ai_solver.model.result.MatchResult;
import org.licas.ai_solver.stat.ClusterStats;
import org.licas.ai_solver.stat.ProcessResult;
import org.licas.ai_solver.model.result.Result;
import org.licas.ai_solver.def.ProblemMediatorDef;
import org.licas.ai_solver.SolverFactory;
import org.licas.ai_solver.model.*;
import org.licas.ai_solver.spec.ProblemScript;
import org.licas.ai_solver.spec.test.TestSpec;

import org.licas.PasswordHandler;
import org.licas.service.spec.ServiceSpec;
import org.licas.util.HeuristicConst;
import org.jlog2.*;

import java.util.*;


/**
 * This class should be implemented by all problem specification classes.
 * This abstract base class contains the main parameter list that might be used for 
 * specifying general problems. The derived classes then provide more specific methods 
 * and parameters.
 * @author Kieran Greer
 */
public abstract class ProblemMediator extends ServiceSpec implements ProblemMediatorDef
{
    /** For logging errors */
    private static final Logger logger;

    
    /** 
     * The solver framework is the controlling framework in which the heuristics are run.
     * It can include {@link HeuristicConst}.{@code GRIDMATCH} or {@code SEARCHHILL}, for example.
     */
    protected String solverType;
    
    /** Number of solutions to create */
    protected int solutionsNumber;
    
    /** True if the tests have ended or should be stopped */
    protected boolean testEnded;

    /**
     * True if store full test trace, but still need to add it. 
     * If false only the result of an evaluation is stored.
     */
    protected boolean fullTrace;

    /** A solution ordering if required. Stores the solution names. */
    protected ArrayList<String> solutionOrder;

    /**
     * The list of solution instances related to this problem.
     * Key is the solution name and value is of type 'Solution' (or derived).
     * Note that correct order may not be the order they are added in.
     */
    protected LinkedHashMap<String, Solution> solutionSet;

    /** This models the problem to be solved */
    protected Problem problem;
    
    /** The current best result */
    protected Result bestResult;
    
    /** The current result */
    protected Result result;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ProblemMediator.class.getName());
        logger.setDebug(false);
    }
    
    
    /** 
     * Create a new instance of ProblemMediator.
     * @param thePasswordHandler for storing passwords.
     */
    public ProblemMediator(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        solutionsNumber = 0;
        fullTrace = false;
        solverType = null;
        heuristicType = null;
        problem = new Problem();   
        resetValues();
    }
    
    /** Reset to starting values */
    public void resetValues()
    {
        result = null;
        solutionOrder = new ArrayList<>();
        heuristicOptions = new HashMap<>();
        solutionSet = new LinkedHashMap<>();
        bestResult = null;
        testEnded = false;
    }
    
    /**
     * Reset the problem-solving structures for the next run. In this case, remove
     * the named solutions from the list of current ones.
     * @param varList a list of variables as key-value pairs.
     * @return true if all are removed, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public abstract boolean resetForNextRun(HashMap<String, ?> varList) throws Exception;
    
    /**
     * Calculate any stats on the clustered solutions.
     * @return the results of analysing the clusters.
     * @param solverType the solver used to create the result.
     * @throws java.lang.Exception any error.
     */
    public ProcessResult processResult(String solverType) throws Exception
    {
        ArrayList<ArrayList<String>> solnNames;     //solution names
        ClusterStats clusterStats;                  //stats on clusters
        ProcessResult processStats;                 //stats on result
        
        if (bestResult != null) {
            if (solverType.equals(HeuristicConst.GRIDHILL) || solverType.equals(HeuristicConst.GRIDMATCH)) {
                if (bestResult.isMatchType()) {
                    clusterStats = (ClusterStats)SolverFactory.getInstance().getSolverData().getProcessResult(solverType);
                    clusterStats.calcStats((GridProblemMediator)this, (MatchResult)bestResult);
                    return clusterStats;
                }
                else if (bestResult.isClusterType()) {
                    processStats = SolverFactory.getInstance().getSolverData().getProcessResult(solverType);
                    solnNames = processStats.solutionNamesInGroups(bestResult);
                    processStats.clusters = processStats.removeDuplicateGroups(solnNames);
                    return processStats;
                }
            }
            else {
                processStats = SolverFactory.getInstance().getSolverData().getProcessResult(solverType);
                solnNames = processStats.solutionNamesInGroups(bestResult);
                processStats.clusters = processStats.removeDuplicateGroups(solnNames);
                return processStats;
            }
        }
        
        return null;
    }
    
    /**
     * Copy any values specific to the problem solver classes to the related specific
     * structures, from the more general list of variables from the Problem Spec itself.
     * @param testSpec the model of the tests to perform.
     * @throws java.lang.Exception any error.
     */
    public void copyToConfig(TestSpec testSpec) throws Exception
    {
        ProblemScript testScript;                  //test script
        
        testScript = testSpec.getTestScript();
        solverType = testScript.solverType;
        heuristicType = testScript.heuristicType;
        datasetType = SolverFactory.getInstance().getSolverData().dataClassFromType(testScript.datasetType);
        setSolutionsNumber(testScript.servicesNum);
        serviceType = testScript.serviceType;
        setHeuristicOptions((HashMap)testScript.heuristicOptions.clone());               
    }

    /**
     * Get the ordered list of solution names.
     * @return the solutions ordering list of names, so that index on it can be used.
     */
    public ArrayList<String> getProblemNames() {
        return problem.getProblemNames();
    }
    
    /**
     * Set the dataset type. This is the actual class name.
     * @param thisDatasetType the dataset type.
     */
    public void setDatasetType(String thisDatasetType)
    {
        datasetType = SolverFactory.getInstance().getSolverData().dataClassFromType(thisDatasetType);
    }
    
    /**
     * Set the type of heuristic to use.
     * @param thisHeuristicType the test heuristic.
     */
    public void setHeuristicType(String thisHeuristicType)
    {
        heuristicType = thisHeuristicType;
    }

    /**
     * Get the type of heuristic to use.
     * @return the value of heuristicType.
     */
    public String getHeuristicType()
    {
        return heuristicType;
    }
    
    /**
     * Clear the list of heuristic-related variable values.
     */
    public void clearHeuristicOptions()
    {
        heuristicOptions.clear();
    }
    
    /**
     * Add a new heuristic-related variable value.
     * @param name a variable name.
     * @param value related value. Can be null for no value.
     */
    public void addHeuristicOption(String name, Object value)
    {
        heuristicOptions.put(name, value);
    }
    
    /**
     * Set the list of heuristic options, as key-value pairs.
     * @param thisHeuristicOptions the value of heuristicOptions.
     */
    public void setHeuristicOptions(HashMap<String, Object> thisHeuristicOptions)
    {
        heuristicOptions = thisHeuristicOptions;
    }
    
    /**
     * Get the list of heuristic-related variable values. Values can be null.
     * @return the value of heuristicOptions.
     */
    public HashMap<String, Object> getHeuristicOptions()
    {
        return heuristicOptions;
    }

    /**
     * Set the problem model.
     * @param thisProblem a description of the problem in terms of tasks to be solved.
     */
    public void setProblem(Problem thisProblem)
    {
        problem = thisProblem;
    }

    /**
     * Get the problem model.
     * @return the value of problem.
     */
    public Problem getProblem()
    {
        return problem;
    }
    
    /**
     * Set the number of solutions to create.
     * @param thisSolutionsNumber the number of solutions.
     */
    public void setSolutionsNumber(int thisSolutionsNumber)
    {
        solutionsNumber = thisSolutionsNumber;
    }

    /**
     * Get the number of solutions to create.
     * @return the totalValue of solutionsNumber.
     */
    public int getSolutionsNumber()
    {
        return solutionsNumber;
    }

    /**
     * Set the list of compound solution instances related to the problem.
     * @param thisSolutionsList the list of solution instances.
     */
    public void setSolutionSet(LinkedHashMap thisSolutionsList)
    {
        solutionSet = thisSolutionsList;
    }

    /**
     * Get the list of compound solution instances.
     * @return the value of solutionsList.
     */
    public LinkedHashMap<String, Solution> getSolutionSet()
    {
        return solutionSet;
    }

    /**
     * Return true if the tests have ended or should be stopped. This is not set
     * automatically and needs to be implemented by any derived class.
     * @return the value of testEnded.
     */
    public boolean getTestEnded()
    {
        return testEnded;
    }
    
    /**
     * Set the value indicating if a full test trace should be stored for output.
     * @param thisFullTrace true if save a full trace. 
     */
    public void setFullTrace(boolean thisFullTrace)
    {
        fullTrace = thisFullTrace;
    }
    
    /**
     * Get the value indicating if a full test trace should be stored for output.
     * @return the value of fullTrace.
     */
    public boolean getFullTrace()
    {
        return fullTrace;
    }
}
