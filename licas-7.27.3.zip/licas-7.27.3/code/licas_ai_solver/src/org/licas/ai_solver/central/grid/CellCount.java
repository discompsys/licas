/*
 * CellCount.java
 *
 * Created on 21 February 2017
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.central.grid;


import org.licas.util.ObjectHandler;


/**
 * This class stores the details of a cell value and count.
 * @author Kieran Greer
 */
public class CellCount 
{
    /** The cell count */
    public double count;
    
    /** The cell value */
    public Object value;
    
    
    /** Create a new instance of CellCount */
    public CellCount()
    {
        count = 0;
        value = null;
    }
    
    /**
     * Get a string-based description of this cell match.
     * @return a string-based description of this object.
     */
    public String toString()
    {
        String matchStr;                            //match string
        
        matchStr = "";
        try {
            matchStr += ("Value: " + ObjectHandler.getValue(value));
        }
        catch (Exception ex) {}

        matchStr += (", count: " + String.valueOf(count));
        matchStr += ("\n");
        
        return matchStr;
    }
    
    /**
     * Clone and return a copy of this cell match.
     * @return a copy of this cell match.
     */
    public Object clone()
    {
        CellCount cloneMatch;                       //clone copy
        
        cloneMatch = new CellCount();
        cloneMatch.count = count;
        cloneMatch.value = value;
            
        return cloneMatch;
    }
}
