/*
 * SomProblemScript.java
 *
 * Created on 27 October 2014
 *
 * Version 1.0.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.spec;


import org.licas.ai_solver.central.SomConst;
import org.licas.ai_solver.central.SomConfig;

import org.licas.service.spec.BehaviourScript;
import org.licas.PasswordHandler;
import org.licas.data.gen.DataGenerator;
import org.licas.util.HeuristicConst;
import org.licas.util.ServiceConst;


/**
 * This class reads an XML file and loads in a specification for a set of test runs.
 * This includes some additional variables for the SOM neural network-type of tests.
 * @author Kieran Greer
 */
public class SomProblemScript extends ProblemScript
{
    /** Configuration values specific to the SOM neural network */
    public SomConfig somConfig;
    
    
    /** 
     * Create a new instance of SomProblemScript.
     * @param thePasswordHandler for storing passwords.
     */
    public SomProblemScript(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        somConfig = new SomConfig();
    }
    
    /**
     * Convert the set of values into the structure to be used to initialise the test services.
     * this depends on the framework, or solver type. The script is already setup for the 
     * centralised problem-solving and so does not need to be changed for that, for example,
     * but the distributed linking can be more easily initialised as the behaviour tests.
     * @return true if converted OK.
     */
    public boolean convertForInitialise()
    {
        String generatorClass;                      //generator class
        
        //only add data generator, do not add evaluator, as that is part of the nn
        if (datasetType != null)
        {
            generatorClass = DataGenerator.getGeneratorClass(datasetType);
            if (generatorClass != null)
            {
                serviceClasses.put(ServiceConst.DATAGENERATORTYPE, generatorClass);
            }
        }
                
        return true;
    }
    
    
    /**
     * Copy the behaviour script values into this object.
     * @param behaviourScript the behaviour script.
     */
    public void copy(BehaviourScript behaviourScript)
    {
        if (behaviourScript != null)
        {
            super.copy(behaviourScript);
            
            //som problem script variables
            if (behaviourScript instanceof SomProblemScript)
            {
                somConfig = (SomConfig)((SomProblemScript)behaviourScript).somConfig.clone();            
            }
        }
    }
    
    /**
     * Validate the whole script and return a description of any errors.
     * @return a description of any errors or null if OK.
     */
    public String validateScript()
    {
        boolean somMatch;                       //true if som nn solver type
        String validateReply;                   //validation errors
        
        somMatch = solverType.equals(HeuristicConst.SOMNN);
        validateReply = super.validateScript();
        if (validateReply == null) validateReply = "";
        else validateReply += "\n";
        
        if (somMatch)
        {
            validateReply += validateVariable(SomConst.LEARNFRAMEWORK);
            validateReply += validateVariable(SomConst.TOPOLOGY);
            validateReply += validateVariable(SomConst.TOPOLOGYROW);
            validateReply += validateVariable(SomConst.TOPOLOGYCOL);
            validateReply += validateVariable(SomConst.NEIGHBOURHOODFUNCION);
            validateReply += validateVariable(SomConst.ACTIVATIONFUNCION);
            validateReply += validateVariable(SomConst.WEIGHTSNUMBER);
        }
        
        validateReply = validateReply.trim();        
        if (validateReply.equals("")) validateReply = null;
        return validateReply;
    }
    
    /**
     * Validate the script variable and return a description if invalid.
     * @param varType the variable type.
     * @return a description of any error, of null if OK.
     */
    protected String validateVariable(String varType)
    {
        String validateError;                   //validate error
        
        validateError = super.validateVariable(varType);
        if ((validateError == null) || validateError.equals(""))
        {
            if (varType.equals(SomConst.LEARNFRAMEWORK))
            {
                if (somConfig.learningFramework == null)
                    validateError = (SomConst.LEARNFRAMEWORK + ": is missing.\n");
            }
            else if (varType.equals(SomConst.TOPOLOGY))
            {
                if (somConfig.topology == null)
                    validateError = (SomConst.TOPOLOGY + ": is missing.\n");
            }
            else if (varType.equals(SomConst.TOPOLOGYROW))
            {
                try {
                    if (somConfig.topologyRow <= 0.0)
                        validateError = (SomConst.TOPOLOGYROW + ": must be greater than 0.\n");
                }
                catch (Exception ex) {
                    validateError = (SomConst.TOPOLOGYROW + ": has incorrect format.\n");
                }
            }
            else if (varType.equals(SomConst.TOPOLOGYCOL))
            {
                try {
                    if (somConfig.topologyCol <= 0.0)
                        validateError = (SomConst.TOPOLOGYCOL + ": must be greater than 0.\n");
                }
                catch (Exception ex) {
                    validateError = (SomConst.TOPOLOGYCOL + ": has incorrect format.\n");
                }
            }
            else if (varType.equals(SomConst.TOPOLOGYRADIUS))
            {
                try {
                    if (somConfig.topologyRadius < 0.0)
                        validateError = (SomConst.TOPOLOGYRADIUS + ": must be greater than or equal to 0.\n");
                }
                catch (Exception ex) {
                    validateError = (SomConst.TOPOLOGYRADIUS + ": has incorrect format.\n");
                }
            }
            else if (varType.equals(SomConst.NEIGHBOURHOODFUNCION))
            {
                if (somConfig.neighbourhoodFunction == null)
                    validateError = (SomConst.NEIGHBOURHOODFUNCION + ": is missing.\n");
            }
            else if (varType.equals(SomConst.ACTIVATIONFUNCION))
            {
                if (somConfig.activationFunction == null)
                    validateError = (SomConst.ACTIVATIONFUNCION + ": is missing.\n");
            }
            else if (varType.equals(SomConst.WEIGHTSNUMBER))
            {
                try {
                    if (somConfig.weightNumber <= 0.0)
                        validateError = (SomConst.WEIGHTSNUMBER + ": must be greater than 0.\n");
                }
                catch (Exception ex) {
                    validateError = (SomConst.WEIGHTSNUMBER + ": has incorrect format.\n");
                }
            }
        }
        
        return validateError;
    }
}
