/*
 * LearnWeights.java
 *
 * Created on 10 May 2007
 *
 * Version 1.3
 *
 * Copyright (c) Kieran Greer
 *
 */

package org.licas.ai_solver.learn;


import org.licas.Service;
import org.jlog2.*;


/**
 * This class is used to learn the best values for the dynamic linking weights. 
 * It is an initial attempt at learning, by changing the weight increment or decrement values,
 * based on earlier updates. This is an older class that has not been developed recently.
 * @author Kieran Greer
 */
public class LearnWeights extends Service
{   
    /** Range constants */
    protected static float MAXWEIGHT = (float)1.0;
    protected static float MINWEIGHT = (float)0.001;
    
    /** The logger */
    private static final Logger logger;
    
    /**Previous update sum for increment */
    protected float previousUpdateSumInc;
    
    /**Previous update sum for decrement */
    protected float previousUpdateSumDec;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(LearnWeights.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Creates a new instance of LearnWeights.
     * @param thisPassword the password to protect.
     * @param thisAdminKey a unique key to protect loading/removal.
     * @throws java.lang.Exception any error.
     */
    public LearnWeights(String thisPassword, String thisAdminKey) throws Exception
    {
        super(thisPassword, thisAdminKey);
        initialise();
    }
    
    /**
     * Initialise some values.
     */
    protected void initialise()
    {
        previousUpdateSumInc = Float.MIN_VALUE;
        previousUpdateSumDec = Float.MIN_VALUE;
    }
    
    /** 
     * Adjust the increment weight value based on the previous number 
     * of sources moved up or down.
     * @param incWeight the current increment weight value.
     * @param totalMovedUp number of sources currently moved up a level.
     * @param totalMovedDown number of sources currently moved down a level.
     * @return the new increment weight value.
     */
    public float updateIncrementWeight(float incWeight, int totalMovedUp, int totalMovedDown)
    {
        //return updateIncrementWeight1(incWeight, totalMovedUp, totalMovedDown);
        return updateIncrementWeight2(incWeight, totalMovedUp, totalMovedDown);
    }
    
    /** 
     * Adjust the increment weight value based on the previous number 
     * of sources moved up or down - version 1 considers only these update values.
     * @param incWeight the current increment weight value.
     * @param totalMovedUp number of sources currently moved up a level.
     * @param totalMovedDown number of sources currently moved down a level.
     * @return the new increment weight value.
     */
    protected float updateIncrementWeight1(float incWeight, int totalMovedUp, int totalMovedDown)
    {
        float scale;                        //factor to scale by
        
        if (totalMovedUp < totalMovedDown) {
            if (totalMovedUp == 0) {
                totalMovedUp++;
                totalMovedDown++;
            }
            
            //increase increment weight
            scale = (float)0.5 + ((float)totalMovedDown / (float)(totalMovedUp + totalMovedDown));
            incWeight /= scale;
        }
        else if (totalMovedUp > totalMovedDown) {
            if (totalMovedDown == 0) {
                totalMovedUp++;
                totalMovedDown++;
            }
            
            //decrease increment weight
            scale = (float)0.5 + ((float)totalMovedUp / (float)(totalMovedUp + totalMovedDown));
            incWeight *= scale;
        }
        
        if (incWeight > MAXWEIGHT) incWeight = MAXWEIGHT;
        if (incWeight < MINWEIGHT) incWeight = MINWEIGHT;
        
        return incWeight;
    }
    
    /** 
     * Adjust the increment weight value based on the previous number 
     * of sources moved up or down - version 2 also considers last update values.
     * @param incWeight the current increment weight value.
     * @param totalMovedUp number of sources currently moved up a level.
     * @param totalMovedDown number of sources currently moved down a level.
     * @return the new increment weight value.
     */
    protected float updateIncrementWeight2(float incWeight, int totalMovedUp, int totalMovedDown)
    {
        float thisUpdateSum;                //this update sum
        float delta;                        //update difference
        
        if (totalMovedUp == 0) {
            totalMovedUp++;
            totalMovedDown++;
        }
        
        thisUpdateSum = ((float)totalMovedUp / (float)totalMovedDown);
        if (previousUpdateSumInc == Float.MIN_VALUE) {
            delta = 0;
        }
        else {
            delta = thisUpdateSum / previousUpdateSumInc;
        }
        previousUpdateSumInc = thisUpdateSum;

        //if less moved up on this update (delta < 0) then increase increment weight
        //if more moved up on this update (delta > 0) then decrease increment weight
        if (delta != 0) incWeight /= delta;
        
        if (incWeight > MAXWEIGHT) incWeight = MAXWEIGHT;
        if (incWeight < MINWEIGHT) incWeight = MINWEIGHT;
        
        return incWeight;
    }
    
    /** 
     * Adjust the decrement weight value based on the previous number 
     * of sources moved up or down.
     * @param decWeight the current decrement weight value.
     * @param totalMovedUp number of sources currently moved up a level.
     * @param totalMovedDown number of sources currently moved down a level.
     * @return the new decrement weight value.
     */
    public float updateDecrementWeight(float decWeight, int totalMovedUp, int totalMovedDown)
    {
        //return updateDecrementWeight1(decWeight, totalMovedUp, totalMovedDown);
        return updateDecrementWeight2(decWeight, totalMovedUp, totalMovedDown);
    }
    
    /** 
     * Adjust the decrement weight value based on the previous number 
     * of sources moved up or down - version 1 considers only these update values.
     * @param decWeight the current decrement weight value.
     * @param totalMovedUp number of sources currently moved up a level.
     * @param totalMovedDown number of sources currently moved down a level.
     * @return the new decrement weight value.
     */
    protected float updateDecrementWeight1(float decWeight, int totalMovedUp, int totalMovedDown)
    {
        float scale;                        //factor to scale by
        
        if (totalMovedUp < totalMovedDown) {
            if (totalMovedUp == 0) {
                totalMovedUp++;
                totalMovedDown++;
            }
            
            //decrease decrement weight
            scale = (float)0.5 + ((float)totalMovedUp / (float)(totalMovedDown + totalMovedUp));
            decWeight *= scale;
        }
        else if (totalMovedUp > totalMovedDown) {
            if (totalMovedDown == 0) {
                totalMovedUp++;
                totalMovedDown++;
            }
            
            //increase decrement weight
            scale = (float)0.5 + ((float)totalMovedDown / (float)(totalMovedUp + totalMovedDown));
            decWeight /= scale;
        }
        
        if (decWeight > MAXWEIGHT) decWeight = MAXWEIGHT;
        if (decWeight < MINWEIGHT) decWeight = MINWEIGHT;
        
        return decWeight;
    }
    
    /** 
     * Adjust the decrement weight value based on the previous number 
     * of sources moved up or down - version 2 also considers last update values.
     * @param decWeight the current decrement weight value.
     * @param totalMovedUp number of sources currently moved up a level.
     * @param totalMovedDown number of sources currently moved down a level.
     * @return the new decrement weight value.
     */
    protected float updateDecrementWeight2(float decWeight, int totalMovedUp, int totalMovedDown)
    {
        float thisUpdateSum;                //this update sum
        float delta;                        //update difference
        
        if (totalMovedDown == 0) {
            totalMovedUp++;
            totalMovedDown++;
        }
        
        thisUpdateSum = ((float)totalMovedDown / (float)totalMovedUp);
        if (previousUpdateSumDec == Float.MIN_VALUE) {
            delta = 0;
        }
        else {
            delta = thisUpdateSum / previousUpdateSumDec;
        }
        previousUpdateSumDec = thisUpdateSum;

        //if less moved down on this update (delta < 0) then increase decrement weight
        //if more moved down on this update (delta > 0) then decrease decrement weight
        if (delta != 0) decWeight /= delta;
        
        if (decWeight > MAXWEIGHT) decWeight = MAXWEIGHT;
        if (decWeight < MINWEIGHT) decWeight = MINWEIGHT;
        
        return decWeight;
    }
}
