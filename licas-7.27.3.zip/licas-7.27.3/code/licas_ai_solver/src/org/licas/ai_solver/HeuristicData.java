/*
 * HeuristicData.java
 *
 * Created on 30 January 2016
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.ai_heuristic.model.FactoryInfo;
import java.util.*;


/**
* This class describes the methods used by the heuristic data. A copy is stored in the
 * {@link HeuristicFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public abstract class HeuristicData 
{
    /** The default heuristic classifications */
    protected HeuristicClassification heuristicClassif;
    
    /** 
     * List of modules automatically loaded in during startup. Of type {@link ModuleHeuristicFactory}.
     */
    protected static ArrayList<ModuleHeuristicFactory> heuristicModules = new ArrayList<>();
    
    /** 
     * Create a new instance of HeuristicData. 
     * @param theHeuristicClassif the heuristic classifications.
     * @param theHeuristicModules list of heuristic modules.
     */
    public HeuristicData(HeuristicClassification theHeuristicClassif, ArrayList<ModuleHeuristicFactory> theHeuristicModules)
    {
        heuristicClassif = theHeuristicClassif;
        heuristicModules = theHeuristicModules;
    }
    
    
    /**
     * Return true if the heuristic type is a known type that can be processed generically.
     * For example, the simple types or Bag-of-Words can be processed by the default
     * evaluators.
     * @param dataType the data object type.
     * @return true if a known type that the evaluators can process.
     */
    public abstract boolean genericDataType(String dataType);
           
    /**
     * Return true if the data type can be used with the genetic algorithms specifically.
     * @param dataType the type of data object that the genetic algorithm might process.
     * @return true if it can be used with genetic algorithms.
     */
    public abstract boolean canBeGeneticType(String dataType);   
    
    /**
     * Get a list of available data generators.
     * @return the list of data generators.
     */
    public abstract HashMap<String, FactoryInfo> getDataGenerators();
    
    /**
     * Get the type of data object that would be evaluated by the heuristic.
     * @param heuristicType the type of heuristic to use.
     * @return the type of object that would be evaluated, or null if unclear.
     */
    public abstract String getObjectType(String heuristicType);
}
