/**
 * Genetic algorithm chromosome genes. 
 */
package org.licas.ai_solver.model.genetic.genes;