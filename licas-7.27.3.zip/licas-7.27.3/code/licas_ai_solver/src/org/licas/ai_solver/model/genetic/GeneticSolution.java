/*
 * GeneticSolution.java
 *
 * Created on 26 August 2010
 *
 * Version 1.2.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.model.genetic;


import org.licas.ai_solver.def.SolutionGeneticDef;
import org.licas.ai_solver.model.*;

import java.util.ArrayList;


/**
 * This is an abstract base solution for the hyper-heuristic problem based on genetic algorithms.
 * @author Kieran Greer
 */
public abstract class GeneticSolution extends Solution implements SolutionGeneticDef
{
    /** The chromosome this solution uses */
    protected Chromosome chromosome;

    /**
     * List of names of entities that this solution was created from.
     * This is useful if the solution is evolved from other ones.
     */
    protected ArrayList<String> createdFrom;
    
    
    /**
     * Create a new instance of GeneticSolution.
     * @param thisName the solution name.
     */
    public GeneticSolution(String thisName)
    {
        super(thisName);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        chromosome = null;
        createdFrom = new ArrayList<>();
    }


    /**
     * Set the chromosome or this solution.
     * @param thisChromosome the chromosome.
     */
    public void setChromosome(Chromosome thisChromosome)
    {
        chromosome = thisChromosome;
    }

    /**
     * Get the chromosome that this solution uses.
     * @return the value of chromosome.
     */
    public Chromosome getChromosome()
    {
        return chromosome;
    }
    
    /**
     * Clear the list of entities that this solution was created from.
     */
    public void clearCreatedFrom()
    {
        createdFrom.clear();
    }
    
    /**
     * Add an entity name to the list that this solution was created from. The
     * name is only stored once.
     * @param entityName the entity name.
     * @return true if the name is new or false if it already exists.
     */
    public boolean addCreatedFrom(String entityName)
    {
        if (!createdFrom.contains(entityName)) {
            createdFrom.add(entityName);
            return true;
        }
        
        return false;
    }
    
    /**
     * Get the list of entity names that this solution was created from.
     * @return the value of createdFrom.
     */
    public ArrayList<String> getCreatedFrom()
    {
        return createdFrom;
    }
}
