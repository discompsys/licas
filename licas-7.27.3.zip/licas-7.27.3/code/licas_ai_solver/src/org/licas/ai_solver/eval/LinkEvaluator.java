/*
 * LinkEvaluator.java
 *
 * Created on 21 October 2013
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.eval;


import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.mediator.problem.*;
import org.licas.ai_solver.util.*;

import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;
import org.licas_xml.abs.*;


/**
 * This class runs a set of generic tests on the distributed linking problem model.
 * This class generates and solves problems based on a generic framework, with a
 * distributed services with links architecture.
 * @author Kieran Greer
 */
public class LinkEvaluator extends EvaluatorDistributed
{
    /** For logging */
    private static final Logger logger;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(LinkEvaluator.class.getName());
        logger.setDebug(false);
    }

    /** Create a new instance of LinkEvaluator */
    public LinkEvaluator()
    {
        super();
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {}

    /**
     * Create or initialise the original problem and solution values. As this is a
     * distributed test with services already setup, this method only sets a start message.
     * @param testSpec the specification describing the tests to run.
     * @param probMediator the model of the problem with all required elements.
     * @return true if initialised OK, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean initialiseMediator(TestSpec testSpec, ProblemMediator probMediator) throws Exception
    {
        Element origProblem;                                //original problem

        try
        {
            //add original problem to the result element
            origProblem = XMLFactory.getInstance().createElement(SolverConst.PROBLEM);           
            origProblem.setText("Original Problem Specification: generate from new set");           
            testResults.addContent(origProblem);

            return true;
        }
        catch (Exception ex)
        {
             throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "initialiseMediator", null, ex);
        }
    }
    
    /**
     * Run a set of tests based on the test specification.
     * @param testSpec the specification describing the tests to run.
     * @param probMediator the model of the problem with all required elements.
     * @return true if the current test results are better than the previous set.
     * @throws java.lang.Exception any error.
     */
    public boolean evaluateSolutions(TestSpec testSpec, ProblemMediator probMediator) throws Exception
    {
        boolean resultsBetter;                      //true if current results are better
        LinkProblemMediator linkProbSpec;           //link problem spec
        
        try
        {
            //run tests on the problems - does not use the rollback, repeats, etc.
            //default always return true
            resultsBetter = true;
                        
            testResults = XMLFactory.getInstance().createElement(SolverConst.ALLRESULTS);           
            linkProbSpec = (LinkProblemMediator)probMediator;
            linkProbSpec.solve(testSpec);
            
            lastTestResult = linkProbSpec.getResultXml();
            testResults.addContent(lastTestResult);
          
            return resultsBetter;
        }
        catch (Exception ex)
        {
             throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "evaluateSolutions", null, ex);
        }
    }
}
