/*
 * Cluster.java
 *
 * Created on 30 June 2017
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.model.result;


import java.util.ArrayList;


/**
 * This class represents a single cluster of the solved problem.
 * @author Kieran Greer
 */
public class Cluster
{
    /** A unique identifier for the cluster */
    public String name;
    
    /** List of values representing the cluster */
    public ArrayList list;
    
    /**
     * Create a new instance of Cluster.
     */
    public Cluster()
    {
        name = null;
        list = new ArrayList();
    }
    
    /**
     * Create a new instance of Cluster.
     * @param theName unique cluster ID.
     */
    public Cluster(String theName)
    {
        name = theName;
        list = new ArrayList();
    }
    
    /**
     * Create a new instance of Cluster.
     * @param theName unique cluster ID.
     * @param theList list of clustered references.
     */
    public Cluster(String theName, ArrayList theList)
    {
        name = theName;
        list = theList;
    }
    
    /**
     * Get a string-based description of this cluster.
     * @return string-based description of this object.
     */
    public String toString()
    {
        String solutionStr;                 //solution as a string

        solutionStr = ("Name: " + name);
        solutionStr += ("\nCluster: " + String.valueOf(list));
        return solutionStr;
    }
    
    /**
     * Get a cluster key name.
     * @param index unique index value for the key.
     * @return name plus index as the key.
     */
    public static String toKey(int index)
    {
        return ("Cluster_" + String.valueOf(index));            
    }
}
