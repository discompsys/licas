/*
 * SearchProblemMediator.java
 *
 * Created on 14 July 2015.
 *
 * Version 1.5
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.mediator.problem;


import org.ai_heuristic.functs.Function;
import org.licas.ai_solver.model.SolutionContainer;
import org.licas.ai_solver.model.comp.CompoundSolution;
import org.licas.ai_solver.model.result.MatchPair;
import org.licas.ai_solver.model.result.MatchPairName;
import org.licas.ai_solver.search.HillClimbing;
import org.licas.ai_solver.model.result.MatchResult;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.SolverFactory;
import org.licas.ai_solver.model.Solution;
import org.licas.ai_solver.model.central.SearchSolution;
import org.licas.ai_solver.util.*;

import org.ai_heuristic.eval.metric.MetricDataset;
import org.licas.data.DataQueryModel;
import org.licas.PasswordHandler;
import org.licas.util.AiConst;
import org.licas_xml.abs.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;

import java.util.*;
import org.licas.ai_solver.mediator.ProblemSolverMediator;
import org.licas.ai_solver.model.result.Result;
import org.licas.server.LocalServer;


/**
 * This class models the problem to be solved using a centralised search procedure
 * that iterates over cycles of test runs, as in a tree search.
 * @author Kieran Greer
 */
public class SearchProblemMediator extends IterateMediatorEvolve
{
    /** For logging errors */
    private static final Logger logger;

    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SearchProblemMediator.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of SearchProblemMediator.
     * @param thePasswordHandler for storing passwords.
     */
    public SearchProblemMediator(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {}
    
    /**
     * Try to (re)sort the problem list after making appropriate changes.
     * @param testSpec the test specification describing the test run.
     * @param separator the tokenizer character.
     * @throws java.lang.Exception any error.
     */
    protected void sortProblems(TestSpec testSpec, String separator) throws Exception
    {
        ProblemSolverMediator solverMediator;       //solver mediator
              
        //retrieve the dataset values and initialise the knn
        inputVariables = new HashMap<>();
        solverMediator = (ProblemSolverMediator)SolverFactory.getInstance().getSolverMediators().createServiceMediator(solverType);
        serviceNames = solverMediator.getServiceNames();
            
        //create the problems with the data
        if (LocalServer.isRunning()) {
            dataHash = solverMediator.getServicesData(testSpec);
            createStoreData(testSpec);
        }
        else {
            //can be central file-only test with no server or services
            dataHash = new LinkedHashMap<>();
            createStoreData(testSpec);
        }
    }
    
    /**
     * Optimise the solutions using the appropriate framework.
     * @param testSpec the model of the tests to perform.
     * @return clusters of solutions or references from the latest optimisation phase.
     * @throws java.lang.Exception any error.
     */
    public Result solve(TestSpec testSpec) throws Exception 
    {
        int i;
        boolean solnAdded;                          //true if aolution added
        String solutionName;                        //solution name
        String solutionType;                        //solution type
        ArrayList<String> problemNames;             //list of problem names
        ArrayList<String> compSolns;                //compound solutions
        ArrayList<String> origSolnList;             //original solutions
        ArrayList<String> solutionNames;            //solution names
        ArrayList<MatchPair> matchList;             //matching results
        ArrayList<Solution> solutionList;           //list of best solutions
        SolutionContainer solutionContainer;        //container for the compound solutions
        HillClimbing solveSearch;                   //to solve the problem
        MetricDataset problemDataset;               //the problem dataset
        Solution solution;                          //new solution that is created
        CompoundSolution compoundSolution;          //compound solution
        
        try {
            result = new MatchResult();
            solutionType = testSpec.getTestScript().metricType;
            solveSearch = new HillClimbing(testSpec);
            solutionList = new ArrayList<>();
            
            if (solutionHierarc.isEmpty()) {
                compoundSolution = new CompoundSolution(SolverConst.COMPOUNDSOLUTION);
                solutionContainer = new SolutionContainer(SolverConst.COMPOUNDSOLUTION);
                solutionContainer.addSolution(compoundSolution);
                solutionHierarc.add(solutionContainer);
                
                //generate first set of problems
                sortProblems(testSpec, ",");
                problemNames = problem.getProblemNames();
                
                for (i = 0; i < problemNames.size(); i++)
                {
                    problemDataset = problem.getProblem(problemNames.get(i));
                    solutionName = NameHandler.checkforName(problemDataset);
                    if (solutionName == null) {
                        solutionName = (heuristicType + String.valueOf(i));
                        problemDataset.setName(solutionName);
                    }

                    solution = createNewSolution(solutionType, problemDataset);
                    solutionList.add(solution);         
                    compoundSolution.addSolution(solution);
                }
            }
            else {
                //add each compound solution as is and then each other solution separately
                solutionList = new ArrayList<>();
                solutionNames = new ArrayList<>();
                solutionContainer = new SolutionContainer(SolverConst.COMPOUNDSOLUTION);
                solutionContainer.addSolution(CompoundSolution.toCompoundSolution(solutionHierarc.get(solutionHierarc.size()-1)));
                solutionHierarc.remove(solutionHierarc.size()-1);
                solutionHierarc.add(solutionContainer);
                
                for (String key: solutionContainer.getSolutions().keySet())
                {
                    compoundSolution = (CompoundSolution)solutionContainer.getSolutions().get(key);
                    solutionList.add(compoundSolution);
                    compSolns = compoundSolution.getSolutionNames();
                    
                    for (i = 0; i < compSolns.size(); i++)
                    {
                        solutionName = compSolns.get(i);
                        if (!solutionNames.contains(solutionName)) {
                            solutionNames.add(solutionName);
                        }
                    }
                }
                
                //add any remaining solutions
                solutionContainer = solutionHierarc.get(0);
                compoundSolution =
                        (CompoundSolution)solutionContainer.getSolutions().get(solutionContainer.getSolutionNames().get(0));
                origSolnList = compoundSolution.getSolutionNames();
                
                //if no new solutions added, then replace cs with orig solution list
                //otherwise use cs as the clusters and add remaining to it
                solnAdded = false;
                for (i = 0; i < origSolnList.size(); i++)
                {
                    solutionName = origSolnList.get(i);
                    if (!solutionNames.contains(solutionName)) {
                        solutionList.add(compoundSolution.getSolution(solutionName));
                        solnAdded = true;
                    }
                }
                
                if (!solnAdded) {
                    solutionList = new ArrayList<>();
                    for (i = 0; i < origSolnList.size(); i++)
                    {
                        solutionName = origSolnList.get(i);
                        solutionList.add(compoundSolution.getSolution(solutionName));
                    }
                }
            }
            
            solveSearch.setSolutions(solutionList);
            matchList = solveSearch.solve();

            if (matchList != null) {
                ((MatchResult)result).setSolutionMatches(matchList);
            }
            
            return result;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "solve", null, ex);
        }
    }
    
    /**
     * Create a new genetic solution with chromosomes, etc. This is a default implementation
     * for the default genetic algorithms that are provided with this package. This includes
     * creating solutions from the simple types of {@code Integer}, {@code Float}, or 
     * {@code String}, primarily for testing purposes only.
     * @param solutionType the type of solution to create.
     * @param problemDataset the problem dataset to create the solution with.
     * @return the new solution.
     * @throws java.lang.Exception any error.
     */
    public Solution createNewSolution(String solutionType, MetricDataset problemDataset) 
            throws Exception
    {
        String solutionName;                    //solution name
        DataQueryModel dataInfo;                //stores evaluator parameters
        SearchSolution solution;                //solution
        Function evalMetric;                    //the solution evaluation metric
        
        //create a new solution
        solutionName = problemDataset.getName();       
        solution = new SearchSolution(solutionName);
        dataInfo = new DataQueryModel();
        dataInfo.setDataType(datasetType);
        
        evalMetric = SolverFactory.getInstance().getSolverMetrics().getEvaluationFunction(datasetType,
                solutionType, SolverFactory.getInstance().getSolverData().getEvaluateData(dataInfo), heuristicOptions);

        //add the evaluator and the dataset to the solution
        solution.setEvaluator(evalMetric);
        solution.setDataset(problemDataset);

        return solution;
    }
    
    /**
     * This can be used to combine existing solutions to evolve or expand new ones.
     * Results are returned as solution pairs, so combine these into overlapping groups
     * and retrieve actual solutions and store.
     * @param result the result generated by the problem solver. 
     * Can be more solutions, references, or an error..
     * @return true if solutions were combined, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean updateSolutions(Result result) throws Exception
    {
        int i, j;
        String solutionName;
        MatchPairName solnMatch;                    //solution match
        MatchResult solutionSet;                    //solutions result
        ArrayList<MatchPair> solutionList;          //list of matching solutions
        SearchSolution searchSoln;                  //search solution
        SolutionContainer solutionContainer;        //container for the compound solutions
        CompoundSolution compoundSolution;          //compound solution
        CompoundSolution nextCompSoln;              //next compound solution
        
        try {
            if ((result != null) && result.isMatchType()) {
                solutionSet = (MatchResult)result;
            
                //add solutions to compound solution in any order, before problem solving,
                //this is then reordered to be in sync with the problem dataset order
                if (solutionHierarc.size() < 2) {
                    //zero or original list, so needs 1 cluster list as well
                    solutionContainer = new SolutionContainer(SolverConst.COMPOUNDSOLUTION);
                }
                else {
                    //add to existing clusters
                    solutionContainer = solutionHierarc.get(solutionHierarc.size()-1);
                }

                solutionList = solutionSet.getSolutionMatches();
                for (i = 0; i < solutionList.size(); i++)
                {
                    solnMatch = (MatchPairName) solutionList.get(i);

                    compoundSolution = null;                
                    for (j = 0; (compoundSolution == null) && (j < solutionContainer.getSolutionNames().size()); j++)
                    {
                        nextCompSoln = (CompoundSolution)solutionContainer.getSolutions().get(solutionContainer.getSolutionNames().get(j));
                        if (nextCompSoln.getSolutionNames().contains(solnMatch.firstName) ||
                            nextCompSoln.getSolutionNames().contains(solnMatch.secondName)) {
                            compoundSolution = nextCompSoln;
                        }
                    }

                    if (compoundSolution == null) {
                        solutionName = (heuristicType + "_" + SolverConst.COMPOUNDSOLUTION);
                        compoundSolution = new CompoundSolution(solutionName);
                        solutionContainer.addSolution(compoundSolution);
                    }

                    if (!compoundSolution.getSolutionNames().contains(solnMatch.firstName)) {
                        searchSoln = (SearchSolution) this.solutionSet.get(solnMatch.firstName);
                        compoundSolution.addSolution(searchSoln);
                    }
                    if (!compoundSolution.getSolutionNames().contains(solnMatch.secondName)) {
                        searchSoln = (SearchSolution) this.solutionSet.get(solnMatch.secondName);
                        compoundSolution.addSolution(searchSoln);
                    }
                }

                //set the result object
                if (bestResult == null) bestResult = new MatchResult();
                ((MatchResult)bestResult).setSolutionMatches(solutionList);
                
                //set solution list for next iteration
                solutionHierarc.add(solutionContainer);
                calcTestEnded(solutionSet);

                return !solutionSet.getSolutionMatches().isEmpty();
            }
            
            return false;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "updateSolutions", null, ex);
        }
    }
    
    /**
     * Reset the problem-solving structures for the next run. In this case, check that
     * there are still solutions to process.
     * @param varList a list of variables as key-value pairs. Needs to include the test spec.
     * @return true if all are removed, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean resetForNextRun(HashMap varList) throws Exception
    {
        TestSpec testSpec;                      //test spec
       
        testSpec = (TestSpec)varList.get(SolverConst.TESTOPTIONS);
        firstSolutionsAndProblems(testSpec);        
        
        return solutionsToProcess();
    }
    
    /**
     * Check for conditions that indicate that the test runs have or should be
     * terminated. This also resets the previous solution results that are stored.
     * @param solutionSet the last solution set to evaluate.
     * @throws java.lang.Exception any error.
     */
    protected void calcTestEnded(MatchResult solutionSet) throws Exception
    {
        int i, j, k;
        boolean sameList;                               //true if same list
        String solnName;                                //next solution name
        ArrayList<String> solnNames;                    //solution names
        CompoundSolution compSoln1;                     //compound solution
        CompoundSolution compSoln2;                     //compound solution
        SolutionContainer solutionContainer1;           //compound solutions list
        SolutionContainer solutionContainer2;           //compound solutions list

        testEnded = solutionSet.getSolutionMatches().isEmpty();
        if (!testEnded && (solutionHierarc.size() > 1))
        {
            //if the last 2 solution sets are the same then terminate
            solutionContainer1 = solutionHierarc.get(solutionHierarc.size()-2);
            solutionContainer2 = solutionHierarc.get(solutionHierarc.size()-1);
            
            if ((solutionContainer1.getSolutions().size() > 0) &&
                    (solutionContainer1.getSolutions().size() == solutionContainer2.getSolutions().size()))
            {
                testEnded = true;
                for (i = 0; testEnded && (i < solutionContainer1.getSolutions().size()); i++)
                {
                    sameList = false;
                    compSoln1 = (CompoundSolution)solutionContainer1.getSolutions().get(solutionContainer1.getSolutionNames().get(i));
                    solnNames = compSoln1.getSolutionNames();

                    for (j = 0; !sameList && (j < solutionContainer2.getSolutions().size()); j++)
                    {
                        sameList = true;
                        compSoln2 = (CompoundSolution)solutionContainer2.getSolutions().get(solutionContainer2.getSolutionNames().get(j));

                        for (k = 0; sameList && (k < solnNames.size()); k++)
                        {
                            solnName = solnNames.get(k);
                            sameList = compSoln2.getSolutionNames().contains(solnName);
                        }
                    }

                    testEnded = sameList;
                }
            }
        }
    }
    
    /**
     * Get the results of the test.
     * @return the test results in XML format.
     * @throws java.lang.Exception any error.
     */
    public Element getResultXml() throws Exception
    {
        Element resultElem;                     //result element

        resultElem = XMLFactory.getInstance().createElement(AiConst.TESTRUNS);
        resultElem.setText("Distributed links test ended.");
        return resultElem;
    }
}
