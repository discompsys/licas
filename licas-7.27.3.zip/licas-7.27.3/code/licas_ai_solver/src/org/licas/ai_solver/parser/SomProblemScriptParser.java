/*
 * SomProblemScriptParser.java
 *
 * Created on 27 October 2014.
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.parser;


import org.licas.ai_solver.central.SomConst;
import org.licas.ai_solver.spec.*;
import org.licas.ai_solver.util.SolverConst;
import org.licas.PasswordHandler;
import org.licas.util.Const;
import org.licas_xml.abs.*;

import java.util.*;


/**
 * This class parses a problem script description of type {@link SomProblemScript}, 
 * to or from XML. It should be called indirectly through the {@link ProblemScriptParser} class.
 * @author Kieran Greer
 */
public class SomProblemScriptParser extends ProblemScriptParser
{
    /** 
     * Create a new instance of SomProblemScriptParser.
     * @param thePasswordHandler for storing passwords.
     */
    public SomProblemScriptParser(PasswordHandler thePasswordHandler)    
    {
        super(thePasswordHandler);
    }
    
    
    /**
     * Serialize the test script into XML.
     * @param testScript the test script to serialize. Of type {@link SomProblemScript}.
     * @param forDisplay if true, create output for display purposes only.
     * @return the script in XML format.
     * @throws java.lang.Exception any error. 
     */
    public Element serialize(ProblemScript testScript, boolean forDisplay) 
            throws Exception
    {
        Element nextElem;                       //next element
        Element nextElem2;                      //next element
        Element scriptElem;                     //script element
        SomProblemScript somScript;             //som script
        
        somScript = (SomProblemScript)testScript;
        scriptElem = super.serialize(somScript, forDisplay);        
        if ((scriptElem != null) && (somScript != null))
        {
            //solver configuration options
            nextElem = scriptElem.getChild(SolverConst.SOLVEROPTIONS);
            if (nextElem == null)
            {
                nextElem = XMLFactory.getInstance().createElement(SolverConst.SOLVEROPTIONS);                   
                nextElem.addContent(nextElem);
            }
            
            if (somScript.somConfig.learningFramework != null)
            {
                nextElem2 = XMLFactory.getInstance().createElement(SomConst.LEARNFRAMEWORK);                   
                nextElem2.setText(somScript.somConfig.learningFramework);
                nextElem.addContent(nextElem2);
            }
            if (somScript.somConfig.topology != null)
            {
                nextElem2 = XMLFactory.getInstance().createElement(SomConst.TOPOLOGY);                   
                nextElem2.setText(somScript.somConfig.topology);
                nextElem.addContent(nextElem2);
            }  
            if (somScript.somConfig.topologyRow > 0)
            {
                nextElem2 = XMLFactory.getInstance().createElement(SomConst.TOPOLOGYROW);                   
                nextElem2.setText(String.valueOf(somScript.somConfig.topologyRow));
                nextElem.addContent(nextElem2);
            }
            if (somScript.somConfig.topologyCol > 0)
            {
                nextElem2 = XMLFactory.getInstance().createElement(SomConst.TOPOLOGYCOL);                   
                nextElem2.setText(String.valueOf(somScript.somConfig.topologyCol));
                nextElem.addContent(nextElem2);
            }
            if (somScript.somConfig.topologyRadius >= 0)
            {
                nextElem2 = XMLFactory.getInstance().createElement(SomConst.TOPOLOGYRADIUS);                   
                nextElem2.setText(String.valueOf(somScript.somConfig.topologyRadius));
                nextElem.addContent(nextElem2);
            }
            if (somScript.somConfig.neighbourhoodFunction != null)
            {
                nextElem2 = XMLFactory.getInstance().createElement(SomConst.NEIGHBOURHOODFUNCION);                   
                nextElem2.setText(somScript.somConfig.neighbourhoodFunction);
                nextElem.addContent(nextElem2);
            }
            if (somScript.somConfig.activationFunction != null)
            {
                nextElem2 = XMLFactory.getInstance().createElement(SomConst.ACTIVATIONFUNCION);                   
                nextElem2.setText(somScript.somConfig.activationFunction);
                nextElem.addContent(nextElem2);
            }
            if (somScript.somConfig.weightNumber >= 0)
            {
                nextElem2 = XMLFactory.getInstance().createElement(SomConst.WEIGHTSNUMBER);                   
                nextElem2.setText(String.valueOf(somScript.somConfig.weightNumber));
                nextElem.addContent(nextElem2);
            }
        }
        
        return scriptElem;
    }
    
    /**
     * Parse the file path to create a test script for creating the test scenario from.
     * @param scriptXml the script document in XML format.
     * @return the created test script object.
     * @throws java.lang.Exception any error.
     */
    public SomProblemScript parse(Element scriptXml) throws Exception
    {
        int i;
        String nextValue;                                   //next value
        Vector elemList;                                    //element list
        Node nextNode;                                      //next node
        Element nextElem;                                   //next element
        SomProblemScript testScript;                        //the test script
                        
        testScript = new SomProblemScript(passwordHandler);    
        testScript.copy(super.parse(scriptXml));
        
        if (scriptXml.getName().equals(Const.TESTSCRIPT))
        {
            nextElem = scriptXml.getChild(SolverConst.SOLVEROPTIONS);
            if (nextElem != null)
            {
                elemList = nextElem.getChildren();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);
                    if (nextNode instanceof Element)
                    {
                        nextElem = (Element)nextNode; 
                        if (nextElem.getName().equals(SomConst.LEARNFRAMEWORK))
                        {
                            try {
                                nextValue = nextElem.getText().trim();
                                testScript.somConfig.learningFramework = nextValue;
                            } catch (Exception ex2) {}
                        }
                        else if (nextElem.getName().equals(SomConst.TOPOLOGY))
                        {
                            try {
                                nextValue = nextElem.getText().trim();
                                testScript.somConfig.topology = nextValue;
                            } catch (Exception ex2) {}
                        }
                        else if (nextElem.getName().equals(SomConst.TOPOLOGYROW))
                        {
                            try {
                                nextValue = nextElem.getText().trim();
                                testScript.somConfig.topologyRow = Integer.parseInt(nextValue);
                            } catch (Exception ex2) {}
                        }
                        else if (nextElem.getName().equals(SomConst.TOPOLOGYCOL))
                        {
                            try {
                                nextValue = nextElem.getText().trim();
                                testScript.somConfig.topologyCol = Integer.parseInt(nextValue);
                            } catch (Exception ex2) {}
                        }
                        else if (nextElem.getName().equals(SomConst.TOPOLOGYRADIUS))
                        {
                            try {
                                nextValue = nextElem.getText().trim();
                                testScript.somConfig.topologyRadius = Integer.parseInt(nextValue);
                            } catch (Exception ex2) {}
                        }
                        else if (nextElem.getName().equals(SomConst.NEIGHBOURHOODFUNCION))
                        {
                            try {
                                nextValue = nextElem.getText().trim();
                                testScript.somConfig.neighbourhoodFunction = nextValue;
                            } catch (Exception ex2) {}
                        }
                        else if (nextElem.getName().equals(SomConst.ACTIVATIONFUNCION))
                        {
                            try {
                                nextValue = nextElem.getText().trim();
                                testScript.somConfig.activationFunction = nextValue;
                            } catch (Exception ex2) {}
                        }
                        else if (nextElem.getName().equals(SomConst.WEIGHTSNUMBER))
                        {
                            try {
                                nextValue = nextElem.getText().trim();
                                testScript.somConfig.weightNumber = Integer.parseInt(nextValue);
                            } catch (Exception ex2) {}
                        }
                    }
                }
            }
        }
        
        return testScript;
    }
}
