/*
 * ProblemScriptParser.java
 *
 * Created on 8 June 2011
 *
 * Version 1.7.4
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.parser;


import org.licas.ai_solver.spec.*;
import org.licas.ai_solver.SolverFactory;
import org.licas.ai_solver.util.*;

import org.licas.PasswordHandler;
import org.licas.parsers.BehaviourScriptParser;
import org.licas.util.AiConst;
import org.licas.util.Const;
import org.licas.util.HeuristicConst;
import org.licas_xml.abs.*;
import org.licas_xml.model.*;

import java.io.*;
import java.util.*;


/**
 * This class parses a problem script description of type {@link ProblemScript} or derived
 * classes, to or from XML.
 * @author Kieran Greer
 */
public class ProblemScriptParser 
{
    /** For storing passwords */
    protected PasswordHandler passwordHandler;
    
    /** 
     * Create a new instance of ProblemScriptParser.
     * @param thePasswordHandler for storing passwords.
     */
    public ProblemScriptParser(PasswordHandler thePasswordHandler)    
    {
        passwordHandler = thePasswordHandler;
    }
    
    
    /**
     * Serialize the test script into XML.
     * @param testScript the test script to serialize.
     * @param forDisplay if true, create output for display purposes only.
     * @return the script in XML format.
     * @throws java.lang.Exception any error. 
     */
    public Element serialize(ProblemScript testScript, boolean forDisplay) throws Exception
    {
        Element nextElem;                                   //next element
        Element nextElem2;                                  //next element
        Element scriptElem;                                 //the script element
        BehaviourScriptParser behaviourParser;              //behaviour script parser
        
        if (testScript != null)
        {
            behaviourParser = new BehaviourScriptParser(passwordHandler);
            scriptElem = behaviourParser.serialize(testScript, forDisplay);
            
            if (testScript.solverType != null)
            {
                scriptElem.setAttribute(Const.TYPE, testScript.solverType);
                nextElem = XMLFactory.getInstance().createElement(SolverConst.FRAMEWORK);                   
                nextElem.setText(String.valueOf(testScript.solverType));
                scriptElem.addContent(nextElem);
            }
            else
            {
                scriptElem.setAttribute(Const.TYPE, HeuristicConst.GRIDMATCH);
            }
            
            //solver configuration options
            nextElem = XMLFactory.getInstance().createElement(SolverConst.SOLVEROPTIONS);                   
            scriptElem.addContent(nextElem);
            
            if (testScript.maxSolutionNum >= 0)
            {
                nextElem2 = XMLFactory.getInstance().createElement(SolverConst.MAXSOLUTIONS);                   
                nextElem2.setText(String.valueOf(testScript.maxSolutionNum));
                nextElem.addContent(nextElem2);
            }
            if (testScript.similarityRangeAsPercentage)
            {
                nextElem2 = XMLFactory.getInstance().createElement(SolverConst.RANGETYPE);                   
                nextElem2.setText(SolverConst.PERCENTAGE);
                nextElem.addContent(nextElem2);
            }
            else
            {
                nextElem2 = XMLFactory.getInstance().createElement(SolverConst.RANGETYPE);                   
                nextElem2.setText(SolverConst.ACTUAL);
                nextElem.addContent(nextElem2);
            }
            if (testScript.rangeValue >= 0)
            {
                nextElem2 = XMLFactory.getInstance().createElement(SolverConst.RANGEVALUE);                   
                nextElem2.setText(String.valueOf(testScript.rangeValue));
                nextElem.addContent(nextElem2);
            }
            
            //test run-specific options
            nextElem = XMLFactory.getInstance().createElement(SolverConst.TESTOPTIONS);                   
            scriptElem.addContent(nextElem);

            nextElem2 = XMLFactory.getInstance().createElement(SolverConst.ADDINKS);                   
            nextElem2.setText(String.valueOf(testScript.testRunsScript.addLinks));
            nextElem.addContent(nextElem2);
            
            nextElem2 = XMLFactory.getInstance().createElement(SolverConst.SAMESERVICES);                   
            nextElem2.setText(String.valueOf(testScript.testRunsScript.sameServices));
            nextElem.addContent(nextElem2);   
            
            nextElem2 = XMLFactory.getInstance().createElement(SolverConst.FULLTRACE);                   
            nextElem2.setText(String.valueOf(testScript.testRunsScript.fullTrace));
            nextElem.addContent(nextElem2);   
            
            if (testScript.testRunsScript.testRuns >= 0)
            {
                nextElem = XMLFactory.getInstance().createElement(AiConst.TESTRUNS);
                nextElem.setText(String.valueOf(testScript.testRunsScript.testRuns));
                scriptElem.addContent(nextElem);
            }
           
            return scriptElem;
        }
        
        return null;
    }
    
    /**
     * Parse the file path to create a test script for creating the test scenario from.
     * @param filePath the script file path.
     * @return the created test script object.
     * @throws java.lang.Exception any error.
     */
    public ProblemScript parseFile(String filePath) throws Exception
    {
        String solverType;                              //solver type
        Element scriptXml;                              //document
        FileInputStream reader;                         //reader
        ProblemScriptParser scriptParser;               //script parser
        
        reader = new FileInputStream(filePath);
        scriptXml = XmlHandler.elementFromStream(reader);
        solverType = scriptXml.getAttributeValue(Const.TYPE);
        if (solverType == null) solverType = SolverConst.PROBLEMSCRIPT;
        scriptParser = SolverFactory.getInstance().getSolverSpecs().getProblemScriptParser(solverType);
        
        return scriptParser.parse(scriptXml);
    }
    
    
    /**
     * Parse the file path to create a test script for creating the test scenario from.
     * @param scriptXml the script document in XML format.
     * @return the created test script object.
     * @throws java.lang.Exception any error.
     */
    public ProblemScript parse(Element scriptXml) throws Exception
    {
        int i, j;
        String solverType;                              //solver type
        String nextValue;                               //next value
        Vector elemList;                                //element list
        Vector elemList2;                               //element list
        Node nextNode;                                  //next node
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        ProblemScript testScript;                       //the test script
        BehaviourScriptParser behaviourParser;          //behaviour script parser
        
        testScript = new ProblemScript(passwordHandler);    
        if (scriptXml.getName().equals(Const.TESTSCRIPT))
        {
            solverType = scriptXml.getAttributeValue(Const.TYPE);
            if (solverType == null)
            {
                solverType = SolverConst.PROBLEMSCRIPT;
                testScript = new GridProblemScript(passwordHandler);
            }
            else
            {
                testScript = SolverFactory.getInstance().getSolverSpecs().getProblemScript(solverType);
            }
            
            behaviourParser = new BehaviourScriptParser(passwordHandler);
            testScript.copy(behaviourParser.parse(scriptXml));
            testScript.scriptType = solverType;
        
            elemList = scriptXml.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode; 
                    if (nextElem.getName().equals(SolverConst.FRAMEWORK) ||
                        nextElem.getName().equals(SolverConst.MATCHTYPE))
                    {
                        try {
                            testScript.solverType = SolverFactory.checkHeuristic(nextElem.getText().trim());
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(SolverConst.MAXSOLUTIONS))
                    {
                        try {
                            nextValue = nextElem.getText().trim();
                            testScript.maxSolutionNum = Integer.parseInt(nextValue);
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(SolverConst.RANGETYPE))
                    {
                        try {
                            nextValue = nextElem.getText().trim();
                            testScript.similarityRangeAsPercentage = nextValue.equals(SolverConst.PERCENTAGE);
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(SolverConst.RANGEVALUE))
                    {
                        try {
                            nextValue = nextElem.getText().trim();
                            testScript.rangeValue = Float.parseFloat(nextValue);
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(SolverConst.FULLTRACE))
                    {
                        try {
                            nextValue = nextElem.getText().trim();
                            testScript.testRunsScript.fullTrace = Boolean.valueOf(nextValue).booleanValue();
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(AiConst.TESTRUNS))
                    {
                        try {
                            nextValue = nextElem.getText().trim();
                            testScript.testRunsScript.testRuns = Integer.parseInt(nextValue);
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(SolverConst.SOLVEROPTIONS))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode; 
                                if (nextElem2.getName().equals(SolverConst.MAXSOLUTIONS))
                                {
                                    try {
                                        nextValue = nextElem2.getText().trim();
                                        testScript.maxSolutionNum = Integer.parseInt(nextValue);
                                    } catch (Exception ex2) {}
                                }
                            }
                        }
                    }  
                    else if (nextElem.getName().equals(SolverConst.TESTOPTIONS))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode; 
                                if (nextElem2.getName().equals(SolverConst.SAMESERVICES))
                                {
                                    try {
                                        nextValue = nextElem2.getText().trim();
                                        testScript.testRunsScript.sameServices = Boolean.valueOf(nextValue).booleanValue();
                                    } catch (Exception ex2) {}
                                }
                                else if (nextElem2.getName().equals(SolverConst.FULLTRACE))
                                {
                                    try {
                                        nextValue = nextElem2.getText().trim();
                                        testScript.testRunsScript.fullTrace = Boolean.valueOf(nextValue).booleanValue();
                                    } catch (Exception ex2) {}
                                }
                            }
                        }
                    }
                }
            }
        }
            
        return testScript;
    }
}
