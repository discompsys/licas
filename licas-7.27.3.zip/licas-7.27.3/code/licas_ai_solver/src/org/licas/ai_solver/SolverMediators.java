/*
 * SolverMediators.java
 *
 * Created on 29 January 2016
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.licas.ai_solver.def.TestDef;
import org.licas.ai_solver.eval.*;
import org.licas.ai_solver.mediator.problem.ProblemMediator;

import org.licas.service.*;
import org.licas.PasswordHandler;

import java.util.*;


/**
 * This class describes the methods used by the solver mediators. A copy is stored in the
 * {@link SolverFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public abstract class SolverMediators
{
    /** The default service mediator to return */
    protected ServiceMediator serviceMediator = null;
    
    /** The password handler */
    protected PasswordHandler passwordHandler;
    /** 
     * List of modules automatically loaded in during startup. Of type {@link ModuleSolverFactory}.
     */
    protected static ArrayList<ModuleSolverFactory> solverModules;
    
    
    /**
     * Create a new instance of SolverMediators.
     * @param thePasswordHandler the password handler.
     * @param theSolverModules list of solver modules.
     */
    public SolverMediators(PasswordHandler thePasswordHandler, ArrayList<ModuleSolverFactory> theSolverModules)
    {
        passwordHandler = thePasswordHandler;
        solverModules = theSolverModules;
    }
    
    
    /**
     * Create and return the appropriate service mediator for the problem type. 
     * If one has already been created, return it instead, so the mediator should
     * be created only once.
     * This mediator creates and controls the flow of information between 
     * the services that are run. The default version is {@link SolverMediators}.
     * @param solverType the type of test framework to solve the problem.
     * @return the appropriate service mediator for solving the problem.
     * @throws java.lang.Exception any error.
     */
    public abstract ServiceMediator createServiceMediator(String solverType) throws Exception;

    /**
     * Create and return the appropriate test mediator to execute the services in the framework. 
     * @param solverType the type of test framework to solve the problem.
     * @param serviceType the type of services that are created.
     * @return the appropriate {@link TestDef} class to run and execute the script in
     * the test loop.
     * @throws java.lang.Exception any error.
     */
    public abstract TestDef getTestMediator(String solverType, String serviceType) 
            throws Exception;

    /**
     * Create and return the appropriate mediator for the current problem type.
     * @param solverType the type of test framework to solve the problem.
     * @param heuristicType the heuristic or problem-solving type.
     * @return the appropriate evaluation mediator for solving the problem.
     */
    public abstract Evaluator getSolverFrameworkMediator(String solverType, 
            String heuristicType);
    
    /**
     * Get the problem mediator object related to the current problem type.
     * @param solverType the type of test framework to solve the problem.
     * @param heuristicType the heuristic or problem-solving type, for example, {@code simpleHeuristicType},
     * {@code HeuristicConst}.{@code TEXTGENETIC}.
     * @return the related problem specification object.
     */
    public abstract ProblemMediator getProblemMediator(String solverType, String heuristicType);
    
    
    /**
     * Set the service mediator.
     * @param theServiceMediator the service mediator.
     */
    public void setServiceMediator(ServiceMediator theServiceMediator)
    {
        serviceMediator = theServiceMediator;
    }
    
    /**
     * Get the currently created service mediator.
     * @return the value of serviceMediator.
     */
    public ServiceMediator getServiceMediator()
    {
        return serviceMediator;
    }
}
