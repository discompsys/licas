/*
 * KnnConfig.java
 *
 * Created on 2 March 2016
 *
 * Version 1.1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.central;


import org.licas.util.TypeConst;
import org.ai_heuristic.data.LearningDataModel;
import org.ai_heuristic.eval.metric.*;

import java.util.*;


/**
 * This class stores some config values to allow a knn to be built and run.
 * The dataset values are currently of type double only.
 * @author Kieran Greer
 */
public class KnnConfig
{
    /** Maximum number of training iterations */
    public int iterations;
    
    /** Number of nearest neighbours */
    public int k;
    
    /** Size of tree container bucket */
    public int bucketSize;
    
    /** Data type */
    public String dataType;
    
    /** Evaluation Metric */
    public String metric;
    
    /** The data to train the neural network with */
    public LearningDataModel knnData;
        
    
    /** Create a new instance of KnnConfig */
    public KnnConfig()
    {
        iterations = 0;
        k = 0;
        bucketSize = 0;
        dataType = null;
        metric = null;
        knnData = null;
    }
    
    /**
     * Convert the stored data points, of type Double, into a {@code MetricDataset} and return.
     * @return the converted dataset.
     * @throws java.lang.Exception any error.
     */
    public MetricDataset dataToDataset() throws Exception
    {
        int i;
        ArrayList<MetricValue> dataList;            //dataset list
        MetricValue metricValue;                    //metric value
        MetricDataset dataset;                      //the dataset
        
        dataList = new ArrayList<>();
        for (i = 0; i < knnData.getDataSize(); i++)
        {
            metricValue = MetricValue.toValue(knnData.getDataKey(i), TypeConst.DOUBLE, knnData.getData(i));
            dataList.add(metricValue);
        }
        
        dataset = MetricDataset.toDataset("knn", TypeConst.DOUBLE, dataList);
        return dataset;
    }
    
    /**
     * Copy the values of this config and return.
     * @return a light clone copy of this object.
     */
    public Object clone()
    {
        KnnConfig knnConfig;                        //copy of the config
        
        knnConfig = new KnnConfig();        
        knnConfig.iterations = iterations;
        knnConfig.k = k;                
        knnConfig.bucketSize = bucketSize;                
        knnConfig.dataType = dataType;
        knnConfig.metric = metric;
        knnConfig.knnData = knnData;
           
        return knnConfig;
    }
}
