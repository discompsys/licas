/*
 * KnnProblemMediator.java
 *
 * Created on 2 March 2016
 *
 * Version 1.3
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.mediator.problem;


import org.licas.ai_solver.model.result.Result;
import org.licas.ai_solver.SolverFactory;
import org.licas.ai_solver.central.*;
import org.licas.ai_solver.spec.*;
import org.licas.ai_solver.mediator.ProblemSolverMediator;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.util.*;

import org.licas.server.LocalServer;
import org.licas.PasswordHandler;
import org.licas.util.*;
import org.ai_heuristic.data.LearningData;
import org.ai_heuristic.eval.metric.MetricDataset;
import org.licas_xml.abs.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;

import java.util.*;


/**
 * This class models the problem to be solved based on a centralised K-Nearest Neighbour.
 * This version receives a single input dataset that it then clusters, without solution updates. 
 * It receives its dataset from a single service and suggests links through optimising using the knn algorithm.
 * @author Kieran Greer
 */
public class KnnProblemMediator extends ProblemMediatorCentral
{
    /** For logging errors */
    private static final Logger logger;

    
    /** Configuration values specific to the knn */
    protected KnnConfig knnConfig;
    
    /** The K-Nearest Neighbour algorithm */
    protected KNN knn;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(KnnProblemMediator.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of KnnProblemMediator.
     * @param thePasswordHandler for storing passwords.
     */
    public KnnProblemMediator(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        knnConfig = new KnnConfig();
        knn = new KNN();
    }
    
    /**
     * Copy any related values to the knn config structure.
     * @param testSpec the model of the tests to perform.
     * @throws java.lang.Exception any error.
     */
    public void copyToConfig(TestSpec testSpec) throws Exception
    {
        KnnProblemScript testScript;                //test script
        
        super.copyToConfig(testSpec);
        testScript = (KnnProblemScript)testSpec.getTestScript();
        solverType = testScript.solverType;
        
        knnConfig = (KnnConfig)testScript.knnConfig.clone();       
        knnConfig.dataType = TypeConst.DOUBLE;
        knnConfig.iterations = testScript.testRunsScript.testRuns;
        knnConfig.metric = testScript.metricType;
    }
    
    /**
     * Optimise the solutions using the appropriate framework.
     * @param testSpec the model of the tests to perform.
     * @return groups of solutions from the latest optimisation phase. In this
     * case null is returned, because all communications are distributed and local,
     * where the services do not return anything anywhere else.
     * @throws java.lang.Exception any error.
     */
    public Result solve(TestSpec testSpec) throws Exception 
    {
        ProblemSolverMediator solverMediator;       //solver mediator
        
        try
        { 
            //retrieve the dataset values and initialise the knn
            solverMediator = (ProblemSolverMediator)SolverFactory.getInstance().getSolverMediators().createServiceMediator(solverType);
            serviceNames = solverMediator.getServiceNames();
            
            //create the problems with the data
            if (LocalServer.isRunning()) {
                dataHash = solverMediator.getServicesData(testSpec);
                createKnnData(testSpec, ",");
            }
            else {
                //can be central file-only test with no server or services
                dataHash = new LinkedHashMap<>();
                createKnnData(testSpec, ",");
            }

            //run tests on the neural network
            knn.initialiseKnn(knnConfig);
            result = knn.runTest();
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "solve", null, ex);
        }
        finally {
            //for linking services, the test number is used as the number of
            //datasets or distributed services to compare with and this is carried
            //out during one test iteration, so always end after one iteration
            testEnded = true;
        }
        
        //the same for knn
        bestResult = result;
        
        return result;
    }
    
    /**
     * Reset the problem-solving structures for the next run. In this case, remove
     * the named solutions from the list of current ones.
     * @param varList a list of variables as key-value pairs. Can be null in this case.
     * @return true if all are removed, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean resetForNextRun(HashMap<String, ?> varList) throws Exception
    { return true; }
    
    /**
     * Create a new knn with the problem datasets. Can be read from a file or retrieved from
     * the distributed services. Single file assumes a single service with a file path 
     * content for a dataset to load. Also assumes CSV {@code ','}-style separator in the file.
     * @param testSpec the model of the tests to perform.
     * @param separator the tokenizer character.
     * @throws java.lang.Exception any error.
     */
    protected void createKnnData(TestSpec testSpec, String separator) throws Exception
    {
        int i;
        String filePath;                                //dataset file path
        ArrayList<MetricDataset> datasets;              //list of datasets
        ArrayList<HashMap<String, Object>> knnDataset;  //knn dataset
        HashMap<String, Object> knnDataValue;           //knn data values
        Element dataElem;                               //data element
        Element valueElem;                              //value element
        MetricDataset metricDataset;                    //metric dataset
        LearningData knnData;                           //knn dataset
        
        filePath = null;
        
        //if only 1 data entry, then maybe a file path to read, so try that first
        if (dataHash.size() == 1) {
            //look for URL address
            try {
                dataElem = (Element)dataHash.values().iterator().next();
                valueElem = dataElem.getChild(Const.VALUE);

                if (valueElem != null) {
                    filePath = valueElem.getText();
                    filePath = UriHandler.removeLocalFileUriPrefix(filePath);
                }
            }
            catch (Exception fex) {}
        }
        
        //add to config
        if (filePath != null) {
            knnData = new LearningData(filePath, separator);
        }
        else {
            //data entries are the actual value sets so convert to knn format
            datasets = getProblemsList(testSpec);
            
            knnDataset = new ArrayList();
            for (i = 0; i < datasets.size(); i++)
            {
                metricDataset = datasets.get(i);
                knnDataValue = new HashMap<>();
                knnDataset.add(knnDataValue);
                
                //should in fact be only 1 entry, for the data row
                metricDataset.resetValueIterator();
                knnDataValue.put(metricDataset.getName(), metricDataset.getFirstValue());
            }
            
            knnData = new LearningData(knnDataset);
        }
        
        knnConfig.knnData = knnData;
    }
    
    /**
     * Get the results of the test.
     * @return the test results in XML format.
     * @throws java.lang.Exception any error.
     */
    public Element getResultXml() throws Exception
    {
        Element resultElem;                         //result element

        resultElem = XMLFactory.getInstance().createElement(SolverConst.BESTSOLUTIONSET);
        resultElem.setText(ResultFormatter.convertToString(result));
        return resultElem;
    }
}
