/*
 * EvolveGenesBOW.java
 *
 * Created on 8 April 2011
 *
 * Version 1.2.4
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.model.genetic.genes;


import org.licas.ai_solver.SolverFactory;
import org.licas.ai_solver.eval.EvaluateSolverData;

import org.licas.data.DataQueryModel;
import org.ai_heuristic.eval.metric.MetricValue;
import org.ai_heuristic.util.AiHeuristicConst;

import java.util.*;


/**
 * This implementation can be used for mutating {@code BagOfWords} bag-of-words 
 * constructs through intersection and union operations.
 * @author Kieran Greer
 */
public class EvolveGenesBOW extends EvolveGenes
{
    /**
     * Create a new instance of EvolveGenesBOW.
     * @param thisGeneType the type of gene as the object classname.
     * @param thisEvolveTypes the different ways that a crossover or mutation can be performed.
     */
    public EvolveGenesBOW(String thisGeneType, ArrayList<String> thisEvolveTypes)
    {
        super(thisGeneType, thisEvolveTypes);
    }

    /**
     * Return true if the two sets of genes are the same.
     * This is the first element in each list.
     * @param geneList1 the first list of consider.
     * @param geneList2 the second list to consider.
     * @return true if the genes are the same.
     * @throws java.lang.Exception any error.
     */
    public boolean areSame(ArrayList<?> geneList1, ArrayList<?> geneList2) throws Exception
    {
        Object gene1;                           //first gene
        Object gene2;                           //second gene
        DataQueryModel dataInfo;                      //stores evaluator parameters
        EvaluateSolverData eval;                //evaluation service
        
        dataInfo = new DataQueryModel();
        dataInfo.setDataType(geneType);               
        eval = SolverFactory.getInstance().getSolverData().getEvaluateData(dataInfo);
        
        gene1 = geneList1.get(0);
        if (gene1 instanceof MetricValue) gene1 = ((MetricValue)gene1).getValue();       
        gene2 = geneList2.get(0);
        if (gene2 instanceof MetricValue) gene2 = ((MetricValue)gene2).getValue(); 
        
        return eval.mathCompare(geneType, gene1, gene2, AiHeuristicConst.EQ); 
    }
    
    /**
     * Generate a crossover between this gene list and the variable passed in.
     * This is the intersection of the first element in each list by default.
     * @param geneList1 the first list of consider.
     * @param geneList2 the second list to consider.
     * @return the result of the crossover. Can return null.
     * @throws java.lang.Exception any error.
     */
    protected ArrayList<?> crossover(ArrayList<?> geneList1, ArrayList<?> geneList2) throws Exception
    {
        boolean usesMetricValue;                //true if uses metric value
        ArrayList combinedGenes;                   //combined gene sequence
        Object gene1;                           //first gene
        Object gene2;                           //second gene
        Object newGene;                         //new gene
        DataQueryModel dataInfo;                      //stores evaluator parameters
        EvaluateSolverData eval;                //evaluation service
        MetricValue metricValue;                //metric value
        
        usesMetricValue = false;
        combinedGenes = new ArrayList();
        
        dataInfo = new DataQueryModel();
        dataInfo.setDataType(geneType);               
        eval = SolverFactory.getInstance().getSolverData().getEvaluateData(dataInfo);
        
        gene1 = geneList1.get(0);
        if (gene1 instanceof MetricValue) {
            gene1 = ((MetricValue)gene1).getValue();
            usesMetricValue = true;
        }
        
        gene2 = geneList2.get(0);
        if (gene2 instanceof MetricValue) gene2 = ((MetricValue)gene2).getValue();      
        newGene = eval.mathOperation(geneType, gene1, gene2, AiHeuristicConst.INTERSECTION);       
        
        if (usesMetricValue) {
            metricValue = MetricValue.toValue(((MetricValue)geneList1.get(0)).getName(),
                ((MetricValue)geneList1.get(0)).getValueType(), newGene);
            
            newGene = metricValue;
        }
        
        combinedGenes.add(newGene);
        return combinedGenes;
    }

    /**
     * Generate a mutation between this gene list and the variable passed in.
     * This is the union of the first element in each list by default.
     * @param geneList1 the first list of consider.
     * @param geneList2 the second list to consider.
     * @return the result of the mutation. Can return null.
     * @throws java.lang.Exception any error.
     */
    protected ArrayList<?> mutate(ArrayList<?> geneList1, ArrayList<?> geneList2) throws Exception
    {
        boolean usesMetricValue;                //true if uses metric value
        ArrayList combinedGenes;                //combined gene sequence
        Object gene1;                           //first gene
        Object gene2;                           //second gene
        Object newGene;                         //new gene
        DataQueryModel dataInfo;                //stores evaluator parameters
        EvaluateSolverData eval;                //evaluation service
        MetricValue metricValue;                //metric value
        
        usesMetricValue = false;
        combinedGenes = new ArrayList();
        
        dataInfo = new DataQueryModel();
        dataInfo.setDataType(geneType);               
        eval = SolverFactory.getInstance().getSolverData().getEvaluateData(dataInfo);
        
        gene1 = geneList1.get(0);
        if (gene1 instanceof MetricValue) {
            gene1 = ((MetricValue)gene1).getValue();
            usesMetricValue = true;
        }
        
        gene2 = geneList2.get(0);
        if (gene2 instanceof MetricValue) gene2 = ((MetricValue)gene2).getValue();        
        newGene = eval.mathOperation(geneType, gene1, gene2, AiHeuristicConst.UNION); 
        
        if (usesMetricValue) {
            metricValue = MetricValue.toValue(((MetricValue)geneList1.get(0)).getName(),
                ((MetricValue)geneList1.get(0)).getValueType(), newGene);
            
            newGene = metricValue;
        }
                
        combinedGenes.add(newGene);
        return combinedGenes;
    }
}
