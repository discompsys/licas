/*
 * DefaultSolverData.java
 *
 * Created on 29 January 2016
 *
 * Version 1.0.3
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.licas.ai_solver.eval.*;
import org.licas.ai_solver.stat.ProcessResult;
import org.licas.data.DataQueryModel;

import java.util.*;
import org.ai_heuristic.util.TextConst;
import org.licas.ai_solver.stat.ClusterStats;
import org.licas.util.HeuristicConst;
import org.licas.util.TypeConst;


/**
 * This class describes the methods used by the solver data. A copy is stored in the
 * {@link DefaultSolverFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public class DefaultSolverData extends SolverData
{
    /**
     * Create a new instance of DefaultSolverData.
     * @param theSolverModules list of solver modules.
     */
    public DefaultSolverData(ArrayList theSolverModules)
    {
        super(theSolverModules);
    }
    
    
    /**
     * Create and return the correct data evaluator.
     * @param dataInfo a full info description for the evaluator to be created.
     * Must include the dataset type at least.
     * @return the appropriate object to evaluate the values directly.
     * @throws java.lang.Exception any error.
     */
    public EvaluateSolverData getEvaluateData(DataQueryModel dataInfo) throws Exception
    {
        int i;
        EvaluateSolverData evalService;             //to evaluate data values
        ModuleSolverFactory moduleFactory;          //module factory
        
        evalService = null;
        if (TypeConst.isSimpleType(dataInfo.getDataType()) ||
                dataInfo.getDataType().equalsIgnoreCase(TextConst.BAGOFWORDS) ||
                dataInfo.getDataType().equalsIgnoreCase(TextConst.METABAGOFWORDS)) {
            evalService = new EvaluateSolverData(dataInfo);
        }
        
        if (evalService == null) {
            //add from the modules
            for (i = 0; (evalService == null) && (i < solverModules.size()); i++)
            {
                moduleFactory = solverModules.get(i);
                if (moduleFactory.hasSolverData()) {
                    evalService = moduleFactory.getSolverData().getEvaluateData(dataInfo);
                }
            }
        }
        
        return evalService;
    }
    
    
    
    /**
     * Get the object used to process the solver result, maybe to create lists of links.
     * @param solverType the type of test framework to solve the problem.
     * @return the result processor.
     */
    public ProcessResult getProcessResult(String solverType)
    {
        int i;
        ProcessResult processResult;                //the result
        ModuleSolverFactory moduleFactory;          //module factory
        
        processResult = null;
        if (solverType.equals(HeuristicConst.GRIDHILL) ||
            solverType.equals(HeuristicConst.GRIDMATCH)) {
            processResult = new ClusterStats();
        }
        else if (solverType.equals(HeuristicConst.SEARCHHILL) ||
            solverType.equals(HeuristicConst.LINKDISTRIBUTED) ||
            solverType.equals(HeuristicConst.NEARESTNEIGHBOUR) ||
            solverType.equals(HeuristicConst.SOMNN)) {
            processResult = new ProcessResult();
        }
        
        if (processResult == null) {
            //add from the modules
            for (i = 0; (processResult == null) && (i < solverModules.size()); i++)
            {
                moduleFactory = solverModules.get(i);
                if (moduleFactory.hasSolverData()) {
                    processResult = moduleFactory.getSolverData().getProcessResult(solverType);
                }
            }
        }
        
        return processResult;
    }
    
    /** Variables and and Types settings for each heuristic type below this comment */
    
    /**
     * Get a list of available data types for a heuristic type.
     * @param heuristicType the heuristic type, or a data type.
     * @return the list of allowed data types.
     */
    public ArrayList<String> getDatasetTypes(String heuristicType)
    {
        int i;
        ArrayList<String> typeList;                 //list of types
        ArrayList<String> nextTypeList;             //list of types
        ModuleSolverFactory moduleFactory;          //module factory
        
        typeList = new ArrayList<>();
        if (heuristicType != null) {
            if (heuristicType.equals(HeuristicConst.INTEGERTYPE)) {
                typeList.add(Integer.class.getName());
            }
            else if (heuristicType.equals(HeuristicConst.FLOATTYPE)) {
                typeList.add(Float.class.getName());
            }
            else if (heuristicType.equals(HeuristicConst.STRINGTYPE)) {
                typeList.add(String.class.getName());
            }
            else if (heuristicType.equals(HeuristicConst.BAGOFWORDSTYPE)) {
                typeList.add(TextConst.BAGOFWORDS);
                typeList.add(TextConst.METABAGOFWORDS);
            }
            else if (heuristicType.equals(TypeConst.URI) ||
                    heuristicType.equals(TypeConst.URL)) {
                typeList.add(TypeConst.URL);
            }
            else if (heuristicType.equals(HeuristicConst.CONTAINSLINK) ||
                    heuristicType.equals(HeuristicConst.COMPLETELINK) ||
                    heuristicType.equals(HeuristicConst.SINGLELINK)) {
                typeList.add(Integer.class.getName());
                typeList.add(Float.class.getName());
                typeList.add(String.class.getName());
                typeList.add(TextConst.BAGOFWORDS);
                typeList.add(TextConst.METABAGOFWORDS);
            }
        }

        //add from the modules
        for (i = 0; i < solverModules.size(); i++)
        {
            moduleFactory = solverModules.get(i);
            if (moduleFactory.hasSolverData()) {
                nextTypeList = moduleFactory.getSolverData().getDatasetTypes(heuristicType);

                if (nextTypeList != null) {
                    typeList.addAll(nextTypeList);
                }
            }
        }
        
        return typeList;
    }
    
    /**
     * Get the object classname from the type name, for the known data object types.
     * @param datasetType the dataset type name.
     * @return the object classname. If not recognised, return {@code datasetType}.
     */
    public String dataClassFromType(String datasetType)
    {
        int i;
        String className;                               //the classname
        ModuleSolverFactory moduleFactory;              //module factory
        
        className = null;
        if (datasetType != null) {
            if (datasetType.equals(HeuristicConst.BAGOFWORDSTYPE)) {
                className = TextConst.BAGOFWORDS;
            }
            else if (datasetType.equals(HeuristicConst.METABAGOFWORDSTYPE)) {
                className = TextConst.METABAGOFWORDS;
            }
            else if (datasetType.equals(HeuristicConst.STRINGTYPE)) {
                className = String.class.getName();
            }
            else if (datasetType.equals(HeuristicConst.INTEGERTYPE)) {
                className = Integer.class.getName();
            }
            else if (datasetType.equals(HeuristicConst.FLOATTYPE)) {
                className = Float.class.getName();
            }
            else if (datasetType.equals(TypeConst.URI) ||
                    datasetType.equals(TypeConst.URL)) {
                className = TypeConst.URL;
            }
        }
        
        if (className == null)
        {
            //add from the modules
            for (i = 0; (className == null) && (i < solverModules.size()); i++)
            {
                moduleFactory = solverModules.get(i);
                if (moduleFactory.hasSolverData()) {
                    className = moduleFactory.getSolverData().dataClassFromType(datasetType);
                }
            }
        }
        
        if (className == null) className = datasetType;
        return className;
    }
    
    /**
     * Get the data type name, for the known data classname.
     * @param datasetType the dataset type classname.
     * @return the object type name. If not recognised, return {@code datasetType}.
     */
    public String dataTypeFromClass(String datasetType)
    {
        int i;
        String className;                               //the classname
        ModuleSolverFactory moduleFactory;              //module factory
        
        className = null;
        if (datasetType != null) {
            if (datasetType.equals(TextConst.BAGOFWORDS)) {
                return HeuristicConst.BAGOFWORDSTYPE;
            }
            else if (datasetType.equals(TextConst.METABAGOFWORDS)) {
                return HeuristicConst.METABAGOFWORDSTYPE;
            }
            else if (datasetType.equals(String.class.getName())) {
                return HeuristicConst.STRINGTYPE;
            }
            else if (datasetType.equals(Integer.class.getName())) {
                return HeuristicConst.INTEGERTYPE;
            }
            else if (datasetType.equals(Float.class.getName())) {
                return HeuristicConst.FLOATTYPE;
            }
            else if (datasetType.equals(TypeConst.URL)) {
                return TypeConst.URI;
            }
        }
        
        if (className == null) {
            //add from the modules
            for (i = 0; (className == null) && (i < solverModules.size()); i++)
            {
                moduleFactory = (ModuleSolverFactory)solverModules.get(i);
                if (moduleFactory.hasSolverData()) {
                    className = moduleFactory.getSolverData().dataTypeFromClass(datasetType);
                }
            }
        }
        
        if (className == null) className = datasetType;
        return className;
    }
}
