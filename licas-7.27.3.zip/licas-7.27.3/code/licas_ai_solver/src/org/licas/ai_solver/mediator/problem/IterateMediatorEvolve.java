/*
 * IterateMediatorEvolve.java
 *
 * Created on 7 January 2021
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.mediator.problem;


import org.ai_heuristic.eval.metric.MetricDataset;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.PasswordHandler;
import org.licas.ai_solver.def.EvolveMediatorDef;
import org.licas.ai_solver.model.Solution;
import org.licas.ai_solver.model.SolutionContainer;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.util.NameHandler;
import org.licas.ai_solver.util.SolverConst;

import java.util.*;


/**
 * This is the abstract base class for modelling a solver that evolves new solutions.
 * @author Kieran Greer
 */
public abstract class IterateMediatorEvolve extends IterateMediatorCentral implements EvolveMediatorDef
{
    /** For logging errors */
    private static final Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(IterateMediatorEvolve.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of IterateProblemMediator.
     * @param thePasswordHandler for storing passwords.
     */
    public IterateMediatorEvolve(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {}

    /**
     * Generate a number of initial problem solutions based on the test spec. Typically,
     * the solution name, solution type and a list of problem datasets to initialise each
     * solution with are supplied as parameters in the test spec.
     * @param testSpec the test specification.
     * @throws java.lang.Exception any error.
     */
    public void firstSolutionsAndProblems(TestSpec testSpec) throws Exception
    {
        int i;
        int numberOfSolutions;                          //number of solutions
        String solutionName;                            //solution name
        String solutionType;                            //solution type
        Iterator<String> solutionNames;                 //list of solution names
        ArrayList<MetricDataset> problemsList;          //list of problems
        LinkedHashMap<String, Solution> newSolutions;   //list of new solutions
        MetricDataset problemDataset;                   //the problem dataset
        Solution solution;                              //new solution that is created
        SolutionContainer compoundSolution;              //compound solution

        try {
            newSolutions = new LinkedHashMap<>();
            solutionType = testSpec.getTestScript().metricType;
            solutionHierarc.clear();

            //test for locally stored problem datasets
            problemsList = getProblemsList(testSpec);

            //generate the problem solutions
            //if datasets specified then one solution per dataset, otherwise
            //generate random data for the number specified
            numberOfSolutions = problemsList.size();
            if (numberOfSolutions > 0) {
                for (i = 0; i < numberOfSolutions; i++)
                {
                    problemDataset = problemsList.get(i);
                    solutionName = NameHandler.checkforName(problemDataset);

                    if (solutionName == null) {
                        solutionName = (heuristicType + String.valueOf(i));
                        problemDataset.setName(solutionName);
                    }

                    solution = createNewSolution(solutionType, problemDataset);
                    newSolutions.put(solution.getName(), solution);
                }

                //add solutions to compound solution in any order, before problem solving,
                //this is then reordered to be in sync with the problem dataset order
                solutionName = (heuristicType + "_" + SolverConst.COMPOUNDSOLUTION);
                compoundSolution = new SolutionContainer(solutionName);

                solutionNames = newSolutions.keySet().iterator();
                while (solutionNames.hasNext())
                {
                    solutionName = solutionNames.next();
                    compoundSolution.addSolution(newSolutions.get(solutionName));
                }

                solutionHierarc.add(compoundSolution);
                solutionSet = newSolutions;
            }
            else {
                testEnded = true;
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "createSolutionsAndProblems", null, ex);
        }
        finally {
            //reset problems list to empty if retrieved from a network
        }
    }
}
