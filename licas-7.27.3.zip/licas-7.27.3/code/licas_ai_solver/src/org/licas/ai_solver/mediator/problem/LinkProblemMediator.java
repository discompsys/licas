/*
 * LinkProblemMediator.java
 *
 * Created on 22 October 2013
 *
 * Version 1.2.5
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.mediator.problem;


import org.licas.ai_solver.model.result.Result;
import org.licas.ai_solver.SolverFactory;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.util.*;

import org.licas.call.*;
import org.licas.PasswordHandler;
import org.licas.util.*;

import org.licas_xml.abs.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;

import java.util.*;
import java.util.concurrent.*;

import org.licas.MessageInfo;
import org.licas.ai_solver.model.result.Cluster;
import org.licas.ai_solver.model.result.ClusterResult;
import org.licas.server.LocalServer;
import org.licas_xml.model.XmlHandler;


/**
 * This class models the problem to be solved based on distributed services with
 * linking mechanisms.
 * @author Kieran Greer
 */
public class LinkProblemMediator extends ProblemMediatorDistributed
{
    /** For logging errors */
    private static final Logger logger;

    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(LinkProblemMediator.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of LinkProblemMediator.
     * @param thePasswordHandler for storing passwords.
     */
    public LinkProblemMediator(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {}
    
    /**
     * Optimise the solutions using the appropriate framework.
     * @param testSpec the model of the tests to perform.
     * @return clusters of solutions or references from the latest optimisation phase.
     * Each service is asked for its links and this is returned as the clustering.
     * @throws java.lang.Exception any error.
     */
    public Result solve(TestSpec testSpec) throws Exception 
    {
        int i;
        String serviceUuid;                             //service uuid
        ArrayList<String> serviceTypes;                 //service types
        HashMap<String, Object> parameters;             //parameters list
        Element serviceUri;                             //the service uri
        Element serverUri;                              //the server uri
        Callable<ClusterResult> callableTask;           //callable method
        ScheduledExecutorService scheduler;             //thread scheduler
        MessageInfo messageInfo;                        //message info
        MethodInfo methodInfo;                          //method info
        CallObject callObject;                          //call object
        
        try
        {        
            callObject = new CallObject();
            serverUri = Handle.createNewServerHandle(testSpec.getTestScript().serverSpec.serverAddress);
            serverSpec.password = testSpec.getTestScript().serverSpec.password;
            serviceTypes = new ArrayList<>();
            serviceTypes.add(testSpec.getTestScript().serviceType);
            
            parameters = new HashMap<>();
            parameters.put(Const.DATASETTYPE, SolverFactory.getInstance().getSolverData().dataClassFromType(testSpec.getTestScript().datasetType));
            parameters.put(AiConst.TESTRUNS, new Integer(testSpec.getTestScript().testRunsScript.testRuns));
            messageInfo = new MessageInfo(parameters);
            
            //retrieve all service ids
            methodInfo = new MethodInfo();
            methodInfo.setName(MethodConst.GETSERVICENAMES);
            methodInfo.setRtnType(TypeConst.ARRAYLIST);
            methodInfo.setServiceURI(serverUri);
            methodInfo.setServerPassword(serverSpec.password);
            methodInfo.setPassword(serverSpec.password);
            methodInfo.addParam(serviceTypes);
            serviceNames = (ArrayList)callObject.call(methodInfo);
            
            if ((serviceNames != null) && !serviceNames.isEmpty()) {
                for (i = 0; i < serviceNames.size(); i++)
                {
                    serviceUuid = serviceNames.get(i);
                    serviceUri = Handle.createNewUrlHandle(testSpec.getTestScript().serverSpec.serverAddress);
                    serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceUuid));

                    methodInfo = new MethodInfo();
                    methodInfo.setName(MethodConst.INVOKEBEHAVIOUR);
                    methodInfo.setRtnType(TypeConst.OBJECT);
                    methodInfo.setServiceURI(serviceUri);
                    methodInfo.setServerPassword(serverSpec.passwordHandler.getServicePassword(serverUri));
                    methodInfo.setPassword(serverSpec.passwordHandler.getServicePassword(serviceUri));
                    methodInfo.addParam(messageInfo);
                    callObject.call(methodInfo);
                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "solve", null, ex);
        }
        finally {
            //for linking services, the test number is used as the number of
            //datasets or distributed services to compare with and this is carried
            //out during one test iteration, so always end after one iteration
            testEnded = true;
        }
        
        //need to ask each service in turn who it is clustered with as the result 
        //let all services run first, as is practical
        scheduler = Executors.newSingleThreadScheduledExecutor();
        callableTask = new Callable() {
            @Override
            public ClusterResult call() throws Exception {
                return toClusters(testSpec);
            }
        };

        Future future = scheduler.schedule(callableTask, ServiceConst.MESSAGESLEEP, TimeUnit.MILLISECONDS);
        result = (ClusterResult) future.get();

        return result;
    }
    
    /**
     * Reset the problem-solving structures for the next run. In this case, remove
     * the named solutions from the list of current ones.
     * @param varList a list of variables as key-value pairs. Should include the service type.
     * @return true if all are removed, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean resetForNextRun(HashMap varList) throws Exception
    {
        int i;
        String serviceUuid;                             //service uuid
        ArrayList<String> serviceTypes;                 //service types
        Element serviceUri;                             //the service uri
        Element serverUri;                              //the server uri
        MethodInfo methodInfo;                          //method info
        CallObject callObject;                          //call object
        
        try
        {        
            callObject = new CallObject();
            serviceTypes = (ArrayList)varList.get(Const.SERVICETYPE);
            serverSpec.serverAddress = LocalServer.getServerURL();
            serverUri = Handle.createNewServerHandle(LocalServer.getServerURL());
            serverSpec.password = serverSpec.passwordHandler.getServicePassword(serverUri);
            
            //retrieve all service ids
            methodInfo = new MethodInfo();
            methodInfo.setName(MethodConst.GETSERVICENAMES);
            methodInfo.setRtnType(TypeConst.ARRAYLIST);
            methodInfo.setServiceURI(serverUri);
            methodInfo.setServerPassword(serverSpec.password);
            methodInfo.setPassword(serverSpec.password);
            methodInfo.addParam(serviceTypes);
            serviceNames = (ArrayList)callObject.call(methodInfo);
            
            if ((serviceNames != null) && !serviceNames.isEmpty()) {
                for (i = 0; i < serviceNames.size(); i++)
                {
                    serviceUuid = serviceNames.get(i);
                    serviceUri = Handle.createNewUrlHandle(serverSpec.serverAddress);
                    serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceUuid));

                    methodInfo = new MethodInfo();
                    methodInfo.setName("resetValues");
                    methodInfo.setRtnType(TypeConst.VOID);
                    methodInfo.setServiceURI(serviceUri);
                    methodInfo.setServerPassword(serverSpec.passwordHandler.getServicePassword(serverUri));
                    methodInfo.setPassword(serverSpec.passwordHandler.getServicePassword(serviceUri));
                    callObject.call(methodInfo);
                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "resetForNextRun", null, ex);
        }
        
        return true;
    }
    
    /**
     * Ask each service in turn who it is clustered with.
     * @param testSpec the model of the tests to perform.
     * @return list of clusters for the services.
     * @throws java.lang.Exception any error.
     */
    protected ClusterResult toClusters(TestSpec testSpec) throws Exception
    {
        int i;
        String serviceUuid;                     //service uuid
        ArrayList serviceLinks;                    //list of services linked to
        Element serviceUri;                     //the service uri
        Element serverUri;                      //the server uri
        Element linksXml;                       //permanent links
        Cluster cluster;                        //next cluster
        ClusterResult cResult;                  //cluster result
        MethodInfo methodInfo;                  //method info
        CallObject callObject;                  //call object
        
        callObject = new CallObject();
        serverUri = Handle.createNewServerHandle(testSpec.getTestScript().serverSpec.serverAddress);       
        cResult = new ClusterResult();
        
        //get the dynamic links for each service - link level only
        if ((serviceNames != null) && !serviceNames.isEmpty())
        {
            for (i = 0; i < serviceNames.size(); i++)
            {
                serviceUuid = (String)serviceNames.get(i);
                serviceUri = Handle.createNewUrlHandle(testSpec.getTestScript().serverSpec.serverAddress);
                serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceUuid));

                //get permanent links list, but also add own service uri
                methodInfo = new MethodInfo();
                methodInfo.setName(MethodConst.PERMANENTLINKSTOXML);
                methodInfo.setRtnType(TypeConst.ELEMENT);
                methodInfo.setServiceURI(serviceUri);
                methodInfo.setServerPassword(serverSpec.passwordHandler.getServicePassword(serverUri));
                methodInfo.setPassword(serverSpec.passwordHandler.getServicePassword(serviceUri));
                linksXml = (Element)callObject.call(methodInfo);
                
                if (linksXml != null)
                {
                    serviceLinks = getServiceLinks(linksXml);
                    serviceLinks.add(serviceUri);
                    cluster = new Cluster(Cluster.toKey(i+1), serviceLinks);
                    cResult.addCluster(cluster);
                }
            }
        }
        
        combine(cResult);
        return cResult;
    }
    
    /**
     * Parse the links description to get the linked to service ids.
     * @param linksXml the links description.
     * @return list of service links.
     */
    private ArrayList<Element> getServiceLinks(Element linksXml)
    {
        int i;
        ArrayList<Element> links;               //services list
        Element nextElem;                       //next element
        Element nextElem2;                      //next element
        Vector childList;                       //child list
        
        links = new ArrayList<>();

        childList = linksXml.getChildren();
        for (i = 0; i < childList.size(); i++)
        {
            nextElem = (Element)childList.get(i);
            if (nextElem.getName().equals(Const.LINK)) {
                nextElem2 = nextElem.getChild(Const.HANDLE);
                if (nextElem2 != null) {
                    links.add((Element)nextElem2.detach());
                }
            }
            else {
                nextServiceLinks(nextElem, links);
            }
        }
        
        return links;
    }
    
    /**
     * Parse the links description to get the linked to service ids.
     * @param linksXml the links description.
     * @param links the list to add to.
     * @return list of service links.
     */
    private void nextServiceLinks(Element linksXml, ArrayList<Element> links)
    {
        int i;
        Element nextElem;                       //next element
        Element nextElem2;                      //next element
        Vector<Node> elemList;                  //element list
        
        elemList = linksXml.getChildren();
        for (i = 0; i < elemList.size(); i++)
        {
            nextElem = (Element)elemList.get(i);
            if (nextElem.getName().equals(Const.LINK)) {
                nextElem2 = nextElem.getChild(Const.HANDLE);
                if (nextElem2 != null) {
                    links.add((Element)nextElem2.detach());
                }
            }
            else {
                nextServiceLinks(nextElem, links);
            }
        }
    }
    
    /**
     * Combine the separate clusters if they overlap.
     * @param cResult the result object with the clusters list. This is updated
     * to combine overlapping clusters into a single cluster.
     * @throws java.lang.Exception any error.
     */
    private void combine(ClusterResult cResult) throws Exception
    {
        int i, j;
        String nextKey;                             //next key
        String nextKey2;                            //next key
        ArrayList<String> allKeys;                  //all keys
        HashMap<String, Cluster> clusters;          //clusters list
        Cluster cluster;                            //next cluster
        Cluster cluster2;                           //next cluster
        
        clusters = cResult.clusters;
        allKeys = new ArrayList(clusters.keySet());

        for (i = 0; i < allKeys.size(); i++)
        {
            nextKey = allKeys.get(i);
            cluster = clusters.get(nextKey);
            
            j = (i+1);
            while (j < allKeys.size())
            {
                nextKey2 = allKeys.get(j);
                cluster2 = clusters.get(nextKey2);

                if (contains(cluster.list, cluster2.list)) {
                    combine(cluster.list, cluster2.list);
                    cResult.clusters.remove(nextKey2);
                    allKeys.remove(j);
                }
                else {
                    j++;
                }
            }
        }
    }
    
        /**
     * Add any element in list2 to list, if they are not present.
     * @param list list of handle elements.
     * @param list2 second list of handle elements.
     * @throws java.lang.Exception any error.
     */
    private void combine(ArrayList list, ArrayList list2) throws Exception
    {
        int i;
        Element nextElem;                       //next element
        
        for (i = 0; i < list2.size(); i++)
        {
            nextElem = (Element)list2.get(i);
            if (!contains(list, nextElem)) {
                list.add(nextElem);
            }
        }
    }
    
    /**
     * Return true if the list contains the handle element.
     * @param list list of handle elements.
     * @param list2 second list of handle elements.
     * @return true if string-based description is contained.
     * @throws java.lang.Exception any error.
     */
    private boolean contains(ArrayList list, ArrayList list2) throws Exception
    {
        int i;
        boolean contains = false;               //true if contains
        Element nextElem;                       //next element
        
        for (i = 0; !contains && (i < list2.size()); i++)
        {
            nextElem = (Element)list2.get(i);
            contains = contains(list, nextElem);
        }
        
        return contains;
    }
    
    /**
     * Return true if the list contains the handle element.
     * @param list list of handle elements.
     * @param handle handle to compare with.
     * @return true if string-based description is contained.
     * @throws java.lang.Exception any error.
     */
    private boolean contains(ArrayList list, Element handle) throws Exception
    {
        int i;
        boolean contains = false;               //true if contains
        String handleStr;                       //handle as string
        String handleStr2;                      //handle as string
        Element nextElem;                       //next element
        
        handleStr = XmlHandler.xmlToString(handle);
        for (i = 0; !contains && (i < list.size()); i++)
        {
            nextElem = (Element)list.get(i);
            handleStr2 = XmlHandler.xmlToString(nextElem);
            contains = (handleStr.equals(handleStr2));
        }
        
        return contains;
    }
    
    /**
     * Get the results of the test.
     * @return the test results in XML format.
     * @throws java.lang.Exception any error.
     */
    public Element getResultXml() throws Exception
    {
        Element resultElem;                         //result element

        resultElem = XMLFactory.getInstance().createElement(SolverConst.BESTSOLUTIONSET);
        resultElem.setText(ResultFormatter.convertToString(result));
        return resultElem;
    }
}
