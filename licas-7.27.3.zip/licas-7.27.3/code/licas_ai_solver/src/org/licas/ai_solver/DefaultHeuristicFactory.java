/*
 * DefaultHeuristicFactory.java
 *
 * Created on 12 November 2015
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


/**
 * This class stores some constant values. These define what base heuristics or algorithms
 * are available for the problem solving.
 * @author Kieran Greer
 */
public class DefaultHeuristicFactory extends HeuristicFactory
{
    /** Create a new instance of DefaultHeuristicFactory */
    public DefaultHeuristicFactory()
    {
        super();
        
        heuristicClassif = new DefaultHeuristicClassification(heuristicModules);
        heuristicMetric = new DefaultHeuristicMetrics(heuristicClassif, heuristicModules);
        heuristicHeuristic = new DefaultHeuristicHeuristics(heuristicClassif, heuristicModules);
        heuristicData = new DefaultHeuristicData(heuristicClassif, heuristicModules);
        heuristicFramework = new DefaultHeuristicFrameworks(heuristicClassif, heuristicModules);
    }
}
