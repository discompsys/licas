/*
 * Evaluator.java
 *
 * Created on 18 March 2010
 *
 * Version 1.5
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.eval;


import org.ai_heuristic.eval.EvaluateBase;
import org.licas.ai_solver.model.result.Result;
import org.licas.ai_solver.SolverFactory;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.mediator.problem.ProblemMediator;
import org.licas.ai_solver.mediator.ProblemSolverMediator;
import org.licas.ai_solver.util.SolverConst;

import org.licas.data.DataQueryModel;
import org.ai_heuristic.functs.FunctionMetric;
import org.licas.util.ObjectHandler;
import org.licas.util.TypeConst;
import org.licas_xml.abs.*;

import java.util.ArrayList;


/**
 * This class should be implemented by any evaluation framework, to mediate between
 * the problem-solver and the services that are part of the problem solving process. 
 * While the {@link ProblemSolverMediator} coordinates the, possibly distributed services 
 * problem-solving framework, this mediator evaluates the created solution sets for 
 * the problem solver, from a more centralised position.
 * @author Kieran Greer
 */
public abstract class Evaluator
{
    /** The last returned test result, which is stored as XML inside of this element. */
    protected Element lastTestResult;

    /** List of all test results, which are stored as XML inside of this element. */
    protected Element testResults;
    
    /** The problem solving result. This can be more solutions, cluster references, or an error. */
    protected Result result;
    
    /** To compare result values */
    protected FunctionMetric valueCompare;
   

    /** Create a new instance of Evaluator */
    public Evaluator()
    {
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        lastTestResult = null;
        valueCompare = null;
        testResults = XMLFactory.getInstance().createElement(SolverConst.ALLRESULTS);
    }
    
    
    /**
     * Create or initialise the solution and problem values from the problem specification.
     * The specification for these must be fully described in the test and problem
     * specifications and the problem specification class must then be able to create the
     * solution and problem dataset objects from this specification.
     * @param testSpec the specification describing the tests to run.
     * @param probMediator the model of the problem with all required elements.
     * @return true if initialised OK, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public abstract boolean initialiseMediator(TestSpec testSpec, ProblemMediator probMediator)
            throws Exception;
    
    /**
     * Return true if the value is better than the best value.
     * @param bestValue the best comparison value.
     * @param value the value to measure.
     * @return true if the new value is better, as determined by the stored function, 
     * or if the best value is null.
     * @throws java.lang.Exception any error.
     */
    protected boolean isBetter(Object bestValue, Object value) throws Exception
    {
        int i;
        Double num1, num2;                  //number counts
        ArrayList list;                     //number list
        Object obj;                         //result object

        if (bestValue != null) {
            bestValue = EvaluateBase.valueFromSet(bestValue);
        }
        if (value != null) {
            value = EvaluateBase.valueFromSet(value);
        }

        if ((bestValue != null) && (value != null)) {
            num1 = 0.0;
            num2 = 0.0;

            if (ObjectHandler.isArrayList(bestValue.getClass().getName())) {
                list = (ArrayList)bestValue;
                for (i = 0; i < list.size(); i++)
                {
                    obj = EvaluateBase.valueFromSet(list.get(i));
                    num1 += (Double)obj;
                }
            }
            if (ObjectHandler.isArrayList(bestValue.getClass().getName())) {
                list = (ArrayList)bestValue;
                for (i = 0; i < list.size(); i++)
                {
                    obj = EvaluateBase.valueFromSet(list.get(i));
                    num2 += (Double)obj;
                }
            }

            return valueCompare.isBetter(TypeConst.DOUBLE, num1, num2);
        }
        
        return true;
    }
    
    /**
     * Create the function metric to evaluate solution results, for calculating some 
     * stat values.
     * @param testSpec the test specification.
     * @return true if the function already exists or was created, false otherwise.
     */
    protected boolean createFunctionMetric(TestSpec testSpec)
    {
        DataQueryModel dataInfo;                      //stores evaluator parameters
        
        if (valueCompare == null) {
            try {
                dataInfo = new DataQueryModel();
                dataInfo.setDataType(SolverFactory.getInstance().getSolverData().dataClassFromType(testSpec.getTestScript().datasetType));
                
                valueCompare = (FunctionMetric)SolverFactory.getInstance().getSolverMetrics().getEvaluationFunction(SolverFactory.getInstance().getSolverData().dataClassFromType(testSpec.getTestScript().datasetType),
                    testSpec.getTestScript().metricType,
                    SolverFactory.getInstance().getSolverData().getEvaluateData(dataInfo), 
                    testSpec.getTestScript().heuristicOptions);
                
                return true;
            }
            catch (Exception ex) {
                valueCompare = null;
                return false;
            }
        }
        
        return false;           
    }
    
    /**
     * Get the last result object that was generated.
     * @return the value of result.
     */
    public Result getResult()
    {
        return result;
    }
    
    /**
     * Get the result from the last test run only in an XML element.
     * @return the test result in XML format.
     */
    public Element getTestResult()
    {
        return lastTestResult;
    }

    /**
     * Get the results of all of the test runs in a single XML element.
     * @return the test results in XML format.
     */
    public Element getAllTestResults()
    {
        return testResults;
    }
}
