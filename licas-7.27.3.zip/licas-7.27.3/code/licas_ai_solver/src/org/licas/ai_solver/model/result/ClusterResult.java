/*
 * ClusterResult.java
 *
 * Created on 29 June 2017
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.model.result;


import org.licas.util.ObjectHandler;
import java.util.*;


/**
 * This class stores a list of clusters of type {@link Cluster}, that represent a reference set.
 * @author Kieran Greer
 */
public class ClusterResult extends Result
{
    /** 
     * List of clusters representing a complete solution.
     * Key is a unique cluster ID and value is of type {@link Cluster}.
     */
    public HashMap<String, Cluster> clusters;
    
    /**
     * Create a new instance of ClusterResult.
     */
    public ClusterResult()
    {
        super();
        clusters = new HashMap<>();
    }

    /**
     * Return true if this result object contains a cluster with the indicated key name.
     * @param key name of a cluster to check for.
     * @return true if this result object has a cluster with the indicated name.
     * @throws java.lang.Exception any error.
     */
    public boolean containsKey(String key) throws Exception
    {
        return clusters.containsKey(key);
    }

    /**
     * Return true if this result object contains a cluster with the indicated set of elements.
     * @param list the cluster elements to compare with. This uses {@code ObjectHandler.equals}
     * to check if the elements are the same.
     * @return true if this result object has a cluster that matches with the element list exactly.
     * @throws java.lang.Exception any error.
     */
    public boolean containsCluster(ArrayList<?> list) throws Exception
    {
        int i, j;
        boolean contains = false;           //true if contains
        String nextKey;                     //next key
        Iterator<String> allKeys;           //all keys
        Cluster cluster;                    //next cluster
        Object obj, obj2;                   //list objects

        allKeys = clusters.keySet().iterator();
        while (!contains && allKeys.hasNext())
        {
            nextKey = allKeys.next();
            cluster = clusters.get(nextKey);

            if (cluster.list.size() == list.size()) {
                contains = true;

                for (i = 0; contains && (i < cluster.list.size()); i++) {
                    contains = false;
                    obj = cluster.list.get(i);

                    for (j = 0; !contains && (j < list.size()); j++) {
                        obj2 = list.get(j);
                        contains = ObjectHandler.equals(obj, obj2);
                    }
                }
            }
        }

        return contains;
    }

    /**
     * Add a new cluster to the result. It should be named with a unique ID.
     * @param cluster the cluster to add.
     * @return true if added, false if the name is missing or already exists.
     */
    public boolean addCluster(Cluster cluster)
    {
        if (cluster.name != null) {
            if (!clusters.containsKey(cluster.name)) {
                clusters.put(cluster.name, cluster);
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Get a string-based description of this cluster result.
     * @return string-based description of this object.
     */
    public String toString()
    {
        int i;
        StringBuilder solutionStr;          //solution as a string
        StringBuilder clusterStr;           //cluster string
        String nextKey;                     //next key
        Iterator<String> allKeys;           //all keys
        Cluster cluster;                    //next cluster
        
        solutionStr = new StringBuilder();
        solutionStr.append("Clusters:\n");
        
        allKeys = clusters.keySet().iterator();
        while (allKeys.hasNext())
        {
            nextKey = allKeys.next();
            cluster = clusters.get(nextKey);
            solutionStr.append(nextKey).append(":\n");
            
            clusterStr = new StringBuilder();
            for (i = 0; i < cluster.list.size(); i++)
            {
                try {
                    clusterStr.append(ObjectHandler.getValue(cluster.list.get(i)));
                }
                catch (Exception ex) {
                    clusterStr.append(String.valueOf(cluster.list.get(i)));
                }
                
                if (i < (cluster.list.size()-1)) clusterStr.append(", ");
            }
            
            solutionStr.append(clusterStr).append("\n");
        }
        
        return solutionStr.toString();
    }
}
