/*
 * ProblemSolverMediator.java
 *
 * Created on 24 July 2013
 *
 * Version 1.7.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.mediator;


import org.licas.ai_solver.SolverFactory;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.mediator.problem.ProblemMediator;
import org.licas.ai_solver.spec.*;
import org.licas.ai_solver.util.SolverConst;

import org.licas.MessageInfo;
import org.licas.PasswordHandler;
import org.licas.meta.MetaFactory;
import org.licas.service.InformationMediator;
import org.licas.service.spec.BehaviourScript;
import org.licas.call.*;
import org.licas.data.gen.DataGenerator;
import org.licas.util.exception.LicasException;
import org.licas.util.*;

import org.ai_heuristic.eval.metric.*;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas_xml.abs.*;
import org.licas_xml.model.XmlHandler;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.*;

import java.util.*;


/**
 * This class can be used to mediate between the information services that are created, the
 * information sources and any related centralised problem solver. A service can be created
 * with data added later, or initialised with an information source. The service then runs
 * on the server and communicates with the problem solver classes through the licas framework.
 * @author Kieran Greer
 */
public class ProblemSolverMediator extends InformationMediator
{
    /** The logger */
    private static final Logger logger;


    /** The main type of service being run */
    protected String infoServiceType;

    /** List of service names */
    protected ArrayList<String> serviceNames;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ProblemSolverMediator.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of ProblemSolverMediator.
     * @param thePasswordHandler the password handler.
     * @throws java.lang.Exception any error.
     */
    public ProblemSolverMediator(PasswordHandler thePasswordHandler) throws Exception
    {
        super(thePasswordHandler);
    }

    /**
     * Creates a new instance of ProblemSolverMediator.
     * @param thisPassword the component password.
     * @param thisAdminKey the unique service key.
     * @param thePasswordHandler the password handler.
     * @throws java.lang.Exception any error.
     */
    public ProblemSolverMediator(String thisPassword, String thisAdminKey,
                                 PasswordHandler thePasswordHandler) throws Exception
    {
        super(thisPassword, thisAdminKey, thePasswordHandler);
    }

    /**
     * Initialise the solver mediator with the server details. Also clear the
     * network of any existing services and the password handler for this service.
     * @param theServiceSpec the test script with all of the test config. Of type
     * {@link ProblemScript}.
     * @return true if initialised OK, false otherwise. Most likely, it would be
     * missing service initialisation information.
     * @throws java.lang.Exception any error.
     */
    public boolean initialiseServerInfo(ProblemScript theServiceSpec) throws Exception
    {
        String className;                       //service class name
        ArrayList<String> serviceTypes;         //service types list
        MethodInfo methodInfo;                  //method info
        CallObject callObject;                  //call object

        try
        {
            initialiseInfo(theServiceSpec);
            serviceNames = new ArrayList<>();

            infoServiceType = theServiceSpec.serviceType;
            if (infoServiceType == null) {
                className = theServiceSpec.serviceClasses.get(ServiceConst.BEHAVIOUR);
                infoServiceType = SolverFactory.getServiceType(className);
                theServiceSpec.serviceType = infoServiceType;
            }
            if (theServiceSpec.dataConditions != null) {
                sourceURLs = theServiceSpec.dataConditions;
            }

            //depending on the source of the test, passwords might not be available,
            //so only clear the network if the server passwords are present
            if (passwordHandler.hasAdminKey(serverUri) && !theServiceSpec.testRunsScript.sameServices) {
                //keep behaviour mediator as not automatically added
                serviceTypes = new ArrayList<>();
                serviceTypes.add(ServiceConst.BEHAVIOURMEDIATOR);

                callObject = new CallObject();
                methodInfo = new MethodInfo();
                methodInfo.setName(MethodConst.CLEARNETWORK);
                methodInfo.setRtnType(TypeConst.VOID);
                methodInfo.setServiceURI(serverUri);
                methodInfo.setServerPassword(passwordHandler.getServicePassword(serverUri));
                methodInfo.setPassword(passwordHandler.getServicePassword(serverUri));
                methodInfo.addParam(serviceTypes);
                methodInfo.addParam(Boolean.TRUE);
                methodInfo.addParam(passwordHandler.getAdminKey(serverUri));
                callObject.call(methodInfo);
            }

            return true;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "initialiseServerInfo", null, ex);
        }
    }

    /**
     * Create an information service for each of the listed sources and initiate each
     * one with the source information. This can include a more detailed admin script
     * and a data generator for random data.
     * @throws java.lang.Exception any error.
     */
    public void createServices() throws Exception
    {
        int i;
        String serviceUuid;                     //service uuid
        String serverPassword;                  //server password
        String nextURL;                         //next url
        ArrayList<String> uriList;              //list of URIs

        try
        {
            uriList = new ArrayList<>();

            //load services onto the network
            if (((ProblemScript)serviceSpec).convertForInitialise()) {
                if (passwordHandler.hasServicePassword(serverUri)) {
                    serverPassword = passwordHandler.getServicePassword(serverUri);
                }
                else {
                    serverPassword = getServicePassword(Const.HTTPSERVER, Handle.getURL(serverUri));
                    if (serverPassword != null) passwordHandler.addServicePassword(serverUri, serverPassword);
                }

                if (serverPassword != null) {
                    if ((sourceURLs != null) && !sourceURLs.isEmpty()) {
                        for (i = 0; i < sourceURLs.size(); i++)
                        {
                            nextURL = sourceURLs.get(i);

                            //try to create the uuid from the file or url path
                            //if not then use a random uuid
                            serviceUuid = UriHandler.getFileName(nextURL);
                            if (serviceUuid == null) {
                                serviceUuid = (ServiceConst.IINDEX + "_" +
                                        UuidHandler.getUuid(3, System.currentTimeMillis()));
                            }

                            uriList.add(serviceUuid);
                        }
                    }
                    else {
                        for (i = 0; i < serviceSpec.servicesNum; i++)
                        {
                            serviceUuid = (ServiceConst.IINDEX + "_" +
                                    UuidHandler.getUuid(4, System.currentTimeMillis()));

                            while (uriList.contains(serviceUuid)) {
                                serviceUuid = (ServiceConst.IINDEX + "_" +
                                        UuidHandler.getUuid(4, System.currentTimeMillis()));
                            }

                            uriList.add(serviceUuid);
                        }
                    }

                    for (i = 0; i < uriList.size(); i++)
                    {
                        serviceUuid = uriList.get(i);

                        nextURL = null;
                        if ((sourceURLs != null) && (sourceURLs.size() > i)) {
                            nextURL = sourceURLs.get(i);
                        }

                        //add new information service
                        createService(serviceUuid, nextURL, i);
                    }
                }
            }
            else {
                throw new LicasException("There may be an error in the service spec, please check this.");
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "createServices",
                    null, ex);
        }
        finally {
            //ask for garbage collection
            System.gc();
        }
    }

    /**
     * Create an information service for each of the listed sources and initiate each
     * one with the source information. This can include a more detailed admin script
     * and a data generator for random data.
     * @param serviceUuid uuid for the service to create.
     * @param dataOrUrl address of a resource to load, or string data itself.
     * @param index for unique ids.
     * @throws java.lang.Exception any error.
     */
    public void createService(String serviceUuid, String dataOrUrl, int index) throws Exception
    {
        boolean isOK;                               //true if OK
        String serviceClass;                        //service class
        String servicePassword;                     //service password
        String serverPassword;                      //server password
        String adminKey;                            //service key
        Element serviceUri;                         //service uri
        Element adminXml;                           //admin XML
        ArrayList<String> jarFiles;                 //list of jar files
        ArrayList<Object> params;                   //parameters
        MethodInfo methodInfo;                      //method info
        CallObject callObject;                      //call object

        try {
            synchronized(Monitor.getMonitor().getSyncOn()) {
                callObject = new CallObject();

                //load service onto the network
                if (passwordHandler.hasServicePassword(serverUri)) {
                    serverPassword = passwordHandler.getServicePassword(serverUri);
                }
                else {
                    serverPassword = getServicePassword(Const.HTTPSERVER, Handle.getURL(serverUri));
                    if (serverPassword != null) passwordHandler.addServicePassword(serverUri, serverPassword);
                }

                if (serverPassword != null) {
                    //admin document construction
                    if (serviceSpec.constructorParams.size() > 0) {
                        servicePassword = (String)serviceSpec.constructorParams.get(0);
                        if (serviceSpec.constructorParams.size() > 1)
                            adminKey = (String)serviceSpec.constructorParams.get(1);
                        else
                            adminKey = UuidHandler.getUuid(10, System.currentTimeMillis());
                    }
                    else {
                        servicePassword = UuidHandler.getUuid(10, System.currentTimeMillis());
                        adminKey = UuidHandler.getUuid(10, System.currentTimeMillis());
                    }

                    //create the admin script
                    adminXml = createAdminScript(serviceUuid, index);

                    //parameters for service itself
                    params = new ArrayList<>();
                    params.add(servicePassword);
                    params.add(adminKey);
                    if ((adminXml != null) && adminXml.hasChildren()) params.add(adminXml);
                    serviceClass = serviceSpec.serviceClasses.get(ServiceConst.BEHAVIOUR);
                    jarFiles = serviceSpec.serviceJarFiles.get(ServiceConst.BEHAVIOUR);

                    //add new information service
                    methodInfo = new MethodInfo();
                    methodInfo.setName(MethodConst.ADDSERVICE);
                    methodInfo.setRtnType(TypeConst.BOOLEAN);
                    methodInfo.setServiceURI(serverUri);
                    methodInfo.setServerPassword(serverPassword);
                    methodInfo.setPassword(serverPassword);
                    methodInfo.addParam(serverPassword);
                    methodInfo.addParam(serviceUuid);
                    methodInfo.addParam(infoServiceType);
                    methodInfo.addParam(jarFiles);
                    methodInfo.addParam(serviceClass);
                    methodInfo.addParam(params);
                    isOK = (Boolean)callObject.call(methodInfo);

                    if (isOK) {
                        passwordHandler.addServicePassword(serviceUuid, servicePassword);
                        passwordHandler.addAdminKey(serviceUuid, adminKey);

                        serviceUri = Handle.createNewUrlHandle(serverIP);
                        serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceUuid));

                        //if a data file is specified, then load the data onto the
                        //information service, otherwise generate some random data
                        if (dataOrUrl != null) {
                            //as file being read store in text/xml format only
                            if (serviceSpec.datasetType.equals(TypeConst.URI) ||
                                    serviceSpec.datasetType.equals(TypeConst.URL)) {
                                //as file being read store in text/xml format only
                                methodInfo = new MethodInfo();
                                methodInfo.setName(MethodConst.LOADDATADETAILS);
                                methodInfo.setRtnType(TypeConst.VOID);
                                methodInfo.setServiceURI(serviceUri);
                                methodInfo.setServerPassword(serverPassword);
                                methodInfo.setPassword(passwordHandler.getServicePassword(serviceUuid));
                                methodInfo.addParam(serviceSpec.datasetType);
                                methodInfo.addParam(dataOrUrl);
                                callObject.call(methodInfo);
                            }
                            else {
                                //as file being read store in text/xml format only
                                methodInfo = new MethodInfo();
                                methodInfo.setName(MethodConst.LOADDATACONTENTS);
                                methodInfo.setRtnType(TypeConst.VOID);
                                methodInfo.setServiceURI(serviceUri);
                                methodInfo.setServerPassword(serverPassword);
                                methodInfo.setPassword(passwordHandler.getServicePassword(serviceUuid));
                                methodInfo.addParam(serviceSpec.datasetType);
                                methodInfo.addParam(dataOrUrl);
                                callObject.call(methodInfo);
                            }
                        }
                        else {
                            methodInfo = new MethodInfo();
                            methodInfo.setName(MethodConst.SETGENDATA);
                            methodInfo.setRtnType(TypeConst.VOID);
                            methodInfo.setServiceURI(serviceUri);
                            methodInfo.setServerPassword(serverPassword);
                            methodInfo.setPassword(passwordHandler.getServicePassword(serviceUuid));
                            methodInfo.addParam(adminKey);
                            callObject.call(methodInfo);
                        }
                    }
                    else {
                        throw new LicasException("Service " + serviceUuid + " could not be loaded.");
                    }
                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "createService",
                    null, ex);
        }
        finally {
            Monitor.getMonitor().release();
        }
    }

    /**
     * Create the admin script to initialise the service with.
     * @param serviceUuid uuid for the service to create.
     * @param index for unique ids.
     * @return the service admin script.
     * @throws java.lang.Exception any error.
     */
    public Element createAdminScript(String serviceUuid, int index) throws Exception
    {
        String serviceClass;                        //service class
        Element servicesXml;                        //services XML
        Element adminXml;                           //admin XML
        Element otherXml;                           //other XML
        Element adminXml2;                          //admin XML
        Element otherXml2;                          //other XML
        Element nextElem;                           //next element
        ArrayList<String> jarFiles;                 //list of jar files
        ArrayList<Object> params;                   //parameters
        Object conParam;                            //constructor parameter
        Object[] fileParam;                         //file parameter

        try
        {
            if (serviceSpec.constructorParams.size() > 2)
            {
                conParam = serviceSpec.constructorParams.get(2);
                if (conParam instanceof String) {
                    adminXml = XmlHandler.stringToElement(FileLoader.getInputStream((String)conParam));
                }
                else if (conParam instanceof Object[]) {
                    fileParam = (Object[])conParam;
                    if ((fileParam.length > 1) && (fileParam[1] instanceof Element)) {
                        adminXml = (Element)fileParam[1];
                    }
                    else {
                        conParam = fileParam[0];
                        adminXml = XmlHandler.stringToElement(FileLoader.getInputStream((String)conParam));
                    }
                }
                else {
                    adminXml = (Element)conParam;
                }
            }
            else {
                adminXml = MetaFactory.createAdmin();
            }

            servicesXml = null;
            if (serviceSpec.serviceClasses.containsKey(AiHeuristicConst.EVALUATOR)) {
                servicesXml = XMLFactory.getInstance().createElement(Const.SERVICES);
                adminXml.addContent(servicesXml);
                otherXml = XMLFactory.getInstance().createElement(Const.SERVICESTOLOAD);
                servicesXml.addContent(otherXml);

                //add other metric values
                adminXml2 = MetaFactory.createAdmin();
                nextElem = MetaFactory.createMeta(AiConst.AISOLVER);
                adminXml2.addContent(nextElem);
                otherXml2 = nextElem;

                if (serviceSpec.metricType != null) {
                    nextElem = MetaFactory.createMeta(AiConst.METRICTYPE);
                    nextElem.setText(serviceSpec.metricType);
                    otherXml2.addContent(nextElem);
                }

                serviceClass = serviceSpec.serviceClasses.get(AiHeuristicConst.EVALUATOR);
                jarFiles = serviceSpec.serviceJarFiles.get(AiHeuristicConst.EVALUATOR);
                if (jarFiles == null) jarFiles = new ArrayList<>();
                params = new ArrayList<>();
                params.add(adminXml2);

                nextElem = MetaFactory.getFactoryService().createLoadService(ServiceConst.EVALUATE, ServiceConst.EVALUATE,
                        serviceClass, jarFiles, params);

                otherXml.addContent(nextElem);
            }

            if (serviceSpec.serviceClasses.containsKey(ServiceConst.DATAGENERATORTYPE)) {
                if (servicesXml == null) {
                    servicesXml = XMLFactory.getInstance().createElement(Const.SERVICES);
                    adminXml.addContent(servicesXml);
                }

                otherXml = servicesXml.getChild(Const.SERVICESTOLOAD);
                if (otherXml == null) {
                    otherXml = XMLFactory.getInstance().createElement(Const.SERVICESTOLOAD);
                    servicesXml.addContent(otherXml);
                }

                serviceClass = serviceSpec.serviceClasses.get(ServiceConst.DATAGENERATORTYPE);
                jarFiles = serviceSpec.serviceJarFiles.get(ServiceConst.DATAGENERATORTYPE);
                if (jarFiles == null) jarFiles = new ArrayList<>();

                adminXml2 = DataGenerator.conditionsToXml(index, (BehaviourScript)serviceSpec, System.currentTimeMillis());

                params = new ArrayList<>();
                params.add(adminXml2);
                nextElem = MetaFactory.getFactoryService().createLoadService(ServiceConst.DATAGENERATORTYPE,
                        ServiceConst.DATAGENERATOR, serviceClass, jarFiles, params);

                nextElem.setAttribute(Const.UUID, serviceUuid);
                nextElem.addContent(DataGenerator.conditionsToXml(index, (BehaviourScript)serviceSpec, System.currentTimeMillis()));
                otherXml.addContent(nextElem);
            }

            //check for external script and add
            if (serviceSpec.externalScript != null) {
                otherXml = adminXml.getChild(Const.OTHERMETA);
                if (otherXml == null) {
                    otherXml = MetaFactory.createMeta(Const.OTHERMETA);
                    adminXml.addContent(otherXml);
                }

                nextElem = MetaFactory.createMeta(Const.OTHERSCRIPT);
                nextElem.setText(serviceSpec.externalScript);
                otherXml.addContent(nextElem);
            }

            //add a data element with the data type at least, for the main service
            otherXml = adminXml.getChild(Const.DATA);
            if (otherXml == null) {
                otherXml = MetaFactory.createMeta(Const.DATA);
                adminXml.addContent(otherXml);
                nextElem = MetaFactory.createMeta(Const.DATATYPE);
                nextElem.setText(SolverFactory.getInstance().getSolverData().dataClassFromType(serviceSpec.datasetType));
                otherXml.addContent(nextElem);
            }

            return adminXml;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "createAdminScript",
                    null, ex);
        }
    }

    /**
     * Send the solution reply to any services on the {@code serviceNames} list.
     * Use the {@code messageReply} method to return the result, passing a
     * {@link MessageInfo} object with an {@link AiConst}.{@code NOACTION} message state..
     * @param testSpec the model of the tests to perform.
     * @param replyXml the result from the problem solver.
     * @throws java.lang.Exception any error.
     */
    public void replyToServices(TestSpec testSpec, Element replyXml) throws Exception
    {
        int i;
        String serviceUuid;                             //service uuid
        Element serviceUri;                             //the service uri
        MessageInfo messageInfo;                        //message info
        MethodInfo methodInfo;                          //method info
        CallObject callObject;                          //call object

        try {
            callObject = new CallObject();
            if ((serviceNames != null) && !serviceNames.isEmpty()) {
                for (i = 0; i < serviceNames.size(); i++)
                {
                    serviceUuid = serviceNames.get(i);
                    serviceUri = Handle.createNewUrlHandle(testSpec.getTestScript().serverSpec.serverAddress);
                    serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceUuid));

                    try {
                        messageInfo = new MessageInfo(SolverConst.PROBLEM_REPLY, replyXml);
                        messageInfo.setMessageState(AiConst.NOACTION);

                        methodInfo = new MethodInfo();
                        methodInfo.setName(MethodConst.MESSAGEREPLY);
                        methodInfo.setRtnType(TypeConst.BOOLEAN);
                        methodInfo.setServiceURI(serviceUri);
                        methodInfo.setServerPassword(passwordHandler.getServicePassword(serverUri));
                        methodInfo.setPassword(passwordHandler.getServicePassword(serviceUri));
                        methodInfo.addParam(messageInfo);

                        callObject.call(methodInfo);
                    }
                    catch (Exception ex) {
                        //do nothing
                    }
                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "replyToServices", null, ex);
        }
    }

    /**
     * Retrieve the information from each information source in XML format and create
     * a data object by parsing it and adding it to a {@code MetricValue} object.
     * This is to seed the problem-solving solutions with and so is probably scientific
     * information in nature.
     * @param testSpec the model of the tests to perform.
     * @param probMediator the problem mediator.
     * @return the list of created metric objects.
     * @throws java.lang.Exception any error.
     */
    public ArrayList<MetricDataset> getServicesInfo(TestSpec testSpec, ProblemMediator probMediator) throws Exception
    {
        ArrayList<MetricValue> valueList;               //list of values
        ArrayList<MetricDataset> datasetList;           //list of datasets
        HashMap<String, ?> datasetHash;                 //dataset hash
        MetricValue metricValue;                        //metric value
        MetricDataset metricDataset;                    //metric dataset
        Object dataObj;                                 //data object

        try
        {
            datasetHash = getServicesData(testSpec);
            datasetList = new ArrayList<>();

            //parse xml datasets to generate data structures for evaluating
            for (String key: datasetHash.keySet())
            {
                dataObj = datasetHash.get(key);
                if (dataObj != null) {
                    //try to parse back into an object first
                    if (dataObj instanceof Element) {
                        try {
                            dataObj = probMediator.parseProblemDataset(SolverFactory.getInstance().getSolverData().dataClassFromType(probMediator.datasetType),
                                    (Element) dataObj);
                        }
                        catch (Exception ex) {}
                    }

                    //give same name to value so that it can be matched
                    metricValue = MetricValue.toValue((Const.VALUE + "_" + String.valueOf(1)),
                            SolverFactory.getInstance().getSolverData().dataClassFromType(probMediator.datasetType),
                            dataObj);

                    valueList = new ArrayList<>();
                    valueList.add(metricValue);
                    metricDataset = MetricDataset.toDataset(key, probMediator.datasetType,
                            valueList);

                    datasetList.add(metricDataset);
                }
            }

            return datasetList;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "getServicesInfo", null, ex);
        }
    }

    /**
     * Get the dataset elements from all running services.
     * @param testSpec the model of the tests to perform.
     * @return the dataset elements indexed by the service uuids.
     * @throws java.lang.Exception any error.
     */
    public LinkedHashMap<String, Object> getServicesData(TestSpec testSpec) throws Exception
    {
        int i;
        String serviceUuid;                             //service uuid
        ArrayList<String> serviceTypes;                 //service types
        LinkedHashMap<String, Object> dataHash;         //services data
        Element serviceUri;                             //the service uri
        MethodInfo methodInfo;                          //method info
        CallObject callObject;                          //call object
        Object reply;                                   //can be anything

        try {
            callObject = new CallObject();
            dataHash = new LinkedHashMap<>();
            serviceTypes = new ArrayList<>();
            serviceTypes.add(infoServiceType);
            serverUri = Handle.createNewServerHandle(testSpec.getTestScript().serverSpec.serverAddress);

            //retrieve all service ids
            methodInfo = new MethodInfo();
            methodInfo.setName(MethodConst.GETSERVICENAMES);
            methodInfo.setRtnType(TypeConst.ARRAYLIST);
            methodInfo.setServiceURI(serverUri);
            methodInfo.setServerPassword(passwordHandler.getServicePassword(serverUri));
            methodInfo.setPassword(passwordHandler.getServicePassword(serverUri));
            methodInfo.addParam(serviceTypes);
            serviceNames = (ArrayList)callObject.call(methodInfo);

            if ((serviceNames != null) && !serviceNames.isEmpty()) {
                for (i = 0; i < serviceNames.size(); i++)
                {
                    serviceUuid = serviceNames.get(i);
                    serviceUri = Handle.createNewUrlHandle(testSpec.getTestScript().serverSpec.serverAddress);
                    serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceUuid));

                    try {
                        methodInfo = new MethodInfo();
                        methodInfo.setName(MethodConst.GETDATA);
                        methodInfo.setRtnType(TypeConst.OBJECT);
                        methodInfo.setServiceURI(serviceUri);
                        methodInfo.setServerPassword(passwordHandler.getServicePassword(serverUri));
                        methodInfo.setPassword(passwordHandler.getServicePassword(serviceUri));

                        reply = callObject.call(methodInfo);
                    }
                    catch (Exception ex) {
                        reply = null;
                    }

                    if (reply != null) {
                        dataHash.put(serviceUuid, reply);
                    }
                }
            }

            return dataHash;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "getServicesData", null, ex);
        }
    }

    /**
     * Get a list of retrieved service names.
     * @return the value of serviceNames.
     */
    public ArrayList<String> getServiceNames()
    {
        return serviceNames;
    }
}
