/**
 * Implementation of some basic search frameworks. 
 */
package org.licas.ai_solver.search;