/*
 * GridMetric.java
 *
 * Created on 28 December 2021
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.central.grid.metric;


/** Interface for comparing cells in the hyper grid */
public interface GridMetric<T> {

    /**
     * Get the data class type.
     * @return class name for the data type of the metric.
     */
    String dataType();

    /**
     * Produce a summed value for the two parameter lists, but only for the matching entries.
     * @param list1 the first value list.
     * @param list2 the second value list.
     * @param hMatch true if try to match, false if try largest score.
     * @param asPercentage true if range is a percentage, false if an actual value.
     * @param range score inside-of which a match is true.
     * @return some value representing the summed total.
     */
    float listSum(Object[] list1, Object[] list2, boolean hMatch, boolean asPercentage, Object range);

    /**
     * Produce a summed value for the two parameters.
     * @param value1 the first value.
     * @param value2 the second value.
     * @return some value representing the summed total.
     */
    float sum(T value1, T value2);

    /**
     * Compare the two values for similarity.
     * @param value1 the first value.
     * @param value2 the second value.
     * @return true if the same, false if different.
     */
    boolean isSame(T value1, T value2);

    /**
     * Return true if hte parameter value represents null, or empty.
     * @param value1 value to consider.
     * @return some value representing the summed total.
     */
    boolean isNull(T value1);

    /**
     * Return an appropriate value of the type to represent null, or empty.
     * @return a null-representation for the type.
     */
    T getNull();

    /**
     * Compare two values lists and return a result.
     * @param list1 the first value.
     * @param list2 the second value. Same size as list1.
     * @param hMatch true if try to match, false if try largest score.
     * @param asPercentage true if range is a percentage, false if an actual value.
     * @param range score inside-of which a match is true.
     * @return the comparison result.
     */
    float listsMatch(T[] list1, T[] list2, boolean hMatch, boolean asPercentage, T range);

    /**
     * Compare two values and return a result.
     * @param value1 the first value.
     * @param value2 the second value.
     * @param hMatch true if try to match, false if try largest score.
     * @param asPercentage true if range is a percentage, false if an actual value.
     * @param range score inside-of which a match is true.
     * @return the comparison result.
     */
    float valuesMatch(T value1, T value2, boolean hMatch, boolean asPercentage, T range);
}
