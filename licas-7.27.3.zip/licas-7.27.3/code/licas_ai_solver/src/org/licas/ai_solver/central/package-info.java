/**
 * Centralised solutions, where services send their data to a single problem solver, which sorts it and can return a result. 
 */
package org.licas.ai_solver.central;