/*
 * Result.java
 *
 * Created on 29 June 2017
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.model.result;


import org.licas.ai_solver.model.EvalBounds;


/**
 * This is a base class for storing the result of applying a problem solver on the problem set.
 * This can return references to clusters or matching solutions.
 * @author Kieran Greer
 */
public class Result
{
    /** The solution result name */
    protected String name;
    
    /** 
     * Result evaluation bounds if used.
     */
    protected EvalBounds evaluation;
    
    
    /**
     * Create a new instance of Result.
     */
    public Result()
    {
        name = null;        
    }
    
    /**
     * Create a new instance of Result.
     * @param thisName the unique result ID.
     */
    public Result(String thisName)
    {
        name = thisName;
    }
    
    /**
     * Return true if this result is a base type storing an {@code EvalBounds} value only, false otherwise.
     * @return true if a {@code Result}, false otherwise.
     */
    public boolean isValueType()
    {
        return (this instanceof Result);
    }

    /**
     * Return true if this result is the matching solutions type, false otherwise.
     * @return true if a {@link MatchResult}, false otherwise.
     */
    public boolean isMatchType()
    {
        return (this instanceof MatchResult);
    }
    
    /**
     * Return true if this result is the cluster references type, false otherwise.
     * @return true if a {@link ClusterResult}, false otherwise.
     */
    public boolean isClusterType()
    {
        return (this instanceof ClusterResult);
    }
    
    /**
     * Return true if this result is the error type, false otherwise.
     * @return true if a {@link ErrorResult}, false otherwise.
     */
    public boolean isErrorType()
    {
        return (this instanceof ErrorResult);
    }
    
    /**
     * Set the solution name.
     * @param thisName the solution name.
     */
    public void setName(String thisName)
    {
        name = thisName;
    }
    
    /**
     * Get the solution name.
     * @return the value of name.
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Set the evaluation value for the result.
     * @param theEvaluation the evaluation value.
     */
    public void setEvaluation(EvalBounds theEvaluation)
    {
        evaluation = theEvaluation;
    }
    
    /**
     * Get an evaluation that the process has produced.
     * @return the value of evaluation.
     */
    public EvalBounds getEvaluation()
    {
        return evaluation;
    }

    /**
     * Get a string-based description of this grid solution.
     * @return string-based description of this object.
     */
    public String toString()
    {
        String solutionStr;                                 //solution as a string

        solutionStr = "";
        if (name != null)
        {
            solutionStr += (name + "\n");
        }
        if (evaluation != null) {
            solutionStr += ("Best score: " + String.valueOf(evaluation.evaluation.getValue()));
            solutionStr += ("\nUpper score: " + String.valueOf(evaluation.upper.getValue()));
            solutionStr += ("\nLower score: " + String.valueOf(evaluation.lower.getValue()));
        }

        return solutionStr;
    }
}
