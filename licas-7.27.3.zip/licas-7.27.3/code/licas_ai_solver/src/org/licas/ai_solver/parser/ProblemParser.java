/*
 * ProblemParser.java
 *
 * Created on 6 April 2010
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.parser;


import org.licas.ai_solver.model.Problem;
import org.licas_xml.abs.*;


/**
 * This class parses a problem description of type {@link Problem} to or from XML.
 * @author Kieran Greer
 */
public abstract class ProblemParser
{
    /** Create a new instance of ProblemParser */
    public ProblemParser()
    {}

    /**
     * Serialize a problem description into xml.
     * @param problem the problem description.
     * @return an xml description of the problem.
     * @throws Exception any error.
     */
    public abstract Element serialize(Problem problem) throws Exception;

    /**
     * Parse the XML back into a problem object.
     * @param rootElem the root element of the xml description.
     * @return a parsed problem object.
     * @throws java.lang.Exception any error.
     */
    public abstract Problem parse(Element rootElem) throws Exception;
}
