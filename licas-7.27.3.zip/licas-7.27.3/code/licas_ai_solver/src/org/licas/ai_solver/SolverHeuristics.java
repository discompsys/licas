/*
 * SolverHeuristics.java
 *
 * Created on 29 January 2016
 *
 * Version 1.1.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.ai_heuristic.model.FactoryInfo;

import java.util.*;


/**
 * This class describes the methods used by the solver heuristics. A copy is stored in the
 * {@link SolverFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public abstract class SolverHeuristics
{
    /** 
     * List of modules automatically loaded in during startup. Of type {@link ModuleSolverFactory}.
     */
    protected static ArrayList<ModuleSolverFactory> solverModules;
    
    /**
     * Create a new instance of SolverHeuristics.
     * @param theSolverModules list of solver modules.
     */
    public SolverHeuristics(ArrayList<ModuleSolverFactory> theSolverModules)
    {
        solverModules = theSolverModules;
    }
    
    
    /**
     * Get a list of possible heuristic options for the specified heuristic types. 
     * This can include variables for the evaluation metric as well.
     * @param solverType the solver framework: hyper, distributed, etc.
     * @param heuristicType the heuristic framework.
     * @param metricType the evaluator of the heuristic. This is also considered, but can be null.
     * @return the list of options for the heuristic. This could be evolution types
     * for a genetic algorithm, for example, but for other heuristics it could
     * be a completely different set of values.
     */
    public abstract ArrayList<String> getHeuristicOptions(String solverType, String heuristicType, String metricType);
    
    /**
     * Get the list of solver classes that can be loaded from the default package.
     * @return a list of FactoryInfo objects for each solver function type.
     */
    public abstract HashMap<String, HashMap<String, FactoryInfo>> getDefaultSolverClasses();
    
    /**
     * Get a list of all available dataset types.
     * @return the list of all dataset types.
     */
    public abstract ArrayList<String> getAllDatasetTypes();
    
    /**
     * Get a list of all available dataset type descriptions.
     * @return the list of all dataset types.
     */
    public abstract ArrayList<String> getAllDatasetTypeDescriptions();
    
    /**
     * Get a list of available text-based dataset types.
     * @return the list of dataset type objects.
     */
    public abstract ArrayList<String> getTextDatasetTypes();
}
