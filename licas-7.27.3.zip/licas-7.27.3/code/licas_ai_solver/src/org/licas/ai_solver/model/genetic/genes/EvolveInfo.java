/*
 * EvolveInfo.java
 *
 * Created on 14 June 2013
 *
 * Version 1.0.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.model.genetic.genes;


import org.licas.ai_solver.util.SolverConst;
import org.licas.util.*;
import org.ai_heuristic.util.TextConst;

import java.util.*;


/**
 * This class stores the information that describes the desired evolution conditions or process.
 * @author Kieran Greer
 */
public class EvolveInfo 
{
    /** The gene type. Also probably the data type */
    public String geneType;
    
    /** 
     * Evolution types, mutate or crossover, for example.
     * If either indicates a percentage calculation, then that will result in
     * both mutate and crossover as percentage calculations. This can be overriden
     * if the fraction values are incorrect. If only one is present then only one
     * evolution type is carried out. Some data types might now allow percentage
     * calculations, such as the bag-of-words.
     */
    public ArrayList<String> evolveTypes;
    
    /** 
     * Fraction percentage related to a mutation, in the range 0 to 1.
     * A value of 0 or less means no fraction. Must then also apply to the crossover.
     */
    public float mutatePercent;
    
    /** 
     * Fraction related to a crossover, in the range 0 to 1.
     * A value of 0 or less means no fraction. Must then also apply to the mutation.
     */
    public float crossoverPercent;
    
    /**
     * Create a new instance of EvolveInfo.
     */
    public EvolveInfo()
    {
        geneType = null;
        resetValues();
    }
    
    /** Reset some values */
    private void resetValues()
    {
        evolveTypes = new ArrayList<>();
        mutatePercent = (float)0.0;
        crossoverPercent = (float)0.0;
    }
    
    /**
     * Return true if the gene type is a simple type.
     * @return true if a simple java type.
     */
    public boolean isSimpleType()
    {
        return TypeConst.isSimpleType(geneType);
    }
    
    /**
     * Return true if the gene type is a bag-of-words or related type.
     * @return true if a bag-of-words related type.
     */
    public boolean isBagOfWords()
    {
        return (geneType.equals(TextConst.BAGOFWORDS) ||
            geneType.equals(TextConst.METABAGOFWORDS));
    }
    
    /**
     * If true use the specified fractions to evolve with. If false use the single default value.
     * @return true if use fractions or false is use default.
     */
    public boolean useFractions()
    {
        return ((mutatePercent > 0) && (mutatePercent <= 1.0) &&
                (crossoverPercent > 0) && (crossoverPercent <= 1.0) &&
                (evolveTypes.contains(SolverConst.MUTATEPERCENT) ||
                evolveTypes.contains(SolverConst.CROSSOVERPERCENT)));
    }
    
    /**
     * Copy any evolve type info from the heuristic options to this class's settings.
     * @param heuristicOptions list of options as key-value pairs.
     */
    public void copyEvolveTypes(HashMap heuristicOptions)
    {
        resetValues();
        if (heuristicOptions.containsKey(SolverConst.MUTATEPERCENT)) {
            evolveTypes.add(SolverConst.MUTATEPERCENT);
            mutatePercent = ((Float)heuristicOptions.get(SolverConst.MUTATEPERCENT)).floatValue();
        }
        if (heuristicOptions.containsKey(SolverConst.CROSSOVERPERCENT)) {
            evolveTypes.add(SolverConst.CROSSOVERPERCENT);
            crossoverPercent = ((Float)heuristicOptions.get(SolverConst.CROSSOVERPERCENT)).floatValue();
        }
        if (heuristicOptions.containsKey(SolverConst.MUTATE)) {
            evolveTypes.add(SolverConst.MUTATE);
        }
        if (heuristicOptions.containsKey(SolverConst.CROSSOVER)) {
            evolveTypes.add(SolverConst.CROSSOVER);
        }
    }
}
