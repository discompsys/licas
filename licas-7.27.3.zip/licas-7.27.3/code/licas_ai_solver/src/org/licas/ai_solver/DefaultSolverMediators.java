/*
 * DefaultSolverMediators.java
 *
 * Created on 29 January 2016
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.licas.ai_solver.def.TestDef;
import org.licas.ai_solver.eval.*;
import org.licas.ai_solver.mediator.ProblemSolverMediator;
import org.licas.ai_solver.mediator.problem.*;
import org.licas.ai_solver.test.*;
import org.licas.PasswordHandler;
import org.licas.service.*;
import org.licas.util.HeuristicConst;

import java.util.*;


/**
 * This class describes the methods used by the solver mediators. A copy is stored in the
 * {@link DefaultSolverFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public class DefaultSolverMediators extends SolverMediators
{
    /**
     * Create a new instance of DefaultSolverMediators.
     * @param thePasswordHandler the password handler.
     * @param theSolverModules list of solver modules.
     */
    public DefaultSolverMediators(PasswordHandler thePasswordHandler, ArrayList theSolverModules)
    {
        super(thePasswordHandler, theSolverModules);
    }
    
    
    /**
     * Set the service mediator.
     * @param theServiceMediator the service mediator.
     */
    public void setServiceMediator(ServiceMediator theServiceMediator)
    {
        serviceMediator = theServiceMediator;
    }
    
    /**
     * Get the currently created service mediator.
     * @return the value of serviceMediator.
     */
    public ServiceMediator getServiceMediator()
    {
        return serviceMediator;
    }
    
    /**
     * Create and return the appropriate service mediator for the problem type.
     * If one has already been created, return it instead, so the mediator should
     * be created only once.
     * This mediator creates and controls the flow of information between 
     * the services that are run. The default version is {@link SolverMediators}.
     * @param solverType the type of test framework to solve the problem.
     * @return the appropriate service mediator for solving the problem.
     * @throws java.lang.Exception any error.
     */
    public ServiceMediator createServiceMediator(String solverType) throws Exception
    {
        int i;
        ModuleSolverFactory moduleFactory;                 //module factory
                
        //Essentially only 1 default mediator type
        if (serviceMediator == null)
        {
            if (solverType.equals(HeuristicConst.GRIDMATCH) ||
                    solverType.equals(HeuristicConst.GRIDHILL) ||
                    solverType.equals(HeuristicConst.SEARCHHILL) ||
                    solverType.equals(HeuristicConst.LINKDISTRIBUTED) ||
                    solverType.equals(HeuristicConst.NEARESTNEIGHBOUR) ||
                    solverType.equals(HeuristicConst.SOMNN))
            {
                serviceMediator = new ProblemSolverMediator(passwordHandler);
            }
            
            if (serviceMediator == null)
            {
                //add from the modules
                for (i = 0; (serviceMediator == null) && (i < solverModules.size()); i++)
                {
                    moduleFactory = (ModuleSolverFactory)solverModules.get(i);
                    if (moduleFactory.hasSolverMediators())
                    {
                        serviceMediator = moduleFactory.getSolverMediators().createServiceMediator(solverType);
                    }
                }
            }
            
            if (serviceMediator == null)
            {
                serviceMediator = new ProblemSolverMediator(passwordHandler);
            }
        }
        
        return serviceMediator;
    }
    
    /**
     * Create and return the appropriate test mediator to execute the services in the framework. 
     * @param solverType the type of test framework to solve the problem.
     * @param serviceType the type of services that are created.
     * @return the appropriate {@link TestDef} class to run and execute the script in
     * the test loop.
     * @throws java.lang.Exception any error.
     */
    public TestDef getTestMediator(String solverType, String serviceType) throws Exception
    {
        int i;
        TestDef testMediator;                           //the test mediator
        ModuleSolverFactory moduleFactory;              //module factory
        
        testMediator = null;
        if (solverType.equalsIgnoreCase(HeuristicConst.GRIDHILL) ||
            solverType.equalsIgnoreCase(HeuristicConst.GRIDMATCH))
        {
            testMediator = new GridTests(passwordHandler);
        }
        else if (solverType.equalsIgnoreCase(HeuristicConst.SEARCHHILL))
        {
            testMediator = new SearchTests(passwordHandler);
        }
        else if (solverType.equalsIgnoreCase(HeuristicConst.LINKDISTRIBUTED))
        {
            testMediator = new LinkTests(passwordHandler);
        }
        else if (solverType.equalsIgnoreCase(HeuristicConst.NEARESTNEIGHBOUR))
        {
            testMediator = new KnnTests(passwordHandler);
        }
        else if (solverType.equalsIgnoreCase(HeuristicConst.SOMNN))
        {
            testMediator = new SomTests(passwordHandler);
        }
        
        if (testMediator == null)
        {
            //add from the modules
            for (i = 0; (testMediator == null) && (i < solverModules.size()); i++)
            {
                moduleFactory = (ModuleSolverFactory)solverModules.get(i);
                if (moduleFactory.hasSolverMediators())
                {
                    testMediator = moduleFactory.getSolverMediators().getTestMediator(solverType, serviceType);
                }
            }
        }
        
        return testMediator;
    }
        
    /**
     * Create and return the appropriate mediator for the current problem type.
     * This default implementation returns a {@link GridEvaluator} or a
     * {@link LinkEvaluator}.
     * @param solverType the type of test framework to solve the problem.
     * @param heuristicType the heuristic or problem-solving type.
     * @return the appropriate evaluation mediator for solving the problem.
     */
    public Evaluator getSolverFrameworkMediator(String solverType, String heuristicType)
    {
        int i;
        Evaluator evalMediator;                     //centralised solutions
        ModuleSolverFactory moduleFactory;          //module factory
        
        evalMediator = null;
        if (solverType.equals(HeuristicConst.GRIDHILL) ||
            solverType.equals(HeuristicConst.GRIDMATCH))
        {
            evalMediator = new GridEvaluator();
        }
        else if (solverType.equals(HeuristicConst.SEARCHHILL))
        {
            evalMediator = new SearchEvaluator();
        }
        else if (solverType.equals(HeuristicConst.LINKDISTRIBUTED))
        {
            evalMediator = new LinkEvaluator();
        }
        else if (solverType.equals(HeuristicConst.NEARESTNEIGHBOUR))
        {
            evalMediator = new KnnEvaluator();
        }
        else if (solverType.equals(HeuristicConst.SOMNN))
        {
            evalMediator = new SomEvaluator();
        }
        
        if (evalMediator == null)
        {
            //add from the modules
            for (i = 0; (evalMediator == null) && (i < solverModules.size()); i++)
            {
                moduleFactory = (ModuleSolverFactory)solverModules.get(i);
                if (moduleFactory.hasSolverMediators())
                {
                    evalMediator = moduleFactory.getSolverMediators().getSolverFrameworkMediator(solverType, heuristicType);
                }
            }
        }

        return evalMediator;
    }
    
    /**
     * Get the problem specification object related to the current problem type.
     * @param solverType the type of test framework to solve the problem.
     * @param heuristicType the heuristic or problem-solving type, for example,
     * {@link HeuristicConst}.{@code GENETICALGORITHM} or {@code FREQUENCY}.
     * @return the related problem specification object.
     */
    public ProblemMediator getProblemMediator(String solverType, String heuristicType)
    {
        int i;
        ProblemMediator mediator;                   //problem mediator
        ModuleSolverFactory moduleFactory;          //module factory
        
        mediator = null;
        if (solverType.equals(HeuristicConst.GRIDHILL) ||
            solverType.equals(HeuristicConst.GRIDMATCH))
        {
            if (heuristicType.equals(HeuristicConst.GENETICALGORITHM))
            {
                mediator = new GeneticGridProblemMediator(passwordHandler);
            }
            else
            {
                mediator = new SingleGridProblemMediator(passwordHandler);
            }
        }
        else if (solverType.equals(HeuristicConst.SEARCHHILL))
        {
            mediator = new SearchProblemMediator(passwordHandler);
        }
        else if (solverType.equals(HeuristicConst.LINKDISTRIBUTED))
        {
            mediator = new LinkProblemMediator(passwordHandler);
        }
        else if (solverType.equals(HeuristicConst.NEARESTNEIGHBOUR))
        {
            mediator = new KnnProblemMediator(passwordHandler);
        }
        else if (solverType.equals(HeuristicConst.SOMNN))
        {
            mediator = new SomProblemMediator(passwordHandler);
        }
        
        if (mediator == null)
        {
            //add from the modules
            for (i = 0; (mediator == null) && (i < solverModules.size()); i++)
            {
                moduleFactory = (ModuleSolverFactory)solverModules.get(i);
                if (moduleFactory.hasSolverMediators())
                {
                    mediator = moduleFactory.getSolverMediators().getProblemMediator(solverType, heuristicType);
                }
            }
        }

        return mediator;
    }
}
