/*
 * HeuristicFrameworks.java
 *
 * Created on 30 January 2016
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.ai_heuristic.model.FactoryInfo;
import java.util.*;


/**
 * This class describes the methods used by the heuristic frameworks. A copy is stored in the
 * {@link HeuristicFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public abstract class HeuristicFrameworks 
{
    /** The default heuristic classifications */
    protected HeuristicClassification heuristicClassif;
    
    /** 
     * List of modules automatically loaded in during startup. Of type {@link ModuleHeuristicFactory}.
     */
    protected static ArrayList<ModuleHeuristicFactory> heuristicModules = new ArrayList<>();
    
    /** 
     * Create a new instance of HeuristicFrameworks. 
     * @param theHeuristicClassif the heuristic classifications.
     * @param theHeuristicModules list of heuristic modules.
     */
    public HeuristicFrameworks(HeuristicClassification theHeuristicClassif, ArrayList<ModuleHeuristicFactory> theHeuristicModules)
    {
        heuristicClassif = theHeuristicClassif;
        heuristicModules = theHeuristicModules;
    }
    
    
    /**
     * Get a list of possible problem-solving frameworks.
     * @return the list of problem solver frameworks, as {@link FactoryInfo} objects.
     * This base class version returns and empty list. See {@link DefaultHeuristicFrameworks} for an example.
     */
    public HashMap<String, FactoryInfo> getFrameworkTypes() {
        return new HashMap<>();
    }
    
    /**
     * Get a list of default behaviour classes with {@link FactoryInfo} descriptions.
     * @param solverType the problem-solving framework, for example, the Hyper-Heuristic 
     * requires {@code Information} services, or {@code MetaConst.ALL} for any service types.
     * @return a list of appropriate service classes. Key is the class name, value is the info object.
     * This base class version returns and empty list. See {@link DefaultHeuristicFrameworks} for an example.
     */
    public HashMap<String, FactoryInfo> getBehaviourClasses(String solverType) {
        return new HashMap<>();
    }
}
