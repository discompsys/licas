/*
 * SomConfig.java
 *
 * Created on 22 October 2014
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.central;


import org.ai_heuristic.data.LearningDataModel;
import java.util.*;


/**
 * This class stores some config values to allow a SOM neural network to be built
 * and run.
 * @author Kieran Greer
 */
public class SomConfig
{
    /** Maximum number of training iterations */
    public int iterations;
    
    /** Number of weights */
    public int weightNumber;
    
    /** Topology row */
    public int topologyRow;
    
    /** Topology column */
    public int topologyCol;
    
    /** Topology radius of influence */
    public int topologyRadius;
    
    /** Data type */
    public String dataType;
    
    /** SOM Learning Framework */
    public String learningFramework;
    
    /** Learning Function */
    public String learningFunction;
    
    /** Neighbourhood Function */
    public String neighbourhoodFunction;
    
    /** Neighbourhood Function model */
    public String neighbourhoodFunctionModel;
    
    /** Activation Function */
    public String activationFunction;
    
    /** Topology */
    public String topology;
    
    /** Evaluation Metric */
    public String metric;
    
    /** Learning function config parameters */
    public HashMap<String, Object> lfParams;
    
    /** List of initialisation weights */
    public double[] weights;
    
    /** List of existing weights for each neuron, from an earlier test run */
    public ArrayList neuronWeights;
    
    /** The data to train the neural network with */
    public LearningDataModel somData;
    
    
    /** Create a new instance of SomConfig */
    public SomConfig()
    {
        iterations = 0;
        weightNumber = 0;
        topologyRow = 0;
        topologyCol = 0;
        topologyRadius = 0;
        lfParams = new HashMap<>();
        dataType = null;
        learningFramework = null;    
        learningFunction = null;    
        neighbourhoodFunction = null;
        neighbourhoodFunctionModel = null;
        activationFunction = null;
        topology = null;   
        metric = null;
        weights = null;
        neuronWeights = null;
        somData = null;
    }
    
    /**
     * Copy the values of this config and return.
     * @return a light clone copy of this object.
     */
    public Object clone()
    {
        SomConfig somConfig;                        //copy of the config
        
        somConfig = new SomConfig();        
        somConfig.activationFunction = activationFunction;
        somConfig.dataType = dataType;
        somConfig.iterations = iterations;
        somConfig.learningFramework = learningFramework;
        somConfig.learningFunction = learningFunction;              
        somConfig.lfParams = (HashMap)lfParams.clone();
        somConfig.metric = metric;
        somConfig.neighbourhoodFunction = neighbourhoodFunction;
        somConfig.neighbourhoodFunctionModel = neighbourhoodFunctionModel;
        somConfig.somData = somData;
        somConfig.topology = topology;
        somConfig.topologyRow = topologyRow;
        somConfig.topologyCol = topologyCol;
        somConfig.topologyRadius = topologyRadius;
        somConfig.weightNumber = weightNumber;
        somConfig.weights = weights;                
           
        return somConfig;
    }
}
