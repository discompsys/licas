/**
 * Classes for returning the problem solver result. 
 */
package org.licas.ai_solver.model.result;