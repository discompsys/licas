/*
 * SolverSpecs.java
 *
 * Created on 29 January 2016
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.licas.ai_solver.parser.ProblemScriptParser;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.ai_solver.spec.ProblemScript;
import org.licas.PasswordHandler;
import org.licas.ai_solver.util.SolverConst;

import java.util.*;


/**
 * This class describes the methods used by the solver test specification. A copy is stored in the
 * {@link SolverFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public abstract class SolverSpecs
{
    /** The password handler */
    protected PasswordHandler passwordHandler;
    
    /** 
     * List of modules automatically loaded in during startup. Of type {@link ModuleSolverFactory}.
     */
    protected static ArrayList<ModuleSolverFactory> solverModules;
    
    /**
     * Create a new instance of SolverSpecs.
     * @param thePasswordHandler the password handler.
     * @param theSolverModules list of solver modules.
     */
    public SolverSpecs(PasswordHandler thePasswordHandler, ArrayList<ModuleSolverFactory> theSolverModules)
    {
        passwordHandler = thePasswordHandler;
        solverModules = theSolverModules;
    }
    
    
    /**
     * Get the test specification object related to the current problem type.
     * @param solverType the type of test framework to solve the problem.
     * {@code HYPERCOMPARE} or {@code LINKDISTRIBUTED}, etc.
     * @return the related test specification object.
     */
    public abstract TestSpec getTestSpec(String solverType);
    
    /**
     * Get the problem script object related to the current problem type.
     * @param solverType the type of test framework to solve the problem.
     * @return the related problem script object.
     */
    public abstract ProblemScript getProblemScript(String solverType);
    
    /**
     * Get the parser to create the problem script from an XML description.
     * @param solverType the type of test framework to solve the problem.
     * @return the related problem script parser.
     */
    public abstract ProblemScriptParser getProblemScriptParser(String solverType);

    /**
     * Get a list of test config script variables, for display purposes.
     * @param scriptType the type of script part. The default package is covered, for example
     * {@code TESTRUNSSCRIPT, GRIDHILL, GRIDMATCH, LINKDISTRIBUTED}, but you can add
     * others to derived classes.
     * @return the list of variable names.
     * This base class version returns and empty list. See {@link DefaultSolverSpecs} for an example.
     */
    public ArrayList<String> getTestScriptVariables(String scriptType)
    {
        return new ArrayList<>();
    }

    /**
     * Get a list of test config script heuristic types.
     * This needs to be a list with all variables added, identified by the key name.
     * @return the list of names with types. Key is the var name, value is the class type.
     * This base class version returns and empty list. See {@link DefaultSolverSpecs} for an example.
     */
    public HashMap<String, String> getTestScriptVariableTypes()
    {
        return new HashMap();
    }

    /**
     * Get a list of test config script variable descriptions, for display purposes.
     * This needs to be a list with all variables added, identified by the key name.
     * @return the list of variable descriptions. Key is the var name, value is the description.
     * This base class version returns and empty list. See {@link DefaultSolverSpecs} for an example.
     */
    public HashMap<String, String> getTestScriptVariableDescriptions()
    {
        return new HashMap();
    }

    /**
     * Get a list of allowed values for a test script variable.
     * @param variableType the variable type.
     * @return the list of allowed values for the variable.
     * This base class version returns and empty list. See {@link DefaultSolverSpecs} for an example.
     */
    public ArrayList<String> getTestScriptVarValues(String variableType)
    {
        return new ArrayList();
    }
}
