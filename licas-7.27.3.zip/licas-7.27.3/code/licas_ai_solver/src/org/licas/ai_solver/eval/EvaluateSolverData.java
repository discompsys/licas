/*
 * EvaluateSolverData.java
 *
 * Created on 25 April 2011
 *
 * Version 1.4.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.eval;


import org.licas.data.*;
import org.ai_heuristic.model.*;
import org.ai_heuristic.util.AiHeuristicConst;


/**
 * This is an extension to the licas {@code EvaluateData} object to allow some other
 * AI-related structures to be included. The main methods are {@code evalComparison}
 * to mathCompare two objects, or {@code mathOperation} to perform a mathematical operator over
 * two objects. As well as {@code Integer}, {@code Long}, {@code Float}, {@code Double} and 
 * {@code String}, this implementation also evaluates a {@code BagOfWords} or a {@code MetaBagOfWords} object.
 * @author Kieran Greer
 */
public class EvaluateSolverData extends EvaluateData
{
    /** 
     * Create a new instance of EvaluateSolverData 
     * @param theDataQuery defines what evaluators are used.
     */
    public EvaluateSolverData(DataQueryModel theDataQuery)
    {
        super(theDataQuery);
    }
    
    /**
     * Evaluate the expression.
     * @param valueType the type of the value.
     * @param value1 first value.
     * @param value2 second value.
     * @param operator mathematical operator - can be add, subtract, multiply, divide.
     * @return the result of the mathematical operation. Simple types are cast to their
     * Object equivalent.
     * @throws java.lang.Exception any error.
     */
    public Object mathOperation(String valueType, Object value1, Object value2, String operator)
            throws Exception
    {
        switch (operator) {
            case AiHeuristicConst.ADD:
                return add(valueType, value1, value2);
            case AiHeuristicConst.SUBTRACT:
                return subtract(valueType, value1, value2);
            case AiHeuristicConst.MULTIPLY:
                return multiply(valueType, value1, value2);
            case AiHeuristicConst.DIVIDE:
                return divide(valueType, value1, value2);
            case AiHeuristicConst.UNION:
                return union(valueType, value1, value2);
            case AiHeuristicConst.INTERSECTION:
                return intersection(valueType, value1, value2);
            case AiHeuristicConst.DOTPRODUCT:
                return dotproduct(valueType, value1, value2);
            case AiHeuristicConst.MAGNITUDE:
                return magnitude(valueType, value1, value2);
            default:
                return null;
        }
    }
    
    /**
     * Evaluate the expression and return true if true.
     * @param valueType the type of the value.
     * @param value1 first value.
     * @param value2 second value.
     * @param operator comparison operator.
     * @return true if comparison is true and false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean mathCompare(String valueType, Object value1, Object value2, String operator)
            throws Exception
    {
        if ((value1 == null) || (value2 == null))
            return false;
        else if (valueType.equals(BagOfWords.class.getName()))
            return evaluate((BagOfWords)value1, (BagOfWords)value2, operator);
        else if (valueType.equals(MetaBagOfWords.class.getName()))
            return evaluate((MetaBagOfWords)value1, (MetaBagOfWords)value2, operator);
        else
            return super.mathCompare(valueType, value1, value2, operator);
    }
    
    
    /**
     * Evaluate the expression and return true if true.
     * @param value1 first value.
     * @param value2 second value.
     * @param operator comparison operator.
     * @return true if comparison is true.
     */
    protected boolean evaluate(BagOfWords value1, BagOfWords value2, String operator)
    {
        boolean eval;                                       //evaluation
               
        //can only check for equivalence at the moment
        eval = false;        
        if (operator.equals(AiHeuristicConst.EQ))
        {
            eval = value1.sameWordList(value2);
        }
        
        return eval;
    }
    
    /**
     * Evaluate the expression and return true if true.
     * @param value1 first value.
     * @param value2 second value.
     * @param operator comparison operator.
     * @return true if comparison is true.
     */
    protected boolean evaluate(MetaBagOfWords value1, MetaBagOfWords value2, String operator)
    {
        boolean eval;                                   //evaluation
       
        //can only check for equivalence at the moment
        eval = false;        
        if (operator.equals(AiHeuristicConst.EQ))
        {
            eval = evaluate(value1, (BagOfWords)value2, operator);
            if (eval) eval = value1.otherIsSame(value2);
        }
        
        return eval;
    }
    
    /**
     * Union of the object values.
     * @param valueType the type of the value.
     * @param value1 first value.
     * @param value2 second value.
     * @return the union of the two objects.
     * @throws java.lang.Exception any error.
     */
    public Object union(String valueType, Object value1, Object value2) throws Exception
    {
        if (value1 == null)
            return value2;
        else if (value2 == null)
            return value1;
        else if (valueType.equals(BagOfWords.class.getName()))
            return union((BagOfWords)value1, (BagOfWords)value2);
        else if (valueType.equals(MetaBagOfWords.class.getName()))
            return union((MetaBagOfWords)value1, (MetaBagOfWords)value2);
        else 
            return null;
    }
    
    /**
     * This is the union of the two structures.
     * @param value1 first value.
     * @param value2 second value.
     * @return the values added together.
     * @throws java.lang.Exception any error.
     */
    protected BagOfWords union(BagOfWords value1, BagOfWords value2) throws Exception
    {
        BagOfWords added;                   //values added together
        
        added = (value1).union(value2);
        return added;
    }
    
    /**
     * This is the union of the two structures.
     * @param value1 first value.
     * @param value2 second value.
     * @return the values added together.
     * @throws java.lang.Exception any error.
     */
    protected MetaBagOfWords union(MetaBagOfWords value1, MetaBagOfWords value2) throws Exception
    {
        MetaBagOfWords added;                       //values added together
        
        added = (MetaBagOfWords)value1.union(value2);        
        return added;
    }
    
    /**
     * Intersection of the object values.
     * @param valueType the type of the value.
     * @param value1 first value.
     * @param value2 second value.
     * @return the intersection of the two objects.
     * @throws java.lang.Exception any error.
     */
    public Object intersection(String valueType, Object value1, Object value2) throws Exception
    {
        if (value1 == null)
            return value2;
        else if (value2 == null)
            return value1;
        else if (valueType.equals(BagOfWords.class.getName()))
            return intersection((BagOfWords)value1, (BagOfWords)value2);
        else if (valueType.equals(MetaBagOfWords.class.getName()))
            return intersection((MetaBagOfWords)value1, (MetaBagOfWords)value2);
        else 
            return null;
    }
    
    /**
     * This is the intersection of the two structures.
     * @param value1 first value.
     * @param value2 second value.
     * @return the intersection value.
     * @throws java.lang.Exception any error.
     */
    protected BagOfWords intersection(BagOfWords value1, BagOfWords value2) throws Exception
    {
        BagOfWords subtracted;                   //values subtracted
        
        subtracted = (value2).intersection(value1);
        return subtracted;
    }
    
    /**
     * This is the intersection of the two structures.
     * @param value1 first value.
     * @param value2 second value.
     * @return the intersection value.
     * @throws java.lang.Exception any error.
     */
    protected MetaBagOfWords intersection(MetaBagOfWords value1, MetaBagOfWords value2) throws Exception
    {
        MetaBagOfWords subtracted;                      //values subtracted
        
        subtracted = (MetaBagOfWords)value1.intersection(value2);        
        return subtracted;
    }
    
    /**
     * Dot-product of the object values.
     * @param valueType the type of the value.
     * @param value1 first value.
     * @param value2 second value.
     * @return the dot-product of the two objects.
     */
    public Object dotproduct(String valueType, Object value1, Object value2)
    {
        if (value1 == null)
            return value2;
        else if (value2 == null)
            return value1;
        else if (valueType.equals(BagOfWords.class.getName()))
            return dotproduct((BagOfWords)value1, (BagOfWords)value2);
        else if (valueType.equals(MetaBagOfWords.class.getName()))
            return dotproduct((MetaBagOfWords)value1, (MetaBagOfWords)value2);
        else 
            return null;
    }
    
    /**
     * This is the dot-product of the two structures.
     * @param value1 first value.
     * @param value2 second value.
     * @return the dot-product value.
     */
    protected Double dotproduct(BagOfWords value1, BagOfWords value2)
    {
        double dotproduct;                       //dotproduct count
        
        dotproduct = value1.dotproduct(value2);        
        return new Double(dotproduct);
    }
    
    /**
     * This is the dot-product of the two structures.
     * @param value1 first value.
     * @param value2 second value.
     * @return the dot-product value.
     */
    protected Double dotproduct(MetaBagOfWords value1, MetaBagOfWords value2)
    {
        double dotproduct;                       //dotproduct count
        
        dotproduct = value1.dotproduct(value2);        
        return new Double(dotproduct);
    }
    
    /**
     * Magnitude of the object values.
     * @param valueType the type of the value.
     * @param value1 first value.
     * @param value2 second value.
     * @return the magnitude of the two objects.
     */
    public Object magnitude(String valueType, Object value1, Object value2)
    {
        if (value1 == null)
            return value2;
        else if (value2 == null)
            return value1;
        else if (valueType.equals(BagOfWords.class.getName()))
            return magnitude((BagOfWords)value1, (BagOfWords)value2);
        else if (valueType.equals(MetaBagOfWords.class.getName()))
            return magnitude((MetaBagOfWords)value1, (MetaBagOfWords)value2);
        else 
            return null;
    }
    
    /**
     * This is the magnitude of the two structures.
     * @param value1 first value.
     * @param value2 second value.
     * @return the magnitude value.
     */
    protected Double magnitude(BagOfWords value1, BagOfWords value2)
    {
        double magnitude;                               //magnitude count
        
        magnitude = value1.magnitude(value2);        
        return new Double(magnitude);
    }
    
    /**
     * This is the magnitude of the two structures.
     * @param value1 first value.
     * @param value2 second value.
     * @return the magnitude value.
     */
    protected Double magnitude(MetaBagOfWords value1, MetaBagOfWords value2)
    {
        double magnitude;                               //magnitude count
        
        magnitude = value1.magnitude(value2);        
        return new Double(magnitude);
    }
    
    /**
     * Add the two objects together and return.
     * @param valueType the type of the value.
     * @param value1 first value.
     * @param value2 second value.
     * @return the two values added together.
     * @throws java.lang.Exception any error.
     */
    public Object add(String valueType, Object value1, Object value2)
            throws Exception
    {
        if (value1 == null)
            return value2;
        else if (value2 == null)
            return value1;
        else if (valueType.equals(BagOfWords.class.getName()))
            return add((BagOfWords)value1, (BagOfWords)value2);
        else if (valueType.equals(MetaBagOfWords.class.getName()))
            return add((MetaBagOfWords)value1, (MetaBagOfWords)value2);
        else
            return super.add(valueType, value1, value2);
    }
    
    /**
     * Add the two BagOfWords values together. This is the union of the two structures.
     * @param value1 first value.
     * @param value2 second value.
     * @return the values added together.
     * @throws java.lang.Exception any error.
     */
    protected Double add(BagOfWords value1, BagOfWords value2) throws Exception
    {
        return new Double(union(value1, value2).getTotalWordCount());
    }
    
    /**
     * Add the two MetaBagOfWords values together. This is the union of the two structures.
     * @param value1 first value.
     * @param value2 second value.
     * @return the values added together.
     * @throws java.lang.Exception any error.
     */
    protected Double add(MetaBagOfWords value1, MetaBagOfWords value2) throws Exception
    {
        return new Double(union(value1, value2).getTotalItemCount());
    }
    
    /**
     * Subtract the second value from the first and return the result.
     * @param valueType the type of the value.
     * @param value1 first value.
     * @param value2 second value.
     * @return the second value subtracted from the first.
     * @throws java.lang.Exception any error.
     */
    public Object subtract(String valueType, Object value1, Object value2)
            throws Exception
    {
        if (value1 == null)
            return value2;
        else if (value2 == null)
            return value1;
        else if (valueType.equals(BagOfWords.class.getName()))
            return subtract((BagOfWords)value1, (BagOfWords)value2);
        else if (valueType.equals(MetaBagOfWords.class.getName()))
            return subtract((MetaBagOfWords)value1, (MetaBagOfWords)value2);
        else
            return super.subtract(valueType, value1, value2);
    }
    
    /**
     * Subtract the values.
     * @param value1 first value.
     * @param value2 second value.
     * @return the subtracted value.
     * @throws java.lang.Exception any error.
     */
    protected Double subtract(BagOfWords value1, BagOfWords value2) throws Exception
    {
        BagOfWords subtracted;                   //values subtracted
       
        subtracted = (value1).subtract(value2);
        return new Double(subtracted.getTotalWordCount());
    }
    
    /**
     * Subtract the values.
     * @param value1 first value.
     * @param value2 second value.
     * @return the subtracted value.
     * @throws java.lang.Exception any error.
     */
    protected Double subtract(MetaBagOfWords value1, MetaBagOfWords value2) throws Exception
    {
        MetaBagOfWords subtracted;                   //values subtracted
        
        subtracted = (MetaBagOfWords)(value1).subtract(value2);
        return new Double(subtracted.getTotalItemCount());
    }
    
    /**
     * Multiply the first value by the second and return the result.
     * @param valueType the type of the value.
     * @param value1 first value.
     * @param value2 second value.
     * @return the first value multiplied by the second.
     * @throws java.lang.Exception any error.
     */
    public Object multiply(String valueType, Object value1, Object value2)
            throws Exception
    {
        if (value1 == null)
            return value2;
        else if (value2 == null)
            return value1;
        else if (valueType.equals(BagOfWords.class.getName()))
            return multiply((BagOfWords)value1, (BagOfWords)value2);
        else if (valueType.equals(MetaBagOfWords.class.getName()))
            return multiply((MetaBagOfWords)value1, (MetaBagOfWords)value2);
        else
            return super.multiply(valueType, value1, value2);
    }
    
    /**
     * Multiply the first value by the second and return the result.
     * @param value1 first value.
     * @param value2 second value.
     * @return the subtracted value.
     */
    protected Double multiply(BagOfWords value1, BagOfWords value2)
    {
        return new Double((double)value1.getTotalWordCount() * (double)value2.getTotalWordCount());
    }
    
    /**
     * Multiply the first value by the second and return the result.
     * @param value1 first value.
     * @param value2 second value.
     * @return the subtracted value.
     */
    protected Double multiply(MetaBagOfWords value1, MetaBagOfWords value2)
    {
        return new Double((double)value1.getTotalItemCount() * (double)value2.getTotalItemCount());
    }
    
    /**
     * Divide the first value by the second and return the result.
     * @param valueType the type of the value.
     * @param value1 first value.
     * @param value2 second value.
     * @return the first value divided by the second.
     * @throws java.lang.Exception any error.
     */
    public Object divide(String valueType, Object value1, Object value2)
            throws Exception
    {
        if (value1 == null)
            return value2;
        else if (value2 == null)
            return value1;
        else if (valueType.equals(BagOfWords.class.getName()))
            return divide((BagOfWords)value1, (BagOfWords)value2);
        else if (valueType.equals(MetaBagOfWords.class.getName()))
            return divide((MetaBagOfWords)value1, (MetaBagOfWords)value2);
        else
            return super.divide(valueType, value1, value2);
    }
    
    /**
     * Divide the first value by the second and return the result.
     * @param value1 first value.
     * @param value2 second value.
     * @return the first value divided by the second.
     */
    protected Double divide(BagOfWords value1, BagOfWords value2)
    {
        return new Double((double)value1.getTotalWordCount() / (double)value2.getTotalWordCount());
    }
    
    /**
     * Divide the first value by the second and return the result.
     * @param value1 first value.
     * @param value2 second value.
     * @return the first value divided by the second.
     */
    protected Double divide(MetaBagOfWords value1, MetaBagOfWords value2)
    {
        return new Double((double)value1.getTotalItemCount() / (double)value2.getTotalItemCount());
    }
}
