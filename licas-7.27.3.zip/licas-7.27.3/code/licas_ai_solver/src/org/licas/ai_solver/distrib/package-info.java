/**
 * Distributed solution, where clustering modules can create links between services,
 * but currently mostly in the core licas package.
 */
package org.licas.ai_solver.distrib;