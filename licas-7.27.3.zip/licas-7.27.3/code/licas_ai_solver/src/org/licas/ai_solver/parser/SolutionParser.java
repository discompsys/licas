/*
 * SolutionParser.java
 *
 * Created on 6 April 2010
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.parser;


import org.licas.ai_solver.model.Solution;
import org.licas_xml.abs.*;


/**
 * This class parses a solution description of type {@link Solution} to or from XML.
 * @author Kieran Greer
 */
public abstract class SolutionParser
{
    /** Create a new instance of SolutionParser */
    public SolutionParser()
    {}

    /**
     * Serialize a solution description into xml.
     * @param solution the solution description.
     * @return an xml description of the solution.
     * @throws Exception any error.
     */
    public abstract Element serialize(Solution solution) throws Exception;

    /**
     * Parse the XML back into a solution object.
     * @param rootElem the root element of the xml description.
     * @return a parsed solution object.
     * @throws java.lang.Exception any error.
     */
    public abstract Solution parse(Element rootElem) throws Exception;
}
