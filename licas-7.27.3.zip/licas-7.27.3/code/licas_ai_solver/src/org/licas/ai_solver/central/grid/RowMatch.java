/*
 * RowMatch.java
 *
 * Created on 2 December 2021
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.central.grid;


import java.util.ArrayList;


/**
 * This class stores the details of two matching grid rows or cells.
 * @author Kieran Greer
 */
public class RowMatch
{
    /**
     * The first cell index.
     * This is either the row or column index from solution 1, where position is then the other coord.
     */
    public int firstIndex;

    /**
     * The second cell index.
     * This is either the row or column index from solution 2, where position is then the other coord.
     */
    public int secondIndex;

    /** The matching value */
    public double value;

    /**
     * The position of the cells along the column or row. This is the same for
     * both cells. For example, if the cell row indexes are 1 and 3, this could
     * relate to column position 5, where the cells are [1, 5] and [3, 5]. Or
     * vice versa for column indexes.
     */
    public int position;

    /** Matching band array - make float to store any value */
    public float[] band;


    /** Create a new instance of RowMatch */
    public RowMatch()
    {
        firstIndex = -1;
        secondIndex = -1;
        value = 0.0;
        position = 0;
        band = null;
    }
    
    /**
     * Get a string-based description of this row match.
     * @return a string-based description of this object.
     */
    public String toString()
    {
        String matchStr;                        //match string
        
        matchStr = "";
        matchStr += ("Soln 1: " + String.valueOf(firstIndex));
        matchStr += (", soln 2: " + String.valueOf(secondIndex));
        matchStr += (", value: " + String.valueOf(value));
        matchStr += (", position: " + String.valueOf(position));
        matchStr += ("\nBand: " + String.valueOf(band));
        matchStr += ("\n");
        
        return matchStr;
    }
    
    /**
     * Clone and return a copy of this row match.
     * @return a copy of this cell match.
     */
    public Object clone()
    {
        RowMatch cloneMatch;                    //clone copy
        
        cloneMatch = new RowMatch();
        cloneMatch.firstIndex = firstIndex;
        cloneMatch.secondIndex = secondIndex;
        cloneMatch.value = value;
        cloneMatch.position = position;
        cloneMatch.band = band;

        return cloneMatch;
    }

    /**
     * Create a clone of the list of cells.
     * @param cells the cells to clone.
     * @return a new copy of the cloned cells list.
     */
    public static ArrayList cloneCells(ArrayList cells)
    {
        int i;
        RowMatch nextEntry;                     //next entry
        RowMatch newEntry;                      //new entry
        ArrayList cellsClone;                   //copy of the cells

        cellsClone = new ArrayList();
        for (i = 0; i < cells.size(); i++)
        {
            nextEntry = (RowMatch)cells.get(i);
            newEntry = (RowMatch)nextEntry.clone();
            cellsClone.add(newEntry);
        }

        return cellsClone;
    }
}
