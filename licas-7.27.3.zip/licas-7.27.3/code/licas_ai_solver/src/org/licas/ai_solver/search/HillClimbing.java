/*
 * HillClimbing.java
 *
 * Created on 8 July 2015
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.search;


import org.licas.ai_solver.model.central.SearchSolution;
import org.licas.ai_solver.model.result.MatchPair;
import org.licas.ai_solver.model.EvalBounds;
import org.licas.ai_solver.model.result.MatchPairName;
import org.licas.ai_solver.spec.test.TestSpec;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.util.*;


/**
 * Hill Climbing search technique to find local optima.
 * @author Kieran Greer.
 */
public class HillClimbing extends SearchFramework
{
    /** For logging */
    private static final Logger logger;
    
    
    /** Number of solutions to keep at each iteration */
    protected int beamWidth;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(HillClimbing.class.getName());
        logger.setDebug(false);
    }
    
    
    /** 
     * Create a new instance of HillClimbing.
     * @param testSpec with any other test spec parameters, such as a beam width.
     * @throws java.lang.Exception any error.
     */
    public HillClimbing(TestSpec testSpec) throws Exception
    {
        super(testSpec);
        initialise(testSpec);
    }
    
    /** 
     * Initialise some values.
     * @param testSpec with any other test spec parameters, such as a beam width.
     */
    private void initialise(TestSpec testSpec)
    {
        beamWidth = testSpec.getTestScript().maxSolutionNum;
    }
    
   /**
    * Search for the best solution set to the problem.
    * @return the list of best solutions.
    * @throws java.lang.Exception any error.
    */
    public ArrayList<MatchPair> solve() throws Exception
    {
        int i, j;
        boolean solutionAdded;                      //true if solution added
        int bestIndex;                              //best index
        ArrayList<EvalBounds> solutionResults;      //list of solution results
        ArrayList<MatchPairName> solutionIndexes;   //list of solution index descr
        ArrayList<MatchPair> bestValueList;         //best value list
        SearchSolution nextSolution;                //next solution
        SearchSolution nextSolution2;               //next solution
        MatchPairName solnMatch;                    //solution match
        EvalBounds nextResult;                      //next result
        Object bestValue;                           //best value
        Object nextValue;                           //next value
        
        try
        {
            solutionResults = new ArrayList<>();
            solutionIndexes = new ArrayList<>();
            bestValueList = new ArrayList<>();
            
            //list of compound indexes to evaluate
            //if both already in a cluster then cannot add again
            for (i = 0; i < (solutions.size()-1); i++)
            {
                nextSolution = (SearchSolution) solutions.get(i);
                for (j = i+1; j < solutions.size(); j++)
                {
                    nextSolution2 = (SearchSolution) solutions.get(j);
                    nextSolution.solve(nextSolution2);

                    solnMatch = new MatchPairName();
                    solnMatch.firstName = nextSolution.getName();
                    solnMatch.secondName = nextSolution2.getName();

                    solutionIndexes.add(solnMatch);
                    solutionResults.add(nextSolution.getEvaluation());
                }
            }
            
            //store the best beam width number of solutions
            //any non-clustered solution with any other one
            solutionAdded = true;
            while (solutionAdded && (bestValueList.size() < beamWidth))
            {
                solutionAdded = false;
                bestIndex = -1;
                bestValue = null;

                for (i = 0; i < solutionIndexes.size(); i++)
                {
                    nextResult = solutionResults.get(i);
                    nextValue = nextResult.evaluation;
                    if (insideRange(nextValue)) {
                        if (bestValue == null) {
                            bestIndex = i;
                            bestValue = nextValue;
                        }
                        else {
                            try {
                                if (valueCompare.isBetter(datasetType, bestValue, nextValue)) {
                                    bestIndex = i;
                                    bestValue = nextValue;
                                }
                            }
                            catch (Exception nex) {
                                //in case result is numerical and dataset is complex
                                if (valueCompare.isBetter(Double.class.getName(), bestValue, nextValue)) {
                                    bestIndex = i;
                                    bestValue = nextValue;
                                }
                            }
                        }
                    }
                }
                
                //add to list and sort remaining
                if (bestIndex >= 0) {
                    solutionAdded = true;
                    solnMatch = solutionIndexes.get(bestIndex);
                    solutionIndexes.remove(bestIndex);                   
                    bestValueList.add(solnMatch);
                }
            }
            
            return bestValueList;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "solve", null, ex);
        }
    }
}
