/**
 * Problem specifications deal more with defining the problem itself and managing solution
 * execution sequences.
 */
package org.licas.ai_solver.mediator.problem;