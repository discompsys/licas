/*
 * KnnProblemScriptParser.java
 *
 * Created on 29 March 2016.
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.parser;


import org.licas.ai_solver.spec.*;
import org.licas.ai_solver.util.SolverConst;
import org.licas.PasswordHandler;
import org.licas.util.Const;

import org.ai_heuristic.util.AiHeuristicConst;
import org.licas_xml.abs.*;

import java.util.*;


/**
 * This class parses a problem script description of type {@link KnnProblemScript}, 
 * to or from XML. It should be called indirectly through the {@link ProblemScriptParser} class.
 * @author Kieran Greer
 */
public class KnnProblemScriptParser extends ProblemScriptParser
{
    /** 
     * Create a new instance of KnnProblemScriptParser.
     * @param thePasswordHandler for storing passwords.
     */
    public KnnProblemScriptParser(PasswordHandler thePasswordHandler)    
    {
        super(thePasswordHandler);
    }
    
    
    /**
     * Serialize the test script into XML.
     * @param testScript the test script to serialize. Of type {@link KnnProblemScript}.
     * @param forDisplay if true, create output for display purposes only.
     * @return the script in XML format.
     * @throws java.lang.Exception any error. 
     */
    public Element serialize(ProblemScript testScript, boolean forDisplay) 
            throws Exception
    {
        Element nextElem;                       //next element
        Element nextElem2;                      //next element
        Element scriptElem;                     //script element
        KnnProblemScript knnScript;             //knn script
        
        knnScript = (KnnProblemScript)testScript;
        scriptElem = super.serialize(knnScript, forDisplay);        
        if ((scriptElem != null) && (knnScript != null))
        {
            //solver configuration options
            nextElem = scriptElem.getChild(SolverConst.SOLVEROPTIONS);
            if (nextElem == null)
            {
                nextElem = XMLFactory.getInstance().createElement(SolverConst.SOLVEROPTIONS);                   
                nextElem.addContent(nextElem);
            }
            
            if (knnScript.knnConfig.k > 0)
            {
                nextElem2 = XMLFactory.getInstance().createElement(AiHeuristicConst.KNN);                   
                nextElem2.setText(String.valueOf(knnScript.knnConfig.k));
                nextElem.addContent(nextElem2);
            }
            if (knnScript.knnConfig.bucketSize > 0)
            {
                nextElem2 = XMLFactory.getInstance().createElement(AiHeuristicConst.BS);                   
                nextElem2.setText(String.valueOf(knnScript.knnConfig.bucketSize));
                nextElem.addContent(nextElem2);
            }
        }
        
        return scriptElem;
    }
    
    /**
     * Parse the file path to create a test script for creating the test scenario from.
     * @param scriptXml the script document in XML format.
     * @return the created test script object.
     * @throws java.lang.Exception any error.
     */
    public KnnProblemScript parse(Element scriptXml) throws Exception
    {
        int i;
        String nextValue;                                   //next value
        Vector elemList;                                    //element list
        Node nextNode;                                      //next node
        Element nextElem;                                   //next element
        KnnProblemScript testScript;                        //the test script
                        
        testScript = new KnnProblemScript(passwordHandler);    
        testScript.copy(super.parse(scriptXml));
        
        if (scriptXml.getName().equals(Const.TESTSCRIPT))
        {
            nextElem = scriptXml.getChild(SolverConst.SOLVEROPTIONS);
            if (nextElem != null)
            {
                elemList = nextElem.getChildren();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);
                    if (nextNode instanceof Element)
                    {
                        nextElem = (Element)nextNode; 
                        if (nextElem.getName().equals(AiHeuristicConst.KNN))
                        {
                            try {
                                nextValue = nextElem.getText().trim();
                                testScript.knnConfig.k = Integer.parseInt(nextValue);
                            } catch (Exception ex2) {}
                        }
                        else if (nextElem.getName().equals(AiHeuristicConst.BS))
                        {
                            try {
                                nextValue = nextElem.getText().trim();
                                testScript.knnConfig.bucketSize = Integer.parseInt(nextValue);
                            } catch (Exception ex2) {}
                        }
                    }
                }
            }
        }
        
        return testScript;
    }
}
