/*
 * SomConst.java
 *
 * Created on 22 October 2014
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.central;


import org.ai_heuristic.functs.*;
import org.ai_heuristic.data.LearningData;
import org.ai_heuristic.algo.cluster.som.kohonen.*;
import org.ai_heuristic.algo.cluster.som.neighbourhood.*;
import org.ai_heuristic.algo.cluster.som.topology.*;
import org.ai_heuristic.algo.cluster.som.network.NetworkModel;
import org.ai_heuristic.util.AiHeuristicConst;

import java.util.*;


/**
 * This class stores some constant values relating specifically to the SOM neural network.
 * @author Kieran Greer
 */
public class SomConst
{
    /** SOM Learning Framework tag */
    public static String LEARNFRAMEWORK = "Learning_Framework";
    
    /** Learning Function tag */
    public static String LEARNFUNCTION = "Learning_Function";
    
    /** Neighbourhood Function tag */
    public static String NEIGHBOURHOODFUNCION = "Neighbourhood_Function";
    
    /** Activation Function tag */
    public static String ACTIVATIONFUNCION = "Activation_Function";
    
    /** Topology tag */
    public static String TOPOLOGY = "Topology";
    
    /** Topology row tag */
    public static String TOPOLOGYROW = "Topology_Row";
    
    /** Topology column tag */
    public static String TOPOLOGYCOL = "Topology_Column";
    
    /** Topology radius tag */
    public static String TOPOLOGYRADIUS = "Topology_Radius";
    
    /** Evaluation Metric tag */
    public static String METRIC = "Metric";
    
    /** Number of weights tag */
    public static String WEIGHTSNUMBER = "Weights_Number";
    
    
    /** WTA Learning Function */
    public static String WTALEARN = "WTA Learning Function";
    
    /** WTA Learning Function with Tired */
    public static String WTALEARNTIRED = "WTA Learning Function with Tired";
    
    /** WTM Learning Function */
    public static String WTMLEARN = "WTM Learning Function";
    
    /** WTM Learning Function with Tired */
    public static String WTMLEARNTIRED = "WTM Learning Function with Tired";
    
    
    /** Fraction Neighbourhood Function Model */
    public static String FRACTIONNEIGHBOURHOOD = "Fraction Neighbourhood";
 
    /** Gauss Neighbourhood Function Model */
    public static String GAUSSNEIGHBOURHOOD = "Gauss Neighbourhood";
    
    
    /** Matrix Topology */
    public static String MATRIXTOPOLOGY = "Matrix Topology";
 
    /** Hexagonal Topology */
    public static String HEXTOPOLOGY = "Hex Topology";
    
    
    /**
     * Return true if the function type is a WTA one, false if a WTM one.
     * @param learningFunctionType the learning function type.
     * @return true if WTA, false otherwise.
     */
    public static boolean isWTA(String learningFunctionType)
    {
        if (learningFunctionType != null) {
            return (learningFunctionType.equals(WTALEARN) ||
                    learningFunctionType.equals(WTALEARNTIRED));
        }
        
        return false;
    }
    
    /**
     * Get a list of the default learn frameworks.
     * @return a list of the default learn function types.
     */
    public static ArrayList<String> somLearnFrameworks()
    {
        ArrayList<String> funcTypes;            //function types
        
        funcTypes = new ArrayList<>();
        funcTypes.add(WTALEARN);
        funcTypes.add(WTALEARNTIRED);
        funcTypes.add(WTMLEARN);
        funcTypes.add(WTMLEARNTIRED);
        
        return funcTypes;
    }
    
    /**
     * Create and return the appropriate learning framework for the specified type.
     * @param learningType the learning framework type.
     * @param params constructor parameters.
     * @return the learning function, or null if the wrong config.
     */
    public static LearningFunction createLearningFramework(String learningType, ArrayList<?> params)
    {
        if (learningType != null) {
            if (learningType.equals(WTALEARN)) {
                return new WTALearningFunction((NetworkModel)params.get(0), ((Integer)params.get(1)).intValue(), (LearningData)params.get(2));
            }
            else if (learningType.equals(WTALEARNTIRED)) {
                return new WTALearningFunctionWithTired((NetworkModel)params.get(0), ((Integer)params.get(1)).intValue(), (LearningData)params.get(2));
            }
            else if (learningType.equals(WTMLEARN)) {
                return new WTMLearningFunction((NetworkModel)params.get(0), ((Integer)params.get(1)).intValue(), (FunctionMetric)params.get(2), 
                        (LearningData)params.get(3), (FunctionLearn)params.get(4), (NeighbourhoodFunctionModel)params.get(5));
            }
            else if (learningType.equals(WTMLEARNTIRED)) {
                return new WTMLearningFunctionWithTired((NetworkModel)params.get(0), ((Integer)params.get(1)).intValue(), (FunctionMetric)params.get(2), 
                        (LearningData)params.get(3), (FunctionLearn)params.get(4), (NeighbourhoodFunctionModel)params.get(5));
            }
        }
        
        return null;
    }
    
    /**
     * Create and return the appropriate topology for the specified type.
     * @param topType the topology type.
     * @param rowNumber number of rows. Larger than 0.
     * @param colNumber number of columns. Larger than 0.
     * @param radius radius of influence. Can be 0.
     * @return the topology model, or null if the wrong config.
     */
    public static TopologyModel createTopology(String topType, int rowNumber, int colNumber, int radius)
    {
        if (topType != null) {
            if (topType.equals(MATRIXTOPOLOGY)) {
                return new MatrixTopology(rowNumber, colNumber, radius);
            }
            else if (topType.equals(HEXTOPOLOGY)) {
                return new HexagonalTopology(rowNumber, colNumber, radius);
            }
        }
        
        return null;
    }
    
    /**
     * Create and return the appropriate learning function for the specified type.
     * @param funcType the learning function type.
     * @param params constructor parameters.
     * @return the function model, or null if the wrong config.
     */
    public static NeighbourhoodFunctionModel createNeighbourhoodFunctionModel(String funcType, HashMap<String, ?> params)
    {
        int intParam;                               //int parameter
        
        if (funcType != null) {
            if (funcType.equals(FRACTIONNEIGHBOURHOOD)) {
                return new FractionNeighbourhoodFunction();
            }
            else if (funcType.equals(GAUSSNEIGHBOURHOOD)) {
                if (params.containsKey(AiHeuristicConst.GFR)) {
                    intParam = ((Integer)params.get(AiHeuristicConst.GFR)).intValue();
                    return new GaussNeighbourhoodFunction(intParam);
                }
            }
        }
        
        return null;
    }
}
