/*
 * ModuleSolverFactory.java
 *
 * Created on 11 November 2015
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver;


import org.licas.PasswordHandler;
import org.jlog2.*;


/**
 * This solver factory is read automatically by the GUI when loaded, to store a
 * pre-programmed script of the services it provides. The services listed here are
 * added to the default list.
 * @author Kieran Greer.
 */
public abstract class ModuleSolverFactory extends SolverFactory
{
    /** The logger */
    private static Logger logger;
    
    
    static
    {
        try
        {
            // get the logger
            logger = LoggerHandler.getLogger(ModuleSolverFactory.class.getName());
            logger.setDebug(false);
        }
        catch (Exception ex) {}
    }

    /**
     * Create a new instance of ModuleSolverFactory.
     * @param thePasswordHandler the main program password handler.
     */
    public ModuleSolverFactory(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
    }
}
