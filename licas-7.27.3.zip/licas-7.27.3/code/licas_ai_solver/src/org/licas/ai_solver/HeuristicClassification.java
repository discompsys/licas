/*
 * HeuristicClassification.java
 *
 * Created on 30 January 2016
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.ai_heuristic.model.FactoryInfo;
import java.util.*;


/**
 * This class describes the methods to classify the different heuristic types. 
 * This class is typically used by the other heuristic factory implementors to
 * determine type or return general information.
 * @author Kieran Greer
 */
public abstract class HeuristicClassification 
{
    /** 
     * Create a new instance of HeuristicClassification. 
     */
    public HeuristicClassification()
    {}
    
    
    /**
     * Return true if the heuristic type is a known type.
     * The method returns false in this base class, so overwrite if you add a new heuristic type.
     * @param heuristicType the heuristic type.
     * @return true if a possible heuristic type.
     */
    public boolean isHeuristic(String heuristicType)
    {
        return false;
    }
    
    /**
     * Return true if the framework type is a recognised centralised type.
     * The method returns false in this base class, so overwrite if you add a new framework type.
     * @param solverType the solver framework the test is run on.
     * @return true if a centralised type.
     */
    public boolean isCentralised(String solverType)
    {
        return false;
    }
    
    /**
     * Get a factory info object for the specified heuristic or evaluator type.
     * @param heuristicType the AI type to check for.
     * @return a factory info object with related information.
     */
    public abstract FactoryInfo getFactoryInfo(String heuristicType);
}
