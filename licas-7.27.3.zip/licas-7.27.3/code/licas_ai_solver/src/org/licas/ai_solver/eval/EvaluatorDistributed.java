/*
 * EvaluatorDistributed.java
 *
 * Created on 8 January 2020
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.eval;


import org.licas.ai_solver.mediator.problem.ProblemMediator;
import org.licas.ai_solver.spec.test.TestSpec;


/**
 * This class should be implemented by any evaluation framework, to mediate between
 * the problem-solver and the services that are part of a distributed problem solving process.
 * @author Kieran Greer
 */
public abstract class EvaluatorDistributed extends Evaluator
{
    /** Create a new instance of EvaluatorDistributed */
    public EvaluatorDistributed()
    {
        super();
    }
    
    /**
     * Run a set of tests based on the test specification.
     * @param testSpec the specification describing the tests to run.
     * @param probMediator the model of the problem with all required elements.
     * @return true if the current test results are better than the previous set.
     * @throws Exception any error.
     */
    public abstract boolean evaluateSolutions(TestSpec testSpec, ProblemMediator probMediator)
            throws Exception;
}
