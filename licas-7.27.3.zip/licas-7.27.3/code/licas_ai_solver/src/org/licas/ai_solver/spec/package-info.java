/**
 * Problem-solver specifications and descriptions that define how and what tests are run,
 * and also start the problem-solving process. 
 */
package org.licas.ai_solver.spec;