/*
 * ClusterStatsDef.java
 *
 * Created on 25 July 2011
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.def;


import org.licas.ai_solver.model.result.MatchResult;
import org.licas.ai_solver.mediator.problem.GridProblemMediator;


/**
 * This interface should be implemented by any statistical clustering process, to be
 * used with the rest of the system without requiring any further changes.
 * @author Kieran Greer
 */
public interface ClusterStatsDef
{
    /**
     * Calculate the stats. These should be calculated based on the clusters that
     * have been generated from the problem-solving process. The stats results can then
     * be used to define network links, or the final cluster values, etc.
     * @param problemSpec the whole problem specification with a list of all solutions.
     * @param solutionSet the problem solving solution set. This is the object that
     * the problem solver returns and contains the problem solver clustering solution.
     * @throws java.lang.Exception any error.
     */
    void calcStats(GridProblemMediator problemSpec, MatchResult solutionSet) throws Exception;
}
