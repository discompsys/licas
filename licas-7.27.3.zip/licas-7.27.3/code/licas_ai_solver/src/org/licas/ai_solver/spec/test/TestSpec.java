/*
 * TestSpec.java
 *
 * Created on 23 March 2010
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.spec.test;


import org.licas.PasswordHandler;
import org.licas.ai_solver.spec.ProblemScript;


/**
 * This class should be extended by all test specification classes. This base class
 * contains all the main parameters that might be used for specifying test runs and
 * is sufficient for the default classes supplied with this package.
 * @author Kieran Greer
 */
public class TestSpec
{
    /** For storing passwords */
    protected PasswordHandler passwordHandler;
    
    /** The test script */
    protected ProblemScript problemScript;
    
    
    /** Additional feedback message describing the test runs */
    protected String message;


    /** 
     * Create a new instance of TestSpec, for a local test only, with no password handler.
     */
    public TestSpec()
    {
        passwordHandler = null;
        this.resetValues();
    }

    /**
     * Create a new instance of TestSpec that might be used for service calls.
     * @param thePasswordHandler for storing passwords.
     */
    public TestSpec(PasswordHandler thePasswordHandler)
    {
        passwordHandler = thePasswordHandler;
        this.resetValues();
    }

    /** Reset the values */
    public void resetValues()
    {
        problemScript = new ProblemScript(passwordHandler);
        message = null;
    }

    
    /**
     * Set the test specification.
     * @param thisTestScript a test script description of the tests to perform.
     */
    public void setTestScript(ProblemScript thisTestScript)
    {
        problemScript = thisTestScript;
    }
    
    /**
     * get the stored test script with the test specification.
     * @return the value of problemScript.
     */
    public ProblemScript getTestScript()
    {
        return problemScript;
    }

    /**
     * Set a message value for the test run.
     * @param thisMessage a message describing the test run.
     */
    public void setMessage(String thisMessage)
    {
        message = thisMessage;
    }

    /**
     * Get the message describing the test runs.
     * @return the value of message.
     */
    public String getMessage()
    {
        return message;
    }
}
