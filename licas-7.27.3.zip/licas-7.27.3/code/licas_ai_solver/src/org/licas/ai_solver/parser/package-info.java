/**
 * For parsing problem-solver specifications and descriptions. 
 */
package org.licas.ai_solver.parser;