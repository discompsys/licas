/**
 * Problem-solving interface, to help to define the class hierarchy. 
 */
package org.licas.ai_solver.def;