/*
 * CompoundSolution.java
 *
 * Created on 26 February 2010
 *
 * Version 1.2.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.model;


import java.util.*;


/**
 * This class can be used simply as a container for a list of solutions.
 * @author Kieran Greer
 */
public class SolutionContainer extends Solution
{
    /**
     * Ordered list of the names of solutions stored in this compound solution.
     * An ordered list is important for processing and re-processing purposes.
     */
    protected ArrayList<String> solutionNames;

    /**
     * List of solution instances this compound solution stores.
     * Key is the solution name and value is of type {@link Solution} or derived.
     */
    protected LinkedHashMap<String, Solution> solutions;

    /**
     * Create a new instance of SolutionContainer.
     * @param thisName this compound solution name or ID.
     */
    public SolutionContainer(String thisName)
    {
        super(thisName);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        solutionNames = new ArrayList<>();
        solutions = new LinkedHashMap<>();
    }

    /**
     * Add a solution name or id to this compound solution. This would normally
     * be done automatically when the solutions are added in {@code addSolution}, as 
     * two solutions with the same name cannot be added. This option is available
     * for a different usage of this class.
     * @param solutionName the solution name to add.
     * @return true if the name was added or false if it already exists.
     */
    public boolean addSolutionName(String solutionName)
    {
        if (!solutionNames.contains(solutionName)) {
            solutionNames.add(solutionName);
            return true;
        }
        
        return false;
    }
    
    /**
     * Get the list of ordered solution names stored in this solution.
     * @return the value of solutionNames.
     */
    public ArrayList<String> getSolutionNames()
    {
        return solutionNames;
    }

    /**
     * Clear the list of solutions.
     */
    public void clearSolutions()
    {
        solutions.clear();
    }

    /**
     * Add a new solution to this compound solution. This also automatically
     * adds the solution name to the list of solution names, which is also
     * used for ordering the solutions.
     * @param thisSolution the solution to add.
     * @return true if added or false if a solution with that name already exists.
     */
    public boolean addSolution(Solution thisSolution)
    {
        String solutionName;                //the solution name

        solutionName = thisSolution.getName();        
        if (!solutionNames.contains(solutionName)) {
            solutionNames.add(solutionName);
            solutions.put(solutionName, thisSolution);
            return true;
        }

        return false;
    }

    /**
     * Remove the specified solution from the list.
     * @param solutionName the solution name.
     */
    public void removeSolution(String solutionName)
    {
        if (solutionNames.contains(solutionName))
            solutionNames.remove(solutionName);
        
        if (solutions.containsKey(solutionName))
            solutions.remove(solutionName);
    }

    /**
     * Get the solution with the specified name.
     * @param solutionName the solution name.
     * @return the solution if it exists or null if it does not.
     */
    public Solution getSolution(String solutionName)
    {
        if (solutions.containsKey(solutionName))
            return solutions.get(solutionName);
        else
            return null;
    }

    /**
     * Get all solutions stored in this compound solution.
     * @return the value of solutions.
     */
    public LinkedHashMap<String, Solution> getSolutions()
    {
        return solutions;
    }
    
    /**
     * Clone this object to create a copy of the main features.
     * @return a cloned copy of this object.
     */
    public Object clone()
    {
        SolutionContainer newSolution;               //new compound solution
        
        newSolution = new SolutionContainer(name);
        newSolution.solutionNames = (ArrayList)this.solutionNames.clone();
        newSolution.solutions = (LinkedHashMap)this.solutions.clone();
        return newSolution;
    }
}
