/*
 * DefaultChromosome.java
 *
 * Created on 8 April 2011
 *
 * Version 1.3.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.model.genetic;


import org.licas.ai_solver.eval.EvaluateGenData;
import org.licas.ai_solver.model.genetic.genes.EvolveGenes;
import org.ai_heuristic.eval.metric.*;
import org.ai_heuristic.functs.Function;
import org.jlog2.*;

import java.util.*;


/**
 * This represents a default chromosome implementation.
 * @author Kieran Greer
 */
public class DefaultChromosome extends Chromosome
{
    /** For logging */
    private static final Logger logger;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(DefaultChromosome.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of DefaultChromosome.
     * @param thisName the id or name of the chromosome.
     * @param thisGeneList the list of genes that define this chromosome. This is
     * then the evaluation seed of the parent {@link EvaluateGenData} class.
     * @param thisEvolveGenes the definition of how this chromosome will evolve genes.
     * @param evalFunction the evaluation function to use.
     * @throws java.lang.Exception any error.
     */
    public DefaultChromosome(String thisName, MetricDataset thisGeneList, Function evalFunction,
            EvolveGenes thisEvolveGenes) throws Exception
    {
        super(thisName, thisGeneList, evalFunction, thisEvolveGenes);
        initialise();
    }

    /** 
     * Initialise some values
     */
    private void initialise()
    {}

    
    /**
     * Evaluate the fitness of this chromosome. This evaluates the gene list
     * that the chromosome stores and returns some result.
     * @return the fitness evaluation for this chromosome.
     * @throws java.lang.Exception any error.
     */
    public ReplySet evaluateFitness() throws Exception
    {
        MetricCompare dataset;                      //dataset to evaluate
        
        dataset = new MetricCompare(evalSeed, compareDataset);        
        return evaluate(dataset);
    }

    /**
     * Generate a new chromosome by combining this chromosome and the variable passed in.
     * @param thisChromosome the chromosome to combine with.
     * @return the result of the evolution. The evolution process is determined by
     * the evolveGenes object, which can also return null.
     * @throws java.lang.Exception any error.
     */
    public Chromosome evolve(Chromosome thisChromosome) throws Exception
    {
        String newName;                             //new chromosome name
        ArrayList nextGeneList;                     //next chromosome gene list
        ArrayList newGeneList;                      //new chromosome gene list
        Chromosome newChromosome;                   //new chromosome

        nextGeneList = thisChromosome.getEvalSeed().getData();

        //mutate or crossover next gene list with current gene list
        newName = name + "_" + thisChromosome.getName();
        newGeneList = evolveGenes.evolveGenes(evalSeed.getData(), nextGeneList);
        newChromosome = cloneChromosomeLight(newName, MetricDataset.toDataset(evalSeed.getName(),
            evalSeed.getValueType(), newGeneList));
        
        return newChromosome;
    }
}
