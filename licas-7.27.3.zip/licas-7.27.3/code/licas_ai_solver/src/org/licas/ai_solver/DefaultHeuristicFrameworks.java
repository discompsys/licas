/*
 * DefaultHeuristicFrameworks.java
 *
 * Created on 30 January 2016
 *
 * Version 1.2.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.ai_heuristic.model.FactoryInfo;
import java.util.*;

import org.licas.service.InformationService;
import org.licas.service.sci.*;
import org.licas.util.HeuristicConst;
import org.licas.util.MetaConst;


/**
 * This class describes the methods used by the heuristic frameworks. A copy is stored in the
 * {@link HeuristicFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public class DefaultHeuristicFrameworks extends HeuristicFrameworks
{
    /** 
     * Create a new instance of DefaultHeuristicFrameworks. 
     * @param theHeuristicClassif the heuristic classifications.
     * @param theHeuristicModules list of heuristic modules.
     */
    public DefaultHeuristicFrameworks(HeuristicClassification theHeuristicClassif, ArrayList<ModuleHeuristicFactory> theHeuristicModules)
    {
        super(theHeuristicClassif, theHeuristicModules);
    }
    
    
    /**
     * Get a list of possible problem-solving frameworks.
     * @return the list of problem solver frameworks, as {@link FactoryInfo} objects.
     */
    public HashMap getFrameworkTypes()
    {
        int i;
        String nextKey;                             //next key
        Iterator allKeys;                           //all keys
        HashMap typeList;                           //list of types
        HashMap nextTypeList;                       //next type list
        FactoryInfo factoryInfo;                    //service info       
        ModuleHeuristicFactory heuristicFactory;    //module factory
        
        typeList = new HashMap();              
        factoryInfo = heuristicClassif.getFactoryInfo(HeuristicConst.GRIDMATCH);
        typeList.put(HeuristicConst.GRIDMATCH, factoryInfo);

        factoryInfo = heuristicClassif.getFactoryInfo(HeuristicConst.GRIDHILL);
        typeList.put(HeuristicConst.GRIDHILL, factoryInfo);

        factoryInfo = heuristicClassif.getFactoryInfo(HeuristicConst.SEARCHHILL);
        typeList.put(HeuristicConst.SEARCHHILL, factoryInfo);

        factoryInfo = heuristicClassif.getFactoryInfo(HeuristicConst.LINKDISTRIBUTED);
        typeList.put(HeuristicConst.LINKDISTRIBUTED, factoryInfo);

        factoryInfo = heuristicClassif.getFactoryInfo(HeuristicConst.NEARESTNEIGHBOUR);
        typeList.put(HeuristicConst.NEARESTNEIGHBOUR, factoryInfo);
        
        factoryInfo = heuristicClassif.getFactoryInfo(HeuristicConst.SOMNN);
        typeList.put(HeuristicConst.SOMNN, factoryInfo);

        //add from the modules
        for (i = 0; i < heuristicModules.size(); i++)
        {
            heuristicFactory = heuristicModules.get(i);
            if (heuristicFactory.hasHeuristicFrameworks())
            {
                nextTypeList = heuristicFactory.getHeuristicFrameworks().getFrameworkTypes();
                if (nextTypeList != null) 
                {
                    allKeys = nextTypeList.keySet().iterator();
                    while (allKeys.hasNext())
                    {
                        nextKey = (String)allKeys.next();
                        if (!typeList.containsKey(nextKey))
                        {
                            typeList.put(nextKey, nextTypeList.get(nextKey));
                        }
                    }
                }
            }
        }
            
        return typeList;
    }
    
    /**
     * Get a list of default behaviour classes with {@link FactoryInfo} descriptions.
     * @param solverType the problem-solving framework, for example, the Hyper-Heuristic 
     * requires {@code Information} services, or {@code MetaConst.ALL} for any service types.
     * @return a list of appropriate service classes. Key is the classname, value is the info object.
     */
    public HashMap getBehaviourClasses(String solverType)
    {
        int i;
        String nextKey;                                 //next key
        Iterator allKeys;                               //all keys
        HashMap behaviourList;                        //info list
        HashMap nextBehaviourList;                    //info list
        FactoryInfo factoryInfo;                        //service info       
        ModuleHeuristicFactory heuristicFactory;        //module factory
          
        behaviourList = new HashMap();
        if ((solverType == null) || solverType.equals(MetaConst.ALL))
        {
            factoryInfo = heuristicClassif.getFactoryInfo(LinkService.class.getName());
            behaviourList.put(LinkService.class.getName(), factoryInfo);

            factoryInfo = heuristicClassif.getFactoryInfo(InformationService.class.getName());
            behaviourList.put(InformationService.class.getName(), factoryInfo);
        }
        else
        { 
            if (!heuristicClassif.isCentralised(solverType))
            {
                factoryInfo = heuristicClassif.getFactoryInfo(LinkService.class.getName());
                behaviourList.put(LinkService.class.getName(), factoryInfo);
            } 

            factoryInfo = heuristicClassif.getFactoryInfo(InformationService.class.getName());
            behaviourList.put(InformationService.class.getName(), factoryInfo);
        }
        
        //add from the modules
        for (i = 0; i < heuristicModules.size(); i++)
        {
            heuristicFactory = (ModuleHeuristicFactory)heuristicModules.get(i);
            if (heuristicFactory.hasHeuristicFrameworks())
            {
                nextBehaviourList = heuristicFactory.getHeuristicFrameworks().getBehaviourClasses(solverType);
                if (nextBehaviourList != null) 
                {
                    allKeys = nextBehaviourList.keySet().iterator();
                    while (allKeys.hasNext())
                    {
                        nextKey = (String)allKeys.next();
                        if (!behaviourList.containsKey(nextKey))
                        {
                            behaviourList.put(nextKey, nextBehaviourList.get(nextKey));
                        }
                    }
                }
            }
        }
        
        return behaviourList;
    }
}
