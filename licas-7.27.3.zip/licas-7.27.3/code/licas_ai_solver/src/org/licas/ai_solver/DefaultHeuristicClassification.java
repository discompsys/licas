/*
 * DefaultHeuristicClassification.java
 *
 * Created on 30 January 2016
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.ai_heuristic.model.FactoryInfo;
import org.ai_heuristic.algo.cluster.som.kohonen.WTALearningFunction;
import org.ai_heuristic.algo.cluster.som.kohonen.WTALearningFunctionWithTired;
import org.ai_heuristic.algo.cluster.som.kohonen.WTMLearningFunction;
import org.ai_heuristic.algo.cluster.som.kohonen.WTMLearningFunctionWithTired;
import org.ai_heuristic.model.BagOfWords;
import org.ai_heuristic.model.MetaBagOfWords;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas.ai_solver.central.SomConst;
import org.licas.ai_solver.util.SolverConst;
import org.licas.data.gen.*;
import org.licas.module.h_module.cluster.*;
import org.licas.service.*;
import org.licas.service.sci.*;
import org.licas.util.*;

import java.util.*;


/**
 * This class describes the methods to classify the different heuristic types. 
 * This class is typically used by the other heuristic factory implementors to
 * determine type or return general information.
 * @author Kieran Greer
 */
public class DefaultHeuristicClassification extends HeuristicClassification
{
    /** 
     * List of modules automatically loaded in during startup. Of type {@link ModuleHeuristicFactory}.
     */
    protected static ArrayList<ModuleHeuristicFactory> heuristicModules = new ArrayList<>();
    
    /** 
     * Create a new instance of DefaultHeuristicClassification. 
     * @param theHeuristicModules list of heuristic modules.
     */
    public DefaultHeuristicClassification(ArrayList<ModuleHeuristicFactory> theHeuristicModules)
    {
        heuristicModules = theHeuristicModules;
    }
    
    
    /**
     * Return true if the heuristic type is a known type.
     * @param heuristicType the heuristic type.
     * @return true if a possible heuristic type.
     */
    public boolean isHeuristic(String heuristicType)
    {
        int i;
        boolean heuristic;                          //true if a heuristic type
        ModuleHeuristicFactory heuristicFactory;    //module factory
        
        heuristic = (!heuristicType.equals(HeuristicConst.METRICONLY));
        if (!heuristic) {
            //add from the modules
            for (i = 0; (!heuristic) && (i < heuristicModules.size()); i++)
            {
                heuristicFactory = heuristicModules.get(i);
                if (heuristicFactory.hasHeuristicClassification()) {
                    heuristic = heuristicFactory.getHeuristicClassification().isHeuristic(heuristicType);
                }
            }
        }
        
        return heuristic;
    }
    
    /**
     * Return true if the framework type is a recognised centralised type.
     * @param solverType the solver framework the test is run on.
     * @return true if a centralised type.
     */
    public boolean isCentralised(String solverType)
    {
        int i;
        boolean centralised;                        //true if a centralised type
        ModuleHeuristicFactory heuristicFactory;    //module factory
        
        centralised = (solverType.equals(HeuristicConst.GRIDMATCH) || 
                solverType.equals(HeuristicConst.GRIDHILL) || 
                solverType.equals(HeuristicConst.SEARCHHILL) || 
                solverType.equals(HeuristicConst.NEARESTNEIGHBOUR) || 
                solverType.equals(HeuristicConst.SOMNN));
        
        if (!centralised) {
            //add from the modules
            for (i = 0; (!centralised) && (i < heuristicModules.size()); i++)
            {
                heuristicFactory = heuristicModules.get(i);
                if (heuristicFactory.hasHeuristicClassification()) {
                    centralised = heuristicFactory.getHeuristicClassification().isCentralised(solverType);
                }
            }
        }
        
        return centralised;
    }
    
    /**
     * Get a factory info object for the specified heuristic or evaluator type.
     * @param heuristicType the AI type to check for.
     * @return a factory info object with related information.
     */
    public FactoryInfo getFactoryInfo(String heuristicType)
    {
        int i;
        FactoryInfo factoryInfo;                        //info object
        ModuleHeuristicFactory heuristicFactory;        //module factory
        
        factoryInfo = null;
        if (heuristicType != null) {
            factoryInfo = AiHeuristicConst.getAiFactoryInfo(heuristicType);
            if (factoryInfo == null) {
                if (heuristicType.equals(HeuristicConst.GRIDMATCH)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = HeuristicConst.FRAMEWORK;
                    factoryInfo.className = HeuristicConst.GRIDMATCH;
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Grid matching framework with closest best from randomised global.";
                }
                else if (heuristicType.equals(HeuristicConst.GRIDHILL)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = HeuristicConst.FRAMEWORK;
                    factoryInfo.className = HeuristicConst.GRIDHILL;
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Grid matching framework with closest best from local hill-climb.";
                }
                else if (heuristicType.equals(HeuristicConst.SEARCHHILL)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = HeuristicConst.FRAMEWORK;
                    factoryInfo.className = HeuristicConst.SEARCHHILL;
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Centralised agglomerative hill-climbing search framework.";
                }
                else if (heuristicType.equals(HeuristicConst.LINKDISTRIBUTED)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = HeuristicConst.FRAMEWORK;
                    factoryInfo.className = HeuristicConst.LINKDISTRIBUTED;
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Distributed linking framework.";
                }
                else if (heuristicType.equals(HeuristicConst.NEARESTNEIGHBOUR)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = HeuristicConst.FRAMEWORK;
                    factoryInfo.className = HeuristicConst.NEARESTNEIGHBOUR;
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Centralised K Nearest Neighbour framework. KNN, BS. File only.";
                }
                else if (heuristicType.equals(HeuristicConst.SOMNN)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = HeuristicConst.FRAMEWORK;
                    factoryInfo.className = HeuristicConst.SOMNN;
                    factoryInfo.filePath = null;
                    factoryInfo.description = "SOM Neural Network framework. TCOL, TROW, TRAD. File only.";
                }
                else if (heuristicType.equals(HeuristicConst.GENETICALGORITHM)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = AiHeuristicConst.EVALUATOR;
                    factoryInfo.className = HeuristicConst.GENETICALGORITHM;
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Genetic Algorithms heuristic. Crossover and/or Mutate.";
                }
                else if (heuristicType.equals(HeuristicConst.FREQUENCY)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = AiHeuristicConst.EVALUATOR;
                    factoryInfo.className = HeuristicConst.FREQUENCY;
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Cluster on similar association counts. File only.";
                }
                else if (heuristicType.equals(SolverConst.FREQGRIDV1)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = AiHeuristicConst.EVALUATOR;
                    factoryInfo.className = SolverConst.FREQGRIDV1;
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Cluster using Frequency Grid version 1.";
                }
                else if (heuristicType.equals(SolverConst.FREQGRIDV2)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = AiHeuristicConst.EVALUATOR;
                    factoryInfo.className = SolverConst.FREQGRIDV2;
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Cluster using Frequency Grid version 2.";
                }
                else if (heuristicType.equals(HeuristicConst.CONTAINSLINK)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = AiHeuristicConst.EVALUATOR;
                    factoryInfo.className = HM_ContainsLink.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Basic containment evaluation. Defaults to Euclidean distance.";
                }
                else if (heuristicType.equals(HeuristicConst.SINGLELINK)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = AiHeuristicConst.EVALUATOR;
                    factoryInfo.className = HM_SingleLink.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Single closest link evaluation. Defaults to Euclidean distance.";
                }
                else if (heuristicType.equals(HeuristicConst.COMPLETELINK)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = AiHeuristicConst.EVALUATOR;
                    factoryInfo.className = HM_CompleteLink.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Single furthest link evaluation. Defaults to Euclidean distance.";
                }
                else if (heuristicType.equals(SomConst.WTALEARN)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = AiHeuristicConst.EVALUATOR;
                    factoryInfo.className = WTALearningFunction.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Winner takes all learning function. Defaults to double types.";
                }
                else if (heuristicType.equals(SomConst.WTALEARNTIRED)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = AiHeuristicConst.EVALUATOR;
                    factoryInfo.className = WTALearningFunctionWithTired.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Winner takes all WT learning function. Defaults to double types.";
                }
                else if (heuristicType.equals(SomConst.WTMLEARN)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = AiHeuristicConst.EVALUATOR;
                    factoryInfo.className = WTMLearningFunction.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Winner takes most learning function. Defaults to double types.";
                }
                else if (heuristicType.equals(SomConst.WTMLEARNTIRED)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = AiHeuristicConst.EVALUATOR;
                    factoryInfo.className = WTMLearningFunctionWithTired.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Winner takes most WT learning function. Defaults to double types.";
                }
                else if (heuristicType.equals(InformationService.class.getName())) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = ServiceConst.BEHAVIOUR;
                    factoryInfo.className = InformationService.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "A service for information processing. Distributed and resources.";
                }
                else if (heuristicType.equals(LinkService.class.getName())) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = ServiceConst.BEHAVIOUR;
                    factoryInfo.className = LinkService.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "A service for linking with other services.";
                }            
                else if (heuristicType.equals(DataService.class.getName())) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = ServiceConst.BEHAVIOUR;
                    factoryInfo.className = DataService.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "A service for information processing. Single (larger) dataset.";
                }
                else if (heuristicType.equals(StringDataGenerator.class.getName())) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = ServiceConst.DATAGENERATORTYPE;
                    factoryInfo.className = StringDataGenerator.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Generate String values between the min-max sizes.";
                }
                else if (heuristicType.equals(NumberDataGenerator.class.getName())) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = ServiceConst.DATAGENERATORTYPE;
                    factoryInfo.className = NumberDataGenerator.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Generate Integer or Float values between the min-max range.";
                }
                else if (heuristicType.equals(ObjectDataGenerator.class.getName())) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = ServiceConst.DATAGENERATORTYPE;
                    factoryInfo.className = ObjectDataGenerator.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Parse a file to create a Java object of the specified data type.";
                }
                else if (heuristicType.equals(HeuristicConst.BAGOFWORDSTYPE)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = HeuristicConst.EVALUATOR;
                    factoryInfo.className = BagOfWords.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Text-related Bag-of-Words data object.";
                }
                else if (heuristicType.equals(HeuristicConst.METABAGOFWORDSTYPE)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = HeuristicConst.EVALUATOR;
                    factoryInfo.className = MetaBagOfWords.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Text-related Meta-Bag-of-Words data object.";
                }
                else if (heuristicType.equals(HeuristicConst.INTEGERTYPE)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = HeuristicConst.EVALUATOR;
                    factoryInfo.className = Integer.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Simple integer data type.";
                }
                else if (heuristicType.equals(HeuristicConst.FLOATTYPE)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = HeuristicConst.EVALUATOR;
                    factoryInfo.className = Float.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Simple float data type.";
                }
                else if (heuristicType.equals(HeuristicConst.STRINGTYPE)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = HeuristicConst.EVALUATOR;
                    factoryInfo.className = String.class.getName();
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Simple string data type.";
                }
                else if (heuristicType.equals(TypeConst.URI) ||
                        heuristicType.equals(TypeConst.URL)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = HeuristicConst.EVALUATOR;
                    factoryInfo.className = TypeConst.URL;
                    factoryInfo.filePath = null;
                    factoryInfo.description = "Indicates to load from a resource.";
                }
                else if (heuristicType.equals(HeuristicConst.METRICONLY)) {
                    factoryInfo = new FactoryInfo();
                    factoryInfo.serviceType = HeuristicConst.EVALUATOR;
                    factoryInfo.className = HeuristicConst.METRICONLY;
                    factoryInfo.filePath = null;
                    factoryInfo.description = "The metric is the only heuristic that is used.";
                }
            }
            
            if (factoryInfo == null) {
                //add from the modules
                for (i = 0; (factoryInfo == null) && (i < heuristicModules.size()); i++)
                {
                    heuristicFactory = heuristicModules.get(i);
                    if (heuristicFactory.hasHeuristicClassification()) {
                        factoryInfo = heuristicFactory.getHeuristicClassification().getFactoryInfo(heuristicType);
                    }
                }
            }
        }
        
        return factoryInfo;
    }
}
