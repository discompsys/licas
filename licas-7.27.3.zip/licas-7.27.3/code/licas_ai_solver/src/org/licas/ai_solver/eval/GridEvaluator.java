/*
 * GridEvaluator.java
 *
 * Created on 30 August 2010
 *
 * Version 1.3
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.eval;


import org.licas.ai_solver.spec.test.*;
import org.licas.ai_solver.spec.GridProblemScript;
import org.licas.ai_solver.mediator.problem.*;
import org.licas.ai_solver.util.SolverConst;

import org.licas_xml.abs.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;


/**
 * This class runs a set of generic tests on the specified hyper-heuristic grid problem model.
 * This class generates and solves problems based on a generic framework, with a centralised
 * problem-solver that evaluates and evolves solutions architecture.
 * @author Kieran Greer
 */
public class GridEvaluator extends EvaluatorCentral
{
    /** For logging */
    private static final Logger logger;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(GridEvaluator.class.getName());
        logger.setDebug(false);
    }

    /** Create a new instance of GridEvaluator */
    public GridEvaluator()
    {
        super();
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {}

    /**
     * Create or initialise the original problem and solution values.
     * @param testSpec the specification describing the tests to run.
     * @param probMediator the model of the problem with all required elements.
     * @return true if initialised OK, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean initialiseMediator(TestSpec testSpec, ProblemMediator probMediator) throws Exception
    {
        GridProblemMediator gridProbMediator;           //problem spec
        Element origProblem;                            //original problem

        try
        {
            //add original problem to the result element
            gridProbMediator = (GridProblemMediator)probMediator;
            origProblem = XMLFactory.getInstance().createElement(SolverConst.PROBLEM);           
            origProblem.setText("Original Problem Specification: generate from new set");
            
            testResults.addContent(origProblem);

            //set here for some values and again during reset for test run - OK
            gridProbMediator.firstSolutionsAndProblems(testSpec);

            return true;
        }
        catch (Exception ex)
        {
             throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "initialiseMediator", null, ex);
        }
    }
    
    /**
     * Run a set of tests based on the test specification.
     * @param testSpec the specification describing the tests to run.
     * @param probMediator the model of the problem with all required elements.
     * @return true if the current test results are better than the previous set.
     * @throws java.lang.Exception any error.
     */
    public boolean evaluateSolutions(TestSpec testSpec, ProblemMediatorCentral probMediator) throws Exception
    {
        boolean resultsBetter;                      //true if current results better
        GridTestSpec gridTestSpec;                  //test spec
        GridProblemMediator gridProbMediator;       //hyper problem mediator
        
        try
        {
            //run tests on the problems
            resultsBetter = false;
            gridTestSpec = (GridTestSpec)testSpec;
            gridProbMediator = (GridProblemMediator)probMediator;           
            testResults = XMLFactory.getInstance().createElement(SolverConst.ALLRESULTS);   
            
            result = gridProbMediator.solve(testSpec);            
            if (result != null)
            {
                evaluateStats(testSpec, probMediator);
                if (gridProbMediator.updateSolutions(result))
                {
                    resultsBetter = gridProbMediator.getResultsBetter();  

                    //if results not better roll back to previous solution set
                    //but also need to randomise the order for the next test run
                    if (!resultsBetter) 
                    {
                        gridProbMediator.restorePreviousSolutionSet(((GridProblemScript)gridTestSpec.getTestScript()).randomise);
                        gridTestSpec.incRollbackCount();
                    }
                    else
                    {
                        lastTestResult = gridProbMediator.getResultXml();
                        testResults.addContent(lastTestResult);
                        gridTestSpec.resetRollbackCount();
                    }
                }
            }
            else
            {
                resultsBetter = false;
                lastTestResult = gridProbMediator.getResultXml();
                testResults.addContent(lastTestResult);
            }
            
            if (resultsBetter) gridTestSpec.resetRollbackCount();
            return resultsBetter;
        }
        catch (Exception ex)
        {
             throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "evaluateSolutions", null, ex);
        }
    }
}
