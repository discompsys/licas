/*
 * GridTestSpec.java
 *
 * Created on 24 October 2014.
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.spec.test;


import org.licas.PasswordHandler;
import org.licas.ai_solver.spec.GridTestRunsScript;


/**
 * This test specification is specific for the Hyper-heuristic-related tests. That is,
 * The new hh or the hill climbing, using the genetic hh framework.
 * @author Kieran Greer
 */
public class GridTestSpec extends TestSpec
{
    /**
     * Count of the number of times the solutions have been rolled back.
     * This is set to 0 by default.
     */
    protected int rollbackCount;


    /** 
     * Create a new instance of GridTestSpec.
     * @param thePasswordHandler for storing passwords.
     */
    public GridTestSpec(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        this.resetValues();
    }

    /** Reset the values */
    public void resetValues()
    {
        rollbackCount = 0;
    }

    
    /**
     * Return true if the solutions have been rolled back by the maximum allowed
     * number of times.
     * @return true if the maximum number of allowed rollbacks has occurred.
     */
    public boolean rollbacksAtMaximum()
    {
        return (rollbackCount >= ((GridTestRunsScript)problemScript.testRunsScript).rollbacks);
    }
    
    /**
     * Reset the number of times the solutions have been rolled back to 0.
     */
    public void resetRollbackCount()
    {
        rollbackCount = 0;
    }
    
    /**
     * Increment the number of times the solutions have been rolled back.
     */
    public void incRollbackCount()
    {
        rollbackCount++;
    }
}
