/**
 * The problem-solving tests are mediated from the classes of this and sub-packages, 
 * as the central location to send/receive messages, initialise values, etc. 
 */
package org.licas.ai_solver.mediator;