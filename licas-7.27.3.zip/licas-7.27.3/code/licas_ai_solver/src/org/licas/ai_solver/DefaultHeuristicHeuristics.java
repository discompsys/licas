/*
 * DefaultHeuristicHeuristics.java
 *
 * Created on 30 January 2016
 *
 * Version 1.0.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.ai_heuristic.model.FactoryInfo;
import java.util.*;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas.ai_solver.central.SomConst;
import org.licas.util.HeuristicConst;


/**
 * This class describes the methods used by the heuristic heuristics. A copy is stored in the
 * {@link HeuristicFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public class DefaultHeuristicHeuristics extends HeuristicHeuristics
{
    /** 
     * Create a new instance of DefaultHeuristicHeuristics. 
     * @param theHeuristicClassif the heuristic classifications.
     * @param theHeuristicModules list of heuristic modules.
     */
    public DefaultHeuristicHeuristics(HeuristicClassification theHeuristicClassif, ArrayList<ModuleHeuristicFactory> theHeuristicModules)
    {
        super(theHeuristicClassif, theHeuristicModules);
    }

    
    /**
     * Get a list of available heuristic types.
     * @return the list of heuristic types.
     */
    public HashMap<String, FactoryInfo> getAllHeuristicTypes()
    {
        int i;
        String nextKey;                                     //next key
        Iterator<String> allKeys;                           //all keys
        HashMap<String, FactoryInfo> heuristicList;         //info list
        HashMap<String, FactoryInfo> nextHeuristicList;     //info list
        ModuleHeuristicFactory heuristicFactory;            //module factory
        
        heuristicList = new HashMap<>();
        heuristicList.putAll(getCentralHeuristicTypes());
        heuristicList.putAll(getLinkHeuristicTypes());
        
        //add from the modules
        for (i = 0; i < heuristicModules.size(); i++)
        {
            heuristicFactory = heuristicModules.get(i);
            if (heuristicFactory.hasHeuristicHeuristics()) {
                nextHeuristicList = heuristicFactory.getHeuristicHeuristics().getAllHeuristicTypes();
                if (nextHeuristicList != null) {
                    allKeys = nextHeuristicList.keySet().iterator();
                    while (allKeys.hasNext())
                    {
                        nextKey = allKeys.next();
                        if (!heuristicList.containsKey(nextKey)) {
                            heuristicList.put(nextKey, nextHeuristicList.get(nextKey));
                        }
                    }
                }
            }
        }
        
        return heuristicList;
    }
    
    /**
     * Get a list of available heuristic types - genetic, linking type, etc. Can include
     * actual classnames for specific types.
     * @param heuristicType the type of problem solving framework - hyper-compare, 
     * hill-climb, links, etc.
     * @return the list of relevant heuristic types. All types are returned if the 
     * solver type is not recognised.
     */
    public HashMap<String, FactoryInfo> getHeuristicTypes(String heuristicType)
    {
        int i, j;
        String nextKey;                                 //next key
        ArrayList<String> allKeys;                      //list of keys
        HashMap<String, FactoryInfo> typeList;          //list of types
        HashMap<String, FactoryInfo> nextTypeList;      //next list of types
        FactoryInfo factoryInfo;                        //factory info
        ModuleHeuristicFactory heuristicFactory;        //module factory
        
        typeList = new HashMap<>();
        if (heuristicType != null) {
            if (heuristicType.equals(HeuristicConst.SOMNN)) {
                typeList = new HashMap<>();
                allKeys = AiHeuristicConst.learnFunctions();
                for (i = 0; i < allKeys.size(); i++)
                {
                    nextKey = allKeys.get(i);
                    factoryInfo = heuristicClassif.getFactoryInfo(SomConst.WTALEARN);
                    typeList.put(nextKey, factoryInfo);                    
                }
            }
            else if (heuristicClassif.isCentralised(heuristicType)) {
                if (heuristicType.equals(HeuristicConst.SEARCHHILL) ||
                    heuristicType.equals(HeuristicConst.NEARESTNEIGHBOUR)) {
                    typeList = new HashMap<>();
                    factoryInfo = heuristicClassif.getFactoryInfo(HeuristicConst.METRICONLY);
                    typeList.put(HeuristicConst.METRICONLY, factoryInfo);
                }
                else {
                    typeList = getCentralHeuristicTypes();
                }
            }
            else if (heuristicType.equals(HeuristicConst.LINKDISTRIBUTED)) {
                typeList = getLinkHeuristicTypes();
            }
        }

        //add from the modules
        for (i = 0; i < heuristicModules.size(); i++)
        {
            heuristicFactory = heuristicModules.get(i);
            if (heuristicFactory.hasHeuristicHeuristics()) {
                nextTypeList = heuristicFactory.getHeuristicHeuristics().getHeuristicTypes(heuristicType);
                if (nextTypeList != null) {
                    allKeys = new ArrayList(nextTypeList.keySet());
                    for (j = 0; j < allKeys.size(); j++)
                    {
                        nextKey = allKeys.get(j);
                        if (!typeList.containsKey(nextKey)) {
                            typeList.put(nextKey, nextTypeList.get(nextKey));
                        }
                    }
                }
            }
        }
        
        return typeList;
    }
    
    /**
     * Get a list of linking heuristic types.
     * @return the list of heuristic types.
     */
    protected HashMap<String, FactoryInfo> getCentralHeuristicTypes()
    {
        HashMap<String, FactoryInfo> heuristicList;     //info list
        FactoryInfo factoryInfo;                        //service info       
               
        heuristicList = new HashMap<>();
        factoryInfo = heuristicClassif.getFactoryInfo(HeuristicConst.GENETICALGORITHM);
        heuristicList.put(HeuristicConst.GENETICALGORITHM, factoryInfo);
        factoryInfo = heuristicClassif.getFactoryInfo(HeuristicConst.FREQUENCY);
        heuristicList.put(HeuristicConst.FREQUENCY, factoryInfo);
        
        return heuristicList;
    }
    
    /**
     * Get a list of linking heuristic types.
     * @return the list of heuristic types.
     */
    protected HashMap<String, FactoryInfo> getLinkHeuristicTypes()
    {
        HashMap<String, FactoryInfo> heuristicList;     //info list
        FactoryInfo factoryInfo;                        //service info       
               
        heuristicList = new HashMap<>();
        factoryInfo = heuristicClassif.getFactoryInfo(HeuristicConst.CONTAINSLINK);
        heuristicList.put(HeuristicConst.CONTAINSLINK, factoryInfo);       
        factoryInfo = heuristicClassif.getFactoryInfo(HeuristicConst.SINGLELINK);
        heuristicList.put(HeuristicConst.SINGLELINK, factoryInfo);       
        factoryInfo = heuristicClassif.getFactoryInfo(HeuristicConst.COMPLETELINK);
        heuristicList.put(HeuristicConst.COMPLETELINK, factoryInfo);

        return heuristicList;
    }
}
