/*
 * SolutionDef.java
 *
 * Created on 25 November 2015
 *
 * Version 1.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.def;


import org.licas.ai_solver.model.EvalBounds;

import java.util.HashMap;


/**
 * Base interface class for a solution.
 * @author Kieran Greer
 */
public interface SolutionDef
{
    /**
     * Set the solution name.
     * @param thisName the solution name.
     */
    void setName(String thisName);

    /**
     * Get the solution name.
     * @return the value of name.
     */
    String getName();

    /**
     * Set the evaluation value for the result.
     * @param theEvaluation the evaluation value.
     */
    void setEvaluation(EvalBounds theEvaluation);

    /**
     * Get the result that this solution has produced.
     * @return the value of evaluation.
     */
    EvalBounds getEvaluation();
}
