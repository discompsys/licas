/*
 * DefaultSolverMetrics.java
 *
 * Created on 29 January 2016
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.ai_heuristic.functs.*;
import org.licas.data.EvaluateData;
import org.licas.service.sci.SolverMetrics;

import java.util.*;


/**
 * This class describes the methods used by the solver metrics. A copy is stored in the
 * {@link DefaultSolverFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public class DefaultSolverMetrics extends SolverMetrics
{
    /**
     * List of modules automatically loaded in during startup. Of type {@link ModuleSolverFactory}.
     */
    protected static ArrayList solverModules;

    /**
     * Create a new instance of DefaultSolverMetrics.
     * @param theSolverModules list of solver modules.
     */
    public DefaultSolverMetrics(ArrayList theSolverModules)
    {
        solverModules = theSolverModules;
    }
    
    
    /**
     * Create and return the correct function/metric for the input parameters.
     * @param valueType the type of object being evaluated.
     * @param functionType the type of function to create.
     * @return the created evaluation function.
     * @throws java.lang.Exception any error.
     */
    public Function getEvaluationFunction(String valueType, String functionType) 
            throws Exception
    {
        int i;
        Function function;                          //evaluation function
        ModuleSolverFactory moduleFactory;          //module factory
        
        function = getEvaluationFunction(valueType, functionType, null, null);
        if (function == null)
        {
            //add from the modules
            for (i = 0; (function == null) && (i < solverModules.size()); i++)
            {
                moduleFactory = (ModuleSolverFactory)solverModules.get(i);
                if (moduleFactory.hasSolverMetrics())
                {
                    function = moduleFactory.getSolverMetrics().getEvaluationFunction(valueType, functionType);
                }
            }
        }
        
        return function;
    }
    
    /**
     * Create and return the correct function/metric for the input parameters. This calls
     * {@link Function}.{@code createFunction} in the first instance and tries to configure it.
     * @param valueType the type of object being evaluated.
     * @param functionType the type of function to create.
     * @param evaluator the evaluator. Can be null for a default evaluator.
     * @param configParams a list of any input configuration parameters. Can be null for no parameters.
     * @return the created evaluation function.
     * @throws java.lang.Exception any error.
     */
    public Function getEvaluationFunction(String valueType, String functionType,
                                          EvaluateData evaluator, HashMap configParams) throws Exception
    {
        int i;
        Function function;                          //the function
        ModuleSolverFactory moduleFactory;          //module factory
        
        function = super.getEvaluationFunction(valueType, functionType, evaluator, configParams);
        if (function == null)
        {
            //add from the modules
            for (i = 0; (function == null) && (i < solverModules.size()); i++)
            {
                moduleFactory = (ModuleSolverFactory)solverModules.get(i);
                if (moduleFactory.hasSolverMetrics())
                {
                    function = moduleFactory.getSolverMetrics().getEvaluationFunction(valueType, functionType,
                        evaluator, configParams);
                }
            }

            if ((function != null) && (evaluator != null))
            {
                if (evaluator.isCompareFunction()) {
                    function.setEvaluator(evaluator.getMathCompare());
                }
            }
        }

        return function;
    }
}
