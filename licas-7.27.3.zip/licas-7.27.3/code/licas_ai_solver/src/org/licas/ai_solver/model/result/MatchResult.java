/*
 * MatchResult.java
 *
 * Created on 30 June 2017
 *
 * Version 1.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.model.result;


import java.util.*;


/**
 * This class stores a list of matching {@link MatchPair} references, to be used
 * to process two solutions further.
 * @author Kieran Greer
 */
public class MatchResult extends Result
{
    /** 
     * The best solution score. This is the best score achieved from a single
     * evaluation relating to the whole solution process.
     */
    protected double bestScore;
    
    /** 
     * The total solution score, which is all matched scores summed.
     */
    protected double totalScore;
    
    /**
     * The best matching solutions.
     */
    protected ArrayList<MatchPair> matches;
    
    
    /** Create a new instance of MatchResult */
    public MatchResult()    
    {
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        bestScore = 0.0;
        totalScore = 0.0;
        matches = new ArrayList<>();
    }
    
    /**
     * Set the solution best score.
     * @param thisBestScore the best single score obtained.
     */
    public void setBestScore(double thisBestScore)
    {
        bestScore = thisBestScore;
    }
    
    /**
     * Get the best single solution score obtained.
     * @return the value of bestScore.
     */
    public double getBestScore()
    {
        return bestScore;
    }
    
    /**
     * Set the total solution score.
     * @param thisTotalScore the summed score of all matches.
     */
    public void setTotalScore(double thisTotalScore)
    {
        totalScore = thisTotalScore;
    }
    
    /**
     * Get the total solution score obtained.
     * @return the value of totalScore.
     */
    public double getTotalScore()
    {
        return totalScore;
    }
    
    /**
     * Get the average solution score obtained, which s the total score divided by
     * the number of matches.
     * @return the value of totalScore.
     */
    public double getAverageScore()
    {
        if (!matches.isEmpty()) {
            return (totalScore / matches.size());
        }
        
        return totalScore;
    }
    
    /**
     * Set the lists of best matching solutions with related problem datasets.
     * @param thisSolutionMatches the best matching solutions and problem indexes.
 Of type MatchPair.
     */
    public void setSolutionMatches(ArrayList<MatchPair> thisSolutionMatches)
    {
        matches = thisSolutionMatches;
    }
    
    /**
     * Get the lists of best solutions.
     * @return the value of matches. Of type {@link MatchPair}.
     */
    public ArrayList<MatchPair> getSolutionMatches()
    {
        return matches;
    }
    
    /**
     * Get a string-based description of this grid solution.
     * @return string-based description of this object.
     */
    public String toString()
    {
        String solutionStr;                                 //solution as a string
        
        solutionStr = "";
        solutionStr += ("Best score: " + String.valueOf(bestScore));
        solutionStr += ("\nAverage score: " + String.valueOf(totalScore));
        solutionStr += ("\nNumber of solutions: " + String.valueOf(matches.size()));               
        return solutionStr;
    }
}
