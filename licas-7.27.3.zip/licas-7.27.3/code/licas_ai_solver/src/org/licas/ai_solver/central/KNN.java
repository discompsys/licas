/*
 * KNN.java
 *
 * Created on 2 March 2016.
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.central;


import org.ai_heuristic.algo.cluster.NearestNeighbour;
import org.ai_heuristic.eval.metric.MetricDataset;
import org.ai_heuristic.eval.metric.ReplySet;
import org.ai_heuristic.functs.Function;
import org.ai_heuristic.functs.FunctionMetric;
import org.ai_heuristic.util.AiHeuristicConst;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.ai_solver.model.result.Cluster;
import org.licas.ai_solver.model.result.ClusterResult;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * This class can be used to create and run a k-nearest neighbour algorithm from a configuration specification.
 * The clustering algorithm is very basic and so returning the nearest neighbours and doing some other clustering
 * might be preferred.
 * @author Kieran Greer
 */
public class KNN
{
    /** For logging errors */
    private static final Logger logger;


    /** The nearest neighbour algorithm to run. */
    protected NearestNeighbour nn;

    /** Training datasets */
    protected MetricDataset knnDataset;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(KNN.class.getName());
        logger.setDebug(false);
    }

    /**
     * Create a new instance of KNN.
     */
    public KNN()
    {
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        nn = null;
        knnDataset = null;
    }

    /**
     * Initialise the knn.
     * @param knnConfig the configuration setup.
     * @throws Exception any error.
     */
    public void initialiseKnn(KnnConfig knnConfig) throws Exception
    {
        String funcType;                            //function type
        String dataType;                            //data type
        HashMap<String, Object> configParams;       //learning function parameters
        FunctionMetric distanceMetric;              //distance metric

        try {
            configParams = new HashMap<>();
            configParams.put(AiHeuristicConst.KNN, new Integer(knnConfig.k));
            configParams.put(AiHeuristicConst.BS, new Integer(knnConfig.bucketSize));

            dataType = knnConfig.dataType;
            funcType = knnConfig.metric;
            distanceMetric = (FunctionMetric)Function.createFunction(funcType, dataType, configParams);
            configParams.put(AiHeuristicConst.EVALUATOR, distanceMetric);

            knnDataset = knnConfig.dataToDataset();
            nn = new NearestNeighbour(dataType, configParams);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "initialiseKnn",
                    null, ex);
        }
    }

    /**
     * Run the knn algorithm test and return a list with the nearest neighbours only.
     * @return the nearest neighbour clusters.
     * Each entry is a cluster group of data row names.
     * @throws Exception any error.
     */
    public ClusterResult runTest() throws Exception
    {
        int i;
        String clusterKey;                          //cluster key
        ArrayList<ArrayList> clusters;              //lists of clusters
        ArrayList clusterGroup;                     //all connections
        ReplySet reply;                             //evaluation result
        Cluster nextCluster;                        //next cluster
        ClusterResult result;                       //cluster result

        //run the nn algorithm
        reply = nn.evaluate(knnDataset);

        //sort the cluster groups from the run
        result = new ClusterResult();
        clusters = (ArrayList)reply.getValue();

        for (i = 0; i < clusters.size(); i++)
        {
            clusterKey = (AiHeuristicConst.DATAROWPREFIX + (i+1));
            clusterGroup = clusters.get(i);
            nextCluster = new Cluster(clusterKey, clusterGroup);
            result.addCluster(nextCluster);
        }

        return result;
    }
}
