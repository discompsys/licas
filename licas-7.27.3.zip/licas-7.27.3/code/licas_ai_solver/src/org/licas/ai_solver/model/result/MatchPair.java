/*
 * MatchPair.java
 *
 * Created on 29 April 2011
 *
 * Version 1.3
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.model.result;


import org.licas.ai_solver.central.grid.HyperHeuristicGrid;
import java.util.ArrayList;


/**
 * This class stores the details of two matching solutions. This might be used, for example, by the
 * genetic algorithms that would then evolve those solutions. The other fields may not be required
 * and are used by the new {@link HyperHeuristicGrid} hyper-heuristic/grid frameworks.
 * @author Kieran Greer
 */
public abstract class MatchPair
{
    /** The total matching value for all datasets */
    public double totalValue;
    
    /** 
     * The problem dataset indexes that the solutions match over. Not all of the
     * problems need to match for the two solutions to generate a score and so 
     * the datasets that do match are indexed here.
     */
    public ArrayList<Object> problems;
    
    /** 
     * The problem dataset evaluations. These are the actual scores for the matched
     * datasets and map directly to the problem indexes.
     */
    public ArrayList<Object> problemEvals;
    
    
    /**
     * Create a new instance of MatchPair.
     */
    public MatchPair()
    {
        super();
        totalValue = 0.0;
        problems = new ArrayList<>();
        problemEvals = new ArrayList<>();
    }
}
