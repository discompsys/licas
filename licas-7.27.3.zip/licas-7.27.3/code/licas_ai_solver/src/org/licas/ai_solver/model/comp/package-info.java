/**
 * Classes for modelling and storing solutions that compare or aggregate solution sets. 
 */
package org.licas.ai_solver.model.comp;