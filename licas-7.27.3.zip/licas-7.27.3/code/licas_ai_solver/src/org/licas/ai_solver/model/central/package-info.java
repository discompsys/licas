/**
 * Classes for centralised modelling. 
 */
package org.licas.ai_solver.model.central;