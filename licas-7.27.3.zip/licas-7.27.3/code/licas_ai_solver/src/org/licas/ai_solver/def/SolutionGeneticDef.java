/*
 * SolutionGeneticDef.java
 *
 * Created on 25 November 2015
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.def;


import org.licas.ai_solver.model.*;
import org.licas.ai_solver.model.genetic.Chromosome;


/**
 * Additional interface classes for a genetic solution to be used to solve the problem.
 * @author Kieran Greer
 */
public interface SolutionGeneticDef extends SolutionSolveDef
{
    /**
     * Evolve the existing solution to create a new one.
     * @param solutionName the name for the new solution.
     * @param evolveWith the solution to evolve with.
     * @return a new solution that is a mutation of both solutions.
     * @throws java.lang.Exception any error.
     */
    Solution evolve(String solutionName, Solution evolveWith) throws Exception;
    
    /**
     * Set the chromosome or this solution.
     * @param thisChromosome the chromosome.
     */
    void setChromosome(Chromosome thisChromosome);

    /**
     * Get the chromosome that this solution uses.
     * @return the value of chromosome.
     */
    Chromosome getChromosome();
}
