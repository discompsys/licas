/**
 * Implementation of the new hyper-heuristic {@code matching} framework that prefers
 * similarity matches over maximising outright, but used as part of a genetic-algorithm solution. 
 */
package org.licas.ai_solver.central.grid;