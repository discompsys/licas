/*
 * DefaultHeuristicMetrics.java
 *
 * Created on 30 January 2016
 *
 * Version 1.0.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import java.util.*;

import org.ai_heuristic.model.FactoryInfo;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas.ai_solver.util.SolverConst;
import org.licas.util.HeuristicConst;


/**
 * This class describes the methods used by the heuristic metrics. A copy is stored in the
 * {@link HeuristicFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public class DefaultHeuristicMetrics extends HeuristicMetrics
{
    /** 
     * Create a new instance of DefaultHeuristicMetrics. 
     * @param theHeuristicClassif the heuristic classifications.
     * @param theHeuristicModules list of heuristic modules.
     */
    public DefaultHeuristicMetrics(HeuristicClassification theHeuristicClassif, ArrayList<ModuleHeuristicFactory> theHeuristicModules)
    {
        super(theHeuristicClassif, theHeuristicModules);
    }
    
    
    /**
     * Get a list of available versions of an evaluation metric type.
     * @param heuristicType the heuristic type.
     * @return the list of versions of the metric evaluator the heuristic can use.
     */
    public HashMap<String, FactoryInfo> getMetricVersions(String heuristicType)
    {
        int i;
        boolean hasMetrics;                             //true if heuristic has metrics
        String nextKey;                                 //next key
        Iterator<String> allKeys;                       //list of keys
        HashMap<String, FactoryInfo> typeList;          //list of types
        HashMap<String, FactoryInfo> nextTypeList;      //next list of types
        ModuleHeuristicFactory heuristicFactory;        //module factory
        
        typeList = new HashMap<>();
        hasMetrics = (heuristicType.equals(HeuristicConst.METRICONLY) || 
                heuristicType.equals(HeuristicConst.GENETICALGORITHM) ||
                heuristicType.equals(HeuristicConst.SINGLELINK) ||
                heuristicType.equals(HeuristicConst.COMPLETELINK) || 
                heuristicType.equals(HeuristicConst.CONTAINSLINK) ||
                AiHeuristicConst.learnFunctions().contains(heuristicType));

        if (heuristicType != null) {
            if (heuristicType.equals(HeuristicConst.METRICONLY)) {
                typeList.put(HeuristicConst.EUCLIDEANFUNCTION, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.EUCLIDEANFUNCTION));
                typeList.put(HeuristicConst.CITYBLOCKFUNCTION, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.CITYBLOCKFUNCTION));
                typeList.put(HeuristicConst.MINKOWSKIFUNCTION, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.MINKOWSKIFUNCTION));
                typeList.put(HeuristicConst.COSINEFUNCTION, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.COSINEFUNCTION));
                typeList.put(HeuristicConst.JACCARDFUNCTION, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.JACCARDFUNCTION));
                typeList.put(HeuristicConst.INDEXSIMILARITY, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.INDEXSIMILARITY));
                typeList.put(HeuristicConst.LEVENSHTEIN, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.LEVENSHTEIN));
                typeList.put(HeuristicConst.DEMERAULEVENSHTEIN, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.DEMERAULEVENSHTEIN));
                typeList.put(HeuristicConst.HAMMING, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.HAMMING));
                typeList.put(HeuristicConst.JAROWINKLER, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.JAROWINKLER));
                typeList.put(HeuristicConst.KULLBACKLEIBLER, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.KULLBACKLEIBLER));
            }
            else if (heuristicType.equals(HeuristicConst.FREQUENCY)) {
                typeList.put(SolverConst.FREQGRIDV1,
                        heuristicClassif.getFactoryInfo(SolverConst.FREQGRIDV1));
                typeList.put(SolverConst.FREQGRIDV2,
                        heuristicClassif.getFactoryInfo(SolverConst.FREQGRIDV2));
            }
            else if (heuristicType.equals(HeuristicConst.GENETICALGORITHM) ||
                    AiHeuristicConst.learnFunctions().contains(heuristicType)) {
                typeList.put(HeuristicConst.EUCLIDEANFUNCTION, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.EUCLIDEANFUNCTION));
                typeList.put(HeuristicConst.CITYBLOCKFUNCTION, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.CITYBLOCKFUNCTION));
                typeList.put(HeuristicConst.MINKOWSKIFUNCTION, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.MINKOWSKIFUNCTION));
                typeList.put(HeuristicConst.COSINEFUNCTION, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.COSINEFUNCTION));
                typeList.put(HeuristicConst.JACCARDFUNCTION, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.JACCARDFUNCTION));
                typeList.put(HeuristicConst.INDEXSIMILARITY, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.INDEXSIMILARITY));
                typeList.put(HeuristicConst.LEVENSHTEIN, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.LEVENSHTEIN));
                typeList.put(HeuristicConst.DEMERAULEVENSHTEIN, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.DEMERAULEVENSHTEIN));
                typeList.put(HeuristicConst.HAMMING, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.HAMMING));
                typeList.put(HeuristicConst.JAROWINKLER, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.JAROWINKLER));
            }
            else if (heuristicType.equals(HeuristicConst.SINGLELINK) ||
                    heuristicType.equals(HeuristicConst.COMPLETELINK)) {
                typeList.put(HeuristicConst.EUCLIDEANFUNCTION, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.EUCLIDEANFUNCTION));
                typeList.put(HeuristicConst.CITYBLOCKFUNCTION, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.CITYBLOCKFUNCTION));
                typeList.put(HeuristicConst.MINKOWSKIFUNCTION, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.MINKOWSKIFUNCTION));
                typeList.put(HeuristicConst.COSINEFUNCTION, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.COSINEFUNCTION));
                typeList.put(HeuristicConst.JACCARDFUNCTION, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.JACCARDFUNCTION));
                typeList.put(HeuristicConst.INDEXSIMILARITY, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.INDEXSIMILARITY));
                typeList.put(HeuristicConst.LEVENSHTEIN, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.LEVENSHTEIN));
                typeList.put(HeuristicConst.DEMERAULEVENSHTEIN, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.DEMERAULEVENSHTEIN));
                typeList.put(HeuristicConst.HAMMING, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.HAMMING));
                typeList.put(HeuristicConst.JAROWINKLER, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.JAROWINKLER));
            }
            else if (heuristicType.equals(HeuristicConst.CONTAINSLINK)) {
                typeList.put(HeuristicConst.SIMPLEMATHCOMPARE, 
                        heuristicClassif.getFactoryInfo(HeuristicConst.SIMPLEMATHCOMPARE));
            }
        }
        
        //add from the modules
        if (hasMetrics) {
            for (i = 0; i < heuristicModules.size(); i++)
            {
                heuristicFactory = heuristicModules.get(i);
                if (heuristicFactory.hasHeuristicMetrics()) {
                    nextTypeList = heuristicFactory.getHeuristicMetric().getMetricVersions(heuristicType);
                    if (nextTypeList != null) {
                        allKeys = nextTypeList.keySet().iterator();
                        while (allKeys.hasNext())
                        {
                            nextKey = allKeys.next();
                            if (!typeList.containsKey(nextKey)) {
                                typeList.put(nextKey, nextTypeList.get(nextKey));
                            }
                        }
                    }
                }
            }
        }

        return typeList;
    }
}
