/*
 * ErrorResult.java
 *
 * Created on 30 June 2017
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.model.result;


/**
 * This can be used to return a result that indicates an error. 
 * It can store an error message, for example.
 * @author Kieran Greer
 */
public class ErrorResult extends Result
{
    /**
     * Create a new instance of ErrorResult.
     */
    public ErrorResult()
    {
        name = null;        
    }
    
    /**
     * Create a new instance of Result.
     * @param error the error description.
     */
    public ErrorResult(String error)
    {
        super(error);
    }
    
    /**
     * Set the error description.
     * @param thisError the error description.
     */
    public void setError(String thisError)
    {
        name = thisError;
    }
    
    /**
     * Get the error description.
     * @return the value of name.
     */
    public String getError()
    {
        return name;
    }
}
