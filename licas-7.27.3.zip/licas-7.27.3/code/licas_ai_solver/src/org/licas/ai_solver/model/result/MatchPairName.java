/*
 * MatchPairName.java
 *
 * Created on 8 January 2021
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.model.result;


import org.licas.ai_solver.central.grid.HyperHeuristicGrid;


/**
 * This class stores the details of two matching solution names. The other fields may not be required
 * and are used by the new {@link HyperHeuristicGrid} hyper-heuristic/grid frameworks.
 * @author Kieran Greer
 */
public class MatchPairName extends MatchPair
{
    /** The first solution name */
    public String firstName;

    /** The second solution name */
    public String secondName;


    /**
     * Create a new instance of MatchPairName.
     */
    public MatchPairName()
    {
        super();
        firstName = null;
        secondName = null;
    }
    
    /**
     * Get a string-based description of this solution match.
     * @return a string-based description of this object.
     */
    public String toString()
    {
        String solutionStr;                                 //solution as a string
        
        solutionStr = "\nNEXT SOLUTION PAIR:\n";
        solutionStr += ("Soln 1: " + firstName);
        solutionStr += (", soln 2: " + secondName);
        solutionStr += (", value: " + String.valueOf(totalValue));
        solutionStr += ("\nProblem indexes: " + String.valueOf(problems));
        solutionStr += ("\nProblem evaluations: " + String.valueOf(problemEvals));
        solutionStr += "\n";
               
        return solutionStr;
    }
}
