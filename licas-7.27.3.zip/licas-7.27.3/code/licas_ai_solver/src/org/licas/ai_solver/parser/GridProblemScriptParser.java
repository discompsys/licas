/*
 * GridProblemScriptParser.java
 *
 * Created on 27 October 2014.
 *
 * Version 1.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.parser;


import org.licas.ai_solver.spec.*;
import org.licas.ai_solver.util.SolverConst;

import org.licas.PasswordHandler;
import org.licas.util.Const;
import org.licas_xml.abs.*;

import java.util.*;


/**
 * This class parses a problem script description of type {@link GridProblemScript}, 
 * to or from XML. It should be called indirectly through the {@link ProblemScriptParser} class.
 * @author Kieran Greer
 */
public class GridProblemScriptParser extends ProblemScriptParser
{
    /** 
     * Create a new instance of GridProblemScriptParser.
     * @param thePasswordHandler for storing passwords.
     */
    public GridProblemScriptParser(PasswordHandler thePasswordHandler)    
    {
        super(thePasswordHandler);
    }
    
    
    /**
     * Serialize the test script into XML.
     * @param testScript the test script to serialize. Of type {@link GridProblemScript}.
     * @param forDisplay if true, create output for display purposes only.
     * @return the script in XML format.
     * @throws java.lang.Exception any error. 
     */
    public Element serialize(ProblemScript testScript, boolean forDisplay) 
            throws Exception
    {
        Element nextElem;                       //next element
        Element nextElem2;                      //next element        
        Element scriptElem;                     //script element
        GridProblemScript gridScript;           //grid script
        
        gridScript = (GridProblemScript)testScript;
        scriptElem = super.serialize(gridScript, forDisplay);
        if ((scriptElem != null) && (gridScript != null))
        {
            //solver configuration options
            nextElem = scriptElem.getChild(SolverConst.SOLVEROPTIONS);
            if (nextElem == null)
            {
                nextElem = XMLFactory.getInstance().createElement(SolverConst.SOLVEROPTIONS);                   
                scriptElem.addContent(nextElem);
            }

            if (gridScript.maxMatches >= 0)
            {
                nextElem2 = XMLFactory.getInstance().createElement(SolverConst.MAXMATCHES);                   
                nextElem2.setText(String.valueOf(gridScript.maxMatches));
                nextElem.addContent(nextElem2);
            }

            //test run-specific options
            nextElem = scriptElem.getChild(SolverConst.TESTOPTIONS);
            if (nextElem == null)
            {
                nextElem = XMLFactory.getInstance().createElement(SolverConst.TESTOPTIONS);                   
                scriptElem.addContent(nextElem);
            }

            nextElem2 = XMLFactory.getInstance().createElement(SolverConst.OKLINKINC);                   
            nextElem2.setText(String.valueOf(gridScript.okIfLinkInc));
            nextElem.addContent(nextElem2);

            if (((GridTestRunsScript)testScript.testRunsScript).rollbacks >= 0)
            {
                nextElem2 = XMLFactory.getInstance().createElement(SolverConst.ROLLBACKS);                   
                nextElem2.setText(String.valueOf(((GridTestRunsScript)testScript.testRunsScript).rollbacks));
                nextElem.addContent(nextElem2);
            }
            if (((GridTestRunsScript)testScript.testRunsScript).noNewClusters >= 0)
            {
                nextElem2 = XMLFactory.getInstance().createElement(SolverConst.NONEWCLUSTERS);                   
                nextElem2.setText(String.valueOf(((GridTestRunsScript)testScript.testRunsScript).noNewClusters));
                nextElem.addContent(nextElem2);
            }

            nextElem2 = XMLFactory.getInstance().createElement(SolverConst.RANDOMISE);                   
            nextElem2.setText(String.valueOf(gridScript.randomise));
            nextElem.addContent(nextElem2);
        }
        
        return scriptElem;
    }
    
    /**
     * Parse the file path to create a test script for creating the test scenario from.
     * @param scriptXml the script document in XML format.
     * @return the created test script object.
     * @throws java.lang.Exception any error.
     */
    public GridProblemScript parse(Element scriptXml) throws Exception
    {
        int i, j;
        String nextValue;                                   //next value
        Vector elemList;                                    //element list
        Vector elemList2;                                   //element list
        Node nextNode;                                      //next node
        Element nextElem;                                   //next element
        Element nextElem2;                                  //next element
        GridProblemScript testScript;                       //the test script
             
        testScript = new GridProblemScript(passwordHandler);   
        testScript.copy(super.parse(scriptXml));
        
        if (scriptXml.getName().equals(Const.TESTSCRIPT))
        {
            elemList = scriptXml.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode; 
                    if (nextElem.getName().equals(SolverConst.MAXMATCHES))
                    {
                        try {
                            nextValue = nextElem.getText().trim();
                            testScript.maxMatches = Integer.parseInt(nextValue);
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(SolverConst.ROLLBACKS))
                    {
                        try {
                            nextValue = nextElem.getText().trim();
                            ((GridTestRunsScript)testScript.testRunsScript).rollbacks = Integer.parseInt(nextValue);
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(SolverConst.NONEWCLUSTERS))
                    {
                        try {
                            nextValue = nextElem.getText().trim();
                            ((GridTestRunsScript)testScript.testRunsScript).noNewClusters = Integer.parseInt(nextValue);
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(SolverConst.RANDOMISE))
                    {
                        try {
                            nextValue = nextElem.getText().trim();
                            testScript.randomise = Boolean.valueOf(nextValue).booleanValue();
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(SolverConst.SOLVEROPTIONS))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equals(SolverConst.RANGETYPE))
                                {
                                    try {
                                        nextValue = nextElem2.getText().trim();
                                        testScript.similarityRangeAsPercentage = nextValue.equals(SolverConst.PERCENTAGE);
                                    } catch (Exception ex2) {}
                                }
                                else if (nextElem2.getName().equals(SolverConst.RANGEVALUE))
                                {
                                    try {
                                        nextValue = nextElem2.getText().trim();
                                        testScript.rangeValue = Float.parseFloat(nextValue);
                                    } catch (Exception ex2) {}
                                }
                                else if (nextElem2.getName().equals(SolverConst.MAXMATCHES))
                                {
                                    try {
                                        nextValue = nextElem2.getText().trim();
                                        testScript.maxMatches = Integer.parseInt(nextValue);
                                    } catch (Exception ex2) {}
                                }
                                else if (nextElem2.getName().equals(SolverConst.RANDOMISE))
                                {
                                    try {
                                        nextValue = nextElem2.getText().trim();
                                        testScript.randomise = Boolean.valueOf(nextValue).booleanValue();
                                    } catch (Exception ex2) {}
                                }
                                else if (nextElem2.getName().equals(SolverConst.OKLINKINC))
                                {
                                    try {
                                        nextValue = nextElem2.getText().trim();
                                        testScript.okIfLinkInc = Boolean.valueOf(nextValue).booleanValue();
                                    } catch (Exception ex2) {}
                                }
                            }
                        }
                    }
                    else if (nextElem.getName().equals(SolverConst.TESTOPTIONS) ||
                            nextElem.getName().equals(SolverConst.REPEATORSTOP))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem.getName().equals(SolverConst.ADDINKS))
                                {
                                    try {
                                        nextValue = nextElem.getText().trim();
                                        testScript.testRunsScript.addLinks = Boolean.valueOf(nextValue).booleanValue();
                                    } catch (Exception ex2) {}
                                }
                                else if (nextElem2.getName().equals(SolverConst.ROLLBACKS))
                                {
                                    try {
                                        nextValue = nextElem2.getText().trim();
                                        ((GridTestRunsScript)testScript.testRunsScript).rollbacks = Integer.parseInt(nextValue);
                                    } catch (Exception ex2) {}
                                }
                                else if (nextElem2.getName().equals(SolverConst.NONEWCLUSTERS))
                                {
                                    try {
                                        nextValue = nextElem2.getText().trim();
                                        ((GridTestRunsScript)testScript.testRunsScript).noNewClusters = Integer.parseInt(nextValue);
                                    } catch (Exception ex2) {}
                                }
                            }
                        }
                    }
                }
            }
        }
        
        return testScript;
    }
}
