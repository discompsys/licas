/**
 * Base classes for modelling and storing problams and solutions with results. 
 */
package org.licas.ai_solver.model;