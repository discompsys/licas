/*
 * Chromosome.java
 *
 * Created on 8 April 2011
 *
 * Version 1.3.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.model.genetic;


import org.licas.ai_solver.model.genetic.genes.EvolveGenes;
import org.licas.ai_solver.eval.EvaluateGenData;
import org.ai_heuristic.eval.metric.*;
import org.ai_heuristic.functs.Function;


/**
 * This represents a single set of genes for a genetic solution. The chromosome
 * stores all of the components that are used to represent a gene list. To evolve
 * this chromosome, an {@link EvolveGenes} object is created, which is passed two gene
 * lists that it uses to create a new one. The new gene list is then added to a
 * copy of this chromosome to create a new one. The {@code evolve} method is used to
 * create a new set of genes. This is derived from {@link EvaluateGenData} and so also stores 
 * the evaluation function used to compare gene lists. Gene lists are stored as
 * {@code MetricDataset} objects, with each value stored as a {@code MetricValue}.
 * @author Kieran Greer
 */
public abstract class Chromosome extends EvaluateGenData
{
    /**
     * A problem dataset to compare to this chromosome.
     */
    protected MetricDataset compareDataset;

    /** 
     * This is used to combine gene lists to create a new one.
     */
    protected EvolveGenes evolveGenes;


    /**
     * Create a new instance of Chromosome.
     * @param thisName the id or name of the chromosome.
     * @param thisGeneList the list of genes that define this chromosome. This is
     * then the evaluation seed of the parent {@link EvaluateGenData} class.
     * @param evalFunction the evaluation function to use.
     * @param thisMutateGenes the definition of how this chromosome will evolveGenes.
     */
    public Chromosome(String thisName, MetricDataset thisGeneList, Function evalFunction,
            EvolveGenes thisMutateGenes)
    {
        super(thisName, thisGeneList, evalFunction);
        evolveGenes = thisMutateGenes;
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        compareDataset = null;
    }
    

    /**
     * Evaluate the fitness of this chromosome. This evaluates the gene list
     * that the chromosome stores and returns some result.
     * @return the fitness evaluation for this chromosome.
     * @throws java.lang.Exception any error.
     */
    public abstract ReplySet evaluateFitness() throws Exception;

    /**
     * Generate a new chromosome by combining this chromosome and the variable passed in.
     * @param thisChromosome the chromosome to combine with.
     * @return the result of the mutation. Can return null.
     * @throws java.lang.Exception any error.
     */
    public abstract Chromosome evolve(Chromosome thisChromosome) throws Exception;
    
    
    /**
     * Return true if the genes in this chromosome are the same as the genes
     * in the chromosome passed in. This calls the {@link EvolveGenes} {@code areSame} method
     * to make the comparison.
     * @param compareTo the chromosome to compare this chromosome with.
     * @return true if the genes are the same, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean sameAs(Chromosome compareTo) throws Exception
    {
        return evolveGenes.areSame(evalSeed.getData(), compareTo.evalSeed.getData());
    }
    
    /**
     * Set the chromosome name.
     * @param thisName the chromosome name.
     */
    public void setName(String thisName)
    {
        name = thisName;
    }
    
    /**
     * Set the other problem dataset to compare with this chromosome.
     * @param thisCompareDataset the problem dataset.
     */
    public void setCompareDataset(MetricDataset thisCompareDataset)
    {
        compareDataset = thisCompareDataset;
    }

    /**
     * Set the object used to evolve gene lists to create a new one.
     * @param thisEvolveGenes the object used to evolve genes through mutations and crossovers.
     */
    public void setEvolveGenes(EvolveGenes thisEvolveGenes)
    {
        evolveGenes = thisEvolveGenes;
    }

    /**
     * Get the object used to create new gene lists.
     * @return the value of evolveGenes.
     */
    public EvolveGenes getEvolveGenes()
    {
        return evolveGenes;
    }
    
    /**
     * Clone this chromosome to create light copy with other values.
     * @param newName the new chromosome name.
     * @param newGeneList the gene pool for the new chromosome.
     * @return a copy of this chromosome.
     * @throws java.lang.Exception any error.
     */
    protected Chromosome cloneChromosomeLight(String newName, MetricDataset newGeneList) 
            throws Exception
    {
        DefaultChromosome cloneChromosome;          //copy of this chromosome

        cloneChromosome = new DefaultChromosome(newName, newGeneList, evalFunction, evolveGenes);
        return cloneChromosome;
    }
    
    /**
     * Create and return the appropriate chromosome for the specified chromosome
     * type. This implementation returns a DefaultChromosome object only.
     * @param chromosomeType the type of chromosome to create.
     * @param chromosomeID the id or name of the chromosome.
     * @param genesList the list of genes that define this chromosome. This is
     * then the evaluation seed of the parent {@link EvaluateGenData} class.
     * @param evalFunction the evaluation function to use.
     * @param evolveGenes the definition of how this chromosome will evolve genes.
     * @return the created chromosome.
     * @throws java.lang.Exception any error.
     */
    public static Chromosome getChromosome(String chromosomeType, String chromosomeID,
            MetricDataset genesList, Function evalFunction, EvolveGenes evolveGenes) throws Exception
    {
        return new DefaultChromosome(chromosomeID, genesList, evalFunction, evolveGenes);
    }
}
