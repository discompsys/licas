/*
 * Problem.java
 *
 * Created on 6 April 2010
 *
 * Version 1.2.1
 *
 * Copyright (C) Kieran Greer
 */


package org.licas.ai_solver.model;


import org.ai_heuristic.eval.metric.MetricDataset;

import java.util.ArrayList;
import java.util.LinkedHashMap;


/**
 * This class models the problem requirements. These are defined as a set of problems,
 * typically the data that needs to be solved by the solutions. That data could be a list of
 * {@code MetricDataset} objects, for example. Each data object then creates and gets 
 * evaluated by a solution.
 * @author Kieran Greer
 */
public class Problem
{
    /** 
     * A list of problems required to solve the whole problem. This can be of
     * any type. The default implementation would expect to receive a list of
     * problem dataset objects that can also be used to initialise any solutions
     * or evaluators.
     */
    private LinkedHashMap<String, MetricDataset> problemSet;

    /**
     * Create a new instance of Problem.
     */
    public Problem()    
    {
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        problemSet = new LinkedHashMap<>();
    }

    /**
     * Return true if this instance has a litst of problems.
     * @return true if subProblems is not empty.
     */
    public boolean hasProblemSet()
    {
        return ((problemSet != null) && !problemSet.isEmpty());
    }

    /**
     * Clear the list of problems.
     */
    public void clearProblemSet()
    {
        problemSet = new LinkedHashMap<>();
    }

    /**
     * Set the list of problems this problem requires.
     * @param thisProblemSet the set of problems to add.
     */
    public void setProblemSet(LinkedHashMap<String, MetricDataset> thisProblemSet)
    {
        problemSet = thisProblemSet;
    }

    /**
     * Set the list of problems this problem requires. Use the dataset name as the
     * hash table key name.
     * @param thisProblemSet the set of problems to add.
     */
    public void setProblemSet(ArrayList<MetricDataset> thisProblemSet)
    {
        int i;

        problemSet.clear();
        for (i = 0; i < thisProblemSet.size(); i++)
        {
            problemSet.put(thisProblemSet.get(i).getName(), thisProblemSet.get(i));
        }
    }

    /**
     * Add the specified task to the list.
     * @param thisProblem the problem to add. Use the dataset name as the hash table entry key.
     * If there is any ordering to the sub-problems then they should be added
     * in that order. This can be of type Solution or any other Object.
     */
    public void addProblem(MetricDataset thisProblem)
    {
       problemSet.put(thisProblem.getName(), thisProblem);
    }

    /**
     * Get th list of problem names or IDs.
     * @return list of the problem set key values.
     */
    public ArrayList<String> getProblemNames()
    {
        return new ArrayList(problemSet.keySet());
    }

    /**
     * Get the problem with the specified key value.
     * @param problemName problem name key value.
     * @return related problem dataset.
     */
    public MetricDataset getProblem(String problemName)
    {
        return problemSet.get(problemName);
    }

    /**
     * Get the list of sub-problems this problem requires.
     * @return the value of problemSet.
     */
    public LinkedHashMap<String, MetricDataset> getProblemSet()
    {
        return problemSet;
    }
}
