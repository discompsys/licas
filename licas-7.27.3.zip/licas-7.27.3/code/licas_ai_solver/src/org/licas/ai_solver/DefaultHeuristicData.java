/*
 * DefaultHeuristicData.java
 *
 * Created on 30 January 2016
 *
 * Version 1.0.3
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.ai_heuristic.model.FactoryInfo;
import java.util.*;

import org.licas.data.gen.*;
import org.licas.util.HeuristicConst;
import org.licas.util.TypeConst;


/**
* This class describes the methods used by the heuristic data. A copy is stored in the
 * {@link DefaultHeuristicFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public class DefaultHeuristicData extends HeuristicData
{
    /** 
     * Create a new instance of DefaultHeuristicData. 
     * @param theHeuristicClassif the heuristic classifications.
     * @param theHeuristicModules list of heuristic modules.
     */
    public DefaultHeuristicData(HeuristicClassification theHeuristicClassif, ArrayList theHeuristicModules)
    {
        super(theHeuristicClassif, theHeuristicModules);
    }
    
    
    /**
     * Return true if the heuristic type is a known type that can be processed generically.
     * For example, the simple types or Bag-of-Words can be processed by the default
     * evaluators.
     * @param dataType the data object type.
     * @return true if a known type that the evaluators can process.
     */
    public boolean genericDataType(String dataType)
    {
        int i;
        boolean generic;                            //true if a generic type
        ModuleHeuristicFactory heuristicFactory;    //module factory
        
        generic = (dataType.equals(HeuristicConst.INTEGERTYPE)  ||
                dataType.equals(HeuristicConst.FLOATTYPE) ||
                dataType.equals(HeuristicConst.STRINGTYPE) ||
                dataType.equals(TypeConst.URI) ||
                dataType.equals(TypeConst.URL) ||
                dataType.equals(HeuristicConst.BAGOFWORDSTYPE) ||
                dataType.equals(HeuristicConst.METABAGOFWORDSTYPE));
        
        if (!generic)
        {
            //add from the modules
            for (i = 0; (!generic) && (i < heuristicModules.size()); i++)
            {
                heuristicFactory = (ModuleHeuristicFactory)heuristicModules.get(i);
                if (heuristicFactory.hasHeuristicData())
                {
                    generic = heuristicFactory.getHeuristicData().genericDataType(dataType);
                }
            }
        }
        
        return generic;
    }
    
        
    /**
     * Return true if the data type can be used with the genetic algorithms specifically.
     * @param dataType the type of data object that the genetic algorithm might process.
     * @return true if it can be used with genetic algorithms.
     */
    public boolean canBeGeneticType(String dataType)
    {
        int i;
        boolean genetic;                            //true if a genetic type
        ModuleHeuristicFactory heuristicFactory;    //module factory
        
        genetic = (dataType.equals(HeuristicConst.INTEGERTYPE)  ||
                dataType.equals(HeuristicConst.FLOATTYPE) ||
                dataType.equals(HeuristicConst.STRINGTYPE) ||
                dataType.equals(HeuristicConst.BAGOFWORDSTYPE) ||
                dataType.equals(HeuristicConst.METABAGOFWORDSTYPE));
        
        if (!genetic)
        {
            //add from the modules
            for (i = 0; (!genetic) && (i < heuristicModules.size()); i++)
            {
                heuristicFactory = (ModuleHeuristicFactory)heuristicModules.get(i);
                if (heuristicFactory.hasHeuristicData())
                {
                    genetic = heuristicFactory.getHeuristicData().canBeGeneticType(dataType);
                }
            }
        }
        
        return genetic;
    }   
    
    /**
     * Get a list of available data generators.
     * @return the list of data generators.
     */
    public HashMap getDataGenerators()
    {
        int i, j;
        String nextKey;                                 //next key
        Iterator allKeys;                               //list of keys
        HashMap heuristicList;                        //info list
        HashMap nextHeuristicList;                    //next info list
        FactoryInfo factoryInfo;                        //service info       
        ModuleHeuristicFactory heuristicFactory;        //module factory
        
        heuristicList = new HashMap();
        factoryInfo = heuristicClassif.getFactoryInfo(StringDataGenerator.class.getName());
        heuristicList.put(StringDataGenerator.class.getName(), factoryInfo);        
        factoryInfo = heuristicClassif.getFactoryInfo(NumberDataGenerator.class.getName());
        heuristicList.put(NumberDataGenerator.class.getName(), factoryInfo);        
        factoryInfo = heuristicClassif.getFactoryInfo(ObjectDataGenerator.class.getName());
        heuristicList.put(ObjectDataGenerator.class.getName(), factoryInfo);
        
        //add from the modules
        for (i = 0; i < heuristicModules.size(); i++)
        {
            heuristicFactory = (ModuleHeuristicFactory)heuristicModules.get(i);
            if (heuristicFactory.hasHeuristicData())
            {
                nextHeuristicList = heuristicFactory.getHeuristicData().getDataGenerators();
                if (nextHeuristicList != null) 
                {
                    allKeys = nextHeuristicList.keySet().iterator();
                    while (allKeys.hasNext())
                    {
                        nextKey = (String)allKeys.next();
                        if (!heuristicList.containsKey(nextKey))
                        {
                            heuristicList.put(nextKey, nextHeuristicList.get(nextKey));
                        }
                    }
                }
            }
        }
        
        return heuristicList;
    }
    
    /**
     * Get the type of data object that would be evaluated by the heuristic.
     * @param heuristicType the type of heuristic to use.
     * @return the type of object that would be evaluated, or null if unclear.
     */
    public String getObjectType(String heuristicType)
    {
        int i;
        String objectType;                              //object type
        ModuleHeuristicFactory heuristicFactory;        //module factory
        
        objectType = null;
        if (heuristicType.equals(HeuristicConst.INTEGERTYPE))
        {
            objectType = Integer.class.getName();
        }
        else if (heuristicType.equals(HeuristicConst.FLOATTYPE))
        {
            objectType = Float.class.getName();
        }
        else if (heuristicType.equals(TypeConst.URI) ||
                heuristicType.equals(TypeConst.URL))
        {
            objectType = TypeConst.URL;
        }
        else if (heuristicType.equals(HeuristicConst.STRINGTYPE) || 
                heuristicType.equals(HeuristicConst.BAGOFWORDSTYPE) || 
                heuristicType.equals(HeuristicConst.METABAGOFWORDSTYPE))
        {
            objectType = String.class.getName();
        }
        
        if (objectType == null)
        {
            //add from the modules
            for (i = 0; (objectType == null) && (i < heuristicModules.size()); i++)
            {
                heuristicFactory = (ModuleHeuristicFactory)heuristicModules.get(i);
                if (heuristicFactory.hasHeuristicData())
                {
                    objectType = heuristicFactory.getHeuristicData().getObjectType(heuristicType);
                }
            }
        }
        
        return objectType;
    }
}
