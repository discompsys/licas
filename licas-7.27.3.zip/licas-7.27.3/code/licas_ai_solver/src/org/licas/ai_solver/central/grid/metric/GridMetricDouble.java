/*
 * GridMetric.java
 *
 * Created on 28 December 2021
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.central.grid.metric;


import org.licas.util.TypeConst;

/** Compare two sets of double values in the hyper grid */
public class GridMetricDouble<T> implements GridMetric {

    /**
     * Get the data class type.
     * @return class name for the data type of the metric.
     */
    public String dataType()
    {
        return TypeConst.DOUBLE;
    }

    /**
     * Produce a summed value for the two parameter lists, but only for the matching entries.
     * @param list1 the first value list.
     * @param list2 the second value list.
     * @param hMatch true if try to match, false if try largest score.
     * @param asPercentage true if range is a percentage, false if an actual value.
     * @param range score inside-of which a match is true.
     * @return some value representing the summed total.
     */
    public float listSum(Object[] list1, Object[] list2, boolean hMatch, boolean asPercentage, Object range)
    {
        int i;
        int colNum;                         //number of columns
        float totalScore;                   //the total score

        totalScore = 0;
        colNum = (list1.length > list2.length) ? list2.length : list1.length;

        for (i = 0; i < colNum; i++) {
            if (valuesMatch(list1[i], list2[i], hMatch, asPercentage, range) > 0) {
                totalScore += sum(list1[i], list2[i]);
            }
        }

        return totalScore;
    }

    /**
     * Produce a summed value for the two parameters.
     * @param value1 the first value.
     * @param value2 the second value.
     * @return some value representing the summed total.
     */
    public float sum(Object value1, Object value2)
    {
        return (float)((double)value1 + (double)value2);
    }

    /**
     * Return true if hte parameter value represents null, or empty.
     * @param value1 value to consider.
     * @return some value representing the summed total.
     */
    public boolean isNull(Object value1)
    {
        return ((double)value1 == Double.NaN);
    }

    /**
     * Return an appropriate value of the type to represent null, or empty.
     * @return a null-representation for the type.
     */
    public Object getNull()
    {
        return (T) new Double(Double.NaN);
    }

    /**
     * Compare the two values for similarity.
     * @param value1 the first value.
     * @param value2 the second value.
     * @return true if the same, false if different.
     */
    public boolean isSame(Object value1, Object value2)
    {
        return ((double)value1 == (double)value2);
    }

    /**
     * Compare two values lists and return a result.
     * @param list1 the first value.
     * @param list2 the second value. Same size as list1.
     * @param hMatch true if try to match, false if try largest score.
     * @param asPercentage true if range is a percentage, false if an actual value.
     * @param range score inside-of which a match is true.
     * @return the comparison result.
     */
    public float listsMatch(Object[] list1, Object[] list2, boolean hMatch, boolean asPercentage, Object range)
    {
        int i;
        int colNum;                         //number of columns
        float totalScore;                   //the total score

        totalScore = 0;
        colNum = (list1.length > list2.length) ? list2.length : list1.length;

        for (i = 0; i < colNum; i++) {
            totalScore += valuesMatch(list1[i], list2[i], hMatch, asPercentage, range);
        }

        return totalScore;
    }

    /**
     * Compare two values and return a result.
     * @param value1 the first value.
     * @param value2 the second value.
     * @param hMatch true if try to match, false if try largest score.
     * @param asPercentage true if range is a percentage, false if an actual value.
     * @param range score inside-of which a match is true.
     * @return the comparison result.
     */
    public float valuesMatch(Object value1, Object value2, boolean hMatch, boolean asPercentage, Object range)
    {
        double cell1;                           //first value
        double cell2;                           //second value
        double similarityRange;                 //range for similarity score
        double similarityScore;                 //similarity score

        cell1 = (double)value1;
        cell2 = (double)value2;
        similarityRange = (double)range;

        if (hMatch) {
            if (similarityRange == 0.0) {
                return ((cell1 == cell2) ? 1 : 0);
            }
            else {
                if (asPercentage) {
                    if (cell1 >= cell2)
                        similarityScore = (cell1 * similarityRange / 100.0);
                    else
                        similarityScore = (cell2 * similarityRange / 100.0);
                }
                else {
                    similarityScore = similarityRange;
                }

                if (cell1 >= cell2) {
                    return ((cell1 <= (cell2 + similarityScore)) ? 1 : 0);
                }
                else {
                    return ((cell2 <= (cell1 + similarityScore)) ? 1 : 0);
                }
            }
        }

        return 1;
    }
}
