/*
 * SolutionSolveDef.java
 *
 * Created on 8 January 2020
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.def;


import java.util.HashMap;


/**
 * Additional interface classes for a solution to be used to solve the problem.
 * @author Kieran Greer
 */
public interface SolutionSolveDef extends SolutionDef
{
    /**
     * Calculate the result of this solution over all problem datasets. The
     * results are then put in a list and stored in the solutionResult object.
     * @param inputVariables an additional set of input variables or constraints. This can be null or empty.
     * @throws java.lang.Exception any error.
     */
    void solve(HashMap<String, ?> inputVariables) throws Exception;
}
