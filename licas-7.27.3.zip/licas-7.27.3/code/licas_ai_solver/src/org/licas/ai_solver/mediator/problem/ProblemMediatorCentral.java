/*
 * ProblemMediatorCentral.java
 *
 * Created on 11 November 2015
 *
 * Version 1.5
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver.mediator.problem;


import org.licas.ai_solver.SolverFactory;
import org.licas.ai_solver.mediator.ProblemSolverMediator;
import org.licas.ai_solver.model.*;
import org.licas.ai_solver.spec.test.TestSpec;

import org.licas.PasswordHandler;
import org.licas.util.*;
import org.licas_xml.abs.Element;
import org.ai_heuristic.eval.metric.MetricDataset;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.*;
import org.jlog2.*;

import java.io.*;
import java.util.*;


/**
 * This is the abstract base class for modelling a solver that receives data from one
 * or more services and processes it locally. This is typically a centralised algorithm.
 * @author Kieran Greer
 */
public abstract class ProblemMediatorCentral extends ProblemMediator
{
    /** For logging errors */
    private static final Logger logger;

    
    /** List of service names */
    protected ArrayList<String> serviceNames;
    
    /** Hierarchical / structural list of iterated solutions */
    protected ArrayList<SolutionContainer> solutionHierarc;
    
    /** List of data elements */
    protected LinkedHashMap<String, Object> dataHash;
       
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ProblemMediatorCentral.class.getName());
        logger.setDebug(false);
    }
    
    
    /**
     * Create a new instance of ProblemMediatorCentral.
     * @param thePasswordHandler for storing passwords.
     */
    public ProblemMediatorCentral(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        resetValues();
    }
    
    /** Reset to starting values */
    public void resetValues()
    {
        super.resetValues();
        
        serviceNames = new ArrayList<>();
        solutionHierarc = new ArrayList<>();
        dataHash = new LinkedHashMap<>();
    }    
    
    /**
     * Create a new set of problem datasets. Can be read from a file or retrieved from
     * the distributed services. Single file assumes a single service with a file path 
     * content for a dataset to load. Also assumes CSV {@code ','}-style separator in the file.
     * @param testSpec the model of the tests to perform.
     * @throws java.lang.Exception any error.
     */
    protected void createStoreData(TestSpec testSpec) throws Exception
    {
        String filePath = null;                         //dataset file path
        ArrayList<MetricDataset> dataList;              //lit of datasets
        Element dataElem;                               //data element
        Element valueElem;                              //value element
        
        //if only 1 data entry, then maybe a file path to read, so try that first
        if (dataHash.size() == 1) {
            //look for URL address
            try {
                dataElem = (Element)dataHash.values().iterator().next();
                valueElem = dataElem.getChild(Const.VALUE);
                if (valueElem != null) {
                    filePath = valueElem.getText();
                    filePath = UriHandler.removeLocalFileUriPrefix(filePath);
                }
            }
            catch (Exception fex) {}
        }

        if (!problem.hasProblemSet()) {
            //add to config
            if (filePath != null) {
                dataList = readData(filePath, testSpec.getTestScript().tokenizer);

                //single dataset read from file does not create links afterwards
                testSpec.getTestScript().testRunsScript.addLinks = false;
            }
            else {
                //data entries are the actual problem value sets as well
                dataList = getProblemsList(testSpec);
            }

            problem.setProblemSet(dataList);
        }
    }
    
        /**
     * Read a data file of values suitable for the entropy grid.
     * @param filePath the path to a local file. Values only, separated by commas.
     * @param separator the tokenizer character.
     * @return the file parsed into data rows of string-based values.
     * @throws java.lang.Exception any error.
     */
    protected ArrayList<MetricDataset> readData(String filePath, String separator) throws Exception
    {
        String nextLine;                            //next line
        ArrayList<String> dataRow;                  //data row
        ArrayList<MetricDataset> dataRows;          //grid cell values
        BufferedReader reader;                      //file reader
        
        dataRows = new ArrayList<>();
        reader = FileLoader.loadFile(new File(filePath));               
        
        while ((nextLine = reader.readLine()) != null)
        {
            dataRow = StringHandler.tokenize(nextLine, separator, false);
            dataRows.add(MetricDataset.toDataset(dataRow));
        }
        
        return dataRows;
    }
    
    /**
     * Retrieve or generate the problems list from data files or services.
     * @param testSpec the test specification.
     * @return the list of problems.
     * @throws java.lang.Exception any error.
     */
    protected ArrayList<MetricDataset> getProblemsList(TestSpec testSpec) throws Exception
    {
        ArrayList<MetricDataset> problemList;               //list of problems
        ProblemSolverMediator solverMediator;               //the solver mediator
        
        try {
            //test for locally stored problem datasets, if empty then retrieve from the distibuted services
            if (getProblem().hasProblemSet()) {
                problemList = new ArrayList<>(getProblem().getProblemSet().values());
            }
            else {
                solverMediator = (ProblemSolverMediator) SolverFactory.getInstance().getSolverMediators().createServiceMediator(solverType);
                problemList = solverMediator.getServicesInfo(testSpec, this);
            }

            return problemList;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "getProblemsList", null, ex);
        }
    }

    /**
     * Return true if any solutions are currently stored.
     * @return true if solutionHierarc is not empty.
     */
    public boolean hasSolutions()
    {
        return !solutionHierarc.isEmpty();
    }

    /**
     * Get any higher level hierarchy of solutions that might have been generated.
     * @return the totalValue of solutionHierarc.
     */
    public ArrayList<SolutionContainer> getSolutionHierarchy()
    {
        return solutionHierarc;
    }
}
