/*
 * EvolveGenes.java
 *
 * Created on 8 April 2011
 *
 * Version 1.0.4
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ai_solver.model.genetic.genes;


import org.licas.ai_solver.model.genetic.Chromosome;
import org.licas.ai_solver.util.SolverConst;

import java.util.*;


/**
 * This is the base class for evolving two different gene lists through
 * crossovers or mutations, to generate a new one. This does not store the gene list
 * itself, which is stored in a {@link Chromosome}, but gets passed the gene lists
 * from the chromosome and applies the evolution mechanism to create a new one. While
 * the gene data is stored as a {@code MetricDataset}, these classes get passed the
 * data list only. This can be a {@code ArrayList} of {@code MetricValue} objects, or
 * the data objects directly.
 * @author Kieran Greer
 */
public abstract class EvolveGenes
{
    /** The type of object that represents a gene. This should be the classname */
    protected String geneType;
    
    /** 
     * The different ways that a crossover or mutation can be performed.
     * This is a list of Strings describing each type.
     */
    protected ArrayList<String> evolveTypes;


    /**
     * Create a new instance of EvolveGenes.
     * @param thisGeneType the type of gene as the object classname.
     * @param thisEvolveTypes the different ways that a crossover or mutation can be performed.
     */
    public EvolveGenes(String thisGeneType, ArrayList<String> thisEvolveTypes)
    {
        geneType = thisGeneType;
        evolveTypes = thisEvolveTypes;
    }
    
    /**
     * Return true if the two sets of genes are the same.
     * @param geneList1 the first list of consider.
     * @param geneList2 the second list to consider.
     * @return true if the genes are the same. This implementation returns false by
     * default. You need to override this implementation to make any real comparison.
     * @throws java.lang.Exception any error.
     */
    public abstract boolean areSame(ArrayList<?> geneList1, ArrayList<?> geneList2) throws Exception;
    
    /**
     * Generate a crossover between this gene list and the variable passed in.
     * @param geneList1 the first list of consider.
     * @param geneList2 the second list to consider.
     * @return the result of the crossover. Can return null.
     * @throws java.lang.Exception any error.
     */
    protected abstract ArrayList<?> crossover(ArrayList<?> geneList1, ArrayList<?> geneList2) throws Exception;

    /**
     * Generate a mutation between this gene list and the variable passed in.
     * @param geneList1 the first list of consider.
     * @param geneList2 the second list to consider.
     * @return the result of the mutation. Can return null.
     * @throws java.lang.Exception any error.
     */
    protected abstract ArrayList<?> mutate(ArrayList<?> geneList1, ArrayList<?> geneList2) throws Exception;
    
    /**
     * Combine the two sets of genes to create a new list.
     * @param geneList1 the first list of consider.
     * @param geneList2 th second list to consider.
     * @return the evolved gene list. Can return null.
     * @throws java.lang.Exception any error.
     */
    public ArrayList<?> evolveGenes(ArrayList<?> geneList1, ArrayList<?> geneList2) throws Exception
    {
        ArrayList<?> evolvedGenes;                          //evolved gene sequence
        
        evolvedGenes = new ArrayList<>();
        if (evolveTypes.contains(SolverConst.CROSSOVER) ||
            evolveTypes.contains(SolverConst.CROSSOVERPERCENT)) {
            evolvedGenes = crossover(geneList1, geneList2);
        }
        
        if (evolveTypes.contains(SolverConst.MUTATE) ||
            evolveTypes.contains(SolverConst.MUTATEPERCENT)) {
            evolvedGenes = mutate(geneList1, geneList2);
        }

        return evolvedGenes;
    }
    
    /**
     * Clear the list of evolution types that determine how a mutation is performed.
     */
    public void clearEvolveTypes()
    {
        evolveTypes.clear();
    }
    
    /**
     * Ad a new evolution type to the list.
     * @param thisEvolveType a type of evolution that can be performed.
     * @return true if added, false if it already exists.
     */
    public boolean addEvolveType(String thisEvolveType)
    {
        if (!evolveTypes.contains(thisEvolveType)) {
            evolveTypes.add(thisEvolveType);
            return true;
        }
        
        return false;
    }
    
    /**
     * Get the list of different ways that a evolutions can be performed.
     * @return the value of evolveTypes.
     */
    public ArrayList<String> getEvolveTypes()
    {
        return evolveTypes;
    }
    
    /**
     * Return an appropriate gene evolution object based on the gene type
     * (probably the dataset type) and set of evolution requirements.
     * @param evolveInfo a full description of the evolution process.
     * @return the object that will be used to evolve chromosome genes.
     */
    public static EvolveGenes getEvolveGeneType(EvolveInfo evolveInfo)
    {
        if (evolveInfo.isSimpleType()) {
            if (evolveInfo.useFractions()) {
                return new DefaultEvolveGenesPct(evolveInfo.geneType, 
                        (ArrayList)evolveInfo.evolveTypes.clone(), evolveInfo.mutatePercent,
                        evolveInfo.crossoverPercent);
            }
            else {
                return new DefaultEvolveGenes(evolveInfo.geneType, 
                        (ArrayList)evolveInfo.evolveTypes.clone());
            }
        }
        else if (evolveInfo.isBagOfWords()) {
            return new EvolveGenesBOW(evolveInfo.geneType, 
                    (ArrayList)evolveInfo.evolveTypes.clone());
        }
        else {
            //if unknown type then use the default settings
            if (evolveInfo.useFractions()) {
                return new DefaultEvolveGenesPct(evolveInfo.geneType, 
                        (ArrayList)evolveInfo.evolveTypes.clone(), evolveInfo.mutatePercent,
                        evolveInfo.crossoverPercent);
            }
            else {
                return new DefaultEvolveGenes(evolveInfo.geneType, 
                        (ArrayList)evolveInfo.evolveTypes.clone());
            }
        }
    }
}
