/*
 * DefaultSolverHeuristics.java
 *
 * Created on 29 January 2016
 *
 * Version 1.0.3
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.ai_solver;


import org.ai_heuristic.model.FactoryInfo;
import org.ai_heuristic.util.AiHeuristicConst;
import org.ai_heuristic.util.TextConst;
import org.licas.ai_solver.central.SomConst;
import org.licas.ai_solver.util.SolverConst;
import org.licas.util.Const;
import org.licas.util.HeuristicConst;
import org.licas.util.TypeConst;

import java.util.*;


/**
 * This class describes the methods used by the solver heuristics. A copy is stored in the
 * {@link DefaultSolverFactory} from where it is accessed and used.
 * @author Kieran Greer
 */
public class DefaultSolverHeuristics extends SolverHeuristics
{
    /**
     * Create a new instance of DefaultSolverHeuristics.
     * @param theSolverModules list of solver modules.
     */
    public DefaultSolverHeuristics(ArrayList theSolverModules)
    {
        super(theSolverModules);
    }
    
    
    /**
     * Get a list of possible heuristic options for the specified heuristic types. 
     * This can include variables for the evaluation metric as well.
     * @param solverType the solver framework: hyper, distributed, etc.
     * @param heuristicType the heuristic framework.
     * @param metricType the evaluator of the heuristic. This is also considered, but can be null.
     * @return the list of options for the heuristic. This could be evolution types
     * for a genetic algorithm, for example, but for other heuristics it could
     * be a completely different set of values.
     */
    public ArrayList<String> getHeuristicOptions(String solverType, String heuristicType, String metricType)
    {
        int i;
        ArrayList<String> options;                  //list of options
        ArrayList<String> nextOptions;              //list of options
        ModuleSolverFactory moduleFactory;          //module factory
        
        
        options = new ArrayList<>();
        if (solverType != null) {
            if (solverType.equals(HeuristicConst.GRIDMATCH) ||
                solverType.equals(HeuristicConst.GRIDHILL)) {
                if ((heuristicType == null) || heuristicType.equals(HeuristicConst.GENETICALGORITHM)) {
                    options.addAll(getEvolveTypes());
                }
            }
        }
        
        if (metricType != null) {
            if (metricType.equals(AiHeuristicConst.MINKOWSKIFUNCTION) || 
                metricType.equals(HeuristicConst.METRICONLY)) {
                if (!options.contains(AiHeuristicConst.MKP))
                    options.add(AiHeuristicConst.MKP);
            }
            
            if (AiHeuristicConst.learnFunctions().contains(metricType) || 
                metricType.equals(HeuristicConst.METRICONLY)) {
                if (!options.contains(AiHeuristicConst.CFC))
                    options.add(AiHeuristicConst.CFC);
                if (!options.contains(AiHeuristicConst.EFN))
                    options.add(AiHeuristicConst.EFN);
                if (!options.contains(AiHeuristicConst.EFC))
                    options.add(AiHeuristicConst.EFC);
                if (!options.contains(AiHeuristicConst.GFR))
                    options.add(AiHeuristicConst.GFR);
                if (!options.contains(AiHeuristicConst.HFC))
                    options.add(AiHeuristicConst.HFC);
                if (!options.contains(AiHeuristicConst.HFC2))
                    options.add(AiHeuristicConst.HFC2);
            }
            
            if (AiHeuristicConst.activationFunctions().contains(metricType) || 
                metricType.equals(SomConst.ACTIVATIONFUNCION) ||
                metricType.equals(HeuristicConst.METRICONLY)) {
                if (!options.contains(AiHeuristicConst.HLT))
                    options.add(AiHeuristicConst.HLT);
                if (!options.contains(AiHeuristicConst.SHLT))
                    options.add(AiHeuristicConst.SHLT);
                if (!options.contains(AiHeuristicConst.LPFA))
                    options.add(AiHeuristicConst.LPFA);
                if (!options.contains(AiHeuristicConst.LPFB))
                    options.add(AiHeuristicConst.LPFB);
            }
            
            if (metricType.equals(AiHeuristicConst.SIMPLEFUNCTION) || 
                metricType.equals(HeuristicConst.METRICONLY)) {
                if (!options.contains(AiHeuristicConst.MIN))
                    options.add(AiHeuristicConst.MIN);
                if (!options.contains(AiHeuristicConst.MAX))
                    options.add(AiHeuristicConst.MAX);
            }
        }
        
        //add from the modules
        for (i = 0; i < solverModules.size(); i++)
        {
            moduleFactory = solverModules.get(i);
            if (moduleFactory.hasSolverHeuristics()) {
                nextOptions = moduleFactory.getSolverHeuristics().getHeuristicOptions(solverType, heuristicType, metricType);
                if (nextOptions != null) {
                    options.addAll(nextOptions);
                }
            }
        }

        return options;
    }
    
    /**
     * Get the list of solver classes that can be loaded from the default package.
     * @return a list of FactoryInfo objects for each solver function type.
     */
    public HashMap<String, HashMap<String, FactoryInfo>> getDefaultSolverClasses()
    {
        int i;
        String serviceFunction;                                         //service function
        String nextKey;                                                 //next key
        Iterator allKeys;                                               //all keys
        ArrayList datasetTypes;                                         //dataset types
        ArrayList datasetDescriptions;                                  //dataset descriptions
        HashMap<String, FactoryInfo> factoryList;                       //factory info list
        HashMap<String, HashMap<String, FactoryInfo>> allSolverInfo;    //all solver info
        HashMap<String, HashMap<String, FactoryInfo>> nextSolverInfo;   //next solver info
        FactoryInfo factoryInfo;                                        //factory info
        ModuleSolverFactory moduleFactory;                              //module factory
                
        allSolverInfo = new HashMap<>();
        serviceFunction = SolverConst.SOLVERFACTORY;
        factoryList = new HashMap<>();
        factoryInfo = new FactoryInfo();
        factoryInfo.className = "org.licas.ai_solver.DefaultSolverFactory";
        factoryInfo.description = "Solver factory with the default package.";
        factoryList.put(factoryInfo.className, factoryInfo);
        allSolverInfo.put(serviceFunction, factoryList);
        
        serviceFunction = Const.DATASETTYPE;
        factoryList = new HashMap();
        datasetTypes = getAllDatasetTypes();
        datasetDescriptions = getAllDatasetTypeDescriptions();
        
        for (i = 0; i < datasetTypes.size(); i++)
        {
            factoryInfo = new FactoryInfo();
            factoryInfo.className = (String)datasetTypes.get(i);
            factoryInfo.description = (String)datasetDescriptions.get(i);
            factoryList.put(factoryInfo.className, factoryInfo);
        }       
        allSolverInfo.put(serviceFunction, factoryList);
        
        //add from the modules
        for (i = 0; i < solverModules.size(); i++)
        {
            moduleFactory = solverModules.get(i);
            if (moduleFactory.hasSolverHeuristics()) {
                nextSolverInfo = moduleFactory.getSolverHeuristics().getDefaultSolverClasses();
                if (nextSolverInfo != null) {
                    allKeys = nextSolverInfo.keySet().iterator();

                    while (allKeys.hasNext())
                    {
                        nextKey = (String)allKeys.next();
                        if (!allSolverInfo.containsKey(nextKey)) {
                            allSolverInfo.put(nextKey, nextSolverInfo.get(nextKey));
                        }
                    }
                }
            }
        }
        
        return allSolverInfo;
    }
    
    /**
     * Get a list of possible evolution types.
     * @return the list of versions of the hyper heuristic.
     */
    private ArrayList<String> getEvolveTypes()
    {
        ArrayList<String> typeList;                 //list of types

        typeList = new ArrayList<>();
        typeList.add(SolverConst.CROSSOVER);
        typeList.add(SolverConst.MUTATE);
        typeList.add(SolverConst.MUTATEPERCENT);
        typeList.add(SolverConst.CROSSOVERPERCENT);

        return typeList;
    }
    
    /**
     * Get a list of all available dataset types.
     * @return the list of all dataset types.
     */
    public ArrayList<String> getAllDatasetTypes()
    {
        int i;
        ArrayList<String> typeList;                 //list of types
        ArrayList<String> nextTypeList;             //list of types
        ModuleSolverFactory moduleFactory;          //module factory
        
        typeList = new ArrayList<>();
        typeList.add(HeuristicConst.BAGOFWORDSTYPE);
        typeList.add(HeuristicConst.METABAGOFWORDSTYPE);
        typeList.add(HeuristicConst.STRINGTYPE);
        typeList.add(HeuristicConst.FLOATTYPE);
        typeList.add(HeuristicConst.INTEGERTYPE);
        typeList.add(TypeConst.URI);
        
        //add from the modules
        for (i = 0; i < solverModules.size(); i++)
        {
            moduleFactory = solverModules.get(i);
            if (moduleFactory.hasSolverHeuristics()) {
                nextTypeList = moduleFactory.getSolverHeuristics().getAllDatasetTypes();

                if (nextTypeList != null) {
                    typeList.addAll(nextTypeList);
                }
            }
        }
        
        return typeList;
    }
    
    /**
     * Get a list of all available dataset type descriptions.
     * @return the list of all dataset types.
     */
    public ArrayList<String> getAllDatasetTypeDescriptions()
    {
        int i;
        ArrayList<String> typeList;                 //list of types
        ArrayList<String> nextTypeList;             //list of types
        ModuleSolverFactory moduleFactory;          //module factory
        
        typeList = new ArrayList<>();
        typeList.add("Bag-of-words, unordered word counts.");
        typeList.add("Bag-of-words, unordered word counts with additional info.");
        typeList.add("Simple text-based data.");
        typeList.add("Simple floating point data.");
        typeList.add("Simple integer data.");
        typeList.add("Indicates to load from a resource.");
        
        //add from the modules
        for (i = 0; i < solverModules.size(); i++)
        {
            moduleFactory = solverModules.get(i);
            if (moduleFactory.hasSolverHeuristics()) {
                nextTypeList = moduleFactory.getSolverHeuristics().getAllDatasetTypeDescriptions();
                if (nextTypeList != null) {
                    typeList.addAll(nextTypeList);
                }
            }
        }
        
        return typeList;
    }
    
    /**
     * Get a list of available dataset types.
     * @return the list of dataset types.
     */
    public ArrayList<String> getTextDatasetTypes()
    {
        int i;
        ArrayList<String> typeList;                 //list of types
        ArrayList<String> nextTypeList;             //list of types
        ModuleSolverFactory moduleFactory;          //module factory
        
        typeList = new ArrayList<>();
        typeList.add(TextConst.METABAGOFWORDS);
        typeList.add(TextConst.BAGOFWORDS);
        
        //add from the modules
        for (i = 0; i < solverModules.size(); i++)
        {
            moduleFactory = solverModules.get(i);
            if (moduleFactory.hasSolverHeuristics()) {
                nextTypeList = moduleFactory.getSolverHeuristics().getTextDatasetTypes();
                if (nextTypeList != null) {
                    typeList.addAll(nextTypeList);
                }
            }
        }
        
        return typeList;
    }
}
