/**
 * Test specifications can store intermediary value sets that then get copied to the problem 
 * specifications, but also other values, relating to how the test process runs, so all
 * of the specification is initially stored here.
 */
package org.licas.ai_solver.spec.test;