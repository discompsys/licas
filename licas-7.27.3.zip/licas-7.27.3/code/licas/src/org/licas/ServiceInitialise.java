/*
 * ServiceInitialise.java
 *
 * Created on 17 January 2014
 *
 * Version 1.2.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.def.ServiceInitialiseDef;
import org.licas.util.Const;
import org.licas_xml.abs.Element;


/**
 * This class performs some additional or final initialisations, after a service
 * has been properly loaded and registered. If it has been created with an admin
 * document for example, the metadata might describe some additional operations 
 * that should be carried out, such as loading in some default utility services.
 * This description needs to be converted into the instructions to load in those 
 * services, which is what this default implementation will do.
 * @author Kieran Greer
 */
public class ServiceInitialise implements ServiceInitialiseDef
{
    /** The logger */
    private static final Logger logger;
    
    
    /** The parent service's password handler */
    protected PasswordHandler passwordHandler;
    
    /** The parent service's admin handler */
    protected ServiceAdmin serviceAdmin;
    
    /** The parent service */
    protected Service parentService;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServiceInitialise.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Create a new instance of ServiceInitialise.
     * @param theParentService the parent service.
     * @param theServiceAdmin the parent service's admin handler.
     * @param thePasswordHandler the parent service's password handler.
     */
    public ServiceInitialise(Service theParentService, ServiceAdmin theServiceAdmin,
            PasswordHandler thePasswordHandler)
    {
        parentService = theParentService;
        serviceAdmin = theServiceAdmin;
        passwordHandler = thePasswordHandler;
    }
    
    /**
     * Finalise the initialisation of the service. If an admin document is passed, 
     * this default implementation uses it to create and load a child service onto 
     * this one.
     * @param serviceXml XML description of the service to load.
     * @throws java.lang.Exception any error.
     */
    public void finaliseInitialisation(Element serviceXml) throws Exception
    {
        String lServiceUuid;                            //service uuid
        String lServiceType;                            //service type
        Element nextElem;                               //next element
        Object serviceObj;                              //service object
        ServiceSerialize serviceSerialize;              //to re-construct the service
        
        serviceSerialize = new ServiceSerialize();
        lServiceUuid = null;
        lServiceType = null;
        
        nextElem = serviceXml.getChild(Const.UUID);
        if (nextElem != null) {
            lServiceUuid = nextElem.getText();
        }
        nextElem = serviceXml.getChild(Const.SERVICETYPE);
        if (nextElem != null) {
            lServiceType = nextElem.getText();
        }
        if (lServiceUuid == null) {
            lServiceUuid = serviceXml.getAttributeValue(Const.NAME);
        }
        if (lServiceType == null) {
            lServiceType = serviceXml.getName();
        }
        
        serviceObj = serviceSerialize.xmlToService(serviceXml, parentService.getServerPassword());        
        if (serviceObj != null) {
            parentService.addService(passwordHandler.getPassword(), 
                    lServiceUuid, lServiceType, serviceObj);
        }
    } 
}
