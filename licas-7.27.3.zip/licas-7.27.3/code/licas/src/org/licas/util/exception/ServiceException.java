/*
 * ServiceException.java
 *
 * Created on 12 January 2009
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util.exception;


import org.jlog2.exception.WriteMessageException;


/**
 * This class can be used to throw an exception relating specifically to services, 
 * for example a missing service.
 * @author Kieran Greer
 */
public class ServiceException extends WriteMessageException 
{
    /**
     * Create a new instance of ServiceException. This exception is passed through
     * each time, although only the message part gets written to the logger.
     * @param message the error message.
     */
    public ServiceException(String message)
    {
        super(message, false);
    }
    
    /**
     * Create a new instance of ServiceException.
     * @param message the error message.
     * @param thisUseOnce if true pass through the logger only once, if false, then pass
     * through the logger each time.
     */
    public ServiceException(String message, boolean thisUseOnce)
    {
        super(message, thisUseOnce);
    }
}
