/*
 * HeuristicConst.java
 *
 * Created on 7 August 2014
 *
 * Version 1.3
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.util;


import org.ai_heuristic.util.AiHeuristicConst;


/**
 * This class stores some constant values. These define what base heuristics or algorithms
 * are available for the problem solving.
 * @author Kieran Greer
 */
public class HeuristicConst extends AiHeuristicConst
{
    public static final String FRAMEWORK = "Framework";   
    
    
    //Problem-solving frameworks
    /** New hyper-heuristic matching framework */
    public static final String GRIDMATCH = "Grid_Match";
    
    /** Grid with hill-climbing framework */
    public static final String GRIDHILL = "Grid_Hill_Climb";
    
    /** Grid with hill-climbing framework */
    public static final String SEARCHHILL = "Search_Hill_Climb";
    
    /** Distributed linking framework */
    public static final String LINKDISTRIBUTED = "Link_Distributed";
    
    /** K-Nearest Neighbour Clustering */
    public static final String NEARESTNEIGHBOUR = "K_NN";
    
    /** Self-Organising Map Neural Network */
    public static final String SOMNN = "Som_NN";
    
    
    //Heuristic Types
    /** Centralised genetic algorithm */
    public static final String GENETICALGORITHM = "Genetic Algorithm";
    
    /** Centralised frequency count algorithm */
    public static final String FREQUENCY = "Frequency";

    /** Defines a clustering service */
    public static final String CLUSTER = "Cluster";

    /** Contains link clustering service */
    public static final String CONTAINSLINK = "Contains Link";
        
    /** Single link clustering service */
    public static final String SINGLELINK = "Single Link";
    
    /** Complete link clustering service */
    public static final String COMPLETELINK = "Complete Link";
    
    /** Only use the metric */
    public static final String METRICONLY = "Metric Only";
    
    /** Heuristic types, specifically for the problem solver genetic algorithm framework */
    public static final String SINGLECONCEPT = "Single Concept";
    public static final String INTEGERTYPE = "Integer Type";
    public static final String FLOATTYPE = "Float Type";
    public static final String STRINGTYPE = "String Type";
    public static final String BAGOFWORDSTYPE = "Bag-Of-Words";
    public static final String METABAGOFWORDSTYPE = "Meta-Bag-Of-Words";
}
