/**
 * Mostly pre-defined constant values, but also some utility methods.
 */
package org.licas.util;