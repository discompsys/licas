/*
 * TypeConst.java
 *
 * Created on 14 February 2013.
 *
 * Version 1.6
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util;


import org.ai_heuristic.util.AiTypeConst;
import org.licas.service.resource.Resource;
import org.licas_text.util.HtmlConst;
import org.licas_text.util.WebResourceHandler;
import org.licas_xml.model.ElementImpl;


/**
 * Constant values relating to data types and objects.
 * @author Kieran Greer
 */
public class TypeConst extends AiTypeConst
{
    /** Defines a Void class parameter type */
    public static final String VOID = "void";   
    
    /** Defines a Date tag name */
    public static final String DATE = "Date";

    /** Defines a byte list tag name */
    public static final String BYTELIST = "Byte_List";

    /** Defines a Binary file type */
    public static final String BINARYFILE = "Binary";
    
    /** Defines a Text file type */
    public static final String TEXTFILE = "Text";
    
    /** Defines an XML file type */
    public static final String XMLFILE = "Xml";
        
    /** Defines an HTML file type */
    public static final String HTMLFILE = "Html";
    
    /** Defines a URI type, to include file paths */
    public static final String URI = "URI";
    
    /** Defines a ByteArray class parameter type */
    public static final String BYTEARRAY = ByteArray.class.getName();
    
    /** Defines a online feed type in xml format */
    public static final String STREAMXML = "XML-Stream";
    
    
    /** Defines an info resource container type */
    public static final String RESOURCECONTAINER = "ResourceContainer";
    
    /** Defines an info resource list container type */
    public static final String LISTCONTAINER = "ListContainer";
    
    /** Defines an info resource random container type */
    public static final String RANDOMCONTAINER = "RandomContainer";
    
    /** Defines an info resource query container type */
    public static final String QUERYCONTAINER = "QueryContainer";
    
    
    /**
     * Return true if the data is a binary type.
     * @param dataType the data type to check, including file type.
     * @return true if a binary data type.
     */
    public static boolean isBinaryType(String dataType)
    {
        boolean isBinary;                           //true if binary
        
        isBinary = (FileObject.isBinaryFile(dataType) ||
                    FileObject.isKnownBinaryType(dataType));
        
        if (!isBinary)
        {
            isBinary = (dataType.equals(TypeConst.BINARYFILE) || 
                        dataType.equals(TypeConst.BYTEARRAY) ||
                        dataType.equals(TypeConst.BYTE) || 
                        dataType.equals(TypeConst.BYTEOBJ));
        }
                    
        return isBinary;
    }
    
    /**
     * Return true if the data is a xml type.
     * @param dataType the data type to check, including file type.
     * @return true if a xml data type.
     */
    public static boolean isXmlType(String dataType)
    {
        boolean isXml;                              //true if xml
        
        isXml = (FileObject.isXmlFile(dataType) ||
                FileObject.isKnownXmlType(dataType));
        
        if (!isXml)
        {
            isXml = (dataType.equals(TypeConst.ELEMENT) ||
                    dataType.equals(ElementImpl.class.getName()));
        }
                    
        return isXml;
    }
    
    /**
     * Return true if the data is a text file type, but not xml or any of the other
     * recognised ones.
     * @param dataType the data type to check, including file type.
     * @return true if a xml data type.
     */
    public static boolean isTextType(String dataType)
    {
        boolean isText;                         //true if text type
        
        isText = (FileObject.isTextFile(dataType) &&
                !(FileObject.isXmlFile(dataType) ||
                FileObject.isHtmlFile(dataType)));
        
        if (!isText)
        {
            isText = FileObject.isKnownTextType(dataType);
        }
        
        if (!isText)
        {
            isText = (dataType.equals(TypeConst.TEXTFILE));
        }
        
        return isText;
    }
    
    /**
     * Return true if the data type indicates an html or xhtml type.
     * @param dataType the data type.
     * @return true if it indicates an html or xhtml type.
     */
    public static boolean isHtml(String dataType)
    {
        if (dataType != null)
        {
            return (WebResourceHandler.isHtml(dataType) ||
                    dataType.equalsIgnoreCase(HtmlConst.HTML) ||
                    dataType.equalsIgnoreCase("text/html") ||
                    dataType.equalsIgnoreCase("text/xhtml"));
        }
                    
        return false;
    }
    
    /**
     * Return true if the data type indicates an html, xhtml or a remote URL type.
     * @param dataType the data type.
     * @return true if it indicates an html, xhtml or a remote URL type.
     */
    public static boolean isURL(String dataType)
    {
        if (dataType != null)
        {
            return (dataType.equalsIgnoreCase(TypeConst.URL));
        }
                    
        return false;
    }
    
    /**
     * Return true if the data type indicates an info resource container.
     * @param dataType the data type.
     * @return true if it indicates an info resource container type.
     */
    public static boolean isResourceContainer(String dataType)
    {
        if (dataType != null)
        {
            return (dataType.equalsIgnoreCase(LISTCONTAINER) ||
                    dataType.equalsIgnoreCase(RANDOMCONTAINER) ||
                    dataType.equalsIgnoreCase(QUERYCONTAINER));
        }
                    
        return false;
    }
    
    /**
     * Get the most appropriate info resource type for the specified data type.
     * @param dataType the data type, for example, Integer.class.getName(), 
     * String.class.getName(), URL.class.getName(). Basic types are covered. 
     * An HTML source should be represented by URL.class.getName(). Container types
     * are also returned.
     * @return the type of Resource that would be created for that data type.
     */
    public static String resourceContainerType(String dataType)
    {
        if (dataType != null)
        {
            if (dataType.equalsIgnoreCase(LISTCONTAINER))
            {
                return Resource.LISTCONTAINERTYPE;
            }
            else if (dataType.equalsIgnoreCase(RANDOMCONTAINER))
            {
                return Resource.RANDOMCONTAINERTYPE;
            }
            else if (dataType.equalsIgnoreCase(QUERYCONTAINER))
            {
                return Resource.QUERYCONTAINERTYPE;
            }
        }

        return null;
    }
}
