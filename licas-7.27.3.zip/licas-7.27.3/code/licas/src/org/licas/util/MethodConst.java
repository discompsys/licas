/*
 * MethodConst.java
 *
 * Created on 9 March 2013.
 *
 * Version 1.23
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util;


/**
 * Some constant values relating to method names.
 * @author Kieran Greer
 */
public class MethodConst 
{  
    //Server methods
    /** Defines initialise the server exists method */
    public static final String SETHTTPSERVER = "setHttpServer";
    
    /** Defines check if server is running at specified address */
    public static final String ISRUNNING = "isRunning";
    
    /** Defines get server administrator contact address */
    public static final String CONTACTINFO = "contactInfo";
    
    /** Defines check if ESB etc running OK method */
    public static final String HASESB = "hasESB";
    
    /** Defines check if service has other service loaded on it */
    public static final String HASSERVICE = "hasService";

    /** Defines execute method */
    public static final String EXECUTE = "execute";

    /** Defines can access the service method */
    public static final String CANACCESS = "canAccess";
    
    /** Defines can access the nested service method */
    public static final String CANACCESSNESTED = "canAccessNested";
    
    /** Defines can access the service metadata method */
    public static final String CANACCESSMETA = "canAccessMeta";
    
    /** Defines is secure service method */
    public static final String ISSECUREMETHOD = "isSecureMethod";
    
    /** Defines get secure service methods */
    public static final String GETSECUREMETHODS = "getSecureMethods";
    
    /** Defines is public service method */
    public static final String ISPUBLICMETHOD = "isPublicMethod";
    
    /** Defines get public service methods */
    public static final String GETPUBLICMETHODS = "getPublicMethods";
    
    /** Defines generic execute server service method */
    public static final String EXECUTESERVICETYPE = "executeServiceType";

    /** Defines generic execute server service asynchronous method */
    public static final String EXECUTESERVICETYPEASYNC = "executeServiceTypeAsync";

    /** Defines check if jar factory exists method */
    public static final String HASJARFACTORY = "hasJarFactory";
    
    /** Defines get local SOA network as XML method */
    public static final String GETSERVERSOA = "getServerSOA";
    
    /** Defines load local SOA network from XML method */
    public static final String LOADSERVERSOA = "loadServerSOA";
    
    /** Defines load service from XML admin script method */
    public static final String LOADSERVICEFROMXML = "loadServiceFromXml";
    
    /** Defines get local server details as XML method */
    public static final String GETSERVERDETAILS = "getServerDetails";
    
    /** Defines load distributed server details from XML method */
    public static final String LOADSERVERDETAILS = "loadServerDetails";
    
    /** Defines get server metrics method */
    public static final String AUTOMANMETRICS = "autoManMetrics";
    
    /** Defines serialize service into XML method */
    public static final String SERVICETOXML = "serviceToXml";
    
    /** Defines parse XML description back into service method */
    public static final String XMLTOSERVICE = "xmlToService";
    
    /** Defines add data info method */
    public static final String ADDDATAINFO = "addDataInfo";


    /** Defines clear network method */
    public static final String CLEARNETWORK = "clearNetwork";
    
    /** Defines block a service method */
    public static final String BLOCKSERVICE = "blockService";
    
    /** Defines unblock a service method */
    public static final String UNBLOCKSERVICE = "unblockService";
    
    /** Defines remove all services method */
    public static final String REMOVEALLSERVICES = "removeAllServices";

    /** Defines generic module send data method */
    public static final String DATATOSERVICE = "dataToService";

    /** Defines generic module receive data method */
    public static final String DATAFROMSERVICE = "dataFromService";
    
    /** Defines subscribe for service method */
    public static final String SUBSCRIBE = "subscribe";
    
    /** Defines unsubscribe for service method */
    public static final String UNSUBSCRIBE = "unsubscribe";
    
    /** Defines publish to do work method */
    public static final String PUBLISH = "publish";
    
    /** Defines unpublish to do work method */
    public static final String UNPUBLISH = "unpublish";
    
    /** Defines execute query method */
    public static final String EXECUTEQUERY = "executeQuery";
    
    /** Defines get query stats method */
    public static final String GETQUERYSTATS = "getStats";
        
    
    //Service methods
    /** Defines a run thread method */
    public static final String RUN = "run";

    /** Defines check if thread is running */
    public static final String ISTARTED = "isStarted";

    /** Defines check if thread can be run */
    public static final String CANRUN = "canRun";
    
    /** Defines start one thread method */
    public static final String STARTTHREAD = "startThread";
    
    /** Defines set allow/block add service method */
    public static final String ALLOWADDSERVICE = "allowAddService";
    
    /** Defines get allow/block add service method */
    public static final String GETALLOWADDSERVICE = "getAllowAddService";
    
    /** Defines start all threads method */
    public static final String STARTALLTHREADS = "startAllThreads";
    
    /** Defines stop all threads method */
    public static final String STOPALLTHREADS = "stopAllThreads";
    
    /** Defines a 'set the shutdown variable' method */
    public static final String SETSHUTDOWN = "setShutDown";
    
    /** Defines a shutdown method */
    public static final String SHUTDOWN = "shutDown";

    /** Defines synchronous to asynchronous method execution */
    public static final String SYNCTOASYNC = "syncToAsync";

    /** Defines synchronous to asynchronous method reply */
    public static final String SYNCTOASYNCREPLY = "syncToAsyncReply";

    /** Defines synchronous to asynchronous method in transit */
    public static final String SYNCTOASYNCTRANSIT = "syncToAsyncTransit";

    /** Defines message reply method */
    public static final String MESSAGEREPLY = "messageReply";
    
    /** Defines add default service method */
    public static final String ADDDEFAULTSERVICE = "addDefaultService";

    /** Defines get the faults tree method */
    public static final String GETFAULTSTREE = "getFaultsTree";

    /** Defines add service method */
    public static final String ADDSERVICE = "addService";
    
    /** Defines remove service using uuid method */
    public static final String REMOVESERVICEID = "removeServiceID";

    /** Defines remove service using service path method */
    public static final String REMOVESERVICEPATH = "removeServicePath";

    /** Defines set description method */
    public static final String SETDESCRIPTION = "setDescription";

    /** Defines set can access nested service method */
    public static final String SETCANACCESSNESTED = "setCanAccessNested";
    
    /** Defines set can access service metadata method */
    public static final String SETCANACCESSMETA = "setCanAccessMeta";
    
    /** Defines calculate root nodes method */
    public static final String CALCULATEROOTNODES = "calculateRootNodes";
    
    /** Defines invoke behaviour method */
    public static final String INVOKEBEHAVIOUR = "invokeBehaviour";
    
    /** Invoke a single evaluation of the service */
    public static final String DOEVALUATE = "doEvaluate";
    
    /** Defines add parser method */
    public static final String ADDPARSER = "addParser";
    
    /** Defines remove parser method */
    public static final String REMOVEPARSER = "removeParser";
    
    /** Defines add object method */
    public static final String ADDOBJECT = "addObject";
    
    /** Defines add root node method */
    public static final String ADDROOTNODE = "addRootNode";

    /** Defines add root node method */
    public static final String GETROOTNODES = "getRootNodes";

    /** Defines remove root node method */
    public static final String REMOVEROOTNODE = "removeRootNode";
    
    /** Defines get service names method */
    public static final String GETSERVICENAMES = "getServiceNames";
    
    /** Defines get service types method */
    public static final String GETSERVICETYPES = "getServiceTypes";

    /** Defines get service number method */
    public static final String GETSERVICENUMBER = "getServiceNumber";

    /** Defines set the service data method */
    public static final String SETDATA = "setData";

    /** Defines get service data method */
    public static final String GETDATA = "getData";
    
    /** Set the data generator data */
    public static final String SETGENDATA = "setGenData";
    
    /** Set the auto process script */
    public static final String SETPROCESSSCRIPT = "setProcessScript";
    
    /** Defines add service meta method */
    public static final String ADDSERVICEMETA = "addServiceMeta";
    
    /** Defines get all service meta method */
    public static final String GETALLSERVICEMETA = "getAllServiceMeta";
    
    /** Defines get service meta method */
    public static final String GETSERVICEMETA = "getServiceMeta";
    
    /** Defines get service meta method */
    public static final String GETSERVICEMETAPART = "getServiceMetaPart";
    
    /** Defines get service meta method */
    public static final String GETSTATS = "getStats";
    
    /** Defines set all link threshold values method */
    public static final String SETALLLINKTHRESHOLDS = "setAllLinkThresholds";

    /** Defines set threshold values method */
    public static final String SETTHRESHOLDS = "setThresholds";
    
    /** Defines add dynamic links method */
    public static final String ADDDYNAMICLINKS = "addDynamicLinks";
    
    /** Defines add dynamic link method */
    public static final String ADDDYNAMICLINK = "addDynamicLink";
    
    /** Defines get linked sources method */
    public static final String GETLINKSOURCES = "getLinkSources";
    
    /** Defines convert dynamic links to xml method */
    public static final String DYNAMICLINKSTOXML = "dynamicLinksToXml";
    
    /** Defines convert permanent links to xml method */
    public static final String PERMANENTLINKSTOXML = "permanentLinksToXml";
    
    /** Defines parse xml to dynamic links method */
    public static final String XMLTODYNAMICLINKS = "xmlToDynamicLinks";
    
    /** Defines increment update hits method */
    public static final String INCREMENTUPDATEHITS = "incrementUpdateHits";        
    
    /** Defines memory to lend method */
    public static final String MEMORYTOLEND = "memoryToLend";
    
    /** Defines change lent memory method */
    public static final String CHANGELENTMEMORY = "changeLentMemory";
    
    /** Defines get current count method */
    public static final String GETCURRENTCOUNT = "getCurrentCount";
    
    /** Defines get current memory method */
    public static final String GETCURRENTMEMORY = "getCurrentMemory";
    
    /** Defines get release memory method */
    public static final String RELEASEMEMORY = "releaseMemory";
    
    /** Defines update increment weight method */
    public static final String UPDATEINCREMENTWEIGHT = "updateIncrementWeight";
    
    /** Defines update decrement weight method */
    public static final String UPDATEDECREMENTWEIGHT = "updateDecrementWeight";
    
    /** Defines has link to method */
    public static final String HASLINKTO = "hasLinkTo";
    
    /** Defines get parent method */
    public static final String GETPARENT = "getParent";
    
    /** Defines get password method */
    public static final String GETPASSWORD = "getPassword";
    
    /** Defines add id for packet communication method */
    public static final String ADDPACKETCOMMUNICATIONID = "addPacketCommunicationID";
    
    /** Defines add message packet method */
    public static final String ADDMESSAGEPACKET = "addMessagePacket";
    
    /** Defines add message packet method */
    public static final String ENDOFMESSAGE = "endOfMessage";

    /** Defines remove all links to method */
    public static final String REMOVEALLLINKSTO = "removeAllLinksTo";
    
    /** Defines add service association method */
    public static final String ADDSERVICEASSOCIATION = "addServiceAssociation";

    /** Defines remove service association method */
    public static final String REMOVESERVICEASSOCIATION = "removeServiceAssociation";

    /** Defines create permanent link to method */
    public static final String CREATEPERMANENTLINKTO = "createPermanentLinkTo";
    
    /** Defines create permanent link to method */
    public static final String REMOVEPERMANENTLINKTO = "removePermanentLinkTo";
    
    /** Defines add link from service method */
    public static final String ADDLINKFROMSERVICE = "addLinkFromService";
    
    /** Defines remove link from service method */
    public static final String REMOVELINKFROMSERVICE = "removeLinkFromService";
    
    /** Defines update dynamic links method */
    public static final String UPDATEDYNAMICLINKS = "updateDynamicLinks";
    
    /** Defines change dynamic links to permanent ones method */
    public static final String DYNAMICLINKSTOPERMANENT = "dynamicLinksToPermanent";
    
    /** Defines load data contents method */
    public static final String LOADDATACONTENTS = "loadDataContents";
    
    /** Defines load data details method */
    public static final String LOADDATADETAILS = "loadDataDetails";
    
    /** Defines load data script method */
    public static final String LOADDATASCRIPT = "loadDataScript";

    /** Defines send data to behaviour mediator method */
    public static final String DATAXMLBM = "dataXmlBH";

    /** Defines send data to data hub method */
    public static final String DATAXMLDH = "dataXmlDH";

    /** Defines get info element method */
    public static final String GETINFOELEMENT = "getInfoElement";

    /** Defines get value method */
    public static final String GETVALUE = "getValue";
    
    /** Defines get file method */
    public static final String GETFILE = "getFile";
    
    /** Defines save file method */
    public static final String SAVEFILE = "saveFile";
    
    /** Defines get jar file for service method */
    public static final String GETJARFORSERVICE = "getJarForService";
    
    /** Defines save service jar file method */
    public static final String SAVESERVICEJAR = "saveServiceJar";
    
    
    //HTTP Server method types
    /** HTTP Get method call */
    public static final String GET = "GET";
    
    /** HTTP Post method call */
    public static final String POST = "POST";
    
    /** HTTP Header method section */
    public static final String HEAD = "HEAD";
    
    
    /** Creates a new instance of MethodConst */
    public MethodConst() {
    }
}
