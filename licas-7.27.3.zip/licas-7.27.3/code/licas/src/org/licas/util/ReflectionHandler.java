/*
 * ReflectionHandler.java
 *
 * Created on 11 January 2014
 *
 * Version 1.4.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util;


import org.licas.util.classloader.LoadObject;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;


/**
 * This class provides methods to process Objects using the Java {@code Reflection} package.
 * @author Kieran Greer
 */
public class ReflectionHandler 
{
    /**
     * Retrieve the constructors for the specified class.
     * @param theClass the class instance.
     * @return a list of constructors.
     */
    public static Constructor[] getConstructors(Class theClass)
    {
        return theClass.getConstructors();
    }

    /**
     * Retrieve a list of all public methods in the class.
     * @param theClass the class instance.
     * @return a list of all public methods.
     */
    public static Method[] getMethods(Class theClass)
    {
        return theClass.getMethods();
    }
    
    /**
     * Check all constructors to see if any match the input parameters or super classes
     * of the input parameters.
     * @param constructors a list of constructors.
     * @param paramTypes the parameter type classes.
     * @return the constructor that matches the input parameters. 
     */
    public static Constructor getConstructor(Constructor[] constructors, Class[] paramTypes)
    {
        boolean isOK;                           //true if params OK
        int i, j;
        Constructor nextConstructor;            //next constructor
        Constructor theConstructor;             //the correct constructor
        Class[] conParams;                      //constructor parameters

        theConstructor = null;

        for (i = 0; i < constructors.length; i++)
        {
            nextConstructor = constructors[i];
            conParams = nextConstructor.getParameterTypes();

            if (conParams.length == paramTypes.length)
            {
                isOK = true;
                for (j=0; j < conParams.length; j++)
                {
                    if (!ObjectHandler.classInstance(conParams[j], paramTypes[j]))
                    {
                        isOK = false;
                        break;
                    }
                }

                if (isOK)
                {
                    theConstructor = nextConstructor;
                    break;
                }
            }
        }

        return theConstructor;
    }
    
    /**
     * Return true if a constructor with the specified parameter list exists for the class type.
     * @param className the name of the java class to construct.
     * @param paramTypes a list of constructor parameter types.
     * @return true if a constructor exists for the class type. False is also returned if
     * the class cannot be constructed.
     */
    public static boolean hasConstructor(String className, Class[] paramTypes)
    {
        Class c;                                    //class definition
        Constructor constructor;                    //class constructor
        Constructor[] constructors;                 //list of constructors
        
        c = LoadObject.getClass(className);
        if (c != null)
        {
            constructors = c.getConstructors();
            constructor = getConstructor(constructors, paramTypes);
            return (constructor != null);
        }

        return false;
    }
    
    /**
     * Try to retrieve the method from the object, matching to the method name only.
     * @param objClass the class for the object that executes the method.
     * @param methodName the method name.
     * @return the method that matches the spec or null if none exists.
     */
    public static Method retrieveMethod(Class objClass, String methodName)
    {
        return ReflectionHandler.retrieveMethod(objClass, methodName, null, null);
    }
    
    /**
     * Try to retrieve the method from the object.
     * @param objClass the class for the object that executes the method.
     * @param methodName the method name.
     * @param replyClass the reply type. This is optional.
     * @return the method that matches the spec or null if none exists.
     */
    public static Method retrieveMethod(Class objClass, String methodName, String replyClass)
    {
        return ReflectionHandler.retrieveMethod(objClass, methodName, replyClass, null);
    }
    
    /**
     * Try to retrieve the method from the object.
     * @param objClass the class for the object that executes the method.
     * @param methodName the method name.
     * @param replyClass the reply type. This is optional.
     * @param paramTypes list of parameter types. Can be empty.
     * @return the method that matches the spec or null if none exists.
     */
    public static Method retrieveMethod(Class objClass, String methodName, String replyClass,
            ArrayList<String> paramTypes)
    {
        return ObjectInvoker.retrieveMethod(objClass, methodName, replyClass, paramTypes);
    }
    
    /**
     * Get actual variable field instance if it is defined.
     * @param instanceObj the object instance to set the value on.
     * @param varName the name of the variable to set it's value.
     * @return the reflection field to set the value on, or null if it is missing.
     */
    public static Field getInstanceField(Object instanceObj, String varName)
    {
        int i;
        Field theField;                             //the field
        Field nextField;                            //next field
        Field[] fields;                             //fields from this class
        
        theField = null;
        if ((varName != null) && !varName.equals(""))
        {
            fields = instanceObj.getClass().getDeclaredFields();
            for (i = 0; (theField == null) && (i < fields.length); i++)
            {
                nextField = fields[i];
                if (nextField.getName().equalsIgnoreCase(varName)) {
                    theField = fields[i];
                }
            }
            
            if (theField == null) {
                fields = instanceObj.getClass().getFields();
                for (i = 0; (theField == null) && (i < fields.length); i++)
                {
                    nextField = fields[i];
                    if (nextField.getName().equalsIgnoreCase(varName)) {
                        theField = fields[i];
                    }
                }
            }
        }  
        
        return theField;
    }
    
    /**
     * Get the value of the named variable instance, if it is accessible.
     * @param instanceObj the object instance to set the value on.
     * @param varName the name of the variable to set it's value.
     * @return the value of the variable (the variable itself) if it can be accessed.
     */
    public static Object getInstanceVariable(Object instanceObj, String varName)
    {
        int i;
        Field nextField;                            //next field
        Field[] fields;                             //fields from this class
        Object fieldValue;                          //field value
        
        fieldValue = null;
        if ((varName != null) && !varName.equals(""))
        {
            fields = instanceObj.getClass().getDeclaredFields();
            for (i = 0; (fieldValue == null) && (i < fields.length); i++)
            {
                nextField = fields[i];
                if (nextField.getName().equalsIgnoreCase(varName)) {
                    try {
                        fieldValue = fields[i].get(instanceObj);
                    } 
                    catch (Exception ex) {
                        fieldValue = null;
                    }
                }
            }
            
            if (fieldValue == null) {
                fields = instanceObj.getClass().getFields();
                for (i = 0; (fieldValue == null) && (i < fields.length); i++)
                {
                    nextField = fields[i];
                    if (nextField.getName().equalsIgnoreCase(varName)) {
                        try {
                            fieldValue = fields[i].get(instanceObj);
                        } 
                        catch (Exception ex) {
                            fieldValue = null;
                        }
                    }
                }
            }
        }  
        
        return fieldValue;
    }
}
