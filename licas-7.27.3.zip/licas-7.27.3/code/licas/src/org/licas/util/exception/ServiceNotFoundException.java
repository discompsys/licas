/*
 * ServiceNotFoundException.java
 *
 * Created on 12 January 2017
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util.exception;


import org.jlog2.exception.WriteMessageException;


/**
 * This class can be used to throw an exception if a service to be invoked does not exist.
 * @author Kieran Greer
 */
public class ServiceNotFoundException extends WriteMessageException
{
    /**
     * Create a new instance of ServiceNotFoundException. This exception is passed through
     * each time, although only the message part gets written to the logger.
     * @param message the error message.
     */
    public ServiceNotFoundException(String message)
    {
        super(message, false);
    }
    
    /**
     * Create a new instance of ServiceNotFoundException.
     * @param message the error message.
     * @param thisUseOnce if true pass through the logger only once, if false, then pass
     * through the logger each time.
     */
    public ServiceNotFoundException(String message, boolean thisUseOnce)
    {
        super(message, thisUseOnce);
    }
}
