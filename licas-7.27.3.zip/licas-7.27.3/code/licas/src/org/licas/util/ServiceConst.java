/*
 * ServiceConst.java
 *
 * Created on 14 February 2013.
 *
 * Version 1.11.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util;


import org.jlog2.util.StringHandler;
import org.licas.query.LicasQueryConst;
import org.licas.service.sci.LinkService;

import java.io.File;
import java.util.ArrayList;


/**
 * Constant values relating to service configuration and use.
 * @author Kieran Greer
 */
public class ServiceConst 
{
    /** Operating system type. This will change file paths before compilation. */
    private static final String OS;
    
    /** True if version for the windows  installer */
    private static final boolean INSTALLER;
    
    /** Base directories */
    public static final String USERHOME;
    public static final String LICASHOME;   
    public static final String APPHOME;
    public static final String WEBHOME;   
    public static final String TEMPDIR;
    
    /** Dir for config files - might need to be reset depending on installation */
    public static final String CONFIGDIR;
    
    /** Dir for resource icons - might need to be reset depending on installation */
    public static final String RESOURCESDIR;    
     
    
    static
    {
        String filePath;
        String propType;
        File locationPath;
        
        filePath = (new File(".")).getAbsolutePath();
        filePath = filePath.substring(0, filePath.length()-1);
         
        propType = System.getProperty("type.os");
        OS = (propType == null) ? Const.WINDOWS : propType;
        propType = System.getProperty("type.install");
        INSTALLER = (propType == null) || (propType.equalsIgnoreCase("true"));
        
        if (INSTALLER && OS.equalsIgnoreCase(Const.WINDOWS))
        {
            APPHOME = filePath;
            USERHOME = System.getProperty("user.home");
            LICASHOME = USERHOME + Const.DIRSEP + "licasData";
            CONFIGDIR = LICASHOME + Const.DIRSEP + "config" + Const.DIRSEP;
            RESOURCESDIR = APPHOME + "resources" + Const.DIRSEP;
            
            //add a default web folder location at the parent level of the installation
            locationPath = new File(APPHOME);
            locationPath = locationPath.getParentFile();
        }
        else if (OS.equalsIgnoreCase(Const.ANDROID))
        {
            USERHOME = APPHOME = filePath;
            LICASHOME = USERHOME + "licasData";
            CONFIGDIR = LICASHOME + Const.DIRSEP + "config" + Const.DIRSEP;
            RESOURCESDIR = APPHOME + "resources" + Const.DIRSEP;
            
            //add a default web folder location at the same level as the installation
            locationPath = new File(APPHOME);
        }
        else
        {
            USERHOME = APPHOME = filePath;
            LICASHOME = USERHOME + "licasData";
            CONFIGDIR = LICASHOME + Const.DIRSEP + "config" + Const.DIRSEP;
            RESOURCESDIR = APPHOME + "resources" + Const.DIRSEP;
            
            //add a default web folder location at the same level as the installation
            locationPath = new File(APPHOME);   
        }
        
        //web and temp dirs in installation directory
        WEBHOME = locationPath.getAbsolutePath() + Const.DIRSEP + "web" + Const.DIRSEP;
        TEMPDIR = locationPath.getAbsolutePath() + Const.DIRSEP + "temp" + Const.DIRSEP;
    }
    
    /** default directories */
    public static final String SERVICESDIR = LICASHOME + Const.DIRSEP + "services" + Const.DIRSEP;
    public static final String SCRIPTSDIR = ServiceConst.LICASHOME + Const.DIRSEP + "scripts" + Const.DIRSEP;
    public static final String MODULESDIR = ServiceConst.LICASHOME + Const.DIRSEP + "modules" + Const.DIRSEP;
    public static final String DATADIR = ServiceConst.LICASHOME + Const.DIRSEP + "data" + Const.DIRSEP;
    public static final String IMAGEDIR = ServiceConst.LICASHOME + Const.DIRSEP + "images" + Const.DIRSEP;
    public static final String CONFIGFILE = ServiceConst.CONFIGDIR + "default_config.xml";
    public static final String CONFIGBKUPFILE = ServiceConst.CONFIGDIR + "default_config.bkup";
    
    /** The path to the lib folder in the distribution folder */
    public static final String LIBPATH = (Const.DIRSEP + "lib" + Const.DIRSEP);
        
    /** The path to the root folder for text file searches over the web */
    public static final String WEBSEARCHHOME = (WEBHOME + "websearch" + Const.DIRSEP);
    
    /** The licas config tag */
    public static final String LICASCONFIG = "Licas_Config";
    
    /** Server config tag */
    public static final String SERVERCONFIG = "Server_Config";
    
    /** Server gui tag */
    public static final String SERVERGUI = "Server_Gui";
    
    
    /** The default service factory tag */
    public static final String DEFAULTSERVICEFACTORY = "Default_Service_Factory";
    
    /** The Service Factory tag */
    public static final String SERVICEFACTORY = "Service_Factory";
    
    /** The Jar Factory tag */
    public static final String DEFAULTJARFACTORY = "Default_Jar_Factory";
    
    /** The Jar Factory tag */
    public static final String JARFACTORY = "Jar_Factory";
    
    /** The default service factory tag */
    public static final String DEFAULTSERVICES = "Default_Services";
    
    /** Defines the function handler tag */
    public static final String FUNCTIONHANDLER = "Function_Handler";
    
    /** Defines the function type tag */
    public static final String FUNCTIONTYPE = "Function_Type";
    
    /** Defines the data generator tag - Use as XML tag */
    public static final String DATAGENERATOR = "Data_Generator";
    
    /** Defines the data generator type - use as Type in GUI */
    public static final String DATAGENERATORTYPE = "Data_Gen";
    
    /** The GUI interface tag */
    public static final String GUI = "Gui";
    
    /** The GUI handler tag */
    public static final String GUIHANDLER = "Gui_Handler";
    
    /** The GUI classname tag */
    public static final String GUICLASSNAME = "Gui_Classname";
    
    /** The group tag */
    public static final String GROUP = "Group";
    
    
    
    //Service handles
    /** Defines a base service */
    public static final String BASE = "Base";
    
    /** Defines a utility service */
    public static final String UTILITY = "Utility";
    
    /** Defines the linking service or handle */
    public static final String LINKER = "Linker";
    
    /** Defines a timer service */
    public static final String TIMER = "Timer";
    
    /** Defines the behaviour service */
    public static final String BEHAVIOUR = "Behaviour";
    
    /** The default behaviour loop sleep time (ms) */
    public static final int BEHAVIOURLOOPSLEEP = 100;

    /** The default message loop sleep time (ms) */
    public static final int MESSAGESLEEP = 10;

    /** The default message loop sleep time (ms) */
    public static final int INITSLEEP = 10;

    /** Default number of call executor threads */
    public static final int CALLTHREADS = 50;

    /** Defines the evaluation service */
    public static final String EVALUATE = "Evaluate";
    
    /** Defines the information service */
    public static final String INFORMATION = "Information";
    
    /** Defines the feed service */
    public static final String FEED = "Feed";
    
    /** Defines the message service */
    public static final String MESSAGE = "Message";
    
    /** Defines the message board service */
    public static final String MESSAGEBOARD = "Message Board";
    
    /** Defines the file paths */
    public static final String FILES = "Files";
    
    /** Defines the file path or service */
    public static final String FILE = "File";
    
    /** Defines the web service */
    public static final String WEBSERVICE = "Web Service";

    /** Defines the web query service */
    public static final String WEBQUERYSERVICE = "Web Query";

    /** Defines the email service */
    public static final String EMAIL = "Email";

    /** Defines a default data hub service type */
    public static final String DATAHUB = "Data Hub";

    /** Defines a default data hub service tag */
    public static final String DATAHUBXML = "Data_Hub";

    /** Defines a default behaviour mediator service type */
    public static final String BEHAVIOURMEDIATOR = "Behaviour_Mediator";
    
    /** Defines a default behaviour cluster view */
    public static final String BEHAVIOURAGGREGATEVIEW = "Aggregate View";
    
    /** Defines a line plot view */
    public static final String LINEPLOTVIEW = "Line Plot";
    
    /** Defines a scatter plot view */
    public static final String SCATTERPLOTVIEW = "Scatter Plot";
    
    /** Defines a histogram plot view */
    public static final String HISTPLOTVIEW = "Histogram Plot";
    
    /** Defines prefix for service name */
    public static final String IINDEX = "I";
    
    
    /** The address info tag */
    public static final String ADDRESSINFO = "Address_Info";
    
    /** The address book tag */
    public static final String ADDRESSBOOK = "Address_Book";
    
    /** The next address tag */
    public static final String NEXTADDRESS = "Next_Address";
    
    /** The address groups tag */
    public static final String ADDRESSGROUPS = "Address_Groups";
    
    
    
    //Service Categories
    /** The All Categories tag */
    public static final String ALLCATEGORIES = "All";
    
    /** The Business Category tag */
    public static final String BUSINESSCATEGORY = "Business";
    
    /** The Business Category tag */
    public static final String PERSONALCATEGORY = "Personal";
    
    /** The Scientific Category tag */
    public static final String SCIENCECATEGORY = "Scientific";
    
    /** The Test Category tag */
    public static final String TESTCATEGORY = "Test";
    
    /** The replace with address symbol */
    public static final String REPLACEWITHADDRESS = "replace_with_address";
    
    
    
    /**
     * Get a list of default licas-based search types.
     * @return a list of default search types.
     */
    public static ArrayList<String> getServerServiceTypes()
    {
        ArrayList<String> searchTypes;                  //search types
        
        searchTypes = LicasQueryConst.getLicasSearchTypes();
        searchTypes.add(LicasQueryConst.SEARCHWEBFOLDER);
        return searchTypes;
    }
    
    /**
     * Get the lit of all service category types.
     * @return a list of service category types.
     */
    public static ArrayList<String> getServiceCategories()
    {
        ArrayList<String> categories;                   //categories list
        
        categories = new ArrayList<>();
        categories.add(BUSINESSCATEGORY);
        categories.add(PERSONALCATEGORY);
        categories.add(SCIENCECATEGORY);
        categories.add(TESTCATEGORY);
        categories.add(ALLCATEGORIES);
        
        return categories;
    }
    
    /**
     * Get the lit of all service category types.
     * @return a list of service category types.
     */
    public static ArrayList<String>  getAdminConfigTypes()
    {
        ArrayList<String>  config;                      //config list
        
        config = new ArrayList<>();
        config.add(Const.TYPE);
        config.add(Const.CATEGORY);
        config.add(Const.DESCRIPTION);
        config.add(Const.KEYWORD);
        
        return config;
    }
    
    /**
     * Check the class type for any recent class changes.
     * @param className the class name.
     * @return the current correct type for the class name.
     */
    public static String checkClassName(String className)
    {
        if (className != null)
        {
            className = StringHandler.replaceFirst(className, "org.licas.gen", "org.licas.data.gen");
            if (className.equalsIgnoreCase("org.licas.service.link.LinkService") ||
                className.equalsIgnoreCase("org.licas.service.BehaviourService"))
            {
                return LinkService.class.getName();
            }
            else if (className.equalsIgnoreCase("org.licas.service.link.HM_ContainsLink"))
            {
                return "org.licas.ai_solver.link.HM_ContainsLink";
            }
            else if (className.equalsIgnoreCase("org.licas.service.BehaviourMediator"))
            {
                return "org.licas.service.sci.BehaviourMediator";
            }
            else if (className.equalsIgnoreCase("org.licas.service.TimerService"))
            {
                return "org.licas.service.sci.TimerService";
            }
            else if (className.startsWith("org.licas.service.basdef"))
            {
                return StringHandler.replaceAll(className, "org.licas.service.basdef", "org.licas.service.model");
            }
        }
        
        return className;
    }
}
