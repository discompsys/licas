/*
 * UrlJarClassLoader.java
 *
 * Created on 23 April 2013
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */
package org.licas.util.classloader;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.StringHandler;

import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;


/**
 * This is a URL class loader, extended to also read a local jar file for class names retrieval.
 * @author Kieran Greer
 */
public class UrlJarClassLoader extends URLClassLoader 
{
    /** The logger */
    private static final Logger logger;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(UrlJarClassLoader.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Create a new instance of UrlJarClassLoader.
     * @param uris list of jar uris. Should only be one, but need
     * array for parent constructor.
     */
    public UrlJarClassLoader(URL[] uris)
    {
        super(uris);
    }
    
    /**
     * Create a new instance of UrlJarClassLoader.
     * @param uris list of jar uris. Should only be one, but need
     * array for parent constructor.
     * @param parent the parent class loader. Can be null.
     */
    public UrlJarClassLoader(URL[] uris, ClassLoader parent)
    {
        super(uris, parent);
    }

    /**
     * Add a url to the classpath.
     * @param url the url address.
     */
    public void addURL(URL url) {
        super.addURL(url);
    }

    /**
     * Retrieve and return the names of all classes stored in the jar identified 
     * by the uri. This does not add the jar as a permanent class loader. It only 
     * parses it to retrieve the class list. Use 'addLoader' or 'loadObject' to
     * add as a permanent loader.
     * @param jarUri the uri for the jar file.
     * @param rtnOnError if true, exit with the first load error, returning null. If
     * false, try to load every class and ignore any errors.
     * @return a list of all class names.
     */
    public ArrayList<String> getAllClasses(String jarUri, boolean rtnOnError)
    {
        String jarName;                             //jar name
        Class nextClass;                            //next class
        ArrayList<String> classes;                  //all classes
        Enumeration entries;                        //entries
        JarFile jarFile;                            //jar file
        JarEntry jarEntry;                          //jar entry
        URL[] uris;                                 //all uris
                
        try
        {
            classes = new ArrayList<>();

            //test format
            uris = new URL[1];
            uris[0] = LoadObject.uriToUrl(jarUri);
            
            jarFile = LoadObject.loadJarFile(jarUri);
            if (jarFile != null)
            {
                entries = jarFile.entries();
                while (entries.hasMoreElements())
                {
                    jarEntry = (JarEntry)entries.nextElement();
                    jarName = jarEntry.getName().trim();

                    if (LoadObject.isLegalClassFile(jarName))
                    {
                        jarName = StringHandler.replaceAll(jarName, ".class", "").trim();
                        jarName = StringHandler.replaceAll(jarName, "/", ".");

                        try
                        {
                            nextClass = loadClass(jarName);
                            classes.add(nextClass.getName());
                        }
                        catch (Exception ex2)
                        { 
                            //do not output message as can be security 
                            //restriction or missing external jar
                            if (rtnOnError) return null;
                        }
                        catch (Throwable th)
                        { 
                            //do not output message as can be security 
                            //restriction or missing external jar
                            if (rtnOnError) return null;
                        }
                    }
                }
            }

            return classes;
        }
        catch (Exception ex)
        {
            ExceptionHandler.debugException(logger, LoggerHandler.WARN, "getAllClasses",
                (jarUri + ": "), ex);

            return null;
        }
    }
}
