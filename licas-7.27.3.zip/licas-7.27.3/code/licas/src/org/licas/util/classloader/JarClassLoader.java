/*
 * JarClassLoader.java
 *
 * Created on 18 March 2013
 *
 * Version 1.0.2
 *
 * Copyright (c) Kieran Greer
 *
 * Author: Kieran Greer
 */
package org.licas.util.classloader;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.StringHandler;

import java.io.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;


/**
 * This is a local jar file class loader that includes code re-compilation if the source exists.
 * Based on 'Understanding the Java ClassLoader' by Greg Travis, IBM, 2001, and also
 * http://kalanir.blogspot.co.uk/2010/01/how-to-write-custom-class-loader-to.html.
 * @author Kieran Greer
 */
public class JarClassLoader extends ClassLoader 
{
    /** The logger */
    private static final Logger logger;
    
    /** The jar file path */
    private final String jarFile;
    
    /** The loaded jar file */
    private JarFile jar;
    
    /** List of already cached classes */
    private final HashMap<String, Class> cachedClasses;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(JarClassLoader.class.getName());
        logger.setDebug(false);
    }
    
    
    /**
     * Create a new instance of JarClassLoader.
     * @param theFilePath the full file path to the local jar file.
     */
    public JarClassLoader(String theFilePath) 
    {
        //calls the parent class loader's constructor
        super(JarClassLoader.class.getClassLoader());
       
        jar = null;
        jarFile = theFilePath;
        cachedClasses = new HashMap<>();
    }
    
    /**
     * Get the class from the class loader.
     * @param className the full class name.
     * @return the class object.
     * @throws ClassNotFoundException class not found.
     */
    public Class loadClass(String className) throws ClassNotFoundException 
    {
        return loadClass(className, true);
    }
    
    /**
     * The heart of the ClassLoader -- automatically compile
     * source as necessary when looking for class files
     * @param className the full class name.
     * @param resolve if true resolve the class, or prepare completely, not just lookup.
     * @return the class object.
     * @throws ClassNotFoundException class not found.
     */
    public Class loadClass(String className, boolean resolve) throws ClassNotFoundException 
    {
        byte[] bytes;                               //file as bytes
        Class result;                               //created class object
        String fileStub;                            //formatted class name for a file
        String javaFilename;                        //file stub with .java
        String classFilename;                       //file stub with .class
        File javaFile;                              //java source file
        File classFile;                             //java class file
        
        // First, see if we've already dealt with this one
        result = findLoadedClass(className);
        
        if (result == null)
        {
            //System.out.println( "findLoadedClass: "+result );
            // Create a pathname from the class className
            // E.g. java.lang.Object => java/lang/Object
            fileStub = className.replace('.', '/');

            // Build objects pointing to the source code (.java) and object
            // code (.class)
            javaFilename = fileStub + ".java";
            classFilename = fileStub + ".class";
            javaFile = new File(javaFilename);
            classFile = new File(classFilename);

            //System.out.println( "j "+javaFile.lastModified()+" c "+
            // classFile.lastModified() );
            // First, see if we want to try compiling. We do if (a) there
            // is source code, and either (b0) there is no object code,
            // or (b1) there is object code, but it's older than the source
            if (javaFile.exists() && (!classFile.exists()
                || javaFile.lastModified() > classFile.lastModified())) 
            {
                try 
                {
                    // Try to compile it. If this doesn't work, then
                    // we must declare failure. (It's not good enough to use
                    // and already-existing, but out-of-date, class file)
                    if (!compile(javaFilename) || !classFile.exists()) 
                    {
                        throw new ClassNotFoundException("Compile failed: " + javaFilename);
                    }
                } 
                catch (IOException ie) 
                {
                    // Another place where we might come to if we fail to compile
                    throw new ClassNotFoundException(ie.toString());
                }
            }
            // Let's try to load up the raw bytes, assuming they were
            // properly compiled, or didn't need to be compiled
            try 
            {
                // read the bytes
                bytes = getBytes(classFilename);

                // try to turn them into a class
                result = defineClass(className, bytes, 0, bytes.length);
            } 
            catch (IOException ie) 
            {
                // This is not a failure! If we reach here, it might
                // mean that we are dealing with a class in a library,
                // such as java.lang.Object
            }

            //System.out.println( "defineClass: "+result );
            // Maybe the class is in a library -- try loading
            // the normal way
            if (result == null) 
            {
                result = findSystemClass(className);
            }

            //System.out.println( "findSystemClass: "+result );
            // Resolve the class, if any, but only if the "resolve"
            // flag is set to true
            if (resolve && result != null) 
            {
                resolveClass(result);
            }
        }
        
        // If we still don't have a class, it's an error
        if (result == null) 
        {
            throw new ClassNotFoundException(className);
        }
        
        // Otherwise, return the class
        return result;
    }
    
    /**
     * Find and return the class from the parsed jar file list.
     * @param className the full class name.
     * @return the class object, or null if one does not exist.
     */
    public Class findClass(String className) 
    {
        int nextValue;                              //next value
        byte[] classByte;                           //class byte stream
        Class result;                               //created class object
        InputStream is;                             //input stream
        ByteArrayOutputStream byteStream;           //byte input stream
        JarEntry entry;                             //jar entry
        
        //check in cached classes first
        result = cachedClasses.get(className);
        
        if (result != null) 
        {
            return result;
        }
        try 
        {
            return findSystemClass(className);
        } 
        catch (Exception e) 
        {}

        try 
        {
            result = null;
            if ((jar == null) && (jarFile != null))
            {
                jar = new JarFile(jarFile);
            }
            
            if (jar != null)
            {
                entry = jar.getJarEntry(className);           
                if (entry != null)
                {
                    is = jar.getInputStream(entry);
                    byteStream = new ByteArrayOutputStream();

                    nextValue = is.read();
                    while (-1 != nextValue) 
                    {
                        byteStream.write(nextValue);
                        nextValue = is.read();
                    }

                    classByte = byteStream.toByteArray();
                    result = defineClass(className, classByte, 0, classByte.length, null);
                    cachedClasses.put(className, result);
                }
            }
            
            return result;
        } 
        catch (Exception ex) 
        {
            ExceptionHandler.debugException(logger, LoggerHandler.WARN, "findClass",
                (jarFile + ": "), ex);

            return null;
        }
    }
    
    /**
     * Given a filename, read the entirety of that file from disk and return it as a byte array.
     * @param filename the name of the file to read.
     * @return the read byte array.
     * @throws IOException error reading the stream.
     */
    private byte[] getBytes(String filename) throws IOException 
    {
        // Find out the length of the file
        File file = new File(filename);
        long len = file.length();
        
        // Create an array that's just the right size for the file's contents
        byte[] raw = new byte[(int) len];
        
        // Open the file
        FileInputStream fin = new FileInputStream(file);
        
        // Read all of it into the array; if we don't get all, then it's an error.
        int r = fin.read(raw);
        if (r != len) 
        {
            throw new IOException("Can't read all, " + r + " != " + len);
        }
        
        fin.close();
        return raw;
    }
    
    /**
     * Spawn a process to compile the java source code file specified in the 'javaFile' 
     * parameter. Return a true if the compilation worked, false otherwise.
     * @param javaFile the java source file to compile.
     * @return true if compiled OK, false otherwise.
     * @throws IOException file exception.
     */
    private boolean compile(String javaFile) throws IOException 
    {
        // Start up the compiler
        Process p = Runtime.getRuntime().exec("javac " + javaFile);
        
        // Wait for it to finish running
        try 
        {
            p.waitFor();
        }
        catch (InterruptedException ie) {}
        
        // Check the return code, in case of a compilation error
        int ret = p.exitValue();
        
        // Tell whether the compilation worked
        return (ret == 0);
    }
    
    /**
     * Retrieve and return the names of all classes stored in the jar identified 
     * by the uri. This does not add the jar as a permanent class loader. It only 
     * parses it to retrieve the class list. Use 'addLoader' or 'loadObject' to
     * add as a permanent loader.
     * @param rtnOnError if true, exit with the first load error, returning null. If
     * false, try to load every class and ignore any errors.
     * @return a list of all class names.
     */
    public ArrayList<String> getAllClasses(boolean rtnOnError)
    {
        String jarName;                             //jar name
        Class nextClass;                            //next class
        ArrayList<String> classes;                  //all classes
        Enumeration<JarEntry> entries;              //entries
        JarEntry jarEntry;                          //jar entry

        try
        {
            classes = new ArrayList<>();
            
            if (jar == null) jar = new JarFile(jarFile);
            entries = jar.entries();

            while (entries.hasMoreElements())
            {
                jarEntry = entries.nextElement();
                jarName = jarEntry.getName().trim();

                if (LoadObject.isLegalClassFile(jarName)) {
                    jarName = StringHandler.replaceAll(jarName, ".class", "").trim();
                    jarName = StringHandler.replaceAll(jarName, "/", ".");

                    try {
                        nextClass = findClass(jarName);
                        classes.add(nextClass.getName());
                    }
                    catch (Exception ex2) {
                        //do not output message as can be security
                        //restriction or missing external jar
                        if (rtnOnError) return null;
                    }
                    catch (Throwable th) {
                        //do not output message as can be security
                        //restriction or missing external jar
                        if (rtnOnError) return null;
                    }
                }
            }

            return classes;
        }
        catch (Exception ex)
        {
            ExceptionHandler.debugException(logger, LoggerHandler.WARN, "getAllClasses",
                (jarFile + ": "), ex);

            return null;
        }
    }
    
    /**
     * Get the local file path that the jar file was loaded from.
     * @return the value of jarFile.
     */
    public String getFilePath()
    {
        return jarFile;
    }
}
