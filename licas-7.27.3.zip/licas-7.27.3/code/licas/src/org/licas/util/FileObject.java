/*
 * FileObject.java
 *
 * Created on 21 July 2007
 *
 * Version 1.10.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.FileLoader;
import org.licas.parsers.types.Base64;
import org.licas.parsers.types.DomParser;
import org.licas.util.classloader.LoadObject;
import org.licas_text.util.WebResourceHandler;

import java.io.File;
import java.util.ArrayList;


/**
 * This stores the details and contents for a file that can be represented by an
 * instance of this class. The file path and optional Java class name is stored. The 
 * file contents are stored as a list of bytes, or as a string or xml-based representation.
 * @author Kieran Greer
 */
public class FileObject 
{
    /** The logger */
    private static final Logger logger;
    
    
    /** This define the file path */
    protected String filePath;
    
    /** This defines the class type */
    protected String classType;
    
    /** The file contents */
    protected Object fileContents;
    
    /** 
     * If true the contents can only be stored as a list of bytes. If false, then
     * xml or string-based representations are also possible. The default is false.
     */
    protected boolean asBytes;
    
    /** Password of either type to protect processing on a remote service, for example. */
    protected String password;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(FileObject.class.getName());
        logger.setDebug(false);
    }
    
    
    /** Creates a new instance of FileObject */
    public FileObject() 
    {
        initialise();
    } 
    
    /** Initialise some values */
    private void initialise()
    {
        filePath = null;
        classType = null;
        fileContents = null;
        asBytes = false;
        password = Const.ANON;
    }
    
    /**
     * Set a value indicating that the file contents can only be stored as a byte 
     * list and not in any other form.
     * @param thisAsBytes true if the file contents can only be stored as a byte list.
     */
    public void setAsBytes(boolean thisAsBytes)
    {
        asBytes = thisAsBytes;
    }
    
    /**
     * Get a value indicating that the file contents can only be stored as a byte list.
     * @return the value of asBytes.
     */
    public boolean getAsBytes()
    {
        return asBytes;
    }
    
    /**
     * Set the file path to the value passed in.
     * @param theFilePath the file path.
     */
    public void setFilePath(String theFilePath)
    {
        filePath = theFilePath;
    }
    
    /**
     * Get the file path.
     * @return the value of filePath.
     */
    public String getFilePath()
    {
        return filePath;
    }
    
    /**
     * Set the class type this file relates to.
     * @param theClassType the class type.
     */
    public void setClassType(String theClassType)
    {
        classType = theClassType;
    }
    
    /**
     * Get the class type this file relates to.
     * @return the value of classType.
     */
    public String getClassType()
    {
        return classType;
    }
    
    /**
     * Set the security password.
     * @param thePassword the security password.
     */
    public void setPassword(String thePassword)
    {
        password = thePassword;
    }
    
    /**
     * Get the security password.
     * @return the value of password.
     */
    public String getPassword()
    {
        return password;
    }
    
    /**
     * Set the contents of this file to the value passed in.
     * @param theFileContents the file contents.
     */
    public void setFileContents(Object theFileContents)
    {
        fileContents = theFileContents;
    }
    
    /**
     * Add the object passed in to the end of the file contents.
     * @param theFileContents can be either a String or a ArrayList of Bytes.
     * @return true if added, false otherwise.
     */
    public boolean addFileContents(Object theFileContents)
    {
        if (ObjectHandler.isString(fileContents) && ObjectHandler.isString(theFileContents))
        {
            fileContents = ((String)fileContents + (String)theFileContents);
            return true;
        }
        else if ((fileContents instanceof ByteArray) && (theFileContents instanceof ByteArray))
        {
            ((ByteArray)fileContents).setByteArray((((ByteArray)fileContents).getByteArray() +
                    ((ByteArray)theFileContents).getByteArray()));
            return true;
        }
        else if ((fileContents instanceof ArrayList) && (theFileContents instanceof ArrayList))
        {
            ((ArrayList)fileContents).addAll((ArrayList)theFileContents);            
            return true;
        }
        
        return false;
    }
    
    /**
     * Get the contents of the file.
     * @return the value of fileContents.
     */
    public Object getFileContents()
    {
        Object dynamicFile;                         //dynamic file contents
        
        dynamicFile = fileContents;
        try
        {
            if (dynamicFile == null)
            {
                loadFile(filePath);
                dynamicFile = fileContents;
                fileContents = null;
            }
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getFileContents", 
                    "", ex);
        }
        
        return dynamicFile;
    }
    
    /**
     * Return true if the file requires a byte array.
     * @param filePath the file path.
     * @return true if byte list required, false otherwise.
     */
    private boolean requiresByteArray(String filePath)
    {
        return (asBytes || isBinaryFile(filePath));
    }
    
    /**
     * Return true if the data type is known, for example 'text/html', or 'image,png', etc.
     * @param dataType the data type, usually for a browser realisation.
     * @return true if the data type is already known and does not need to be changed.
     */
    public static boolean isKnownDataType(String dataType)
    {
        if (dataType != null)
        {
            return (isKnownTextType(dataType) ||
                    isKnownBinaryType(dataType));
        }
                    
        return false;
    }
    
    /**
     * Return true if the data type is a known text type, for example 'text/html', etc.
     * @param dataType the data type, usually for a browser realisation.
     * @return true if the data type is already known and does not need to be changed.
     */
    public static boolean isKnownTextType(String dataType)
    {
        if (dataType != null)
        {
            return (dataType.equalsIgnoreCase("text/plain") ||
                    isKnownHtmlType(dataType) ||
                    isKnownXmlType(dataType));
        }
                    
        return false;
    }
    
    /**
     * Return true if the data type is a known html type, for example 'text/xhtml', etc.
     * @param dataType the data type, usually for a browser realisation.
     * @return true if the data type is already known and does not need to be changed.
     */
    public static boolean isKnownHtmlType(String dataType)
    {
        if (dataType != null)
        {
            return (dataType.equalsIgnoreCase("text/html") ||
                    dataType.equalsIgnoreCase("text/xhtml") ||
                    dataType.equalsIgnoreCase("text/css") ||
                    dataType.equalsIgnoreCase("text/javascript"));
        }
                    
        return false;
    }
    
    /**
     * Return true if the data type is a known xml type, for example 'text/xml', etc.
     * @param dataType the data type, usually for a browser realisation.
     * @return true if the data type is already known and does not need to be changed.
     */
    public static boolean isKnownXmlType(String dataType)
    {
        if (dataType != null)
        {
            return (dataType.equalsIgnoreCase("text/xml"));
        }
                    
        return false;
    }
    
    /**
     * Return true if the data type is a known binary type, for example 'image,png', 
     * or 'Application/pdf', etc.
     * @param dataType the data type, usually for a browser realisation.
     * @return true if the data type is already known and does not need to be changed.
     */
    public static boolean isKnownBinaryType(String dataType)
    {
        if (dataType != null)
        {
            return (isKnownImageType(dataType) ||
                    isKnownApplicationType(dataType));
        }
                    
        return false;
    }
    
    /**
     * Return true if the data type is a known image type, for example 'image,png', etc..
     * @param dataType the data type, usually for a browser realisation.
     * @return true if the data type is already known and does not need to be changed.
     */
    public static boolean isKnownImageType(String dataType)
    {
        if (dataType != null)
        {
            return (dataType.equalsIgnoreCase("image/gif") ||
                    dataType.equalsIgnoreCase("image/png") ||
                    dataType.equalsIgnoreCase("image/jpg") ||
                    dataType.equalsIgnoreCase("image/jpeg") ||
                    dataType.equalsIgnoreCase("image/tif") ||
                    dataType.equalsIgnoreCase("image/tiff") ||
                    dataType.equalsIgnoreCase("image/ico"));
        }
                    
        return false;
    }
    
    /**
     * Return true if the data type is a known application type, for example 'Application/pdf', etc..
     * @param dataType the data type, usually for a browser realisation.
     * @return true if the data type is already known and does not need to be changed.
     */
    public static boolean isKnownApplicationType(String dataType)
    {
        if (dataType != null)
        {
            return (dataType.equalsIgnoreCase("Application/pdf") ||
                    dataType.equalsIgnoreCase("Application/msword") ||
                    dataType.equalsIgnoreCase("Application/x-msexcel"));
        }
                    
        return false;
    }
    
    /**
     * Return true if the file path end with a known file type. The path itself
     * might not be correct, but it ends with a known file type nameOnly.
     * @param fileName the file name or full file path.
     * @return true if it indicates a known file type.
     */
    public static boolean isKnownFile(String fileName)
    {
        String postfix;                         //postfix name
        
        if (fileName != null)
        {
            postfix = getFileType(fileName);
            if (postfix != null) 
            {
                return (isTextFile(fileName) ||
                        isImageFile(fileName) ||
                        isBinaryFile(fileName));
            }
        }
                    
        return false;
    }
    
    /**
     * Return true if the file path ends with a known text file type. That is,
     * something that is not binary but is in ascii text format.
     * The path itself might not be correct, but it ends with a known file type nameOnly.
     * @param fileName the file name or full file path.
     * @return true if it indicates a known text file type.
     */
    public static boolean isTextFile(String fileName)
    {
        String postfix;                         //postfix name
        
        if (fileName != null)
        {
            postfix = getFileType(fileName);
            if (postfix != null) 
            {
                return WebResourceHandler.isTextFile(postfix);
            }
        }
                    
        return false;
    }
    
    /**
     * Return true if the file is binary, requiring a byte list.
     * @param fileName the file path or name.
     * @return true if byte list required, false otherwise.
     */
    public static boolean isBinaryFile(String fileName)
    {
        String postfix;                         //postfix name
        
        if (fileName != null)
        {
            postfix = getFileType(fileName);
            if (postfix != null) 
            {
                return WebResourceHandler.isBinaryFile(postfix);
            }
        }
                    
        return false;
    }
    
    /**
     * Return true if the file path ends with a known xml file type. The path itself
     * might not be correct, but it ends with a known file type nameOnly.
     * @param fileName the file name or full file path.
     * @return true if it indicates a known xml file type.
     */
    public static boolean isXmlFile(String fileName)
    {
        String postfix;                         //postfix name
        
        if (fileName != null)
        {
            postfix = getFileType(fileName);
            return WebResourceHandler.isXmlFile(postfix);
        }
                    
        return false;
    }
    
    /**
     * Return true if the file path ends with a known image file type. The path itself
     * might not be correct, but it ends with a known file type nameOnly.
     * @param fileName the file name or full file path.
     * @return true if it indicates a known image file type.
     */
    public static boolean isImageFile(String fileName)
    {
        String postfix;                         //postfix name
        
        if (fileName != null)
        {
            postfix = getFileType(fileName);
            if (postfix != null) 
            {
                return WebResourceHandler.isImageFile(postfix);
            }
        }
                    
        return false;
    }
    
    /**
     * Return true if the file path ends with a known internet file type. The path itself
     * might not be correct, but it ends with a known file type nameOnly. Not every
     * type is included.
     * @param fileName the file name or full file path.
     * @return true if it indicates a known internet file type.
     */
    public static boolean isHtmlFile(String fileName)
    {
        String postfix;                         //postfix name
        
        if (fileName != null)
        {
            postfix = getFileType(fileName);
            if (postfix != null) 
            {
                return WebResourceHandler.isHtmlFile(postfix);
            }
        }
                    
        return false;
    }
    
    /**
     * Return true if an xml file representation should be used.
     * @param fileName the file path or name.
     * @return true if the file type indicates an xml file and binary has not
     * already been specified.
     */
    protected boolean useAsXmlFile(String fileName)
    {
        return (!asBytes && isXmlFile(fileName));
    }
    
    /**
     * Get the file type.
     * @param fileName the file name or full file path.
     * @return the nameOnly, or content after the last '.'.
     */
    public static String getFileType(String fileName)
    {
        int index;                              //index
        String postfix;                         //postfix name
        
        postfix = fileName;
        if (postfix != null)
        {
            index = fileName.lastIndexOf(".");
            if (index >= 0) postfix = fileName.substring(index+1).toLowerCase();
        }
                    
        return postfix;
    }
    
    /**
     * Remove the file type from the file name.
     * @param fileName the file name or full file path.
     * @return the filename, or content before the last '.'.
     */
    public static String removeFileType(String fileName)
    {
        int index;                              //index
        String nameOnly;                        //name only
        
        nameOnly = fileName;
        if (nameOnly != null)
        {
            index = fileName.lastIndexOf(".");
            if (index >= 0) nameOnly = fileName.substring(0, index);
        }
                    
        return nameOnly;
    }
    
    /**
     * Get the html content file type description from the file path.
     * @param fileName the file name or full file path.
     * @return the content type, to add to an http message resource.
     */
    public static String contentTypeFromFile(String fileName)
    {
        String contentType;                     //content type
        String postfix;                         //postfix name
        
        contentType = null;
        if (fileName != null)
        {
            postfix = getFileType(fileName);
            if (postfix != null) 
            {
                if (postfix.equalsIgnoreCase("html"))
                {
                    contentType = "text/html";
                }
                else if (postfix.equalsIgnoreCase("xhtml"))
                {
                    contentType = "text/xhtml";
                }
                else if (postfix.equalsIgnoreCase("css"))
                {
                    contentType = "text/css";
                }
                else if (postfix.equalsIgnoreCase("js"))
                {
                    contentType = "text/javascript";
                }
                else if (postfix.equalsIgnoreCase("gif"))
                {
                    contentType = "image/gif";
                }
                else if (postfix.equalsIgnoreCase("png"))
                {
                    contentType = "image/png";
                }
                else if (postfix.equalsIgnoreCase("jpeg") ||
                        postfix.equalsIgnoreCase("jpg"))
                {
                    contentType = "image/jpeg";
                }
                else if (postfix.equalsIgnoreCase("tiff") ||
                        postfix.equalsIgnoreCase("tif"))
                {
                    contentType = "image/tiff";
                }
                else if (postfix.equalsIgnoreCase("ico"))
                {
                    contentType = "image/ico";
                }
                else if (postfix.equalsIgnoreCase("pdf"))
                {
                    contentType = "Application/pdf";
                }
                else if (postfix.equalsIgnoreCase("doc") ||
                        postfix.equalsIgnoreCase("docx"))
                {
                    contentType = "Application/msword";
                }
                else if (postfix.equalsIgnoreCase("xls") ||
                        postfix.equalsIgnoreCase("xlsx") ||
                        postfix.equalsIgnoreCase("xlsb") ||
                        postfix.equalsIgnoreCase("csv"))
                {
                    contentType = "Application/x-msexcel";
                }
                else if (postfix.equalsIgnoreCase("xml"))
                {
                    contentType = "text/xml";
                }
                else
                {
                    contentType = "text/plain";
                }
            }
        }
                    
        return contentType;
    }
    
    /**
     * Get the html content file type description from the content itself. This
     * is used for specific cases only.
     * @param bodyStr the file content as a string.
     * @return the content type, to add to an http message resource.
     */
    public static String contentTypeFromCode(String bodyStr)
    {
        String contentType;                         //content type
        String contentStart;                        //content start
        
        contentType = null;
        if (isKnownDataType(bodyStr))
        {
            contentType = bodyStr;
        }
        else if (TypeConst.isBinaryType(bodyStr))
        {
            contentType = contentTypeFromFile(bodyStr);
        }
        else if (TypeConst.isXmlType(bodyStr))
        {
            contentType = "text/xml";
        }
        
        if (contentType == null)
        {
            if (bodyStr.length() > 12)
                contentStart = bodyStr.substring(0, 12);
            else
                contentStart = bodyStr;
            
            if (TypeConst.isURL(contentStart) || TypeConst.isHtml(contentStart))
            {
                contentType = "text/html";
            }
            else 
            {
                if (isHtmlContent(contentStart)) 
                    contentType = "text/html";
                else if (bodyStr.equals(TypeConst.XMLFILE))
                    contentType = "text/xml";
            }
        }
        
        if (contentType == null)
        {
            contentType = "text/plain";
        }
        
        return contentType;
    }
    
    /**
     * Return true if the text start with formatting indicating html content.
     * @param theText the text content to parse.
     * @return true if it indicates a html content.
     */
    private static boolean isHtmlContent(String theText)
    {
        if (theText != null)
        {
            return (theText.toLowerCase().startsWith("<!doc") ||
                theText.toLowerCase().startsWith("<html"));
        }
                    
        return false;
    }
    
    /**
     * Load the contents of the file specified by the path into an appropriate data structure.
     * @param theFilePath the local path of the file to load.
     * @throws java.lang.Exception any error.
     */
    public void loadFile(String theFilePath) throws Exception
    {
        try
        {
            filePath = theFilePath; 
            if (requiresByteArray(filePath)) 
            {
                fileContents = fileToByteArray(filePath);
            }
            else if (useAsXmlFile(filePath)) 
            {
                fileContents = DomParser.parse(FileLoader.getInputStream(filePath));
            }
            else 
            {
                fileContents = FileLoader.getInputStream(filePath);
                if (fileContents != null) fileContents = ((String)fileContents).trim();
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "loadFile",
                    null, ex);
        }
    }
    
    /**
     * Copy the source input stream contents to a list of Byte objects.
     * @param filePath the file path in string format.
     * @return the source stream as a list of Byte objects.
     */
    public static ByteArray fileToByteArray(String filePath)
    {
        ByteArray byteArray;                    //byte array as a string
 
        byteArray = new ByteArray();
        byteArray.setByteArray(Base64.encodeFromFile(filePath));
        
        return byteArray;
    }
    
    /**
     * Copy the source input stream contents to the destination file.
     * @param sourceFile the file to copy.
     * @param destFile the file path to copy to
     * @throws java.lang.Exception any error.
     */
    public static void copyStream(File sourceFile, File destFile) throws Exception
    {
        FileLoader.copyStream(sourceFile, destFile);
    }

    /**
     * Get the current directory the program is running in.
     * @return the directory path in String format.
     * @throws java.lang.Exception any error. 
     */
    public static String getCurrentDirectory() throws Exception
    {
        return FileLoader.getCurrentDirectory();
    }
    
    /**
     * Get the list of directories stored in the specified directory.
     * @param dirPath the directory path.
     * @return a list of all directories stored under this directory.
     */
    public static ArrayList<String> getDirectoryList(String dirPath)
    {
        return FileLoader.getDirectoryList(dirPath);
    }
    
    /**
     * Get the list of files stored in the specified directory.
     * @param dirPath the directory path.
     * @return a list of all files stored under this directory.
     * @throws java.lang.Exception any error.
     */
    public static ArrayList<String> getFileList(String dirPath) throws Exception
    {
        return FileLoader.getFileList(dirPath);
    }
    
    /**
     * Get the list of files stored in the specified directory.
     * @param dirPath the directory path.
     * @return a list of all files in the directory. This is the full file names, with paths.
     * @throws java.lang.Exception any error.
     */
    public static ArrayList<String> getFullFileListPaths(String dirPath) throws Exception
    {
        return FileLoader.getFullFileListPaths(dirPath, false);
    }
    
    /**
     * Get the list of files stored in the specified directory.
     * @param dirPath the directory path.
     * @param subFolders if true include all files in all sub-folders, if false include
     * files in the current folder only.
     * @return a list of all files in the directory. This is the full file names, with paths.
     * @throws java.lang.Exception any error.
     */
    public static ArrayList<String> getFullFileListPaths(String dirPath, boolean subFolders) throws Exception
    {
        return FileLoader.getFullFileListPaths(dirPath, subFolders);
    }

    /**
     * Get the list of all required jar files for a particular jar class.
     * @param jarFile the path for the base jar file.
     * @param serverIp the server ip address.
     * @return the base jar file formatted, together with any in its lib folder.
     * @throws java.lang.Exception any error.
     */
    public static ArrayList<String> getAllJarFilePaths(String jarFile, String serverIp) throws Exception
    {
        int i;
        File filePath;                                  //file path
        File[] allFiles;                                //list of all files
        ArrayList<String> jarFiles;                     //list of jar files

        //add the required jar files
        jarFiles = new ArrayList();
        jarFiles.add(LoadObject.addJarPrefix(serverIp, jarFile));

        //add any additional jar files in a lib folder
        filePath = new File(jarFile);
        filePath = filePath.getAbsoluteFile();
        jarFile = filePath.getParent();

        filePath = new File(jarFile + ServiceConst.LIBPATH);
        if (filePath.isDirectory())
        {
            allFiles = filePath.listFiles();
            for (i = 0; i < allFiles.length; i++)
            {
                if (allFiles[i].getName().endsWith(".jar")) {
                    jarFile = (filePath.getAbsolutePath() + Const.DIRSEP + allFiles[i].getName());
                    jarFiles.add(LoadObject.addJarPrefix(serverIp, jarFile));
                }
            }
        }

        return jarFiles;
    }
    
    /**
     * Check the file type to make sure it is in the file name.
     * @param theFile the file object with the full file path.
     * @param type the file type that should be indicated.
     * @return the same file object with a filename ending with the file type.
     */
    public static File checkFileType(File theFile, String type)
    {
        String postFix;                         //postfix setting
        
        postFix = type;
        if (!postFix.startsWith(".")) postFix = ("." + postFix);
        if (!theFile.getAbsolutePath().toLowerCase().endsWith(postFix))
        {
            theFile = new File(theFile.getAbsolutePath() + postFix);
        }
        
        return theFile;
    }
    
    /**
     * Return a String description of this object.
     * @return the values as a String.
     */
    public String toString()
    {
        String descr = filePath;
        if (classType != null) descr += " - class type - " + classType;
        
        return descr;
    }
}
