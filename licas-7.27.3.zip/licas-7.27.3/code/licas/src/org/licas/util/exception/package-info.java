/**
 * Licas-specific exception types.
 */
package org.licas.util.exception;