/*
 * LicasException.java
 *
 * Created on 21 March 2007, 15:23
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util.exception;


import org.jlog2.exception.WriteMessageException;


/**
 * This class is thrown when a licas-related exception is detected.
 * @author Kieran Greer
 */
public class LicasException extends WriteMessageException 
{    
    /**
     * Create a new instance of LicasException. This exception is passed through
     * each time, although only the message part gets written to the logger.
     * @param message the error message.
     */
    public LicasException(String message)
    {
        super(message, false);
    }
    
    /**
     * Create a new instance of LicasException.
     * @param message the error message.
     * @param thisUseOnce if true pass through the logger only once, if false, then pass
     * through the logger each time.
     */
    public LicasException(String message, boolean thisUseOnce)
    {
        super(message, thisUseOnce);
    }    
}
