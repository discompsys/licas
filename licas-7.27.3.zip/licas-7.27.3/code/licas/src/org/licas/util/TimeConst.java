/*
 * TimeConst.java
 *
 * Created on 13 February 2013.
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util;


import java.util.ArrayList;


/**
 * Constant values relating to time periods.
 * @author Kieran Greer
 */
public class TimeConst 
{
    /** Time attribute name */
    public static final String TIMEPERIOD = "Time_Period";
    
    /** Day tag name */
    public static final String MILLISECONDPART = "Millisecond";
    
    /** Day tag name */
    public static final String SECOND = "Second";
    
    /** Day tag name */
    public static final String MINUTE = "Minute";
    
    /** Day tag name */
    public static final String HOUR = "Hour";
    
    /** Day tag name */
    public static final String DAY = "Day";
    
    /** Week tag name */
    public static final String WEEK = "Week";
    
    /** Month tag name */
    public static final String MONTH = "Month";
    
    /** Year tag name */
    public static final String YEAR = "Year";
	
	
	
    /** Second in milliseconds */
    public static final long MILLISECOND = 1000;
    
    /** Minute in milliseconds */
    public static final long MILLIMINUTE = (MILLISECOND * 60);
    
    /** Hour in milliseconds */
    public static final long MILLIHOUR = (MILLIMINUTE * 60);
    
    /** Day in milliseconds */
    public static final long MILLIDAY = (MILLIHOUR * 24);
    
    /** Day in milliseconds */
    public static final long MILLIWEEK = (MILLIDAY * 7);
    
    /** Month in milliseconds */
    public static final long MILLIMONTH = (MILLIDAY * 30);
    
    /** Year in milliseconds */
    public static final long MILLIYEAR = (MILLIMONTH * 12);
    
    
    /**
     * Get a list of all stored time periods.
     * @return a list of time period descriptions.
     */
    public static ArrayList<String> getTimePeriods()
    {
        ArrayList<String> timeList;                 //list of time descriptions
        
        timeList = new ArrayList<>();
        timeList.add(MILLISECONDPART);
        timeList.add(SECOND);
        timeList.add(MINUTE);
        timeList.add(HOUR);
        timeList.add(DAY);
        timeList.add(WEEK);
        timeList.add(MONTH);
        timeList.add(YEAR);
        
        return timeList;
    }
    
    
    /**
     * Get a list of all stored time periods, between and including the start/end.
     * @param start period to start with. If null start from the smallest one.
     * @param end period to end with. If null end with the largest one.
     * @return the list of time periods.
     */
    public static ArrayList<String> getTimePeriods(String start, String end)
    {
        int i;
        boolean isStart;                            //true if is start
        boolean isEnd;                              //true if is end
        String nextTimePeriod;                      //next time period
        ArrayList<String> timeList;                 //list of time descriptions
        
        isStart = false;
        isEnd = false;
        if (start == null) start = MILLISECONDPART;
        if (end == null) end = YEAR;        
        timeList = getTimePeriods();
        
        i = 0;
        while (i < timeList.size())
        {
            nextTimePeriod = timeList.get(i);
            if (!isStart) isStart = (start.equals(nextTimePeriod));
            
            if (isEnd || !isStart) {
                timeList.remove(i);
            }
            else {
                isEnd = (end.equals(nextTimePeriod));
                i++;
            }
        }
        
        return timeList;
    }
    
    /**
     * Convert the milliseconds value into a number for the the time unit.
     * @param timeUnit the unit to convert to.
     * @param milliseconds the time in milliseconds.
     * @return the time in the specified time units.
     */
    public static long asTimeUnit(String timeUnit, long milliseconds)
    {
        long timeCount;                  //time in milliseconds
        
        timeCount = 0;
        switch (timeUnit) {
            case MILLISECONDPART:
                timeCount = milliseconds;
                break;
            case SECOND:
                timeCount = (milliseconds / MILLISECOND);
                break;
            case MINUTE:
                timeCount = (milliseconds / MILLIMINUTE);
                break;
            case HOUR:
                timeCount = (milliseconds / MILLIHOUR);
                break;
            case DAY:
                timeCount = (milliseconds / MILLIDAY);
                break;
            case WEEK:
                timeCount = (milliseconds / MILLIWEEK);
                break;
            case MONTH:
                timeCount = (milliseconds / MILLIMONTH);
                break;
            case YEAR:
                timeCount = (milliseconds / MILLIYEAR);
                break;
        }
        
        return timeCount;
    }
    
    /**
     * Convert the number of time units into a total milliseconds value.
     * @param timeUnit the time unit.
     * @param timeCount the number of this time unit.
     * @return the total time in milliseconds.
     */
    public static long getMilliseconds(String timeUnit, int timeCount)
    {
        long milliseconds;                  //time in milliseconds
        
        milliseconds = 0;
        switch (timeUnit) {
            case MILLISECONDPART:
                milliseconds = timeCount;
                break;
            case SECOND:
                milliseconds = (timeCount * MILLISECOND);
                break;
            case MINUTE:
                milliseconds = (timeCount * MILLIMINUTE);
                break;
            case HOUR:
                milliseconds = (timeCount * MILLIHOUR);
                break;
            case DAY:
                milliseconds = (timeCount * MILLIDAY);
                break;
            case WEEK:
                milliseconds = (timeCount * MILLIWEEK);
                break;
            case MONTH:
                milliseconds = (timeCount * MILLIMONTH);
                break;
            case YEAR:
                milliseconds = (timeCount * MILLIYEAR);
                break;
        }
        
        return milliseconds;
    }
}
