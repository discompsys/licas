/*
 * AiConst.java
 *
 * Created on 13 June 2014.
 *
 * Version 1.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util;


import org.licas.MessageInfo;


/**
 * Some constant values relating to the AI components of the licas library.
 * @author Kieran Greer
 */
public class AiConst 
{ 
    //Autonomic manager tags
    /** Defines autonomic manager tag */
    public static final String AUTONOMICMANAGER = "Autonomic_Manager";

    /** Defines monitor module */
    public static final String MONITOR = "Monitor";

    /** Defines analysis module */
    public static final String ANALYZE = "Analyze";

    /** Defines planner module */
    public static final String PLAN = "Plan";

    /** Defines execution module */
    public static final String EXECUTE = "Execute";

    /** Number of test runs */
    public static final String TESTRUNS = "Test_Runs";

    /** Defines the end of a test */
    public static final String TESTENDED = "Test_Ended";
    
    /** Defines effector or effector action */
    public static final String EFFECTOR = "Effector";
    
    /** General term for the {@link MessageInfo} message Object value */
    public static final String MI_OBJECT = "MI_Object";

    
    
    /** Defines a fault a determined by an autonomic manager */
    public static final String AUTOMANFAULT = "Autonomic_Manager_Fault";
    
    /** Defines a policy */
    public static final String POLICY = "Policy";
    
    /** Defines a policy */
    public static final String PROCESS = "Process";
    
    /** Defines an action */
    public static final String ACTION = "Action";
    
    /** Defines max number of iterations */
    public static final String ITERATIONS = "Iterations";
    
    /** Defines an action to block access to something (service) */
    public static final String ACTIONBLOCK = "Block";
    
    /** Defines an action to unblock access to something (service) */
    public static final String ACTIONUNBLOCK = "Unblock";
    
    /** Defines an action to shutdown something (service) */
    public static final String ACTIONSHUTDOWN = "Shutdown";
    
    /** Defines state for effector action */
    public static final String EFFECTACTION = "EffectAction";
    
    /** Defines state for no action */
    public static final String NOACTION = "NoAction";
    
    /** Defines start of replace with indexer */
    public static final String RELACEWITH = "Replace_";
    
    
    
    //Problem Solving
    /** Defines a problem solving admin element */
    public static final String AISOLVER = "AI_Solver";  
    
    /** Defines load data remotely tag */
    public static final String LOADREMOTE = "Load_Remote";
    
    /** Defines load content directly tag */
    public static final String LOADCONTENT = "Load_Content";
    
    
    //Defines AI script tags
    public static final String HEURISTICOPTIONS = "Heuristic_Options";    
    public static final String HEURISTICOPTION = "Heuristic_Option";    
    public static final String HEURISTICTYPE = "Heuristic_Type";
    public static final String METRICTYPE = "Metric_Type";
    
    
    //Defines some other ID tags
    public static final String THIS = "this";
    public static final String METHOD = "method";
}
