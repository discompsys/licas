/*
 * ObjectHandler.java
 *
 * Created on 11 January 2009
 *
 * Version 1.14
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util;


import com.vladium.utils.IObjectProfileNode;
import com.vladium.utils.ObjectProfiler;
import org.ai_heuristic.util.SymbolHandler;
import org.licas.Service;
import org.licas.call.Handle;
import org.licas.meta.MetaFactory;
import org.licas.module.*;
import org.licas.parsers.Parsers;
import org.licas.parsers.types.*;
import org.licas.server.LocalServer;
import org.licas_text.util.QueryConst;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;

import java.lang.reflect.Method;
import java.util.*;


/**
 * This class provides methods to process or compare objects, with reference to licas 
 * objects in particular. Note that you can add a {@code getKey()} method to your own 
 * object and this class will try to use it with its own {@code getKey} method.
 * @author Kieran Greer
 */
public class ObjectHandler 
{
    /**
     * Return the key relating to the object specified.
     * If the object is derived from a licas Service, then its uuid is returned,
     * if the object is an Element, then its String equivalent is returned.
     * If the object is complex, then if it implements a {@code getKey()} method, an
     * attempt to invoke that is tried, if that fails then the {@code String} value of the 
     * object is returned.
     * @param ob1 the representation of the object.
     * @return the key value for the source.
     * @throws java.lang.Exception any error.
     */
    public static String getKey(Object ob1) throws Exception
    {
        Object[] args;                      //arguments
        Method theMethod;                   //method to invoke
        
        if (ModuleHandler.isFrameworkModule(ob1)) {
            return ((FrameworkModule)ob1).getUUID();
        }
        else if (ob1 instanceof Element) {
            return XmlHandler.xmlToString((Element)ob1);
        }
        else {
            try {
                theMethod = ReflectionHandler.retrieveMethod(ob1.getClass(), "getKey", 
                        TypeConst.STRING);

                if (theMethod != null) {
                    args = new Object[0];
                    return String.valueOf(theMethod.invoke(ob1, args));
                }
            }
            catch (Exception mex) {}
            
            return String.valueOf(ob1);
        }
    }

    /**
     * Return a String-based representation of the object value. This either parses
     * an XML-based value or returns {@code String.valueOf()}. If the value is a service,
     * then it will try to retrieve the uuid name.
     * @param theValue the object value to describe.
     * @return the object value in String format.
     * @throws java.lang.Exception any error.
     */
    public static String getValue(Object theValue) throws Exception
    {
        String valueStr;            //object value as a String

        valueStr = null;
        if (theValue != null) {
            if (ModuleHandler.isFrameworkModule(theValue)) {
                try {
                    valueStr = getKey(theValue);
                }
                catch (Exception ex) {
                    valueStr = String.valueOf(theValue);
                }
            }
            else if (theValue instanceof Element) {
                valueStr = XmlHandler.xmlToString((Element)theValue);
            }
            else {
                valueStr = String.valueOf(theValue);
            }
        }

        return valueStr;
    }

    /**
     * Return the object class name in a format suitable for logging.
     * @param theObject the object to describe.
     * @return the object class name in String format.
     */
    public static String getClass(Object theObject)
    {
        String className;                    //the class name

        if (theObject != null) {
            className = theObject.getClass().getName();
        }
        else {
            className = null;
        }

        return className;
    }
    
    /**
     * Return an Element defining the path to the object specified.
     * If the object is derived from a licas Service, then the getFullPath()
     * method is used to retrieve the path. If the object is an Element then it is 
     * returned as it is, otherwise the element is constructed as follows:
     * The Handle class is used to create a handle with the uri of the current server,
     * The String.valueOf value of the object is then used to add a handle part 
     * to the whole handle and this is then returned. This is not a reliable option 
     * however and the value passed in should be either a Service or an Element.
     * @param ob1 the representation of the object.
     * @return the path value for the source.
     * @throws java.lang.Exception any error.
     */
    public static Element getElementPath(Object ob1) throws Exception
    {
        Element newPath;                //new path definition
        
        if (ob1 instanceof Service) {
            newPath = ((Service)ob1).getFullPath();
        }
        else if (ob1 instanceof Element) {
            newPath = (Element)ob1;
        }
        else {
            newPath = Handle.createNewUrlHandle(LocalServer.getServerURL());
            newPath = Handle.addToHandle(newPath, Handle.asHandleElement(String.valueOf(ob1)));
        }
        
        return newPath;
    }
    
    /**
     * Return true if the two objects are equal to each other as defined by this method.
     * If the objects are derived from licas Services, then their uuids are compared.
     * If they are XML elements then the element values are compared.
     * If they are strings then the String.equals is used, otherwise Object.equals is used.
     * @param ob1 the first object to compare.
     * @param ob2 the second object to compare.
     * @return true if the objects are the same as defined by this method.
     * @throws java.lang.Exception any error.
     */
    public static boolean equals(Object ob1, Object ob2) throws Exception
    {
        String val1;                //string value representation of object1
        String val2;                //string value representation of object2
        boolean isEqual;            //true if equal
        
        if (ModuleHandler.isService(ob1)) {
            val1 = ((Service)ob1).getUUID();
        }
        else if (isElement(ob1)) {
            val1 = XmlHandler.xmlToString((Element)ob1);
        }
        else if (isString(ob1)) {
            val1 = (String)ob1;
        }
        else {
            val1 = null;
        }
        
        if (ModuleHandler.isService(ob2)) {
            val2 = ((Service)ob2).getUUID();
        }
        else if (isElement(ob2)) {
            val2 = XmlHandler.xmlToString((Element)ob2);
        }
        else if (isString(ob2)) {
            val2 = (String)ob2;
        }
        else {
            val2 = null;
        }
        
        if ((val1 != null) && (val2 != null)) {
            isEqual = val1.equals(val2);
        }
        else {
            isEqual = ob1.equals(ob2);
        }
        
        return isEqual;
    }

    /**
     * Try to convert the parameter into an Object if possible.
     * @param param the parameter in String format. Can also represent a list.
     * @return the parameter converted into an other Object format if required.
     */
    public static Object convertParameter(Object param)
    {
        int i;
        Object paramObj;                    //parameter as an object
        Object nextParam;                   //next parameter

        try {
            if (param instanceof ArrayList) {
                paramObj = new ArrayList();
                for (i = 0; i < ((ArrayList)param).size(); i++)
                {
                    nextParam = ((ArrayList)param).get(i);
                    ((ArrayList)paramObj).add(Parsers.parseObject(nextParam));
                }
            }
            else if (!ObjectHandler.isString(param)) {
                paramObj = Parsers.parseObject(param);
            }
            else {
                paramObj = param;
            }
        }
        catch (Exception ex) {
            paramObj = param;
        }

        return paramObj;
    }

    /**
     * Check if the two parameters match with regard to class type.
     * Consider super classes of the second parameter.
     * @param param1 the first parameter class. Also the base class to match.
     * @param obj2 the parameter object that might be of that type.
     * @return true if the parameters match.
     */
    public static boolean classInstance(Class param1, Object obj2)
    {
        boolean match;                          //true if params match

        if (param1.getName().equals(Object.class.getName()) || (obj2 == null)) {
            match = true;
        }
        else {
            match = classInstance(param1, obj2.getClass());
            if (!match) match = Parsers.shouldConvert(param1, obj2);
        }

        return match;
    }

    /**
     * Check if the two parameters match with regard to class type.
     * Consider super classes of the second parameter.
     * @param param1 the first parameter class. Also the base class to match.
     * @param param2 the second parameter class that might be of that type.
     * @return true if the parameters match.
     */
    public static boolean classInstance(Class param1, Class param2)
    {
        boolean match = false;                  //true if params match

        if (param1.isPrimitive()) {
            if (param1.getName().equals(TypeConst.BOOLEAN))
                match = param2.getName().equals(TypeConst.BOOLEANOBJ);
            if (param1.getName().equals(TypeConst.BYTE))
                match = (param2.getName().equals(TypeConst.BYTEOBJ) ||
                        param2.getName().equals(TypeConst.BYTEOBJCODE));
            if (param1.getName().equals(TypeConst.CHARACTER))
                match = param2.getName().equals(TypeConst.CHARACTEROBJ);
            if (param1.getName().equals(TypeConst.SHORT))
                match = param2.getName().equals(TypeConst.SHORTOBJ);
            if (param1.getName().equals(TypeConst.INTEGER))
                match = param2.getName().equals(TypeConst.INTEGEROBJ);
            if (param1.getName().equals(TypeConst.LONG))
                match = param2.getName().equals(TypeConst.LONGOBJ);
            if (param1.getName().equals(TypeConst.FLOAT))
                match = param2.getName().equals(TypeConst.FLOATOBJ);
            if (param1.getName().equals(TypeConst.DOUBLE))
                match = param2.getName().equals(TypeConst.DOUBLEOBJ);
        }
        else {
            match = (param1.getName().equals(param2.getName()) ||
                    XmlHandler.elementsMatch(param1.getName(), param2.getName()));
        }

        if (!match) {
            if (param2.getSuperclass() != null)
                match = classInstance(param1, param2.getSuperclass());
        }

        return match;
    }

    /**
     * Convert a primitive type class description into the related object description.
     * @param paramClass string-based description of the class.
     * @return same description, or the object type description for a primitive type.
     */
    public static String toObjectClass(String paramClass) {
        if (paramClass.equalsIgnoreCase(TypeConst.BOOLEAN)) {
            return TypeConst.BOOLEANOBJ;
        }
        else if (paramClass.equalsIgnoreCase(TypeConst.BYTE)) {
            return TypeConst.BYTEOBJ;
        }
        else if (paramClass.equalsIgnoreCase(TypeConst.CHARACTER)) {
            return TypeConst.CHARACTEROBJ;
        }
        else if (paramClass.equalsIgnoreCase(TypeConst.SHORT)) {
            return TypeConst.SHORTOBJ;
        }
        else if (paramClass.equalsIgnoreCase(TypeConst.INTEGER)) {
            return TypeConst.INTEGEROBJ;
        }
        else if (paramClass.equalsIgnoreCase(TypeConst.LONG)) {
            return TypeConst.LONGOBJ;
        }
        else if (paramClass.equalsIgnoreCase(TypeConst.FLOAT)) {
            return TypeConst.FLOATOBJ;
        }
        else if (paramClass.equalsIgnoreCase(TypeConst.DOUBLE)) {
            return TypeConst.DOUBLEOBJ;
        }

        return paramClass;
    }

    /**
     * Return a code value for the type if one exists.
     * @param type the object type.
     * @return a smaller code value if one exists.
     */
    public static String typeCode(String type)
    {
        if (type.equals(TypeConst.BYTEOBJ))
            return TypeConst.BYTEOBJCODE;
        
        return type;
    }

    /**
     * Return true if the object indicates a Boolean object.
     * @param obj the object to check.
     * @return true if a Boolean, false if not or error.
     */
    public static boolean isBoolean(Object obj)
    {
        try {
            return obj.getClass().getName().equalsIgnoreCase(TypeConst.BOOLEANOBJ);
        }
        catch (Exception ex) {
            return false;
        }
    }

    /**
     * Return true if the object indicates a String object.
     * @param obj the object to check.
     * @return true if a String, false if not or error.
     */
    public static boolean isString(Object obj)
    {
        try {
            return obj.getClass().getName().equalsIgnoreCase(TypeConst.STRING);
        }
        catch (Exception ex) {
            return false;
        }
    }

    /**
     * Return true if the object indicates an XML element.
     * @param obj the object to check.
     * @return true if a licas or dom XML element, false if not or error.
     */
    public static boolean isElement(Object obj)
    {
        try {
            return (XmlHandler.isElement(obj.getClass().getName()) || DomParser.isW3cDom(obj));
        }
        catch (Exception ex) {
            return false;
        }
    }

    /**
     * Return true if the object indicates the base Object type.
     * @param obj the object to check.
     * @return true if the base Object type, false if not or error.
     */
    public static boolean isObject(Object obj)
    {
        try {
            return (obj.getClass().getName().equals(TypeConst.OBJECT));
        }
        catch (Exception ex) {
            return false;
        }
    }

    /**
     * Return true if type is an array type type.
     * @param type the object type.
     * @return true if type starts with the array type bracket [.
     */
    public static boolean isArrayType(String type)
    {
        return type.startsWith(ListParser.ARRAYCLASS);
    }
    
    /**
     * Return true if type is an ArrayList type.
     * @param type the object type.
     * @return true if type is an ArrayList type.
     */
    public static boolean isArrayList(String type)
    {
        return type.equals(ArrayList.class.getName());
    }
    
    /**
     * Return true if type is a Vector type.
     * @param type the object type.
     * @return true if type is a Vector type.
     */
    public static boolean isVector(String type)
    {
        return type.equals(Vector.class.getName());
    }
    
    /**
     * Return true if type is a LinkedList type.
     * @param type the object type.
     * @return true if type is a LinkedList type.
     */
    public static boolean isLinkedList(String type)
    {
        return type.equals(LinkedList.class.getName());
    }
    
    /**
     * Return true if type is a Hashtable type.
     * @param type the object type.
     * @return true if type is a Hashtable type.
     */
    public static boolean isHashtable(String type)
    {
        return type.equals(Hashtable.class.getName());
    }
    
    /**
     * Return true if type is a HashMap type.
     * @param type the object type.
     * @return true if type is a HashMap type.
     */
    public static boolean isHashMap(String type)
    {
        return type.equals(HashMap.class.getName());
    }
    
    /**
     * Return true if type is a LinkedHashMap type.
     * @param type the object type.
     * @return true if type is a LinkedHashMap type.
     */
    public static boolean isLinkedHashMap(String type)
    {
        return type.equals(LinkedHashMap.class.getName());
    }
    
    /**
     * Return true if type is a Stack type.
     * @param type the object type.
     * @return true if type is a Stack type.
     */
    public static boolean isStack(String type)
    {
        return type.equals(Stack.class.getName());
    }

    /**
     * Return true if the variable indicates a true value.
     * @param var the variable to check. Can be Boolean, String or query OK element.
     * @return true if the variable contains a true boolean value.
     */
    public static boolean valueIsTrue(Object var)
    {
        String value;                   //reply value
        
        if (var != null) {
            if (var instanceof Boolean) {
                return (Boolean)var;
            }
            else if (isString(var)) {
                return Boolean.valueOf((String)var);
            }
            else if (isElement(var)) {
                //test for query reply OK and not NOT_OK
                value = ((Element)var).getText();
                return value.equalsIgnoreCase(QueryConst.OK);
            }
        }
        
        return false;
    }
    
    /**
     * Return true if the variable indicates a false value.
     * @param var the variable to check. Can be Boolean, String or query Not_OK element.
     * @return true if the variable contains a true boolean value.
     */
    public static boolean valueIsFalse(Object var)
    {
        String value;                   //reply value
        
        if (var != null) {
            if (var instanceof Boolean) {
                return !(Boolean)var;
            }
            else if (isString(var)) {
                return !Boolean.valueOf((String)var);
            }
            else if (isElement(var)) {
                //test for query reply OK and not NOT_OK
                value = ((Element)var).getText();
                return value.equalsIgnoreCase(QueryConst.NOTOK);
            }
        }
        
        return false;
    }
    
    /**
     * Return true if the object represents the null type.
     * @param obj the object to check.
     * @return true if null or {@link Const}.{@code NULL}.
     */
    public static boolean isNull(Object obj)
    {
        return ((obj == null) || 
                (isString(obj) && obj.equals(Const.NULL)));
    }
    
    /**
     * For actual object instances, but not sure how accurate or how to use best.
     * @param theObj the object instance to measure.
     * @return the object size in bytes.
     */
    public static long sizeOf(Object theObj)
    {
        IObjectProfileNode profile = ObjectProfiler.profile (theObj);
        return profile.size();
    }

    /**
     * Parse the data element from the service info to create the related Java Object.
     * @param dataXml this is the base data or dataset element with nested elements that include
     * directly, {@link Const}.{@code DATATYPE}, {@code DATASETTYPE} and then {@code VALUE} 
     * elements for parsing. If they are missing, a {@code convertParameter} call is 
     * tried on the whole XML object.
     * @return the data value if the XML element is in the correct format, or null otherwise.
     * @throws java.lang.Exception any error.
     */
    public static Object dataXmlToValue(Element dataXml) throws Exception
    {
        String dataType;                                //the data type
        Element nextElem;                               //next element
        Element dataElem;                               //value element
        Object dataValue;                               //data value
        
        dataElem = null;
        dataType = MetaFactory.getFactoryData().getDataType(dataXml);
        
        if (dataType != null) {
            nextElem = dataXml.getChild(Const.VALUE);
            if (nextElem != null) {
                dataElem = nextElem;
            }

            if (dataElem != null) {
                //can still be direct text info or nested XML info
                if (dataElem.hasChildren()) {
                    dataValue = dataElem.getElementChildAtIndex(0);
                }
                else {
                    dataValue = valueFromString(dataType, dataElem.getText());
                }
            }
            else {
                //can still be complex object with attribute descriptions
                dataValue = convertParameter(dataXml);
            }
        }
        else {
            //can still be complex object with attribute descriptions
            dataValue = convertParameter(dataXml);
        }
        
        return dataValue;
    }
    
    /**
     * Return the value as a String. If the value type is not recognised, then a 
     * {@code String.valueOf(value)} is returned.
     * @param valueType the type of the value.
     * @param value the value.
     * @return a String description of the value.
     * @throws java.lang.Exception any error.
     */
    public static String valueToString(String valueType, Object value) throws Exception
    {
        Element arrayElem;                                  //array element
        ArrayParser arrayParser;                            //for parsing arrays
        
        if ((valueType != null) && (value != null) && !valueType.equals("")) {
            if (TypeConst.isSimpleType(valueType)) {
                return String.valueOf(value);
            }
            else if (valueType.equals(TypeConst.ELEMENT) && (value instanceof Element)) {
                return XmlHandler.xmlToString((Element)value);
            }
            else if (isArrayType(valueType)) {
                arrayParser = new ArrayParser();
                arrayElem = arrayParser.serialize(value);
                if (arrayElem != null) {
                    return arrayElem.getChild(Const.PARAMETER).getText();
                }
            }
            else {
                return String.valueOf(value);
            }
        }

        return null;
    }

    /**
     * Convert the String representation to the value object.
     * @param valueType the type of the value.
     * @param value the value as a String.
     * @return the value as its correct object.
     * @throws java.lang.Exception any error.
     */
    public static Object valueFromString(String valueType, String value) throws Exception
    {
        ArrayParser arrayParser;                            //for parsing arrays
        
        if ((valueType != null) && (value != null) && !valueType.equals("") && !value.equals("")) {
            if (TypeConst.isSimpleType(valueType)) {
                if (valueType.equals(TypeConst.INTEGER) || valueType.equals(TypeConst.INTEGEROBJ)) {
                    return new Integer(value);
                }
                else if (valueType.equals(TypeConst.LONG) || valueType.equals(TypeConst.LONGOBJ)) {
                    return new Long(value);
                }
                else if (valueType.equals(TypeConst.SHORT) || valueType.equals(TypeConst.SHORTOBJ)) {
                    return new Short(value);
                }
                else if (valueType.equals(TypeConst.FLOAT) || valueType.equals(TypeConst.FLOATOBJ)) {
                    return new Float(value);
                }
                else if (valueType.equals(TypeConst.DOUBLE) || valueType.equals(TypeConst.DOUBLEOBJ)) {
                    return new Double(value);
                }
                else if (valueType.equals(TypeConst.BOOLEAN) || valueType.equals(TypeConst.BOOLEANOBJ)) {
                    return Boolean.valueOf(value);
                }
                else if (valueType.equals(TypeConst.BYTE) || 
                        valueType.equals(TypeConst.BYTEOBJ) || valueType.equals(TypeConst.BYTEOBJCODE)) {
                    return Byte.valueOf(value);
                }
                else if (valueType.equals(TypeConst.CHARACTER) || valueType.equals(TypeConst.CHARACTEROBJ)) {
                    return value.charAt(0);
                }
                else if (valueType.equals(TypeConst.STRING)) {
                    return String.valueOf(value);
                }
            }
            else if (valueType.equals(TypeConst.ELEMENT)) {
                if (!value.startsWith(Const.XMLHEADER)) {
                    value = (Const.XMLHEADER + SymbolHandler.NL + value);
                }
                return XmlHandler.stringToElement(value);
            }
            else if (isArrayType(valueType)) {
                arrayParser = new ArrayParser();
                return arrayParser.parseToArray(valueType, value);
            }
            else if (valueType.equals(TypeConst.OBJECT)) {
                return Parsers.parse(value);
            }
        }
        
        return null;
    }
}
