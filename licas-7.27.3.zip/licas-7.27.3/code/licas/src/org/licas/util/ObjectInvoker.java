/*
 * ObjectInvoker.java
 *
 * Created on 13 November 2015
 *
 * Version 1.1.4
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util;


import org.licas.call.MethodInfo;
import org.licas.parsers.Parsers;
import org.licas.util.exception.MethodNotFoundException;

import java.lang.reflect.Method;
import java.util.ArrayList;


/**
 * This class provides methods to invoke an object method using reflection.
 * @author Kieran Greer
 */
public class ObjectInvoker 
{
    /** Match counts */
    private static final int EXACTMATCH = 10;
    private static final int OBJMATCH = 1;
    
    /**
     * Try to retrieve the method from the object, matching to the method name only.
     * @param objClass the class for the object that executes the method.
     * @param methodName the method name.
     * @return the method that matches the spec or null if none exists.
     * @throws java.lang.Exception any error.
     */
    public static Method retrieveMethod(Class objClass, String methodName) 
            throws Exception
    {
        return ReflectionHandler.retrieveMethod(objClass, methodName, null, null);
    }
    
    /**
     * Try to retrieve the method from the object.
     * @param objClass the class for the object that executes the method.
     * @param methodName the method name.
     * @param replyClass the reply type. This is optional.
     * @return the method that matches the spec or null if none exists.
     * @throws java.lang.Exception any error.
     */
    public static Method retrieveMethod(Class objClass, String methodName, String replyClass) 
            throws Exception
    {
        return ReflectionHandler.retrieveMethod(objClass, methodName, replyClass, null);
    }
    
    /**
     * Try to retrieve the method from the object.
     * @param objClass the class for the object that executes the method.
     * @param methodName the method name.
     * @param replyClass the reply type. This is optional.
     * @param paramTypes list of parameter types. Can be empty.
     * @return the method that matches the spec or null if none exists.
     */
    public static Method retrieveMethod(Class objClass, String methodName, String replyClass,
            ArrayList<String> paramTypes)
    {
        Method theMethod;                       //the method to call
        Method[] methods;                       //list of methods
          
        theMethod = null;
        if (paramTypes == null) paramTypes = new ArrayList();
        
        if (objClass != null) {
            //try for methods in local class
            methods = objClass.getDeclaredMethods();
            theMethod = retrieveMethod(objClass, methodName, replyClass, paramTypes, 
                    methods);
            
            //if null, try for accessible derived methods
            if (theMethod == null) {
                methods = objClass.getMethods();
                theMethod = retrieveMethod(objClass, methodName, replyClass, paramTypes,
                        methods);
            }
        }
        
        return theMethod;
    }
    
    /**
     * Try to retrieve the method from the object.
     * @param objClass the class for the object that executes the method.
     * @param methodName the method name.
     * @param replyClass the reply type. This is optional.
     * @param paramTypes list of parameter types. Can be empty.
     * @param methods method list to use.
     * @return the method that matches the spec or null if none exists.
     */
    private static Method retrieveMethod(Class objClass, String methodName, String replyClass,
            ArrayList<String> paramTypes, Method[] methods)
    {
        int i, j;
        int counter;                            //counter
        int bestCount;                          //best count
        String paramType;                       //parameter type
        ArrayList matches;                      //list of matching methods
        Class[] methodParams;                   //method params
        Method theMethod;                       //the method to call
        Method nextMethod;                      //next method to call
          
        theMethod = null;
        matches = new ArrayList();
        if (paramTypes == null) paramTypes = new ArrayList();
        
        if (objClass != null)
        {
            //try to match all fields
            for (i = 0; (theMethod == null) && (i < methods.length); i++)
            {
                theMethod = null;
                nextMethod = methods[i];

                if (nextMethod.getName().equals(methodName)) {
                    if (replyClass != null) {
                        if (ObjectHandler.toObjectClass(nextMethod.getReturnType().getName()).equals(
                                ObjectHandler.toObjectClass(replyClass)))
                            theMethod = nextMethod;
                    }
                    else {
                        theMethod = nextMethod;
                    }
                    
                    if (theMethod != null) {
                        if (theMethod.getParameterTypes().length != paramTypes.size()) {
                            theMethod = null;
                        }
                    }
                }
                
                if (theMethod != null) {
                    matches.add(theMethod);
                }
            }
            
            //if more than one match - select based on param types
            theMethod = null;
            bestCount = -1;
            for (i = 0; i < matches.size(); i++)
            {
                counter = 0;
                nextMethod = (Method)matches.get(i);
                methodParams = nextMethod.getParameterTypes();   
                    
                try
                {
                    for (j = 0; j < methodParams.length; j++)
                    {
                        paramType = paramTypes.get(j);
                        if (paramType.equalsIgnoreCase(Object.class.getName())) {
                            counter += OBJMATCH;
                        }
                        else {
                            if (TypeConst.isSimpleType(paramType)) {
                                if (ObjectHandler.toObjectClass(methodParams[j].getName()).equals(
                                        ObjectHandler.toObjectClass(paramType))) {
                                    counter += EXACTMATCH;
                                }
                            }
                            else {
                                try {
                                    if (ObjectHandler.classInstance(methodParams[j], Class.forName(paramType))) {
                                        counter += EXACTMATCH;
                                    }
                                } catch (Exception cex){}
                            }
                        }
                    }
                }
                catch (Exception ex) {
                    throw ex;
                }

                if (counter > bestCount) {
                    theMethod = nextMethod;
                    bestCount = counter;
                }
            }
        }
        
        return theMethod;
    }
    
    /**
     * Use reflection to invoke the method.
     * @param methodInfo the method info details.
     * @param invokeObj the object to invoke the method on.
     * @return the result of the execution.
     * @throws MethodNotFoundException for a method declaration mismatch.
     * @throws java.lang.Exception any other error.
     */
    public static Object invokeMethod(MethodInfo methodInfo, Object invokeObj)
            throws MethodNotFoundException, Exception
    {
        int i;
        Method toInvoke;                            //method to invoke
        ArrayList<Object> paramValues;              //list of parameter values
        Object nextParamObj;                        //next parameter object
        Object[] params;                            //params list
        
        
        toInvoke = ObjectInvoker.retrieveMethod(invokeObj.getClass(),
                methodInfo.getName(), methodInfo.getRtnType(), 
                methodInfo.objParameterTypes());

        if (toInvoke != null) {
            paramValues = methodInfo.getParamValues();
            params = new Object[paramValues.size()];

            for (i = 0; i < paramValues.size(); i++) {
                nextParamObj = Parsers.parseObject(paramValues.get(i));
                params[i] = nextParamObj;
            }

            return toInvoke.invoke(invokeObj, params);
        }
        else {
            throw new MethodNotFoundException("Method " + methodInfo.getName() +
                    " mismatch on object " + toInvoke.getClass().getName());
        }
    }
}
