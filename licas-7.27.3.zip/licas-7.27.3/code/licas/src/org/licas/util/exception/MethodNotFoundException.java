/*
 * MethodNotFoundException.java
 *
 * Created on 12 January 2009
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util.exception;


import org.jlog2.exception.WriteMessageException;


/**
 * This class can be used to throw an exception if a method to be invoked does not exist.
 * @author Kieran Greer
 */
public class MethodNotFoundException extends WriteMessageException
{
    /**
     * Create a new instance of MethodNotFoundException. This exception is passed through
     * each time, although only the message part gets written to the logger.
     * @param message the error message.
     */
    public MethodNotFoundException(String message)
    {
        super(message, false);
    }
    
    /**
     * Create a new instance of MethodNotFoundException.
     * @param message the error message.
     * @param thisUseOnce if true pass through the logger only once, if false, then pass
     * through the logger each time.
     */
    public MethodNotFoundException(String message, boolean thisUseOnce)
    {
        super(message, thisUseOnce);
    }
}
