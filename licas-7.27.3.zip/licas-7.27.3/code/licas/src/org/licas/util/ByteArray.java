/*
 * ByteArray.java
 *
 * Created on 29 May 2012
 *
 * Version 1.1
 *
 * Copyright (c) 2007 Kieran Greer
 */

package org.licas.util;


/**
 * This stores a byte stream in a string-based representation.
 * @author Kieran Greer
 */
public class ByteArray 
{
    /** The string-based representation of the byte array */
    private String byteArray;
    
    
    /** Create a new instance of ByteArray */
    public ByteArray()
    {
        byteArray = null;
    }
    
    /**
     * Set the whole byte array structure.
     * @param theByteArray the byte array represented as a string.
     */
    public void setByteArray(String theByteArray)
    {
        byteArray = theByteArray;
    }
    
    /**
     * Get the whole byte array structure.
     * @return the value of byteArray.
     */
    public String getByteArray()
    {
        return byteArray;
    }
}
