/*
 * UriHandler.java
 *
 * Created on 7 June 2011
 *
 * Version 1.2.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util;


import org.jlog2.util.StringHandler;

import java.io.File;
import java.net.URL;


/**
 * This class can be used to try to extract certain information form uri paths.
 * @author Kieran
 */
public class UriHandler 
{
    /**
     * Return true if the file is defined as a file from the local services folder.
     * @param fileUri the file uri path.
     * @return true if it has the jarfactory prefix.
     */
    public static boolean isJarfactoryFile(String fileUri)
    {
        return fileUri.startsWith(Const.LICASJARFILE);
    }
    
    /**
     * Add the uri file prefix to define a file in the local system.
     * @param theFilePath the file path for the jar file.
     * @return the full file path specification.
     */
    public static String addLocalFileUriPrefix(String theFilePath)
    {
        String fullPath;                            //full path

        fullPath = (Const.FILEURIPREFIX + theFilePath);
        return fullPath;
    }
    
    /**
     * Remove the the uri file  prefix from the local file description if it exists.
     * @param theFilePath the file path for the jar file.
     * @return the file path with the prefix removed, or the same path
     * if there is no prefix.
     */
    public static String removeLocalFileUriPrefix(String theFilePath)
    {
        String fullPath;                            //full path

        fullPath = StringHandler.replaceFirst(theFilePath, Const.FILEURIPREFIX, "");
        return fullPath;
    }
    
    /**
     * Add the jar factory prefix to define a jar file in the local services folder.
     * @param theJarFile the file path for the jar file.
     * @return the full jar path specification.
     */
    public static String addJarFactoryPrefix(String theJarFile)
    {
        String fullPath;                            //full path

        fullPath = (Const.LICASJARFILE + theJarFile);
        return fullPath;
    }
    
    /**
     * Remove the jar factory prefix from the jar file description if it exists.
     * @param theJarFile the file path for the jar file.
     * @return the file path with the jar factory prefix removed, or the same path
     * if there is no prefix.
     */
    public static String removeJarFactoryPrefix(String theJarFile)
    {
        String fullPath;                            //full path

        fullPath = StringHandler.replaceFirst(theJarFile, Const.LICASJARFILE, "");
        return fullPath;
    }
    
    /**
     * Create the jar factory uri string from the required values.
     * @param ipAddress the ip address of the server the factory runs on.
     * @param password the server password.
     * @param jarFileName the name of the jar file.
     * @return the jar factory uri string of combined input values.
     */
    public static String createJarFactoryUri(String ipAddress, String password,
            String jarFileName)
    {
        String jarFactoryUri;                       //the jar factory uri
        
        jarFactoryUri = Const.LICASJARFILE;
        jarFactoryUri += (Const.URIURL + ipAddress);
        jarFactoryUri += (Const.URIPASSWORD + password);
        jarFactoryUri += (Const.URIJAR + jarFileName);
        
        return jarFactoryUri;
    }
    
    /**
     * Get an array the stores the different jar file values for retrieving
     * from a remote server's jar factory.
     * @param theJarFile the original jar uri.
     * @return a parsed version of the jar uri.
     */
    public static String[] getJarFactoryParsed(String theJarFile)
    {
        String[] jarUri;                        //parsed jar uri
        
        jarUri = new String[3];
        theJarFile = removeJarFactoryPrefix(theJarFile);
        jarUri[0] = getJarFactoryURL(theJarFile);
        theJarFile = removeJarFactoryURL(theJarFile);
        jarUri[1] = getJarFactoryPassword(theJarFile);
        theJarFile = removeJarFactoryPassword(theJarFile);
        jarUri[2] = getJarFactoryJar(theJarFile);
        
        return jarUri;
    }
    
    /**
     * Gat the jar factory url section if it exists.
     * @param theJarFile the file path for the jar file.
     * @return the server url section only.
     */
    private static String getJarFactoryURL(String theJarFile)
    {
        int index;                                  //index
        String fullPath = null;                     //full path

        if (theJarFile.startsWith(Const.URIURL))
        {
            theJarFile = StringHandler.replaceFirst(theJarFile, Const.URIURL, "");
            index = theJarFile.indexOf(Const.URIPASSWORD);
            if (index > 0)
            {
                fullPath = theJarFile.substring(0, index);
                if (!fullPath.endsWith("/")) fullPath += "/";
            }
        }
        
        return fullPath;
    }
    
    /**
     * Remove the jar factory url section if it exists.
     * @param theJarFile the file path for the jar file.
     * @return the rest of the jar file url, with any server url details removed.
     */
    private static String removeJarFactoryURL(String theJarFile)
    {
        int index;                                  //index
        String fullPath;                            //full path

        fullPath = theJarFile;
        index = fullPath.indexOf(Const.URIPASSWORD);
        if (index > 0) fullPath = fullPath.substring(index);
        
        return fullPath;
    }
    
    /**
     * Gat the jar factory password section if it exists.
     * @param theJarFile the file path for the jar file.
     * @return the server password section only.
     */
    private static String getJarFactoryPassword(String theJarFile)
    {
        int index;                                  //index
        String fullPath = null;                     //full path

        if (theJarFile.startsWith(Const.URIPASSWORD))
        {
            theJarFile = StringHandler.replaceFirst(theJarFile, Const.URIPASSWORD, "");
            index = theJarFile.indexOf(Const.URIJAR);
            if (index > 0) fullPath = theJarFile.substring(0, index);
        }
        
        return fullPath;
    }
    
    /**
     * Remove the jar factory password section if it exists.
     * @param theJarFile the file path for the jar file.
     * @return the rest of the jar file url, with any server password details removed.
     */
    private static String removeJarFactoryPassword(String theJarFile)
    {
        int index;                                  //index
        String fullPath;                            //full path

        fullPath = theJarFile;
        index = fullPath.indexOf(Const.URIJAR);
        if (index > 0) fullPath = fullPath.substring(index);
        
        return fullPath;
    }
    
    /**
     * Gat the jar factory jar filename section if it exists.
     * @param theJarFile the file path for the jar file.
     * @return the jar filename section only.
     */
    private static String getJarFactoryJar(String theJarFile)
    {
        String fullPath = null;                     //full path

        if (theJarFile.startsWith(Const.URIJAR))
        {
            fullPath = StringHandler.replaceFirst(theJarFile, Const.URIJAR, "");
        }
        
        return fullPath;
    }
    
    /**
     * Try to parse the uri object to extract the final file name from the path.
     * The uri can represent any conventional path object, such as a 'URL' of a 
     * 'File'.
     * @param uriString the full path as a string-based description.
     * @return the final file path part if it exists. Also checks that the uri is
     * well formed.
     */
    public static String getFileName(String uriString)
    {
        int index;                                          //index
        String fileName;                                    //file name
        URL url;                                            //url path
        File file;                                          //file path
        
        fileName = null;
        try
        {
            url = new URL(uriString);
            fileName = url.getPath();
        }
        catch (Exception ex1)
        {
            try
            {
                file = new File(uriString);
                fileName = file.getPath();
            }
            catch (Exception ex2) 
            {}
        }
        
        if (fileName != null)
        {
            index = fileName.lastIndexOf("\\");
            if (index > 0)
            {
                fileName = fileName.substring(index+1);
                index = fileName.indexOf(".");
                if (index > 0) fileName = fileName.substring(0, index);
            }
            else
            {
                index = fileName.lastIndexOf("/");
                if (index > 0)
                {
                    fileName = fileName.substring(index+1);
                    index = fileName.indexOf(".");
                    if (index > 0) fileName = fileName.substring(0, index);
                }
            }
        }
        
        return fileName;
    }
}
