/*
 * MetaConst.java
 *
 * Created on 19 October 2013.
 *
 * Version 1.4
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util;


/**
 * Constant values relating to the creation or processing of metadata.
 * @author Kieran Greer
 */
public class MetaConst extends org.licas_text.util.MetaConst
{
    //Services   
    /** Defines admin document */
    public static final String ADMIN = "Admin";
    
    /** Defines all service meta xml description */
    public static final String ALLSERVICEMETA = "All_Service_Meta";
    
    /** Defines service meta xml description */
    public static final String SERVICEMETA = "Service_Meta";
    
    /** Defines child service meta xml description */
    public static final String CHILDSERVICEMETA = "Child_Service_Meta";
    
    /** Defines meta xml descriptions for permanently linked services */
    public static final String PERMANENTLINKSERVICEMETA = "Link_Service_Meta";
    
    /** Defines meta xml descriptions for dynamically linked services */
    public static final String DYNAMICLINKSERVICEMETA = "Dynamic_Link_Service_Meta";

    /** Defines meta xml descriptions for associated linked services */
    public static final String ASSOCIATEDLINKSERVICEMETA = "Associated_Link_Service_Meta";

    /** Defines all of the optional metadata */
    public static final String ALL = "All";

    /** None indicator */
    public static final String NONE = "None";
    
    /** Exists indicator */
    public static final String EXISTS = "Exists";
    
       
    //Contracts
    /** Defines client id tag */
    public static final String CLIENT = "Client";
    
    /** Defines policy document tag */
    public static final String POLICY = "Policy";

    /** Defines work or service provision info */
    public static final String WORKINFO = "Work_Info";
    
    /** Defines all service service level agreements */
    public static final String SERVICELEVELCONTRACTS = "Service_Level_Contracts";

    /** Defines a service service level agreement */
    public static final String SERVICELEVELCONTRACT = "Service_Level_Contract";

    /** Defines service level tag */
    public static final String SERVICELEVEL = "Service_Level";

    /** Defines contract evaluation tag */
    public static final String CONTRACTEVALUATION = "Contract_Evaluation";

    /** Defines other contract metadata tag */
    public static final String OTHERCONTRACTMETA = "Other_Contract_Meta";

    /** Defines contract tag */
    public static final String CONTRACT = "Contract";
    
    /** Defines contract OK tag */
    public static final String CONTRACTOK = "Yes";

    /** Defines contract not OK tag */
    public static final String CONTRACTNOTOK = "No";
    
    /** Defines all contracts code tag */
    public static final String ALLCONTRACTSCODE = "wxlgrsrztz";
    
    
    
    //Security Manager
    /** Defines a root security manager tag */
    public static final String SECURITYMANAGER = "Security_Manager";   
    
    /** Defines any permissions tag */
    public static final String PERMISSIONS = "Permissions";
    
    /** Defines next permission tag */
    public static final String NEXTPERMISSION = "Next_Permission";
    
    /** Defines a folder/file permission type */
    public static final String FILEPERMISSION = "File";
    
    /** Defines a read permission */
    public static final String READ = "read";
    
    /** Defines a write permission */
    public static final String WRITE = "write";
    
    
    
    //Fault or error elements
    /** Defines a fault element */
    public static final String FAULT = "Fault";
    
    /** Defines a fault details element */
    public static final String DETAILS = "Details";
    
    /** Defines a server fault type */
    public static final String SERVERFAULT = "Server_Fault";
    
    /** Defines a service missing fault type */
    public static final String SERVICEMISSING = "Service_Missing";
    
    /** Defines a service access fault type */
    public static final String SERVICEACCESS = "Service_Access";

    /** Defines process a method fault type */
    public static final String METHODFAULT = "Method_Fault";
    
    /** Defines a service is missing description */
    public static final String SERVICEMISSINGDESC = "Service is not running";
    
    /** Defines a service action description */
    public static final String SERVICEACTIONDESC = "Service block, unblock, shutdown, etc.";
    
    /** Defines an incorrect password description */
    public static final String INCORRECTPASSWORDDESC = "Incorrect password";
    
    /** Defines an IO Exception */
    public static final String IOEXCEPTION = "An IO Exception has occurred.";
}
