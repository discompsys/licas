/*
 * LoadObject.java
 *
 * Created on 18 February 2007
 *
 * Version 2.8.2
 *
 * Copyright (c) Kieran Greer
 *
 */

package org.licas.util.classloader;


import org.licas.parsers.types.MyObjectInputStream;
import org.licas.parsers.types.ReflectionParser;
import org.licas.server.LocalServer;
import org.licas.util.*;
import org.licas.util.exception.LicasException;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.*;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.lang.reflect.Constructor;
import java.net.JarURLConnection;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;


/**
 * This class loads and returns a Java object. A {@link URLClassLoader} is used to try to
 * load in a Java object from an external jar file. these get added to the list of
 * loaders when you call {@code loadObject} to create an object instance, or when you call
 * {@code addLoader} to add a new loader. One tip might be to add a set of the new jar files together.
 * @author Kieran Greer
 */
public class LoadObject
{
    /** The logger */
    private static final Logger logger;

    /** Secret key allows some admin changes on the loader when set */
    private static String loaderKey = null;
    
    /** True if allow new URL classloaders, false otherwise. Defaults to true. */
    private static boolean allowNewLoaders = true;
    
    /** A jar loader for the licas package specifically */
    private static JarClassLoader licasJarLoader;
    
    /** The list of URL class loaders used to load all classes */
    private static final ArrayList<ClassLoader> jarLoader;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(LoadObject.class.getName());
        logger.setDebug(false);

        //add default loaders. If lib folder with licas.jar, add this as well
        jarLoader = new ArrayList<>();
        jarLoader.add(ClassLoader.getSystemClassLoader());
        
        //try to set the default base loader
        getBaseLoader();
    }


    /** Creates a new instance of LoadObject */
    public LoadObject() {
    }
    
    /**
     * Try to store the default base 'licas.jar' loader, then make it the parent 
     * to all new loaders that are added. If contained in another jar, then add 
     * main jar file instead.
     */
    private static void getBaseLoader()
    {
        int i;
        String fileName;                            //file name
        String installFolder;                       //installation folder
        ArrayList<String> fileList;                 //file list
        URL[] urls;                                 //urls list
        ClassLoader nextLoader;                     //next class loader

        installFolder = ServiceConst.APPHOME;
        installFolder = installFolder.substring(0, installFolder.length()-1);
        
        licasJarLoader = null;
        nextLoader = jarLoader.get(0);
        
        if (isUrlLoader(nextLoader))
        {
            urls = ((URLClassLoader)nextLoader).getURLs();
            for (i = 0; (licasJarLoader == null) && i < urls.length; i++)
            {
                fileName = new File(urls[i].toExternalForm()).getName();   
                if (fileName.equals("licas.jar"))
                {
                    licasJarLoader = new JarClassLoader(new File(urls[i].toExternalForm()).getPath());
                }
            }

            if (licasJarLoader == null)
            {
                //try a lib folder
                try 
                {
                    installFolder += "/lib/";
                    fileList = FileLoader.getFileList(installFolder);
                    for (i = 0; (licasJarLoader == null) && i < fileList.size(); i++)
                    {
                        fileName = fileList.get(i);
                        if (fileName.equals("licas.jar"))
                        {
                            fileName = new File(installFolder + fileName).toString();           
                            licasJarLoader = new JarClassLoader(fileName);
                        }
                    }
                }
                catch (Exception ex)
                {}
            }
        
            if (licasJarLoader == null)
            {
                //try first classloader instead
                for (i = 0; (licasJarLoader == null) && i < urls.length; i++)
                {
                    try
                    {
                        licasJarLoader = new JarClassLoader(new File(urls[i].toExternalForm()).getPath());
                    }
                    catch (Exception ex)
                    {}
                }
            }
        }
        else
        {
            //try first loader, for android maybe
            licasJarLoader = new JarClassLoader(null);
        }
    }
    
    /**
     * Return true if the file path is a legal jar file type. Currently only
     * checks that the file ends with '.jar'.
     * @param jarFilePath the jar file path.
     * @return true if the file path is a jar file type.
     */
    public static boolean isLegalJarFile(String jarFilePath)
    {
        jarFilePath = removeJarPrefix(jarFilePath);
        if (jarFilePath != null)
        {
            return (jarFilePath.toLowerCase().endsWith(".jar"));
        }
        
        return false;
    }
    
    /**
     * Return true if the class name is a legal one for separate loading and creation.
     * @param jarClassName the name of the class in the jar file.
     * @return if a new class can be created from it.
     */
    protected static boolean isLegalClassFile(String jarClassName)
    {
        jarClassName = jarClassName.toLowerCase();
        return (jarClassName.endsWith(".class") && !jarClassName.contains("$"));
    }
    
    /**
     * Return true if the classloader loads the specified url.
     * @param classLoader the URL class loader.
     * @param url the URL to check for.
     * @param includeParent if true also check the parent loader.
     */
    private static boolean containsURL(URLClassLoader classLoader, URL url, boolean includeParent)
    {
        int i;
        boolean containsURL;                        //true if contains the URL
        URL[] loaderUrls;                           //loader urls
        ClassLoader parentLoader;                   //parent class loader
        
        containsURL = false;
        loaderUrls = classLoader.getURLs();     
        for (i = 0; !containsURL && (i < loaderUrls.length); i++)
        {
            containsURL = urlToFile(loaderUrls[i]).toString().equals(urlToFile(url).toString());
        }

        if (!containsURL && includeParent)
        {
            parentLoader = classLoader.getParent();
            if (isUrlLoader(parentLoader))
            {
                containsURL = containsURL((URLClassLoader)parentLoader, url, includeParent);
            }
        }
        
        return containsURL;
    }
    
    /**
     * Create a new instance of the specified object and return.
     * @param theJarUris uris from which the remote object can be loaded, only if needed.
     * @param theClassName the name of the class.
     * @param params initialisation parameters.
     * @return the loaded object.
     * @throws java.lang.Exception any error.
     */
    public static Object loadObject(ArrayList<String> theJarUris, String theClassName, ArrayList<?> params)
            throws Exception
    {
        int i;
        Class c;                                    //class definition
        Constructor constructor;                    //class constructor
        Class[] paramTypes;                         //parameter types
        Constructor[] constructors;                 //list of constructors
        Object[] paramObj;                          //parameters as an array
        Object service = null;                      //service to load

        try
        {
            //first check if allow
            if (!allowNewLoaders) theJarUris = null;
        
            if (theClassName != null)
            {
                try
                {
                    theClassName = ReflectionParser.unformatClassName(theClassName);
                }
                catch (Exception ex) {}
                
                if (params != null)
                {
                    paramObj = params.toArray();
                    paramTypes = new Class[paramObj.length];
                    
                    for (i = 0; i < paramObj.length; i++)
                    {
                        paramTypes[i] = paramObj[i].getClass();
                    }
                }
                else
                {
                    paramObj = new Object[0];
                    paramTypes = new Class[0];
                }

                //add the urls to the class loader if they do not already exist
                addLoader(theJarUris);

                c = getClass(theClassName);
                constructors = c.getConstructors();
                constructor = ReflectionHandler.getConstructor(constructors, paramTypes);

                if (constructor != null)
                {
                    constructor.setAccessible(true);
                    service = constructor.newInstance(paramObj);
                }
                else
                {
                    throw new LicasException("Could not find constructor for class " + 
                            theClassName, true);
                }
            }
        }
        catch (Exception ex)
        {
            //can happen normally, so throw warning to catch instead
            throw ExceptionHandler.handleException(logger, LoggerHandler.WARN, "loadObject",
                    null, ex);
        }

        return service;
    }
    
    /**
     * Add the list of jar uris to the current loader.
     * @param uris the list of jar uris.
     * @throws java.lang.Exception any error.
     */
    public static void addLoader(ArrayList<String> uris) throws Exception
    {
        int i; 
        URL[] newUrls;                              //new urls
        URL[] allUrls;                              //all urls
        ArrayList<URL> toAdd;                       //urls to add
        UrlJarClassLoader newLoader;                //new class loader
        JarClassLoader parentLoader;                //new class loader
        
        //first check if allow
        if (!allowNewLoaders) uris = null;
        
        //add the urls to the class loader if they do not already exist
        if ((uris != null) && (uris.size() > 0))
        {
            try
            {
                newUrls = new URL[uris.size()];
                for (i = 0; i < uris.size(); i++)
                {
                    newUrls[i] = uriToUrl(uris.get(i));
                }

                toAdd = getUrlsNotLoaded(newUrls);

                allUrls = new URL[toAdd.size()];
                for (i = 0; i < toAdd.size(); i++)
                {
                    allUrls[i] = toAdd.get(i);
                }

                try 
                {
                    //try to add the default licas loader as the parent loader
                    parentLoader = licasJarLoader;
                    newLoader = new UrlJarClassLoader(allUrls, parentLoader);
                    jarLoader.add(newLoader);
                }
                catch (Exception lex)
                {}
                              
//                printCurrentJarLoader();
            }
            catch (Exception ex)
            {
                throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "addLoader",
                    null, ex);
            }
        }
    }
    
    /**
     * Load and return the jar file from the specified uri.
     * @param jarUri the uri specification for the jar file.
     * @return the loaded jar file.
     * @throws java.lang.Exception any error.
     */
    protected static JarFile loadJarFile(String jarUri) throws Exception
    {
        String theUri;                              //the uri to retrieve from
        JarFile jarFile;                            //jar file
        URL theUrl;                                 //the url
        JarURLConnection jarUrl;                    //jar url connection
        
        //this reads a jar fle, not a classloader, so maybe OK
        try
        {
            jarFile = new JarFile(LoadObject.urlToFile(LoadObject.uriToUrl(jarUri)));
        }
        catch (Exception ex)
        {
           try
            {
                //try to load locally
                theUri = LoadObject.uriToUrl(jarUri).toString();
                jarFile = new JarFile(theUri);
            }
            catch (Exception ex2)
            {              
                //try to load remotely
                theUrl = LoadObject.uriToUrl(jarUri);

                try
                {
                    jarUrl = (JarURLConnection)theUrl.openConnection();
                    jarFile = jarUrl.getJarFile();
                }
                catch (Exception ex3)                 
                {
                    jarFile = new JarFile(theUrl.toExternalForm());
                }
            } 
        }
        
        return jarFile;
    }
    
    /**
     * Traverse through all currently stored class loaders and try to create an
     * instance of each class.
     * @throws java.lang.Exception any error.
     */
    public static void loadAllClasses() throws Exception
    {
        int i, j;
        URL nextURL;                                //next url
        URL[] urls;                                 //list of urls
        UrlJarClassLoader classLoader;              //url class loader
        
        try
        {
            //first loader is the system loader, so do not load all of those
            for (i = 1; i < jarLoader.size(); i++)
            {
                try
                {
                    classLoader = (UrlJarClassLoader)jarLoader.get(i);
                    
                    urls = classLoader.getURLs();
                    for (j = 0; j < urls.length; j++)
                    {
                        nextURL = urls[j];
                        classLoader.getAllClasses(nextURL.getFile(), true);
                    }
                }
                catch (Exception lex) {}
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, 
                    "loadAllClasses", null, ex);
        }
    }
    
    /**
     * Retrieve and return the names of all classes stored in the jar identified 
     * by the uri. This does not add the jar as a permanent class loader. It only 
     * parses it to retrieve the class list. Use 'addLoader' or 'loadObject' to
     * add as a permanent loader.
     * @param jarUri the uri for the jar file.
     * @param rtnOnError if true, exit with the first load error, returning null. If
     * false, try to load every class and ignore any errors.
     * @return a list of all class names.
     */
    public static ArrayList<String> getAllClasses(String jarUri, boolean rtnOnError)
    {
        int i;
        String jarName;                             //jar name
        Class nextClass;                            //next class
        Enumeration entries;                        //entries
        ArrayList<String> classes;                  //all classes
        JarFile jarFile;                            //jar file
        JarEntry jarEntry;                          //jar entry
        UrlJarClassLoader classLoader;              //class loader
        URL[] uris;                                 //all uris

        try {
            classes = null;
            uris = new URL[1];
            uris[0] = uriToUrl(jarUri);

            if (removeJarPrefix(jarUri).equals(removeJarPrefix(licasJarLoader.getFilePath()))) {
                classes = licasJarLoader.getAllClasses(rtnOnError);
            }
            else {
                //base loader is the system url loader
                for (i = (jarLoader.size() - 1); i > 0; i--)
                {
                    classLoader = (UrlJarClassLoader)jarLoader.get(i);
                    if (containsURL(classLoader, uris[0], true)) {
                        classes = classLoader.getAllClasses(jarUri, rtnOnError);
                        break;
                    }
                }
            }
            
            //try to create new loader if completely new url, but do not add
            if (((classes == null) || classes.isEmpty()) && allowNewLoaders) {
                classLoader = new UrlJarClassLoader(uris);
                
                jarFile = loadJarFile(jarUri);
                if (jarFile != null) {
                    entries = jarFile.entries();
                    while (entries.hasMoreElements())
                    {
                        jarEntry = (JarEntry)entries.nextElement();
                        jarName = jarEntry.getName().trim();

                        if (isLegalClassFile(jarName)) {
                            jarName = StringHandler.replaceAll(jarName, ".class", "").trim();
                            jarName = StringHandler.replaceAll(jarName, "/", ".");

                            try {
                                nextClass = classLoader.loadClass(jarName);
                                classes.add(nextClass.getName());
                            }
                            catch (Throwable ex2) {
                                //do not output message as can be security
                                //restriction or missing external jar
                                if (rtnOnError) return null;
                            }
                        }
                    }
                }
            }
            
            return classes;
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "getAllClasses",
                null, ex);

            return null;
        }
    }
    
    /**
     * Retrieve a class instance of the class specified.
     * @param theClassName the binary or fully qualified name of the class.
     * @return the class description or null if the class cannot be reflected.
     */
    public static Class getClass(String theClassName)
    {
        int i;
        Class theClass = null;                      //the class
        ClassLoader classLoader;                    //url class loader

        try
        {
            try
            {
                theClass = Class.forName(theClassName);
            }
            catch (Exception ex)
            {
                for (i = 0; i < jarLoader.size(); i++)
                {
                    try
                    {
                        classLoader = jarLoader.get(i);
                        theClass = classLoader.loadClass(theClassName);
                        if (theClass != null) break;
                    }
                    catch (Exception lex) {}
                }
            }
        }
        catch (Exception ex)
        {
            //do not output a message as there are different reasons for an error
            //a null class instance is returned if it cannot be created
        }

        return theClass;
    }
    
    /**
     * Add the URL to the list of URLs.
     * @param urlsToAdd the current list of URLs to add, of type URL.
     * @param currentUrls the list of currently loaded urls.
     * @param theUrl the URL to add, but only if a jar file with the same name
     * is not already stored.
     */
    private static void addUrl(ArrayList<URL> urlsToAdd, ArrayList<URL> currentUrls, URL theUrl)
    {
        int i;
        boolean inList;                             //true if already in the list
        boolean alreadyLoaded;                      //true if jar file is already loaded
        String theUrlStr;                           //the ural as a string
        String nextUrlStr;                          //next url as a string
        URL nextUrl;                                //next url
        
        if (theUrl != null) 
        {
            inList = false;
            theUrlStr = theUrl.getFile();            
            if (theUrlStr.contains("/"))
            {
                theUrlStr = theUrlStr.substring(theUrlStr.lastIndexOf("/")+1);
            }
                
            if (!theUrlStr.equals(""))
            {
                for (i = 0; !inList && (i < urlsToAdd.size()); i++)
                {
                    nextUrl = urlsToAdd.get(i);
                    nextUrlStr = nextUrl.getFile();

                    if (nextUrlStr.contains("/"))
                    {
                        nextUrlStr = nextUrlStr.substring(nextUrlStr.lastIndexOf("/")+1);
                    }

                    inList = theUrlStr.equals(nextUrlStr);
                }

                if (!inList)
                {
                    alreadyLoaded = false;
                    for (i = 0; !alreadyLoaded && (i < urlsToAdd.size()); i++)
                    {
                        nextUrl = urlsToAdd.get(i);
                        nextUrlStr = nextUrl.getFile();

                        if (nextUrlStr.contains("/"))
                        {
                            nextUrlStr = nextUrlStr.substring(nextUrlStr.lastIndexOf("/")+1);
                        }

                        if (!nextUrlStr.equals(""))
                        {
                            alreadyLoaded = (nextUrlStr.equals(theUrlStr));
                        }
                    }

                    if (!alreadyLoaded)
                    {
                        for (i = 0; !alreadyLoaded && (i < currentUrls.size()); i++)
                        {
                            nextUrl = currentUrls.get(i);
                            if (nextUrl != null)
                            {
                                nextUrlStr = nextUrl.getFile();

                                if (nextUrlStr.contains("/"))
                                {
                                    nextUrlStr = nextUrlStr.substring(nextUrlStr.lastIndexOf("/")+1);
                                }

                                if (!nextUrlStr.equals(""))
                                {
                                    alreadyLoaded = (nextUrlStr.equals(theUrlStr));
                                }
                            }
                        }

                        if (!alreadyLoaded)
                        {
                            urlsToAdd.add(theUrl);
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Retrieve all URLs from this class loader and all parent ones as well.
     * @param classLoaders the list of class loaders.
     * @param allUrls a list of all retrieved URLs, of type URL.
     */
    private static void getUrls(ArrayList<ClassLoader> classLoaders, ArrayList<URL> allUrls)
    {
        int i, j;
        URL[] currentUrls;                          //current urls
        ClassLoader parentLoader;                   //parent class loader
        ClassLoader classLoader;                    //url class loader
        ArrayList<ClassLoader> parentList;          //parent loaders

        for (i = 0; i < classLoaders.size(); i++)
        {
            classLoader = classLoaders.get(i);
            if (isUrlLoader(classLoader)) {
                currentUrls = ((URLClassLoader)classLoader).getURLs();
                for (j = 0; j < currentUrls.length; j++) {
                    allUrls.add(currentUrls[j]);
                }

                parentLoader = classLoader.getParent();
                if (isUrlLoader(parentLoader)) {
                    parentList = new ArrayList<>();
                    parentList.add(parentLoader);
                    getUrls(parentList, allUrls);
                }
            }
        }
    }
    
    /**
     * Get a list of the URLs not already loaded in an existing classloader.
     * @param urls the list of urls to check for.
     * @return a list of urls not already part of a classloader.
     */
    private static ArrayList<URL> getUrlsNotLoaded(URL[] urls)
    {
        int i;
        ArrayList<URL> toAdd;                           //urls to add
        ArrayList<URL> urlVec;                          //all current urls
        
        urlVec = new ArrayList<>();
        LoadObject.getUrls(jarLoader, urlVec);                

        //add only the urls that are not currently added
        toAdd = new ArrayList<>();
        for (i = 0; i < urls.length; i++)
        {
            addUrl(toAdd, urlVec, urls[i]);
        }
        
        return toAdd;
    }
    
    /**
     * Use the jar loaders to read on a (base64) byte stream.
     * @param objBytes the byte stream.
     * @return the constructed object.
     */
    public static Object objStream(byte[] objBytes)
    {
        int i;
        ClassLoader nextLoader;                     //new class loader
        ByteArrayInputStream bais = null;           //input stream
        MyObjectInputStream ois  = null;            //output stream
        Object obj = null;                          //created object
        
        if (jarLoader != null) {
            bais = new java.io.ByteArrayInputStream(objBytes);                   
            for (i = 0; i < jarLoader.size(); i++)
            {
                try {
                    nextLoader = jarLoader.get(i);
                    ois = new MyObjectInputStream(nextLoader, bais);                    
                    obj = ois.readObject();
                    break;
                }
                catch (Exception lex) {}
            }
        }
        
        return obj;
    }

    /**
     * Calculate what the correct prefix for the jar file paths is
     * based on the uri of the server and add to the server uri.
     * @param theJarFile the file path for the jar file.
     * @return the full jar path specification.
     * @throws java.lang.Exception any error.
     */
    public static String addJarPrefix(String theJarFile) throws Exception
    {
        String fullPath;                        //full path

        fullPath = addJarPrefix("", theJarFile);
        return fullPath;
    }

    /**
     * Calculate what the correct jar file path is based on the uri of the server and file path.
     * @param serverUri the uri of the server to send the jar spec to.
     * @param theJarFile the file path for the jar file.
     * @return the full jar path specification.
     * @throws java.lang.Exception any error.
     */
    public static String addJarPrefix(String serverUri, String theJarFile) throws Exception
    {
        String thisIP;                              //this ip address
        String fullPath = null;                     //full path
        URL serverURL;                              //server url
       
        if ((theJarFile != null) && !theJarFile.equals("") && !theJarFile.equals(Const.NULL))
        {
            fullPath = theJarFile;
            if (!fullPath.endsWith(Const.ENDJAR)) fullPath += Const.ENDJAR;
            
            if ((serverUri != null) && !serverUri.equals("") && !serverUri.equals(Const.NULL))
            {
                if (!serverUri.endsWith("/")) serverUri += "/";
                serverURL = uriToUrl(serverUri);
                thisIP = LocalServer.getServerURL();

                if (!fullPath.startsWith(Const.JAR))
                {
                    if ((thisIP == null) || LocalServer.checkAddress(serverURL.getHost(), serverURL.getPort())) 
                        fullPath = (Const.JAR + Const.JARFILEURI + fullPath);
                    else
                        fullPath = (Const.JAR + thisIP + fullPath);
                }
            }
            else
            {
                if (!fullPath.startsWith(Const.JAR))
                    fullPath = (Const.JAR + Const.JARFILEURI + fullPath);
            }
        }

        return fullPath;
    }

    /**
     * Calculate what the correct prefix for the jar file paths is
     * based on the uri of the server and add to the jar file paths.
     * @param serverUri the uri of the server to send the jar spec to.
     * @param jarUris the jar file specifications.
     * @return the jar file specifications with the prefix added.
     * @throws java.lang.Exception any error.
     */
    public static ArrayList<String> addJarPrefix(String serverUri, ArrayList<String> jarUris) throws Exception
    {
        int i;
        String nextJar;                             //next jar spec
        ArrayList<String> withPrefix;               //the jar specs with the prefix

        withPrefix = new ArrayList<>();
        if (jarUris != null)
        {
            for (i = 0; i < jarUris.size(); i++)
            {
                nextJar = jarUris.get(i);
                nextJar = addJarPrefix(serverUri, nextJar);
                withPrefix.add(nextJar);
            }
        }

        return withPrefix;
    }
    
    /**
     * Remove additional jar file formatting that is used to define a jar file for
     * a class loader. Try to keep only the file path itself.
     * @param theJarFile the file path for the jar file.
     * @return the full jar path specification.
     */
    public static String removeJarPrefix(String theJarFile)
    {
        String fullPath = null;                     //full path
        
        if ((theJarFile != null) && !theJarFile.equals("") && !theJarFile.equals(Const.NULL))
        {
            fullPath = theJarFile;
            if (fullPath.endsWith(Const.ENDJAR)) 
            {
                fullPath = fullPath.substring(0, (fullPath.length() - Const.ENDJAR.length()));
            }
            if (fullPath.startsWith(Const.JAR))
            {
                fullPath = fullPath.substring(Const.JAR.length());
            }           
            if (fullPath.startsWith(Const.JARFILEURI))
            {
                fullPath = fullPath.substring(Const.JARFILEURI.length());
            }
        }

        return fullPath;
    }
    
    /**
     * Convert the uri spec into a URL. This only adds a file path, not a full jar file spec. 
     * @param theUri the uri description in String format.
     * @return a URL generated from the uri.
     */
    protected static URL uriToUrl(String theUri)
    {
        String formattedUri = null;                 //formatted uri
        File file;                                  //file object
        URL url = null;                             //the url
 
        try
        {
            formattedUri = StringHandler.replaceAll(theUri, Const.JAR, "");
            if (formattedUri != null)
            {
                if (formattedUri.endsWith(Const.ENDJAR))
                {
                    formattedUri = formattedUri.substring(0, formattedUri.lastIndexOf(Const.ENDJAR));
                }

                url = new URL(formattedUri);
            }
        }
        catch (Exception ex)
        {
            try
            {
                if (formattedUri != null)
                {
                    file = new File(formattedUri);
                    url = file.toURI().toURL();
                }
            }
            catch (Exception ex2)
            {
                ExceptionHandler.handleException(logger, LoggerHandler.WARN, "uriToUrl",
                    null, ex);
            }
        }
        
        return url;
    }
    
    /**
     * Convert the URL into a file object if it is valid. 
     * @param theUrl the URL.
     * @return a file object created from the specified path.
     */
    protected static File urlToFile(URL theUrl)
    {
        String formattedUri;                        //formatted uri
        File file = null;                           //the file

        try
        {
            formattedUri = theUrl.toString();
            if (formattedUri.startsWith(Const.JAR))
            {
                formattedUri = StringHandler.replaceFirst(formattedUri, Const.JAR, "");
            }
            
            if (formattedUri.startsWith(Const.JARFILEURI))
            {
                formattedUri = StringHandler.replaceFirst(formattedUri, Const.JARFILEURI, "");
            }
            
            if (!Const.isLinux() && formattedUri.startsWith("/"))
            {
                formattedUri = StringHandler.replaceFirst(formattedUri, "/", "");
            }
            else if (Const.isLinux() && formattedUri.startsWith("//"))
            {
                formattedUri = StringHandler.replaceFirst(formattedUri, "//", "/");
            }
            
            if (formattedUri.endsWith(Const.ENDJAR))
            {
                formattedUri = formattedUri.substring(0, formattedUri.lastIndexOf(Const.ENDJAR));
            }
            
            file = new File(formattedUri);
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "uriToUrl",
                null, ex);
        }
        
        return file;
    }

    /**
     * Return indexes of parameters that should now be changed to the parent object.
     * @param params the current parameters.
     * @return the list of indexes to change to the parent object. 
     */
    protected static ArrayList<Integer> convertToParent(ArrayList<?> params)
    {
        int i;
        String nextStr;                             //next string
        ArrayList<Integer> indexes;                 //indexes
        Object nextObj;                             //next object

        indexes = new ArrayList<>();
        for (i=0; i < params.size(); i++)
        {
            nextObj = params.get(i);
            if (ObjectHandler.isString(nextObj))
            {
                nextStr = (String)nextObj;
                if (nextStr.equals(Const.PARENT))
                {
                    indexes.add(i);
                }
            }
        }

        return indexes;
    }

    /**
     * Return true if the classloader is a URL class loader.
     * @param loader the loader to check.
     * @return true if a URL class loader.
     */
    protected static boolean isUrlLoader(ClassLoader loader)
    {
        return ((loader instanceof UrlJarClassLoader) ||
                (loader instanceof URLClassLoader));
    }

    /**
     * Set the secret loader key. Can only be set once.
     * @param thisKey the key value.
     * @return true if set, false if key already exists.
     */
    public static boolean setLoaderKey(String thisKey)
    {
        if (loaderKey == null) 
        {
            loaderKey = thisKey;
            return true;
        }
        
        return false;
    }
    
    /**
     * Return true if the key entered is the loader key.
     * @param thisKey the key value.
     * @return true if same as loader key, true if loader key is null,
     * false otherwise.
     */
    private static boolean isLoaderKey(String thisKey)
    {
        return ((loaderKey == null) || loaderKey.equals(thisKey));
    }
    
    /**
     * Set/change the value indicating if url classloaders can be used.
     * @param thisAllowNew true if allow adding new url classloaders, false if not allow,
     * when only the setup loaders can be used.
     * @param thisKey the loader key to protect any changes.
     * @return true if update made OK, false if loader key is not correct.
     */
    public static boolean setAllowNewLoaders(boolean thisAllowNew, String thisKey)
    {
        if (isLoaderKey(thisKey))
        {
            allowNewLoaders = thisAllowNew;
            return true;
        }
        
        return false;
    }
    
    /**
     * Get the value indicating if url classloaders can be used.
     * @return the value of allowNewLoaders.
     */
    public static boolean getAllowNewLoaders()
    {
        return allowNewLoaders;
    }

    /**
     * Format the class name to remove any array indicators, etc.
     * @param theClassName the class name to format.
     * @return the formatted class name.
     */
    private static String formatClassName(String theClassName)
    {
        String newClassName;                        //the formatted class name

        newClassName = theClassName;
        newClassName = StringHandler.replaceAll(newClassName, "[L", "");
        newClassName = StringHandler.replaceAll(newClassName, ";", "");

        return newClassName;
    }
    
    /**
     * Print out the contents of the current jar file loader to system.out
     */
    private static void printCurrentJarLoader()
    {
        int i, j;
        StringBuilder loaderDescr;                      //loader description
        URL[] urls;                                     //urls list
        ClassLoader nextLoader;                         //next class loader
        
        loaderDescr = new StringBuilder("Current class loader list description:");
        for (i = 0; i < jarLoader.size(); i++)
        {
            nextLoader = jarLoader.get(i);
            
            loaderDescr.append("\n     Next loader:");
            loaderDescr.append("\n     ").append(nextLoader.toString());

            if (isUrlLoader(nextLoader)) {
                urls = ((URLClassLoader)nextLoader).getURLs();
                for (j = 0; j < urls.length; j++) {
                    loaderDescr.append("\n          Next URL:");
                    loaderDescr.append("\n          ").append(urls[j].toString());
                }
            }
            
            loaderDescr.append("\n     Next loader parent:");
            loaderDescr.append("\n     ").append(String.valueOf(nextLoader.getParent()));
        }
        
        System.out.println(loaderDescr);
    }
}
