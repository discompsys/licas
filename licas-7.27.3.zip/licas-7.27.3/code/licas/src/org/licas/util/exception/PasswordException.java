/*
 * PasswordException.java
 *
 * Created on 29 December 2008
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util.exception;


import org.jlog2.exception.WriteMessageException;


/**
 * This class can be used to throw an exception relating to an incorrect password.
 * @author Kieran Greer
 */
public class PasswordException extends WriteMessageException
{
    /**
     * Create a new instance of PasswordException. This exception is passed through
     * each time, although only the message part gets written to the logger.
     * @param message the error message.
     */
    public PasswordException(String message)
    {
        super(message, false);
    }
    
    /**
     * Create a new instance of PasswordException.
     * @param message the error message.
     * @param thisUseOnce if true pass through the logger only once, if false, then pass
     * through the logger each time.
     */
    public PasswordException(String message, boolean thisUseOnce)
    {
        super(message, thisUseOnce);
    }
}
