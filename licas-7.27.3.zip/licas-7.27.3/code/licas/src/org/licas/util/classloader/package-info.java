/**
 * For dynamically creating and loading in classes from Jar files.
 */
package org.licas.util.classloader;