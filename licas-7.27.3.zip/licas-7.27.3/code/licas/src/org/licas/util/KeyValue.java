/*
 * KeyValue.java
 *
 * Created on 15 July 2014
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 *
 */

package org.licas.util;

import java.util.Date;

/**
 * Key-Value pair, where the key is a String and the value is an Object.
 * @author Kieran Greer
 */
public class KeyValue 
{
    /** Optional time-stamp for the object. Default is not set. */
    public long timeStamp;

    /** The key */
    public String key;
    
    /** The value */
    public Object value;

    
    /** Create a new instance of KeyValue */
    public KeyValue()
    {
        timeStamp = -1;
        key = null;
        value = null;
    }
    
    /**
     * String-based representation of the key-value.
     * @return string-based description.
     */
    public String toString()
    {
        String str;                         //description
        
        str = ("Key: " + key);
        try
        {
            str += (", Value: " + ObjectHandler.getValue(value));
        }
        catch (Exception ex) {
            str += (", Value: " + String.valueOf(value));
        }
        if (timeStamp > 0) {
            str += (", time-stamp: " + (new Date(timeStamp)).toString());
        }

        return str;
    }
}
