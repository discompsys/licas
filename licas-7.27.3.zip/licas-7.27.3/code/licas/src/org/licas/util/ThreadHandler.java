/*
 * ThreadHandler.java
 *
 * Created on 26 March 2010
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.util;


import java.awt.*;


/**
 * This class can be used to handle some thread specific problems, related to
 * invoking waiting GUI events. If the operating system is specified as 'Android' -
 * {@code System.setProperty('type.os', Const.ANDROID);} then the event queue is switched off.
 * @author Kieran Greer
 */
public class ThreadHandler
{
    /**
     * This can be used to notify the next event on the event dispatch thread to execute.
     * This does not include some GUI update events, but only the running thread events.
     * @throws java.lang.Exception any error.
     */
    public static void notifyEvents() throws Exception
    {
        String prop;                //property value
        
        prop = System.getProperty("type.os");
        if ((prop == null) || !prop.equalsIgnoreCase(Const.ANDROID))
        {
            if (EventQueue.getCurrentEvent() != null)
            {
                if (EventQueue.getCurrentEvent() instanceof Runnable)
                {
                    if (EventQueue.isDispatchThread())
                        EventQueue.invokeLater((Runnable)EventQueue.getCurrentEvent());
                    else
                        EventQueue.invokeAndWait((Runnable)EventQueue.getCurrentEvent());
                }
            }
        }
    }

    /**
     * This can be used to notify the next event on the event dispatch thread to execute.
     * This includes all events, including the GUI update events.
     */
    public static void notifyAllEvents()
    {
        String prop;                //property value
        
        prop = System.getProperty("type.os");
        if ((prop == null) || !prop.equalsIgnoreCase(Const.ANDROID))
        {
            if (EventQueue.getCurrentEvent() != null)
            {
                EventQueue.invokeLater((Runnable)EventQueue.getCurrentEvent());
            }
        }
    }
}
