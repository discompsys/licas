/*
 * MessageInfo.java
 *
 * Created on 26 January 2011
 *
 * Version 1.4
 *
 * Copyright (c) 2011 Kieran Greer
 */

package org.licas;


import org.licas.util.AiConst;

import java.util.Date;


/**
 * This class stores information communication messages, or message objects in general. This can
 * be used to model agent-like messages with communication IDs and even state transitions.
 * Two states are stored - one is for the current message communication thread and
 * one is for the autonomic component itself. If the component is processing more than
 * one message, then its state does not have to relate to this message or process
 * in particular. This class only provides the variable fields. To actually implement
 * state transitions, etc., requires additional coding.
 * @author Kieran Greer
 */
public class MessageInfo
{
    /** A timestamp to record when the message was sent/received */
    private long timeStamp;

    /** The communication ID relating to the message */
    private String commID;
    
    /** Whether an input message or an output message */
    private String inOut;

    /** The state for the current service function or method that is being executed */
    private String messageState;

    /** The current state of the auto component (service) itself */
    private String serviceState;

    /** The message itself */
    private Object message;


    /**
     * Create a new instance of MessageInfo.
     * @param theMessage the message.
     */
    public MessageInfo(Object theMessage)
    {
        initialise();
        message = theMessage;
    }
    
    /**
     * Create a new instance of MessageInfo.
     * @param theCommID a message communication ID or key.
     * @param theMessage the message. The can also be a client URI.
     */
    public MessageInfo(String theCommID, Object theMessage)
    {
        initialise();
        commID = theCommID;
        message = theMessage;
    }

    /** Initialise some values */
    private void initialise()
    {
        timeStamp = System.currentTimeMillis();
        commID = null;
        inOut = null;
        messageState = null;
        serviceState = null;
    }


    /**
     * Set the message value.
     * @param theMessage the value of message.
     */
    public void setMessage(Object theMessage)
    {
        message = theMessage;
    }
    
    /**
     * Get the message.
     * @return the value of message.
     */
    public Object getMessage()
    {
        return message;
    }
    
    /**
     * Set the message communication ID.
     * @param theCommID the communication ID.
     */
    public void setCommID(String theCommID)
    {
        commID = theCommID;
    }
    
    /**
     * Get the message communication ID.
     * @return the value of commID.
     */
    public String getCommID()
    {
        return commID;
    }

    /**
     * Set the time stamp for the message. This can be set only once.
     * It is stored in the form of milliseconds created from {@code Date.getTime()}.
     */
    public void setTimeStamp()
    {
        if (timeStamp < 0) timeStamp = (new Date().getTime());
    }

    /**
     * Set the time stamp for the message. This can be set only once.
     * It should be in the form of milliseconds created from {@code Date.getTime()}.
     * @param theTimeStamp a time stamp for the message instance.
     */
    public void setTimeStamp(long theTimeStamp)
    {
        if (timeStamp < 0) timeStamp = theTimeStamp;
    }

    /**
     * Get the time the message was logged at.
     * This should be in the form of milliseconds from {@code Date.getTime()}.
     * @return the time stamp value.
     */
    public long getTimeStamp()
    {
        return timeStamp;
    }

    /**
     * Set whether an input or an output message type. Can be either {@link AiConst}.{@code INPUT},
     * or {@code OUTPUT}.
     * @param theInOut the value indicating an input or an output message type.
     */
    public void setInOut(String theInOut)
    {
        inOut = theInOut;
    }

    /**
     * Get the input-output status of the message.
     * @return the value of inOut.
     */
    public String getInOut()
    {
        return inOut;
    }
    
    /**
     * Set the state for the current function that is being executed.
     * @param theMessageState the service function state.
     */
    public void setMessageState(String theMessageState)
    {
        messageState = theMessageState;
    }

    /**
     * Get the state for the function that is being executed.
     * @return the value of messageState.
     */
    public String getMessageState()
    {
        return messageState;
    }

    /**
     * Set the state for the auto service component itself.
     * @param theServiceState the auto component's state.
     */
    public void setServiceState(String theServiceState)
    {
        serviceState = theServiceState;
    }

    /**
     * Get the state for the auto service component itself.
     * @return the value of serviceState.
     */
    public String getServiceState()
    {
        return serviceState;
    }

    /**
     * Return true if this message is the same object the one passed in.
     * @param thisMessage the message to compare to.
     * @return true if the same based on Object similarity values.
     */
    public boolean isSameObj(MessageInfo thisMessage)
    {
        return ((thisMessage.getTimeStamp() == timeStamp) &&
                (thisMessage.hashCode() == hashCode()));
    }
    
    /**
     * Return true if this message has the same ID as the one passed in.
     * @param thisMessage the message to compare to.
     * @return true if the same, based on ID values.
     */
    public boolean isSameID(MessageInfo thisMessage)
    {
        return ((thisMessage.getTimeStamp() == timeStamp) &&
                (thisMessage.getCommID().equals(commID)));
    }
    
    /**
     * Get a copy of this {@code MessageInfo} object.
     * @return a copy of this object, with a direct message reference.
     */
    public Object clone()
    {
        MessageInfo messageClone;                   //message clone

        messageClone = new MessageInfo(commID, message);
        messageClone.setInOut(inOut);
        messageClone.setMessageState(messageState);
        messageClone.setServiceState(serviceState);
        messageClone.setTimeStamp(timeStamp);
        
        return messageClone;
    }
}
