/*
 * LicasDocSearch.java
 *
 * Created on 22 September 2014
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.query;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.FileLoader;
import org.jlog2.util.UuidHandler;
import org.licas.PasswordHandler;
import org.licas.Service;
import org.licas.ServiceAdmin;
import org.licas.ServiceLinks;
import org.licas.call.CallObject;
import org.licas.call.Handle;
import org.licas.call.MethodInfo;
import org.licas.call.ParamInfo;
import org.licas.def.search.LicasDocSearchDef;
import org.licas.server.ESB;
import org.licas.server.LocalServer;
import org.licas.service.model.Contract;
import org.licas.service.spec.ServiceSpec;
import org.licas.util.*;
import org.licas_text.SourceText;
import org.licas_text.parser.QueryParser;
import org.licas_text.query.QueryMediator;
import org.licas_text.query.model.PatternConstraint;
import org.licas_text.query.model.PatternElement;
import org.licas_text.query.model.QueryModel;
import org.licas_text.util.QueryConst;
import org.licas_text.util.XmlHtmlHandler;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.Vector;


/**
 * Search over the contents of documents in specified folders. Note that this does not
 * update any links between services or perform any other type of function.
 * This currently only searches over the public web folder and sub-folders.
 * @author Kieran Greer
 */
public class LicasDocSearch extends ServiceAdmin implements LicasDocSearchDef
{
    /** For logging */
    private static final Logger logger;
    
    
    /** List of IDs for queries currently being executed */
    protected ArrayList<String> queryIDs;
    
    /** The password handler */
    protected PasswordHandler passwordHandler;
    
    /** Initialisation service specification */
    protected ServiceSpec serviceSpec;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(LicasDocSearch.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of LicasDocSearch.
     * @param theParent the parent service.
     * @param thePasswordHandler the parent password handler.
     * @throws java.lang.Exception any error.
     */
    public LicasDocSearch(Service theParent, PasswordHandler thePasswordHandler) 
            throws Exception
    {
        super(theParent, thePasswordHandler.getAdminKey(), null);
        passwordHandler = thePasswordHandler;
        
        serviceSpec = new ServiceSpec(passwordHandler);
        serviceSpec.serverSpec.serverAddress = LocalServer.getServerURL();
        serviceSpec.serverSpec.password = passwordHandler.getPassword();
        serviceSpec.serverSpec.adminKey = passwordHandler.getAdminKey();
        
        initialise();
    }
    
    /** 
     * Initialise some values.
     * @throws java.lang.Exception any error.
     */
    private void initialise() throws Exception
    {
        passwordHandler = serviceSpec.serverSpec.passwordHandler;
        queryIDs = new ArrayList<>();
    }

    /**
     * Query the server to parse documents to find matching information. To be
     * recognised by the default classes, the root {@code request} element should
     * have the tag name of {@link QueryConst}.{@code QUERYMODEL}, or 'Query_Model'. This 
     * should then contain a description of the query request. For this default model, the
     * XML request that is passed in needs to be parsed by a {@link QueryParser} parser
     * into a {@link QueryModel} object, of the 'licas_text' package. This is what the 
     * default classes will then evaluate. The documentation describes the different 
     * fields in more detail.
     * @param queryEngine the query engine type.
     * @param callTimeout maximum time allowed for the call (in milliseconds).
     * @param request the query request in XML format.
     * @param serverLinks the {@link ESB} links information.
     * @return any suitable matches to the request. These are stored inside of
     * an element for each related service, with attributes to describe the service
     * uuid and type.
     * @throws java.lang.Exception any error.
     */
    public Element docSearch(String queryEngine, int callTimeout, Element request, 
            ServiceLinks serverLinks) throws Exception
    {
        int i, j;
        String queryID;                             //query id
        String queryType;                           //query type
        String filePath;                            //file path
        String fileText;                            //file text content
        String patternValue;                        //pattern value
        String comparison;                          //comparison value
        ArrayList<String> fileList;                 //list of files
        Vector<Node> replyElems;                    //reply elements
        Element searchReply;                        //search reply
        Element replyElem;                          //reply element
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Element queryXml;                           //query model as xml
        Element queryElem;                          //query reply element
        PatternElement patternElement;              //pattern element
        PatternConstraint patternConstraint;        //pattern constraint
        QueryModel queryModel;                      //the query model
        QueryParser queryParser;                    //related query parser
        QueryMediator queryMediator;                //query mediator
 
        queryID = null;

        try {
            queryMediator = new QueryMediator();
            DocumentReader.checkForBinaryReader();
            replyElem = XMLFactory.getInstance().createElement(Const.RESULT);
            
            //check if query description nested in another element
            if (!request.getName().equals(QueryConst.QUERYMODEL))
                queryXml = request.getChild(QueryConst.QUERYMODEL);
            else
                queryXml = request;
            
            //only query with the model spec, must have root Query_Model name
            queryID = queryXml.getAttributeValue(QueryConst.QID);
            if ((queryID == null) || queryID.equals("")) {
                queryID = UuidHandler.getUuid(10);
                queryXml.setAttribute(QueryConst.QID, queryID);
            }
            
            //check that query has not cycled back to this server
            if (!queryIDs.contains(queryID)) {
                queryIDs.add(queryID);
                queryParser = new QueryParser();
                queryModel = (QueryModel)queryParser.parse(queryXml);
                queryType = queryModel.getQueryType();
                 
                //search using local service only if file list added, else distributed web folders
                if (!queryModel.getFileList().isEmpty()) {
                    fileList = readUrlDocs(queryModel.getFileList());

                    for (i = 0; i < fileList.size(); i++)
                    {
                        fileText = fileList.get(i);
                        queryElem = queryMediator.executeQuery(queryXml, fileText);

                        if ((queryElem != null) && (queryElem.hasChildren() || 
                            ((queryElem.getText() != null) && !queryElem.getText().trim().equals("")))) {
                            nextElem = XMLFactory.getInstance().createElement(Const.NEXTREPLY); 
                            replyElem.addContent(nextElem);

                            nextElem2 = XMLFactory.getInstance().createElement(Const.SERVERADDRESS);
                            nextElem2.setText(LocalServer.getServerURL());
                            nextElem.addContent(nextElem2);

                            nextElem2 = XMLFactory.getInstance().createElement(Const.FILEURI);
                            nextElem2.setText(queryModel.getFileList().get(i));
                            nextElem.addContent(nextElem2);
                        }
                    }
                }
                else {
                    //get list of files from the web folder, only consider text readable ones
                    fileList = FileObject.getFullFileListPaths(ServiceConst.WEBSEARCHHOME, true);                

                    //execute the query - if filename search then local here,
                    //if contents search then use the query engine
                    //this will default to a text lines-based search in either case
                    patternElement = queryModel.getQueryPattern().get(0);

                    if (queryType.equalsIgnoreCase(LicasQueryConst.FILENAME)) {
                        patternConstraint = patternElement.getValueConstraints().get(0);
                        comparison = patternConstraint.getCondition();
                        patternValue = patternConstraint.getValue().toLowerCase();

                        for (i = 0; i < fileList.size(); i++)
                        {
                            filePath = fileList.get(i);
                            fileText = (new File(filePath)).getName();

                            if (comparison.equalsIgnoreCase(QueryConst.CONTAINS)) {
                                if (fileText.toLowerCase().contains(patternValue)) {
                                    nextElem = XMLFactory.getInstance().createElement(Const.NEXTREPLY); 
                                    replyElem.addContent(nextElem);

                                    nextElem2 = XMLFactory.getInstance().createElement(Const.SERVERADDRESS);
                                    nextElem2.setText(LocalServer.getServerURL());
                                    nextElem.addContent(nextElem2);

                                    nextElem2 = XMLFactory.getInstance().createElement(Const.FILEURI);
                                    nextElem2.setText(filePath);
                                    nextElem.addContent(nextElem2);
                                }
                            }
                            else {
                                //match whole filename - remove postfix first
                                fileText = FileObject.removeFileType(fileText);

                                if (fileText.toLowerCase().equals(patternValue)) {
                                    nextElem = XMLFactory.getInstance().createElement(Const.NEXTREPLY); 
                                    replyElem.addContent(nextElem);

                                    nextElem2 = XMLFactory.getInstance().createElement(Const.SERVERADDRESS);
                                    nextElem2.setText(LocalServer.getServerURL());
                                    nextElem.addContent(nextElem2);

                                    nextElem2 = XMLFactory.getInstance().createElement(Const.FILEURI);
                                    nextElem2.setText(filePath);
                                    nextElem.addContent(nextElem2);
                                }
                            }
                        }
                    }
                    else {
                        for (i = 0; i < fileList.size(); i++)
                        {
                            filePath = fileList.get(i);
                            fileText = DocumentReader.readDocument(filePath);
                            queryElem = queryMediator.executeQuery(queryXml, fileText);

                            if ((queryElem != null) && (queryElem.hasChildren() || 
                                ((queryElem.getText() != null) && !queryElem.getText().trim().equals("")))) {
                                nextElem = XMLFactory.getInstance().createElement(Const.NEXTREPLY); 
                                replyElem.addContent(nextElem);

                                nextElem2 = XMLFactory.getInstance().createElement(Const.SERVERADDRESS);
                                nextElem2.setText(LocalServer.getServerURL());
                                nextElem.addContent(nextElem2);

                                nextElem2 = XMLFactory.getInstance().createElement(Const.FILEURI);
                                nextElem2.setText(filePath);
                                nextElem.addContent(nextElem2);
                            }
                        }
                    }

                    //also query linked server and combine the results
                    for (i = 0; i < serverLinks.getServiceAssociations().size(); i++)
                    {
                        searchReply = queryServerDocs(queryEngine, callTimeout, (Element)queryXml.clone(),
                                serverLinks.getServiceAssociations().get(i));

                        if ((searchReply != null) && searchReply.hasChildren()) {
                            replyElems = searchReply.getChildren();
                            for (j = 0; j < replyElems.size(); j++)
                            {
                                replyElem.addContent((Element)replyElems.get(j));
                            }
                        }
                    }
                }
            }
            
            return replyElem;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "docSearch", 
                    "", ex);
        }
        finally {
            if (queryID != null) queryIDs.remove(queryID);
        }
    }
    
    /**
     * Query the specified server with the query request and return the result.
     * @param queryEngine the query engine type.
     * @param callTimeout maximum time allowed for the call (in milliseconds).
     * @param request the query request.
     * @param serverUrl the uri of the server to call. If null try the local server.
     * @return any suitable matches to the request. These are stored inside of
     * an element for each related service, with attributes to describe the service
     * uuid and type.
     */
    private Element queryServerDocs(String queryEngine, int callTimeout, Element request,
            Element serverUrl)
    {
        String serverUri;                           //server uri
        String serverPassword;                      //server password
        Element queryReply;                         //query reply    
        Contract contract;                          //the contract
        ESB serverParent;                           //auto server parent
        MethodInfo methodInfo;                      //method info
        MethodInfo methodParam;                     //method parameter
        CallObject call;                            //call object
        
        queryReply = null;
        serverPassword = null;

        try {
            call = new CallObject();
            serverParent = (ESB)service;            
            if (serverUrl == null) serverUrl = Handle.getLocalServerURI();
            serverUri = XmlHandler.xmlToString(serverUrl); 

            try {
                serverPassword = serverParent.getPassword(serverUri, serviceAdminKey);
            }
            catch (Exception pex) {}

            if (serverPassword == null) {
                //try to retrieve the password remotely
                contract = Contract.getYesContract();
            
                methodInfo = new MethodInfo();
                methodInfo.setName(MethodConst.GETPASSWORD);
                methodInfo.setRtnType(TypeConst.STRING);
                methodInfo.setServiceURI(serverUrl);
                methodInfo.addParam(new ParamInfo(Const.ANON));
                methodInfo.addParam(new ParamInfo(contract));
                serverPassword = (String)call.call(methodInfo);
                
                if (serverPassword != null) serverParent.addServicePassword(serverUri, serverPassword, serviceAdminKey);
            }
            
            if (serverPassword != null) {
                //remote server only executes query locally (update any links?)
                //queryEngine determines service to execute, method name not used for web folder search
                methodParam = new MethodInfo();
                methodParam.setName(MethodConst.EXECUTEQUERY);
                methodParam.setRtnType(TypeConst.ELEMENT);
                if (callTimeout > 0) methodParam.setCallTimeout(callTimeout);
                methodParam.addParam(new ParamInfo(request));

                methodInfo = new MethodInfo();
                methodInfo.setName(MethodConst.EXECUTESERVICETYPE);
                methodInfo.setRtnType(TypeConst.ELEMENT);
                methodInfo.setServiceURI(serverUrl);
                methodInfo.setServerPassword(serverPassword);
                methodInfo.setPassword(serverPassword);
                methodInfo.getParams().add(new ParamInfo(queryEngine));
                methodInfo.getParams().add(new ParamInfo(methodParam));
                if (callTimeout > 0) methodInfo.setCallTimeout(callTimeout);
                queryReply = (Element)call.call(methodInfo);
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "queryServerDocs", 
                null, ex);
        }

        return queryReply;
    }
    
    /**
     * Read a list of text documents from files or URLs and return the parsed text.
     * @param fileList list of file paths or URLs to read the document from.
     * @return list of text-only documents, with any markup/formatting removed.
     * @throws java.lang.Exception any error.
     */
    public ArrayList<String> readUrlDocs(ArrayList<String> fileList) throws Exception
    {
        int i;
        String fileType;                        //the file type
        String filePath;                        //file path
        String fileText;                        //file text
        ArrayList<String> textList;             //list of parsed text
        SourceText sourceText;                  //source text

        try {
            textList = new ArrayList<>();
            sourceText = new SourceText();
            DocumentReader.checkForBinaryReader();
            
            for (i = 0; i < fileList.size(); i++)
            {
                filePath = fileList.get(i);
                fileType = FileObject.getFileType(filePath);
                
                if (TypeConst.isHtml(fileType)) {
                    fileText = sourceText.parseHTML(new URL(filePath), null);                   
                }
                else if (TypeConst.isXmlType(fileType)) {
                    fileText = FileLoader.getInputStream(filePath);
                    fileText = XmlHtmlHandler.removeXmlTags(fileText);
                }
                else if (TypeConst.isTextType(fileType)) {
                    fileText = FileLoader.getInputStream(filePath);
                }
                else {
                    fileText = DocumentReader.readDocument(filePath);
                }
                
                textList.add(fileText);
            }

            return textList;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "readUrlDocs", 
                null, ex);
        }
    }
}
