/*
 * LinkQueryConfig.java
 *
 * Created on 8 April 2018
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.query;


import java.util.ArrayList;


/**
 * Configuration for a query over the dynamic links structure.
 * @author Kieran Greer
 */
public class LinkQueryConfig
{
    /** Maximum number of links to return */
    public int maxNumber;
    
    /** List of concepts in a path to traverse */
    public ArrayList<String> conceptList;
    
    
    /** Create a new instance of LinkQueryConfig */
    public LinkQueryConfig()
    {
        maxNumber = -1;
        conceptList = new ArrayList<>();
    }
}
