/*
 * DocumentReader.java
 *
 * Created on 30 April 2018
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.query;


import org.jlog2.util.FileLoader;
import org.licas.util.ReflectionHandler;
import org.licas.util.TypeConst;
import org.licas.util.classloader.LoadObject;

import java.io.BufferedReader;
import java.lang.reflect.Method;
import java.util.ArrayList;


/**
 * Read a document into text. Can try to find a binary reader to parse word files.
 * @author Kieran Greer
 */
public class DocumentReader
{
    /** Binary reader to read binary documents as well */
    private static Object binaryReader = null;
    
    /**
     * Read a document into a text string. Check for a binary reader first.
     * @param filePath the document file path.
     * @return the parsed text.
     * @throws java.lang.Exception any error.
     */
    public static String readDocument(String filePath) throws Exception
    {
        StringBuilder fileText;                 //the parsed text
        String nextLine;                        //next line
        ArrayList<String> paramTypes;           //param types
        Object[] params;                        //parameters
        BufferedReader reader;                  //buffered reader
        Method method;                          //the reflection method
        
        fileText = new StringBuilder();
        if (binaryReader != null) {
            paramTypes = new ArrayList<>();
            paramTypes.add(TypeConst.STRING);
            
            params = new Object[1];
            params[0] = filePath;
            method = ReflectionHandler.retrieveMethod(binaryReader.getClass(), "readFile",
                BufferedReader.class.getName(), paramTypes);
            
            reader = (BufferedReader)method.invoke(binaryReader, params);
            while ((nextLine = reader.readLine()) != null)
            {
                fileText.append(nextLine);
            }
        }
        else {
            fileText = new StringBuilder(FileLoader.getInputStream(filePath));
        }

        return fileText.toString();
    }
    
    /**
     * Check if a jar file with a binary reader is available and create if it is.
     */
    public static void checkForBinaryReader()
    {
        try {
            if (binaryReader == null) {
                LoadObject.getClass("org.dcs.word_filter.FileHandler");
                binaryReader = LoadObject.loadObject(new ArrayList<>(),
                    "org.dcs.word_filter.FileHandler", new ArrayList<>());
            }
        }
        catch (Exception ex) {
            binaryReader = null;
        }
    }
}
