/**
 * The default search and query engines, mostly system-related.
 */
package org.licas.query;