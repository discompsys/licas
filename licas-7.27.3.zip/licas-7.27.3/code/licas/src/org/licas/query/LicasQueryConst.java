/*
 * LicasQueryConst.java
 *
 * Created on 29 October 2015.
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.query;


import org.licas_text.util.QueryConst;

import java.util.ArrayList;


/**
 * Some constant values relating to the default licas query engines.
 * @author Kieran Greer
 */
public class LicasQueryConst extends QueryConst
{ 
    //Queries
    /** Root licas query tag */
    public static final String LICASQUERY = "Licas_Query";
    
    /** Search metadata type */
    public static final String SEARCHMETADATA = "Search metadata";
    
    /** Search autonomic manager stats type */
    public static final String SEARCHAUTODATA = "Autonomic manager metrics";
    
    /** Search internet contents type */
    public static final String SEARCHALLWEB = "Search web contents";
    
    /** Search web folder type */
    public static final String SEARCHWEBFOLDER = "Search web folder";
    
    
    //Query Model
    public static final String QUERYMEDIATOR = "queryMediator";
    public static final String QUERYMODEL = "queryModel";
    public static final String QUERYREPLY = "queryReply";
    
    
    //Autonomic Search or Query Metrics
    public static final String MESSAGECOUNT = "Message count";
    public static final String MESSAGESIZE = "Message size";
    public static final String EMPTYCOUNT = "Empty count";
    
    
    /**
     * Get a list of default licas-based search types.
     * @return a list of default search types.
     */
    public static ArrayList<String> getLicasSearchTypes()
    {
        ArrayList<String> searchTypes;
        
        searchTypes = new ArrayList<>();
        searchTypes.add(SEARCHMETADATA);
        searchTypes.add(SEARCHAUTODATA);
        return searchTypes;
    }
}
