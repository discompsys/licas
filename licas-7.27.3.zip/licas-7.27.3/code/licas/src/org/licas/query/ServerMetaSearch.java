/*
 * ServerMetaSearch.java
 *
 * Created on 6 April 2011
 *
 * Version 1.4.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.query;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.UuidHandler;
import org.licas.PasswordHandler;
import org.licas.Service;
import org.licas.ServiceAdmin;
import org.licas.ServiceLinks;
import org.licas.call.CallObject;
import org.licas.call.Handle;
import org.licas.call.MethodInfo;
import org.licas.call.ParamInfo;
import org.licas.def.search.ServiceMetaSearchDef;
import org.licas.server.ESB;
import org.licas.server.LocalServer;
import org.licas.service.InformationMediator;
import org.licas.service.model.Contract;
import org.licas.service.spec.QueryUpdate;
import org.licas.service.spec.ServiceSpec;
import org.licas.util.Const;
import org.licas.util.MethodConst;
import org.licas.util.TypeConst;
import org.licas_text.parser.QueryParser;
import org.licas_text.query.QueryEngine;
import org.licas_text.query.QueryMediator;
import org.licas_text.query.model.QueryModel;
import org.licas_text.util.MetaConst;
import org.licas_text.util.QueryConst;
import org.licas_text.util.XmlHtmlHandler;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.util.ArrayList;
import java.util.Vector;


/**
 * Metadata search facility on a server to search for related services. This can 
 * search over limited information on the services stored under this server. The
 * search is performed over the metadata stored for each service.
 * @author Kieran Greer
 */
public class ServerMetaSearch extends ServiceAdmin implements ServiceMetaSearchDef
{
    /** For logging */
    private static final Logger logger;
    
    
    /** List of IDs for queries currently being executed */
    protected ArrayList<String> queryIDs;
    
    /** The password handler */
    protected PasswordHandler passwordHandler;
    
    /** Initialisation service specification */
    protected ServiceSpec serviceSpec;
    
    /** Can be used to mediate between services or update related values */
    protected InformationMediator infoMediator;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServerMetaSearch.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of ServerMetaSearch.
     * @param theParent the parent service.
     * @param thePasswordHandler the parent password handler.
     * @throws java.lang.Exception any error.
     */
    public ServerMetaSearch(Service theParent, PasswordHandler thePasswordHandler) 
            throws Exception
    {
        super(theParent, thePasswordHandler.getAdminKey(), null);
        passwordHandler = thePasswordHandler;
        
        serviceSpec = new ServiceSpec(passwordHandler);
        serviceSpec.serverSpec.serverAddress = LocalServer.getServerURL();
        serviceSpec.serverSpec.password = passwordHandler.getPassword();
        serviceSpec.serverSpec.adminKey = passwordHandler.getAdminKey();
        
        initialise();
    }
    
    /** 
     * Initialise some values.
     * @throws java.lang.Exception any error.
     */
    private void initialise() throws Exception
    {
        passwordHandler = serviceSpec.serverSpec.passwordHandler;
        queryIDs = new ArrayList<>();
        
        infoMediator = new InformationMediator(passwordHandler);
        infoMediator.initialiseInfo(serviceSpec);
    }

    /**
     * Allow the server to perform queries over all of the registered service metadata 
     * to find matching information. To be recognised by the default classes, the root 
     * {@code request} element should have the tag name of {@link QueryConst}.{@code QUERYMODEL}, 
     * or {@code 'Query_Model'}. This should then contain a description of the query request. 
     * For this default model, the XML request that is passed in needs to be parsed by 
     * a {@link QueryParser} parser into a {@link QueryModel} object, of the {@code 'licas_text'} 
     * package. This is what the default classes will then evaluate. The documentation 
     * describes the different fields in more detail.
     * @param queryEngine the query engine type. Required for a distributed query.
     * @param callTimeout maximum time allowed for the call (in milliseconds).
     * @param request the query request.
     * @param serverLinks for links with other servers. These will also be queried.
     * @return any suitable matches to the request. These are stored inside of
     * an element for each related service, with attributes to describe the service
     * uuid and type.
     * @throws java.lang.Exception any error.
     */
    public Element metaSearch(String queryEngine, int callTimeout, Element request,
            ServiceLinks serverLinks) throws Exception
    {
        int i, j;
        String nextServiceID;                   //next service id
        String nextAdminKey;                    //next admin key
        String nextServiceType;                 //next service type
        String localLinkType;                   //local link type
        String remoteLinkType;                  //remote link type
        String queryID;                         //query id
        ArrayList<String> serviceIDs;           //all service ids
        ArrayList<String> lrIDs;                //list of local or remote IDs
        ArrayList<String> toInclude;            //additional metadata
        ArrayList<Element> localReplies;        //local replies
        ArrayList<Element> remoteReplies;       //remote replies
        Vector<Node> replyElems;                //reply elements
        Element serviceUri;                     //the service uri
        Element queryReply;                     //the query reply
        Element searchReply;                    //search reply
        Element replyElem;                      //reply element
        Element nextElem;                       //next element
        Element otherMeta;                      //additional processing metadata
        Element serviceMeta;                    //service metadata
        Element queryModel;                     //query model as xml
        QueryUpdate queryUpdate;                //query update spec
        ESB serverParent;                       //auto server parent
 
        queryID = null;
        try
        {
            serverParent = (ESB)service;
            queryUpdate = new QueryUpdate();
            
            replyElem = XMLFactory.getInstance().createElement(Const.RESULT); 
            localReplies = new ArrayList<>();
            remoteReplies = new ArrayList<>();
            localLinkType = null;
            remoteLinkType = null;

            //check if query description nested in another element
            if (!request.getName().equals(QueryConst.QUERYMODEL))
                queryModel = request.getChild(QueryConst.QUERYMODEL);
            else
                queryModel = request;
            
            queryID = queryModel.getAttributeValue(QueryConst.QID);
            if ((queryID == null) || queryID.equals("")) {
                queryID = UuidHandler.getUuid(10);
                queryModel.setAttribute(QueryConst.QID, queryID);
            }
            
            //check that query has not cycled back to this server
            if (!queryIDs.contains(queryID)) {
                queryIDs.add(queryID);
                serviceIDs = serverParent.getServiceNames();
                
                //remove remote link updates part if there is one - set other part
                otherMeta = request.getChild(MetaConst.META);
                if (otherMeta != null) {
                    nextElem = otherMeta.getChild(Const.LOCALLINKS);
                    if (nextElem != null) {
                        localLinkType = nextElem.getText();
                    }
                    nextElem = otherMeta.getChild(Const.REMOTELINKS);
                    if (nextElem != null) {
                        remoteLinkType = nextElem.getText();
                        nextElem.detach();
                    }
                }
                
                toInclude = new ArrayList<>();
                toInclude.add(Const.OTHERMETA);
                toInclude.add(Const.DATA);

                for (i = 0; i < serviceIDs.size(); i++)
                {
                    nextServiceID = serviceIDs.get(i);
                    nextAdminKey = serverParent.getAdminKey(nextServiceID, serviceAdminKey);

                    if (nextAdminKey != null) {
                        serviceMeta = serverParent.getServiceMeta(nextServiceID, nextAdminKey, toInclude);
                        searchReply = queryServiceMeta(serviceMeta, (Element)queryModel.clone());

                        if ((searchReply != null) && searchReply.hasChildren()) {
                            nextServiceType = serverParent.getServiceType(nextServiceID);

                            nextElem = XMLFactory.getInstance().createElement(Const.NEXTSERVICE);
                            nextElem.setAttribute(Const.NAME, nextServiceID);
                            nextElem.setAttribute(Const.TYPE, nextServiceType);
                            nextElem.addContent(searchReply);

                            replyElem.addContent(nextElem);
                            localReplies.add(nextElem);
                        }
                    }
                }

                //also query linked server and combine the results
                for (i = 0; i < serverLinks.getServiceAssociations().size(); i++)
                {
                    searchReply = queryServerMeta(queryEngine, callTimeout, (Element)request.clone(),
                            serverLinks.getServiceAssociations().get(i));

                    if ((searchReply != null) && searchReply.hasChildren()) {
                        replyElems = searchReply.getChildren();
                        for (j = 0; j < replyElems.size(); j++)
                        {
                            replyElem.addContent((Element)replyElems.get(j));
                            remoteReplies.add((Element)replyElems.get(j));
                        }
                    }
                }
                
                if ((localLinkType != null)  && (localReplies.size() > 0)) {
                    lrIDs = new ArrayList<>();
                    toInclude = new ArrayList<>();
                    toInclude.add(localLinkType);

                    for (i = 0; i < localReplies.size(); i++)
                    {
                        queryReply = localReplies.get(i);
                        queryReply = queryReply.getChild(Const.METASEARCH);

                        if (queryReply != null) {
                            serviceUri = queryReply.getChild(Const.HANDLE);

                            if (serviceUri != null) {
                                nextServiceID = XmlHandler.xmlToString(serviceUri);
                                if (!lrIDs.contains(nextServiceID)) lrIDs.add(nextServiceID);
                            }
                        }
                    }

                    queryUpdate.localUpdates = toInclude;
                    queryUpdate.localLrb = 0;
                    queryUpdate.localURIs = lrIDs;
                }

                if ((remoteLinkType != null)  && (remoteReplies.size() > 0)) {
                    lrIDs = new ArrayList<>();
                    toInclude = new ArrayList<>();
                    toInclude.add(remoteLinkType);

                    for (i = 0; i < remoteReplies.size(); i++)
                    {
                        queryReply = remoteReplies.get(i);
                        queryReply = queryReply.getChild(Const.METASEARCH);

                        if (queryReply != null) {
                            serviceUri = queryReply.getChild(Const.HANDLE);

                            if (serviceUri != null) {
                                nextServiceID = XmlHandler.xmlToString(serviceUri);
                                if (!lrIDs.contains(nextServiceID)) lrIDs.add(nextServiceID);
                            }
                        }
                    }

                    queryUpdate.remoteUpdates = toInclude;
                    queryUpdate.remoteLrb = 1;
                    queryUpdate.remoteURIs = lrIDs;
                }
        
                infoMediator.updateQueryInfo(queryUpdate);
            }
            
            return replyElem;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "metaSearch", 
                    "", ex);
        }
        finally {
            if (queryID != null) queryIDs.remove(queryID);
        }
    }
    
    /**
     * Query the specified server with the query request and return the result.
     * @param queryEngine the query engine type.
     * @param callTimeout maximum time allowed for the call (in milliseconds).
     * @param request the query request.
     * @param serverUrl the uri of the server to call. If null try the local server.
     * @return any suitable matches to the request. These are stored inside of
     * an element for each related service, with attributes to describe the service
     * uuid and type.
     */
    private Element queryServerMeta(String queryEngine, int callTimeout, Element request,
            Element serverUrl)
    {
        String serverUri;                           //server uri
        String serverPassword;                      //server password
        Element queryReply;                         //query reply    
        Contract contract;                          //the contract
        ESB serverParent;                           //auto server parent
        MethodInfo methodInfo;                      //method info
        MethodInfo methodParam;                     //method parameter
        CallObject call;                            //call object
        
        queryReply = null;
        serverPassword = null;

        try {
            call = new CallObject();
            serverParent = (ESB)service;            
            if (serverUrl == null) serverUrl = Handle.getLocalServerURI();
            serverUri = XmlHandler.xmlToString(serverUrl); 

            //try to retrieve the server password
            try {
                serverPassword = serverParent.getPassword(serverUri, serviceAdminKey);
            }
            catch (Exception pex) {}

            if (serverPassword == null) {
                //if null check if allowed automatic access
                contract = Contract.getYesContract();
            
                methodInfo = new MethodInfo();
                methodInfo.setName(MethodConst.GETPASSWORD);
                methodInfo.setRtnType(TypeConst.STRING);
                methodInfo.setServiceURI(serverUrl);
                methodInfo.addParam(new ParamInfo(Const.ANON));
                methodInfo.addParam(new ParamInfo(contract));
                serverPassword = (String)call.call(methodInfo);
                
                if (serverPassword != null) serverParent.addServicePassword(serverUri, serverPassword, serviceAdminKey);
            }
            
            if (serverPassword != null) {
                //remote server only executes query locally and then updates its own 
                //local permanent links only
                methodParam = new MethodInfo();
                methodParam.setName(MethodConst.EXECUTEQUERY);
                methodParam.setRtnType(TypeConst.ELEMENT);
                if (callTimeout > 0) methodParam.setCallTimeout(callTimeout);
                methodParam.addParam(new ParamInfo(request));

                methodInfo = new MethodInfo();
                methodInfo.setName(MethodConst.EXECUTESERVICETYPE);
                methodInfo.setRtnType(TypeConst.ELEMENT);
                methodInfo.setServiceURI(serverUrl);
                methodInfo.setServerPassword(serverPassword);
                methodInfo.setPassword(serverPassword);
                methodInfo.getParams().add(new ParamInfo(queryEngine));
                methodInfo.getParams().add(new ParamInfo(methodParam));
                if (callTimeout > 0) methodInfo.setCallTimeout(callTimeout);
                queryReply = (Element)call.call(methodInfo);
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "queryServerMeta", 
                null, ex);
        }

        return queryReply;
    }
    
    /**
     * Query the service metadata object to find matching information.
     * @param serviceMeta the service metadata description.
     * @param request the query request.
     * @return any suitable matches to the request. These are parts of the metadata
     * for this service that match the query conditions exactly and also any elements
     * that are nested inside or after the matched parts.
     * @throws java.lang.Exception any error.
     */
    private Element queryServiceMeta(Element serviceMeta, Element request) throws Exception
    {
        String queryType;                               //the query type
        String replyText;                               //reply text
        Element queryReply;                             //the query reply
        Element reply;                                  //query reply
        Element okElem;                                 //OK reply element
        QueryModel queryModel;                          //the query model
        QueryParser queryParser;                        //related query parser
        QueryMediator patternQuery;                     //xml pattern-based query
        Object requestObj;                              //request object

        //if text search then perform over the whole metadata document
        //if xml search then find the specific elements
        patternQuery = new QueryMediator();
        queryParser = new QueryParser();
        queryModel = (QueryModel)queryParser.parse(request);
        queryType = queryModel.getQueryType();           
        
        //if text search on XML, then do some pre-formatting to remove the xml tags completely
        if (!QueryEngine.isXmlQueryType(queryType)) {
            requestObj = XmlHtmlHandler.removeXmlTags(XmlHandler.xmlToString(serviceMeta)); 
        }
        else {
            requestObj = serviceMeta;
        }

        //execute the query
        queryReply = patternQuery.executeQuery(request, requestObj);

        //process the reply
        reply = XMLFactory.getInstance().createElement(Const.METASEARCH);           
        if (queryReply != null) {
            if (queryReply.hasChildren()) {
                reply.addContent(queryReply);
            }
            else {
                replyText = queryReply.getText();
                if ((replyText != null) && !replyText.equals("")) {
                    okElem = XMLFactory.getInstance().createElement(MetaConst.META);
                    reply.addContent(okElem);
                }
            }
        }
        
        return reply;
    }
}
