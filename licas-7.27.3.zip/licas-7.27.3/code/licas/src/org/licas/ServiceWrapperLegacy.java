/*
 * ServiceWrapperLegacy.java
 *
 * Created on 12 October 2019
 *
 * Version 1.2.1
 *
 * Copyright (c) Kieran Greer
 *
 */

package org.licas;


import org.licas.call.MethodInfo;
import org.licas.def.ServiceWrapperDef;
import org.licas.meta.ServiceMeta;
import org.licas.module.FrameworkModule;
import org.licas.module.ModuleHandler;
import org.licas.security.Metrics;
import org.licas.service.model.Contract;
import org.licas.service.model.WorkInfo;
import org.licas.util.*;
import org.licas.util.exception.ServiceException;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.UuidHandler;

import java.lang.reflect.Method;


/**
 * This class is a wrapper to store any object that may be invoked as a service or from a service.
 * Any service that is loaded onto the network is wrapped first. It can then only be
 * accessed through using the correct password. There are two service wrappers - this
 * stores a {@code legacy} object and a {@link ServiceWrapper} stores a licas {@link Service} object.
 * The autonomic manager is also an extension of {@code ServiceWrapper} class.
 * This means that any object can actually be loaded and stored as a service. The wrapper
 * class extends either a {@link FrameworkModule} or a full {@code Service}, depending on
 * what additional functionality is required. This would mean that any object can be
 * used as part of the licas system and the object methods can be found and invoked.
 * @author Kieran Greer
 */
public class ServiceWrapperLegacy extends Service implements ServiceWrapperDef
{
    /** The logger */
    private static final Logger logger;

    /** True if structures for enclosed service object already set */
    protected boolean setStructures;

    /** Measurements of general message/transaction numbers */
    protected Metrics metrics;

    /** The legacy object */
    protected Object legacyObj;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServiceWrapperLegacy.class.getName());
        logger.setDebug(false);
    }

    /**
     * Creates a new instance of ServiceWrapperLegacy.
     * @param theObj the object to wrap.
     * @throws Exception any error.
     */
    public ServiceWrapperLegacy(Object theObj) throws Exception
    {
        super();
        legacyObj = theObj;
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        setStructures = false;
        metrics = null;
    }

    /**
     * Return true if the stored object is legacy code, false if a licas service.
     * @return true in this case.
     */
    public boolean storesLegacy()
    {
        return true;
    }

    /** Create and initialise a new metrics object */
    private void createMetrics()
    {
        metrics = new Metrics();

        try {
            metrics.serviceID = UuidHandler.getUuid(10);
        }
        catch (Exception ex) {
            metrics.serviceID = Const.SERVICEWRAPPER;
        }

        metrics.serviceType = Const.SERVICEWRAPPER;
    }

    /**
     * This run method tries to start the run method on the embedded object.
     * You should override run in the embedded object to include your own process.
     */
    public void run() {
        try {
            if (legacyObj != null) {
                if (legacyObj instanceof Thread) ((Thread) legacyObj).start();
                else if (legacyObj instanceof Runnable) ((Runnable) legacyObj).run();
            }
        } catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "run", null, ex);
        }
    }

    /**
     * You must call this method to interrupt the thread.
     * This also interrupts all nested services.
     * @param adminKey the key to identify unique loading of the service.
     * @return true if the service is stopped.
     */
    public boolean interrupt(String adminKey)
    {
        boolean isOK;                       //true if OK

        isOK = false;
        if (passwordHandler.isAdminKey(adminKey))
        {
            if ((legacyObj != null) && (legacyObj instanceof Thread)) {
                try {
                    ((Thread) legacyObj).interrupt();
                } catch (Exception ex) {
                }
            }

            isOK = super.interrupt(adminKey);
        }

        return isOK;
    }

    /**
     * Copy and set certain settings between the service object and the wrapper.
     * @param parent the parent of the wrapper.
     * @throws Exception any error.
     */
    public final void copyToService(Object parent) throws Exception
    {
        try {
            if (!setStructures) {
                if (ModuleHandler.isService(parent)) {
                    passwordHandler = new PasswordHandler(((Service) parent).getPasswordHandler().getPassword(),
                            ((Service) parent).getPasswordHandler().getAdminKey());

                    if (!ModuleHandler.isServer(parent)) {
                        setParent((Service) parent);
                    }
                }
            }
        }
        finally {
            setStructures = true;
        }
    }

    /**
     * Reset the wrapper settings based on the wrapped object if a service.
     */
    public final void copyFromService()
    {
        setStructures = true;
    }

    /**
     * Add some metrics values relating to the current message.
     * @param messageObj the message object.
     * @param theAdminKey the admin key for the parent service.
     */
    public void addMetrics(MethodInfo messageObj, String theAdminKey)
    {
        if (metrics == null) createMetrics();
        if (getPasswordHandler().getAdminKey().equals(theAdminKey))
        {
            metrics.addMetrics(messageObj);
        }
    }

    /**
     * Get the default message/transaction metrics.
     * @return the value of metrics.
     */
    public Metrics getMetrics()
    {
        return metrics;
    }


    /**
     * Create a metadata description of this service for the server repository.
     * This wrapper is used to process the licas information for the legacy object.
     * @param theAdminKey the unique service key for admin purposes.
     * @return a metadata description of this service.
     * @throws Exception any error.
     */
    public ServiceMeta createMetaForRepos(String theAdminKey) throws Exception
    {
        return super.createMetaForRepos(theAdminKey);
    }

    /**
     * Store the communicationID with the related client uri.
     * @param communicationID the communication id.
     * @param clientUri the uri/reference for the calling client.
     * @return true if the id is new and can be added, or false if the id already
     * exists or cannot be added.
     * @throws Exception any error.
     */
    public boolean addCommunicationID(String communicationID, Object clientUri) throws Exception
    {
        return super.addCommunicationID(communicationID, clientUri);
    }

    /**
     * Add a new temporary password to the temp passwords list.
     * @param addPassword true if add a password.
     * @return the newly created password or null if do not add.
     * @throws Exception any error.
     */
    protected String addTempPassword(boolean addPassword) throws Exception
    {
        return super.addTempPassword(addPassword);
    }

    /**
     * Remove the temporary password from the list if it exists.
     * @param tempPassword the temporary password.
     */
    protected void removeTempPassword(String tempPassword)
    {
        super.removeTempPassword(tempPassword);
    }

    /**
     * Return true if the wrapped object can be accessed by the password.
     * If the object is of type {@code Service} then its {@code canAccess} method is called,
     * otherwise true is automatically returned.
     * @param thePassword the password to use.
     * @return true if the wrapped object can be accessed or false otherwise.
     */
    public boolean canAccess(String thePassword)
    {
        return true;
    }

    /**
     * Return true if the method on the wrapped object can be accessed by the password.
     * If the object is of type {@code Service} then its {@code canAccess} method is called,
     * otherwise true is automatically returned.
     * @param thePassword the password to use.
     * @param methodName the name of the method to call.
     * @return true if the wrapped object can be accessed or false otherwise.
     */
    public boolean canAccess(String thePassword, String methodName) throws Exception
    {
        return true;
    }

    /**
     * Return true if the method on the wrapped object can be accessed by the password.
     * If the object is of type {@code Service} then its {@code canAccess} method is called,
     * otherwise true is automatically returned.
     * @param thePassword the password to use.
     * @param theMethod the method reflection description.
     * @return true if the wrapped object can be accessed or false otherwise.
     */
    public boolean canAccess(String thePassword, Method theMethod) throws Exception
    {
        return true;
    }

    /**
     * Get this service's password, depending on the calling component's contract description.
     * By default, a service is assigned a 'yes' contract, meaning that it is open and
     * will always return its password, to allow for method invocation. The other default
     * option is a 'no' contract, meaning that there is no negotiation and the password
     * must be known. This can also be changed by adding a different 'sla' contract for
     * each service level in the service. You can therefore override this method
     * to provide your own checks, using this as a guide.
     * @param clientID the clientID of the calling component.
     * @param clientContract the description of the calling component's contract proposal.
     * @return the value of the password for the specified service level if the contract
     * is accepted, or null if it is not accepted. The default 'yes' contract always
     * returns the password.
     * @throws Exception any error.
     */
    public String getPassword(String clientID, Contract clientContract) throws Exception
    {
        return super.getPassword(clientID, clientContract);
    }

    /**
     * Get the password for this service.
     * The wrapper's getPassword method is called.
     * @param theAdminKey the service key.
     * @return the access password for this service.
     */
    public String getPassword(String theAdminKey)
    {
        return super.getPassword(theAdminKey);
    }

    /**
     * Get the password for the specified service.
     * The wrapper's getPassword method is called.
     * @param serviceUuid the id of the service to ask the password for.
     * @param theAdminKey the service key.
     * @return the password for the specified service or null if it cannot be retrieved.
     * @throws Exception any error.
     */
    public String getPassword(String serviceUuid, String theAdminKey) throws Exception
    {
        return super.getPassword(serviceUuid, theAdminKey);
    }

    /**
     * Get the work protocol details for the service.
     * The wrapper's {@code serviceAdmin} is used.
     * @return the service wrapper's {@code workInfo} details.
     */
    public WorkInfo getWorkInfo() { return super.serviceAdmin.workInfo; }

    /**
     * Return the service for the related service name.
     * The wrapper's getService method is called.
     * @param serviceName the name of the service.
     * @param thePassword the password to access the service to retrieve.
     * @return the wrapped service, or null if no service exists.
     * @throws ServiceException is access to any nested services is blocked.
     * @throws Exception any other error.
     */
    public ServiceWrapperDef getService(String serviceName, String thePassword)
            throws ServiceException, Exception
    {
        return super.getService(serviceName, thePassword);
    }

    /**
     * Return the service for the related service name.
     * The wrapper's getService method is called, where this version requires the admin key as well,
     * but then returns a direct reference.
     * @param serviceName the name of the service.
     * @param thePassword the password to access the service.
     * @param adminKey the service key for this server.
     * @return the service object if it exists or null if it does not.
     * @throws ServiceException for service specific error.
     * @throws Exception any other error.
     */
    public Object getService(String serviceName, String thePassword, String adminKey)
        throws ServiceException, Exception
    {
        return super.getService(serviceName, thePassword, adminKey);
    }

    /**
     * Set the wrapped object that is typically derived from {@link Service},
     * but can be a legacy object of any type.
     * @param theObj the value of obj.
     */
    public void setObjService(Object theObj)
    {
        if (legacyObj == null) legacyObj = theObj;
    }

    /**
     * Get the stored object service.
     * @param adminKey the admin key for the object or wrapper.
     * @return the stored object, or null if not the admin key.
     */
    public Object getObjService(String adminKey)
    {
        if ((adminKey != null) && getPasswordHandler().isAdminKey(adminKey))
        {
            return legacyObj;
        }

        return null;
    }

    /**
     * Get the class type of the stored object.
     * @return the stored object class name.
     */
    public Class getObjClass()
    {
        if (legacyObj != null) return legacyObj.getClass();
        else return null;
    }

    /**
     * Execute the specified method and return the result.
     * If the wrapped object is a service then its execute method is called,
     * otherwise this wrapper's execute method is called.
     * @param methodInfo the method call description with all of the required information.
     * @param addTempPassword if true add a temporary password to allow traversal
     * through this service. If the service is referenced directly as an object
     * then set this to false so that the caller must know this service's password.
     * @return the reply, any object.
     * @throws ServiceException any service specific error.
     * @throws Exception any other error.
     */
    public Object execute(MethodInfo methodInfo, boolean addTempPassword)
            throws ServiceException, Exception
    {
        return super.execute(methodInfo, addTempPassword);
    }

    /**
     * Invoke the method on the stored object with the specified parameters.
     * @param theMethod the method to invoke.
     * @param params the parameter list.
     * @return the result of the method invocation.
     * @throws Exception any error.
     */
    public Object invokeObj(Method theMethod, Object[] params) throws Exception
    {
        if (legacyObj != null) return theMethod.invoke(legacyObj, params);
        else return null;
    }
    
    /**
     * Return the thread state of the embedded object.
     * @return the embedded object state if a thread.
     */
    public String threadAliveState()
    {
        if (legacyObj != null)
        {
            if (legacyObj instanceof Thread)
                return String.valueOf(((Thread) legacyObj).isAlive());
            else if (legacyObj instanceof Runnable)
                return String.valueOf(new Thread(((Runnable) legacyObj)).isAlive());
        }

        return String.valueOf(Boolean.FALSE);
    }
}
