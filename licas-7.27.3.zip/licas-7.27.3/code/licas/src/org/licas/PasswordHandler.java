/*
 * PasswordHandler.java
 *
 * Created on 8 December 2008
 *
 * Version 1.13.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas;


import org.licas.call.CallObject;
import org.licas.call.Handle;
import org.licas.call.MethodInfo;
import org.licas.call.ParamInfo;
import org.licas.parsers.admin.AdminParser;
import org.licas.server.LocalServer;
import org.licas.service.model.Contract;
import org.licas.util.*;
import org.licas.util.exception.PasswordException;
import org.licas.util.exception.ServiceException;
import org.licas_text.util.XmlHtmlHandler;
import org.jlog2.util.UuidHandler;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.util.*;


/**
 * This class stores and processes passwords related to the parent service. This
 * includes all levels of security access if security levels are included. By default,
 * a service has one password to allow access to any of its methods and also a service
 * password to allow the administrator of the service to perform other
 * method operations that might alter the service itself. These are stored in the
 * {@code password} and {@code adminKey} fields respectively. If no security levels are specified 
 * in an admin document, then these are the only passwords that are required. 
 * <p>
 * If an admin document is included with the service's initialisation, then security levels
 * can be specified, where each level can have a different password. These different
 * levels are also managed by this object, which essentially needs to check that a
 * password entered is the same as the one at the specified level. This also relates
 * to the method that the calling service is trying to invoke. The service is also 
 * allowed to specify certain methods to be globally available, without any password. 
 * These are stored in the {@code globalMethods} list. 
 * <p>
 * While traversing through nested services, it is necessary to create temporary 
 * passwords to allow access to the next nested service by the invoking service only. 
 * These temporary passwords are stored in a {@code tempPasswords} list. These are created 
 * and destroyed automatically during the traversal process.
 * <p>
 * The parent service also needs to be able to store passwords to other services that it 
 * knows about, to allow it to access the other services' methods. These are stored in
 * the {@code servicePasswords} and {@code adminKeys} lists.
 * <p>
 * This class now also accepts Element URI descriptions as well as String-based IDs. The
 * element is automatically converted into its String-based equivalent and that is then used.
 * This means that it is easy to pass the full URI Handle description for any service,
 * if you want to store the password under a full description. This might be useful to
 * GUIs, for example, that connect to more than one server. note however that when asking 
 * for a password, you need to match the same key that you added it with. So if it was added
 * with a URI, the same URI needs to be entered to retrieve it.
 * @author Kieran Greer
 */
public class PasswordHandler 
{
    /** The the parent service */
    private Service service;
    
    /** A password to protect access to the parent service's methods */
    private String password;
    
    /** A password to protect access to the parent service itself */
    private String adminKey;
    
    /** A list of temporary passwords. Values are passwords of type String. */
    private List<String> tempPasswords;
    
    /** 
     * A list of global methods that do not require any password. 
     * Values are method names of type String. 
     */
    private ArrayList<String> globalMethods;
    
    /** 
     * The order of the access levels from the lowest to the highest.
     * Values are access level names of type String.
     */
    private ArrayList<String> levelOrder;
    
    /**
     * The list of passwords for the different levels.
     * Keys are access levels of type String and values are passwords of type String.
     */
    private HashMap<String, String> levelPasswords;
    
    /**
     * The methods at each level. Keys are the level names of type String and
     * values are method descriptions in XML format.
     */
    private HashMap<String, Element> levelMethods;
    
    /** 
     * A list of access levels with the groups that they belong to.
     * Keys are the access levels of type String and values are the associated
     * group names of type String.
     */
    private HashMap<String, String> levelGroups;
    
    /** 
     * Levels group information for each method.
     * Keys are the group names of type String and values are the access levels
     * in that group of type List of Strings.
     */
    private HashMap<String, ArrayList<String>> allGroups;
    
    /** 
     * Excluded levels group information for each method.
     * Keys are the access levels of type String and values are the excluded
     * access levels of type List of Strings.
     */
    private HashMap<String, ArrayList<String>> allExclude;
    
    /** 
     * A list of passwords to allow access to other services.
     * Keys are the service names of type String and values are the associated
     * passwords of type String.
     */
    private HashMap<String, String> servicePasswords;
    
    /** 
     * A list of service keys to allow admin access to other services.
     * Keys are the service names of type String and values are the associated
     * service keys of type String.
     */
    private HashMap<String, String> adminKeys;
    
    
    
    /**
     * Create a new instance of PasswordHandler. Initialise with {@link Const}.{@code ANON}
     * passwords. They might not be used.
     */
    public PasswordHandler()
    {
        initialise(Const.ANON, Const.ANON);
    }
    
    /**
     * Create a new instance of PasswordHandler.
     * @param thePassword the parent service password.
     * @param theAdminKey the parent service admin key.
     */
    public PasswordHandler(String thePassword, String theAdminKey)
    {
        initialise(thePassword, theAdminKey);
    }
    
    /**
     * Initialise some values.
     * @param thePassword the parent service password.
     * @param theAdminKey the parent service admin key.
     */
    private void initialise(String thePassword, String theAdminKey)
    {
        service = null;
        password = thePassword;
        adminKey = theAdminKey;
        tempPasswords = Collections.synchronizedList(new ArrayList<>());
        globalMethods = new ArrayList<>();
        levelOrder = new ArrayList<>();
        levelGroups = new HashMap<>();
        levelPasswords = new HashMap<>();
        levelMethods = new HashMap<>();
        allGroups = new HashMap<>();
        allExclude = new HashMap<>();
        servicePasswords = new HashMap<>();
        adminKeys = new HashMap<>();
        
        if (password == null) password = Const.ANON;
        if (adminKey == null) adminKey = Const.ANON;
    }
    
    /**
     * Reset the password values.
     * @param thePassword the service password.
     * @param theAdminKey the service key.
     */
    public void reset(String thePassword, String theAdminKey)
    {
        initialise(thePassword, theAdminKey);
    }
    
    /**
     * Remove passwords and admin keys for the specified services.
     * @param serviceIDs list of IDs for services to remove. Should be String key or Element path.
     * @throws java.lang.Exception any error.
     */
    public void remove(ArrayList<?> serviceIDs) throws Exception
    {
        int i;
        String serviceID;                           //service id
        Element serviceUri;                         //service uri
        Object nextID;                              //next id object
        
        for(i = 0; i < serviceIDs.size(); i++)
        {
            nextID = serviceIDs.get(i);
            if (nextID instanceof Element) {
                serviceUri = (Element)nextID;
                serviceID = XmlHandler.xmlToString((Element)nextID);
                servicePasswords.remove(serviceID);
                adminKeys.remove(serviceID);
                
                //also remove for uuid only
                serviceID = Handle.getLastServiceHandle(serviceUri);
            }
            else {
                serviceID = (String)nextID;
            }

            servicePasswords.remove(serviceID);
            adminKeys.remove(serviceID);
        }
    }
    
    /**
     * Remove passwords and admin keys for all services except for the specified URIs.
     * @param serviceURIs list of service URIs to keep. This must be exact and might probably
     * be the server URIs themselves. Should be String key or Element path.
     * @throws java.lang.Exception any error.
     */
    public void removeExcept(ArrayList<?> serviceURIs) throws Exception
    {
        int i;
        String serviceID;                           //service id
        ArrayList<String> passwordKeys;             //password keys
        ArrayList<String> uriList;                  //list of uris

        uriList = new ArrayList<>();
        for (i = 0; i < serviceURIs.size(); i++) {
            uriList.add(ObjectHandler.getKey(serviceURIs.get(i)));
        }
        
        passwordKeys = new ArrayList<>(servicePasswords.keySet());
        for (i = 0; i < passwordKeys.size(); i++)
        {
            serviceID = passwordKeys.get(i);
            if (!uriList.contains(serviceID)) {
                servicePasswords.remove(serviceID);
                adminKeys.remove(serviceID);
            }
        }
    }
    
    /**
     * Return true if a password is stored for the specified service uuid.
     * @param serviceUri the unique service URI.
     * @return true if a password is stored for this service.
     * @throws java.lang.Exception any error.
     */
    public boolean hasServicePassword(Element serviceUri) throws Exception
    {
        return hasServicePassword(XmlHandler.xmlToString(serviceUri));
    }

    /**
     * Return true if a password is stored for the specified service uuid.
     * @param serviceID the unique service name.
     * @return true if a password is stored for this service.
     */
    public boolean hasServicePassword(String serviceID)
    {
        try {
            getServicePassword(serviceID);
            return true;
        }
        catch (Exception ex) {
            return false;
        }
    }

    /**
     * Return true if a service key is stored for the specified service uuid.
     * @param serviceUri the unique service URI.
     * @return true if a service key is stored for this service.
     * @throws java.lang.Exception any error.
     */
    public boolean hasAdminKey(Element serviceUri) throws Exception
    {
        return hasAdminKey(XmlHandler.xmlToString(serviceUri));
    }
    
    /**
     * Return true if a service key is stored for the specified service uuid.
     * @param serviceID the unique service name.
     * @return true if a service key is stored for this service.
     */
    public boolean hasAdminKey(String serviceID)
    {
        try {
            getAdminKey(serviceID);
            return true;
        }
        catch (Exception ex) {
            return false;
        }
    }
    
    /**
     * Return true if the key passed in is the same as this service's password.
     * @param thePassword the password to check.
     * @return true if the same as this service password.
     */
    public boolean isPassword(String thePassword)
    {
        boolean canAccess;                      //true if can access
           
        canAccess = false;
        if (thePassword != null) canAccess = password.equals(thePassword);
        return canAccess;
    }
    
    /**
     * Return true if the key passed in is the same as this service's admin key.
     * @param theAdminKey the key to check.
     * @return true if the specified key is the service key.
     */
    public boolean isAdminKey(String theAdminKey)
    {
        boolean canAccess;                      //true if can access
               
        canAccess = false;
        if (theAdminKey != null) canAccess = adminKey.equals(theAdminKey);
        return canAccess;
    }
    
    /**
     * Return true if the password is the same as the password or admin key for
     * this handler's service.
     * @param thePassword the password to compare with.
     * @return true if the same as this object's password or admin key.
     */
    private boolean isPasswordOrAdminKey(String thePassword)
    {
        return (isPassword(thePassword) || isAdminKey(thePassword));
    }
    
    /**
     * Return true if the password allows the calling component to access the 
     * specified method on this component.
     * @param thePassword the password to use.
     * @param methodName the name of the method.
     * @return true if the specified password allows access to the method.
     * @throws java.lang.Exception any error.
     */
    protected boolean canAccess(String thePassword, String methodName) throws Exception
    {
        int i;
        boolean canAccess;                      //true if can access
        String nextLevel;                       //next level key
        Iterator<String> allLevels;             //all level keys
        Element accessXml;                      //access xml
        Element methodXml;                      //xml description of the method
        Vector<Node> elemList;                  //element list
        
        canAccess = false;
        
        if ((thePassword != null) && (methodName != null))
        {
            canAccess = isPasswordOrAdminKey(thePassword);        
            if (!canAccess) {
                allLevels = levelMethods.keySet().iterator();
                while (!canAccess && allLevels.hasNext())
                {
                    nextLevel = allLevels.next();
                    accessXml = levelMethods.get(nextLevel);
                    
                    elemList = accessXml.getChildren();
                    for (i = 0; !canAccess && (i < elemList.size()); i++)
                    {
                        methodXml = (Element)elemList.get(i);
                        if (methodXml.getName().equals(Const.METHOD)) {
                            if (AdminParser.getMethodName(methodXml).equals(methodName)) {
                                canAccess = canAccess(thePassword, methodName, methodXml);
                            }
                        }
                    }
                }
            }
        }
        else if (methodName == null)
        {
            throw new PasswordException("Method name should not be null.");
        }
        
        return canAccess;
    }
    
    /**
     * Return true if the password allows the calling component to access the 
     * specified method on this component.
     * @param thePassword the password to use.
     * @param methodName the name of the method.
     * @param methodXml the xml description of the method.
     * @return true if the specified password allows access to the method.
     * @throws java.lang.Exception any error.
     */
    protected boolean canAccess(String thePassword, String methodName, Element methodXml) throws Exception
    {
        int i;
        boolean canAccess;                      //true if can access at this level
        boolean isAccessLevel;                  //true if is access level
        boolean passwordFound;                  //true if the password is found
        int levelPosition;                      //the level position
        int passwordPosition;                   //the password position
        String methodLevel;                     //method access level
        String passwordLevel;                   //password access level
        String theGroup;                        //the group
        Iterator<String> levelKeys;             //level keys
        ArrayList<String> levelGroup;           //level group info
 
        
        canAccess = false;
        isAccessLevel = false;
        methodLevel = null;
        passwordLevel = null;
        
        if ((thePassword != null) && (methodXml != null))
        {
            canAccess = isPasswordOrAdminKey(thePassword);        
            if (!canAccess) {
                levelKeys = levelMethods.keySet().iterator();
                while (!isAccessLevel && levelKeys.hasNext())
                {
                    methodLevel = levelKeys.next();
                    isAccessLevel = AdminParser.isAccessLevel(levelMethods.get(methodLevel), methodXml);
                }

                if (isAccessLevel) {
                    levelPosition = -1;
                    passwordPosition = -1;

                    for (i = 0; i < levelOrder.size(); i++)
                    {
                        if (methodLevel.equals(levelOrder.get(i))) {
                            levelPosition = i;
                            break;
                        }
                    }
                    
                    passwordFound = false;
                    levelKeys = levelPasswords.keySet().iterator();
                    while (!passwordFound && levelKeys.hasNext())
                    {
                        passwordLevel = levelKeys.next();
                        if (thePassword.equals(levelPasswords.get(passwordLevel))) {
                            passwordFound = true;
                            for (i = 0; i < levelOrder.size(); i++)
                            {
                                if (passwordLevel.equals(levelOrder.get(i))) {
                                    passwordPosition = i;
                                    break;
                                }
                            }
                        }
                    }
                    
                    //the hierarchy or order applies for multiple groups as for a single group
                    if ((passwordPosition > -1) && (levelPosition > -1)) {
                        canAccess = (passwordPosition >= levelPosition);
                    }
                    
                    //still need to check group info though
                    if (canAccess) {
                        //check in same group
                        if (levelGroups.containsKey(methodLevel)) {
                            theGroup = levelGroups.get(methodLevel);
                            levelGroup = allGroups.get(theGroup);
                            
                            canAccess = ((levelGroup != null) &&
                                    levelGroup.contains(passwordLevel));
                        }
                        
                        //check not excluded
                        if (canAccess) {
                            if (allExclude.containsKey(passwordLevel)) {
                                levelGroup = allExclude.get(passwordLevel);
                                canAccess = !levelGroup.contains(methodLevel);
                            }
                        }
                    }
                }
            }
        }
        
        if (!canAccess) canAccess = isPublicMethod(methodName);       
        return canAccess;
    }
    
    /**
     * Return true if the password allows the calling component to access this component.
     * @param thePassword the password to use.
     * @return true if the specified password is the correct password or there is no password.
     */
    public boolean canAccess(String thePassword)
    {
        boolean canAccess = false;                  //true if can access
        ArrayList<String> passwords;                //level passwords
        
        if (thePassword != null)
        {
            canAccess = isPasswordOrAdminKey(thePassword);            
            if (!canAccess) {
                if (levelPasswords.size() > 0) {
                    passwords = new ArrayList<>(levelPasswords.values());
                    canAccess = passwords.contains(thePassword);
                }
            }
        }
        
        return canAccess;
    }
    
    /**
     * Return true if the password allows the calling component
     * to access this component by a temp password.
     * @param thePassword the password to use.
     * @return true if the entered password is the valid.
     */
    public boolean canAccessTemp(String thePassword)
    {
        boolean canAccess = false;                  //true if can access
        
        if (thePassword != null) {
            canAccess = tempPasswords.contains(thePassword);
        }
        
        return canAccess;
    }
    
    /**
     * Get the password for this service based on this service's key.
     * @param theAdminKey the service key.
     * @return the access password for this service.
     */
    protected String getPassword(String theAdminKey)
    {
        if (isAdminKey(theAdminKey)) {
            return getPassword();
        }
        
        return null;
    }
    
    /**
     * Get the password for the specified service.
     * @param serviceUri the unique service URI.
     * @param theAdminKey the service key.
     * @return the password for the specified service or null if it cannot be retrieved.
     * @throws java.lang.Exception any error.
     */
    protected String getPassword(Element serviceUri, String theAdminKey) throws Exception
    {
        return getPassword(XmlHandler.xmlToString(serviceUri), theAdminKey);
    }
    
    /**
     * Get the password for the specified service.
     * @param serviceID the id of the service to ask the password for.
     * @param theAdminKey the service key.
     * @return the password for the specified service or null if it cannot be retrieved.
     * @throws java.lang.Exception any error.
     */
    protected String getPassword(String serviceID, String theAdminKey) throws Exception
    {
        if (isAdminKey(theAdminKey)) {
            return getServicePassword(serviceID);
        }
        
        return null;
    }

    /**
     * Get the service password, making a remote call if necessary.
     * This method only makes a single call to the other service to try
     * and retrieve the password with default values. It assumes that the
     * other service will automatically return its password when asked (the
     * default implementation) and does not negotiate in any way.
     * If the service's password is already stored then no call in made.
     * @param serviceID the uuid of the service.
     * This should only be the uuid and not the whole serviceUri path.
     * @param serverUrl URL address of a remote server if it needs to be called.
     * Can be null for local server.
     * @return the password for the service to call.
     * @throws ServiceException probably for password or service not found.
     * @throws java.lang.Exception any error.
     */
    public String getServicePassword(String serviceID, String serverUrl)
            throws ServiceException, Exception
    {
        String servicePassword;                 //the service password key
        String serverPassword;                  //the server password
        Element serverUri;                      //server uri
        Element serviceUri;                     //service uri
        Contract contract;                      //the contract
        MethodInfo methodInfo;                  //method info
        CallObject call;                        //call object

        try {
            servicePassword = getServicePassword(serviceID);
        }
        catch (PasswordException exp) {
            if (serverUrl == null) serverUrl = LocalServer.getServerURL();
            serverUri = Handle.createNewServerHandle(serverUrl);           
            contract = Contract.getYesContract();
            
            try {
                serverPassword = getServicePassword(XmlHandler.xmlToString(serverUri));
            }
            catch (PasswordException exp2) {
                call = new CallObject();
                methodInfo = new MethodInfo();
                methodInfo.setName(MethodConst.GETPASSWORD);
                methodInfo.setRtnType(TypeConst.STRING);
                methodInfo.setServiceURI(serverUri);
                methodInfo.addParam(new ParamInfo(Const.ANON));
                methodInfo.addParam(new ParamInfo(contract));
                serverPassword = (String)call.call(methodInfo);
            }

            //if server can stop here, otherwise make another call for the service 
            serviceUri = Handle.createNewUrlHandle(serverUrl);
            serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceID));
                
            if ((serviceID.equalsIgnoreCase(Const.HTTPSERVER))) {
                servicePassword = serverPassword;
            }
            else {
                try {
                    servicePassword = getServicePassword(XmlHandler.xmlToString(serviceUri));
                }
                catch (PasswordException exp2) {
                    call = new CallObject();
                    methodInfo = new MethodInfo();
                    methodInfo.setName(MethodConst.GETPASSWORD);
                    methodInfo.setRtnType(TypeConst.STRING);
                    methodInfo.setServiceURI(serviceUri);
                    methodInfo.setServerPassword(serverPassword);
                    methodInfo.addParam(new ParamInfo(Const.ANON));
                    methodInfo.addParam(new ParamInfo(contract));
                    servicePassword = (String)call.call(methodInfo);
                }
            }
            
            if ((servicePassword != null) && !servicePassword.equals("")) {
                addServicePassword(serviceUri, servicePassword);
            }
        }

        return servicePassword;
    }

    /**
     * Add the passwords in the hashtable structure to the handler.
     * If the service key already exists do not overwrite.
     * @param allPasswords the list of passwords. Keys are the service ids of
     * type String and values are lists containing service thread state,
     * service password and service key.
     * @throws java.lang.Exception any error.
     */
    public void addPasswords(HashMap<String, ArrayList<String>> allPasswords) throws Exception
    {
        int i;
        ArrayList<Object> params;               //passwords list

        //add passwords to the password handler
        for (String serviceID: allPasswords.keySet())
        {
            params = new ArrayList<>();
            for (i = 0; i < allPasswords.get(serviceID).size(); i++) {
                params.add(ObjectHandler.getValue(allPasswords.get(serviceID).get(i)));
            }

            addServicePassword(serviceID, (String)params.get(1));
            addAdminKey(serviceID, (String)params.get(2));
        }
    }

    /**
     * Get the password associated with the specified service level.
     * @param levelID the level the password is for.
     * @return the password if it exists or null otherwise.
     */
    protected String getLevelPassword(String levelID)
    {
        String servicePassword;                 //service password

        servicePassword = null;
        if (levelPasswords.size() > 0) {
            if (levelPasswords.containsKey(levelID)) {
                servicePassword = levelPasswords.get(levelID);
            }
        }
        else {
            servicePassword = getPassword();
        }

        return servicePassword;
    }
    
    /**
     * Get the temporary passwords.
     * @return the value of tempPasswords. Values are passwords of type String.
     */
    public List<String> getTempPasswords()
    {
        return tempPasswords;
    }
    
    /**
     * Remove all passwords relating to linked or nested services.
     * @param thisAdminKey the service key for the parent service.
     */
    public void clearLinkedServicePasswords(String thisAdminKey)
    {
        if (isAdminKey(thisAdminKey)) {
            tempPasswords.clear();
            servicePasswords.clear();
            adminKeys.clear();
        }
    }
    
    /**
     * Remove all passwords relating to linked or nested services.
     * @param serviceIDs id list for service passwords to remove. Should be String key or Element path.
     * @param thisAdminKey the service key for the parent service.
     * @throws java.lang.Exception any error.
     */
    public void clearLinkedServicePasswords(ArrayList<?> serviceIDs, String thisAdminKey)
        throws Exception
    {
        String serviceID;                       //service id

        if (isAdminKey(thisAdminKey)) {
            for (Object keyObj: serviceIDs)
            {
                serviceID = ObjectHandler.getKey(keyObj);
                servicePasswords.remove(serviceID);
                adminKeys.remove(serviceID);
                tempPasswords.clear();
            }
        }
    }
    
    /**
     * Add a new password for a new service.
     * @param serviceUri the unique service URI.
     * @param servicePassword the password to access the service.
     * @return true if added or false if the service name already exists.
     * @throws java.lang.Exception any error.
     */
    public boolean addServicePassword(Element serviceUri, String servicePassword)
            throws Exception
    {
        return addServicePassword(XmlHandler.xmlToString(serviceUri), servicePassword);
    }
    
    /**
     * Add a new password for a new service.
     * @param serviceID the unique id of the service.
     * @param servicePassword the password to access the service.
     * @return true if added or false if the service name already exists.
     */
    public boolean addServicePassword(String serviceID, String servicePassword)
    {
        if ((serviceID != null) && !servicePasswords.containsKey(serviceID)) {
            servicePasswords.put(serviceID, servicePassword);
            return true;
        }
        
        return false;
    }
    
    /**
     * Remove the specified service from the password list if it exists.
     * @param serviceUri the unique service URI.
     * @throws java.lang.Exception any error.
     */
    public void removeServicePassword(Element serviceUri) throws Exception
    {
        removeServicePassword(XmlHandler.xmlToString(serviceUri));
    }
    
    /**
     * Remove the specified service from the password list if it exists.
     * @param serviceID the unique service id.
     */
    public void removeServicePassword(String serviceID)
    {
        servicePasswords.remove(serviceID);
    }
    
    /**
     * Get the password associated with the specified service.
     * @param serviceUri the unique service URI.
     * @return the password if it exists or null otherwise.
     * @throws PasswordException if no password exists.
     * @throws java.lang.Exception any other error.
     */
    public String getServicePassword(Element serviceUri) throws Exception, PasswordException
    {
        return getServicePassword(XmlHandler.xmlToString(serviceUri));
    }
    
    /**
     * Get the password associated with the specified service. Password keys are all
     * strings, but can be full handle paths or just uuids.
     * @param serviceID the unique service id.
     * @return the password if it exists or null otherwise.
     * @throws PasswordException if no password exists.
     */
    public String getServicePassword(String serviceID) throws PasswordException
    {
        String id;                              //service id
        String servicePassword;                 //service password
        
        servicePassword = passwordKey(serviceID, servicePasswords);
        if (servicePassword == null) {
            //make exception for request for local server password
            if ((serviceID.equals(Const.HTTPSERVER) && (service != null))) {
                try {
                    servicePassword = service.getServerPassword();
                } 
                catch (Exception ex) {}
            }
        }
        if (servicePassword == null) {
            try {
                id = ObjectHandler.getValue(service);
            }
            catch (Exception ex) {
                id = String.valueOf(service);
            }
            
            throw new PasswordException("No password for service " + serviceID + 
                    " in service " + id);
        }
        
        return servicePassword;
    }
    
    /**
     * Add a new service key for a new service.
     * @param serviceUri the unique service URI.
     * @param adminKey the key to access the service.
     * @return true if added or false if the service name already exists.
     * @throws java.lang.Exception any error.
     */
    public boolean addAdminKey(Element serviceUri, String adminKey) throws Exception
    {
        return addAdminKey(XmlHandler.xmlToString(serviceUri), adminKey);
    }
    
    /**
     * Add a new service key for a new service.
     * @param serviceID the unique id of the service.
     * @param adminKey the key to access the service.
     * @return true if added or false if the service name already exists.
     */
    public boolean addAdminKey(String serviceID, String adminKey)
    {
        if ((serviceID != null) && !adminKeys.containsKey(serviceID)) {
            adminKeys.put(serviceID, adminKey);
            return true;
        }
        
        return false;
    }
    
    /**
     * Remove the admin key for the specified service if it exists.
     * @param serviceUri the unique service URI.
     * @throws java.lang.Exception any error.
     */
    public void removeAdminKey(Element serviceUri) throws Exception
    {
        removeAdminKey(XmlHandler.xmlToString(serviceUri));
    }
    
    /**
     * Remove the admin key for the specified service if it exists.
     * @param serviceID the unique service id.
     */
    public void removeAdminKey(String serviceID)
    {
        adminKeys.remove(serviceID);
    }
    
    /**
     * Get the admin key associated with the specified service.
     * @param serviceUri the unique service URI.
     * @return the admin key if it exists or null otherwise.
     * @throws PasswordException if no admin key exists.
     * @throws java.lang.Exception any other error.
     */
    public String getAdminKey(Element serviceUri) throws Exception, PasswordException
    {
        return getAdminKey(XmlHandler.xmlToString(serviceUri));
    }
    
    /**
     * Get the admin key associated with the specified service.
     * @param serviceID the unique service id.
     * @return the admin key if it exists or null otherwise.
     * @throws PasswordException if no admin key exists.
     */
    public String getAdminKey(String serviceID) throws PasswordException
    {
        String id;                              //service id
        String serviceKey;                      //service key
        
        serviceKey = passwordKey(serviceID, adminKeys);
        if (serviceKey == null) {
            try {
                id = ObjectHandler.getValue(service);
            }
            catch (Exception ex) {
                id = String.valueOf(service);
            }
            
            throw new PasswordException("No admin key for service " + serviceID +
                    " in service " + id);
        }
        
        return serviceKey;
    }
    
    /**
     * Get the password or key associated with the specified service.
     * @param serviceID the unique service id.
     * @param passwords the passwords list to search.
     * @return the associated value if it exists or null otherwise.
     */
    private String passwordKey(String serviceID, HashMap<String, String> passwords)
    {
        int i;
        String serviceKey;                      //service key
        String serviceHandle;                   //service handle value
        String keyObj;                          //key object
        Element serviceUri;                     //service uri
        ArrayList<String> allKeys;              //all keys
        
        serviceKey = null;
        if (passwords.containsKey(serviceID)) {
            serviceKey = passwords.get(serviceID);
        }
        else {
            //try to compare with the service uuid only and not a whole uri
            allKeys = new ArrayList<>(passwords.keySet());
            for (i = 0; (serviceKey == null) && (i < allKeys.size()); i++)
            {
                keyObj = allKeys.get(i);
                serviceHandle = keyObj;
                
                try {
                    //try convert key from string to handle
                    serviceUri = XmlHandler.stringToElement(keyObj);
                    serviceHandle = Handle.getLastServiceHandle(serviceUri);
                }
                catch (Exception ex) {}

                try {
                    //try convert id from string to handle
                    serviceUri = XmlHandler.stringToElement(serviceID);
                    serviceID = Handle.getLastServiceHandle(serviceUri);
                }
                catch (Exception ex) {}
                
                if ((serviceHandle != null) && serviceHandle.equalsIgnoreCase(serviceID)) {
                    serviceKey = passwords.get(keyObj);
                }
            }
        }
        
        return serviceKey;
    }
    
    /**
     * Set a link to the parent service.
     * @param thisService the parent service.
     */
    protected void setService(Service thisService)
    {
        if (service == null) service = thisService;
    }
    
    /**
     * Get the password.
     * @return the value of password.
     */
    public String getPassword()
    {
        return password;
    }
    
    /**
     * Get the service key.
     * @return the value of adminKey.
     */
    public String getAdminKey()
    {
        return adminKey;
    }
    
    /**
     * Set the order of the access levels.
     * @param theLevelOrder the access levels in order from lowest to highest.
     * Values are access level names of type String.
     */
    public void setLevelOrder(ArrayList<String> theLevelOrder)
    {
        levelOrder = theLevelOrder;
    }
    
    /**
     * Set the passwords for each level.
     * @param theLevelPasswords the passwords for each level. Keys are access
     * levels of type String and values are passwords of type String.
     */
    public void setLevelPasswords(HashMap<String, String> theLevelPasswords)
    {
        levelPasswords = theLevelPasswords;
    }
    
    /**
     * Set the methods for each level.
     * @param theLevelMethods the methods for each level. Keys are the level
     * names of type String and values are method descriptions in XML format.
     */
    public void setLevelMethods(HashMap<String, Element> theLevelMethods)
    {
        levelMethods = theLevelMethods;
        
        if (levelMethods.containsKey(Const.GLOBAL)) {
            globalMethods = AdminParser.getMethodNames(levelMethods.get(Const.GLOBAL));
        }
    }
    
    /**
     * Set the groups for each level.
     * @param theLevelGroups the access levels with related groups. Keys are the 
     * access levels of type String and values are the associated group names of 
     * type String.
     */
    public void setLevelGroups(HashMap<String, String> theLevelGroups)
    {
        levelGroups = theLevelGroups;
    }
    
    /**
     * Set the level groups.
     * @param theAllGroups the groups the levels are put into. Keys are the
     * group names of type String and values are the access levels in that
     * group of type ArrayList of Strings.
     */
    public void setAllGroups(HashMap<String, ArrayList<String>> theAllGroups)
    {
        allGroups = theAllGroups;
    }
    
    /**
     * Set the excluded levels values.
     * @param theAllExclude the excluded levels values. Keys are the access
     * levels of type String and values are the excluded access levels of type
     * ArrayList of Strings.
     */
    public void setAllExclude(HashMap<String, ArrayList<String>> theAllExclude)
    {
        allExclude = theAllExclude;
    }
    
    /**
     * Return true if the method can be freely called.
     * @param methodName the name of the method.
     * @return true if the method can be freely called.
     */
    public boolean isPublicMethod(String methodName)
    {
        return globalMethods.contains(methodName);
    }
    
    /**
     * Serialize the password details into XML. Any Handle-style keys
     * are returned in a {@code shortened} form that is not XML-based.
     * @return the passwords list as an XML-based description.
     */
    public Element asXml()
    {
        String nextPassword;                    //next password
        String nextServiceKey;                  //next service key
        Element passwordsElem;                  //passwords element
        Element nextElem;                       //next element
        Element nextElem2;                      //next element
        
        passwordsElem = XMLFactory.getInstance().createElement(Const.PASSWORDS);
        
        for (String key: servicePasswords.keySet())
        {
            nextPassword = servicePasswords.get(key);
            nextServiceKey = adminKeys.getOrDefault(key, null);
                
            try {
                nextElem = XmlHandler.stringToElement(key);
                key = Handle.toShort(nextElem);
            }
            catch (Exception ex) {}
            
            nextElem = XMLFactory.getInstance().createElement(Const.NEXTPASSWORDS);
            nextElem.setAttribute(Const.UUID, key);
            passwordsElem.addContent(nextElem);
            
            nextElem2 = XMLFactory.getInstance().createElement(MetaConst.PASSWORD);
            nextElem2.setText(nextPassword);
            nextElem.addContent(nextElem2);
            
            if (nextServiceKey != null) {
                nextElem2 = XMLFactory.getInstance().createElement(Const.SERVICEKEY);
                nextElem2.setText(nextServiceKey);
                nextElem.addContent(nextElem2);
            }
        }
        
        return passwordsElem;
    }
    
    /**
     * Serialize the password details into XML. Any Handle-style keys
     * are returned in a {@code full} form includes XML-based elements.
     * @return the passwords list as an XML-based description.
     * @throws java.lang.Exception any error.
     */
    public Element toXml() throws Exception
    {
        String nextPassword;                    //next password
        String nextServiceKey;                  //next service key
        Element passwordsElem;                  //passwords element
        Element nextElem;                       //next element
        Element nextElem2;                      //next element
        
        passwordsElem = XMLFactory.getInstance().createElement(Const.PASSWORDS);

        for (String key: servicePasswords.keySet())
        {
            nextPassword = servicePasswords.get(key);
            nextServiceKey = adminKeys.getOrDefault(key, null);
                
            try {
                nextElem = XmlHandler.stringToElement(key);
                key = XmlHandler.xmlToString(nextElem);
            }
            catch (Exception ex) {}
            
            nextElem = XMLFactory.getInstance().createElement(Const.NEXTPASSWORDS);
            nextElem.setAttribute(Const.UUID, key);
            passwordsElem.addContent(nextElem);
            
            nextElem2 = XMLFactory.getInstance().createElement(MetaConst.PASSWORD);
            nextElem2.setText(nextPassword);
            nextElem.addContent(nextElem2);
            
            if (nextServiceKey != null) {
                nextElem2 = XMLFactory.getInstance().createElement(Const.SERVICEKEY);
                nextElem2.setText(nextServiceKey);
                nextElem.addContent(nextElem2);
            }
        }
        
        return passwordsElem;
    }
    
    /**
     * Parse the XML-based description of passwords and add to this password handler.
     * @param passwordsXml an xml-based description, probably created using {@code toXml}.
     */
    public void fromXml(Element passwordsXml)
    {
        int i;
        String nextKey;                         //next key
        String nextPassword;                    //next password
        String nextServiceKey;                  //next service key
        Element nextElem;                       //next element
        Element nextElem2;                      //next element
        Vector<Node> elemList;                  //element list
        
        elemList = passwordsXml.getChildren();
        for (i = 0; i < elemList.size(); i++)
        {
            nextElem = (Element)elemList.get(i);
            if (nextElem.getName().equals(Const.NEXTPASSWORDS)) {
                nextKey = XmlHtmlHandler.decodeXml(nextElem.getAttributeValue(Const.UUID));
                
                nextElem2 = nextElem.getChild(MetaConst.PASSWORD);
                if (nextElem2 != null) {
                    nextPassword = nextElem2.getText();
                    addServicePassword(nextKey, nextPassword);
                }
                nextElem2 = nextElem.getChild(Const.SERVICEKEY);
                if (nextElem2 != null) {
                    nextServiceKey = nextElem2.getText();
                    addAdminKey(nextKey, nextServiceKey);
                }
            }
        }
    }
    
    /**
     * Get a new password.
     * @return a new unique password.
     * @throws java.lang.Exception any error.
     */
    public static String getNewPassword() throws Exception
    {
        return UuidHandler.getUuid(15, System.currentTimeMillis());
    }
}
