/*
 * MessageStore.java
 *
 * Created on 8 April 2016
 *
 * Version 1.0.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas;


import org.jlog2.*;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * Stores information on earlier invoked or transitional method processes. 
 * @author Kieran Greer
 */
public class MessageStore
{
    /** The logger */
    private static final Logger logger;
    
    
    /** 
     * Communication IDs to identify the calling components.
     * Keys are the communication ids and values are the calling
     * component's uris, as Objects in MessageInfo containers.
     */
    private final HashMap<String, Object> communicationIDs;
    
    /**
     * List of reply IDs in transit, or not completed yet. Of type String.
     */
    private final ArrayList<String> transitReplies;
    
    /** 
     * Stored replies to earlier method invocations.
     * Keys are the reply ids and values are the result of executing the method.
     */
    private final HashMap<String, Object> savedReplies;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(MessageStore.class.getName());
        logger.setDebug(false);
    }
    
    
    /**
     * Create a new instance of MessageStore.
     */
    public MessageStore()
    {
        communicationIDs = new HashMap<>();
        transitReplies = new ArrayList<>();
        savedReplies = new HashMap<>();
    }
    
    
    /**
     * Return true if the communication ID is saved.
     * @param commID the id to check for.
     * @return true if communicationIDs contains it, false otherwise.
     */
    public boolean hasCommID(String commID)
    {
        return communicationIDs.containsKey(commID);
    }
    
    /**
     * Return true if the method reply has been registered and/or may have completed.
     * @param replyID the id to check for.
     * @return true if transitReplies or savedReplies contains it, false otherwise.
     */
    public boolean inTransit(String replyID)
    {
        return transitReplies.contains(replyID);
    } 
    
    /**
     * Return true if the method reply is saved.
     * @param replyID the id to check for.
     * @return true if savedReplies contains it, false otherwise.
     */
    public boolean hasSavedReply(String replyID)
    {
        return savedReplies.containsKey(replyID);
    } 
    
    /**
     * Get the list of current communication IDs.
     * @return the key set to communicationIDs.
     */
    public ArrayList<String> getCommIDs()
    {
        return new ArrayList(communicationIDs.keySet());
    }
    
    /**
     * Get the list of current reply IDs.
     * @return the key set to savedReplies.
     */
    public ArrayList<String> getReplyIDs()
    {
        return new ArrayList(savedReplies.keySet());
    }
    
    
    /**
     * Add a communication id with its related client reference.
     * @param commID a unique comm id for the client.
     * @param messageInfo the client reference - URI or other. Can also be timestamped.
     */
    public void addCommID(String commID, MessageInfo messageInfo)
    {
        communicationIDs.put(commID, messageInfo);
    }
    
    /**
     * Remove the communication ID from the stored list.
     * @param commID the id to remove.
     */
    public void removeCommID(String commID)
    {
        communicationIDs.remove(commID);
    }
    
    /**
     * Get the client message info for the communication id.
     * @param commID the id to check for.
     * @return a stored messageInfo with the client reference, or null if one does not exist.
     */
    public MessageInfo getCommClient(String commID)
    {
        if (communicationIDs.containsKey(commID))
        {
            return (MessageInfo)communicationIDs.get(commID);
        }
        
        return null;
    }
    
    /**
     * Add a reply id with its related method reply.
     * @param replyID a unique reply id for the client.
     * @param reply the reply object to store.
     */
    public void addSavedReply(String replyID, Object reply)
    {
        MessageInfo messageInfo;                //message info
        
        if (!(reply instanceof MessageInfo))
        {
            messageInfo = new MessageInfo(replyID, reply);
            reply = messageInfo;
        }

        savedReplies.put(replyID, reply);
    }
    
    /**
     * Add a reply id to indicate that it has been registered, but not necessarily
     * completed execution yet.
     * @param replyID a unique reply id for the client.
     */
    public void addMethodTransit(String replyID)
    {
        if (!transitReplies.contains(replyID))
        {
            transitReplies.add(replyID);
        }
    }
    
    /**
     * Remove the reply ID from the registered and stored lists, plus any stored object.
     * @param replyID the id to remove.
     */
    public void removeReplyID(String replyID)
    {
        transitReplies.remove(replyID);
        savedReplies.remove(replyID);
    }
    
    /**
     * Get and remove the reply object for the reply id.
     * @param replyID the id to check for.
     * @return a stored method reply, or null if one does not exist.
     */
    public MessageInfo getSavedReply(String replyID)
    {
        Object replyObj;                        //reply object
        MessageInfo messageInfo;                //reply message

        messageInfo = null;
        if (savedReplies.containsKey(replyID))
        {
            transitReplies.remove(replyID);
            replyObj = savedReplies.remove(replyID);

            if (replyObj instanceof MessageInfo) {
                messageInfo = (MessageInfo)replyObj;
            }
            else {
                messageInfo = new MessageInfo(replyObj);
            }
        }
        
        return messageInfo;
    }
}
