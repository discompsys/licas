/*
 * ServiceInfo.java
 *
 * Created on 24 April 2007
 *
 * Version 1.3.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas;


import org.licas.def.ServiceWrapperDef;
import org.licas.service.model.WorkInfo;
import org.licas_xml.abs.Element;
import org.jlog2.*;


/**
 * This class stores information relating to a single service. It is used when adding
 * a service to another one, internally by the system and is not required for external use.
 * @author Kieran Greer
 */
public class ServiceInfo 
{
    /** The logger */
    private static final Logger logger;


    /** A name used to define the service */
    private final String name;
    
    /** The service type */
    private final String serviceType;
    
    /** The full path to the service */
    private Element servicePath;
    
    /** A description of the service in XML format */
    private Element description;

    /** Description of the allowed work protocol */
    private final WorkInfo workInfo;

    /** The service */
    private final ServiceWrapperDef service;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServiceInfo.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Creates a new instance of ServiceInfo.
     * @param thisName the name to define the service.
     * @param thisServiceType the service type.
     * @param thisDescription the description. Can be {@code null}.
     * @param thisWorkInfo the allowed work protocol.
     * @param thisService the service wrapper.
     */
    public ServiceInfo(String thisName, String thisServiceType, Element thisDescription,
                       WorkInfo thisWorkInfo, ServiceWrapperDef thisService)
    {
        name = thisName;
        serviceType = thisServiceType;
        description = thisDescription;
        workInfo = thisWorkInfo;
        service = thisService;
        servicePath = null;
    }
    
    /**
     * Return the name of the service.
     * @return the value of name.
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Return the type of the service.
     * @return the value of serviceType.
     */
    public String getServiceType()
    {
        return serviceType;
    }
    
    /**
     * Set the service path.
     * @param theServicePath the full path to the service.
     */
    public void setServicePath(Element theServicePath)
    {
        servicePath = theServicePath;
    }

    /**
     * Get the full service path.
     * @return the value of servicePath.
     */
    public Element getServicePath()
    {
        return servicePath;
    }
    
    /**
     * Set the description value.
     * @param theDescription the description of the service.
     */
    public void setDescription(Element theDescription)
    {
        description = theDescription;
    }
    
    /**
     * Get the description value.
     * @return the value of description.
     */
    public Element getDescription()
    {
        return description;
    }

    /**
     * Get the work protocol description.
     * @return the value of workInfo.
     */
    public WorkInfo getWorkInfo() { return workInfo; }

    /**
     * Return the service itself.
     * @return the value of service.
     */
    public ServiceWrapperDef getService()
    {
        return service;
    }
    
    /**
     * Get a limited clone of this object.
     * @return a clone of this object without the service object itself.
     */
    public ServiceInfo cloneNoService()
    {
        Element descrClone;                 //clone of the description
        ServiceInfo serviceInfo;            //clone info
        
        if (description != null)
            descrClone = (Element)description.clone();
        else
            descrClone = null;
        
        serviceInfo = new ServiceInfo(name, serviceType, descrClone, null, null);
        serviceInfo.setServicePath((Element)servicePath.clone());
    
        return serviceInfo;
    }
}
