/*
 * AdminInfo.java
 *
 * Created on 18 January 2009
 *
 * Version 1.10
 *
 * Copyright (c) Kieran Greer
 */

package org.licas;


import org.licas.parsers.admin.AutonomicManagerParser;
import org.licas.util.*;
import org.licas_xml.abs.Element;

import java.util.*;


/**
 * This class stores information created by the administrator of the service. The service can be initialised
 * with an XML document that describe aspects of its service and data, including how to configure the AI aspects
 * and provide levels of security. If considering security, then each service is accessed through method invocation,
 * but each method can be protected by a password. Security levels can be specified, with methods defined at each level.
 * The administrator can also specify contracts and policy scripts for the service. A contract can be used to specify
 * the conditions that must be agreed upon for the service (or method) to be invoked. Some of the metadata that the
 * system uses is generated automatically. For example, the method descriptions are read from the service class type,
 * using {@code Reflection}. These descriptions can then be overridden by the service initialisation admin document,
 * if different security levels are required.
 * <p>
 * Data is read as the first nested element under the {@code Data} tag name. The {@code Other_Meta} tag is recognised
 * as a slot for other metadata and the {@code Policy} tag is recognised as a slot for an autonomous service's policy
 * or control script. This optional metadata is added to the {@code additional} hash list, as separate XML elements with
 * optional keywords. These XML elements can then be retrieved from the 'additional' hash list directly, by using the
 * appropriate key. See the admin user guide for further details.
 * @author Kieran Greer
 */
public class AdminInfo 
{
    /** The service uuid that this admin info relates to */
    private String uuid;

    /** The type of the related service */
    private String type;
    
    /** Optional category that the service belongs to */
    private String category;
    
    /** Optional file path for the admin document that created this info */
    private String adminFile;

    /**
     * True if access to service metadata is allowed, false if it is blocked.
     * The default value is true.
     */
    private boolean metaAccessAllowed;
    
    /**
     * True if access to nested services is allowed, false if it is blocked. Access
     * to nested services means that any service objects that are stored or nested
     * inside of the service this admin relates to can be accessed through that one if 
     * the correct password is used. If this is set to false, then they cannot be accessed 
     * at all, with any password. These nested services could typically be utility services 
     * that perform certain actions for the parent service only and so allowing access to them
     * might not be suitable. The default value is true.
     */
    private boolean nestedAccessAllowed;

    /** 
     * The description of the service. This is a general XML-based description of
     * what the service does.
     */
    private Element description;

    /**
     * The description of the autonomic manager configuration. This is a section of
     * the admin document that describes what autonomous modules to load, where 
     * the classes are to load them and the policy documents to initialise them with.
     * This section is read as is from the admin document and then passed to the
     * {@link AutonomicManagerParser}, which then parses it and creates the autonomic manager
     * with the correct monitoring modules.
     */
    private Element autoManConfig;

    /** 
     * The description of the service level contracts. This is a section of the
     * admin document that describes the contracts that must be agreed upon before
     * the service can be used. This document section would be passed to a
     * {@link ContractManager} that would parse it to create {@link ServiceLevel} objects that
     * describe the contract terms for each access level in the service.
     */
    private Element serviceLevelAdmin;

    /** 
     * Description of services to create and load onto the parent service of this one. 
     */
    private Element loadServices;
    
    /** 
     * Variable instance value descriptions. The first element should include the
     * field name as an attribute and the nested sequence should be parsed into
     * the variable by an already registered parser.
     */
    private Element instanceValues;
    
    /** 
     * Serialize instance value descriptions. The first element should include the
     * field name as an attribute and the nested sequence should be parsed into
     * the variable by an already registered parser. If no nested elements, then
     * retrieve the variable from the name and serialize.
     */
    private Element serializeValues;
    
    /** 
     * The order of the levels. Each security access level has a label or name
     * and is also ordered. This list stores the correct order. The values are 
     * the level names, of type String. 
     */
    private ArrayList<String> levelOrder;
    
    /** 
     * The passwords for each access level.
     * Keys are the level names of type String and values are the access
     * passwords of type String.
     */
    private HashMap<String, String> levelPasswords;
    
    /** 
     * Access levels information for each method.
     * Keys are the access levels of type String and values are descriptions
     * of the methods at each level of type Element.
     */
    private HashMap<String, Element> accessLevels;
    
    /** 
     * A list of access levels with the groups that they belong to.
     * Keys are the access levels of type String and values are the associated 
     * group names of type String.
     */
    private HashMap<String, String> levelGroups;
    
    /** 
     * Levels group information for each method.
     * Keys are the group names of type String and values are the access levels
     * in that group of type ArrayList of Strings.
     */
    private HashMap<String, ArrayList<String>> allGroups;
    
    /** 
     * Excluded levels group information for each method.
     * Keys are the access levels of type String and values are the excluded
     * access levels of type ArrayList of Strings.
     */
    private HashMap<String, ArrayList<String>> allExclude;
    
    /**
     * List of additional XML sections. These are indexed by the first element name
     * and stored as separate elements. They might not be processed in a default service class,
     * but might be recognised by other standard derived classes, for example the {@code Event} element.
     */
    protected HashMap<String, Element> additional;
    
    
    /**
     * Create a new instance of AdminInfo.
     */
    public AdminInfo()
    {
        initialise();
    }
    
    /**
     * Initialise some values.
     */
    private void initialise()
    {
        uuid = null;
        type = null;
        category = null;
        adminFile = null;
        metaAccessAllowed = true;
        nestedAccessAllowed = true;
        description = null;
        autoManConfig = null;
        serviceLevelAdmin = null;
        loadServices = null;
        instanceValues = null;
        serializeValues = null;
        levelOrder = new ArrayList<>();
        levelPasswords = new HashMap<>();
        levelGroups = new HashMap<>();
        accessLevels = new HashMap<>();
        allGroups = new HashMap<>();
        allExclude = new HashMap<>();
        additional = new HashMap<>();
    }
    
    /**
     * Return true if the access level exists.
     * @param levelKey the access level key.
     * @return true if an access level with the key name exists.
     */
    public boolean hasAccessLevel(String levelKey)
    {
        return ((accessLevels != null) && accessLevels.containsKey(levelKey));
    }
    
    /**
     * Set the file path for the admin xml file.
     * @param thisAdminFile the admin document file path.
     */
    public void setAdminFilePath(String thisAdminFile)
    {
        adminFile = thisAdminFile;
    }
    
    /**
     * Get the file path for the admin xml file.
     * @return the value of adminFile.
     */
    public String getAdminFilePath()
    {
        return adminFile;
    }
    
    /**
     * Set the service uuid.
     * @param theUuid the service uuid.
     */
    public void setUuid(String theUuid)
    {
        uuid = theUuid;
    }

    /**
     * Get the service uuid.
     * @return the value of uuid.
     */
    public String getUuid()
    {
        return uuid;
    }

    /**
     * Set the service type.
     * @param theType the service type.
     */
    public void setType(String theType)
    {
        type = theType;
    }
    
    /**
     * Get the service type.
     * @return the value of type.
     */
    public String getType()
    {
        return type;
    }
    
    /**
     * Set the service category.
     * @param theCategory the service category.
     */
    public void setCategory(String theCategory)
    {
        category = theCategory;
    }
    
    /**
     * Get the service category.
     * @return the value of category.
     */
    public String getCategory()
    {
        return category;
    }

    /**
     * Set the values indicating if access to service metadata is allowed or blocked.
     * @param thisMetaAccessAllowed if true access is allowed but still requires the password.
     * If false access is blocked for any condition.
     */
    public void setMetaAccessAllowed(boolean thisMetaAccessAllowed)
    {
        metaAccessAllowed = thisMetaAccessAllowed;
    }

    /**
     * Get the value indicating if access to the service metadata is allowed.
     * @return true access is allowed but still requires the password,
     * or false access is blocked for any condition.
     */
    public boolean getMetaAccessAllowed()
    {
        return metaAccessAllowed;
    }
    
    /**
     * Set the values indicating if access to nested services is allowed or blocked.
     * @param thisNestedAccessAllowed if true access is allowed but still requires the password.
     * If false access is blocked for any condition.
     */
    public void setNestedAccessAllowed(boolean thisNestedAccessAllowed)
    {
        nestedAccessAllowed = thisNestedAccessAllowed;
    }

    /**
     * Get the value indicating if access to the nested services is allowed.
     * @return true access is allowed but still requires the password,
     * or false access is blocked for any condition.
     */
    public boolean getNestedAccessAllowed()
    {
        return nestedAccessAllowed;
    }

    /**
     * Set the description value.
     * @param theDescription the description of the service.
     */
    public void setDescription(Element theDescription)
    {
        description = theDescription;
    }

    /**
     * Get the description value.
     * @return the value of description.
     */
    public Element getDescription()
    {
        return description;
    }

    /**
     * Set the configuration description for the autonomic manager.
     * @param theAutoManAdmin the description of the autonomic manager config.
     */
    public void setAutonomicManagerAdmin(Element theAutoManAdmin)
    {
        autoManConfig = theAutoManAdmin;
    }

    /**
     * Get the configuration description for the autonomic manager.
     * @return the value of autoManAdmin.
     */
    public Element getAutonomicManagerAdmin()
    {
        return autoManConfig;
    }

    /**
     * Set the service level agreements value.
     * @param theServiceLevelAdmin the description of the service levels.
     */
    public void setServiceLevelContracts(Element theServiceLevelAdmin)
    {
        serviceLevelAdmin = theServiceLevelAdmin;
    }

    /**
     * Get the service level contracts value.
     * @return the value of serviceLevelAdmin.
     */
    public Element getServicelevelContracts()
    {
        return serviceLevelAdmin;
    }
    
    /**
     * Set the services to load value.
     * @param theLoadServices the metadata related to the services to load.
     */
    public void setLoadServices(Element theLoadServices)
    {
        loadServices = theLoadServices;
    }

    /**
     * Get the metadata defining the services to load.
     * @return the value of loadServices.
     */
    public Element getLoadServices()
    {
        return loadServices;
    }

    /**
     * Set the data value.
     * @param dataXml the service data.
     * @throws java.lang.Exception any error.
     */
    public void setData(Element dataXml) throws Exception
    {
        additional.put(Const.DATA, dataXml);
    }

    /**
     * Get the data value.
     * @return the value of data.
     */
    public Element getData()
    {
        return additional.get(Const.DATA);
    }

    /**
     * Set the additional other metadata values.
     * @param otherMetaXml the additional metadata not included as default.
     */
    public void setOtherMeta(Element otherMetaXml)
    {
        additional.put(Const.OTHERMETA, otherMetaXml);
    }

    /**
     * Get the metadata specific to this service.
     * @return the value of meta.
     */
    public Element getOtherMeta()
    {
        return additional.get(Const.OTHERMETA);
    }

    /**
     * Additional metadata elements not necessarily processed directly in the base services.
     * @return the value of additional.
     */
    public HashMap<String, Element> getAdditional()
    {
        return additional;
    }
    
    /**
     * Set the variable instance values script.
     * @param theInstanceValues description of actual variable instance values.
     */
    public void setInstanceValues(Element theInstanceValues)
    {
        instanceValues = theInstanceValues;
    }
    
    /**
     * Get the variable instance values script.
     * @return the value of instanceValues.
     */
    public Element getInstanceValues()
    {
        return instanceValues;
    }
    
    /**
     * Set the variable serialize values script.
     * @param theSerializeValues description of actual variable serialize values.
     */
    public void setSeializeValues(Element theSerializeValues)
    {
        serializeValues = theSerializeValues;
    }
    
    /**
     * Get the variable serialize values script.
     * @return the value of serializeValues.
     */
    public Element getSerializeValues()
    {
        return serializeValues;
    }
    
    /**
     * Add another level to the end of the list.
     * @param theLevel the name of the access level to add.
     * @return true if added or false if it already exists. 
     */
    public boolean addLevelOrder(String theLevel)
    {
        if (!levelOrder.contains(theLevel))
        {
            levelOrder.add(theLevel);
            return true;
        }
        
        return false;
    }
    
    /**
     * Set the level order.
     * @param theLevelOrder the level order. Values are level names of type String.
     */
    public void setLevelOrder(ArrayList<String> theLevelOrder)
    {
        levelOrder = theLevelOrder;
    }
    
    /**
     * Get the level order.
     * @return the value of levelOrder. Values are level names of type String.
     */
    public ArrayList<String> getLevelOrder()
    {
        return levelOrder;
    }
    
    /**
     * Store the level passwords with the level names.
     * @param theLevelPasswords the passwords for each level. Keys are the
     * level names of type String and values are the access passwords of type String.
     */
    public void setLevelPasswords(HashMap<String, String> theLevelPasswords)
    {
        levelPasswords = theLevelPasswords;
    }
    
    /**
     * Get the passwords stored for each access level.
     * @return the value of levelPasswords. Keys are the level names of type
     * String and values are the access passwords of type String.
     */
    public HashMap<String, String> getLevelPasswords()
    {
        return levelPasswords;
    }
    
    /**
     * Set the method access levels.
     * @param theAccessLevels the access levels for each method. Keys are the
     * access levels of type String and values are descriptions of the methods
     * at each level of type String.
     */
    public void setAccessLevels(HashMap<String, Element> theAccessLevels)
    {
        accessLevels = theAccessLevels;
    }
    
    /**
     * Get the access levels for each method.
     * @return the value of accessLevels. Keys are the access levels of type
     * String and values are descriptions of the methods at each level of type String.
     */
    public HashMap<String, Element> getAccessLevels()
    {
        return accessLevels;
    }
    
    /**
     * Set the groups for each level.
     * @param theLevelGroups the access levels with related groups. Keys are the 
     * access levels of type String and values are the associated group names of 
     * type String.
     */
    public void setLevelGroups(HashMap<String, String> theLevelGroups)
    {
        levelGroups = theLevelGroups;
    }
    
    /**
     * Get the access levels with related groups.
     * @return the value of levelGroups. Keys are the access levels of type String 
     * and values are the associated group names of type String.
     */
    public HashMap<String, String> getLevelGroups()
    {
        return levelGroups;
    }
    
    /**
     * Set the level groups.
     * @param theAllGroups the groups the levels are put into. Keys are the
     * group names of type String and values are the access levels in that group
     * of type ArrayList of Strings.
     */
    public void setAllGroups(HashMap<String, ArrayList<String>> theAllGroups)
    {
        allGroups = theAllGroups;
    }
    
    /**
     * Get the groups the levels are put into.
     * @return the value of allGroups. Keys are the group names of type String
     * and values are the access levels in that group of type ArrayList of Strings.
     */
    public HashMap<String, ArrayList<String>> getAllGroups()
    {
        return allGroups;
    }
    
    /**
     * Set the excluded levels values.
     * @param theAllExclude the excluded levels values. Keys are the access
     * levels of type String and values are the excluded access levels of type
     * ArrayList of Strings.
     */
    public void setAllExclude(HashMap<String, ArrayList<String>> theAllExclude)
    {
        allExclude = theAllExclude;
    }
    
    /**
     * Get the excluded levels values.
     * @return the value of allExclude. Keys are the access levels of type
     * String and values are the excluded access levels of type ArrayList of Strings.
     */
    public HashMap<String, ArrayList<String>> getAllExclude()
    {
        return allExclude;
    }
    
    /**
     * Return a cloned copy of this admin info object.
     * @return a copy of this object with each structure cloned.
     */
    public AdminInfo cloneAdminInfo()
    {
        int i;
        ArrayList<String> cloneLevelOrder;                  //cloned levels order
        ArrayList<String> groupList;                        //group list
        ArrayList<String> cloneGroupList;                   //cloned group list
        HashMap<String, String> cloneLevelPasswords;        //cloned level passwords
        HashMap<String, String> cloneLevelGroups;           //cloned level groups
        HashMap<String, Element> cloneAccessLevels;         //cloned access levels
        HashMap<String, ArrayList<String>> cloneAllGroups;  //cloned all groups
        HashMap<String, ArrayList<String>> cloneAllExclude; //cloned group exclusions
        AdminInfo cloneAdminInfo;                           //cloned admin info
        
        cloneAdminInfo = new AdminInfo();
        cloneAdminInfo.uuid = uuid;
        cloneAdminInfo.type = type;
        cloneAdminInfo.nestedAccessAllowed = nestedAccessAllowed;
        
        if (description != null)
            cloneAdminInfo.description = (Element)description.clone();
        if (autoManConfig != null)
            cloneAdminInfo.autoManConfig = (Element)autoManConfig.clone();
        if (serviceLevelAdmin != null)
            cloneAdminInfo.serviceLevelAdmin = (Element)serviceLevelAdmin.clone();
        if (additional != null)
            cloneAdminInfo.getAdditional().putAll((HashMap)additional.clone());
        
        cloneLevelOrder = new ArrayList<>();
        for (i = 0; i < levelOrder.size(); i++)
        {
            cloneLevelOrder.add(levelOrder.get(i));
        }
        
        cloneAdminInfo.levelOrder = cloneLevelOrder;
        cloneLevelPasswords = new HashMap<>();
        
        for (String key : levelPasswords.keySet())
        {
            cloneLevelPasswords.put(key, levelPasswords.get(key));
        }
        
        cloneAdminInfo.levelPasswords = cloneLevelPasswords;
        cloneLevelGroups = new HashMap<>();
        
        for (String key : levelGroups.keySet())
        {
            cloneLevelGroups.put(key, levelGroups.get(key));
        }
        
        cloneAdminInfo.levelGroups = cloneLevelGroups;
        cloneAccessLevels = new HashMap<>();
        
        for (String key : accessLevels.keySet())
        {
            cloneAccessLevels.put(key, (Element)accessLevels.get(key).clone());
        }
        
        cloneAdminInfo.accessLevels = cloneAccessLevels;
        cloneAllGroups = new HashMap<>();
        
        for (String key : allGroups.keySet())
        {
            groupList = allGroups.get(key);
            cloneGroupList = new ArrayList<>();
            
            for (i = 0; i < groupList.size(); i++)
            {
                cloneGroupList.add(groupList.get(i));
            }
            
            cloneAllGroups.put(key, cloneGroupList);
        }
        
        cloneAdminInfo.allGroups = cloneAllGroups;
        cloneAllExclude = new HashMap<>();
        
        for (String key : allExclude.keySet())
        {
            groupList = allExclude.get(key);
            cloneGroupList = new ArrayList<>();
            
            for (i = 0; i < groupList.size(); i++)
            {
                cloneGroupList.add(groupList.get(i));
            }
            
            cloneAllExclude.put(key, cloneGroupList);
        }
        
        cloneAdminInfo.allExclude = cloneAllExclude;
        
        return cloneAdminInfo;
    }
    
    /**
     * Return true if the element name is a recognised admin tag name that gets processed
     * and stored in the default classes. Additional tags like {@code Event} is not recognised.
     * @param elementName the name of the element.
     * @return true if it is recognised as an admin element.
     */
    public static boolean isDistinctAdminTag(String elementName)
    {
        ArrayList<String> tagNames;                 //list of tag names
        
        tagNames = getDistinctAdminTagNames();
        return tagNames.contains(elementName);
    }
    
    /**
     * Get a list of element names that are recognised as distinct script types.
     * @return a list of element tag names. Additional tags like {@code Event} is not returned.
     */
    public static ArrayList<String> getDistinctAdminTagNames()
    {
        ArrayList<String> tagNames;                 //list of tag names
        
        tagNames = new ArrayList<>();
        tagNames.add(MetaConst.ADMIN);
        tagNames.add(MetaConst.SERVICEMETA);
        tagNames.add(Const.UUID);
        tagNames.add(Const.SERVICETYPE);
        tagNames.add(Const.CLASSNAME);
        tagNames.add(Const.HANDLE);
        tagNames.add(Const.CONSTRUCTORS);
        tagNames.add(Const.METHODS);
        tagNames.add(Const.SERVICECATEGORY);
        tagNames.add(Const.SERVICEPASSWORD);
        tagNames.add(Const.SERVICEKEY);
        tagNames.add(Const.SERVICESTATE);
        tagNames.add(Const.NESTEDACCESSALLOWED);
        tagNames.add(Const.METAACCESSALLOWED);
        tagNames.add(Const.PASSWORDS);
        tagNames.add(Const.DESCRIPTION);
        tagNames.add(Const.KEYWORDS);
        tagNames.add(MetaConst.WORKINFO);
        tagNames.add(MetaConst.CHILDSERVICEMETA);
        tagNames.add(Const.SERVICES);
        tagNames.add(Const.SERVICESTOLOAD);
        tagNames.add(Const.ACCESSLEVEL);
        tagNames.add(Const.LEVELTYPE);
        tagNames.add(Const.GLOBAL);
        tagNames.add(Const.GROUP);
        tagNames.add(Const.NAME);
        tagNames.add(Const.EXCLUDE);
        tagNames.add(MetaConst.SERVICELEVELCONTRACTS);
        tagNames.add(AiConst.AUTONOMICMANAGER);
        tagNames.add(Const.INSTANCEVALUES);
        tagNames.add(Const.LINKS);
        
        return tagNames;
    }
}
