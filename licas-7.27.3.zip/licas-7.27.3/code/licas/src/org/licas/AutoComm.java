/*
 * ModuleComm.java
 *
 * Created on 1 October 2019
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas;


import org.licas.autonomic.script.AutoEngine;

/**
 * Communication bridge between protected {@link Auto} methods and other packages.
 * @author Kieran Greer
 */
public class AutoComm
{
    /**
     * Execute a behaviour, such as an evaluation and result.
     * @param messageInfo the message to evaluate.
     * @param auto direct reference to the auto to invoke.
     * @return the result of any subsequent behaviour event.
     * @throws java.lang.Exception any error.
     */
    public MessageInfo behaviourAction(MessageInfo messageInfo, Auto auto) throws Exception
    {
       return auto.behaviourAction(messageInfo);
    }

    /**
     * Get the auto engine.
     * @param auto direct reference to the auto to invoke.
     * @return the value of autoEngine.
     */
    public AutoEngine getAutoEngine(Auto auto)
    {
        return auto.autoEngine;
    }
}
