/*
 * JarFactory.java
 *
 * Created on 26 April 2012
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service;


import org.licas.util.FileObject;

import java.util.ArrayList;


/**
 * This class controls the local or remote handling of jar files by the server.
 * @author Kieran Greer
 */
public abstract class JarFactory
{
    /** A key to allow changes to the service factory */
    private static String factoryKey = null;
    
    /** Single instance of the factory that is used to process all method calls */
    private static JarFactory jarFactory = null;

    /**
     * Get the created instance of the jar factory.
     * @return the value of jarFactory.
     */
    public static JarFactory getInstance()
    {
        return jarFactory;
    }

    /**
     * Set the instance of the jar factory to be used. This can be set if either:
     * the jar factory is currently null, or the factory key is correct. This will
     * also set the factory key value for the initial (if null) assignment.
     * @param thisJarFactory the jar factory that is retrieved for any method call.
     * @param thisFactoryKey a key to protect dynamic changing of the factory.
     */
    public static void setJarFactory(JarFactory thisJarFactory, String thisFactoryKey)
    {
        if (jarFactory == null) {
            jarFactory = thisJarFactory;
            factoryKey = thisFactoryKey;
        }
        else {
            if ((factoryKey != null) && factoryKey.equals(thisFactoryKey)) {
                jarFactory = thisJarFactory;
            }
        }
    }
    
    /**
     * Remove the current jar factory by re-setting it to null.
     * @param thisFactoryKey a key to protect dynamic changing of the factory.
     */
    public static void removeJarFactory(String thisFactoryKey)
    {
        if (jarFactory != null) {
            if ((factoryKey != null) && factoryKey.equals(thisFactoryKey)) {
                jarFactory = null;
            }
        }
    }
    
    /**
     * Get the list of all jar files in the services folder.
     * @return the list of all jar filenames in the services folder.
     * @throws java.lang.Exception any error.
     */
    public abstract ArrayList<String> getServiceJars() throws Exception;
    
    /**
     * Get the list of all jar files in the modules folder.
     * @return the list of all jar filenames in the modules folder.
     * @throws java.lang.Exception any error.
     */
    public abstract ArrayList<String> getModuleJars() throws Exception;
    
    /**
     * Read the contents of the jar file into a {@code FileObject} and return.
     * @param sourceFile the file path to the jar file.
     * @return a FileObject that contains the file contents.
     * @throws java.lang.Exception any error.
     */
    public abstract FileObject jarToFile(String sourceFile) throws Exception;
    
    /**
     * Save the contents of the {@code FileObject} to the default services location.
     * @param fileObject the file object with the file contents.
     * @return the jar file path formatted if the file was saved, null otherwise.
     * @throws java.lang.Exception any error.
     */
    public abstract String saveJarFile(FileObject fileObject) throws Exception;
}
