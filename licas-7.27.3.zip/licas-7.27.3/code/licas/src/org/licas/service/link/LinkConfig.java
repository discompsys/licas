/*
 * LinkConfig.java
 *
 * Created on 24 January 2007
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.link;

import org.ai_heuristic.util.AiHeuristicConst;

import java.util.ArrayList;

/**
 * This class stores a description of what linking options are allowed and can parse 
 * a String-based description to determine if a certain linking option has been specified.
 */
public class LinkConfig 
{
    /** Config separator */
    private static final String SEP = ":";
    
    /**link method descriptions */
    /** Defines a link only search */
    public static final String LINKONLY = "Link_Only";
    
    /** Defines a link with full search */
    public static final String LINKFULL = "Link_Full";
    
    /** Defines the comparison operator included */
    public static final String COMPARISON = "Comparison";
    
    /** Defines the memory limit method */
    public static final String MEMORY = "Memory";
    
    /** Defines the weight learning algorithm */
    public static final String LEARN = "Learn";
    
    /** Defines the borrow memory method */
    public static final String BORROW = "Borrow"; 
    
    /** Defines to include a reserve slot for each branch */
    public static final String RESERVE = "Reserve";
    
    /** Defines update individual links if no full answer */
    public static final String INDIVIDUAL = "Individual";
    
    /** Defines filter individual links before using */
    public static final String FILTER = "Filter";
    
    /** Defines add negative concepts to the link */
    public static final String ADDNEGATIVE = "Add_Negative";
    
    /** Defines create network view */
    public static final String VIEW = "View";
    
    /** Defines local view only */
    public static final String LOCALVIEW = "LocalViewOnly";
    
    /** Defines always add full search count */
    public static final String ALWAYSFULL = "Always_Full";
    
    /** Defines add full search count if it provides an answer */
    public static final String FULLIFANSWER = "Full_If_Answer";
    
    /** Defines never add full search count */
    public static final String NEVERFULL = "Never_Full";

    /** Defines reasoning query */
    public static final String REASON = "Reason";

    /** Defines calculate stats for the process */
    public static final String STATS = "Stats";
    

    /**
     * Creates a new instance of LinkConfig
     */
    public LinkConfig() {
    }

    /**
     * Return true if parameter is a valid link method.
     * @param linkMethod the link method.
     * @return true if a valid link method.
     * @throws java.lang.Exception any error.
     */
    public static boolean isLinkMethod(String linkMethod) throws Exception
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);

            return (createView(linkMethod) || 
                localViewOnly(linkMethod) ||
                isLinkOnly(linkMethod) ||
                isLinkFull(linkMethod) ||
                alwaysFull(linkMethod) ||
                fullIfAnswer(linkMethod) ||
                neverFull(linkMethod) ||
                includeComparison(linkMethod) ||
                limitMemory(linkMethod) || 
                canLearn(linkMethod) ||
                canBorrow(linkMethod) ||
                updateIndividual(linkMethod) ||
                filter(linkMethod) ||
                addNegative(linkMethod) ||
                isReasoning(linkMethod) ||
                stats(linkMethod));
        }
        else
            return false;
    }
    
    /**
     * Return a list of all legal linking methods.
     * @return a list of all linking methods.
     */
    public static ArrayList getLinkMethods()
    {
        ArrayList linkingMethods;                  //list of linking methods
        
        linkingMethods = new ArrayList();
        linkingMethods.add(COMPARISON);   
        linkingMethods.add(MEMORY);    
        linkingMethods.add(LEARN);    
        linkingMethods.add(BORROW);     
        linkingMethods.add(RESERVE);
    
        return linkingMethods;    
    }

    /**
     * Get a list of the default activation functions.
     * @return a list of the default activation function types.
     */
    public static ArrayList activationFunctions()
    {
        return AiHeuristicConst.activationFunctions();
    }

    /**
     * Return true if any full search is indicated.
     * @param linkMethod a string description of the link method.
     * @return true if any full search is indicated.
     */
    public static boolean isFullSearch(String linkMethod)
    {
        if (linkMethod != null)
        {
            return (isLinkFull(linkMethod) && !isLinkOnly(linkMethod));
        }
        else
            return false;
    }

    /**
     * Return true if any linked search is indicated.
     * @param linkMethod a string description of the link method.
     * @return true if any linked search is indicated.
     */
    public static boolean isLinkSearch(String linkMethod)
    {
        if (linkMethod != null)
        {
            return (isLinkOnly(linkMethod) || isLinkFull(linkMethod));
        }
        else
            return false;
    }

    /**
     * Return true if link only search method used.
     * @param linkMethod a string description of the link method.
     * @return true if link only search method used.
     */
    public static boolean isLinkOnly(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + LINKONLY + SEP) >= 0);
        }
        else
            return false;
    }

    /**
     * Return true if link with full search method used.
     * @param linkMethod a string description of the link method.
     * @return true if link with full search method used.
     */
    public static boolean isLinkFull(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + LINKFULL + SEP) >= 0);
        }
        else
            return false;
    }
    
    /**
     * Return true if parameter is a valid link method.
     * @param currentLinkConfig the current link configuration, null if no config yet.
     * @param linkMethod the new link method to add.
     * @return the link configuration with the new link type added.
     * @throws java.lang.Exception any error.
     */
    public static String addLinkMethod(String currentLinkConfig, String linkMethod)
            throws Exception
    {
        if (linkMethod != null)
        {
            if ((currentLinkConfig == null) || currentLinkConfig.equals(""))
            {
                currentLinkConfig = fixLinkMethod(linkMethod);
            }
            else
            {
                currentLinkConfig += linkMethod;
                currentLinkConfig = fixLinkMethod(currentLinkConfig);
            }
        }
        
        return currentLinkConfig;
    }
    
    /**
     * Make sure the link specification has the appropriate start and end characters.
     * @param linkMethod the current link specification.
     * @return the fixed link specification.
     */
    public static String fixLinkMethod(String linkMethod)
    {
        if (linkMethod != null)
        {
            if (!linkMethod.startsWith(SEP)) linkMethod = SEP + linkMethod;
            if (!linkMethod.endsWith(SEP)) linkMethod = linkMethod + SEP;
        }
        else
            linkMethod = SEP;
        
        return linkMethod;
    }

    /**
     * Return true if network should create a view.
     * @param linkMethod a string description of the link method.
     * @return true if network should create a view.
     */
    public static boolean createView(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + VIEW + SEP) >= 0);
        }
        else
            return false;
    }
    
    /**
     * Return true if network should store all view components locally only.
     * @param linkMethod a string description of the link method.
     * @return true if network should store all view components locally only.
     */
    public static boolean localViewOnly(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + LOCALVIEW + SEP) >= 0);
        }
        else
            return false;
    }
    
    /**
     * Return true if always add full search count.
     * @param linkMethod a string description of the link method.
     * @return true if link only search method used.
     */
    public static boolean alwaysFull(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + ALWAYSFULL + SEP) >= 0);
        }
        else
            return false;
    }
    
    /**
     * Return true if add full search count only if it returns an answer.
     * @param linkMethod a string description of the link method.
     * @return true if link only search method used.
     */
    public static boolean fullIfAnswer(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + FULLIFANSWER + SEP) >= 0);
        }
        else
            return false;
    }
    
    /**
     * Return true if never add full search count.
     * @param linkMethod a string description of the link method.
     * @return true if link only search method used.
     */
    public static boolean neverFull(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + NEVERFULL + SEP) >= 0);
        }
        else
            return false;
    }
    
    /**
     * Return true if comparison operator is included in linking.
     * @param linkMethod a string description of the link method.
     * @return true if comparison operator is included.
     */
    public static boolean includeComparison(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + COMPARISON + SEP) >= 0);
        }
        else
            return false;
    }
    
    /**
     * Return true if amount of memory is limited.
     * @param linkMethod a string description of the link method.
     * @return true if amount of memory is limited.
     */
    public static boolean limitMemory(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + MEMORY + SEP) >= 0);
        }
        else
            return false;
    }
    
    /**
     * Return true if link configuration indicates can learn.
     * @param linkMethod a string description of the link method.
     * @return true if link method can learn.
     */
    public static boolean canLearn(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + LEARN + SEP) >= 0);
        }
        else
            return false;
    }
    
    /**
     * Return true if link configuration indicates can borrow memory.
     * @param linkMethod a string description of the link method.
     * @return true if link method can borrow memory.
     */
    public static boolean canBorrow(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + BORROW + SEP) >= 0);
        }
        else
            return false;
    }
    
    /**
     * Return true if link configuration indicates can borrow memory.
     * @param linkMethod a string description of the link method.
     * @return true if link method can borrow memory.
     */
    public static boolean includeReserve(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + RESERVE + SEP) >= 0);
        }
        else
            return false;
    }
    
    /**
     * Return true if link configuration indicates to update individual links.
     * @param linkMethod a string description of the link method.
     * @return true if link method should update individual links.
     */
    public static boolean updateIndividual(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + INDIVIDUAL + SEP) >= 0);
        }
        else
            return false;
    }
    
    /**
     * Return true if link configuration indicates to filter individual links.
     * @param linkMethod a string description of the link method.
     * @return true if link method should filter individual links.
     */
    public static boolean filter(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + FILTER + SEP) >= 0);
        }
        else
            return false;
    }
    
    /**
     * Return true if link configuration indicates to add negative concepts to the links.
     * @param linkMethod a string description of the link method.
     * @return true if link method should include negative concepts with the links.
     */
    public static boolean addNegative(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + ADDNEGATIVE + SEP) >= 0);
        }
        else
            return false;
    }

    /**
     * Return true if link configuration indicates reasoning queries as well.
     * @param linkMethod a string description of the link method.
     * @return true if link method indicates reasoning queries.
     */
    public static boolean isReasoning(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + REASON + SEP) >= 0);
        }
        else
            return false;
    }

    /**
     * Return true if link configuration indicates to calculate stats.
     * @param linkMethod a string description of the link method.
     * @return true if link method should calculate stats.
     */
    public static boolean stats(String linkMethod)
    {
        if (linkMethod != null)
        {
            linkMethod = fixLinkMethod(linkMethod);
            return (linkMethod.indexOf(SEP + STATS + SEP) >= 0);
        }
        else
            return false;
    }
    
    /**
     * Return the linker class that most closely matches the linking method.
     * @param linkMethod a string description of the link method.
     * @return true the name of the class to create for the linking method.
     */
    public static String zzz_getLinkerClass(String linkMethod)
    {
        String linkerClass = null;                  //linker class
        
        if (linkMethod != null)
        {
            if (limitMemory(linkMethod))
            {
                linkerClass = Link_M.class.getName();
            }
            else if (includeReserve(linkMethod))
            {
                linkerClass = Link_NM.class.getName();
            }
            else
            {
                linkerClass = Link_M.class.getName();
            }
        }
        
        return linkerClass;
    }
}
