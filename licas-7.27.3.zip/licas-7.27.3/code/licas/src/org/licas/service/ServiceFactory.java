/*
 * ServiceFactory.java
 *
 * Created on 27 October 2011
 *
 * Version 1.4.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service;


import org.ai_heuristic.model.FactoryInfo;
import org.licas.PasswordHandler;
import org.licas.def.ServiceDef;
import org.licas.def.gui.ServiceGuiDef;
import org.licas.meta.model.ServiceModuleInfo;
import org.licas.query.LicasQueryConst;
import org.licas.util.Const;
import org.licas.util.ServiceConst;
import org.licas_xml.abs.Element;

import java.util.ArrayList;


/**
 * This class determines what service interfaces are returned for each service type.
 * @author Kieran Greer
 */
public abstract class ServiceFactory
{
    /** A key to allow changes to the service factory */
    private static String factoryKey = null;
    
    /** 
     * List of modules automatically loaded in during startup. Of type {@link ModuleServiceFactory}.
     */
    protected static ArrayList<ModuleServiceFactory> serviceModules;
    
    /** Single instance of the factory that is used to process all method calls */
    private static volatile ServiceFactory serviceFactory = null;

    /** List of default service jar files */
    protected static ArrayList<String> defaultJars;


    static
    {
        try {
            serviceModules = new ArrayList<>();

            defaultJars = new ArrayList<>();
            defaultJars.add("licas_services.jar");
            defaultJars.add("licas_services_m1.jar");
        }
        catch (Exception ex) {}
    }
    
    
    /**
     * Get the created instance of the service factory.
     * @return the value of serviceFactory.
     */
    public static ServiceFactory getInstance()
    {
        return serviceFactory;
    }

    /**
     * Set the instance of the service factory to be used. This can be set if either:
     * the service factory is currently null, or the factory key is correct. This will
     * also set the factory key value for the initial (if null) assignment.
     * @param thisServiceFactory the service factory that is retrieved for any method call.
     * @param thisFactoryKey a key to protect dynamic changing of the factory.
     */
    public static void setServiceFactory(ServiceFactory thisServiceFactory, String thisFactoryKey)
    {
        if (serviceFactory == null) {
            synchronized(ServiceFactory.class) {
                serviceFactory = thisServiceFactory;
                factoryKey = thisFactoryKey;
            }
        }
        else {
            synchronized(ServiceFactory.class) {
                if ((factoryKey != null) && factoryKey.equals(thisFactoryKey)) {
                    serviceFactory = thisServiceFactory;
                }
            }
        }
    }

    /**
     * Return true if the service can be added as a global server service.
     * @param serviceType the service type.
     * @return true if the service type can be a global server service.
     */
    public boolean isGlobalService(String serviceType)
    {
        return (serviceType.equals(Const.METASEARCH) ||
                serviceType.equals(ServiceConst.BEHAVIOURMEDIATOR));
    }
    
    /**
     * Add a factory service module, for retrieving service info details.
     * @param serviceModule the factory service module.
     */
    public void addServiceModule(ModuleServiceFactory serviceModule)
    {
        serviceModules.add(serviceModule);
    }
    
    /**
     * Get a list of the default services that can be loaded.
     * @return the list of default services that can be loaded.
     */
    public abstract ArrayList<ServiceModuleInfo> getDefaultServiceInfo();
    
    /**
     * Get a list of the default services that can be loaded for the category type.
     * @param categoryType the type of category to retrieve default services for.
     * {@link ServiceConst}.{@code ALLCATEGORIES} means all services.
     * @return the list of default services that can be loaded.
     */
    public abstract ArrayList<ServiceModuleInfo> getDefaultServiceInfo(String categoryType);
    
    /**
     * Get the class name for a specified service type.
     * @param serviceType the service type.
     * @return the default service class or null if it does not exist.
     */
    public abstract String getDefaultServiceClassname(String serviceType);
    
    /**
     * Create a new default service or module. This must be a recognised module from its
     * service type, for this service factory.
     * @param serviceUuid the uuid for the new default service to add.
     * @param serviceType the type of service to create. Note that a uuid is not set.
     * @param adminXml the admin info or description of the new service.
     * @param passwordHandler the password handler for the service that calls this method.
     * @return the service or module if it can be created, null otherwise.
     * @throws java.lang.Exception any error.
     */
    public abstract ServiceDef createDefaultService(String serviceUuid, String serviceType,
        Element adminXml, PasswordHandler passwordHandler) throws Exception;
    
    /**
     * Add a particular class to be loaded for the specified service type and function.
     * This will automatically overwrite any existing saved classname.
     * @param serviceFunction the function of the service.
     * @param factoryInfo the info object for the interface.
     * @throws java.lang.Exception any error.
     */
    public abstract void addServiceClass(String serviceFunction, FactoryInfo factoryInfo) throws Exception;
    
    /**
     * Remove a particular class for the specified service type and function.
     * @param serviceFunction the function of the service.
     * @param factoryInfo the info object for the interface.
     * @throws java.lang.Exception any error.
     */
    public abstract void removeServiceClass(String serviceFunction, FactoryInfo factoryInfo) throws Exception;
    
    /**
     * Return the initialised GUI interface for the specified service.
     * @param serviceType the type of service.
     * @return return a GUI interface that is compatible with the service methods.
     * @throws java.lang.Exception any error.
     */
    public abstract ServiceGuiDef getServiceGui(String serviceType) throws Exception;
    
    /**
     * Return the stored service class for the specified service type. For the 
     * Linker service the most commonly used class is returned. The LinkConfig
     * class can be passed the linking method to return a more accurate result.
     * @param serviceType the type of service.
     * @return the service class stored for that type, or null if it is missing.
     * @throws java.lang.Exception any error.
     */
    public abstract String getServiceClass(String serviceType) throws Exception;
    
    /**
     * Get a list of types that can represent the default query engine.
     * @return the list of default query engine types.
     */
    public ArrayList<String> getBehaviourViewTypes()
    {
        ArrayList<String> defaultServices;              //default services list
        
        defaultServices = new ArrayList<>();
        defaultServices.add(ServiceConst.BEHAVIOURAGGREGATEVIEW);        
        defaultServices.add(ServiceConst.LINEPLOTVIEW);        
        defaultServices.add(ServiceConst.SCATTERPLOTVIEW);        
        defaultServices.add(ServiceConst.HISTPLOTVIEW);        
        return defaultServices;
    }
    
    /**
     * Get a short description of the view type.
     * @param viewType the behaviour view type.
     * @return the graph type description.
     */
    public String getBehaviourViewDescr(String viewType)
    {
        if (viewType.equalsIgnoreCase(ServiceConst.BEHAVIOURAGGREGATEVIEW)) {
            return "Clusters of links between services.";
        }
        else if (viewType.equalsIgnoreCase(ServiceConst.LINEPLOTVIEW)) {
            return "Line-series plot for each service.";
        }
        else if (viewType.equalsIgnoreCase(ServiceConst.SCATTERPLOTVIEW)) {
            return "Point-series plot for each service.";
        }
        else if (viewType.equalsIgnoreCase(ServiceConst.HISTPLOTVIEW)) {
            return "Frequency plot for a value.";
        }
        
        return "";
    }
    
    /**
     * Get a list of types that can represent the default query engine.
     * @return the list of default query engine types.
     */
    public static ArrayList<String> getDefaultQueryEngineTypes()
    {
        ArrayList<String> defaultServices;                      //default services list
        
        defaultServices = LicasQueryConst.getLicasSearchTypes();        
        return defaultServices;
    }
}
