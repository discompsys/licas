/*
 * AiConfig.java
 *
 * Created on 28 October 2019
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.sci;


import org.licas.util.HeuristicConst;


/**
 * This class stores a description of what heuristic and metric options are allowed and can parse
 * a String-based description to determine what classes if any should be used.
 * @author Kieran Greer
 */
public class AiConfig {
    /** Config separator */
    private static final String SEP = ":";

    /**
     * Creates a new instance of AiConfig
     */
    public AiConfig() {
    }

    /**
     * Return true if a clustering method is indicated.
     * @param aiMethod a string description of the ai method.
     * @return true if a clustering method is indicated.
     */
    public static boolean isClusterMethod(String aiMethod)
    {
        if (aiMethod != null)
        {
            aiMethod = fixLinkMethod(aiMethod);
            return (aiMethod.contains(SEP + HeuristicConst.CLUSTER + SEP));
        }
        else
            return false;
    }

    /**
     * Return true if a contains link clustering method is indicated.
     * @param aiMethod a string description of the ai method.
     * @return true if a clustering method is indicated.
     */
    public static boolean isContainsCluster(String aiMethod)
    {
        if (aiMethod != null)
        {
            aiMethod = fixLinkMethod(aiMethod);
            return (aiMethod.contains(SEP + HeuristicConst.CONTAINSLINK + SEP));
        }
        else
            return false;
    }

    /**
     * Return true if a complete link clustering method is indicated.
     * @param aiMethod a string description of the ai method.
     * @return true if a clustering method is indicated.
     */
    public static boolean isCompleteCluster(String aiMethod)
    {
        if (aiMethod != null)
        {
            aiMethod = fixLinkMethod(aiMethod);
            return (aiMethod.contains(SEP + HeuristicConst.COMPLETELINK + SEP));
        }
        else
            return false;
    }

    /**
     * Return true if a single link clustering method is indicated.
     * @param aiMethod a string description of the ai method.
     * @return true if a clustering method is indicated.
     */
    public static boolean isSingleCluster(String aiMethod)
    {
        if (aiMethod != null)
        {
            aiMethod = fixLinkMethod(aiMethod);
            return (aiMethod.contains(SEP + HeuristicConst.SINGLELINK + SEP));
        }
        else
            return false;
    }

    /**
     * Return true if parameter is a valid link method.
     * @param currentAiConfig the current ai configuration, null if no config yet.
     * @param aiMethod the new ai method to add.
     * @return the ai configuration with the new link type added.
     */
    public static String addAiMethod(String currentAiConfig, String aiMethod)
    {
        if (aiMethod != null)
        {
            if ((currentAiConfig == null) || currentAiConfig.equals(""))
            {
                currentAiConfig = fixLinkMethod(aiMethod);
            }
            else
            {
                currentAiConfig += aiMethod;
                currentAiConfig = fixLinkMethod(currentAiConfig);
            }
        }

        return currentAiConfig;
    }

    /**
     * Make sure the link specification has the appropriate start and end characters.
     * @param aiMethod the current ai specification.
     * @return the fixed link specification.
     */
    public static String fixLinkMethod(String aiMethod)
    {
        if (aiMethod != null)
        {
            if (!aiMethod.startsWith(SEP)) aiMethod = SEP + aiMethod;
            if (!aiMethod.endsWith(SEP)) aiMethod = aiMethod + SEP;
        }
        else
            aiMethod = SEP;

        return aiMethod;
    }
}
