/**
 * Resource objects for storing other resource objects and performing some pre-defined operations over them.
 */
package org.licas.service.resource.container;