/**
 * These classes can be instantiated, or are base definitions that can be used as is
 * with minimal abstract functionality, or can be further extended as needed.
 */
package org.licas.service.model;