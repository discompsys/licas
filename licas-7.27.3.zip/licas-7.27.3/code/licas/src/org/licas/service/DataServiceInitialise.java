/*
 * DataServiceInitialise.java
 *
 * Created on 17 January 2014
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service;


import org.ai_heuristic.eval.EvaluateBase;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.PasswordHandler;
import org.licas.Service;
import org.licas.ServiceAdmin;
import org.licas.ServiceInitialise;
import org.licas.data.gen.DataGenerator;
import org.licas.meta.MetaFactory;
import org.licas.util.ServiceConst;
import org.licas_xml.abs.Element;


/**
 * This class performs some additional or final initialisations, after a {@link DataService}
 * service has been properly loaded and registered. If it has been created with an admin
 * document for example, the metadata might describe some additional operations 
 * that should be carried out, such as loading in some default utility services.
 * @author Kieran Greer
 */
public class DataServiceInitialise extends ServiceInitialise
{
    /** The logger */
    private static final Logger logger;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(DataServiceInitialise.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Create a new instance of DataServiceInitialise.
     * @param theParentService the parent service.
     * @param theServiceAdmin the parent service's admin handler.
     * @param thePasswordHandler the parent service's password handler.
     */
    public DataServiceInitialise(Service theParentService, ServiceAdmin theServiceAdmin,
            PasswordHandler thePasswordHandler)
    {
        super(theParentService, theServiceAdmin, thePasswordHandler);
    }
    
    /**
     * Finalise the initialisation of the service. If an admin document is passed, 
     * this default implementation retrieves the XML description of services to load 
     * and tries to create and load them as child services of this one.
     * @param servicesXml services to load XML section.
     * @throws java.lang.Exception any error.
     */
    public void finaliseInitialisation(Element servicesXml) throws Exception
    {
        //call super class to load the services
        super.finaliseInitialisation(servicesXml); 
    }
}
