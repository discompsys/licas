/*
 * ServiceSpec.java
 *
 * Created on 24 July 2013
 *
 * Version 1.3
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.service.spec;


import org.ai_heuristic.parser.BagOfWordsParser;
import org.ai_heuristic.parser.MetaBagOfWordsParser;
import org.ai_heuristic.util.AiHeuristicConst;
import org.ai_heuristic.util.TextConst;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.PasswordHandler;
import org.licas.meta.MetaFactory;
import org.licas.util.Const;
import org.licas.util.ObjectHandler;
import org.licas.util.ServiceConst;
import org.licas.util.TypeConst;
import org.licas_text.util.QueryConst;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;


/**
 * This class can provide a general specification for creating or loading services
 * onto a server or network.
 * @author Kieran Greer
 */
public class ServiceSpec
{
    /** For logging errors */
    private static final Logger logger;

    
    /** The type of dataset to use */
    public String datasetType;
    
    /** The directory to read the files from */
    public String dirPath;
    
    /** The character to separate dataset values */
    public String tokenizer;
    
    
    /** Number of services or solutions - also the initial number to create */
    public int servicesNum;
    
    /** If true create the services on the specified server, if false test without services */
    public boolean createServices;
    
    /** 
     * Service classes.
     * Key is the service type and value is the class name.
     */
    public HashMap<String, String> serviceClasses;
    
    /** 
     * Parameters to initialise the base service with.
     * Can contain service password, admin key and admin script.
     */
    public ArrayList<Object> constructorParams;

    /**
     * The type of heuristic to use.
     * This defines the type of problem solver to use, or the problem solving mechanism.
     */
    public String heuristicType;

    /**
     * The type of metric to use, for example.{@link AiHeuristicConst}.{@code EUCLIDEANFUNCTION}.
     * This defines the evaluation function that the problem-solving heuristic should use.
     */
    public String metricType;

    /** The test service type */
    public String serviceType;
    
    /** 
     * List of conditions under which data can be generated or read. This could 
     * be a list of file directory paths to read file contents from, or it could 
     * be a set or range of allowed values, represented in String format.
     */
    public ArrayList<String> dataConditions;

    /**
     * A list of different heuristic options. For example, genetic algorithms require the evolve types.
     * Key is the variable name and value is the value. These are more for initialisation purposes.
     */
    public HashMap<String, Object> heuristicOptions;

    /**
     * Arbitrary list of key-value pairs for processing in solutions. Maybe not for initialising,
     * but for run-time passing of values.
     */
    public HashMap<String, Object> inputVariables;

    /**
     * Service jar files.
     * Key is the service type and value is a list or required jar files.
     */
    public HashMap<String, ArrayList<String>> serviceJarFiles;

    /** The file path to read an external script from */
    public String externalScript;
    
    /** Linking specification */
    public LinkSpec linkSpec;
    
    /** Server config specification */
    public ServerSpec serverSpec;

    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServiceSpec.class.getName());
        logger.setDebug(false);
    }
    
    
    /** 
     * Create a new instance of ServiceSpec.
     * @param thePasswordHandler for storing passwords.
     */
    public ServiceSpec(PasswordHandler thePasswordHandler)
    {
        initialise(thePasswordHandler);
    }

    /** 
     * Initialise some values.
     * @param passwordHandler for storing passwords.
     */
    private void initialise(PasswordHandler passwordHandler)
    {
        servicesNum = 0;
        createServices = true;
        serviceType = null;
        heuristicType = null;
        metricType = null;
        datasetType = null;
        dirPath = null;
        tokenizer = ",";
        externalScript = null;
        dataConditions = new ArrayList<>();
        constructorParams = new ArrayList<>();
        serviceClasses = new HashMap<>();
        serviceJarFiles = new HashMap<>();
        heuristicOptions = new HashMap<>();
        inputVariables = new HashMap<>();
        linkSpec = new LinkSpec();
        serverSpec = new ServerSpec(passwordHandler);
    }
    
    /**
     * Validate the whole script and return a description of any errors.
     * @return a description of any errors or null if OK.
     */
    public String validateScript()
    {
        String validateReply;                   //validation errors
        
        validateReply = "";
        validateReply += validateVariable(Const.SERVICES);
        validateReply += validateVariable(Const.SOLUTIONS);
        validateReply += validateVariable(Const.CREATESERVICES);
        validateReply += validateVariable(Const.DATASETTYPE);
        validateReply += validateVariable(QueryConst.FILEPATH);

        validateReply = validateReply.trim();
        if (validateReply.equals("")) validateReply = null;
        return validateReply;
    }
    
    /**
     * Validate the script variable and return a description if invalid.
     * @param varType the variable type.
     * @return a description of any error, of null if OK.
     */
    protected String validateVariable(String varType)
    {
        String validateError;                   //validate error

        validateError = "";
        if (varType.equals(Const.SERVICES)) {
            if (!serviceClasses.containsKey(ServiceConst.BEHAVIOUR) ||
                !serviceJarFiles.containsKey(ServiceConst.BEHAVIOUR)) {
                validateError = (Const.SERVICES + ": behaviour service at least is required.\n");
            }
        }
        else if (varType.equals(Const.SOLUTIONS))
        {
            try {
                if (servicesNum <= 0.0) {
                    if ((datasetType != null) && !TypeConst.isSimpleType(datasetType)) {
                        if ((dirPath == null) || dirPath.equals("")) {
                            validateError = (Const.SOLUTIONS + ": must be greater than 0.\n");
                        }
                    }
                    else {
                        validateError = (Const.SOLUTIONS + ": must be greater than 0.\n");
                    }
                }
            }
            catch (Exception ex) {
                validateError = (Const.SOLUTIONS + ": has incorrect format.\n");
            }
        }
        else if (varType.equals(QueryConst.FILEPATH) && (dirPath != null)) {
            dirPath = dirPath.trim();
            if (!dirPath.equals("") && !(new File(dirPath).exists())) {
                validateError = (QueryConst.FILEPATH + ": datasets directory is incorrect or missing.\n");
            }
        }
        
        return validateError;
    }
    
    /**
     * Parse a problem dataset in XML format to create the associated object.
     * This can be anything depending on what sort of data is being processed, 
     * so any derived class need to implement this to be application specific.
     * @param datasetType the type of dataset to be parsed.
     * @param dataXml the dataset description in XML.
     * @return the parsed object.
     * @throws java.lang.Exception any error.
     */
    public Object parseProblemDataset(String datasetType, Element dataXml) throws Exception
    {
        String bowStr;                                  //bow string
        Element valueXml;                               //value xml element
        BagOfWordsParser bagOfWordsParser;              //bag of words parser
        MetaBagOfWordsParser bagOfWordsAndParser;       //bag of words plus parser
        Object parsedObj;                               //parsed object
        
        //might need to update the data type if retrieved from a resource type
        MetaFactory.getFactoryData().setDataType(datasetType, dataXml);
        parsedObj = null;

        if (datasetType.equals(TextConst.BAGOFWORDS)) {
            //remove the outer data element if it is still there
            if (dataXml.getName().equals(Const.DATA)) {
                valueXml = dataXml.getChild(Const.VALUE);
                if (valueXml == null) {
                    valueXml = dataXml.getElementChildAtIndex(0);
                }
                
                dataXml = valueXml;
            }
                    
            //also check if stored as a string or the required xml
            if (!dataXml.hasChildren()) {
                bowStr = dataXml.getText();
                dataXml = XmlHandler.stringToElement(bowStr);
            }
            else {
                if (dataXml.getChild(TextConst.BAGOFWORDSTAG) != null) {
                    dataXml = dataXml.getChild(TextConst.BAGOFWORDSTAG);
                }
            }
            
            bagOfWordsParser = new BagOfWordsParser();
            parsedObj = bagOfWordsParser.parse(dataXml);
        }
        else if (datasetType.equals(TextConst.METABAGOFWORDS)) {
            //remove the outer data element if it is still there
            if (dataXml.getName().equals(Const.DATA)) {
                dataXml = dataXml.getChild(Const.VALUE);
                if (dataXml != null) {
                    dataXml = dataXml.getElementChildAtIndex(0);
                }
            }
                  
            //also check if stored as a string or the required xml
            if (dataXml != null) {
                if (!dataXml.hasChildren()) {
                    bowStr = dataXml.getText();
                    dataXml = XmlHandler.stringToElement(bowStr);
                } else {
                    if (dataXml.getChild(TextConst.BAGOFWORDSTAG) != null) {
                        dataXml = dataXml.getChild(TextConst.BAGOFWORDSTAG);
                    }
                }

                bagOfWordsAndParser = new MetaBagOfWordsParser();
                parsedObj = bagOfWordsAndParser.parse(dataXml);
            }
        }
        else {
            parsedObj = ObjectHandler.dataXmlToValue(dataXml);
        }
        
        return parsedObj;
    }
}
