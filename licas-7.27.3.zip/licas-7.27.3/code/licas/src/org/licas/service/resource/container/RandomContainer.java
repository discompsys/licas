/*
 * RandomContainer.java
 *
 * Created on 8 April 2014
 *
 * Version 1.3.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.resource.container;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.service.resource.Resource;
import org.licas.util.Const;
import org.licas.util.exception.LicasException;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;
import java.util.Random;


/**
 * This can be used to store an array or set of {@link Resource} derived objects and 
 * randomly return the details of one of them upon request.
 * @author Kieran Greer
 */
public class RandomContainer extends ResourceContainer
{
    /** The logger */
    private static final Logger logger;
    
    
    /** Random number generator */
    private Random rnd;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(RandomContainer.class.getName());
        logger.setDebug(false);
    }

    
    /**
     * Create a new instance of RandomContainer.
     * @param theDataType the container type.
     * @throws java.lang.Exception any error.
     */
    public RandomContainer(String theDataType) throws Exception
    {
        super(theDataType);
        initialise(null);
    }

    /**
     * Create a new instance of RandomContainer.
     * @param theDataType the container type.
     * @param dataXml a description of the initialisation parameters.
     * @throws java.lang.Exception any error.
     */
    public RandomContainer(String theDataType, Element dataXml) throws Exception
    {
        super(theDataType);
        initialise(dataXml);
    }
    
    /** 
     * Initialise some values.
     * @param dataXml a description of the initialisation parameters.
     * @throws java.lang.Exception any error.
     */
    private void initialise(Element dataXml) throws Exception
    {
        if ((dataXml != null)&& !parseInfo(dataXml)) {
            throw new LicasException("Could not parse the data description");
        }
    }
    
    /**
     * Parse the data description in the admin document to create the data object.
     * @param dataXml the {@code Data} element of the admin document. This should include
     * the container {@code DataType} element and a {@code Value} element that stores 
     * a list of child {@code Data} elements that store information for each resource to create. 
     * The {@code Value} element can also optionally store the random number generator 
     * initialisation value (of type long). If this is missing, then the current date is used. 
     * This would be another {@code Value} element that could be created using 
     * {@code MetaFactory.addXML(adminData, (MetaFactory.createMetaValueXML(Const.VALUE, rnd-init),
     * Const.VALUE)}, for example.
     * @return true if any specified resources are successfully added, false otherwise.
     * @throws java.lang.Exception any error.
     */
    protected boolean parseInfo(Element dataXml) throws Exception
    {
        String infoValue;                           //info value
        Element valueElem;                          //value element
        
        valueElem = parseValueElem(dataXml);
        if (valueElem != null) {
            valueElem = valueElem.getChild(Const.VALUE);
            if (valueElem != null) {
                infoValue = valueElem.getText();
                rnd = new Random(Long.parseLong(infoValue));
            }
            else {
                rnd = new Random(System.currentTimeMillis());
            }
        }
        else {
            rnd = new Random(System.currentTimeMillis());
        }
        
        return super.parseInfo(dataXml);
    }
    
    /**
     * Get the source information wrapped in an XML element.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * @return the value of the resource info as an XML element. This format is 
     * consistent with adding a 'Data' element through an admin document.
     * @throws java.lang.Exception any error.
     */
    public Element getInfo(Element infoDescr) throws Exception
    {
        int index;                                  //list index
        Element dataElem;                           //data element
        Element sourceInfo;                         //source info
        ArrayList<String> resourceIDs;              //list of ids
        Resource infoResource;                      //info resource
        
        try {
            sourceInfo = XMLFactory.getInstance().createElement(Const.DATA);
            resourceIDs = new ArrayList<>(resourceList.keySet());

            if (!resourceIDs.isEmpty()) {
                index = rnd.nextInt(resourceIDs.size());
                infoResource = resourceList.get(resourceIDs.get(index));
                dataElem = infoResource.getInfo(infoDescr);
                sourceInfo.addContent(dataElem);
            }
            
            return sourceInfo;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getInfo",
                null, ex);
        } 
    }
    
    /**
     * Get the currently selected value itself and not a wrapped description.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * @return the info value.
     * @throws java.lang.Exception any error.
     */
    public Object getValue(Element infoDescr) throws Exception
    {
        int index;                                  //list index
        ArrayList<String> resourceIDs;              //list of ids
        Resource infoResource;                      //info resource
        
        try {
            resourceIDs = new ArrayList<>(resourceList.keySet());

            if (!resourceIDs.isEmpty()) {
                index = rnd.nextInt(resourceIDs.size());
                infoResource = resourceList.get(resourceIDs.get(index));
                return infoResource.getValue(infoDescr);
            }
            
            return null;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getValue",
                null, ex);
        }
    }
}
