/*
 * AddressInfo.java
 *
 * Created on 29 October 2011
 *
 * Version 1.3
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.service.model;


import org.licas.call.Handle;
import org.licas.util.Const;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;


/**
 * This class stores information for a single service address, including passwords.
 * It is not used by the calling mechanism inherently, but might be useful for a service
 * wishing to store related addresses, such as the messenger service.
 * @author Kieran Greer
 */
public class AddressInfo 
{
    /** Unique service ID */
    public String serviceID;
    
    /** Password to access the service */
    public String servicePassword;
    
    /** Admin key to access the service */
    public String serviceAdminKey;
    
    /** URL address of the server the service runs on */
    public String serverURL;
    
    /** Password to access the server */
    public String serverPassword;
    
    /** Optional file path for an image to display */
    public String imagePath;
    
    /** Arbitrary description for the address */
    public String description;
    
    
    /** Create a new instance of AddressInfo */
    public AddressInfo()
    {
        serviceID = null;
        servicePassword = null;
        serviceAdminKey = Const.ANON;
        serverURL = null;
        serverPassword = null;
        imagePath = null;
        description = null;
    }
    
    /**
     * Return true if the entry is complete.
     * @return true if there are no null values. 
     */
    public boolean isComplete()
    {
        return ((serviceID != null) && (servicePassword != null) &&
                (serverURL != null) && (serverPassword != null));
    }
    
    /**
     * Construct and return the service key value that should be a unique URI across servers.
     * It contains the full service handle (ip address plus service ID) as a string.
     * @return the service key value, to be used as a unique identifier.
     * @throws java.lang.Exception any error.
     */
    public String serviceKey() throws Exception
    {
        String serviceKey;                              //service key
        Element address;                                //address
        
        serviceKey = null;
        if ((serviceID != null) && (serverURL != null))
        {
            address = serviceAddress();
            if (address != null) serviceKey = XmlHandler.xmlToString(address);
        }
        
        return serviceKey;
    }
    
    /**
     * Construct and return the service address as an XML-based description, including the
     * server ip address.
     * @return the service address as constructed by {@link Handle}.
     */
    public Element serviceAddress()
    {
        Element address;                                //address
        
        address = null;
        if ((serviceID != null) && (serverURL != null))
        {
            address = Handle.createNewUrlHandle(serverURL);
            address = Handle.addToHandle(address, Handle.asHandleElement(serviceID));
        }
        
        return address;
    }
    
    /**
     * Construct and return the base server address as an XML-based description, including 
     * the server ip address and default {@link Const}.{@code HTTPSERVER} name.
     * @return the server address as constructed by {@link Handle}.
     */
    public Element serverAddress()
    {
        Element address;                                //address
        
        address = null;
        if (serverURL != null)
        {
            address = Handle.createNewUrlHandle(serverURL);
            address = Handle.addToHandle(address, Handle.asHandleElement(Const.HTTPSERVER));
        }
        
        return address;
    }
    
    /**
     * Parse the service key to retrieve the service id only.
     * @param serviceKey the full URI service key, as constructed by {@code serviceKey()}.
     * @return the service id value only.
     * @throws java.lang.Exception any error.
     */
    public static String idFromKey(String serviceKey) throws Exception
    {
        String thisServiceID;                           //service id
        Element address;                                //address
        
        thisServiceID = null;
        if (serviceKey != null)
        {
            address = XmlHandler.stringToElement(serviceKey);
            thisServiceID = Handle.getLastServiceHandle(address);
        }
        
        return thisServiceID;
    }
    
    /**
     * Construct and return the service key value that should be a unique URI across servers.
     * It contains the full service handle (ip address plus service ID) as a string.
     * @param thisServerURL the server url address to use {@code (http://ip/port)}.
     * @param thisServiceID the service uuid.
     * @return the service key value, to be used as a unique identifier.
     * @throws java.lang.Exception any error.
     */
    public static String serviceKey(String thisServerURL, String thisServiceID) throws Exception
    {
        String serviceKey;                              //service key
        Element address;                                //address
        
        serviceKey = null;
        if ((thisServiceID != null) && (thisServerURL != null))
        {
            address = Handle.createNewUrlHandle(thisServerURL);
            address = Handle.addToHandle(address, Handle.asHandleElement(thisServiceID));
            if (address != null) serviceKey = XmlHandler.xmlToString(address);
        }
        
        return serviceKey;
    }
}
