/**
 * Base classes for more scientific testing, including linking tests.
 */
package org.licas.service.sci;