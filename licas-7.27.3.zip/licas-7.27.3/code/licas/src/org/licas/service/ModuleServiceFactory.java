/*
 * ModuleServiceFactory.java
 *
 * Created on 6 November 2015
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service;


import org.ai_heuristic.model.FactoryInfo;

import org.licas.PasswordHandler;
import org.licas.def.ServiceDef;
import org.licas.def.gui.ServiceGuiDef;
import org.licas.meta.LicasConfig;
import org.licas.meta.model.ServiceModuleInfo;
import org.licas.util.ServiceConst;
import org.licas_xml.abs.Element;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;

import java.util.*;


/**
 * This service factory is read automatically by the GUI when loaded, to store a
 * pre-programmed script of the services it provides.
 * @author Kieran Greer
 */
public abstract class ModuleServiceFactory
{
    /** The logger */
    private static final Logger logger;
    
    /**
     * List of services that this module provides.
     * Key is the service type and value is the related {@link ServiceModuleInfo} info.
     */
    protected HashMap<String, ServiceModuleInfo> services;
    
    /**
     * List of GUI interfaces that are available for any of the services.
     * Key is the service type and value is the related {@link FactoryInfo} info.
     */
    protected HashMap<String, FactoryInfo> serviceGuis;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ModuleServiceFactory.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Create a new instance of ModuleServiceFactory. This constructor does not
     * initialise the service factory properly and should be used only to create
     * an instance of the object for type checking.
     */
    public ModuleServiceFactory()
    {
        services = new HashMap<>();
        serviceGuis = new HashMap<>();
        setServiceInfo();
        setGuiInfo();
    }
    
    /**
     * Set or create a list of the default services that can be loaded from this module.
     * This is automatically called as part of the constructor. Also add related default parsers.
     */
    protected abstract void setServiceInfo();
    
    /**
     * Set or create a list of the service GUI classes that operate as the service.
     * This is automatically called as part of the constructor.
     */
    protected abstract void setGuiInfo();
    
    /**
     * Get a list of the default services that can be loaded for the category type.
     * Also add related default parsers.
     * @param categoryType the type of category to retrieve default services for.
     * {@link ServiceConst}.{@code ALLCATEGORIES} means all services. If the licas config file
     * has overwritten an entry, then return that instead.
     * @param defaultServices list of currently loaded service info.
     * @param licasConfig the factory config to add the service information to.
     */
    public abstract void getDefaultServiceInfo(String categoryType, ArrayList<ServiceModuleInfo> defaultServices,
                                               LicasConfig licasConfig);
    
    /**
     * Get the class name for a specified service type.
     * @param serviceType the service type.
     * @return the default service class or null if it does not exist.
     */
    public abstract String getDefaultServiceClassname(String serviceType);

    /**
     * Create a new default service or module.
     * @param serviceUuid the uuid for the new default service to add.
     * @param serviceType the type of service to create. Note that a uuid is not set.
     * @param adminXml the admin info or description of the new service.
     * @param passwordHandler the password handler for the service that calls this method.
     * @return the service or module if it can be created, null otherwise.
     * @throws java.lang.Exception any error.
     */
    public abstract ServiceDef createDefaultService(String serviceUuid, String serviceType,
        Element adminXml, PasswordHandler passwordHandler) throws Exception;
    
    /**
     * Return the initialised GUI interface for the specified service.
     * @param serviceType the type of service.
     * @return return a GUI interface that is compatible with the service methods.
     * @throws java.lang.Exception any error.
     */
    public abstract ServiceGuiDef getServiceGui(String serviceType) throws Exception;
    
    /**
     * Return the stored service class for the specified service type. This is only
     * for the known default service types, not any types added by a user. For the 
     * Linker service the most commonly used class is returned. The LinkConfig
     * class can be passed the linking method to return a more accurate result.
     * @param serviceType the type of service.
     * @return the service class stored for that type, or null if it is missing.
     * @throws java.lang.Exception any error.
     */
    public abstract String getServiceClass(String serviceType) throws Exception;
    
    
    /**
     * Return the full list of initialised GUI interface for the specified service.
     * @return the value of serviceGuis.
     */
    public HashMap<String, FactoryInfo> getServiceGui()
    {
        return serviceGuis;
    }
}
