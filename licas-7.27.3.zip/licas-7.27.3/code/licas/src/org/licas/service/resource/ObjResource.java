/*
 * ObjResource.java
 *
 * Created on 11 September 2013
 *
 * Version 1.4
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.resource;


import org.ai_heuristic.def.ParserDef;
import org.ai_heuristic.eval.EvaluateBase;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.FileLoader;
import org.licas.meta.MetaFactory;
import org.licas.parsers.Parsers;
import org.licas.util.Const;
import org.licas.util.ObjectHandler;
import org.licas.util.classloader.LoadObject;
import org.licas.util.exception.LicasException;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.io.File;
import java.util.ArrayList;
import java.util.Vector;


/**
 * This is a generic type of resource to store any information Object directly.
 * It might be used for basic types, such as {@code Integer} or {@code Float}, for example.
 * Alternatively, you can specify a parser and serialize/parse your own Java objects.
 * This automatically loads the contents in and does not dynamically retrieve each time.
 * @author Kieran Greer
 */
public class ObjResource extends Resource
{
    /** The logger */
    private static final Logger logger;
    
    
    /** A parser to serializeToString/parse the Java object with */
    private ParserDef parser;
    
    /** The object-based information */
    private Object objInfo;
    
        
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ObjResource.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of ObjResource.
     * @param theDataType the resource data type.
     * @param theData the data object. This is stored as is, do not need to parse anything.
     * @throws java.lang.Exception any error.
     */
    public ObjResource(String theDataType, Object theData) throws Exception
    {
        super(theDataType);
        objInfo = theData;
    }

    /**
     * Create a new instance of ObjResource.
     * @param theDataType the resource data type.
     * @param dataXml a description of the initialisation parameters. Can be null.
     * @throws java.lang.Exception any error.
     */
    public ObjResource(String theDataType, Element dataXml) throws Exception
    {
        super(theDataType);
        objInfo = null;
        parser = null;
        
        if (dataXml != null)
        {
            if (!parseInfo(dataXml))
            {
                throw new LicasException("Could not parse the data description");
            }
        }
    }
    
    /**
     * Parse the data description in the admin document to create the data object.
     * This version should retrieve a string-based description and try to parse it
     * into the data object.
     * @param dataXml the {@code Data} element of the admin document. This should include
     * a {@code Value} element that stores a String-based file path description and possibly
     * an {@code Action} element. If there is no specified action, then the data is loaded
     * into the resource as default. There can also be a {@code Parser} element, as specified by
     * {@code MetaFactory.createParserXML}.
     * @return true if the file was successfully loaded, false otherwise.
     * @throws java.lang.Exception any error.
     */
    protected boolean parseInfo(Element dataXml) throws Exception
    {
        int i;
        String dataValue;                           //data value
        ArrayList<String> jarFiles;                 //jar files list
        File dataFile;                              //data file
        Element parserElem;                         //parser element
        Element dataValueElem;                      //data value element
        Element nextElem;                           //next element
        Vector<Node> elemList;                      //elements list
        
        try
        {
            setUUID(dataXml);
            objInfo = null;
            
            //first get details about a related parser
            parserElem = dataXml.getChild(Const.PARSER);     
            if (parserElem != null) {
                dataValueElem = parserElem.getChild(Const.PARSERCLASS);
                if (dataValueElem != null) {
                    jarFiles = new ArrayList<>();
                    dataValue = dataValueElem.getText();
                    
                    dataValueElem = parserElem.getChild(Const.JARFILESXML);
                    if (dataValueElem != null) {
                        elemList = dataValueElem.getChildren();
                        for (i = 0; i < elemList.size(); i++)
                        {
                            nextElem = (Element)elemList.get(i);
                            if (nextElem.getName().equals(Const.JARFILEXML)) {
                                jarFiles.add(nextElem.getText());
                            }
                        }
                    }
                    
                    parser = (ParserDef)LoadObject.loadObject(jarFiles, dataValue, new ArrayList<>());
                }
            }
            else {
                parser = Parsers.getParser(dataType);
            }

            //retrieve data value and parse if required
            dataValueElem = parseValueElem(dataXml);
            if (dataValueElem != null)
            {
                if (dataValueElem.hasChildren()) {
                    //assume complex type and try to parse
                    dataValueElem = dataValueElem.getElementChildAtIndex(0);

                    //only complex types require a parser
                    if ((parser != null) && (dataValueElem != null)) {
                        objInfo = parser.parse(dataValueElem);
                    }
                    else if (dataValueElem != null) {
                        objInfo = dataValueElem;
                    }
                }
                else {
                    //try to re-process the text description
                    dataValue = dataValueElem.getText();
                    try {
                        dataValueElem = XmlHandler.stringToElement(dataValue);
                    }
                    catch (Exception ex) {
                        dataFile = new File(dataValue);
                        if (dataFile.exists()) {
                            dataValue = FileLoader.getInputStream(dataValue).trim();
                            try {
                                dataValueElem = XmlHandler.stringToElement(dataValue);
                            }
                            catch (Exception ex2) {
                                dataValueElem = null;
                                objInfo = dataValue;
                            }
                        }
                        else {
                            dataValueElem = null;
                            objInfo = EvaluateBase.valueFromString(dataType, dataValue);
                        }
                    }

                    //only complex types require a parser
                    if ((parser != null) && (dataValueElem != null)) {
                        objInfo = parser.parse(dataValueElem);
                    }
                    else if (dataValueElem != null) {
                        objInfo = dataValueElem;
                    }
                }

                return true;
            }
            
            return false;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parseInfo",
                null, ex);
        }
    }
    
    /**
     * Get the currently loaded source information wrapped in an XML element.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * Can be null as not used in this version.
     * @return the value of the resource info as an XML element. This format is 
     * consistent with adding a {@code Data} element through an admin document.
     * @throws java.lang.Exception any error.
     */
    public Element getInfo(Element infoDescr) throws Exception
    {
        String objStr;                          //object as a string
        Element dataElem;                       //data element
        Element sourceInfo;                     //source info
        
        try
        {
            sourceInfo = XMLFactory.getInstance().createElement(Const.DATA);
            if (objInfo != null) 
            {
                if (ObjectHandler.isString(objInfo))
                {
                    sourceInfo = MetaFactory.getFactoryData().createDataTypeValue(dataType, (String)objInfo);
                }
                else if (ObjectHandler.isElement(objInfo))
                {
                    sourceInfo = MetaFactory.getFactoryData().createDataTypeValue(dataType, (Element)objInfo);
                }
                else if (objInfo instanceof ArrayList)
                {
                    sourceInfo = MetaFactory.getFactoryData().createDataTypeValue(dataType, (ArrayList)objInfo);
                }
                else
                {
                    if (parser != null) 
                    {
                        try 
                        {
                            dataElem = parser.serialize(objInfo);
                            sourceInfo = MetaFactory.getFactoryData().createDataTypeValue(dataType, dataElem);
                        }
                        catch (Exception ex) 
                        {
                            objStr = ObjectHandler.valueToString(dataType, objInfo);
                            sourceInfo = MetaFactory.getFactoryData().createDataTypeValue(dataType, objStr);
                        }
                    }
                    else
                    {
                        objStr = ObjectHandler.valueToString(dataType, objInfo);
                        sourceInfo = MetaFactory.getFactoryData().createDataTypeValue(dataType, objStr);
                    }
                }
            }
            
            return sourceInfo;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getInfo",
                null, ex);
        } 
    }
    
    /**
     * Get the value itself and not a wrapped description.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * Can be null as not used in this version.
     * @return the info value.
     * @throws java.lang.Exception any error.
     */
    public Object getValue(Element infoDescr) throws Exception
    {
        return objInfo;
    }
}
