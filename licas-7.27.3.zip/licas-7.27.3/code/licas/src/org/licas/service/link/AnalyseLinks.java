/*
 * AnalyseLinks.java
 *
 * Created on 7 August 2015
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.link;


import org.ai_heuristic.tree.TreeNode;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.query.LinkQueryConfig;
import org.licas.util.ObjectHandler;

import java.util.*;


/**
 * This class can perform some basic analysis over the link structures as follows:<br>
 * 1. If any links exist as part of the query then {@code exists} returns true.<br>
 * 2. If the links are ThresholdSource structures in a tree, then only the top level
 * is returned and the frequency count is the weight value for each source link.<br>
 * 3. If the links are Objects or Strings in a list or tree, then the frequency count 
 * is the number of times each link occurs, as part of the query reply.
 * @author Kieran Greer
 */
public class AnalyseLinks 
{
    /** For logging */
    private static final Logger logger;
    
    
    /** True if a link exists */
    private boolean exists;
    
    /** List of value counts */
    private HashMap<String, Float> valueCounts;
    
    /** List of best link references */
    private ArrayList<String> bestLinks;
    
     
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(AnalyseLinks.class.getName());
        logger.setDebug(false);
    }
    
    
    /** 
     * Create a new instance of AnalyseLinks.
     * @throws java.lang.Exception any error.
     */
    public AnalyseLinks() throws Exception
    {
        initialise();
    }
    
    /** 
     * Initialise some values.
     * @throws java.lang.Exception any error.
     */
    private void initialise() throws Exception
    {
        resetValues();
    }
    
    /** 
     * Reset for the start of an analysis.
     * @throws java.lang.Exception any error.
     */
    public void resetValues() throws Exception
    {
        exists = false;
        bestLinks = new ArrayList<>();
        valueCounts = new HashMap<>();
    }
    
    /**
     * Add analysis about the current set of tree nodes. The analysis is for
     * all of the calls to this method, without resetting the object. You can
     * also call {@code finaliseAnalysis} after these calls, to perform some stats
     * over the analysis objects.
     * @param treeNode the tree node to add the analysis for.
     * @param queryConfig the query configuration.
     * @throws java.lang.Exception any error.
     */
    public void analyseLinks(TreeNode treeNode, LinkQueryConfig queryConfig) throws Exception
    {
        int i;
        boolean isOK;                           //true if OK
        String nextKey;                         //next key
        ArrayList<Object> links;                //list of linked objects
        TreeNode nextSources;                   //next sources
        Object nextObj;                         //next object
        
        try
        {
            isOK = true;
            links = new ArrayList<>();
            valueCounts = new HashMap<>();
            nextSources = treeNode;

            if (queryConfig.maxNumber <= 0) {
                queryConfig.maxNumber = Integer.MAX_VALUE;
            }
            if (queryConfig.conceptList == null) {
                queryConfig.conceptList = new ArrayList<>();
            }

            for (i = 0; isOK && (i < queryConfig.conceptList.size()); i++)
            {
                nextObj = queryConfig.conceptList.get(i);
                nextKey = ObjectHandler.getKey(nextObj);

                if (nextSources.hasChildNode(nextKey)) {
                    nextSources = (TreeNode) nextSources.getChildNode(nextKey);
                }
                else {
                    isOK = false;
                }
            }

            //add all link threshold structures and then sort for top x number
            if (isOK) {
                getLinkThreshold(nextSources, links);
                bestLinks = linkCounts(links, queryConfig);
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "analyseLinks",
                null, ex);
        }
    }
    
    /**
     * Add analysis about the current set of link reference values. The analysis is for
     * all of the calls to this method, without resetting the object. You can
     * also call {@code finaliseAnalysis} after these calls, to perform some stats
     * over the analysis objects.
     * @param links list of link reference values, probably of type String.
     * @param queryConfig the query configuration.
     * @throws java.lang.Exception any error.
     */
    public void analyseLinks(ArrayList<?> links, LinkQueryConfig queryConfig) throws Exception
    {
        try {
            if (links != null) {
                exists = true;
                bestLinks = linkCounts(links, queryConfig);
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "analyseLinks",
                null, ex);
        }
    }
    
    /**
     * Calculate the frequency counts for similar link values over the tree.
     * @param links list of links to analyse, no tree direct link list.
     * @param queryConfig query configuration for maximum numbers.
     * @throws java.lang.Exception any error.
     */
    private ArrayList<String> linkCounts(ArrayList<?> links, LinkQueryConfig queryConfig)
        throws Exception
    {
        int i;
        int bestIndex;                          //best index
        float linkValue;                        //link value
        float bestValue;                        //best value
        String linkSource;                      //link source as string
        
        try
        {
            while ((valueCounts.size() < queryConfig.maxNumber) && !links.isEmpty())
            {
                bestIndex = -1;
                bestValue = Float.MIN_VALUE;
                
                for (i = 0; i < links.size(); i++)
                {
                    linkSource = getSource(links.get(i));
                    linkValue = getCount(links.get(i));
                    
                    if (valueCounts.containsKey(linkSource)) {
                        linkValue += valueCounts.get(linkSource);
                    }
                    
                    if (linkValue > bestValue) {
                        bestValue = linkValue;
                        bestIndex = i;
                    }
                }
                
                if (bestIndex >= 0) {
                    linkSource = getSource(links.remove(bestIndex));
                    valueCounts.put(linkSource, bestValue);
                }
                else {
                    break;
                }
            }
            
            return new ArrayList<>(valueCounts.keySet());
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "linkCounts",
                null, ex);
        }
    }

    /**
     * Retrieve all threshold structures in all (sub)trees starting with this one.
     * @param rootNode the tree to start from.
     * @param linkList the list to add the structures to.
     * @throws java.lang.Exception any error.
     */
    private void getLinkThreshold(TreeNode rootNode, ArrayList<Object> linkList) throws Exception
    {
        TreeNode nextTreeNode;                  //next tree node
        Thresholds nextThresholds;              //next set of linkSpec
        Object nextObj;                         //next object
        
        nextObj = rootNode.getValue();    
        if (nextObj != null) {
            if (nextObj instanceof Thresholds) {
                nextThresholds = (Thresholds)nextObj;
                linkList.addAll(nextThresholds.linkValues.values());
            }
            else {
                linkList.add(ObjectHandler.getValue(nextObj));
            }
        }
        
        for (String key: rootNode.getChildNodeKeys())
        {
            nextTreeNode = (TreeNode) rootNode.getChildNode(key);
            getLinkThreshold(nextTreeNode, linkList);
        }
    }
    
    /**
     * Get the string-based description for the link source.
     * @param sourceObj the source, may be {@link ThresholdSource} or maybe a string.
     * @return string-based representation of the link source.
     * @throws java.lang.Exception any error.
     */
    private String getSource(Object sourceObj) throws Exception
    {
        if (sourceObj != null) {
            if (sourceObj instanceof ThresholdSource) {
                return ObjectHandler.getValue(((ThresholdSource)sourceObj).source);
            }
            else {
                return ObjectHandler.getValue(sourceObj);
            }
        }
        
        return null;
    }
    
    /**
     * Get the frequency count for the link source.
     * @param sourceObj the source, may be {@link ThresholdSource} or maybe a string.
     * @return frequency count - weight value, or 1.0 for string instance.
     */
    private float getCount(Object sourceObj)
    {
        if (sourceObj != null) {
            if (sourceObj instanceof ThresholdSource) {
                return ((ThresholdSource)sourceObj).value;
            }
            else {
                return (float)1.0;
            }
        }
        
        return 0;
    }
    
    /**
     * Return true if a link exists anywhere in the analysis.
     * @return the value of exists.
     */
    public boolean exists()
    {
        return exists;
    }
    
    /**
     * Get the best reference link(s) over the analysis query.
     * @return the value of {@code bestLinks} reference sources.
     */
    public ArrayList<String> getBestLinks()
    {
        return bestLinks;
    }
    
    /**
     * Get the unprocessed list of reference objects, with a count of occurrences for each one.
     * @return the value of valueCounts.
     */
    public HashMap<String, Float> getValueCounts()
    {
        return valueCounts;
    }
    
    /**
     * Convert the values into a string-based description.
     * @return a String-based description of this object.
     */
    public String toString()
    {
        int i;
        float floatValue;                   //float value
        StringBuilder descr;                //analysis description

        descr = new StringBuilder("Best links:\n");
        if (bestLinks != null) {
            for (i = 0; i < bestLinks.size(); i++)
            {
                descr.append(bestLinks.get(i)).append("\n");
            }
        }
        descr.append("\nLink counts:\n");

        if (valueCounts != null) {
            for (String key: valueCounts.keySet())
            {
                floatValue = valueCounts.get(key);
                descr.append(key).append(": ").append(String.valueOf(floatValue)).append("\n");
            }
        }
        
        return descr.toString();
    }
}
