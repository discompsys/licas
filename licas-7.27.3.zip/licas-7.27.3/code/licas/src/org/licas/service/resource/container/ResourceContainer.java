/*
 * ResourceContainer.java
 *
 * Created on 8 April 2014
 *
 * Version 1.4.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.resource.container;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.service.resource.Resource;
import org.licas.util.Const;
import org.licas.util.TypeConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Vector;


/**
 * This can be used to store an array or set of {@link Resource} derived objects that 
 * can then be invoked upon request. The resource objects do not have to be of the same
 * type and it is their {@code getInfo} or {@code getValue} methods that are invoked. 
 * A container might be initialised with a script that includes the details of the stored 
 * resources. 
 * <br>
 * To create the script, for example, you might use {@code MetaFactory.getFactoryData().createResourceContainerXML(containerType)}
 * and then add to the element: {@code containerXml.valueXml.addContent(MetaFactory.getFactoryData().createDataValueXML(dataType, infoData))}.
 * <br>
 * You can also create an empty list and add resources manually to it.
 * @author Kieran Greer
 */
public abstract class ResourceContainer extends Resource
{
    /** The logger */
    private static final Logger logger;
    
    
    /** The object-based information */
    protected LinkedHashMap<String, Resource> resourceList;
    
        
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ResourceContainer.class.getName());
        logger.setDebug(false);
    }

    
    /**
     * Create a new instance of ResourceContainer.
     * @param theDataType the container type.
     * @throws java.lang.Exception any error.
     */
    public ResourceContainer(String theDataType) throws Exception
    {
        super(theDataType);
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        resourceList = new LinkedHashMap<>();
    }
    
    /**
     * Parse the data description in the admin document to create the data object.
     * @param dataXml the {@code Data} element of the admin document. This should include
     * the container {@code DataType} element and a {@code Value} element that stores 
     * a list of child {@code Data} elements that store information for each resource to create. 
     * These are processed as defined in the individual resource object comments.
     * @return true if any specified resources are successfully added, false otherwise.
     * @throws java.lang.Exception any error.
     */
    protected boolean parseInfo(Element dataXml) throws Exception
    {
        int i;
        String infoDataType;                        //info data type
        Element infoElem;                           //next info element
        Element typeElem;                           //data type element
        Element valueElem;                          //value element
        Vector<Node> elemList;                      //child elements
        Resource infoResource;                      //info resource

        if (dataXml != null) {
            setUUID(dataXml);

            valueElem = parseValueElem(dataXml);
            if (valueElem != null) {
                elemList = valueElem.getChildren();

                for (i = 0; i < elemList.size(); i++) {
                    infoElem = (Element) elemList.get(i);

                    if (infoElem.getName().equals(Const.DATA)) {
                        typeElem = infoElem.getChild(Const.DATATYPE);

                        if (typeElem != null) {
                            infoDataType = typeElem.getText();
                            infoResource = Resource.createResource(infoDataType, infoElem);
                            if (infoResource != null) {
                                resourceList.put(infoResource.getUUID(), infoResource);
                            }
                            else {
                                return false;
                            }
                        }
                    }
                }
            }
        }
        
        return true;
    }
    
    /**
     * Get a list of IDs used to identify each resource in the container.
     * @return a list of ids to identify each resource in the container.
     */
    public ArrayList<String> getResourceIDs()
    {
        ArrayList<String> resourceIDs;                  //resource ids

        resourceIDs = new ArrayList<>(resourceList.keySet());
        return resourceIDs;
    }

    /**
     * Add a new resource. Use its uuid as the key.
     * @param resource the resource to add.
     * @return true if added, false if the key already exists.
     */
    public boolean addResource(Resource resource)
    {
        if (!resourceList.containsKey(resource.getUUID())) {
            resourceList.put(resource.getUUID(), resource);
            return true;
        }

        return false;
    }

    /**
     * Get the resource relating to the key identifier.
     * @param key unique uuid identifier for the resource.
     * @return the related resource or null if one does not exist.
     */
    public Resource getResource(String key)
    {
        if ((resourceList != null) && resourceList.containsKey(key)) {
            return resourceList.get(key);
        }

        return null;
    }

    /**
     * Remove the resource relating to the key identifier.
     * @param key unique uuid identifier for the resource.
     * @return true if removed or false if one does not exist.
     */
    public boolean removeResource(String key)
    {
        if ((resourceList != null) && resourceList.containsKey(key)) {
            resourceList.remove(key);
            return true;
        }

        return false;
    }
    
    /**
     * Create a resource container object and return. The resource that is created
     * is selected automatically from the data type and so is a best match guess.
     * @param dataType the type of container to create, for example:
     * {@link TypeConst}.{@code IDCONTAINER}, {@code RANDOMCONTAINER} or {@code QUERYCONTAINER}.
     * @param dataXml a description of the initialisation parameters. Can be null.
     * @return a matched info resource or null if the type is not recognised.
     * @throws java.lang.Exception any error.
     */
    public static Resource createContainer(String dataType, Element dataXml)
            throws Exception
    {
        Resource infoResource;                  //the info resource
        
        infoResource = null;
        if (dataType.equalsIgnoreCase(TypeConst.LISTCONTAINER)) {
            infoResource = new ListContainer(dataType, dataXml);
        }
        else if (dataType.equalsIgnoreCase(TypeConst.RANDOMCONTAINER)) {
            infoResource = new RandomContainer(dataType, dataXml);
        }
        else if (dataType.equalsIgnoreCase(TypeConst.QUERYCONTAINER)) {
            infoResource = new QueryContainer(dataType, dataXml);
        }
        
        return infoResource;
    }
}
