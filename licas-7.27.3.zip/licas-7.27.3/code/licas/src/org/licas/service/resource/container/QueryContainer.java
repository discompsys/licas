/*
 * QueryContainer.java
 *
 * Created on 9 April 2014
 *
 * Version 1.3.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.resource.container;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.service.resource.Resource;
import org.licas.util.Const;
import org.licas.util.classloader.LoadObject;
import org.licas.util.exception.LicasException;
import org.licas_text.def.QueryDef;
import org.licas_text.query.QueryMediator;
import org.licas_text.query.model.QueryModel;
import org.licas_text.util.QueryConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;


/**
 * This can be used to store an array or set of {@link Resource} derived objects and 
 * return the details of any of them that match a query specification. To do this,
 * the container uses a QueryDef derived query engine to evaluate the query expression,
 * of type {@link QueryMediator}.
 * <p>
 * It uses the definition's {@code executeQueryModel} method on the contents of each resource.
 * The query itself is sent as an XML-script that is a parsed version of the {@code licas_text}
 * package {@code QueryModel}. You can use the related {@code QueryParser} to parse to or from XML.
 * <p>
 * Alternatively, you can write your own query engine, that implements {@code QueryDef}, pass
 * the class name as part of the constructor script {@code Value} element and it will be created instead.
 * If you then add your own parser for a new query model, or still use the existing one,
 * you can perform your own evaluations.
 * @author Kieran Greer
 */
public class QueryContainer extends ResourceContainer
{
    /** The logger */
    private static final Logger logger;
    
    
    /** Query engine */
    private QueryDef queryEngine;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(QueryContainer.class.getName());
        logger.setDebug(false);
    }

    
    /**
     * Create a new instance of QueryContainer.
     * @param theDataType the container type.
     * @throws java.lang.Exception any error.
     */
    public QueryContainer(String theDataType) throws Exception
    {
        super(theDataType);
        initialise(null);
    }

    /**
     * Create a new instance of QueryContainer.
     * @param theDataType the container type.
     * @param dataXml a description of the initialisation parameters.
     * @throws java.lang.Exception any error.
     */
    public QueryContainer(String theDataType, Element dataXml) throws Exception
    {
        super(theDataType);
        initialise(dataXml);
    }
    
    /** 
     * Initialise some values.
     * @param dataXml a description of the initialisation parameters.
     * @throws java.lang.Exception any error.
     */
    private void initialise(Element dataXml) throws Exception
    {
        if (dataXml != null)
        {
            if (!parseInfo(dataXml))
            {
                throw new LicasException("Could not parse the data description");
            }
        }
    }
    
    /**
     * Parse the data description in the admin document to create the data object.
     * @param dataXml the {@code Data} element of the admin document. This should include
     * the container {@code DataType} element and a {@code Value} element that stores 
     * a list of child {@code Data} elements that store information for each resource to create. 
     * The {@code Value} element can also optionally store a different query engine type.
     * This would be the class name and is assumed to be from a local jar file.
     * It would be stored in another {@code Value} element that could be created using 
     * {@code MetaFactory.addXML(adminData, (MetaFactory.createMetaValueXML(Const.VALUE, query-engine-class),
     * Const.VALUE)}, for example.
     * @return true if any specified resources are successfully added, false otherwise.
     * @throws java.lang.Exception any error.
     */
    protected boolean parseInfo(Element dataXml) throws Exception
    {
        String infoValue;                           //info value
        Element valueElem;                          //next info element
        
        setUUID(dataXml);
            
        valueElem = parseValueElem(dataXml);
        if (valueElem != null)
        {
            valueElem = valueElem.getChild(Const.VALUE);
            if (valueElem != null)
            {
                infoValue = valueElem.getText();
                queryEngine = (QueryDef)LoadObject.loadObject(null, infoValue, new ArrayList<>());
            }
            else
            {
                queryEngine = new QueryMediator();
            }
        }
        else
        {
            queryEngine = new QueryMediator();
        }
        
        return super.parseInfo(dataXml);
    }
    
    /**
     * Get the source information wrapped in an XML element.
     * @param infoDescr a description of the query to execute on each resource. The
     * {@link QueryModel} is used as default.
     * @return the query reply value.
     * @throws java.lang.Exception any error.
     */
    public Element getInfo(Element infoDescr) throws Exception
    {
        int i;
        ArrayList<Object> valueList;                //value list
        Object value;                               //the resource value
        Element sourceInfo;                         //source info
        Element queryInfo;                          //all query info
        Element queryReply;                         //query reply
        ListContainer listContainer;                //list container
        
        try {
            //retrieve values
            listContainer = new ListContainer(this.dataType, null);
            listContainer.resourceList = (LinkedHashMap)this.resourceList.clone();
            valueList = listContainer.getValue(null);
            
            //execute query on each value
            sourceInfo = XMLFactory.getInstance().createElement(Const.DATA);          
            queryInfo = XMLFactory.getInstance().createElement(QueryConst.QUERYREPLY);
            sourceInfo.addContent(queryInfo);
            
            if (valueList != null) {
                for (i = 0; i < valueList.size(); i++)
                {
                    value = valueList.get(i);
                    queryReply = queryEngine.executeQuery(infoDescr, value);
                    if (queryReply != null) queryInfo.addContent(queryReply);
                }
            }
            
            return sourceInfo;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getInfo",
                null, ex);
        } 
    }
    
    /**
     * Get the currently selected value itself and not a wrapped description. For a
     * query container, this is in fact the same operation as {@code getInfo} and returns
     * the same query reply {@code Element}.
     * @param infoDescr a description of the query to execute on the resources. The
     * {@link QueryModel} is used as default.
     * @return the query reply value.
     * @throws java.lang.Exception any error.
     */
    public Object getValue(Element infoDescr) throws Exception
    {
        try
        {
            return getInfo(infoDescr);
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getValue",
                null, ex);
        }
    }
}
