/**
 * Application-specific base or fully implemented services, including factory classes for describing them.
 */
package org.licas.service;