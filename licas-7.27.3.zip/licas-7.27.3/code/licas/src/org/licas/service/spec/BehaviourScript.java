/*
 * BehaviourScript.java
 *
 * Created on 18 June 2012
 *
 * Version 1.2.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.spec;


import org.licas.PasswordHandler;


/**
 * This class reads an XML file and loads in a specification for a set of test runs.
 * @author Kieran Greer
 */
public class BehaviourScript extends ServiceSpec
{
    /** Can be a behaviour or a problem solver script by default */
    public String scriptType;
    
    /** Minimum value */
    public int minValue;
    
    /** Maximum value */
    public int maxValue;
    
    
    /** 
     * Create a new instance of BehaviourScript.
     * @param thePasswordHandler for storing passwords.
     */
    public BehaviourScript(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        scriptType = null;
        minValue = 0;
        maxValue = 0;  
    }
    
    /**
     * Validate the whole script and return a description of any errors.
     * @return a description of any errors or null if OK.
     */
    public String validateScript()
    {
        String validateReply;                   //validation errors
        String nextValidateReply;               //next validation reply
        
        validateReply = "";
        nextValidateReply = serverSpec.validateScript();
        if (nextValidateReply != null) validateReply += nextValidateReply;
        
        if (createServices) {
            nextValidateReply = linkSpec.validateScript();
            if (nextValidateReply != null) validateReply += nextValidateReply;
        }
        
        nextValidateReply = super.validateScript();
        if (nextValidateReply != null) validateReply += nextValidateReply;

        validateReply = validateReply.trim();
        if (validateReply.equals("")) validateReply = null;
        return validateReply;
    }
    
    /**
     * Validate the script variable and return a description if invalid.
     * @param varType the variable type.
     * @return a description of any error, of null if OK.
     */
    protected String validateVariable(String varType)
    {
        String validateError;                   //validate error
        
        validateError = serverSpec.validateVariable(varType);
        if ((validateError == null) | validateError.equals("")) {
            validateError = linkSpec.validateVariable(varType);

            if ((validateError == null) | validateError.equals("")) {
                validateError = super.validateVariable(varType);
            }
        }
        
        return validateError;
    }
}
