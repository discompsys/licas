/*
 * WorkInfo.java
 *
 * Created on 5 February 2018
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.model;


import org.licas.call.MethodInfo;
import org.licas.def.ContractDef;


/**
 * This provides a description of some work that a service can carry out or request.
 * @author Kieran Greer
 */
public class WorkInfo 
{
    public static final int POINTPOINT = 0;
    public static final int SUBSCRIBE = 1;
    public static final int BOTH = 2;

    /** Type of work protocol for the service - point-to-point, subscribe, or both */
    public int workProtocol;

    /** The info to publish */
    public String info;

    /** Keywords list to describe the service */
    public KeywordInfo keywordInfo;

    /** Description of the method and location for the service */
    public MethodInfo methodInfo;
    
    /** Optional contract terms for negotiating with. Defaults to 'Yes' contract. */
    public ContractDef contract;

    /** Matching score if relevant */
    public float score;


    /**
     * Create a new instance of WorkInfo.
     * Work protocol defaults to {@code SUBSCRIBE}.
     */
    public WorkInfo()
    {
        workProtocol = SUBSCRIBE;
        info = null;
        keywordInfo = null;
        methodInfo = null;
        contract = Contract.getYesContract();
        score = (float)0.0;
    }

    /**
     * Return true if the work protocol allows point-to-point, direct call on the service ID.
     * @return true if point-to-point or both.
     */
    public boolean isPtP() {
        return ((workProtocol == POINTPOINT) || (workProtocol == BOTH));
    }

    /**
     * Return true if the work protocol allows subscribe, call on a service type.
     * @return true if subscribe or both.
     */
    public boolean isSubscribe() {
        return ((workProtocol == SUBSCRIBE) || (workProtocol == BOTH));
    }
}
