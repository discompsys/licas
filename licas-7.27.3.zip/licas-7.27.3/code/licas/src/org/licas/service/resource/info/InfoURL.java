/*
 * InfoURL.java
 *
 * Created on 10 November 2013
 *
 * Version 1.4.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.resource.info;


import org.licas.meta.MetaFactory;
import org.licas.service.InformationService;
import org.licas.service.resource.Resource;
import org.licas.util.*;
import org.licas.util.exception.LicasException;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.net.MalformedURLException;
import java.net.URL;


/**
 * This is used by the {@link InformationService} to store and parse a remote file location.
 * The URL link to the file is stored, where the link contents are returned upon request.
 * If the action is stored as {@link AiConst}.{@code LOADREMOTE} then the contents are
 * dynamically retrieved upon request, but if the action is stored as {@code LOADCONTENTS} 
 * then the contents are stored once during initialisation and retrieved locally.
 * @author Kieran Greer
 */
public class InfoURL extends Resource
{
    /** The logger */
    private static final Logger logger;
    
    
    /** The URL address */
    protected URL url;
       
    /** The url data */
    protected FileObject urlData;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(InfoURL.class.getName());
        logger.setDebug(false);
    }

    
    /**
     * Create a new instance of InfoURL.
     * @param theDataType the resource data type.
     * @param dataXml a description of the initialisation parameters. Can be null.
     * @throws java.lang.Exception any error.
     */
    public InfoURL(String theDataType, Element dataXml) throws Exception
    {
        super(theDataType);
        url = null;
        urlData = new FileObject();
        urlData.setAsBytes(TypeConst.isBinaryType(theDataType));

        if ((dataXml != null) && !parseInfo(dataXml)) {
            throw new LicasException("Could not parse the data description.");
        }
    }
    
    /**
     * Parse the data description in the document to create the data object.
     * This version should read a URL address and store that. It also only returns the 
     * URL address upon request.
     * @param dataXml this must include a {@code VALUE} element that stores a String-based 
     * URL path description. It can also contain an {@link AiConst}.{@code ACTION}
     * element, which can be set to {@code LOADREMOTE} to ask the URI and not the actual 
     * contents to be stored.
     * @return true if the file was successfully loaded, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean parseInfo(Element dataXml) throws Exception
    {
        String actionType;                          //the type of action
        Element dataValueElem;                      //data value element
        
        try {
            setUUID(dataXml);

            dataValueElem = parseValueElem(dataXml);
            if (dataValueElem != null) {
                try {
                    url = new URL(dataValueElem.getText());
                }
                catch (MalformedURLException muex) {
                    url = new URL(UriHandler.addLocalFileUriPrefix(dataValueElem.getText()));
                    dataValueElem.setText(url.toExternalForm());
                }
                
                if (url != null) {
                    dataValueElem = dataXml.getChild(AiConst.ACTION);       
                    if (dataValueElem != null) {
                        actionType = dataValueElem.getText();
                        if (actionType.equalsIgnoreCase(AiConst.LOADREMOTE)) {
                            urlData.setFilePath(url.toExternalForm());
                        }
                        else {
                            urlData.loadFile(url.toExternalForm());
                        }

                    }
                    else {
                        urlData.loadFile(url.toExternalForm());
                    }

                    return true;
                }
            }

            return false;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parseInfo",
                null, ex);
        }
    }
    
    /**
     * Get the url address.
     * @return the value of {@code url.toExternalForm()}.
     */
    public String getURL()
    {
        return url.toExternalForm();
    }
    
    /**
     * Get the currently loaded source information wrapped in an XML element.
     * This is the whole unparsed URL document.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * Can be null, or it can include an {@link AiConst}.{@code ACTION} element, which can 
     * be set to {@code LOADREMOTE} to ask the URI and not the actual contents to be stored.
     * @return the value of the resource info as an XML element. This format is 
     * consistent with adding a 'Data' element through an admin document.
     * HTML description is coded, so probably need to use XmlHandler.removeStringSpec(...) 
     * after retrieving the XML 'Data' element's text content on the client side.
     * @throws java.lang.Exception any error.
     */
    public Element getInfo(Element infoDescr) throws Exception
    {
        String fileContents;                        //file contents
        Element sourceInfo;                         //source info
        
        try {
            sourceInfo = XMLFactory.getInstance().createElement(Const.DATA);
            fileContents = (String)getValue(infoDescr);

            if (fileContents != null) {
                sourceInfo = MetaFactory.getFactoryData().createDataTypeValue(dataType, fileContents);
            }
            
            return sourceInfo;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getInfo",
                null, ex);
        } 
    }
    
    /**
     * Get the value itself and not a wrapped description. This is the URL address
     * as a string.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * Can be null, or it can include an {@link AiConst}.{@code ACTION} element, which can 
     * be set to {@code LOADREMOTE} to ask the URI and not the actual contents to be stored.
     * @return the info value.
     * @throws java.lang.Exception any error.
     */
    public Object getValue(Element infoDescr) throws Exception
    {
        String fileContents;                        //file contents
        String actionType;                          //action type
        Element dataValueElem;                      //data value element
        ByteArray byteArray;                        //byte array as a string
        
        try {
            //default is to store the URL and read remotely
            actionType = AiConst.LOADREMOTE;
            if (infoDescr != null) {
                dataValueElem = infoDescr.getChild(AiConst.ACTION);

                if (dataValueElem != null) {
                    actionType = dataValueElem.getText();
                }
            }
              
            if (actionType.equalsIgnoreCase(AiConst.LOADREMOTE)) {
                fileContents = getURL();
            }
            else {
                if (urlData.getFilePath() == null) {
                    urlData.loadFile(url.toExternalForm());
                }

                byteArray = (ByteArray)urlData.getFileContents();
                fileContents = byteArray.getByteArray().trim();
            }
            
            return fileContents;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getValue",
                null, ex);
        }
    }
}
