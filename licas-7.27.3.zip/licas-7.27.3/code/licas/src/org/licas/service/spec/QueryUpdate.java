/*
 * QueryUpdate.java
 *
 * Created on 1 August 2013
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.spec;


import java.util.ArrayList;


/**
 * A specification for updating service details from query results.
 * @author Kieran Greer
 */
public class QueryUpdate 
{
    /** List of local 'local-remote-both' value */
    public int localLrb;
    
    /** List of remote 'local-remote-both' value */
    public int remoteLrb;
    
    /** List of local update methods */
    public ArrayList<String> localUpdates;
    
    /** List of remote update methods */
    public ArrayList<String> remoteUpdates;
    
    /** List of local URIs */
    public ArrayList<String> localURIs;
    
    /** List of remote URIs */
    public ArrayList<String> remoteURIs;
    
    /** Create a new instance of QueryUpdate */
    public QueryUpdate()
    {
        localLrb = -1;
        remoteLrb = -1;
        localUpdates = new ArrayList<>();
        remoteUpdates = new ArrayList<>();
        localURIs = new ArrayList<>();
        remoteURIs = new ArrayList<>();
    }
}
