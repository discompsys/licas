/**
 * Linking-related classes and services, including the original dynamic linking mechanism, 
 * with 3-level structure, thresholds, memory control and linking options.
 */
package org.licas.service.link;