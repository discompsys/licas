/*
 * InfoBinary.java
 *
 * Created on 3 February 2014
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.resource.info;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.meta.MetaFactory;
import org.licas.service.InformationService;
import org.licas.service.resource.Resource;
import org.licas.util.AiConst;
import org.licas.util.ByteArray;
import org.licas.util.Const;
import org.licas.util.FileObject;
import org.licas.util.exception.LicasException;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;


/**
 * This is used by the {@link InformationService} to store any binary Object directly.
 * It might be used particularly for binary files, for example.
 * @author Kieran Greer
 */
public class InfoBinary extends Resource
{
    /** The logger */
    private static final Logger logger;
    
     
    /** The binary data */
    private final FileObject binaryData;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(InfoBinary.class.getName());
        logger.setDebug(false);
    }

    
    /**
     * Create a new instance of InfoBinary.
     * @param theDataType the resource data type.
     * @param dataXml a description of the initialisation parameters. Can be null.
     * @throws java.lang.Exception any error.
     */
    public InfoBinary(String theDataType, Element dataXml) throws Exception
    {
        super(theDataType);
        binaryData = new FileObject();

        if ((dataXml != null) && !parseInfo(dataXml)) {
            throw new LicasException("Could not parse the data description.");
        }     
    }
    
    /**
     * Parse the data description in the data description document to create the data object.
     * This version should read a file path. It can then either load in the contents
     * or reference it dynamically.
     * @param dataXml the outermost element is not checked for, but might be a {@code DATA} 
     * or {@code DATASET} element. This should include a {@link Const}.{@code VALUE} element
     * that stores a String-based file path description and possibly an {@code ACTION} element
     * that can define if the data is stored in the resource or dynamically retrieved upon request
     * through {@code <Data><Value>file path</Value><Action>the action</Action></Data>}.
     * The action ({@link AiConst}.{@code LOADREMOTE}) stores the file path to dynamically
     * retrieve the data upon request. Anything else, including no action, loads the data
     * into the resource as binary contents. 
     * @return true if the file was successfully loaded, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean parseInfo(Element dataXml) throws Exception
    {
        String filePath;                            //the file path
        String actionType;                          //the type of action
        Element dataValueElem;                      //data value element
        
        try {
            setUUID(dataXml);
            
            dataValueElem = parseValueElem(dataXml);
            if (dataValueElem != null) {
                filePath = dataValueElem.getText();

                if (filePath != null) {
                    if (FileObject.isKnownFile(filePath) && FileObject.isBinaryFile(filePath)) {
                        dataValueElem = dataXml.getChild(AiConst.ACTION);

                        if (dataValueElem != null) {
                            actionType = dataValueElem.getText();

                            if (actionType.equalsIgnoreCase(AiConst.LOADREMOTE)) {
                                binaryData.setFilePath(filePath);
                            }
                            else {
                                binaryData.loadFile(filePath);
                            }

                        }
                        else {
                            binaryData.loadFile(filePath);
                        }

                        return true;
                    }  
                }
            }

            return false;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parseInfo",
                null, ex);
        }
    }
    
    /**
     * Get the currently loaded source information wrapped in an XML element.
     * This is still Base64 encoded.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * Can be null as not used in this version.
     * @return the value of the resource info as an XML element. This format is 
     * consistent with adding a {@code Data} element through an admin document. The
     * binary data is stored as a {@link ByteArray} tokenised String and not a {@code byte[]}. It
     * can be converted into a byte[] for display, by using the ByteArray {@code toBytes} method.
     * @throws java.lang.Exception any error.
     */
    public Element getInfo(Element infoDescr) throws Exception
    {
        ByteArray byteArray;                        //byte array as a string
        Element sourceInfo;                         //source info
        
        try {
            sourceInfo = XMLFactory.getInstance().createElement(Const.DATA);
            if (binaryData != null) {
                byteArray = (ByteArray)binaryData.getFileContents();  
                sourceInfo = MetaFactory.getFactoryData().createDataTypeValue(dataType, byteArray.getByteArray());
            } 
            
            return sourceInfo;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getInfo",
                null, ex);
        } 
    }
    
    /**
     * Get the value itself and not a wrapped description. This is still Base64 encoded.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * Can be null as not used in this version.
     * @throws java.lang.Exception any error.
     */
    public Object getValue(Element infoDescr) throws Exception
    {
        ByteArray byteArray;                        //byte array as a string
        
        byteArray = (ByteArray)binaryData.getFileContents();
        return byteArray.getByteArray();
    }
}
