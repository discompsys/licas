/*
 * Contract.java
 *
 * Created on 13 November 2012
 *
 * Version 1.0.3
 *
 * Copyright (c) 2011 Kieran Greer
 */


package org.licas.service.model;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.def.ContractDef;
import org.licas.util.MetaConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.Vector;


/**
 * Default contract class. This is essentially a wrapper for an arbitrary XML-based 
 * description that should also contain certain standard elements. A contract is a 
 * description of an agreement between services, typically to allow access to a 
 * service through passwords and/or to actually carry out the service in question. 
 * The process is service-specific, but this version also offers default 'yes', 'no' 
 * and 'true' contracts that can be used to tell the server, or a service, to automatically 
 * return its password, or to refuse and require the client to know what the correct 
 * password is.
 * @author Kieran Greer
 */
public class Contract implements ContractDef
{
    /** For logging */
    private static final Logger logger;
    
    /** The service or negotiation contract */
    protected Element contract;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(Contract.class.getName());
        logger.setDebug(false);
    }
    
    /** 
     * Create a new instance of Contract.
     * @param theContract the contract description. This can take any form and 
     * so is represented by an XML element only.
     */
    public Contract(Element theContract)
    {
        contract = theContract;
    }
    
    /**
     * Get the negotiation or service contract information.
     * @return the value of contract.
     */
    public Element getContract()
    {
        return contract;
    }
    
    /**
     * Get the negotiation or service contract information.
     * @return the value of contract.
     */
    public Element toXml()
    {
        return contract;
    }
    
    /**
     * Return true if the contract is a default 'yes' contract.
     * @param theContract the contract to evaluate.
     * @return true if a default yes contract.
     */
    public static boolean isYesContract(Contract theContract)
    {
        boolean isYes;                          //true if yes contract
        Element nextElem;                       //next element
        Element yesInfo;                        //yes info
        
        isYes = true;
        nextElem = null;
        yesInfo = theContract.getContract();
        
        if (isYes) {
            nextElem = yesInfo.getChild(MetaConst.POLICY);
            isYes = (nextElem != null);
        }
        
        if (isYes) {
            isYes = nextElem.getText().equals(MetaConst.ALLCONTRACTSCODE);
        }
        
        if (isYes) {
            nextElem = yesInfo.getChild(MetaConst.SERVICELEVEL);
            isYes = (nextElem != null);
        }
        
        if (isYes) {
            isYes = nextElem.getText().equals(MetaConst.ALLCONTRACTSCODE);
        }
        
        if (isYes) {
            nextElem = yesInfo.getChild(MetaConst.CONTRACTEVALUATION);
            isYes = (nextElem != null);
        }
        
        if (isYes) {
            isYes = nextElem.getText().equals(MetaConst.CONTRACTOK);
        }
        
        return isYes;
    }
    
    /**
     * Return true if the contract is a default 'no' contract.
     * @param theContract the contract to evaluate.
     * @return true if a default no contract.
     */
    public static boolean isNoContract(Contract theContract)
    {
        boolean isNo;                           //true if no contract
        Element nextElem;                       //next element
        Element noInfo;                         //no info
        
        isNo = true;
        nextElem = null;
        noInfo = theContract.getContract();
        
        if (isNo) {
            nextElem = noInfo.getChild(MetaConst.POLICY);
            isNo = (nextElem != null);
        }
        
        if (isNo) {
            isNo = nextElem.getText().equals(MetaConst.ALLCONTRACTSCODE);
        }
        
        if (isNo) {
            nextElem = noInfo.getChild(MetaConst.SERVICELEVEL);
            isNo = (nextElem != null);
        }
        
        if (isNo) {
            isNo = nextElem.getText().equals(MetaConst.ALLCONTRACTSCODE);
        }
        
        if (isNo) {
            nextElem = noInfo.getChild(MetaConst.CONTRACTEVALUATION);
            isNo = (nextElem != null);
        }
        
        if (isNo) {
            isNo = nextElem.getText().equals(MetaConst.CONTRACTNOTOK);
        }
        
        return isNo;
    }
    
    /**
     * Create and return a negotiation or service contract that always returns 'yes'.
     * @return a default constructed new contract.
     */
    public static Contract getYesContract()
    {
        Element nextElem;                       //next element
        Element yesInfo;                        //yes info
        Contract yesContract;                   //yes contract
        
        yesInfo = XMLFactory.getInstance().createElement(MetaConst.SERVICELEVELCONTRACT);
        nextElem = XMLFactory.getInstance().createElement(MetaConst.POLICY);
        nextElem.setText(MetaConst.ALLCONTRACTSCODE);
        yesInfo.addContent(nextElem);
        
        nextElem = XMLFactory.getInstance().createElement(MetaConst.SERVICELEVEL);
        nextElem.setText(MetaConst.ALLCONTRACTSCODE);
        yesInfo.addContent(nextElem);
        
        nextElem = XMLFactory.getInstance().createElement(MetaConst.CONTRACTEVALUATION);
        nextElem.setText(MetaConst.CONTRACTOK);
        yesInfo.addContent(nextElem);
        
        yesContract = new Contract(yesInfo);
        return yesContract;
    }
    
    /**
     * Create and return a negotiation or service contract that always returns 'no'.
     * @return a default constructed new contract.
     */
    public static Contract getNoContract()
    {
        Element nextElem;                       //next element
        Element noInfo;                         //no info
        Contract noContract;                    //no contract
        
        noInfo = XMLFactory.getInstance().createElement(MetaConst.SERVICELEVELCONTRACT);
        nextElem = XMLFactory.getInstance().createElement(MetaConst.POLICY);
        nextElem.setText(MetaConst.ALLCONTRACTSCODE);
        noInfo.addContent(nextElem);
        
        nextElem = XMLFactory.getInstance().createElement(MetaConst.SERVICELEVEL);
        nextElem.setText(MetaConst.ALLCONTRACTSCODE);
        noInfo.addContent(nextElem);
        
        nextElem = XMLFactory.getInstance().createElement(MetaConst.CONTRACTEVALUATION);
        nextElem.setText(MetaConst.CONTRACTNOTOK);
        noInfo.addContent(nextElem);
        
        noContract = new Contract(noInfo);
        return noContract;
    }
    
    /**
     * Create a default true contract. This is different to a 'yes' contract in the
     * sense that it is a 'reply' to a negotiation and not an automatic response.
     * @param clientID the id of the calling client.
     * @param serviceLevel the service level.
     * @return a default affirmative reply to a contract negotiation phase.
     */
    public static Contract getTrueContract(String clientID, String serviceLevel)
    {
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        Contract trueContract;                      //true contract

        rootElem = XMLFactory.getInstance().createElement(MetaConst.SERVICELEVELCONTRACT);

        nextElem = XMLFactory.getInstance().createElement(MetaConst.CLIENT);
        nextElem.setText(clientID);
        rootElem.addContent(nextElem);

        nextElem = XMLFactory.getInstance().createElement(MetaConst.CONTRACTEVALUATION);
        nextElem.setText(MetaConst.CONTRACTOK);
        rootElem.addContent(nextElem);

        nextElem = XMLFactory.getInstance().createElement(MetaConst.SERVICELEVEL);
        nextElem.setText(serviceLevel);
        rootElem.addContent(nextElem);

        trueContract = new Contract(rootElem);        
        return trueContract;
    }

    /**
     * Parse the contract to retrieve the value for the specified element. These
     * are first-level elements with pre-defined names.
     * @param elementName the name of the element. Can be for example {@code Const.POLICY},
     * {@code Const.CLIENT}, {@code Const.SERVICELEVEL}.
     * @param theContract the client contract.
     * @return the element value, or null if none is available or if the contract
     * is not properly structured.
     */
    public static String getElementValue(String elementName, Contract theContract)
    {
        int i;
        String elemValue;                           //element value
        Node nextNode;                              //next node
        Element contractXml;                        //contract description
        Element nextElem;                           //next element
        Vector<Node> elemList;                      //list of elements

        elemValue = null;
        contractXml = theContract.getContract();
        elemList = contractXml.getChildren();

        for (i = 0; i < elemList.size(); i++)
        {
            nextNode = elemList.get(i);

            if (nextNode instanceof Element) {
                nextElem = (Element)nextNode;
                if (nextElem.getName().equals(elementName)) {
                    elemValue = nextElem.getText();
                    break;
                }
            }
        }

        return elemValue;
    }
}
