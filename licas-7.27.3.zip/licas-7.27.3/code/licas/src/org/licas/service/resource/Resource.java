/*
 * Resource.java
 *
 * Created on 11 September 2013
 *
 * Version 1.4
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.resource;


import org.jlog2.util.UuidHandler;
import org.licas.meta.MetaFactory;
import org.licas.service.InformationService;
import org.licas.service.resource.container.ListContainer;
import org.licas.service.resource.container.QueryContainer;
import org.licas.service.resource.container.RandomContainer;
import org.licas.service.resource.container.ResourceContainer;
import org.licas.service.resource.info.*;
import org.licas.util.AiConst;
import org.licas.util.Const;
import org.licas.util.FileObject;
import org.licas.util.TypeConst;
import org.licas_text.util.HtmlConst;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;


/**
 * This is used by a service, such as the {@link InformationService}, to store a single 
 * resource instance. The resource could store static content or access an online link, for example.
 * @author Kieran Greer
 */
public abstract class Resource 
{
    /** Resource types */
    public static final String INFOANYTYPE = ObjResource.class.getName();
    public static final String INFOBINARYTYPE = InfoBinary.class.getName();
    public static final String INFOTEXTTYPE = InfoText.class.getName();
    public static final String INFOXMLTYPE = InfoXml.class.getName();
    public static final String INFOHTMLTYPE = InfoHtml.class.getName();
    public static final String INFOSTREAMXMLTYPE = InfoStreamXml.class.getName();
    public static final String INFOURLTYPE = InfoURL.class.getName();
    public static final String INFOSTRINGTYPE = InfoString.class.getName();
    public static final String LISTCONTAINERTYPE = ListContainer.class.getName();
    public static final String RANDOMCONTAINERTYPE = RandomContainer.class.getName();
    public static final String QUERYCONTAINERTYPE = QueryContainer.class.getName();
    
    
    /** A unique id for the resource */
    protected String uuid;
    
    /** The data type */
    protected String dataType;
    
    
    /**
     * Create a new instance of Resource.
     * @param theDataType the resource data type.
     * @throws java.lang.Exception any error.
     */
    public Resource(String theDataType) throws Exception
    {
        dataType = dataFromResourceType(theDataType);
    }
    
    /**
     * Parse the data description in the admin document to create the data object.
     * @param dataXml the outermost element is not checked for, but might be a {@code DATA} 
     * or {@code DATASET} element. This should include a {@code VALUE} element that stores 
     * a String or XML-based value description and possibly an {@code Action} element. 
     * If there is no specified action, then the data is loaded into the resource as default. 
     * An action of {@link AiConst}.{@code LOADREMOTE}, for example, will retrieve the 
     * data dynamically upon request, from the file link.
     * @return true if the resource was successfully initialised, false otherwise.
     * @throws java.lang.Exception any error.
     */
    protected abstract boolean parseInfo(Element dataXml) throws Exception;
    
    /**
     * Get the currently loaded source information wrapped in an XML element.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * @return the value of the resource info as an XML element. This format is 
     * consistent with adding data through an admin document.
     * @throws java.lang.Exception any error.
     */
    public abstract Element getInfo(Element infoDescr) throws Exception;
    
    /**
     * Get the value itself and not a wrapped description.
     * @param infoDescr a description of the info resource value that should be retrieved,
     * but can be null.
     * @return the info value.
     * @throws java.lang.Exception any error.
     */
    public abstract Object getValue(Element infoDescr) throws Exception;
    
    
    /**
     * Check if there is a {@code UUID} attribute specified in the admin script root element
     * and set the resource ID if there is. If there is not then assign a unique random one. The resource
     * @param adminXml the initialisation admin script.
     * @throws java.lang.Exception any error.
     */
    protected void setUUID(Element adminXml) throws Exception
    {
        String resourceID;                          //he resource ID
        
        resourceID = null;
        if (adminXml != null)
        {
            resourceID = adminXml.getAttributeValue(Const.UUID);
        }
        
        if (resourceID == null)
        {
            resourceID = UuidHandler.getUuid(10);
        }
        
        uuid = resourceID;
    }

    /**
     * Set the resource uuid.
     * @param theUuid the uuid value.
     */
    public void setUUID(String theUuid)
    {
        uuid = theUuid;
    }

    /**
     * Get the ID value.
     * @return the value of uuid.
     */
    public String getUUID()
    {
        return uuid;
    }
    
    /**
     * Get the data type.
     * @return the value of dataType.
     */
    protected String getDataType()
    {
        return dataType;
    }

    /**
     * Try to find the value element, but only for a specific structure at the start of
     * the document, so find the first instance and the rest can include any element name.
     * @param dataXml the resource admin document. Should have a {@code Data} element
     * as the first element, and a {@code Value} element at the immediate next level.
     * @return the value element, or {@code null} if the structure does not exist.
     * @throws java.lang.Exception any error.
     */
    protected Element parseValueElem(Element dataXml) throws Exception
    {
        Element valueElem;                  //value element

        valueElem = XmlHandler.firstWithName(dataXml, Const.DATA);
        if (valueElem != null)
        {
            valueElem = dataXml.getChild(Const.VALUE);
        }

        return valueElem;
    }

    /**
     * Get the data type from the resource type. This is a best guess or generalisation 
     * of possible types that might be returned. Text is considered to be a text file,
     * whereas String is for a stored text string.
     * @param theResourceType the resource type to convert.
     * @return the type of data from the resource type, or the resource type if it
     * is not recognised, is the ResourceObject, or a Resource Container.
     */
    public static String dataFromResourceType(String theResourceType)
    {
        if (theResourceType != null)
        {
            if (theResourceType.equals(INFOSTREAMXMLTYPE))
            {
                theResourceType = TypeConst.STREAMXML;
            }
            else if (theResourceType.equals(INFOBINARYTYPE))
            {
                theResourceType = TypeConst.BYTEOBJ;
            }
            else if (theResourceType.equals(INFOURLTYPE))
            {
                theResourceType = TypeConst.URL;
            }
            else if (theResourceType.equals(INFOHTMLTYPE))
            {
                theResourceType = HtmlConst.HTML;
            }
            else if (theResourceType.equals(INFOXMLTYPE))
            {
                theResourceType = TypeConst.ELEMENT;
            }
            else if (theResourceType.equals(INFOTEXTTYPE))
            {
                theResourceType = TypeConst.TEXTFILE;
            }
            else if (theResourceType.equals(INFOSTRINGTYPE))
            {
                theResourceType = TypeConst.STRING;
            }
        }
        
        return theResourceType;
    }
    
    /**
     * Get the most appropriate info resource type for the specified data type.
     * @param dataType the data type, for example, Integer.class.getName(), 
     * String.class.getName(), URL.class.getName(). Basic types are covered. 
     * An HTML source should be represented by URL.class.getName().
     * @return the type of Resource that would be created for that data type.
     */
    public static String resourceTypeForDataType(String dataType)
    {
        if (dataType != null)
        {
            if (TypeConst.isResourceContainer(dataType))
            {
                return TypeConst.resourceContainerType(dataType);
            }
            else if (dataType.equals(TypeConst.STREAMXML))
            {
                return INFOSTREAMXMLTYPE;
            }
            else if (TypeConst.isURL(dataType))
            {
                return INFOURLTYPE;
            }
            else if (TypeConst.isHtml(dataType) || FileObject.isHtmlFile(dataType))
            {
                return INFOHTMLTYPE;
            }
            else if (TypeConst.isBinaryType(dataType) || FileObject.isBinaryFile(dataType))
            {
                return INFOBINARYTYPE;
            }
            else if (TypeConst.isXmlType(dataType) || FileObject.isXmlFile(dataType))
            {
                return INFOXMLTYPE;
            }
            else if (TypeConst.isTextType(dataType) || FileObject.isTextFile(dataType))
            {
                return INFOTEXTTYPE;
            }
            else if (dataType.equalsIgnoreCase(TypeConst.STRING))
            {
                return INFOSTRINGTYPE;
            }

            return INFOANYTYPE;
        }
        else
        {
            return null;
        }
    }
    
    /**
     * Create an info resource object and return. The resource that is created
     * is selected automatically from the data type and so is a best match guess.
     * @param dataType the data type of the value to be stored, for example, {@code Class.getName()}.
     * @param dataXml a description of the initialisation parameters, ideally with a
     * {@code Data-Value} structure. Can be null, when no value is set.
     * @return a matched info resource or ObjResource if the type is not recognised.
     * @throws java.lang.Exception any error.
     */
    public static Resource createResource(String dataType, Element dataXml)
            throws Exception
    {
        boolean dataOK;                             //true if structure OK
        Element dataElem;                           //data element
        Element valueElem;                          //value element
        Resource infoResource;                      //the info resource

        //check the xml data for the data-value structure
        dataOK = false;
        if (dataXml.getName().equalsIgnoreCase(Const.DATA))
        {
            valueElem = dataXml.getChild(Const.VALUE);
            dataOK = (valueElem != null);
        }

        if (!dataOK)
        {
            dataElem = MetaFactory.createMeta(Const.DATA);
            valueElem = MetaFactory.createMeta(Const.VALUE);
            valueElem.addContent(dataXml);
            dataElem.addContent(valueElem);
            dataXml = dataElem;
        }

        valueElem = dataXml.getChild(Const.DATATYPE);
        if (valueElem == null)
        {
            valueElem = MetaFactory.createMeta(Const.DATATYPE);
            valueElem.setText(dataType);
            dataXml.addContent(valueElem);
        }

        //create the resource
        if (TypeConst.isResourceContainer(dataType))
        {
            infoResource = ResourceContainer.createContainer(dataType, dataXml);
        }
        else if (dataType.equals(TypeConst.STREAMXML))
        {
            infoResource = new InfoStreamXml(dataType, dataXml);
        }
        else if (TypeConst.isURL(dataType) || dataType.equals(INFOURLTYPE))
        {
            infoResource = new InfoURL(dataType, dataXml);
        }
        else if (TypeConst.isHtml(dataType) || dataType.equals(INFOHTMLTYPE))
        {
            infoResource = new InfoHtml(dataType, dataXml);
        }
        else if (TypeConst.isBinaryType(dataType) || dataType.equals(INFOBINARYTYPE))
        {
            infoResource = new InfoBinary(dataType, dataXml);
        }
        else if (TypeConst.isXmlType(dataType) || dataType.equals(INFOXMLTYPE))
        {
            infoResource = new InfoXml(dataType, dataXml);
        }
        else if (TypeConst.isTextType(dataType) || dataType.equals(INFOTEXTTYPE))
        {
            infoResource = new InfoText(dataType, dataXml);
        }
        else if (dataType.equalsIgnoreCase(TypeConst.STRING) || dataType.equals(INFOSTRINGTYPE))
        {
            infoResource = new InfoString(dataType, dataXml);
        }
        else 
        {
            infoResource = new ObjResource(dataType, dataXml);
        }
        
        return infoResource;
    }
}
