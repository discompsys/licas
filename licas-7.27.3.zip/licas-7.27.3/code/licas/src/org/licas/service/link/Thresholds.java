/*
 * Thresholds.java
 *
 * Created on 15 December 2006
 *
 * Version 1.13
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.link;

import org.ai_heuristic.eval.metric.MetricDataset;
import org.ai_heuristic.functs.Function;
import org.ai_heuristic.functs.FunctionActivate;
import org.ai_heuristic.functs.activate.FunctionLinear;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.CollectionHandler;
import org.licas.call.CallObject;
import org.licas.call.MethodFactory;
import org.licas.call.MethodInfo;
import org.licas.service.spec.LinkSpec;
import org.licas.util.Const;
import org.licas.util.MethodConst;
import org.licas.util.ObjectHandler;
import org.licas.util.TypeConst;
import org.licas.util.exception.LicasException;
import org.licas_text.util.XmlHtmlHandler;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.*;


/**
 * This class is the base structure for the dynamic links from one source to other sources.
 * Each link is stored as a {@link ThresholdSource} and relates to an association with one other 
 * source only. This class stores the references to all related sources in all the different
 * linking levels. It also updates these references when a new group of source references 
 * is presented.
 * <p>
 * This class only represents the final or leaf node structures that contain the link values 
 * for each source. Any path associated with a group of linked sources is stored in the 
 * {@link Link}, {@link Link_M}, or related linking service classes. Each evaluation is now passed
 * through an activation function that can be defined by its class name. This defaults to
 * the linear type that simply returns the same value that is passed in. Other types can make
 * the link value evaluation less linear, but there is no check on any correctness, as any
 * relevant function can be added. The only exception is a check for the value of {@code <= 0}, 
 * which is done using the link value only, without any activation function.
 * @author Kieran Greer
 */
public class Thresholds
{    
    /** The logger */
    private static final Logger logger;
    
    
    /** The original threshold config values */
    protected LinkSpec linkSpec;
    
    /** The threshold to monitor the source */
    protected float monitorThreshold;
    
    /** The threshold to add a link */
    protected float linkThreshold;
    
    /** The number of possible sources to store */
    protected int possibleNumber;
    
    /** The number of monitors to store */
    protected int monitorNumber;
    
    /** The number of links to store */
    protected int linkNumber;
    
    /** The number of sources moved up / swapped next level up */
    protected int totalMovedUp;
    
    /** The number of sources moved down because they fell below the threshold */
    protected int totalMovedDown;
    
    /** The maximum number of allowed negative entries for each link */
    protected int maxNegative;
    
    /** The amount to increment source values by */
    protected float increment;
    
    /** The amount to weight increment values by */
    protected float incWeight;
    
    /** The amount to weight decrement values by */
    protected float decWeight;
    
    /** The linking method used */
    protected String linkMethod;

    /**
     * A source for possible values that may later be monitored.
     * Keys are source types and values are the possible values.
     */
    protected HashMap<String, ThresholdSource> possibleValues;

    /**
     * The actual values at the monitor level.
     * Keys are the source ids and values are the monitor values.
     */
    protected HashMap<String, ThresholdSource> monitorValues;
    
    /**
     * The actual values at the link level.
     * Keys are the source ids and values are the link values.
     */
    protected HashMap<String, ThresholdSource> linkValues;
    
    /** The times the sources were last incremented */
    protected HashMap<String, Long> timeStamps;
    
    /** A list of sources that have already been updated */
    protected ArrayList<Object> updatedSources;
    
    /** The reserve source that may be added */
    protected ThresholdSource reserve;
    
    /**
     * The activation function to use. 
     * The weight value is passed through this to produce the threshold value.
     */
    protected FunctionActivate functionActive;

    /** The parent component */
    protected Link parent;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(Thresholds.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of Thresholds. The activation function is assumed to
     * be a {@link FunctionLinear} type.
     * @param thisParent the parent component.
     * @throws java.lang.Exception any error.
     */
    public Thresholds(Link thisParent) throws Exception
    {
        parent = thisParent;
        maxNegative = parent.maxNegative;
        linkSpec = parent.linkSpec;
        createActivationFunction();
        resetValues();
    }
    
    /** 
     * Create the activation function, from the spec description.
     * @throws java.lang.Exception any error.
     */
    protected void createActivationFunction() throws Exception
    {
        if (linkSpec.functionActivate == null) {
            functionActive = new FunctionLinear();
        }
        else {
            functionActive = (FunctionActivate)Function.createFunction(linkSpec.functionActivate, 
                    TypeConst.FLOAT, linkSpec.functionConfig);
        }
    }
    
    /**
     * Reset the thresholds to initial values.
     * @throws java.lang.Exception any error.
     */
    public void resetValues() throws Exception
    {
        linkThreshold = linkSpec.linkThreshold;
        monitorThreshold = linkSpec.monitorThreshold;
        linkNumber = linkSpec.linkNumber;
        monitorNumber = linkSpec.monitorNumber;
        possibleNumber = linkSpec.possibleNumber;
        increment = linkSpec.linkIncrement;
        incWeight = (float)1.0;
        decWeight = linkSpec.linkWeightDec;        
        resetRelated();
    }
    
    /** 
     * Reset the related values structures.
     * @throws java.lang.Exception any error.
     */
    public void resetRelated() throws Exception
    {
        monitorValues = new HashMap<>();
        linkValues = new HashMap<>();
        possibleValues = new HashMap<>();
        timeStamps = new HashMap<>();
        reserve = createNewThresholdSource(null);
        resetUpdatedSources();
    }
    
    /** 
     * Reset values to indicate no sources have currently been updated.
     * @throws java.lang.Exception any error.
     */
    public void resetUpdatedSources() throws Exception
    {
        ArrayList<Object> parameters;           //method info parameters
        MethodInfo methodInfo;                  //method info
        CallObject call;                        //make call
        
        if (LinkConfig.canLearn(linkMethod))
        {
            call = new CallObject();

            parameters = new ArrayList<>();
            parameters.add(incWeight);
            parameters.add(totalMovedUp);
            parameters.add(totalMovedDown);

            methodInfo = MethodFactory.createMethodCall(MethodConst.UPDATEINCREMENTWEIGHT,
                    TypeConst.FLOAT, parent, parameters, null);
            incWeight = (Float) call.call(methodInfo);

            parameters = new ArrayList<>();
            parameters.add(decWeight);
            parameters.add(totalMovedUp);
            parameters.add(totalMovedDown);

            methodInfo = MethodFactory.createMethodCall(MethodConst.UPDATEDECREMENTWEIGHT,
                    TypeConst.FLOAT, parent, parameters, null);
            decWeight = (Float) call.call(methodInfo);
        }
        
        totalMovedUp = 0;
        totalMovedDown = 0;
        updatedSources = new ArrayList<>();
    }
    
    /**
     * Store the negative comparisons for the specified source reference.
     * @param source the source key.
     * @param theSources the negative sources to add.
     * @throws java.lang.Exception any error.
     */
    public void storeNegatives(Object source, ArrayList<Object> theSources) throws Exception
    {
        ThresholdSource link;                   //link value
        String theKey;                          //the key
        
        theKey = ObjectHandler.getKey(source);
        link = linkValues.get(theKey);

        if (link != null) {
            link.addNegative(theSources);
        }
    }
    
    /**
     * Increment the source value stored at the specified level.
     * @param thresholdType the level the source is stored at.
     * @param source the source representation.
     * @param timeStamp the current time.
     * @return float the new source value after activation function evaluation.
     * @throws Exception any error.
     */
    public float incrementSource(int thresholdType, Object source, long timeStamp) throws Exception
    {
        float newValue;                         //new source value
        String theKey;                          //the key
        
        theKey = ObjectHandler.getKey(source);       
        newValue = incrementSource(thresholdType, source);
        timeStamps.put(theKey, timeStamp);
        return activationValue(newValue);
    }
    
    /**
     * Increment the source value stored at the specified level.
     * @param thresholdType the level the source is stored at.
     * @param source the source representation.
     * @return float the new source value.
     * @throws java.lang.Exception any error.
     */
    protected float incrementSource(int thresholdType, Object source) throws Exception
    {
        float nextValue;                                    //next source value
        String theKey;                                      //the key
        HashMap<String, ThresholdSource> thisThresholds;    //selected thresholds
        ThresholdSource link;                               //link value
              
        theKey = ObjectHandler.getKey(source);

        if (thresholdType == Const.LINKSOURCE)
            thisThresholds = linkValues;
        else if (thresholdType == Const.MONITORSOURCE)
            thisThresholds = monitorValues;
        else
            thisThresholds = possibleValues;
        
        //if source missing from specified level then just return increment value
        if (thisThresholds.containsKey(theKey)) {
            link = thisThresholds.get(theKey);
            nextValue = (link.value + getIncrement());
            link.value = nextValue;
        }
        else {
            nextValue = getIncrement();
            
            link = createNewThresholdSource(source);
            link.value = nextValue;
            thisThresholds.put(theKey, link);
        }
        
        return nextValue;
    }
    
    /**
     * Return the activation value for the specified source weight value.
     * @param sourceWeight the current value associated with the source.
     * @return the value passed through the activation function.
     * @throws java.lang.Exception any error.
     */
    protected float activationValue(float sourceWeight) throws Exception
    {
        MetricDataset dataset;                      //evaluator dataset
        Object result;                              //evaluation result
        
        dataset = MetricDataset.toDataset(TypeConst.FLOAT, sourceWeight);
        result = functionActive.evaluate(dataset).getValue();
        
        if (result instanceof Float) return (Float) result;
        else return ((Double)result).floatValue();
    }
    
    /**
     * Create a new threshold object partially filled in.
     * @param source the source reference.
     * @return the created threshold source object.
     * @throws java.lang.Exception any error.
     */
    public ThresholdSource createNewThresholdSource(Object source) throws Exception
    {
        ThresholdSource link;                           //link
        
        link = new ThresholdSource(maxNegative, this);
        link.source = source;
        link.value = increment;
        
        return link;
    }
    
    /**
     * Return the current total number of source references in the structure.
     * @return the total number of sources stored at any level in the linking structure.
     */
    public int getSourceCount()
    {
        return (linkValues.size() + monitorValues.size() + possibleValues.size());
    }
    
    /**
     * Return true if the sources contain a source with the key specified.
     * @param sources the source representations.
     * @param key the key value to match.
     * @return true if any source has the key specified.
     * @throws java.lang.Exception any error.
     */
    protected boolean contains(ArrayList<Object> sources, Object key) throws Exception
    {
        int i;
        
        for (i = 0; i < sources.size(); i++)
        {
            if (ObjectHandler.equals(sources.get(i), key)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Increment the reserve source value.
     * @param timeStamp the current time.
     * @throws java.lang.Exception any error.
     */
    public void incrementReserve(long timeStamp) throws Exception
    {
        String theKey;                          //the key
        
        theKey = ObjectHandler.getKey(reserve.source);
        
        reserve.value += getIncrement();
        reserve.timeStamp = timeStamp;
        timeStamps.put(theKey, timeStamp);
    }
    
    /**
     * If the reserve source is not the same name then decrement its value.
     * @param sources the source representations.
     * @throws java.lang.Exception any error.
     */
    public void decrementReserve(ArrayList<Object> sources) throws Exception
    {
        int i;
        Object nextSource;                  //next source
        
        if ((reserve != null) && !reserve.notAssigned()) {
            for (i = 0; i < sources.size(); i++)
            {
                nextSource = sources.get(i);

                if (ObjectHandler.equals(nextSource, reserve.source)) {
                    reserve.value -= getDecrement();
                    break;
                }
            }
        }
    }
    
    /**
     * Set the reserve source value. Set the timestamp internally here.
     * @param thisReserve the value of reserve.
     * @throws java.lang.Exception any error.
     */
    public void setReserve(ThresholdSource thisReserve) throws Exception
    {
        String theKey;                          //the key
        
        theKey = ObjectHandler.getKey(reserve.source);
        
        reserve.source = thisReserve.source;
        reserve.value = thisReserve.value;
        reserve.timeStamp = thisReserve.timeStamp;
        timeStamps.put(theKey, reserve.timeStamp);
    }
    
    /**
     * Get the reserve source value.
     * @return the value of reserve.
     */
    public ThresholdSource getReserve()
    {
        if ((reserve.value != Float.MAX_VALUE))
            return reserve;
        else
            return null;
    }
    
    /**
     * Get the link sources.
     * @return the source objects stored in linkValues.
     */
    public ArrayList<Object> getLinkSources()
    {
        ArrayList<Object> links;                //links
        ThresholdSource link;                   //link
        
        links = new ArrayList<>();
        for (String key : linkValues.keySet())
        {
            link = linkValues.get(key);
            links.add(link.source);
        }
        
        return links;
    }

    /**
     * Get the monitor sources.
     * @return the source objects stored in monitorValues.
     */
    public ArrayList<Object> getMonitorSources()
    {
        ArrayList<Object> links;                //links
        ThresholdSource link;                   //link

        links = new ArrayList<>();
        for (String key : monitorValues.keySet())
        {
            link = monitorValues.get(key);
            links.add(link.source);
        }

        return links;
    }

    /**
     * Get the possible sources.
     * @return the source objects stored in possibleValues.
     */
    public ArrayList<Object> getPossibleSources()
    {
        ArrayList<Object> links;                //links
        ThresholdSource link;                   //link

        links = new ArrayList<>();
        for (String key : possibleValues.keySet())
        {
            link = possibleValues.get(key);
            links.add(link.source);
        }

        return links;
    }
    
    /**
     * Get the link sources, where the negative concepts do not apply.
     * @param negativeSources the list of negative sources, representing concept(parts). Can be {@code null}.
     * @return the objects stored in linkValues.
     * @throws java.lang.Exception any error.
     */
    public ArrayList<Object> getLinkSources(ArrayList<Object> negativeSources) throws Exception
    {
        ArrayList<Object> links;                    //links
        ThresholdSource link;                       //link
        
        links = new ArrayList<>();
        
        for (String key : linkValues.keySet())
        {
            link = linkValues.get(key);
            if (!link.hasNegative(negativeSources)) {
                links.add(link.source);
            }
        }
        
        return links;
    }

    /**
     * Move the specified source from the level it is at, down to the next level.
     * This method checks all levels for the source before moving it.
     * @param source the source representation.
     * @return true if the source was found and moved down.
     * @throws java.lang.Exception any error.
     */
    public boolean moveSourceDown(Object source) throws Exception
    {
        int i;
        int thresholdType;                              //threshold type

        for (i = 0; i < 3; i++)
        {
            if (i == 0) thresholdType = Const.NOSOURCE;
            else if (i == 1) thresholdType = Const.MONITORSOURCE;
            else thresholdType = Const.LINKSOURCE;

            if (moveSourceDown(thresholdType, source)) return true;
        }

        return false;
    }

    /**
     * Move the specified source from the specified level down to the next level.
     * @param thresholdType the threshold level.
     * @param source the source representation.
     * @return true if the source exists at the specified level and was moved down.
     * @throws java.lang.Exception any error.
     */
    public boolean moveSourceDown(int thresholdType, Object source) throws Exception
    {
        String theKey;                                      //the key
        ThresholdSource link;                               //link

        try {
            theKey = ObjectHandler.getKey(source);
            if (thresholdType == Const.LINKSOURCE) {
                if (linkValues.containsKey(theKey)) {
                    link = linkValues.get(theKey);
                    linkValues.remove(theKey);
                    monitorValues.put(theKey, link);
                    return true;
                }
            }
            else if (thresholdType == Const.MONITORSOURCE) {
                if (monitorValues.containsKey(theKey)) {
                    link = monitorValues.get(theKey);
                    monitorValues.remove(theKey);
                    possibleValues.put(theKey, link);
                    return true;
                }
            }
            else if (possibleValues.containsKey(theKey)) {
                possibleValues.remove(theKey);
                return true;
            }

            return false;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "moveSourceDown", source.toString(), ex);
        }
    }

    /**
     * Return the level at which the source is stored at or no level if not stored.
     * @param source the source representation. An attempt is automatically made to
     * try to extract the source key or ID if it is a known source type. This is the
     * key value that it would be registered under in any linking structure. If a single
     * increment value is larger than a particular level, the level that the value
     * would place the link at is returned instead.
     * @return the level that the source is currently stored at.
     * @throws java.lang.Exception any error.
     */
    public int getSourceLevel(Object source) throws Exception
    {
        int theLevel;                           //the level
        String theKey;                          //the key

        theKey = ObjectHandler.getKey(source);

        if (linkValues.containsKey(theKey))
            theLevel = Const.LINKSOURCE;
        else if (monitorValues.containsKey(theKey))
            theLevel = Const.MONITORSOURCE;
        else if (possibleValues.containsKey(theKey))
            theLevel = Const.POSSIBLESOURCE;
        else
            theLevel = Const.NOSOURCE;

        //if first increment moves source to level above lowest
        //then need to place one level below intended
        //the move up operation will then place at correct level
        if (theLevel == Const.NOSOURCE) {
            if (activationValue(getIncrement()) > linkThreshold)
                theLevel = Const.MONITORSOURCE;
            else if (activationValue(getIncrement()) > monitorThreshold)
                theLevel = Const.POSSIBLESOURCE;
        }

        return theLevel;
    }


    /**
     * Add a new source or increment its weight value and move it up the linking
     * structure if necessary. All sources are added automatically without any
     * memory restrictions. The utility service must therefore check for this.
     * @param source the source representation.
     * @param timeStamp the current time.
     * @throws java.lang.Exception any error.
     */
    public void incAndMoveSourceUp(Object source, long timeStamp) throws Exception
    {
        Thresholds.incAndMoveSourceUp(this, source, timeStamp);
    }

    /**
     * Automatically move the specified source from the specified level up to the next level.
     * @param thresholdType the threshold level.
     * @param source the source representation.
     * @param timeStamp the time for a source move.
     * @throws java.lang.Exception any error.
     */
    public void moveSourceUp(int thresholdType, Object source, long timeStamp)
            throws Exception
    {
        Thresholds.moveSourceUp(this, thresholdType, source, timeStamp);
    }

    /**
     * Decrement the sources in any of the structures if not the source type
     * and return any sources that now fall below the related threshold.
     * @param sources the representations of the sources to add.
     * @return ArrayList a list of sources that now need to be moved down a level.
     * @throws java.lang.Exception any error.
     */
    protected ArrayList<Object> sourcesToMoveDown(ArrayList<Object> sources) throws Exception
    {
        return Thresholds.sourcesToMoveDown(this, sources);
    }

    /**
     * Decrement the sources in the specified structure if not the source type
     * and return any sources that now fall below the threshold.
     * @param thresholdType the threshold type: link, monitor or possible.
     * @param sources the representations of the sources to add.
     * @return ArrayList a list of sources that now need to be moved down a level.
     * @throws java.lang.Exception any error.
     */
    protected ArrayList<Object> sourcesToMoveDown(int thresholdType, ArrayList<Object> sources) throws Exception
    {
        return Thresholds.sourcesToMoveDown(this, thresholdType, sources);
    }

    /**
     * Swap the specified sources from the specified level and level below.
     * @param thresholdType the threshold level of the upper source.
     * @param source1 the source representation for the source at the upper level.
     * @param source2 the source representation for the source at the lower level.
     * @throws java.lang.Exception any error.
     */
    public void swapSources(int thresholdType, Object source1, Object source2) throws Exception
    {
        Thresholds.swapSources(this, thresholdType, source1, source2);
    }

    /**
     * Remove the specified source from the specified level.
     * @param thresholdType the threshold level.
     * @param source the source representation.
     * @throws java.lang.Exception any error.
     */
    public void removeSource(int thresholdType, Object source) throws Exception
    {
        Thresholds.removeSource(this, thresholdType, source);
    }

    /**
     * Return the minimum source name for the specified threshold type:
     * link, monitor or possible.
     * @param thresholdType the threshold type.
     * @return the source details as stored in thresholds.
     * @throws java.lang.Exception any error.
     */
    public ThresholdSource getMinSource(int thresholdType) throws Exception
    {
        return Thresholds.getMinSource(this, thresholdType);
    }

    /**
     * Serialize the link values into XML and return.
     * @param allLevels if true, return all 3 levels, if false only return the top link level
     * references.
     * @param includeValues if true, return the weight and timestamp as well, if false,
     * return just the source references.
     * @return the linked references in XML format.
     * @throws java.lang.Exception any error.
     */
    public Element linksToXml(boolean allLevels, boolean includeValues) throws Exception
    {
        return Thresholds.linksToXml(this, allLevels, includeValues);
    }

    /**
     * Serialize the link sources into strings and return.
     * @param linkStrings list of strings to add to.
     * @param allLevels if true, return all 3 levels, if false only return the top link level
     * references.
     * @throws java.lang.Exception any error.
     */
    public void linksToString(HashMap<String, String> linkStrings, boolean allLevels) throws Exception
    {
        Thresholds.linksToString(this, linkStrings, allLevels);
    }

    /**
     * Parse the xml-based description back into links for this structure.
     * @param linksElem the links element that contains all link references.
     * @throws java.lang.Exception any error.
     */
    public void xmlToLinks(Element linksElem) throws Exception
    {
        Thresholds.xmlToLinks(this, linksElem);
    }


    /**
     * Set the monitor values.
     * @param thisMonitorValues the monitor values.
     */
    public void setMonitorValues(HashMap<String, ThresholdSource> thisMonitorValues)
    {
        monitorValues = thisMonitorValues;
    }

    /**
     * Get the monitor values.
     * @return the value of monitorValues.
     */
    public HashMap<String, ThresholdSource> getMonitorValues()
    {
        return monitorValues;
    }

    /**
     * Set the possible values.
     * @param thisPossibleValues the possible values.
     */
    public void setPossibleValues(HashMap<String, ThresholdSource> thisPossibleValues)
    {
        possibleValues = thisPossibleValues;
    }

    /**
     * Get the possible values.
     * @return the value of possibleValues.
     */
    public HashMap<String, ThresholdSource> getPossibleValues()
    {
        return possibleValues;
    }

    /**
     * Set the full link values list.
     * @param thisLinkValues the possible values.
     */
    public void setLinkValues(HashMap<String, ThresholdSource> thisLinkValues)
    {
        linkValues = thisLinkValues;
    }

    /**
     * Get the full link values list.
     * @return the value of linkValues.
     */
    public HashMap<String, ThresholdSource> getLinkValues()
    {
        return linkValues;
    }

    /**
     * Set the activation function.
     * @param thisFunctionActive the activation function.
     */
    public void setActivationFunction(FunctionActivate thisFunctionActive)
    {
        functionActive = thisFunctionActive;
    }

    /**
     * Get the activation function.
     * @return the value of functionActive.
     */
    public FunctionActivate getActivationFunction()
    {
        return functionActive;
    }

    /**
     * Set the linking configuration.
     * @param thisLinkSpec the config specification.
     */
    public void setLinkSpec(LinkSpec thisLinkSpec)
    {
        linkSpec = thisLinkSpec;
    }

    /**
     * Get the original linking configuration.
     * @return the value of linkSpec.
     */
    public LinkSpec getLinkSpec()
    {
        return linkSpec;
    }

    /**
     * Get the value to decrement sources by.
     * @return the decrement amount.
     */
    protected float getDecrement()
    {
        return (increment * decWeight);
    }

    /**
     * Get the increment weight value.
     * @return the value of incWeight.
     */
    public float getIncWeight()
    {
        return incWeight;
    }

    /**
     * Get the decrement weight value.
     * @return the value of decWeight.
     */
    public float getDecWeight()
    {
        return decWeight;
    }

    /**
     * Get the total number of sources last moved up a level.
     * @return the value of totalMovedUp.
     */
    public int getTotalMovedUp()
    {
        return totalMovedUp;
    }

    /**
     * Get the total number of sources last moved down a level.
     * @return the value of totalMovedDown.
     */
    public int getTotalMovedDown()
    {
        return totalMovedDown;
    }

    /**
     * Get the number of sources stored as links.
     * @return the number of link sources.
     */
    public int getLinkCount()
    {
        return linkValues.size();
    }

    /**
     * Get the number of sources stored as monitors.
     * @return the number of monitor sources.
     */
    public int getMonitorCount()
    {
        return monitorValues.size();
    }

    /**
     * Get the number of sources stored as possible links.
     * @return the number of possible sources.
     */
    public int getPossibleCount()
    {
        return possibleValues.size();
    }

    /**
     * Get the link threshold value.
     * @return the value of link.
     */
    public float getLinkThreshold()
    {
        return linkThreshold;
    }

    /**
     * Change the number of link sources to store.
     * @param changeNumber the number to change by. Can be positive or negative.
     */
    public void changeLinkNumber(int changeNumber)
    {
        linkNumber += changeNumber;
    }

    /**
     * Get the number of links to store.
     * @return the value of linkNumber.
     */
    public int getLinkNumber()
    {
        return linkNumber;
    }

    /**
     * Get the monitor threshold value.
     * @return the value of monitorThreshold.
     */
    public float getMonitorThreshold()
    {
        return monitorThreshold;
    }

    /**
     * Change the number of monitor sources to store.
     * @param changeNumber the number to change by. Can be positive or negative.
     */
    public void changeMonitorNumber(int changeNumber)
    {
        monitorNumber += changeNumber;
    }

    /**
     * Get the number of monitors to store.
     * @return the value of monitorNumber.
     */
    public int getMonitorNumber()
    {
        return monitorNumber;
    }

    /**
     * Change the number of possible sources to store.
     * @param changeNumber the number to change by. Can be positive or negative.
     */
    public void changePossibleNumber(int changeNumber)
    {
        possibleNumber += changeNumber;
    }

    /**
     * Get the number of possible sources to store.
     * @return the value of possibleNumber.
     */
    public int getPossibleNumber()
    {
        return possibleNumber;
    }

    /**
     * Get the increment value.
     * @return the value of increment.
     */
    public float getIncrement()
    {
        return increment;
    }

    /**
     * Get the linking method used.
     * @return the value of linkMethod.
     */
    public String getLinkMethod()
    {
        return linkMethod;
    }

    /**
     * Return a new instance of the activation function stored in this Thresholds structure.
     * @return a clone copy, using the {@code newInstance} method, or null is none exists.
     * @throws java.lang.Exception any error.
     */
    public FunctionActivate cloneFunction() throws Exception
    {
        if (functionActive != null) {
            return (FunctionActivate)functionActive.newInstance();
        }

        return null;
    }


    /** Static traversal methods */

    /**
     * Add a new source or increment its weight value and move it up the linking
     * structure if necessary. All sources are added automatically without any
     * memory restrictions. The utility service must therefore check for this.
     * @param thresholds the thresholds structure.
     * @param source the source representation.
     * @param timeStamp the current time.
     * @throws java.lang.Exception any error.
     */
    protected static void incAndMoveSourceUp(Thresholds thresholds, Object source, long timeStamp) throws Exception
    {
        boolean linkContains;               //true if link contains the source
        boolean monitorContains;            //true if monitor contains the source
        String theKey;                      //the key
        ThresholdSource link;               //link object

        theKey = ObjectHandler.getKey(source);

        //check where source is currently stored,
        //or if a single increment automatically moves to a link level
        linkContains = (thresholds.linkValues.containsKey(theKey) ||
                (thresholds.activationValue(thresholds.getIncrement()) > thresholds.linkThreshold));

        if (linkContains)
            monitorContains = false;
        else
            monitorContains = (thresholds.monitorValues.containsKey(theKey) ||
                    (thresholds.activationValue(thresholds.getIncrement()) > thresholds.monitorThreshold));

        //update and/or add to the appropriate level
        if (linkContains) {
            if (thresholds.linkValues.containsKey(theKey)) {
                link = thresholds.linkValues.get(theKey);
                link.value += thresholds.getIncrement();
            }
            else {
                link = thresholds.createNewThresholdSource(source);
                link.value = thresholds.getIncrement();
                thresholds.linkValues.put(theKey, link);
            }
        }
        else if (monitorContains) {
            if (thresholds.monitorValues.containsKey(theKey)) {
                link = thresholds.monitorValues.get(theKey);
                link.value += thresholds.getIncrement();

                if (thresholds.activationValue(link.value) > thresholds.linkThreshold) {
                    thresholds.monitorValues.remove(theKey);
                    thresholds.linkValues.put(theKey, link);
                }
            }
            else {
                link = thresholds.createNewThresholdSource(source);
                link.value = thresholds.getIncrement();
                thresholds.monitorValues.put(theKey, link);
            }
        }
        else if (thresholds.possibleValues.containsKey(theKey)) {
            link = thresholds.possibleValues.get(theKey);
            link.value += thresholds.getIncrement();

            if (thresholds.activationValue(link.value) > thresholds.monitorThreshold) {
                thresholds.possibleValues.remove(theKey);
                thresholds.monitorValues.put(theKey, link);
            }
        }
        else {
            link = thresholds.createNewThresholdSource(source);
            link.value = thresholds.getIncrement();
            thresholds.possibleValues.put(theKey, link);
        }

        thresholds.timeStamps.put(theKey, timeStamp);
    }

    /**
     * Automatically move the specified source from the specified level up to the next level.
     * @param thresholds the thresholds structure.
     * @param thresholdType the threshold level.
     * @param source the source representation.
     * @param timeStamp the time for a source move.
     * @throws java.lang.Exception any error.
     */
    protected static void moveSourceUp(Thresholds thresholds, int thresholdType, Object source, long timeStamp)
            throws Exception
    {
        String theKey;                                      //the key
        ThresholdSource link;                               //link

        theKey = ObjectHandler.getKey(source);

        //link can be missing if moved above lowest level
        //because of increment and threshold values
        //so need to check this also
        if (thresholdType == Const.MONITORSOURCE) {
            if (thresholds.monitorValues.containsKey(theKey)) {
                link = thresholds.monitorValues.get(theKey);
                thresholds.monitorValues.remove(theKey);
            }
            else {
                link = thresholds.createNewThresholdSource(source);
            }

            thresholds.linkValues.put(theKey, link);
            thresholds.timeStamps.put(theKey, timeStamp);
        }
        else if (thresholdType == Const.POSSIBLESOURCE) {
            if (thresholds.possibleValues.containsKey(theKey)) {
                link = thresholds.possibleValues.get(theKey);
                thresholds.possibleValues.remove(theKey);
            }
            else {
                link = thresholds.createNewThresholdSource(source);
            }

            thresholds.monitorValues.put(theKey, link);
            thresholds.timeStamps.put(theKey, timeStamp);
        }
        else if (thresholdType == Const.NOSOURCE) {
            if (LinkConfig.includeReserve(thresholds.linkMethod)) {
                if (thresholds.reserve.value != Float.MAX_VALUE) {
                    link = thresholds.reserve;
                    thresholds.possibleValues.put(theKey, link);
                    thresholds.reserve = thresholds.createNewThresholdSource(null);
                    thresholds.timeStamps.put(theKey, timeStamp);
                }
                else {
                    throw new Exception("Thresholds.moveSourceUp: Error: reserve not assigned a value");
                }
            }
            else {
                link = thresholds.createNewThresholdSource(source);
                thresholds.possibleValues.put(theKey, link);
                thresholds.timeStamps.put(theKey, timeStamp);
            }
        }

        thresholds.totalMovedUp++;
    }

    /**
     * Decrement the sources in any of the structures if not the source type
     * and return any sources that now fall below the related threshold.
     * @param thresholds the thresholds structure.
     * @param sources the representations of the sources to add.
     * @return ArrayList a list of sources that now need to be moved down a level.
     * @throws java.lang.Exception any error.
     */
    protected static ArrayList<Object> sourcesToMoveDown(Thresholds thresholds, ArrayList<Object> sources) throws Exception
    {
        int i;
        int thresholdType;                          //threshold type
        ArrayList<Object> sourcesToMove;            //list of sources to move

        sourcesToMove = new ArrayList<>();
        for (i = 0; i < 3; i++)
        {
            if (i == 0) thresholdType = Const.NOSOURCE;
            else if (i == 1) thresholdType = Const.MONITORSOURCE;
            else thresholdType = Const.LINKSOURCE;

            CollectionHandler.addAll(sourcesToMove, thresholds.sourcesToMoveDown(thresholdType, sources));
        }

        return sourcesToMove;
    }

    /**
     * Decrement the sources in the specified structure if not the source type
     * and return any sources that now fall below the threshold.
     * @param thresholds the thresholds structure.
     * @param thresholdType the threshold type: link, monitor or possible.
     * @param sources the representations of the sources to add.
     * @return ArrayList a list of sources that now need to be moved down a level.
     * @throws java.lang.Exception any error.
     */
    protected static ArrayList<Object> sourcesToMoveDown(Thresholds thresholds, int thresholdType, ArrayList<Object> sources) throws Exception
    {
        boolean isNull;                                 //true if null in all levels
        float nextValue;                                //next value
        String nextKey;                                 //next key
        Iterator<String> allKeys;                       //all keys
        ArrayList<Object> sourcesToMove;                //list of sources to move
        Map<String, ThresholdSource> thisThresholds;    //selected thresholds
        ThresholdSource link;                           //link

        sourcesToMove = new ArrayList<>();
        if (thresholdType == Const.LINKSOURCE)
            thisThresholds = Collections.synchronizedMap(thresholds.linkValues);
        else if (thresholdType == Const.MONITORSOURCE)
            thisThresholds = Collections.synchronizedMap(thresholds.monitorValues);
        else
            thisThresholds = Collections.synchronizedMap(thresholds.possibleValues);

        allKeys = thisThresholds.keySet().iterator();
        while (allKeys.hasNext())
        {
            try {
                nextKey = allKeys.next();
                link = thisThresholds.get(nextKey);

                if (link != null) {
                    nextValue = link.value;
                    if (!thresholds.contains(sources, nextKey) && !thresholds.contains(thresholds.updatedSources, nextKey)) {
                        nextValue -= thresholds.getDecrement();
                        link.value = nextValue;

                        thisThresholds.put(nextKey, link);
                        thresholds.updatedSources.add(nextKey);

                        if (thresholdType == Const.LINKSOURCE) {
                            if (thresholds.activationValue(nextValue) <= thresholds.linkThreshold) {
                                sourcesToMove.add(nextKey);
                            }
                        }
                        else if (thresholdType == Const.MONITORSOURCE) {
                            if (thresholds.activationValue(nextValue) <= thresholds.monitorThreshold) {
                                sourcesToMove.add(nextKey);
                            }
                        }
                        else if (thresholdType == Const.POSSIBLESOURCE) {
                            if (thresholds.activationValue(nextValue) <= 0) {
                                sourcesToMove.add(nextKey);
                            }
                        }
                    }
                }
                else {
                    thisThresholds.remove(nextKey);

                    //if level incorrect then maybe saved somewhere else
                    //so check this and remove timestamp if null everywhere
                    thisThresholds = thresholds.linkValues;
                    link = thisThresholds.get(nextKey);
                    isNull = (link == null);

                    if (isNull) {
                        thisThresholds = thresholds.monitorValues;
                        link = thisThresholds.get(nextKey);
                        isNull = (link == null);
                    }
                    if (isNull) {
                        thisThresholds = thresholds.possibleValues;
                        link = thisThresholds.get(nextKey);
                        isNull = (link == null);
                    }

                    if (isNull) thresholds.timeStamps.remove(nextKey);
                }
            }
            catch (Exception ex) {
                throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                        "sourcesToMoveDown", null, ex);
            }
        }

        thresholds.totalMovedDown += sourcesToMove.size();

        return sourcesToMove;
    }

    /**
     * Swap the specified sources from the specified level and level below.
     * @param thresholds the thresholds structure.
     * @param thresholdType the threshold level of the upper source.
     * @param source1 the source representation for the source at the upper level.
     * @param source2 the source representation for the source at the lower level.
     * @throws java.lang.Exception any error.
     */
    protected static void swapSources(Thresholds thresholds, int thresholdType, Object source1, Object source2) throws Exception
    {
        String theKey1;                                 //the key
        String theKey2;                                 //the key
        ThresholdSource link1;                          //link
        ThresholdSource link2;                          //link

        theKey1 = ObjectHandler.getKey(source1);
        theKey2 = ObjectHandler.getKey(source2);

        if (thresholdType == Const.LINKSOURCE) {
            link1 = thresholds.linkValues.get(theKey1);
            link2 = thresholds.monitorValues.get(theKey2);
            thresholds.linkValues.put(theKey2, link2);
            thresholds.monitorValues.put(theKey1, link1);
            thresholds.linkValues.remove(theKey1);
            thresholds.monitorValues.remove(theKey2);
        }
        else if (thresholdType == Const.MONITORSOURCE) {
            link1 = thresholds.monitorValues.get(theKey1);
            link2 = thresholds.possibleValues.get(theKey2);
            thresholds.monitorValues.put(theKey2, link2);
            thresholds.possibleValues.put(theKey1, link1);
            thresholds.monitorValues.remove(theKey1);
            thresholds.possibleValues.remove(theKey2);
        }
        else if (LinkConfig.includeReserve(thresholds.linkMethod)) {
            if (ObjectHandler.equals(thresholds.reserve.source, source2)) {
                link1 = thresholds.possibleValues.get(theKey1);
                link2 = thresholds.reserve;
                thresholds.possibleValues.put(theKey2, link2);

                thresholds.reserve = thresholds.createNewThresholdSource(link1.source);
                thresholds.reserve.value = link1.value;
                thresholds.reserve.timeStamp = link1.timeStamp;
                thresholds.possibleValues.remove(theKey1);
            }
            else {
                throw new LicasException("Thresholds.swapSources: Error: reserve not assigned a value");
            }
        }

        thresholds.totalMovedUp++;
    }

    /**
     * Remove the specified source from the specified level.
     * @param thresholds the thresholds structure.
     * @param thresholdType the threshold level.
     * @param source the source representation.
     * @throws java.lang.Exception any error.
     */
    protected static void removeSource(Thresholds thresholds, int thresholdType, Object source) throws Exception
    {
        String theKey;                          //the key

        theKey = ObjectHandler.getKey(source);

        if (thresholdType == Const.LINKSOURCE) {
            thresholds.linkValues.remove(theKey);
        }
        else if (thresholdType == Const.MONITORSOURCE) {
            thresholds.monitorValues.remove(theKey);
        }
        else if (thresholdType == Const.POSSIBLESOURCE) {
            thresholds.possibleValues.remove(theKey);
        }
        else if (LinkConfig.includeReserve(thresholds.linkMethod)) {
            if (ObjectHandler.equals(thresholds.reserve.source, source))
                thresholds.reserve = thresholds.createNewThresholdSource(null);
        }

        thresholds.timeStamps.remove(theKey);
    }

    /**
     * Return the minimum source name for the specified threshold type:
     * link, monitor or possible.
     * @param thresholds the thresholds structure.
     * @param thresholdType the threshold type.
     * @return the source details as stored in thresholds.
     * @throws java.lang.Exception any error.
     */
    protected static ThresholdSource getMinSource(Thresholds thresholds, int thresholdType) throws Exception
    {
        long minTimeStamp;                                  //minimum time stamp
        long nextTimeStamp;                                 //next time stamp
        float minValue;                                     //minimum value
        float nextValue;                                    //next value
        String nextKey;                                     //next key
        Iterator<String> allKeys;                           //all keys
        HashMap<String, ThresholdSource> thisThresholds;    //selected thresholds
        ThresholdSource link;                               //link
        ThresholdSource tSource;                            //source details

        minTimeStamp = Long.MAX_VALUE;
        minValue = Float.MAX_VALUE;
        nextKey = null;
        tSource = null;

        try {
            if (thresholdType == Const.LINKSOURCE)
                thisThresholds = thresholds.linkValues;
            else if (thresholdType == Const.MONITORSOURCE)
                thisThresholds = thresholds.monitorValues;
            else
                thisThresholds = thresholds.possibleValues;

            allKeys = thisThresholds.keySet().iterator();
            while (allKeys.hasNext())
            {
                nextKey = allKeys.next();
                link = thisThresholds.get(nextKey);
                nextValue = thresholds.activationValue(link.value);
                nextTimeStamp = thresholds.timeStamps.get(nextKey);

                if (nextValue < minValue) {
                    minValue = nextValue;
                    minTimeStamp = nextTimeStamp;

                    tSource = link;
                    tSource.timeStamp = nextTimeStamp;
                }
                else if ((nextValue == minValue) && (nextTimeStamp < minTimeStamp)) {
                    minValue = nextValue;
                    minTimeStamp = nextTimeStamp;

                    tSource = link;
                    tSource.timeStamp = nextTimeStamp;
                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "getMinSource", nextKey, ex);
        }

        return tSource;
    }

    
    /**
     * Serialize the link values into XML and return.
     * @param thresholds the thresholds structure.
     * @param allLevels if true, return all 3 levels, if false only return the top link level
     * references.
     * @param includeValues if true, return the weight and timestamp as well, if false, 
     * return just the source references.
     * @return the linked references in XML format.
     * @throws java.lang.Exception any error.
     */
    protected static Element linksToXml(Thresholds thresholds, boolean allLevels, boolean includeValues) throws Exception
    {
        Element linksElem;                      //links element
        
        linksElem = XMLFactory.getInstance().createElement(Const.LINKS);
        thresholds.nextLinksToXml(linksElem, Const.LINK, thresholds.linkValues, includeValues);
        
        if (allLevels) {
            thresholds.nextLinksToXml(linksElem, Const.MONITOR, thresholds.monitorValues, includeValues);
            thresholds.nextLinksToXml(linksElem, Const.POSSIBLE, thresholds.possibleValues, includeValues);
        }
        
        return linksElem;
    }
    
    /**
     * Serialize the link values into XML and add to the root element.
     * @param linksElem the root links element.
     * @param linkLevel the link level.
     * @param linkRefs list of link references.
     * @param includeValues if true, return the weight and timestamp as well, if false, 
     * return just the source references.
     * @throws java.lang.Exception any error.
     */
    protected void nextLinksToXml(Element linksElem, String linkLevel, HashMap<String, ThresholdSource> linkRefs, boolean includeValues)
            throws Exception
    {
        String linkRef;                     //link reference as a String
        ThresholdSource link;               //link
        Element linkElem;                   //link element
        Element sourceElem;                 //source ref as an element
        Element valueElem;                  //related value element
        
        for (String key: linkRefs.keySet())
        {
            link = linkRefs.get(key);
            
            if ((link != null) && (link.source != null)) {
                linkElem = XMLFactory.getInstance().createElement(linkLevel);
                linkElem.setAttribute(Const.KEY, key);

                if (link.source instanceof Element) {
                    sourceElem = (Element)link.source;
                }
                else {
                    linkRef = ObjectHandler.getKey(link.source);
                    sourceElem = XMLFactory.getInstance().createElement(Const.SOURCE);
                    sourceElem.setText(linkRef);
                }

                linkElem.addChild(sourceElem);
                linksElem.addContent(linkElem);

                if (includeValues) {
                    valueElem = XMLFactory.getInstance().createElement(Const.WEIGHT);
                    valueElem.setText(String.valueOf(link.value));
                    linkElem.addChild(valueElem);

                    valueElem = XMLFactory.getInstance().createElement(Const.TIMESTAMP);
                    valueElem.setText(String.valueOf(link.timeStamp));
                    linkElem.addChild(valueElem);
                }
            }
        }
    }
    
    /**
     * Serialize the link sources into strings and return.
     * @param thresholds the thresholds structure.
     * @param linkStrings list of strings to add to.
     * @param allLevels if true, return all 3 levels, if false only return the top link level
     * references.
     * @throws java.lang.Exception any error.
     */
    protected static void linksToString(Thresholds thresholds, HashMap<String, String> linkStrings, boolean allLevels) throws Exception
    {
        thresholds.nextLinksToString(linkStrings, Const.LINK, thresholds.linkValues);
        
        if (allLevels) {
            thresholds.nextLinksToString(linkStrings, Const.MONITOR, thresholds.monitorValues);
            thresholds.nextLinksToString(linkStrings, Const.POSSIBLE, thresholds.possibleValues);
        }
    }
    
    /**
     * Serialize the link values into XML and add to the root element.
     * @param linkStrings list of strings to add to.
     * @param linkLevel the link level.
     * @param linkRefs list of link references.
     * @throws java.lang.Exception any error.
     */
    protected void nextLinksToString(HashMap<String, String> linkStrings, String linkLevel,
                                   HashMap<String, ThresholdSource> linkRefs) throws Exception
    {
        String linkRef;                     //link reference as a String
        String linkStr;                     //link string
        ThresholdSource link;               //link
        
        for (String key: linkRefs.keySet())
        {
            link = linkRefs.get(key);
            
            if (ObjectHandler.isElement(link.source)) {
                linkRef = ((Element)link.source).getText();
            }
            else {
                linkRef = ObjectHandler.getKey(link.source);
            }
            
            linkStr = linkStrings.get(linkLevel);
            if ((linkStr == null) || linkStr.trim().isEmpty())
                linkStr += (linkLevel + ": ");
            else
                linkStr += ", ";

            linkStr += linkRef;
            linkStrings.put(linkLevel, linkStr);
        }
    }
    
    /**
     * Parse the xml-based description back into links for this structure.
     * @param thresholds the thresholds structure.
     * @param linksElem the links element that contains all link references.
     * @throws java.lang.Exception any error.
     */
    protected static void xmlToLinks(Thresholds thresholds, Element linksElem) throws Exception
    {
        int i, j;
        String keyValue;                            //key value
        String nextValue;                           //next value
        ThresholdSource link;                       //link
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Vector<Node> elemList;                      //element list
        Vector<Node> elemList2;                     //element list
        
        elemList = linksElem.getChildren();
        for (i = 0; i < elemList.size(); i++)
        {
            nextElem = (Element)elemList.get(i);
            keyValue = XmlHtmlHandler.decodeXml(nextElem.getAttributeValue(Const.KEY));
            link = thresholds.createNewThresholdSource(null);
            
            elemList2 = nextElem.getChildren();
            for (j = 0; j < elemList2.size(); j++)
            {
                nextElem2 = (Element)elemList2.get(j);
                if (nextElem2.getName().equals(Const.HANDLE)) {
                    link.source = nextElem2.clone();
                }
                else if (nextElem2.getName().equals(Const.SOURCE)) {
                    if (nextElem2.hasChildren()) {
                        link.source = nextElem2.clone();
                    }
                    else {
                        link.source = nextElem2.getText();
                    }
                }
                else if (nextElem2.getName().equals(Const.WEIGHT)) {
                    nextValue = nextElem2.getText();
                    link.value = Float.parseFloat(nextValue);
                }
                else if (nextElem2.getName().equals(Const.TIMESTAMP)) {
                    nextValue = nextElem2.getText();
                    link.timeStamp = Long.parseLong(nextValue);
                }
            }
            
            if (nextElem.getName().equalsIgnoreCase(Const.LINK)) {
                thresholds.linkValues.put(keyValue, link);
            }
            else if (nextElem.getName().equalsIgnoreCase(Const.MONITOR)) {
                thresholds.monitorValues.put(keyValue, link);
            }
            else if (nextElem.getName().equalsIgnoreCase(Const.POSSIBLE)) {
                thresholds.possibleValues.put(keyValue, link);
            }
        }
    }
}
