/**
 * Service or network specifications, for particular implementations or uses.
 */
package org.licas.service.spec;