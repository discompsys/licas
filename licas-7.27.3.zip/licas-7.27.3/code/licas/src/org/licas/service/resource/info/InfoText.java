/*
 * InfoText.java
 *
 * Created on 11 September 2013
 *
 * Version 1.3.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.resource.info;


import org.licas.meta.MetaFactory;
import org.licas.service.InformationService;
import org.licas.service.resource.Resource;
import org.licas.util.AiConst;
import org.licas.util.Const;
import org.licas.util.FileObject;
import org.licas.util.exception.LicasException;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;


/**
 * This is used by the {@link InformationService} to store text-based information 
 * that is probably read from a file.
 * @author Kieran Greer
 */
public class InfoText extends Resource
{
    /** The logger */
    private static final Logger logger;
    
  
    /** Text-based information source, stored in a file */
    private final FileObject textData;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(InfoText.class.getName());
        logger.setDebug(false);
    }

    
    /**
     * Create a new instance of InfoText.
     * @param theDataType the resource data type.
     * @param dataXml a description of the initialisation parameters. Can be null.
     * @throws java.lang.Exception any error.
     */
    public InfoText(String theDataType, Element dataXml) throws Exception
    {
        super(theDataType);
        textData = new FileObject();
        textData.setAsBytes(false);

        if ((dataXml != null) && !parseInfo(dataXml)) {
            throw new LicasException("Could not parse the data description.");
        }
    }
    
    /**
     * Parse the data description in the document to create the data object.
     * This version should read a file path. It can then either load in the contents
     * or reference it dynamically.
     * @param dataXml the outermost element is not checked for, but might be a {@code DATA} 
     * or {@code DATASET} element. This should include a {@code VALUE} element that stores 
     * a String-based file path description and possibly an {@code ACTION} element that can 
     * define if the data is stored in the resource or dynamically retrieved upon request 
     * through {@code <Data><Value>file path</Value><Action>the action</Action></Data>}.
     * The action ({@link AiConst}.{@code LOADREMOTE}) stores the file path to dynamically
     * retrieve the data upon request. Anything else, including no action, loads the data
     * into the resource as text contents. 
     * @return true if the file was successfully loaded, false otherwise.
     * @throws java.lang.Exception any error.
     */
    protected boolean parseInfo(Element dataXml) throws Exception
    {
        String filePath;                            //the file path
        String actionType;                          //the type of action
        Element dataValueElem;                      //data value element
        
        try
        {
            setUUID(dataXml);
            dataValueElem = parseValueElem(dataXml);

            if (dataValueElem != null) {
                filePath = dataValueElem.getText();
                if (filePath != null) {
                    if (FileObject.isKnownFile(filePath) && FileObject.isTextFile(filePath)) {
                        dataValueElem = dataXml.getChild(AiConst.ACTION);       
                        if (dataValueElem != null) {
                            actionType = dataValueElem.getText();
                            if (actionType.equalsIgnoreCase(AiConst.LOADREMOTE)) {
                                textData.setFilePath(filePath);
                            }
                            else {
                                textData.loadFile(filePath);
                            }

                        }
                        else {
                            textData.loadFile(filePath);
                        }

                        return true;
                    }  
                }
            }

            return false;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parseInfo",
                null, ex);
        }
    }
    
    /**
     * Get the currently loaded source information wrapped in an XML element.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * Can be null as not used in this version.
     * @return the value of the resource info as an XML element. This format is 
     * consistent with adding a 'Data' element through an admin document.
     * @throws java.lang.Exception any error.
     */
    public Element getInfo(Element infoDescr) throws Exception
    {
        String textInfo;                            //text info
        Element sourceInfo;                         //source info
        
        try {
            sourceInfo = XMLFactory.getInstance().createElement(Const.DATA);
            if (textData != null) {
                textInfo = (String)textData.getFileContents();
                sourceInfo = MetaFactory.getFactoryData().createDataTypeValue(dataType, textInfo);   
            }
            
            return sourceInfo;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getInfo",
                null, ex);
        } 
    }
    
    /**
     * Get the value itself and not a wrapped description.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * Can be null as not used in this version.
     * @return the info value.
     * @throws java.lang.Exception any error.
     */
    public Object getValue(Element infoDescr) throws Exception
    {
        return textData.getFileContents();
    }
}
