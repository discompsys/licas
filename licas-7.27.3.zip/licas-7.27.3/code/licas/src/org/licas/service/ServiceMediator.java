/*
 * ServiceMediator.java
 *
 * Created on 21 August 2012
 *
 * Version 1.5.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.PasswordHandler;
import org.licas.Service;
import org.licas.call.CallObject;
import org.licas.call.Handle;
import org.licas.call.MethodInfo;
import org.licas.call.ParamInfo;
import org.licas.server.LocalServer;
import org.licas.service.spec.ServiceSpec;
import org.licas.util.*;
import org.licas.util.exception.LicasException;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.util.*;


/**
 * This is the base class for mediating between the services that are created and running
 * on a single server. It provides capabilities for evaluating centrally, the information sources 
 * and any related problem solver classes. There is a default implementation called 
 * {@link InformationMediator} and you should use the {@code DefaultSolverFactory.createMediator}
 * method to return an instance of the service.
 * @author Kieran Greer
 */
public abstract class ServiceMediator extends Service
{
    /** The logger */
    private static final Logger logger;

    
    /** Only the server ip address, for example, 'http://123.4.5.6:8888' */
    protected String serverIP;
    
    /** The server url address */
    protected Element serverUri;
    
    /** The service specification */
    protected ServiceSpec serviceSpec;

    /** To synchronize on */
    protected final Object syncOn = new Object();

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServiceMediator.class.getName());
        logger.setDebug(false);
    }
    
    
    /**
     * Create a new instance of ServiceMediator.
     * @param thePasswordHandler the password handler.
     * @throws java.lang.Exception any error.
     */
    public ServiceMediator(PasswordHandler thePasswordHandler) throws Exception
    {
        super();
        passwordHandler = thePasswordHandler;
        initialise();
    }

    /**
     * Creates a new instance of ServiceMediator.
     * @param thisPassword the component password.
     * @param thisAdminKey the unique service key.
     * @param thePasswordHandler the password handler.
     * @throws java.lang.Exception any error.
     */
    public ServiceMediator(String thisPassword, String thisAdminKey, 
            PasswordHandler thePasswordHandler) throws Exception
    {
        super(thisPassword, thisAdminKey);
        passwordHandler = thePasswordHandler;
        initialise();
    }
    
    /**
     * Initialise some values.
     */
    private void initialise()
    {
        serverIP = LocalServer.getServerURL();
        serverUri = Handle.createNewServerHandle(serverIP);
    }
    
    /**
     * Initialise the solver mediator with the server details. Also clear the 
     * network of any existing services and the password handler for this service.
     * @param serviceSpec the service spec or test script, with all of the config details.
     * @return true if initialised OK, false otherwise. Most likely, it would be
     * missing server initialisation information.
     * @throws java.lang.Exception any error.
     */
    public abstract boolean initialiseServerInfo(ServiceSpec serviceSpec) throws Exception;
    
    /**
     * Create the services and initialise as defined by the script.
     * @param serviceType the type to assign to each main or base service.
     * @throws java.lang.Exception any error.
     */
    public abstract void createServices(String serviceType) throws Exception;  
    
    /**
     * Initialise the services, primarily adding and initialising linking 
     * structures if they are included. The initialisation could be application
     * specific and so it is done in each version of this class.
     * @param serviceType the type of service to initialise.
     * @throws java.lang.Exception any error.
     */
    public abstract void initialiseServices(String serviceType) throws Exception;
    
    
    /**
     * Initialise the information mediator with password details.
     * @param theServiceSpec the spec with all of the related config info.
     * @throws java.lang.Exception any error.
     */
    public void initialiseInfo(ServiceSpec theServiceSpec) throws Exception
    {
        try {
            serviceSpec = theServiceSpec;
            serverIP = serviceSpec.serverSpec.serverAddress;
            serverUri = Handle.createNewServerHandle(serverIP);
            
            passwordHandler = serviceSpec.serverSpec.passwordHandler;
            if (passwordHandler == null) {
                passwordHandler = new PasswordHandler(Const.ANON, Const.ANON);
                passwordHandler.addServicePassword(serverUri, serviceSpec.serverSpec.password);
                passwordHandler.addAdminKey(serverUri, serviceSpec.serverSpec.adminKey);
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, 
                    "initialiseInfo", null, ex);
        }
    }
    
    /**
     * Start the threads of all services of the specified service type.
     * @param serviceType the service type or unique id.
     * @throws java.lang.Exception any error.
     */
    public void startServices(String serviceType) throws Exception
    {
        boolean isOK;                               //true if OK
        String serverPassword;                      //server password
        String serverKey;                           //server key
        MethodInfo methodInfo;                      //method info
        CallObject call;                            //call object
        
        synchronized(syncOn) {
            try {
                call = new CallObject();
                methodInfo = new MethodInfo();
                serverPassword = passwordHandler.getServicePassword(serverUri);
                serverKey = passwordHandler.getAdminKey(serverUri);

                methodInfo.setName(MethodConst.STARTALLTHREADS);
                methodInfo.setRtnType(TypeConst.BOOLEAN);
                methodInfo.setServiceURI(serverUri);
                methodInfo.setServerPassword(serverPassword);
                methodInfo.setPassword(serverPassword);
                methodInfo.getParams().add(new ParamInfo(serviceType));
                methodInfo.getParams().add(new ParamInfo(serverKey));
                isOK = ((Boolean)call.call(methodInfo)).booleanValue();

                if (!isOK) {
                    throw new LicasException("Could not start the server threads.");
                }
            }
            catch (Exception ex) {
                throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                        "startServices", null, ex);
            }
        }
    }
    
    /**
     * Create permanent links between each key service and the list it is related to.
     * @param serviceGroups the groups of services that are clustered together.
     * The key would be a service ID and value a list of other services related to it.
     * The entries can be either IDs or String-based full URI descriptions.
     * @throws java.lang.Exception any error.
     */
    public void createPermanentLinks(HashMap<String, ArrayList<ArrayList<String>>> serviceGroups) throws Exception
    {
        int i, j;
        String linkUuid;                                    //link uuid
        Element serviceUri;                                 //service from uri
        Element linkUri;                                    //link uri
        ArrayList<ArrayList<String>> groupList;             //group list
        ArrayList<String> nextList;                         //next list
        MethodInfo methodInfo;                              //method info
        CallObject callObject;                              //call object
        
        try {
            callObject = new CallObject();
            
            for (String serviceUuid: serviceGroups.keySet())
            {
                groupList = serviceGroups.get(serviceUuid);
                try {
                    serviceUri = XmlHandler.stringToElement(serviceUuid);
                    serviceUuid = Handle.getLastServiceHandle(serviceUri);
                }
                catch (Exception xmlex) {
                    serviceUri = Handle.createNewUrlHandle(serverIP);
                    serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceUuid));
                }
                
                //create permanent links between each set of services
                for (i = 0; i < groupList.size(); i++)
                {
                    nextList = groupList.get(i);
                    for (j = 0; j < nextList.size(); j++)
                    {
                        linkUuid = nextList.get(j);
                        try {
                            linkUri = XmlHandler.stringToElement(linkUuid);
                            linkUuid = Handle.getLastServiceHandle(linkUri);
                        }
                        catch (Exception xmlex2) {
                            linkUri = Handle.createNewUrlHandle(serverIP);
                            linkUri = Handle.addToHandle(linkUri, Handle.asHandleElement(linkUuid));
                        }
                                               
                        methodInfo = new MethodInfo();
                        methodInfo.setName(MethodConst.CREATEPERMANENTLINKTO);
                        methodInfo.setRtnType(TypeConst.BOOLEAN);
                        methodInfo.setServiceURI(serviceUri);
                        methodInfo.setServerPassword(passwordHandler.getServicePassword(serverUri));
                        methodInfo.setPassword(passwordHandler.getServicePassword(serviceUuid));
                        methodInfo.getParams().add(new ParamInfo(passwordHandler.getAdminKey(serviceUuid)));
                        methodInfo.getParams().add(new ParamInfo(linkUuid));
                        methodInfo.getParams().add(new ParamInfo(passwordHandler.getServicePassword(linkUuid)));
                        methodInfo.getParams().add(new ParamInfo(linkUri));
                        callObject.call(methodInfo);
                    }
                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, 
                    "createPermanentLinks", null, ex);
        }
    }
    
    /**
     * Create association links between each key service and the list it is related to.
     * @param serviceGroups the groups of services that are clustered together.
     * The key would be a service ID and value a list of other services related to it.
     * @throws java.lang.Exception any error.
     */
    public void createAssociationLinks(HashMap<String, ArrayList<ArrayList<String>>> serviceGroups) throws Exception
    {
        int i, j;
        String linkUuid;                                    //link uuid
        String linkPassword;                                //password to linked service
        Element serviceUri;                                 //service from uri
        Element linkUri;                                    //link uri
        ArrayList<ArrayList<String>> groupList;             //group list
        ArrayList<String> nextList;                         //next list
        MethodInfo methodInfo;                              //method info
        CallObject callObject;                              //call object
        
        try
        {
            callObject = new CallObject();
            
            for (String serviceUuid: serviceGroups.keySet())
            {
                groupList = serviceGroups.get(serviceUuid);
                try {
                    serviceUri = XmlHandler.stringToElement(serviceUuid);
                    serviceUuid = Handle.getLastServiceHandle(serviceUri);
                }
                catch (Exception xmlex) {
                    serviceUri = Handle.createNewUrlHandle(serverIP);
                    serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceUuid));
                }
                
                //create permanent links between each set of services
                for (i = 0; i < groupList.size(); i++)
                {
                    nextList = groupList.get(i);
                    for (j = 0; j < nextList.size(); j++)
                    {
                        linkUuid = nextList.get(j);
                        try {
                            linkUri = XmlHandler.stringToElement(linkUuid);
                            linkUuid = Handle.getLastServiceHandle(linkUri);
                        }
                        catch (Exception xmlex2) {
                            linkUri = Handle.createNewUrlHandle(serverIP);
                            linkUri = Handle.addToHandle(linkUri, Handle.asHandleElement(linkUuid));                       
                        }
                        
                        try {
                            linkPassword = passwordHandler.getServicePassword(linkUri);
                        }
                        catch (Exception xmlex2) {
                            linkPassword = passwordHandler.getServicePassword(linkUuid);                       
                        }
                        
                        methodInfo = new MethodInfo();
                        methodInfo.setName(MethodConst.ADDSERVICEASSOCIATION);
                        methodInfo.setRtnType(TypeConst.BOOLEAN);
                        methodInfo.setServiceURI(serviceUri);
                        methodInfo.setServerPassword(passwordHandler.getServicePassword(serverUri));
                        methodInfo.setPassword(passwordHandler.getServicePassword(serviceUuid));
                        methodInfo.getParams().add(new ParamInfo(passwordHandler.getAdminKey(serviceUuid)));
                        methodInfo.getParams().add(new ParamInfo(linkUri));
                        methodInfo.getParams().add(new ParamInfo(linkPassword));
                        callObject.call(methodInfo);
                    }
                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, 
                    "createAssociationLinks", null, ex);
        }
    }
    
    /**
     * Update dynamic links for the services that are grouped together.
     * @param serviceGroups the groups of services that are clustered together.
     * The key would be a service ID and value a list of other services related to it.
     * This can either be a {@code ArrayList} that includes more groups, or a list of service names.
     * @param toPermanent if true, convert any dynamic links at the link level
     * into permanent links, or remove permanent links now moved down a level.
     * @throws java.lang.Exception any error.
     */
    public void updateDynamicLinks(HashMap<String, ArrayList<ArrayList<String>>> serviceGroups, boolean toPermanent)
            throws Exception
    {
        Element serviceUri;                                 //service from uri
        ArrayList<ArrayList<String>> groupList;             //group list
        ArrayList<String> conceptList;                      //link concept path
        MethodInfo methodInfo;                              //method info
        CallObject callObject;                              //call object
        
        try
        {
            callObject = new CallObject();
            
            for (String serviceUuid: serviceGroups.keySet())
            {
                groupList = serviceGroups.get(serviceUuid);
                try {
                    serviceUri = XmlHandler.stringToElement(serviceUuid);
                }
                catch (Exception xmlex) {
                    serviceUri = Handle.createNewUrlHandle(serverIP);
                    serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceUuid)); 
                }
                
                //create link path with any constant value as no real path exists
                conceptList = new ArrayList<>();
                conceptList.add(serviceUuid);

                //pass the list to just the service in the key
                methodInfo = new MethodInfo();
                methodInfo.setName(MethodConst.UPDATEDYNAMICLINKS);
                methodInfo.setRtnType(TypeConst.VOID);
                methodInfo.setServiceURI(serviceUri);
                methodInfo.setServerPassword(passwordHandler.getServicePassword(serverUri));
                methodInfo.setPassword(passwordHandler.getServicePassword(serviceUri));
                methodInfo.addParam(conceptList);
                methodInfo.addParam(groupList);
                methodInfo.addParam(new Boolean(toPermanent));
                methodInfo.addParam(passwordHandler.getAdminKey(serviceUri));
                callObject.call(methodInfo);
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, 
                    "updateDynamicLinks", null, ex);
        }
    }
    
    /**
     * Get the list of uuids only of all services currently linked to through dynamic links,
     * with the {@code source} uuid added only once, but the {@code linked to} uuid added the 
     * number of times it occurs.
     * @return a list with service uuids only.
     * @throws java.lang.Exception any error.
     */
    public ArrayList<String> getLinkedServiceUuids() throws Exception
    {
        int i, j;
        boolean hasLinks;                           //true if has links
        String sourceUuid;                          //source service uuid
        String linkedUuid;                          //linked service uuid
        ArrayList<String> serviceUuids;             //service uuids
        Vector<Node> elemList;                      //element list
        Vector<Node> elemList2;                     //element list
        Node nextNode;                              //next node
        Element dynamicLinksElem;                   //dynamic links element
        Element nextLinksElem;                      //next links element
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        
        try
        {
            serviceUuids = new ArrayList<>();
            dynamicLinksElem = dynamicLinksToXml();
            elemList = dynamicLinksElem.getChildren();
            
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = elemList.get(i);
                if (nextNode instanceof Element) {
                    nextLinksElem = (Element)nextNode;

                    if (nextLinksElem.getName().equals(MetaConst.DYNAMICLINKSERVICEMETA)) {
                        sourceUuid = null;
                        hasLinks = false;
                        
                        elemList2 = nextLinksElem.getChildren();            
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            linkedUuid = null;
                            nextNode = elemList2.get(j);

                            if (nextNode instanceof Element) {
                                nextElem = (Element)nextNode;

                                if (nextElem.getName().equals(Const.SOURCE)) {
                                    nextElem2 = nextElem.getChild(Const.UUID);

                                    if ((nextElem2 != null) && (nextElem2.getText() != null)) {
                                        sourceUuid = nextElem2.getText().trim();
                                    }
                                }
                                else if (nextElem.getName().equals(Const.LINK)) {
                                    nextElem2 = nextElem.getChild(Const.HANDLE);

                                    if (nextElem2 != null) {
                                        linkedUuid = Handle.getLastServiceHandle(nextElem2);
                                    }
                                }

                                if (linkedUuid != null) {
                                    serviceUuids.add(linkedUuid);
                                    hasLinks = true;
                                }
                            }
                                    
                            if ((sourceUuid != null) && hasLinks) {
                                if (!serviceUuids.contains(sourceUuid)) {
                                    serviceUuids.add(sourceUuid);
                                    sourceUuid = null;
                                }
                            }
                        }
                    }             
                }
            }
            
            return serviceUuids;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, 
                    "getLinkedServiceUuids", null, ex);
        }
    }
    
    /**
     * Get the list of all dynamic links created on each service.
     * @return the list of all dynamic links as an XML-based description.
     * @throws java.lang.Exception any error.
     */
    public Element dynamicLinksToXml() throws Exception
    {
        int i;
        String serviceUuid;                         //service uuid
        String infoServiceType;                     //info service type
        String serverUriStr;                        //server uri as a string
        Element serviceUri;                         //service uri
        ArrayList<String> serviceUuids;             //list of service uuids
        ArrayList<String> serviceTypes;             //service types
        Element dynamicLinksElem;                   //dynamic links element
        MethodInfo methodInfo;                      //method info
        CallObject callObject;                      //call object
        Object reply;                               //method reply
        
        try {
            callObject = new CallObject();
            serverUriStr = XmlHandler.xmlToString(serverUri); 
            dynamicLinksElem = XMLFactory.getInstance().createElement(Const.LINKS);
            infoServiceType = ServiceConst.INFORMATION;
            serviceTypes = new ArrayList<>();
            serviceTypes.add(infoServiceType);

            //retrieve the information services
            methodInfo = new MethodInfo();
            methodInfo.setName(MethodConst.GETSERVICENAMES);
            methodInfo.setRtnType(TypeConst.ARRAYLIST);
            methodInfo.setServiceURI(serverUri);
            methodInfo.setServerPassword(passwordHandler.getServicePassword(serverUriStr));
            methodInfo.setPassword(passwordHandler.getServicePassword(serverUriStr));
            methodInfo.addParam(serviceTypes);
            serviceUuids = (ArrayList)callObject.call(methodInfo);
            
            for (i = 0; i < serviceUuids.size(); i++)
            {
                serviceUuid = serviceUuids.get(i);
                serviceUri = Handle.createNewUrlHandle(serverIP);
                serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceUuid));
                
                methodInfo = new MethodInfo();
                methodInfo.setName(MethodConst.DYNAMICLINKSTOXML);
                methodInfo.setRtnType(TypeConst.ELEMENT);
                methodInfo.setServiceURI(serviceUri);
                methodInfo.setServerPassword(passwordHandler.getServicePassword(serverUriStr));
                methodInfo.setPassword(passwordHandler.getServicePassword(serviceUuid));
                methodInfo.addParam(new ParamInfo(passwordHandler.getAdminKey(serviceUuid)));
                reply = callObject.call(methodInfo);
                
                if (reply != null) {
                    if (reply instanceof Element)
                        dynamicLinksElem.addContent((Element)reply);
                }
            }
            
            return dynamicLinksElem;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, 
                    "dynamicLinksToXml", null, ex);
        }
    }
}
