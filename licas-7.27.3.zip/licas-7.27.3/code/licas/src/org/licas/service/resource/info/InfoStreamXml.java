/*
 * InfoStreamXml.java
 *
 * Created on 23 August 2016
 *
 * Version 1.6
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.resource.info;


import org.licas.meta.MetaFactory;
import org.licas.service.InformationService;
import org.licas.service.resource.Resource;
import org.licas.util.Const;
import org.licas.util.UriHandler;
import org.licas.util.exception.LicasException;
import org.licas_internet.conn.ConnectionInfo;
import org.licas_internet.conn.LicasWebConnection;
import org.licas_text.stream.FeedFormatter;
import org.licas_text.util.XmlHtmlHandler;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.model.XmlHandler;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.events.XMLEvent;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Vector;



/**
 * This is used by the {@link InformationService} to return a remote stream value parsed into xml.
 * The URL link to the online source is stored and the contents are returned upon request.
 * This should close the stream after each request. The {@code getValue} method logs any 
 * error but then returns {@code null} instead of throwing an exception. An alternative 
 * to this would be the {@link InfoHtml} resource for more basic HTML pages. 
 * <p>
 * This class tries to read the event stream as an input stream. If that fails, it tries to
 * retrieve the whole stream first as a string, check formatting and then create the event stream.
 * If that fails, it resets SSL to accept any certificate and repeats the process.
 * The TrustManager is then re-loaded at the end if it has been reset.
 * <p>
 * The default is to parse the stream to format it as an rss feed. As well as the {@link Const}.{@code VALUE} 
 * element, it is possible to add a {@code <Keywords><Keyword>kw1</Keyword><Keyword>kw2</Keyword>...</Keywords>} section 
 * to the initialisation script to define a different set of element names to keep.
 * In that case, both the data value element and the keywords element probably need to be
 * both wrapped in an outer element.
 * @author Kieran Greer
 */
public class InfoStreamXml extends Resource
{
    /** The logger */
    private static final Logger logger;
    
    
    /** The URL address */
    private URL url;
    
    /** List of names to use as the key element tags */
    private final ArrayList<String> keyList;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(InfoStreamXml.class.getName());
        logger.setDebug(false);
    }

    
    /**
     * Create a new instance of InfoStreamXml.
     * @param theDataType the resource data type. One of the stream types. This
     * returns the stream as a String by default.
     * @param dataXml a description of the initialisation parameters. Can be null.
     * @throws java.lang.Exception any error.
     */
    public InfoStreamXml(String theDataType, Element dataXml) throws Exception
    {
        super(theDataType);
        url = null;
        keyList = new ArrayList<>();

        if ((dataXml != null) && !parseInfo(dataXml)) {
            throw new LicasException("Could not parse the data description.");
        }
    }
    
    /**
     * Parse the data description in the document to create the data object.
     * This version should read a URL address and store that. It also only returns the 
     * URL address upon request.
     * @param dataXml this must include a {@link Const}.{@code VALUE} element that stores 
     * a String-based URL path description. It can also include a {@code Keywords} element 
     * that stores a specific list of element tag names to keep. If not present, then a 
     * default rss set of element names are kept.
     * @return true if the file was successfully loaded, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean parseInfo(Element dataXml) throws Exception
    {
        int i;
        boolean isOK;                           //true if OK
        Element dataValueElem;                  //data value element
        Element keyNamesElem;                   //key names element
        Node nextNode;                          //next node
        Element nextElem;                       //next element
        Vector<Node> elemList;                  //element list
        
        try
        {
            isOK = false;
            setUUID(dataXml);     
            
            //parse for the stream url
            dataValueElem = parseValueElem(dataXml);
            if (dataValueElem != null) {
                try {
                    url = new URL(dataValueElem.getText());
                }
                catch (MalformedURLException muex) {
                    url = new URL(UriHandler.addLocalFileUriPrefix(dataValueElem.getText()));
                    dataValueElem.setText(url.toExternalForm());
                }
                
                isOK = true;
            }
            
            //parse for a specific set of element names to keep
            if (isOK) {
                keyNamesElem = XmlHandler.firstWithName(dataXml, Const.KEYWORDS);

                if (keyNamesElem != null) {
                    elemList = keyNamesElem.getChildren();

                    for (i = 0; i < elemList.size(); i++)
                    {
                        nextNode = elemList.get(i);
                        if (nextNode instanceof Element) {
                            nextElem = (Element)nextNode;

                            if (nextElem.getName().equals(Const.KEYWORD)) {
                                keyList.add(nextElem.getText());
                            }
                        }
                    }
                }
            }

            return isOK;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parseInfo",
                null, ex);
        }
    }
    
    /**
     * Get the currently loaded source information wrapped in an XML element.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * @return the value of the resource info as an XML element. This format is 
     * consistent with adding a {@code Data} element through an admin document.
     * @throws java.lang.Exception any error.
     */
    public Element getInfo(Element infoDescr) throws Exception
    {
        String fileStr;                         //contents as a string
        Element fileContents;                   //file contents
        
        try {
            fileContents = (Element)getValue(infoDescr);

            if (fileContents != null) {
                fileStr = XmlHandler.xmlToString(fileContents);
                fileStr = XmlHandler.addStringSpec(fileStr);
                return MetaFactory.getFactoryData().createDataTypeValue(dataType, fileStr);
            }
            
            return null;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getInfo",
                null, ex);
        } 
    }
    
    /**
     * Get the value itself and not a wrapped description. 
     * @param infoDescr a description of the info resource value that should be retrieved.
     * Ignored in this case as the whole source stream, parsed into XML, is returned.
     * @return the info value.
     * @throws java.lang.Exception any error.
     */
    public Object getValue(Element infoDescr) throws Exception
    {
        Element xmlElem;                    //xml element
        
        try {
            try {
                xmlElem = readAsStream();
            }
            catch (Exception ex1) {
                xmlElem = readAsString();
            }

            return xmlElem;
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getValue",
                ("Failed stream is " + url.toExternalForm() + ": "), ex);
            
            return null;
        }
    }
    
    /**
     * Connect and retrieve the stream as an input stream, then create event reader from that. 
     * @return the info value.
     * @throws java.lang.Exception any error.
     */
    private Element readAsStream() throws Exception
    {
        InputStreamReader reader;               //the read stream
        ConnectionInfo connInfo;                //connection info
        LicasWebConnection conn;                //licas url connection
        URLConnection connection;               //url connection
        XMLEventReader eventReader;             //event reader
        
        conn = null;
        reader = null;
        eventReader = null;

        try {
            connInfo = new ConnectionInfo();
            connInfo.remoteAddress = url.toExternalForm();
            conn = new LicasWebConnection(connInfo);
            conn.connect();
            connection = (URLConnection)conn.getConn();
            reader = new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8);
            eventReader = XMLInputFactory.newInstance().createXMLEventReader(reader);

            return readEventStream(eventReader);
        }
        finally {
            if (conn != null) {
                try {
                    conn.disconnect();
                }
                catch (Exception cex) {}
            }
            if (reader != null) {
                try {
                    reader.close();
                }
                catch (Exception rex) {}
            }
            if (eventReader != null) {
                try {
                    eventReader.close();
                }
                catch (Exception rex) {}
            }
        }
    }
    
    /**
     * Connect and retrieve the stream as a string, then create event reader from that. 
     * @return the info value.
     * @throws java.lang.Exception any error.
     */
    private Element readAsString() throws Exception
    {
        int index;                              //index
        int ch;                                 //next character
        StringBuilder stream;                   //stream as string
        StringReader reader;                    //the read stream
        ConnectionInfo connInfo;                //connection info
        LicasWebConnection conn;                //licas url connection
        URLConnection connection;               //url connection
        XMLEventReader eventReader;             //event reader
        
        conn = null;
        reader = null;
        eventReader = null;
        stream = new StringBuilder();

        try {
            connInfo = new ConnectionInfo();
            connInfo.remoteAddress = url.toExternalForm();
            conn = new LicasWebConnection(connInfo);
            conn.connect();
            connection = (URLConnection)conn.getConn();

            //read the stream this way so that illegal characters can be removed
            stream = new StringBuilder();
            while ((ch = connection.getInputStream().read()) >= 0) {
                stream.append((char) ch);
            }

            index = stream.indexOf("<");
            if (index >= 0) {
                stream = new StringBuilder(stream.substring(index));
            }

            //stream = XmlHtmlHandler.repairXmlTags(stream, null);
            stream = new StringBuilder(XmlHtmlHandler.removeVoidTags(stream.toString().trim()));
            reader = new StringReader(stream.toString());
            eventReader = XMLInputFactory.newInstance().createXMLEventReader(reader);

            return readEventStream(eventReader);
        }
        catch (Exception ex) {
            try {
                return FeedFormatter.formatToElement(stream.toString());
            }
            catch (Exception ex2) {
                throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "readAsString", "", ex2);
            }
        }
        finally {
            if (conn != null) {
                try {
                    conn.disconnect();
                }
                catch (Exception cex) {}
            }
            if (reader != null) {
                try {
                    reader.close();
                }
                catch (Exception rex) {}
            }
            if (eventReader != null) {
                try {
                    eventReader.close();
                }
                catch (Exception rex) {}
            }
        }
    }
    
    /**
     * Read the event stream into an XML element. 
     * @param eventReader the reader.
     * @throws java.lang.Exception any error.
     */
    private Element readEventStream(XMLEventReader eventReader) throws Exception
    {
        boolean isStart;                        //true if start tag
        String ePart;                           //event part
        StringBuilder eventStr;                 //whole event string
        Element xmlElem;                        //xml element
        XMLEvent event;                         //stream event

        eventStr = new StringBuilder();
        isStart = false;

        while (eventReader.hasNext()) {
            event = eventReader.nextEvent();

            if ((event != null) && !(event.isStartDocument() || event.isEndDocument())) {

                if (isStart) {
                    ePart = event.toString().trim();
                    if (!ePart.isEmpty()) eventStr.append(event.toString());
                }

                if (event.isStartElement()) {
                    if (!isStart) {
                        isStart = true;
                        ePart = event.toString().trim();
                        if (!ePart.isEmpty()) eventStr.append(event.toString());
                    }
                }
                else if (event.isEndElement()) {
                    if (isStart) {
                        isStart = false;
                    }
                    else {
                        ePart = event.toString().trim();
                        if (!ePart.isEmpty()) eventStr.append(event.toString());
                    }
                }
            }
        }

        if ((keyList == null) || keyList.isEmpty()) {
            xmlElem = FeedFormatter.formatToElement(eventStr.toString());
        }
        else {
            xmlElem = FeedFormatter.formatToElement(eventStr.toString(), keyList);
        }

        return xmlElem;
    }
    
    /**
     * Get the url address.
     * @return the value of {@code url.toExternalForm()}.
     */
    public String getURL()
    {
        return url.toExternalForm();
    } 
}
