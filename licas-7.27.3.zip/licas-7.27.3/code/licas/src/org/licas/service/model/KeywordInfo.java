/*
 * KeywordInfo.java
 *
 * Created on 12 September 2011
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.model;


import org.licas_text.meta.MatchKeywords;
import org.licas_text.util.MetaConst;

import java.util.ArrayList;


/**
 * Stores information for a single set of keywords relating to a single concept.
 * @author Kieran Greer
 */
public class KeywordInfo 
{
    /** The topic that the keywords relate to */
    protected String topic;           
    
    /** The language that the keywords are written in */
    protected String language;
    
    /** The source of the keyword definitions. Can be a URI or something else */
    protected String source;
    
    /** The list of keywords relating to the concept and language */
    protected ArrayList<String> keywords;
    
    
    /** 
     * Create a new instance of KeywordInfo with default fields: topic is {@code null},
     * language is {@code 'en'} and source is {@link MetaConst}.{@code META}.
     */
    public KeywordInfo()
    {
        topic = null;
        language = "en";
        source = MetaConst.META;
        initialise();
    }
    
    /** 
     * Create a new instance of KeywordInfo.
     * @param theTopic the topic the keywords relate to. This can be null if not used.
     * @param theLanguage the language of the keywords. Can be null when it defaults
     * to 'en' (English).
     * @param theSource the source of the keywords. Can be null when it defaults
     * to {@link MetaConst}.{@code META}.
     */
    public KeywordInfo(String theTopic, String theLanguage, String theSource)
    {
        topic = theTopic;
        if (theLanguage == null) language = "en";
        else language = theLanguage;
        if (theSource == null) source = MetaConst.META;
        else source = theSource;       
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        keywords = new ArrayList<>();
    }
    
    /**
     * Return true if the two keyword lists match on both topic and word lists.
     * <ol>
     * <li>{@link MetaConst}.{@code ANYSTRUCTURE}: returns true for any match.</li>
     * <li>{@link MetaConst}.{@code ALLPARTIAL}: the keyword must be present in both lists
     * but a matching position is not required. returns true if topics match and any type of
     * keyword list match.</li>
     * <li>{@link MetaConst}.{@code ALLEXACT}: returns true if topics match and keyword lists
     * also match exactly.</li>
     * </ol>
     * @param keyInfo the keyword info to match with.
     * @param matchType the type of matching, as described. If null defaults to {@link MetaConst}.{@code ANYSTRUCTURE}.
     * @return true if a match, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean matchesWith(KeywordInfo keyInfo, String matchType) throws Exception
    {
        float topicScore;                       //topic score
        float keyScore;                         //keywords score
        MatchKeywords compareMeta;              //compare keyword meta
        
        topicScore = (float)0.0;
        if ((topic != null) && (keyInfo.topic != null))
        {
            if (topic.equalsIgnoreCase(keyInfo.topic)) topicScore = (float)1.0;
        }
        
        compareMeta = new MatchKeywords();
        keyScore = compareMeta.compareMetadata(getKeywords(), keyInfo.getKeywords(), matchType);
        
        switch (matchType)
        {
            case MetaConst.ANYSTRUCTURE:
            case MetaConst.ALLPARTIAL:
                return ((topicScore > 0) || (keyScore > 0));
            case MetaConst.ALLEXACT:
                return ((topicScore > 0) || (keyScore > 0.9));
            default:
                return false;
        }
    }
    
    /**
     * Add a keyword to the list of keywords.
     * @param theKeyword the keyword to add.
     */
    public void addKeyword(String theKeyword)
    {
        if (!keywords.contains(theKeyword)) keywords.add(theKeyword);
    }
    
    /**
     * Get the topic.
     * @return the value of topic.
     */
    public String getTopic()
    {
        return topic;
    }
    
    /**
     * Get the language.
     * @return the value of language.
     */
    public String getLanguage()
    {
        return language;
    }
    
    /**
     * Get the source the keywords came from.
     * @return the value of source.
     */
    public String getSource()
    {
        return source;
    }
    
    /**
     * Get the list of keywords.
     * @return the value of keywords.
     */
    public ArrayList<String> getKeywords()
    {
        return keywords;
    }
}
