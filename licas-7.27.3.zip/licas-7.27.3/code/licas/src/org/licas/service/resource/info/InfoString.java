/*
 * InfoString.java
 *
 * Created on 25 March 2015
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.resource.info;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.meta.MetaFactory;
import org.licas.service.InformationService;
import org.licas.service.resource.Resource;
import org.licas.util.Const;
import org.licas.util.exception.LicasException;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;


/**
 * This is used by the {@link InformationService} to store (text)string-based information directly.
 * @author Kieran Greer
 */
public class InfoString extends Resource
{
    /** The logger */
    private static final Logger logger;
    
  
    /** Text-based information source, stored locally only */
    private String textInfo;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(InfoString.class.getName());
        logger.setDebug(false);
    }

    
    /**
     * Create a new instance of InfoText.
     * @param theDataType the resource data type.
     * @param dataXml a description of the initialisation parameters. Can be null.
     * @throws java.lang.Exception any error.
     */
    public InfoString(String theDataType, Element dataXml) throws Exception
    {
        super(theDataType);
        textInfo = null;

        if ((dataXml != null) && !parseInfo(dataXml)) {
            throw new LicasException("Could not parse the data description.");
        }
    }
    
    /**
     * Parse the data description in the document to create the data object.
     * This version should read a string-based description directly and store 
     * it internally. It does not attempt to retrieve the data from a file or process
     * any Action element. So this is always a static piece of information.
     * @param dataXml the outermost element is not checked for, but might be a {@code DATA} 
     * or {@code DATASET} element. This should include a {@code VALUE} element that stores 
     * a String-based piece of text that gets stored in this object for retrieval. 
     * @return true if the file was successfully loaded, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean parseInfo(Element dataXml) throws Exception
    {
        Element dataValueElem;                      //data value element
        
        try {
            setUUID(dataXml);
            dataValueElem = parseValueElem(dataXml);

            if (dataValueElem != null) {
                textInfo = dataValueElem.getText();
                return true;
            }

            return false;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parseInfo",
                null, ex);
        }
    }
    
    /**
     * Get the currently loaded source information wrapped in an XML element.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * Can be null as not used in this version.
     * @return the value of the resource info as an XML element. This format is 
     * consistent with adding a 'Data' element through an admin document.
     * @throws java.lang.Exception any error.
     */
    public Element getInfo(Element infoDescr) throws Exception
    {
        Element sourceInfo;                             //source info
        
        try {
            sourceInfo = XMLFactory.getInstance().createElement(Const.DATA);
            if (textInfo != null) {
                sourceInfo = MetaFactory.getFactoryData().createDataTypeValue(dataType, textInfo);   
            }
            
            return sourceInfo;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getInfo",
                null, ex);
        } 
    }
    
    /**
     * Get the value itself and not a wrapped description.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * Can be null as not used in this version.
     * @return the info value.
     * @throws java.lang.Exception any error.
     */
    public Object getValue(Element infoDescr) throws Exception
    {
        return textInfo;
    }
}
