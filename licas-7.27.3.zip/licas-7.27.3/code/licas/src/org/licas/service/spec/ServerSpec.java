/*
 * ServerSpec.java
 *
 * Created on 30 July 2014
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.service.spec;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.PasswordHandler;
import org.licas.service.ServiceMediator;
import org.licas.util.Const;

import java.net.URL;


/**
 * This class can provide a general specification for the server setup.
 * @author Kieran Greer
 */
public class ServerSpec
{
    /** For logging errors */
    private static final Logger logger;
    
    
    /** If true, start the service threads running after being loaded */
    public boolean startThreads;
    
    /** Server address */
    public String serverAddress;
    
    /** Server password */
    public String password;
    
    /** Server admin key */
    public String adminKey;
    
    /** For referencing a local password store */
    public PasswordHandler passwordHandler;

    /** The service mediator */
    public ServiceMediator serviceMediator;
        

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServerSpec.class.getName());
        logger.setDebug(false);
    }
    
    
    /** 
     * Create a new instance of ServerSpec.
     * @param thePasswordHandler for storing passwords.
     */
    public ServerSpec(PasswordHandler thePasswordHandler)
    {
        passwordHandler = thePasswordHandler;
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        startThreads = false;
        serverAddress = "http://127.0.0.1:8888";
        password = Const.ANON;
        adminKey = Const.ANON;
        serviceMediator = null;
    }
    
    /**
     * Validate the whole script and return a description of any errors.
     * @return a description of any errors or null if OK.
     */
    public String validateScript()
    {
        String validateReply;                   //validation errors
        
        validateReply = "";
        validateReply += validateVariable(Const.STARTTHREADS);
        validateReply += validateVariable(Const.SERVERADDRESS);
        validateReply += validateVariable(Const.SERVERPASSWORD);
        validateReply += validateVariable(Const.SERVERKEY);

        validateReply = validateReply.trim();
        if (validateReply.equals("")) validateReply = null;
        return validateReply;
    }
    
    /**
     * Validate the script variable and return a description if invalid.
     * @param varType the variable type.
     * @return a description of any error, of null if OK.
     */
    protected String validateVariable(String varType)
    {
        String validateError;                   //validate error
        
        validateError = "";
        switch (varType) {
            case Const.CREATESERVICES:
                //createServices - no check here
                break;
            case Const.STARTTHREADS:
                //startThreads - no check here
                break;
            case Const.SERVERADDRESS:
                try {
                    new URL(serverAddress);
                } catch (Exception ex) {
                    validateError = (Const.SERVERADDRESS + ": has incorrect format.\n");
                }
                break;
            case Const.SERVERPASSWORD:
                try {
                    if (password == null)
                        validateError = (Const.SERVERPASSWORD + ": value not entered.\n");
                } catch (Exception ex) {
                    validateError = (Const.SERVERPASSWORD + ": has incorrect format.\n");
                }
                break;
            case Const.SERVERKEY:
                try {
                    if (adminKey == null)
                        validateError = (Const.SERVERKEY + ": value not entered.\n");
                } catch (Exception ex) {
                    validateError = (Const.SERVERKEY + ": has incorrect format.\n");
                }
                break;
        }
        
        return validateError;
    }
}
