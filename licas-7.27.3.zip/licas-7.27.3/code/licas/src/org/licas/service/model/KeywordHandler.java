/*
 * KeywordHandler.java
 *
 * Created on 12 September 2011
 *
 * Version 1.1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.model;


import org.jlog2.util.CollectionHandler;
import org.licas.parsers.admin.KeywordHandlerParser;
import org.licas_xml.abs.Element;

import java.util.*;


/**
 * This stores and processes keywords for any service metadata structure.
 * @author Kieran Greer
 */
public class KeywordHandler 
{
    /**
     * The lists of all keywords in all languages. Key is the topic name and
     * value is another hashmap, where key is the language name and value is
     * another hashmap where key is the source and value is the keyword info object.
     */
    protected HashMap<String, HashMap<String, HashMap<String, KeywordInfo>>> keywordLists;
     
    
    /** Create a new instance of KeywordHandler */
    public KeywordHandler()
    {
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        keywordLists = new HashMap<>();
    }
    
    /**
     * Add a new list of keywords to the keyword structures. This either adds a new
     * info structure or appends to an existing keywords list.
     * @param keywordInfo the keyword info to add.
     */
    public void addKeywordList(KeywordInfo keywordInfo)
    {
        int i;
        String nextKeyword;                                         //next keyword
        HashMap<String, HashMap<String, KeywordInfo>> languageHash; //language hashtable
        HashMap<String, KeywordInfo> sourceHash;                    //source hashtable
        KeywordInfo thisInfo;                                       //existing info
        
        if (!keywordLists.containsKey(keywordInfo.getTopic())) {
            keywordLists.put(keywordInfo.getTopic(), new HashMap<>());
        }
        
        languageHash = keywordLists.get(keywordInfo.getTopic());
        if (!languageHash.containsKey(keywordInfo.getLanguage())) {
            languageHash.put(keywordInfo.getLanguage(), new HashMap<>());
        }
        
        sourceHash = languageHash.get(keywordInfo.getLanguage());
        if (!sourceHash.containsKey(keywordInfo.getSource())) {
            sourceHash.put(keywordInfo.getSource(), keywordInfo);
        }
        else {
            thisInfo = sourceHash.get(keywordInfo.getSource());
            for (i = 0; i < keywordInfo.getKeywords().size(); i++)
            {
                nextKeyword = (String)keywordInfo.getKeywords().get(i);
                thisInfo.addKeyword(nextKeyword);
            }
        }
    }
    
    /**
     * Get any keyword lists for the specified language.
     * @param topic the topic the keywords belong to.
     * @param language the language the keywords were written in. Can be {@code null}
     * when any matching lists are returned.
     * @return a set of combined keyword lists for each source, one for each language.
     */
    public HashMap<String, ArrayList<String>> getKeywords(String topic, String language)
    {
        return getKeywords(topic, language, null);
    }
    
    /**
     * Get any keyword lists for the specified topic, language and source.
     * @param topic the topic the keywords belong to.
     * @param language the language the keywords were written in. Can be {@code null}
     * when any matching lists are returned.
     * @param source the source of the keywords. Can be {@code null} when any matching 
     * lists are returned.
     * @return a set of combined keyword lists for each source, one for each language.
     */
    public HashMap<String, ArrayList<String>> getKeywords(String topic, String language, String source)
    {
        int i, j;
        String nextLanguage;                                        //next language
        String nextSource;                                          //next source
        List<String> languageList;                                  //language list
        ArrayList<String> sourceList;                               //source list
        ArrayList<String> sourceKeywords;                           //list of keywords
        ArrayList<String> nextKeywordList;                          //next list of keywords
        HashMap<String, ArrayList<String>> languageKeywords;        //list of keywords
        HashMap<String, HashMap<String, KeywordInfo>> languageHash; //language hashtable
        HashMap<String, KeywordInfo> sourceHash;                    //source hashtable
        KeywordInfo keywordInfo;                                    //keyword info
        
        languageKeywords = new HashMap<>();
        if (keywordLists.containsKey(topic)) {
            languageHash = keywordLists.get(topic);
            if (language == null) {
                languageList = new ArrayList<>(languageHash.keySet());
            }
            else {
                languageList = new ArrayList<>();
                languageList.add(language);
            }
            
            for (i = 0; i < languageList.size(); i++)
            {
                nextLanguage = languageList.get(i);

                if (languageHash.containsKey(nextLanguage)) {
                    sourceHash = languageHash.get(nextLanguage);
                    if (source == null) {
                        sourceList = new ArrayList<>(sourceHash.keySet());
                    }
                    else {
                        sourceList = new ArrayList<>();
                        sourceList.add(source);
                    }
                    
                    sourceKeywords = new ArrayList<>();
                    for (j = 0; j < sourceList.size(); j++)
                    {
                        nextSource = sourceList.get(j);
                        keywordInfo = sourceHash.get(nextSource);

                        nextKeywordList = keywordInfo.getKeywords();
                        CollectionHandler.addAllSet(sourceKeywords, nextKeywordList);
                    }
                    
                    languageKeywords.put(language, sourceKeywords);
                }
            }
        }
        
        return languageKeywords;
    }

    /**
     * Return a single list of just the keywords only, without any of the context or language details.
     * @return single list of all keywords.
     */
    public ArrayList<String> justKeywords()
    {
        ArrayList<String> keyList;                                  //list of keywords
        ArrayList<String> nextKeywordList;                          //next list of keywords
        HashMap<String, HashMap<String, KeywordInfo>> languageHash; //language hashtable
        HashMap<String, KeywordInfo> sourceHash;                    //source hashtable
        KeywordInfo keywordInfo;                                    //keyword info

        keyList = new ArrayList<>();

        for (String key: keywordLists.keySet())
        {
            languageHash = keywordLists.get(key);
            for (String key2: languageHash.keySet())
            {
                sourceHash = languageHash.get(key2);
                for (String key3: sourceHash.keySet())
                {
                    keywordInfo = sourceHash.get(key3);
                    nextKeywordList = keywordInfo.getKeywords();

                    if (nextKeywordList != null) {
                        keyList.addAll(nextKeywordList);
                    }
                }
            }
        }

        return keyList;
    }

    /**
     * Get all saved lists of all keywords.
     * @return the value of keywordLists.
     */
    public HashMap<String, HashMap<String, HashMap<String, KeywordInfo>>> getKeywordLists()
    {
        return keywordLists;
    }
    
    /**
     * Convert the list of keywords into XML format.
     * @return the keywords structure converted into XML.
     * @throws java.lang.Exception any error.
     */
    public Element keywordsToXml() throws Exception
    {
        KeywordHandlerParser keywordHandlerParser;  //keyword parser
        
        keywordHandlerParser = new KeywordHandlerParser();
        return keywordHandlerParser.serialize(this);
    }
}
