/*
 * ScriptService.java
 *
 * Created on 22 March 2016
 *
 * Version 1.3.1
 *
 * Copyright (c) Kieran Greer
 *
 */

package org.licas.service;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.AutoSecure;
import org.licas.MessageInfo;
import org.licas.module.HeuristicModule;
import org.licas.module.b_module.BM_Script;
import org.licas.module.h_module.HM_Cluster;
import org.licas.module.s_module.SM_Data;
import org.licas.util.ServiceConst;
import org.licas_xml.abs.Element;


/**
 * This service executes a single script process each behaviour invocation. An external script
 * is not read, but the process is hard-coded into the {@code autoEvent} method of the {@link BM_Script}
 * behaviour module. Note that this class also extends the most secure {@link AutoSecure} auto class
 * and so will only have access to limited methods externaly and the message queue.
 * @author Kieran Greer
 */
public class ScriptService extends AutoSecure
{
    /** The logger */
    private static final Logger logger;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ScriptService.class.getName());
        logger.setDebug(false);
    }

    /** 
     * Creates a new instance of ScriptService.
     * Password and service key set to {@code anon} by default.
     * @throws java.lang.Exception any error.
     */
    public ScriptService() throws Exception
    {
        super();        
        initialise();
    }
    
    /** 
     * Creates a new instance of ScriptService.
     * @param thisPassword password to invoke this service.
     * @param thisAdminKey admin key for this service.
     * @throws java.lang.Exception any error.
     */
    public ScriptService(String thisPassword, String thisAdminKey) throws Exception
    {
        super(thisPassword, thisAdminKey);        
        initialise();
    }
    
    /** 
     * Creates a new instance of ScriptService.
     * @param thisPassword password to invoke this service.
     * @param thisAdminKey admin key for this service.
     * @param adminXml the admin info or description of this service.
     * @throws java.lang.Exception any error.
     */
    public ScriptService(String thisPassword, String thisAdminKey, Element adminXml)
            throws Exception
    {
        super(thisPassword, thisAdminKey, adminXml);
        initialise();
    }
    
    /** 
     * Initialise some values.
     * @throws java.lang.Exception any error.
     */
    private void initialise() throws Exception
    {}

    /**
     * This behaviour executes a script on the auto engine and returns the result.
     * @param messageInfo the message to evaluate, but can be null.
     * @return the result of executing the script.
     * @throws java.lang.Exception any error.
     */
    protected MessageInfo behaviourAction(MessageInfo messageInfo) throws Exception
    {
        HeuristicModule evaluate;                   //heuristic evaluation module

        try
        {
            //check that the heuristic has been created
            evaluate = (HM_Cluster)getService(ServiceConst.EVALUATE,
                    passwordHandler.getPassword(), passwordHandler.getAdminKey());

            //run the behaviour and evaluation
            return bm.behaviourAction(messageInfo, evaluate, (SM_Data)sm);
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "behaviourAction", null, ex);
        }
    }
}
