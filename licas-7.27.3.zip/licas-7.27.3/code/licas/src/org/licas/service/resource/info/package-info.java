/**
 * Resource objects for accessing a single data type, information-related.
 */
package org.licas.service.resource.info;