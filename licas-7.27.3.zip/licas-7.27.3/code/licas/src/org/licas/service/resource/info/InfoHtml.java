/*
 * InfoHtml.java
 *
 * Created on 12 September 2013
 *
 * Version 1.4.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.resource.info;


import org.ai_heuristic.util.SymbolHandler;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.meta.MetaFactory;
import org.licas.service.InformationService;
import org.licas.util.AiConst;
import org.licas.util.Const;
import org.licas.util.FileObject;
import org.licas_text.SourceConfig;
import org.licas_text.SourceText;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.io.BufferedReader;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Vector;


/**
 * This is used by the {@link InformationService} to store and parse a remote html file.
 * The content can also be stored locally if the action element declares it to be stored
 * locally through {@link AiConst}.{@code LOADCONTENT}. The default for an html resource is to
 * link to the html file, where the content is dynamically retrieved  and parsed when the 
 * info is requested. An alternative to this would be the {@link InfoStreamXml} resource.
 * @author Kieran Greer
 */
public class InfoHtml extends InfoURL
{
    /** The logger */
    private static final Logger logger;
    
    /** InfoHtml types */
    public static final String TEXTONLY = "TextOnly";
    public static final String REFERENCES = "References";
    
    
    /** List of HTML parts to return, if preferred over a whole document */
    private ArrayList<String> infoParts;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(InfoHtml.class.getName());
        logger.setDebug(false);
    }

    
    /**
     * Create a new instance of InfoHtml.
     * @param theDataType the resource data type.
     * @param dataXml a description of the initialisation parameters. Can be null,
     * or it can specify a list of specific parts to return.
     * @throws java.lang.Exception any error.
     */
    public InfoHtml(String theDataType, Element dataXml) throws Exception
    {
        super(theDataType, dataXml);
    }
    
    /**
     * Parse the data description in the document to create the data object.
     * @param dataXml this must include a {@code VALUE} element that stores a String-based 
     * URL path description. The data is then retrieved from this location upon request.
     * <p>
     * The {@code Value} element can be in one of two forms. It can store directly a String-based 
     * URL file path description, or it can store child elements that include a URL path
     * as well as HTML parts that should be retrieved only. It can therefore look 
     * like either: {@code <Value>url address</Value>} or 
     * {@code <Value><URL>url address</URL><Include>part 1</Include><Include>part 2</Include></Value>}.
     * The include parts are in this case: {@code TEXTONLY}, {@code REFERENCES}.
     * 'Text only' removes all of the html formatting, while 'references' should parse
     * the html document and return a hyperlinks list only.
     * @return true if the file was successfully loaded, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean parseInfo(Element dataXml) throws Exception
    {
        int i;
        String filePath;                            //url file path
        String actionType;                          //the type of action
        Element dataValueElem;                      //data value element
        Element partElem;                           //spec part
        Vector<Node> elemList;                      //child elements list
        
        try
        {
            infoParts = new ArrayList<>();
            url = null;
            setUUID(dataXml);    
            
            dataValueElem = parseValueElem(dataXml);
            if (dataValueElem != null) {
                if (dataValueElem.hasChildren()) {
                    elemList = dataValueElem.getChildren();

                    for (i = 0; i < elemList.size(); i++)
                    {
                        partElem = (Element)elemList.get(i);
                        if (partElem.getName().equals(Const.URL)) {
                            try {
                                url = new URL(dataValueElem.getText());
                            }
                            catch (MalformedURLException muex) {
                                url = new URL(Const.FILEURIPREFIX + dataValueElem.getText());
                                dataValueElem.setText(url.toExternalForm());
                            }
                        }
                        else if (partElem.getName().equals(Const.INCLUDE)) {
                            infoParts.add(partElem.getText());
                        }
                    }
                }
                else {
                    try {
                        url = new URL(dataValueElem.getText());
                    }
                    catch (MalformedURLException muex) {
                        url = new URL(Const.FILEURIPREFIX + dataValueElem.getText());
                        dataValueElem.setText(url.toExternalForm());
                    }
                    
                    filePath = url.toExternalForm();
                    if (filePath != null) {
                        if (FileObject.isHtmlFile(filePath)) {
                            dataValueElem = dataXml.getChild(AiConst.ACTION);       
                            if (dataValueElem != null) {
                                actionType = dataValueElem.getText();
                                if (actionType.equalsIgnoreCase(AiConst.LOADCONTENT)) {
                                    urlData = new FileObject();
                                    urlData.loadFile(filePath);
                                    url = null;
                                }

                                return true;
                            }
                        }  
                    }
                }
                
                return true;
            }

            return false;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parseInfo",
                null, ex);
        }
    }
    
    /**
     * Get the currently loaded source information wrapped in an XML element.
     * This is the whole unparsed html document. Alternatively, if a list of
     * parts to include has been specified in the initialisation script, only those
     * parts get returned instead. 
     * @param infoDescr a description of the info resource value that should be retrieved.
     * Can be null as not used in this version.
     * @return the value of the resource info as an XML element. This format is 
     * consistent with adding a {@code Data} element through an admin document.
     * HTML description is coded, so probably need to use {@code XmlHandler.removeStringSpec(...)} 
     * after retrieving the XML {@code Data} element's text content on the client side.
     * @throws java.lang.Exception any error.
     */
    public Element getInfo(Element infoDescr) throws Exception
    {
        int i;
        String fileText;                                //file as text
        String toInclude;                               //part to include
        Element sourceInfo;                             //source info
        
        try
        {
            sourceInfo = XMLFactory.getInstance().createElement(Const.DATA);
            
            if (infoParts.isEmpty()) {
                fileText = (String)getValue(infoDescr);
                if (fileText != null) {
                    sourceInfo = MetaFactory.getFactoryData().createDataTypeValue(dataType, fileText);
                }
            }
            else {
                for (i = 0; i < infoParts.size(); i++)
                {
                    toInclude = infoParts.get(i);
                    sourceInfo.addContent(getInfoFor(toInclude).getElementChildAtIndex(0));
                }
            }
            
            return sourceInfo;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getInfo",
                null, ex);
        } 
    }
    
    /**
     * Get the currently loaded source information wrapped in an XML element,
     * but return only the part of it that is relevant to the specified variable.
     * for parsed HTML, for example, the readable content ({@code TEXTONLY}) or a list of 
     * HTTP references ({@code REFERENCES}). So the info part can specify this and it can
     * be different or separate from the resource initialisation script.
     * @param thisPart a description of the info part to return.
     * @return the value of the resource info part as an XML element. This format 
     * is consistent with adding {@code Data} through an admin document.
     * @throws java.lang.Exception any error.
     */
    public Element getInfoFor(String thisPart) throws Exception
    {
        int i;
        String nextLine;                                //next line
        StringBuilder fileText;                         //file as text
        String input;                                   //file input
        SourceText sourceText;                          //source text
        ArrayList<URL> linksList;                       //links list
        BufferedReader buffReader;                      //buffered reader
        Element sourceInfo;                             //source info
        
        
        try
        {
            fileText = null;
            sourceText = new SourceText();
            sourceInfo = XMLFactory.getInstance().createElement(Const.DATA);

            if (thisPart.equals(TEXTONLY))
            {
                if (url == null) {
                    input = (String)urlData.getFileContents();
                }
                else {
                    input = sourceText.parseHTML(url, new SourceConfig());
                }
                
                buffReader = new BufferedReader(new StringReader(input));
                while ((nextLine = buffReader.readLine()) != null)
                {
                    if (fileText == null) fileText = new StringBuilder((nextLine + SymbolHandler.NL));
                    else fileText.append(nextLine).append(SymbolHandler.NL);
                }

                if (fileText != null) sourceInfo.setText(fileText.toString());
            }
            else if (thisPart.equals(REFERENCES)) {
                if (url == null) {
                    input = (String)urlData.getFileContents();
                }
                else {
                    input = sourceText.parseHTML(url, new SourceConfig());
                }
                
                buffReader = new BufferedReader(new StringReader(input));
                while ((nextLine = buffReader.readLine()) != null)
                {
                    if (fileText == null) fileText = new StringBuilder((nextLine + SymbolHandler.NL));
                    else fileText.append(nextLine).append(SymbolHandler.NL);
                }

                if (fileText != null) {
                    sourceText.parseHyperLinks(fileText.toString());
                    linksList = sourceText.getHyperLinks();
                    
                    fileText = new StringBuilder();
                    for (i = 0; i < linksList.size(); i++)
                    {
                        fileText.append(linksList.get(i).toExternalForm());
                        if (i < (linksList.size()-1)) fileText.append(SymbolHandler.NL);
                    }
                    
                    sourceInfo = MetaFactory.getFactoryData().createDataTypeValue(dataType, fileText.toString());
                }
            }
            
            return sourceInfo;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getInfoFor",
                null, ex);
        }
    }
    
    /**
     * Get the value itself and not a wrapped description. This is the URL address
     * as a string.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * Can be null as not used in this version.
     * @return the info value.
     * @throws java.lang.Exception any error.
     */
    public Object getValue(Element infoDescr) throws Exception
    {
        try {
            if (url == null) {
                return urlData.getFileContents();
            }
            else {
                return super.getValue(infoDescr);
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getValue",
                null, ex);
        }
    }
}
