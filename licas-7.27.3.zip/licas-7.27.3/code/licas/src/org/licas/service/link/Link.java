/*
 * Link.java
 *
 * Created on 17 February 2007
 *
 * Version 1.15
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.service.link;


import org.ai_heuristic.eval.metric.MetricDataset;
import org.ai_heuristic.tree.*;
import org.ai_heuristic.util.AiHeuristicConst;

import org.licas.*;
import org.licas.module.*;
import org.licas.parsers.LinksParser;
import org.licas.query.LinkQueryConfig;
import org.licas.service.spec.LinkSpec;
import org.licas.util.*;
import org.licas_xml.abs.Element;
import org.jlog2.*;
import org.licas_xml.abs.Node;

import java.util.*;


/**
 * This is an abstract base class for a set of linking methods to dynamically link 
 * components. The derived class should be added as a utility service, to any service 
 * requiring the dynamic linking mechanism. A {@link Tree} structure is used to store any
 * related path information to a set of sources, that are themselves stored in a {@link Thresholds}
 * structure at the end of each path, inside a {@link TreeNode}. There are three default derived versions:
 * <p>
 * {@link Link_B} does not have any memory restrictions. It will also only increment weight
 * values and not decrement them.
 * <p>
 * {@link Link_NM} does not have any memory restrictions, but will decrement weight values as
 * well as increment them.
 * <p>
 * {@link Link_M} restricts the linking structure based on the memory (allowed numbers of entries)
 * and some other options. It also increments and decrements weight values.
 * @author Kieran Greer
 */
public abstract class Link extends ServiceModule
{
    /** The logger */
    private static final Logger logger;
    
    /** 
     * A time stamp indicating the time that a particular source reference is
     * added. This is then stored in the linking structure itself.
     */
    protected long timeStamp;
    
    /** 
     * The dynamic links structure that lists source references. 
     * The linking path now uses a Tree structure. Each node name is the path 
     * value and the node value can be a linking structure. Each node also stores 
     * other child nodes, for the path structure.
     */
    protected Tree linkTree;
    
    /** 
     * This stores the original linking configuration, which is used to initialise the
     * thresholds structures.
     */
    protected LinkSpec linkSpec;
    
    /** Total number of sources at the link level */
    protected int linkCount;
    
    /** Total number of sources at the monitor level */
    protected int monitorCount;
    
    /** Total number of sources at the possible level */
    protected int possibleCount;
    
    /** The maximum number of allowed negative entries for each link */
    protected int maxNegative;
    

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(Link.class.getName());
        logger.setDebug(false);
    }

    /**
     * Creates a new instance of Link. Need to call {@code setServiceDetails} later.
     * @throws Exception any error.
     */
    public Link() throws Exception
    {
        super();
        linkSpec = new LinkSpec();
        resetValues();
    }

    /**
     * Creates a new instance of Link.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public Link(Service service, PasswordHandler pHandler) throws Exception
    {
        super();
        setServiceDetails(service, pHandler);
        linkSpec = new LinkSpec();
        resetValues();
    }

    /**
     * Creates a new instance of Link.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @param thisLinkSpec the config to use for initialising the thresholds structures.
     * @throws java.lang.Exception any error.
     */
    public Link(Service service, PasswordHandler pHandler, LinkSpec thisLinkSpec) throws Exception
    {
        super();
        setServiceDetails(service, pHandler);
        resetValues();

        linkSpec = thisLinkSpec;
        setThresholds(linkSpec);
    }
    
    /**
     * Update the linkSpec structure. Add or update the new sources references
     * and also add these to the added sources list.
     * @param theThresholds the linkSpec structure.
     * @param conceptPath a preferred path to find in the tree.
     * @param newSources list of sources to add or update.
     * @param timeStamp time stamp for update.
     * @param sourcesAdded a list of all added sources over all of the update calls.
     * @param negative a list of negative source results. Can be empty.
     * @throws java.lang.Exception any error.
     */
    protected abstract void updateThresholds(Thresholds theThresholds, ArrayList<String> conceptPath,
                                             ArrayList newSources, long timeStamp,
                                             ArrayList sourcesAdded, ArrayList negative) throws Exception;

    /**
     * Create a new threshold object partially filled in.
     * @return the created threshold source object.
     * @throws java.lang.Exception any error.
     */
    public abstract Thresholds createNewThresholds() throws Exception;
    

    /** Reset the values */
    public void resetValues()
    {
        linkCount = 0;
        monitorCount = 0;
        possibleCount = 0;
        timeStamp = 0;
        maxNegative = Const.DEFAULTMAXNEGATIVE;
        linkTree = new Tree(AiHeuristicConst.TREE, TypeConst.STRING);
    }
    
    /**
     * Set the initial threshold values for this component. This is the method
     * to call to initialise the threshold values. All other linking structures
     * that are created in this service are then initialised with the same values 
     * that are set here.
     * @param copyLinkSpec a full config description for any threshold objects.
     * @throws java.lang.Exception any error.
     */
    public void setThresholds(LinkSpec copyLinkSpec) throws Exception
    {
        linkSpec.copy(copyLinkSpec);
        resetRelatedThresholds();
    }
    
    /**
     * Set the initial threshold values for this component. This is the method
     * to call to initialise the threshold values. All other linking structures
     * that are created in this service are then initialised the same values 
     * that are set here. This method parses an XML-based description of the initial config.
     * @param thresholdsXml the root config element.
     * @throws java.lang.Exception any error. 
     */
    public void setThresholds(Element thresholdsXml) throws Exception
    {
        LinksParser linkParser;                         //linking parser
        
        linkParser = new LinksParser();
        linkSpec = linkParser.xmlToThresholdsConfig(thresholdsXml);
        resetRelatedThresholds();
    }

    /**
     * Set the threshold values for the {@link Thresholds} parameter. The object that is 
     * passed in is set with the default values for this service.
     * @param copyTo the threshold object to set values for.
     * @throws java.lang.Exception any error.
     */
    public void setThresholds(Thresholds copyTo) throws Exception
    {
        copyTo.setLinkSpec(linkSpec);
        copyTo.resetValues();
    }

    /**
     * Reset all end linking threshold structures to the original specification.
     * @throws java.lang.Exception any error.
     */
    protected void resetRelatedThresholds() throws Exception
    {
        Object nextObj;                         //next object
        TreeNode nextNode;                      //next tree node
        Thresholds nextThresholds;              //next set of linkSpec

        nextObj = linkTree.getValue();
        if (nextObj instanceof Thresholds) {
            nextThresholds = (Thresholds)nextObj;
            setThresholds(nextThresholds);
        }
        
        for (String key : linkTree.getChildNodeKeys())
        {
            nextNode = linkTree.getChildNode(key);
            nextObj = nextNode.getValue();

            if (nextObj instanceof Thresholds) {
                nextThresholds = (Thresholds)nextObj;
                setThresholds(nextThresholds);
            }
            
            resetRelatedThresholds(nextNode);
        }
    }

    /**
     * Reset the next end linking threshold structure to the original specification.
     * @param nextSources next sources root node.
     * @throws Exception any error.
     */
    protected void resetRelatedThresholds(TreeNode nextSources) throws Exception
    {
        Object nextObj;                         //next object
        TreeNode nextNode;                      //next tree node
        Thresholds nextThresholds;              //next set of linkSpec

        nextObj = nextSources.getValue();
        if (nextObj instanceof Thresholds) {
            nextThresholds = (Thresholds)nextObj;
            setThresholds(nextThresholds);
        }
        
        for (String key: nextSources.getChildNodeKeys())
        {
            nextNode = nextSources.getChildNode(key);
            nextObj = nextNode.getValue();

            if (nextObj instanceof Thresholds) {
                nextThresholds = (Thresholds)nextObj;
                setThresholds(nextThresholds);
            }
            
            resetRelatedThresholds(nextNode);
        }
    }

    /**
     * Reset all end linking threshold structure updates to zero, for a new update batch.
     * @throws java.lang.Exception any error.
     */
    protected void resetUpdatedThresholds() throws Exception
    {
        Object nextObj;                         //next object
        TreeNode nextNode;                      //next tree node
        Thresholds nextThresholds;              //next set of linkSpec

        nextObj = linkTree.getValue();
        if (nextObj instanceof Thresholds) {
            nextThresholds = (Thresholds)nextObj;
            setThresholds(nextThresholds);
        }
        
        for (String key: linkTree.getChildNodeKeys())
        {
            nextNode = linkTree.getChildNode(key);
            nextObj = nextNode.getValue();

            if (nextObj instanceof Thresholds) {
                nextThresholds = (Thresholds)nextObj;
                setThresholds(nextThresholds);
            }
            
            resetUpdatedThresholds(nextNode);
        }
    }

    /**
     * Reset the next end linking threshold structure updates to zero, for a new update batch.
     * @param nextSources next sources root node.
     * @throws java.lang.Exception any error.
     */
    protected void resetUpdatedThresholds(TreeNode nextSources) throws Exception
    {
        Object nextObj;                         //next object
        TreeNode nextNode;                      //next tree node
        Thresholds nextThresholds;              //next set of linkSpec

        nextObj = nextSources.getValue();
        if (nextObj instanceof Thresholds) {
            nextThresholds = (Thresholds)nextObj;
            setThresholds(nextThresholds);
        }
        
        for (String key: nextSources.getChildNodeKeys())
        {
            nextNode = nextSources.getChildNode(key);
            nextObj = nextNode.getValue();
            
            if (nextObj instanceof Thresholds) {
                nextThresholds = (Thresholds)nextObj;
                setThresholds(nextThresholds);
            }
            
            resetUpdatedThresholds(nextNode);
        }
    }
    
    /**
     * Add sources related by some event to the component. A concept list with a
     * single dummy value of {@link Const}.{@code LINKS} is added.
     * @param sourceList the list of source URIs to add, or link URIs to update.
     * @return ArrayList a list of the sources that have been added.
     * @throws Exception any error.
     */
    public ArrayList<?> addDynamicLinks(ArrayList sourceList) throws Exception
    {
        return addDynamicLinks(sourceList, null, new ArrayList<>());
    }
    
    /**
     * Add sources related by some event to the component.
     * @param sourceList the list of source URIs to add, or link URIs to update.
     * @param conceptList the list of concepts that make up the linking path.
     * This should not be null and include at least 1 value.
     * @return ArrayList a list of the sources that have been added.
     * @throws Exception any error.
     */
    public ArrayList<?> addDynamicLinks(ArrayList sourceList, ArrayList<String> conceptList) throws Exception
    {
        return addDynamicLinks(sourceList, conceptList, new ArrayList<>());
    }
    
    /**
     * Add sources related by some event to the component.
     * @param sourceList the list of source URIs to add, or link URIs to update.
     * @param conceptList the list of concepts that make up the linking path.
     * This should not be null and include at least 1 value. If not, then a concept list 
     * with a single dummy value of {@link Const}.{@code LINKS} is used.
     * @param negative a list of negative comparisons. This can be empty.
     * @return ArrayList a list of the sources that have been added.
     * @throws Exception any error.
     */
    public ArrayList<?> addDynamicLinks(ArrayList sourceList, ArrayList<String> conceptList,
                                             ArrayList negative) throws Exception
    {
        int i;
        String nextKey;                             //next key
        ArrayList<String> conceptPath;              //path of concept values
        ArrayList<?> newSources;                    //new related source references
        ArrayList<?> sourcesAdded;                  //sources added from any call
        TreeNode thisSources;                       //this related sources
        TreeNode newNode;                           //new node
        Thresholds nextThresholds;                  //next set of linkSpec
            
        synchronized(syncOn)
        {
            timeStamp++;
            newSources = sourceList;
            thisSources = linkTree;
            conceptPath = new ArrayList<>();
            sourcesAdded = new ArrayList<>();

            if ((conceptList == null) || conceptList.isEmpty()) {
                conceptList = new ArrayList<>();
                conceptList.add(Const.LINKS);
            }

            for (i = 0; i < conceptList.size(); i++)
            {
                nextKey = conceptList.get(i);
                if (!thisSources.hasChildNode(nextKey)) {
                    newNode = new TreeNode(nextKey, TypeConst.STRING);                   
                    thisSources.addChildNode(newNode);
                }

                thisSources = thisSources.getChildNode(nextKey);
                if (i == (conceptList.size() - 1)) {
                    if (thisSources.getValue() == null) {
                        nextThresholds = new Thresholds(this);
                        setThresholds(nextThresholds);
                        thisSources.setValue(MetricDataset.toDataset(nextThresholds));
                    }

                    nextThresholds = (Thresholds)thisSources.getValue();
                    updateThresholds(nextThresholds, conceptPath, newSources, timeStamp,
                            sourcesAdded, negative);
                }
            }

            return sourcesAdded;
        }
    }

    /**
     * Count the number of instances of each source type in the different threshold structures.
     * @return a list of the total counts. Keys are the source types and values are the instance counts.
     */
    public HashMap<String, Long> getTotalInstancesCount()
    {
        long totalCount;                            //total count of instances
        HashMap<String, Long> totalInstances;       //total instances count
        Thresholds nextThresholds;                  //next set of linkSpec
        TreeNode nextNode;                          //next tree node
        Object nextValue;                           //next value

        totalInstances = new HashMap<>();
        for (String key: linkTree.getChildNodeKeys())
        {
            nextNode = (TreeNode) linkTree.getChildNode(key);
            nextValue = nextNode.getValue();

            if (nextValue instanceof Thresholds) {
                nextThresholds = (Thresholds)nextValue;

                totalCount = nextThresholds.getLinkCount();
                totalCount += nextThresholds.getMonitorCount();
                totalCount += nextThresholds.getPossibleCount();

                if (totalInstances.containsKey(key)) {
                    totalCount += totalInstances.get(key);
                }

                totalInstances.put(key, totalCount);
            }
            
            getTotalInstancesCount(nextNode, totalInstances);
        }

        return totalInstances;
    }

    /**
     * Count the number of instances of each source type in the different threshold structures.
     * @param treeNode next sources list.
     * @param totalInstances instances count.
     */
    protected void getTotalInstancesCount(TreeNode treeNode, HashMap<String, Long> totalInstances)
    {
        long totalCount;                        //total count of instances
        Thresholds nextThresholds;              //next set of linkSpec
        TreeNode nextNode;                      //next tree node
        Object nextValue;                       //next value

        for (String key: treeNode.getChildNodeKeys())
        {
            nextNode = treeNode.getChildNode(key);
            nextValue = nextNode.getValue();

            if (nextValue instanceof Thresholds) {
                nextThresholds = (Thresholds)nextValue;

                totalCount = nextThresholds.getLinkCount();
                totalCount += nextThresholds.getMonitorCount();
                totalCount += nextThresholds.getPossibleCount();

                if (totalInstances.containsKey(key)) {
                    totalCount += totalInstances.get(key);
                }

                totalInstances.put(key, totalCount);
            }
            
            getTotalInstancesCount(nextNode, totalInstances);
        }
    }

    /**
     * Get the total number of sources stored as links in all threshold structures.
     * @param thresholdLevel the threshold level: link, monitor or possible.
     * @return the total number of link sources
     */
    public long getThresholdCount(int thresholdLevel)
    {
        long totalCount;                        //total count of instances
        Thresholds nextThresholds;              //next set of linkSpec
        TreeNode nextNode;                      //next tree node
        Object nextValue;                       //next value

        totalCount = 0;
        for (String key: linkTree.getChildNodeKeys())
        {
            nextNode = linkTree.getChildNode(key);
            nextValue = nextNode.getValue();

            if (nextValue instanceof Thresholds) {
                nextThresholds = (Thresholds)nextValue;

                switch (thresholdLevel) {
                    case Const.LINKSOURCE:
                        totalCount += nextThresholds.getLinkCount();
                        break;
                    case Const.MONITORSOURCE:
                        totalCount += nextThresholds.getMonitorCount();
                        break;
                    case Const.POSSIBLESOURCE:
                        totalCount += nextThresholds.getPossibleCount();
                        break;
                }
            }
            
            totalCount += getThresholdCount(nextNode, thresholdLevel);
        }

        return totalCount;
    }

    /**
     * Get the total number of sources stored as links in all threshold structures.
     * @param treeNode next list of sources.
     * @param thresholdLevel the threshold level: link, monitor or possible.
     * @return the total number of link sources
     */
    public long getThresholdCount(TreeNode treeNode, int thresholdLevel)
    {
        long totalCount;                        //total count of instances
        Thresholds nextThresholds;              //next set of linkSpec
        TreeNode nextNode;                      //next tree node
        Object nextValue;                       //next value

        totalCount = 0;
        for (String key: treeNode.getChildNodeKeys())
        {
            nextNode = treeNode.getChildNode(key);
            nextValue = nextNode.getValue();

            if (nextValue instanceof Thresholds)
            {
                nextThresholds = (Thresholds)nextValue;

                switch (thresholdLevel) {
                    case Const.LINKSOURCE:
                        totalCount += nextThresholds.getLinkCount();
                        break;
                    case Const.MONITORSOURCE:
                        totalCount += nextThresholds.getMonitorCount();
                        break;
                    case Const.POSSIBLESOURCE:
                        totalCount += nextThresholds.getPossibleCount();
                        break;
                }
            }
            
            totalCount += getThresholdCount(nextNode, thresholdLevel);
        }

        return totalCount;
    }
    
    /**
     * Return all linked sources as a string-based description.
     * @param allLevels if true, return all 3 levels, if false only return the top link level
     * references.
     * @param indent for formatting purposes, can be null.
     * @return an string-based representation of the linked sources.
     * @throws Exception any error.
     */
    public String dynamicLinksToString(boolean allLevels, String indent) throws Exception
    {
        LinksParser linksParser;                        //for parsing the links
        
        if ((linkSpec != null) && (linkTree != null)) {
            linksParser = new LinksParser();
            return linksParser.dynamicLinksToString(linkSpec, linkTree, allLevels, indent);
        }
        
        return "";
    }
    
    /**
     * Return all linked sources as a list of XML elements.
     * @param allLevels if true, return all 3 levels, if false only return the top link level
     * references.
     * @param configValues if false, return just the path and source info.
     * If true, include other values, such as config, as well. 
     * @return an XML representation of all linked sources.
     * @throws Exception any error.
     */
    public Element dynamicLinksToXml(boolean allLevels, boolean configValues) throws Exception
    {
        LinksParser linksParser;                        //for parsing the links
        
        linksParser = new LinksParser();
        if (service != null) {
            return linksParser.dynamicLinksToXml(getUUID(), linkSpec, linkTree,
                    allLevels, configValues);
        }
        else {
            return linksParser.dynamicLinksToXml("", linkSpec, linkTree, 
                    allLevels, configValues);
        }
    }
    
    /**
     * Parse the XML description to retrieve a list of linked sources from it.
     * @param rootElem the root tree element to parse from.
     * @return a list of all the link elements in the input parameter.
     */
    public ArrayList<Element> getLinkElements(Element rootElem)
    {
        int i;
        ArrayList<Element> linksList;           //list of link elements
        Element nextElem;                       //next element
        Vector<Node> elemList;                  //element list
        
        linksList = new ArrayList<>();
        elemList = rootElem.getChildren();

        for (i = 0; i < elemList.size(); i++)
        {
            nextElem = (Element)elemList.get(i);
            if (nextElem.getName().equalsIgnoreCase(Const.LINK)) {
                linksList.add(nextElem);
            }
            else {
                linksList.addAll(getLinkElements(nextElem));
            }
        }
        
        return linksList;
    }
    
    /**
     * Parse the xml description and fill the link spec and structure with the dynamic links.
     * @param linksElem the dynamic links description.
     * @throws Exception any error.
     */
    public void xmlToDynamicLinks(Element linksElem) throws Exception
    {
        LinksParser linksParser;                        //for parsing the links
        
        linksParser = new LinksParser();
        linksParser.xmlToDynamicLinks(this, linksElem);
    }

    /**
     * Return a list of sources linked to the current source, using the specified concept path.
     * @param concepts the list of concepts to describe the tree path.
     * @param negativeConcepts a list of concepts that would stop the link being used.
     * This is typically {@code null}.
     * @return a list of uris to linked sources.
     * @throws Exception any error.
     */
    public ArrayList<Object> getLinkSources(ArrayList<String> concepts, ArrayList<Object> negativeConcepts)
            throws Exception
    {
        int i;
        String nextKey;                         //next key
        ArrayList<Object> links;                //list of linked objects
        TreeNode nextSources;                   //next sources
        TreeNode nextTreeNode;                  //next tree node
        Thresholds nextThresholds;              //next set of linkSpec
        Object nextConcept;                     //next concept
        Object nextObj;                         //next object

        links = new ArrayList<>();
        nextSources = linkTree;

        for (i = 0; i < concepts.size(); i++)
        {
            nextConcept = concepts.get(i);
            nextKey = ObjectHandler.getKey(nextConcept);

            if (i == (concepts.size()-1)) {
                if (nextSources.hasChildNode(nextKey)) {
                    nextTreeNode = nextSources.getChildNode(nextKey);
                    nextObj = nextTreeNode.getValue();
                    
                    if (nextObj instanceof Thresholds) {
                        nextThresholds = (Thresholds)nextObj;
                        links = nextThresholds.getLinkSources(negativeConcepts);
                    }
                }
            }
            else {
                if (nextSources.hasChildNode(nextKey)) {
                    nextSources = nextSources.getChildNode(nextKey);
                }
                else {
                    break;
                }
            }
        }

        if (logger.getDebug())
            LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "getLinkSources",
                "returned links: " + String.valueOf(links));

        return links;
    }

    /**
     * Return a list of sources at any level, using the specified concept path.
     * @param concepts the list of concepts to describe the tree path.
     * @return a list of uris to linked sources.
     * @throws Exception any error.
     */
    public ArrayList<Object> getAllSources(ArrayList<String> concepts) throws Exception
    {
        int i;
        String nextKey;                         //next key
        ArrayList<Object> links;                //list of linked objects
        TreeNode nextSources;                   //next sources
        TreeNode nextTreeNode;                  //next tree node
        Thresholds nextThresholds;              //next set of linkSpec
        Object nextConcept;                     //next concept
        Object nextObj;                         //next object

        links = new ArrayList<>();
        nextSources = linkTree;

        for (i = 0; i < concepts.size(); i++)
        {
            nextConcept = concepts.get(i);
            nextKey = ObjectHandler.getKey(nextConcept);

            if (i == (concepts.size()-1)) {
                if (nextSources.hasChildNode(nextKey)) {
                    nextTreeNode = nextSources.getChildNode(nextKey);
                    nextObj = nextTreeNode.getValue();

                    if (nextObj instanceof Thresholds) {
                        nextThresholds = (Thresholds)nextObj;
                        links = nextThresholds.getLinkSources();
                        links.addAll(nextThresholds.getMonitorSources());
                        links.addAll(nextThresholds.getPossibleSources());
                    }
                }
            }
            else {
                if (nextSources.hasChildNode(nextKey)) {
                    nextSources = nextSources.getChildNode(nextKey);
                }
                else {
                    break;
                }
            }
        }

        if (logger.getDebug())
            LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "getAllSources",
                    "returned links: " + String.valueOf(links));

        return links;
    }
    
    /**
     * Perform a query over the link paths to return matching sources.
     * @param queryConfig the query configuration.
     * @return a list of source uris that match with the query.
     * @throws java.lang.Exception any error.
     */
    public Element linkQuery(LinkQueryConfig queryConfig) throws Exception
    {
        ArrayList<String> bestLinks;            //list of linked objects
        LinksParser linksParser;                //links parser
        AnalyseLinks anaLinks;                  //to analyse the links

        linksParser = new LinksParser();
        anaLinks = new AnalyseLinks();
        anaLinks.analyseLinks(linkTree, queryConfig);
        bestLinks = anaLinks.getBestLinks();

        return linksParser.linkSourcesToXml(getUUID(), bestLinks);
    }

    /**
     * Remove the specified source from all linking structures in all (sub)trees.
     * @param source the source representation.
     * @throws java.lang.Exception any error.
     */
    public void removeSource(Object source) throws Exception
    {
        ArrayList<Thresholds> linkList;                 //all thresholds in all (sub)trees

        synchronized(syncOn)
        {
            linkList = new ArrayList<>();
            getLinkThreshold(linkTree, linkList);

            for (Thresholds thresholds : linkList) {
                thresholds.removeSource(Const.LINKSOURCE, source);
                thresholds.removeSource(Const.MONITORSOURCE, source);
                thresholds.removeSource(Const.POSSIBLESOURCE, source);
                thresholds.removeSource(Const.NOSOURCE, source);    //checks reserve
            }
        }
    }

    /**
     * Retrieve all threshold structures in all (sub)trees starting with this one.
     * @param rootNode the tree to start from.
     * @param linkList the list to add the structures to.
     */
    private void getLinkThreshold(TreeNode rootNode, ArrayList<Thresholds> linkList)
    {
        TreeNode nextTreeNode;                  //next tree node
        Thresholds nextThresholds;              //next set of linkSpec
        Object nextObj;                         //next object
        
        nextObj = rootNode.getValue();                    
        if (nextObj instanceof Thresholds) {
            nextThresholds = (Thresholds)nextObj;
            linkList.add(nextThresholds);
        }
        
        for (String key: rootNode.getChildNodeKeys())
        {
            nextTreeNode = rootNode.getChildNode(key);
            getLinkThreshold(nextTreeNode, linkList);
        }
    }
    
    /**
     * Get the current number of entries for the threshold level.
     * @param thresholdType the threshold structure type.
     * @return the number of entries.
     */
    public int getCurrentCount(int thresholdType)
    {
        int theCount = 0;                           //current count

        if (thresholdType == Const.LINKSOURCE) {
            theCount = linkCount;
        }
        else {
            if (thresholdType == Const.MONITORSOURCE) {
                theCount = monitorCount;
            }
            else {
                if (thresholdType == Const.POSSIBLESOURCE) {
                    theCount = possibleCount;
                }
            }
        }

        return theCount;
    }

    /**
     * Return the id of the component.
     * @param componentObj the component representation.
     * @return the id of the component, or null if the component is null.
     */
    protected String getUuid(Object componentObj)
    {
        String thisUuid;                //the uuid

        thisUuid = null;
        if (componentObj != null) {
            if (ObjectHandler.isString(componentObj)) {
                thisUuid = (String)componentObj;
            }
            else {
                thisUuid = ((FrameworkModule)componentObj).getUUID();
            }
        }

        return thisUuid;
    }

    /**
     * Get the dynamic linking specification.
     * @return the value of linkSpec.
     */
    public LinkSpec getLinkSpec() {
        return linkSpec;
    }

    /**
     * Get the list of related sources
     * @return the value of linkTree.
     */
    public Tree getLinkTree()
    {
        return linkTree;
    }
}
