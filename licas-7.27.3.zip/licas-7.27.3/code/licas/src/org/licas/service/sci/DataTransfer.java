/*
 * DataTransfer.java
 *
 * Created on 24 February 2022
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.service.sci;


import org.licas_xml.abs.Element;
import java.util.*;


/** Single list of data for transfer from one service to another */
public class DataTransfer {

    /** Related service type */
    public String type;

    /**
     * Data description. Key is a unique service ID and value is a time-stamped list of data entries.
     */
    public HashMap<String, LinkedHashMap<String, Element>> dataQueue;


    /** Create a new instance of DataTransfer */
    public DataTransfer()
    {
        type = null;
        dataQueue = new HashMap<>();
    }

    /**
     * Get the data description for the indicated tome key.
     * @param timeKey the time key.
     * @return the XML-based data for that entry, or null if it does not exist.
     */
    public Element dataFor(String timeKey)
    {
        for (LinkedHashMap<String, Element> entries : dataQueue.values()) {
            if (entries.containsKey(timeKey))
            {
                return entries.get(timeKey);
            }
        }

        return null;
    }

    /**
     * Return true if the data list contains the indicated time key.
     * @param timeKey the time key.
     * @return true if the time key is an index key.
     */
    public boolean hasTimeKey(String timeKey)
    {
        return allTimeKeys().contains(timeKey);
    }

    /**
     * Get a list of all time keys for all services.
     * @return all time keys in a single list.
     */
    public ArrayList<String> allTimeKeys()
    {
        ArrayList<String> timeKeys;         //time keys

        timeKeys = new ArrayList<>();
        for (LinkedHashMap entries : dataQueue.values()) {
            timeKeys.addAll(entries.keySet());
        }

        return timeKeys;
    }

    /**
     * Remove the data entry for the time-stamp and the whole type if now empty.
     * @param timeKey the time-stamp to remove.
     */
    public void removeEntry(String timeKey)
    {
        LinkedHashMap<String, Element> entries;     //service entries

        for (String id : dataQueue.keySet()) {
            entries = dataQueue.get(id);

            if (entries.containsKey(timeKey)) {
                entries.remove(timeKey);

                if (entries.isEmpty()) {
                    dataQueue.remove(id);
                }

                break;
            }
        }
    }
}
