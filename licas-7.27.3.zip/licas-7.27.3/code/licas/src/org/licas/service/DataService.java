/*
 * DataService.java
 *
 * Created on 24 February 2009
 *
 * Version 1.17.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service;


import org.licas.*;
import org.licas.call.*;
import org.licas.data.*;
import org.licas.data.gen.DataGenerator;
import org.licas.def.DataServiceDef;
import org.licas.meta.MetaFactory;
import org.licas.module.DataModule;
import org.licas.module.s_module.SM_Data;
import org.licas.parsers.Parsers;
import org.licas.service.resource.Resource;
import org.licas.util.*;
import org.licas.util.exception.*;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.licas_xml.abs.*;

import org.ai_heuristic.eval.EvaluateBase;
import org.ai_heuristic.def.EvaluateMathDef;

import java.lang.reflect.Field;
import java.util.*;


/**
 * This is a {@link Service} implementation that includes basic data and evaluation handling. 
 * Storing and evaluating data objects is likely to be useful for a lot of services. Data is at
 * a lower level than information and so the {@link InformationService} is a super class of this one,
 * but all services from {@code Service} up use the same resources to store and return the data values.
 * This class also accepts a data generator and can create the data module later from it.
 * <br>Note the {@code infoXmlDH} method to link any derived service with a {@code DataHub}, or the
 * {@code infoXmlBM} method to link any derived service with a {@code BehaviourMediator}, for example.
 * @author Kieran Greer
 */
public class DataService extends Service implements DataServiceDef
{
    /** The logger */
    private static final Logger logger;


    /** Single operator method to invoke */
    protected MethodInfo dataMethod;
    
    /** Default math evaluator, of basic java types */
    protected EvaluateMathDef dataCompare;

    /** The result object is typically an evaluation over the data */
    protected Object resultObj;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(DataService.class.getName());
        logger.setDebug(false);
    }

    /** 
     * Creates a new instance of DataService.
     * Password and service key set to {@code anon} by default.
     * @throws java.lang.Exception any error.
     */
    public DataService() throws Exception
    {
        super();        
        initialise();
        resetValues();
    }
    
    /** 
     * Creates a new instance of DataService.
     * @param thisPassword password to invoke this service.
     * @param thisAdminKey admin key for this service.
     * @throws java.lang.Exception any error.
     */
    public DataService(String thisPassword, String thisAdminKey) throws Exception
    {
        super(thisPassword, thisAdminKey);        
        initialise();
        resetValues();
    }
    
    /** 
     * Creates a new instance of DataService.
     * @param thisPassword password to invoke this service.
     * @param thisAdminKey admin key for this service.
     * @param adminXml the admin info or description of this service.
     * @throws java.lang.Exception any error.
     */
    public DataService(String thisPassword, String thisAdminKey, Element adminXml)
            throws Exception
    {
        super(thisPassword, thisAdminKey, adminXml);
        initialise();
        resetValues();
    }

    /** Reset values for the next run, empty here. */
    public void resetValues(){}

    /** 
     * Initialise some values.
     */
    private void initialise()
    {
        resultObj = null;
        serviceInitialise = new DataServiceInitialise(this, serviceAdmin, passwordHandler);
    }
    
    /**
     * Set actual values for variable instances if they are defined.
     * <p>
     * {@code NOTE:} you must add this method to your own derived class if you use it,
     * so that the private variables in that class can be accessed. It is ignored
     * unless it gets called through the script initialisation process.
     * @param instanceValues the admin script part that defines instance values.
     * @throws java.lang.Exception any error.
     */
    protected void setInstanceValues(Element instanceValues) throws Exception
    {
        int i;
        String varName;                             //variable name
        Element instanceValue;                      //instance value
        Element nextElem;                           //next element
        Vector<Node> elemList;                      //list of elements
        Field instField;                            //instance field
        Object valueObj;                            //value object
        
        if (instanceValues != null) {
            elemList = instanceValues.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                instanceValue = (Element)elemList.get(i);  
                varName = instanceValue.getAttributeValue(Const.NAME);               
                nextElem = instanceValue.getElementChildAtIndex(0);
                valueObj = Parsers.parse(nextElem);

                if (valueObj != null) {
                    instField = ReflectionHandler.getInstanceField(this, varName);
                    if (instField != null) {
                        try {
                            instField.set(this, valueObj);
                        }
                        catch (Exception ex) {}
                    }
                }
            }
        }
    }
    
    /**
     * Get the value of the specified variable if it exists.
     * <p>
     * {@code NOTE:} you must add this method to your own derived class if you use it,
     * so that the private variables in that class can be accessed. It is ignored
     * unless it gets called through the script initialisation process.
     * @param varName the name of the variable to check for.
     * @throws java.lang.Exception any error.
     */
    protected Object getInstanceValue(String varName) throws Exception
    {
        int i;
        Field nextField;                            //next field
        Field[] fields;                             //fields from this class
        Object fieldValue;                          //field value

        fieldValue = null;
        if ((varName != null) && !varName.equals("")) {
            fields = this.getClass().getDeclaredFields();
            for (i = 0; (fieldValue == null) && (i < fields.length); i++)
            {
                nextField = fields[i];
                if (nextField.getName().equalsIgnoreCase(varName)) {
                    try {
                        fieldValue = fields[i].get(this);
                    }
                    catch (Exception ex) {
                        fieldValue = null;
                    }
                }
            }

            if (fieldValue == null) {
                fields = this.getClass().getFields();
                for (i = 0; (fieldValue == null) && (i < fields.length); i++)
                {
                    nextField = fields[i];
                    if (nextField.getName().equalsIgnoreCase(varName)) {
                        try {
                            fieldValue = fields[i].get(this);
                        }
                        catch (Exception ex) {
                            fieldValue = null;
                        }
                    }
                }
            }
        }

        return fieldValue;
    }
    
    /**
     * Set actual values for serialized variable instances if they are defined.
     * <p>
     * {@code NOTE:} you must add this method to your own derived class if you
     * use it, so that the private variables in that class can be accessed.
     * @param serializeXml the admin script part that defines serialize instance
     * values.
     * @throws java.lang.Exception any error.
     */
    protected void setSerializeValues(Element serializeXml) throws Exception
    {
        int i;
        String varName;                             //variable name
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Vector<Node> elemList;                      //element list
        Field instField;                            //instance field
        Object valueObj;                            //value object

        if (serializeXml != null) {
            elemList = serializeXml.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextElem = (Element) elemList.get(i);
                if (nextElem.getName().equals(Const.SERIALISEVALUE)) {
                    varName = nextElem.getAttributeValue(Const.NAME);

                    if (!varName.equals(MetaConst.ADMIN)) {
                        if (nextElem.hasChildren()) {
                            nextElem2 = nextElem.getElementChildAtIndex(0);
                            valueObj = Parsers.parse(nextElem2);

                            if (valueObj != null) {
                                instField = ReflectionHandler.getInstanceField(this, varName);
                                if (instField != null) {
                                    try {
                                        instField.set(this, valueObj);
                                    }
                                    catch (Exception ex) {}
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Evaluate the data.
     * @param dataQueryModel evaluator query. For this version it must be a {@link ComparisonQueryModel}.
     * @return the evaluation reply.
     * @throws java.lang.Exception and error.
     */
    public Element evaluate(DataQueryModel dataQueryModel) throws Exception
    {
        EvaluateData evaluator;             //evaluate data
        Element dataElem;                   //data element
        Element reply;                      //the reply
        Object replyObj;                    //reply object
        
        try
        {
            dataCompare = null;
            dataMethod = null;
            dataElem = null;

            if (dm != null) {
                evaluator = createEvaluateData(dataQueryModel);
                replyObj = evaluator.evaluate();

                dataElem = XMLFactory.getInstance().createElement(Const.DATASET);
                dataElem.setAttribute(Const.SERVICE, getUUID());
                dataElem.setAttribute(Const.DATATYPE, dm.getDataType());
                dataElem.setText(ObjectHandler.getValue(replyObj));
            }

            reply = XMLFactory.getInstance().createElement(Const.RESULT);
            if (dataElem != null) reply.addContent(dataElem);
            return reply;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "evaluate", null, ex);
        }
    }
    
    /**
     * Create the data evaluator based on the input specification.
     * @param dataQueryModel to store the data evaluator values.
     * @return the created data evaluator.
     * @throws java.lang.Exception any error.
     */
    protected EvaluateData createEvaluateData(DataQueryModel dataQueryModel) throws Exception
    {
        setData(dataQueryModel);
        return new EvaluateData(dataQueryModel);
    }

    /**
     * Create the data evaluator based on the input specification.
     * @param dataQueryModel to store the data evaluator values.
     * @param adminKey the admin key for the parent service.
     * @return the created data evaluator, or {@code null} if the admin key is incorrect.
     * @throws java.lang.Exception any error.
     */
    public EvaluateData createEvaluateData(DataQueryModel dataQueryModel, String adminKey) throws Exception
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            setData(dataQueryModel);
            return new EvaluateData(dataQueryModel);
        }

        return null;
    }
    
    /**
     * Set the random data value, created using the installed data generator.
     * @param adminKey the admin key for this service.
     * @throws java.lang.Exception any error.
     */
    public void setGenData(String adminKey) throws Exception
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            setFixedDataValue();
        }
        else {
            throw new LicasException("Incorrect admin key for service " + getUUID());
        }
    }

    /**
     * If a data generator has been loaded, use it to set a single fixed
     * data value for this service. Add it to the admin details.
     * @throws java.lang.Exception any error.
     */
    protected void setFixedDataValue() throws Exception
    {
        String dataType;                        //data type
        String theData;                         //the data value
        Element dataXml;                        //data XML
        DataGenerator dataGenerator;            //the data generator

        //retrieve data generator and generate random data string
        dataGenerator = (DataGenerator)getService(ServiceConst.DATAGENERATORTYPE,
                passwordHandler.getPassword(), passwordHandler.getAdminKey());

        if (dataGenerator != null) {
            dataType = dataGenerator.getDataType();
            theData = EvaluateBase.valueToString(dataType, dataGenerator.getNextValue());
            dataXml = MetaFactory.getFactoryData().createDataTypeValue(dataType, theData);
            serviceAdmin.getAdminInfo().setData(dataXml);
        }

        //then store the data in the appropriate Resource object
        setDataModule();
    }

    /**
     * Set the value for the local {@link DataModule} dataset, from the query parameters.
     * @param dataQueryModel to store the data evaluator values.
     * @throws java.lang.Exception any error.
     */
    protected void setData(DataQueryModel dataQueryModel) throws Exception
    {
        String dataType;                            //data type
        Element nextElem;                           //next element
        Object dataValue;                           //data value
        Object dataObj;                             //data object

        if (dataQueryModel != null) {
            if (dm.isEmpty()) {
                //must have both data type and value
                if (dataQueryModel.getDataType() != null) {
                    dataType = dataQueryModel.getDataType();
                    dataValue = dataQueryModel.getDataset();

                    if ((dataValue != null) && ObjectHandler.isElement(dataValue)) {
                        nextElem = ((Element) dataValue).getChild(Const.DATATYPE);
                        if (nextElem != null) dataType = nextElem.getText();
                        dataObj = ObjectHandler.dataXmlToValue((Element) dataValue);
                    } else {
                        dataObj = dataValue;
                    }

                    setData(dataType, dataObj, passwordHandler.getAdminKey());
                }
            }
        }
    }

    /**
     * Set the value that this service will use as its data source. This method
     * creates a {@link Resource} in the {@link DataModule} and stores the value directly.
     * @param dataType the data type.
     * @param dataObj the data object.
     * @param adminKey the admin key for the service.
     * @return true if set OK, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean setData(String dataType, Object dataObj, String adminKey) throws Exception
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            dm.setData(dataType, dataObj);
            return true;
        }

        return false;
    }

    /**
     * Get the data type.
     * @return the data type.
     */
    public String getDataType()
    {
        return dm.getDataType();
    }

    /**
     * Return true if the input data type is OK with the current service type.
     * The check can be used when updating the data module or resource, for example.
     * @param dataType the data type, should match with the service and data module.
     * @return true if OK, false otherwise.
     */
    protected boolean dataTypeOK(String dataType)
    {
        return ((dm == null) || (getDataType() == null) ||
                dataType.equalsIgnoreCase(getDataType()));
    }

    /**
     * Get the whole data value.
     * @return the data value in its original format.
     * @throws java.lang.Exception any error.
     */
    public Object getData() throws Exception
    {
        return getData(null);
    }

    /**
     * Get the data value only, based on some condition.
     * @param infoDescr a description of the info resource value that should be retrieved,
     * but can be null.
     * @return the data value in its original format.
     * @throws java.lang.Exception any error.
     */
    public Object getData(Element infoDescr) throws Exception
    {
        if (dm.isEmpty()) {
            setFixedDataValue();
        }
        if (!dm.isEmpty()) {
            return dm.getData(infoDescr);
        }

        return null;
    }

    /**
     * This is used to send the current data and result to a behaviour mediator if one is running.
     * <br>1. The data object is the static metadata {@code Data} entry.
     * <br>2. The result object is retrieved and assumed to be in XMl here.
     * <br>3. This default method also sends link information.
     * <br>The behaviour service can aggregate all of the service info's, to produce graphs or other results.
     * <p>
     * This version sends the data information to a service identified by
     * {@link ServiceConst}.{@code BEHAVIOURMEDIATOR}. It includes the data element
     * of this service, any links that it has formed and also the result of the
     * evaluation process.
     * @param adminKey as it would typically be called internally, it is protected by
     * the service's admin key.
     * @throws java.lang.Exception any other error.
     */
    public void dataXmlBM(String adminKey) throws Exception
    {
        Object result;              //result object if exists

        try {
            if (passwordHandler.isAdminKey(adminKey)) {
                //check result object is in XML and not null.
                result = getResultObj();

                if (result != null) {
                    //if not an element, then try to parse into one
                    if (!ObjectHandler.isElement(result)) {
                        if (TypeConst.isSimpleType(result.getClass().toString())) {
                            result = MetaFactory.createMetaValue(Const.DATA, result);
                        }
                        else {
                            try {
                                result = Parsers.serializeToElement(result);
                            }
                            catch (Exception ex) {
                                result = null;
                            }
                        }
                    }

                    if (result != null) {
                        dataXmlBM(serviceAdmin.getAdminInfo().getData(), (Element) result, true);
                    }
                }
            }
        }
        catch (PasswordException | MethodNotFoundException pe) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "dataXmlBM",
                    null, pe);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "dataXmlBM", null, ex);
        }
    }

    /**
     * This is the implementation used to send the current data result to a behaviour
     * mediator if one is running. The behaviour service can aggregate all of the service
     * info's, to produce graphs or other results.
     * <p>
     * This version sends the data information to a service identified by
     * {@link ServiceConst}.{@code BEHAVIOURMEDIATOR}. It includes the data element
     * of this service, any links that it has formed and also the result of the
     * evaluation process.
     * @param dataXml this is the service's {@code Data} section. It can be null if it
     * should not be sent.
     * @param otherXml is any additional information, such as an evaluation result, or
     * anything that has been dynamically created. It gets added as a sub-element
     * of the outermost reply element.
     * @param links true if include linking information.
     * @throws java.lang.Exception any other error.
     */
    protected void dataXmlBM(Element dataXml, Element otherXml, boolean links) throws Exception
    {
        Element linkElem;                           //link element
        Element reply;                              //the reply
        ServiceSerialize serializer;                //the serializer

        try {
            reply = XMLFactory.getInstance().createElement(Const.RESULT);

            //add the service uuid if missing
            if (reply.getChild(Const.UUID) == null) {
                reply.addContent(MetaFactory.createMetaValue(Const.UUID, getUUID()));
            }

            //add the service's metadata
            if (dataXml != null) {
                reply.addContent(dataXml);
            }

            //add the evaluation result
            if (otherXml != null) {
                reply.addContent(otherXml);
            }

            //add the links
            if (links) {
                serializer = new ServiceSerialize();
                linkElem = serializer.allLinksToXml(this, false, false);
                if (linkElem.hasChildren()) {
                    reply.addContent(linkElem);
                }
            }

            //get data hub if one exists and send this result
            ((SM_Data)sm).dataToService(ServiceConst.BEHAVIOURMEDIATOR, reply);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "dataXmlBM", null, ex);
        }
    }

    /**
     * This is used to send the current data result to a data hub if one is running.
     * The data hub service can aggregate all of the service info's and make it available.
     * <p>
     * This version sends the data information to a service identified by
     * {@link ServiceConst}.{@code DATAHUB}. It includes the data element
     * of this service, any links that it has formed and also the result of the
     * evaluation process.
     * @param adminKey as it would typically be called internally, it is protected by
     * the service's admin key.
     * @throws java.lang.Exception any other error.
     */
    public void dataXmlDH(String adminKey) throws Exception
    {
        Object result;              //result object if exists

        try {
            if (passwordHandler.isAdminKey(adminKey)) {
                //check data object is in XML or null.
                result = dm.getData();
                if (result != null) {
                    //if string can be wrapped
                    if (ObjectHandler.isString(result)) {
                        result = MetaFactory.createMetaValue(Const.DATA, result);
                    }
                    else if (!ObjectHandler.isElement(result)) {
                        result = null;
                    }
                }

                if ((result == null) || ObjectHandler.isElement(result)) {
                    dataXmlDH(serviceAdmin.getAdminInfo().getData(), (Element)result);
                }
            }
        }
        catch (PasswordException pe) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "dataXmlDH",
                    null, pe);
        }
        catch (MethodNotFoundException mnfe) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "dataXmlDH",
                    null, mnfe);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "dataXmlDH", null, ex);
        }
    }

    /**
     * This is used to send the current data result to a data hub if one is running.
     * The data hub service can aggregate all of the service info's and make it available.
     * This method uses the {@code Data-Value} metadata structure to send the data.
     * <p>
     * This version sends the data information to a service identified by
     * {@link ServiceConst}.{@code DATAHUB}. It includes the data element
     * of this service, any links that it has formed and also the result of the
     * evaluation process.
     * @param dataXml this is the service's {@code Data} section. It can be null if it
     * should not be sent.
     * @param otherXml this is a result or other xml piece of data to send. It can be null
     * if it should not be sent.
     * @throws java.lang.Exception any error.
     */
    protected void dataXmlDH(Element dataXml, Element otherXml) throws Exception
    {
        String valueText;                           //value text
        Element valueXml;                           //value element
        Element reply;                              //the reply

        try {
            reply = XMLFactory.getInstance().createElement(ServiceConst.DATAHUBXML);
            reply.setAttribute(Const.UUID, getUUID());
            reply.setAttribute(Const.TYPE, getServiceType());

            //add the service's metadata
            if (dataXml == null) {
                dataXml = MetaFactory.createMeta(Const.DATA);
            }
            if (dataXml.getChild(Const.VALUE) == null) {
                valueXml = MetaFactory.createMeta(Const.VALUE);
                dataXml.addContent(valueXml);
            }
            else {
                valueXml = dataXml.getChild(Const.VALUE);
            }

            valueText = valueXml.getText();
            if ((valueText == null) || valueText.equals("")) {
                if (!valueXml.hasChildren() && (otherXml != null)) {
                    valueXml.addContent(otherXml);
                }
            }

            if (dataXml != null) {
                reply.addContent(dataXml);
            }

            //get data hub if one exists and send this result
            ((SM_Data)sm).dataToService(ServiceConst.DATAHUB, reply);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "dataXmlDH", null, ex);
        }
    }

    /**
     * Set the result value, which is usually an evaluation over the data source.
     * This is typically in XML format.
     * @param thisObj the value to set the result object to.
     */
    public void setResultObj(Object thisObj)
    {
        resultObj = thisObj;
    }

    /**
     * Get the result object value. This is typically in XML format.
     * @return the value of resultObj.
     */
    public Object getResultObj()
    {
        return resultObj;
    }
}
