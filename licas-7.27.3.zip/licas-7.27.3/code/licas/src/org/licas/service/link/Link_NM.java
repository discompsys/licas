/*
 * Link_NM.java
 *
 * Created on 20 July 2011
 *
 * Version 1.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.link;


import org.licas.PasswordHandler;
import org.licas.Service;
import org.licas.service.spec.LinkSpec;
import org.jlog2.*;

import java.util.ArrayList;


/**
 * This is an implementation of a linking service that does not apply any memory
 * restrictions, but both increments and decrements links depending on their use.
 * @author Kieran Greer
 */
public class Link_NM extends Link_B
{
    /** The logger */
    private static final Logger logger;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(Link_NM.class.getName());
        logger.setDebug(false);
    }

    /**
     * Creates a new instance of Link_NM. Need to call {@code setServiceDetails} later.
     * @throws Exception any error.
     */
    public Link_NM() throws Exception
    {
        super();
    }

    /**
     * Creates a new instance of Link_NM.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public Link_NM(Service service, PasswordHandler pHandler) throws Exception
    {
        super(service, pHandler);
    }

    /**
     * Creates a new instance of Link_NM.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @param thisLinkSpec the config to use for initialising the thresholds structures.
     * @throws java.lang.Exception any error.
     */
    public Link_NM(Service service, PasswordHandler pHandler, LinkSpec thisLinkSpec) throws Exception
    {
        super(service, pHandler, thisLinkSpec);
    }

    /**
     * Update the linkSpec structure. Add or update the new sources references
     * and also add these to the added sources list.
     * @param theThresholds the linkSpec structure.
     * @param conceptPath a preferred path to find in the tree.
     * @param newSources list of sources to add or update.
     * @param timeStamp time stamp for update.
     * @param sourcesAdded a list of all added sources over all of the update calls.
     * @param negative a list of negative source results. Can be empty.
     * @throws java.lang.Exception any error.
     */
    protected void updateThresholds(Thresholds theThresholds, ArrayList<String> conceptPath,
                                    ArrayList newSources, long timeStamp,
                                    ArrayList sourcesAdded, ArrayList negative) throws Exception
    {
        int i;
        boolean addNegative;                    //true if add negative concepts
        ArrayList<Object> sourcesToMove;        //list of sources to move down
        
        addNegative = LinkConfig.addNegative(linkSpec.linkMethod);  
        
        //move sources not used in this answer down if required
        sourcesToMove = theThresholds.sourcesToMoveDown(newSources);
        for (i = 0; i < sourcesToMove.size(); i++)
        {
            theThresholds.moveSourceDown(sourcesToMove.get(i));
        }
        
        for (i = 0; i < newSources.size(); i++)
        {
            theThresholds.incAndMoveSourceUp(newSources.get(i), timeStamp);
            sourcesAdded.add(newSources.get(i));

            if (addNegative && ((negative != null) && !negative.isEmpty())) {
                theThresholds.storeNegatives(newSources.get(i), negative);
            }
        }
    }
}
