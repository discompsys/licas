/*
 * ThresholdSource.java
 *
 * Created on 30 January 2007.
 *
 * Version 1.3
 *
 * Copyright (c) Kieran Greer.
 */

package org.licas.service.link;


import org.licas.util.Const;

import java.util.ArrayList;
import java.util.Date;


/**
 * This class stores values relating to a linked source, stored in a {@link Thresholds} structure.
 * Each reference in the Thresholds structure needs certain information about each source it
 * is linking with, including the current link value, or the source reference itself,
 * including probably a URI description. As this is different for each source, the information
 * is stored here.
 * @author Kieran Greer
 */
public class ThresholdSource 
{
    /** The maximum number of allowed negative entries at all levels */
    protected int negativeMax;
    
    /** 
     * The source representation as stored in the thresholds structure,
     * e.g. full path or reference.
     */
    public Object source;
    
    /** A list of negative related concepts */
    public Thresholds negativeConcepts;
    
    /** The source value */
    public float value;
    
    /** A time stamp indicating the last time the source was incremented */
    public long timeStamp;
    
    /** The parent thresholds structure */
    public Thresholds parent;
    
    
    /** 
     * Creates a new instance of ThresholdSource.
     * The maximum allowed negative entries is set to {@link Const}.{@code DEFAULTMAXNEGATIVE}.
     * The value itself is a special case however and not generally used.
     * @param thisParent the parent thresholds structure.
     */
    public ThresholdSource(Thresholds thisParent)
    {
        source = null;
        negativeMax = Const.DEFAULTMAXNEGATIVE;
        negativeConcepts = null;
        parent = thisParent;
        value = Float.MAX_VALUE;
        timeStamp = Long.MIN_VALUE;
    }
    
    /** 
     * Creates a new instance of ThresholdSource.
     * @param thisNegativeMax the maximum number of negative allowed entries.
     * @param thisParent the parent thresholds structure.
     */
    public ThresholdSource(int thisNegativeMax, Thresholds thisParent)
    {
        source = null;
        negativeMax = thisNegativeMax;
        negativeConcepts = null;
        parent = thisParent;
        value = Float.MAX_VALUE;
        timeStamp = Long.MIN_VALUE;
    }
    
    /** 
     * Return true if any of the negative concepts are stored with the link.
     * @param theNodes the node sources to add as negative, in relation to concepts(parts).
     * @return true if any concepts in the list are at the link level in this
     * structure.
     * @throws java.lang.Exception any error.
     */
    public boolean hasNegative(ArrayList<Object> theNodes) throws Exception
    {
        int i;
        int sourceLevel;                            //source level
        Object nextConcept;                         //next concept
        
        if (negativeConcepts != null) {
            for (i = 0; i < theNodes.size(); i++)
            {
                nextConcept = theNodes.get(i);
                sourceLevel = negativeConcepts.getSourceLevel(nextConcept);
                if (sourceLevel == Const.LINKSOURCE) return true;
            }
        }
        
        return false;
    }
    
    /** 
     * Add the specified negative relations to the list.
     * @param theNodes the node sources to add as negative, in relation to concepts(parts).
     * @throws java.lang.Exception any error.
     */
    public void addNegative(ArrayList<Object> theNodes) throws Exception
    {
        int i;
        int sourceLevel;                            //source level
        String nextConcept;                         //next concept
        ArrayList sourcesToMove;                       //sources to move down
        ThresholdSource minSource;                  //minimum source
       
        if (negativeConcepts == null) {
            negativeConcepts = parent.parent.createNewThresholds();
        }
        
        //move existing concepts down if not part of current list
        sourcesToMove = negativeConcepts.sourcesToMoveDown(theNodes);
        for (i = 0; i < sourcesToMove.size(); i++)
        {
            negativeConcepts.moveSourceDown(theNodes.get(i));
        }
        
        //update links for current list
        for (i=0; i < theNodes.size(); i++)
        {
            nextConcept = (String)theNodes.get(i);
            sourceLevel = negativeConcepts.getSourceLevel(nextConcept);
            
            //negativeMax is the memory allocation
            //if new entry, then check total number overall, if total at the maximum
            //then remove an existing one before adding the new one, otherwise 
            //just add new one without other memory considerations
            if (sourceLevel == Const.NOSOURCE) {
                if (negativeConcepts.getSourceCount() > negativeMax) {
                    //too many sources, so remove one from lowest available level
                    minSource = negativeConcepts.getMinSource(Const.POSSIBLESOURCE);                    
                    if (minSource != null) {
                        negativeConcepts.removeSource(Const.POSSIBLESOURCE, minSource.source);
                    }
                    else {
                        minSource = negativeConcepts.getMinSource(Const.MONITORSOURCE);                    
                        if (minSource != null) {
                            negativeConcepts.removeSource(Const.MONITORSOURCE, minSource.source);
                        }
                        else {
                            minSource = negativeConcepts.getMinSource(Const.LINKSOURCE);                    
                            if (minSource != null) {
                                negativeConcepts.removeSource(Const.LINKSOURCE, minSource.source);
                            }
                        }
                    }
                }                
            }

            negativeConcepts.incAndMoveSourceUp(nextConcept, new Date().getTime());
        }
    }
    
    /**
     * Return true if object not yet assigned new values.
     * @return true if not assigned new values.
     */
    public boolean notAssigned()
    {
        return ((source == null) || (value == Float.MAX_VALUE));
    }
}
