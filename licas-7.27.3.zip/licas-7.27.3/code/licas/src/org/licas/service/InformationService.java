/*
 * InformationService.java
 *
 * Created on 6 June 2011
 *
 * Version 1.11.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service;


import org.licas.MessageInfo;
import org.licas.meta.MetaFactory;
import org.licas.module.s_module.SM_Auto;
import org.licas.service.resource.Resource;
import org.licas.service.sci.LinkService;
import org.licas.util.*;
import org.licas.util.exception.LicasException;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;


/**
 * <p>This class can be used to retrieve information from a {@link Resource} source.
 * The resource is initialised in the service through the admin XML {@code Data} element,
 * which is now configurable for different dat2a types and even nested lists or containers.</p>
 * <p>Information may typically be used as part of a {@code Publish-Subscribe} process and not
 * a data calculation one. The behaviour loop has therefore been set to 1 whole day, instead
 * of the AI value of {@link ServiceConst}.{@code BEHAVIOURSLEEP} of a few milliseconds.
 * You can change this value to whatever in your code via {@code sleepTime = milliseconds;}</p>
 * @author Kieran Greer
 */
public class InformationService extends LinkService
{
    /** The logger */
    private static final Logger logger;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(InformationService.class.getName());
        logger.setDebug(false);
    }

    /**
     * Create a new instance of InformationService.
     * @throws java.lang.Exception any error.
     */
    public InformationService() throws Exception
    {
        super();
        initialise();
    }

    /**
     * Creates a new instance of InformationService.
     * @param thisPassword the component password.
     * @param thisAdminKey the unique service key.
     * @throws java.lang.Exception any error.
     */
    public InformationService(String thisPassword, String thisAdminKey) throws Exception
    {
        super(thisPassword, thisAdminKey);
        initialise();
    }
    
    /** 
     * Creates a new instance of InformationService.
     * @param thisPassword the component password.
     * @param thisAdminKey the unique service key.
     * @param adminXml the admin info or description of this service. This can include
     * a resource to load, so do not pass to parent class, but initialise separately.
     * @throws java.lang.Exception any error.
     */
    public InformationService(String thisPassword, String thisAdminKey, Element adminXml)
            throws Exception
    {
        super(thisPassword, thisAdminKey, adminXml);
        initialise();
    }

    /**
     * Initialise some values. Set the behaviour loop time to 1 whole day,
     * so update the information only once each day by default.
     */
    private void initialise()
    {
        this.sleepTime = TimeConst.MILLIDAY;
    }

    /**
     * This is a method to be invoked by something like a RESTFul or HTTP Server call.
     * It is supposed to copy the HTTP GET protocol method and return the content of
     * this service, as a String. This version returns the {@code getValue(...)} value of 
     * the information service. Note that the value {@link Const}.{@code SEPCHARS} can be
     * used to parse the String reply.
     * @return a String-based value representing the content of the service.
     * @throws java.lang.Exception any error.
     */
    public String GET() throws Exception
    {
        String dataType;                        //data type
        String dataValue;                       //the data value
        Object dataObj;                         //data object
        
        dataValue = "";
        if (dm != null) {
            dataType = dm.getDataType();
            dataObj = dm.getData();

            if (dataObj != null) {
                if (TypeConst.isBinaryType(dataType) && ObjectHandler.isString(dataObj)) {
                    dataValue = (TypeConst.BINARYFILE + Const.SEPCHARS + dataObj);
                } else if (dataObj instanceof byte[]) {
                    dataValue = (TypeConst.BINARYFILE + Const.SEPCHARS + new String((byte[]) dataObj));
                } else if (dataObj instanceof Element) {
                    dataValue = (TypeConst.XMLFILE + Const.SEPCHARS + XmlHandler.xmlToString((Element) dataObj));
                } else {
                    dataValue = (dataType + Const.SEPCHARS + String.valueOf(dataObj));
                }
            }
        }

        return dataValue;
    }
    
    /**
     * Set the random data value, created using the installed data generator.
     * @param adminKey the admin key for this service.
     * @throws java.lang.Exception any error.
     */
    public void setGenData(String adminKey) throws Exception
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            setFixedDataValue();
        }
        else {
            throw new LicasException("Incorrect admin key for service " + getUUID());
        }
    }

    /**
     * This behaviour retrieves the resource information and publishes it on the server. Any other
     * service that subscribes for it is then sent the information through a push activity. The result
     * is also sent to a {@code Behaviour Mediator} service for viewing, but that is probably optional.
     * The evaluation result is then returned as the method result.
     * @param messageInfo the message to evaluate. This behaviour works internally only, and so the
     * external message can be {@code null}.
     * @return the result of executing the behaviour.
     * @throws java.lang.Exception any error.
     */
    protected MessageInfo behaviourAction(MessageInfo messageInfo) throws Exception
    {
        MessageInfo messageReply;               //message reply

        try {
            //can use for the publish information
            messageInfo = new MessageInfo(serviceAdmin.getKeywordHandler().justKeywords());

            //run the behaviour and evaluation
            messageReply = bm.behaviourAction(messageInfo, null, (SM_Auto)sm);

            //added in case the default script sets a value for the result
            if (getResultObj() != null) {
                dataXmlBM(passwordHandler.getAdminKey());
            }

            return messageReply;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "behaviourAction", null, ex);
        }
    }

    /**
     * Get the source information, as parsed and coded XML in String format. 
     * This is the most reliable method for a remote call, as it also codes the String 
     * so that it can be transferred across the servers.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * This can be null if there is no query description.
     * @return the value of {@code infoResource} as a coded string. This is a string in XML
     * format that is consistent with the {@code Data} format in the admin document. It is 
     * automatically decoded when received by the client-side methods and can then be 
     * parsed back into XML using the {@code XmlHandler.stringToElement} method. 
     * @throws java.lang.Exception any error.
     * @deprecated this method is inefficient because it codes and decodes too many times,
     * so use {@code getInfoElement} instead.
     */
    public String getSourceInfo(Element infoDescr) throws Exception
    {
        String sourceString;                    //source as a string
        Element sourceInfo;                     //source info
        
        try {
            if (infoDescr == null) sourceInfo = getInfoElement();
            else sourceInfo = getInfoElement(infoDescr);
            
            if (sourceInfo != null) {
                sourceString = XmlHandler.xmlToString(sourceInfo);
                sourceString = XmlHandler.addStringSpec(sourceString); 
            }
            else {
                sourceString = Const.NULL;
            }

            return sourceString;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getSourceInfo",
                null, ex);
        } 
    }
    
    /**
     * Get the currently loaded source information as an XML element. This probably
     * returns the format {@code <Data><Value>Info value here</Value><Value_Type>Info value type</Value_Type></Data>}.
     * @return the value of {@code infoResource} as an XML element.
     * @throws java.lang.Exception any error.
     */
    public Element getInfoElement() throws Exception
    {
        try {
            return getInfoElement(null);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "getInfoElement", null, ex);
        } 
    }
    
    /**
     * Get the currently loaded source information as an XML element. This probably
     * returns the format {@code <Data><Value>Info value here</Value><Value_Type>Info value type</Value_Type></Data>}.
     * @param infoDescr a description of the info resource value that should be retrieved,
     *                  or can be {@code null}.
     * @return the value of {@code infoResource} as an XML element.
     * @throws java.lang.Exception any error.
     */
    public Element getInfoElement(Element infoDescr) throws Exception
    {
        Element sourceElem;                     //source info

        try {
            //can be stored either as an XML Data element in the admin doc or
            //as an info resource object
            sourceElem = null;           
            if (dm.isEmpty()) {
                setFixedDataValue();
            }
            if (!dm.isEmpty()) {
                sourceElem = dm.getResource().getInfo(infoDescr);
            }
            
            return sourceElem;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "getInfoElement", null, ex);
        } 
    }
    
    /**
     * Load data contents onto the service, so store the information directly on the
     * service. This can be dangerous because it will overwrite the current data module.
     * The contents description is then copied to the metadata {@code Data} element.
     * @param dataType the type of data to load.
     * @param urlPath the file path as a local or remote url.
     * @throws java.lang.Exception any error.
     */
    public void loadDataContents(String dataType, String urlPath) throws Exception
    {
        Element dataXml;                        //data XML description

        //the load contents command on the resource determines if the file is read locally
        dataXml = MetaFactory.getFactoryAI().createDataAction(dataType, urlPath,
                MethodConst.LOADDATACONTENTS);

        //parse data description to create the info resource
        serviceAdmin.getAdminInfo().setData(dataXml);
        setDataModule();
    }
    
    /**
     * Load data details onto the service, which is a description of the external source and
     * the information is retrieved from the external source each time. This can be dangerous
     * because it will overwrite the current data module. The contents description is then
     * copied to the metadata {@code Data} element. The external source an be local or remote.
     * @param dataType the type of data to load.
     * @param urlPath the file path as a local or remote url.
     * @throws java.lang.Exception any error.
     */
    public void loadDataDetails(String dataType, String urlPath) throws Exception
    {
        Element dataXml;                        //data XML

        dataXml = MetaFactory.getFactoryAI().createDataAction(dataType, urlPath,
                AiConst.LOADREMOTE);

        //parse data description to create the info resource
        serviceAdmin.getAdminInfo().setData(dataXml);
        setDataModule();
    }
    
    /**
     * Create a new resource object from a new admin document.
     * @param adminDataXml the new admin data section. Replaces the existing data
     * section completely.
     * @throws java.lang.Exception any error.
     */
    public void loadDataScript(Element adminDataXml) throws Exception
    {
        serviceAdmin.getAdminInfo().setData(adminDataXml);
        setDataModule();
        initialise();
    }
}
