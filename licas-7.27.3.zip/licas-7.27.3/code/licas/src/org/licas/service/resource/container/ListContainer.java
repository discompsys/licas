/*
 * ListContainer.java
 *
 * Created on 5 November 2014
 *
 * Version 1.2.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.resource.container;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.call.CallPool;
import org.licas.call.MethodInfo;
import org.licas.service.resource.Resource;
import org.licas.util.Const;
import org.licas.util.TypeConst;
import org.licas.util.exception.LicasException;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;


/**
 * This can be used to store an array or set of {@link Resource} derived objects that 
 * can then be invoked upon request. Either the full list of resources can be returned
 * or a list as defined by a set of IDs (typically the resource {@code uuid}). The resource 
 * objects do not have to be of the same type and it is their {@code getInfo} or {@code getValue} 
 * methods that are invoked. A container might be initialised with a script that includes 
 * the details of the stored resources. 
 * @author Kieran Greer
 */
public class ListContainer extends ResourceContainer
{
    /** The logger */
    private static final Logger logger;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ListContainer.class.getName());
        logger.setDebug(false);
    }

    
    /**
     * Create a new instance of ListContainer.
     * @param theDataType the container type.
     * @throws java.lang.Exception any error.
     */
    public ListContainer(String theDataType) throws Exception
    {
        super(theDataType);
        initialise(null);
    }

    /**
     * Create a new instance of ListContainer.
     * @param theDataType the container type.
     * @param dataXml a description of the initialisation parameters.
     * @throws java.lang.Exception any error.
     */
    public ListContainer(String theDataType, Element dataXml) throws Exception
    {
        super(theDataType);
        initialise(dataXml);
    }
    
    /** 
     * Initialise some values.
     * @param dataXml a description of the initialisation parameters.
     * @throws java.lang.Exception any error.
     */
    private void initialise(Element dataXml) throws Exception
    {
        if ((dataXml != null) && !parseInfo(dataXml)) {
            throw new LicasException("Could not parse the data description");
        }
    }
    
    /**
     * Parse the data description in the admin document to create the data object.
     * @param dataXml the {@code Data} element of the admin document. This should include
     * the container {@code DataType} element and a {@code Value} element that stores 
     * a list of child {@code Data} elements that store information for each resource to create. 
     * These are processed as defined in the individual resource object comments.
     * @return true if any specified resources are successfully added, false otherwise.
     * @throws java.lang.Exception any error.
     */
    protected boolean parseInfo(Element dataXml) throws Exception
    {
        return super.parseInfo(dataXml);
    }
    
    /**
     * Get the source information wrapped in an XML element.
     * @param infoDescr a description of the info resource values that should be retrieved.
     * This can be empty, or include a list of ID elements, each of which stores a resource 
     * id to retrieve.
     * @return a value for every resource in the list. This format is consistent with adding 
     * an XML {@code Data} element through an admin document.
     * @throws java.lang.Exception any error.
     */
    public Element getInfo(Element infoDescr) throws Exception
    {
        int i;
        String resourceID;                          //the resource uuid
        Resource infoResource;                      //info resource
        Element infoElem;                           //info element
        Element dataElem;                           //data element
        Element sourceInfo;                         //source info
        ArrayList<String> idList;                   //list of resource ids
        Vector<Node> elemList;                      //list of child elements
        HashMap<String, MethodInfo> methodInfos;    //resource methods
        Map<String, Object> resultSet;              //resource replies
        MethodInfo methodInfo;                      //next method
        CallPool callPool;                          //call threads

        try
        {
            infoResource = null;
            methodInfos = new HashMap<>();
            resultSet = new HashMap<>();
            sourceInfo = XMLFactory.getInstance().createElement(Const.DATA);          
            
            //determine the resource list
            if ((infoDescr == null) || !infoDescr.hasChildren())
            {
                //all resources
                idList = new ArrayList<>(resourceList.keySet());
            }
            else
            {
                idList = new ArrayList<>();

                elemList = infoDescr.getChildren();
                for (i = 0; i < elemList.size(); i++)
                {
                    infoElem = (Element)elemList.get(i);
                    if (infoElem.getName().equalsIgnoreCase(Const.UUID)) {
                        resourceID = infoElem.getText();
                        idList.add(resourceID);
                    }
                }
            }

            for (i = 0; i < idList.size(); i++)
            {
                try {
                    resourceID = idList.get(i);
                    if ((resourceID != null) && !resourceID.equals("")) {
                        if (resourceList.containsKey(resourceID)) {
                            infoResource = resourceList.get(resourceID);
                            methodInfo = new MethodInfo();
                            methodInfo.setServiceURI(infoResource);
                            methodInfo.setName("getInfo");
                            methodInfo.setRtnType(TypeConst.ELEMENT);
                            methodInfo.addParam(null);
                            methodInfos.put(infoResource.getUUID(), methodInfo);
                        }
                    }
                }
                catch (Exception ex) {
                    dataElem = XMLFactory.getInstance().createElement(Const.ERROR);
                    if (infoResource != null) {
                        dataElem.setText(infoResource.getUUID());
                    }

                    sourceInfo.addContent(dataElem);
                }
            }
            
            //run the resources on a thread pool
            if (!methodInfos.isEmpty()) {
                callPool = new CallPool(methodInfos);
                callPool.executeOnce();

                while (!callPool.getShutDown())
                {
                    Thread.currentThread().wait();
                }

                resultSet = callPool.getResults();
            }
              
            //process the results
            if ((resultSet != null) && !resultSet.isEmpty()) {
                for (i = 0; i < idList.size(); i++)
                {
                    resourceID = idList.get(i);
                    if ((resourceID != null) && !resourceID.equals("")) {
                        dataElem = (Element)resultSet.get(resourceID);

                        if (dataElem == null) {
                            dataElem = XMLFactory.getInstance().createElement(Const.ERROR);
                            if (infoResource != null) {
                                dataElem.setText(infoResource.getUUID());
                            }
                        }

                        sourceInfo.addContent(dataElem);
                    }
                }
            }

            return sourceInfo;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getInfo",
                null, ex);
        } 
    }
    
    /**
     * Get the currently selected value itself and not a wrapped description.
     * This can be empty, or include a list of ID elements, each of which stores a resource 
     * id to retrieve.
     * @return a list storing a value for every resource in the list.
     * @throws java.lang.Exception any error.
     */
    public ArrayList<Object> getValue(Element infoDescr) throws Exception
    {
        int i;
        String resourceID;                          //the resource uuid
        Resource infoResource;                      //info resource
        Element infoElem;                           //info element
        Vector<Node> elemList;                      //list of child elements
        ArrayList<String> resourceIDs;              //list of ids
        ArrayList<Object> valueList;                //list of values
        Object resourceValue;                       //resource value        
        HashMap<String, MethodInfo> methodInfos;    //resource methods
        Map<String, Object> resultSet;              //resource replies
        MethodInfo methodInfo;                      //next method
        CallPool callPool;                          //call threads
        
        try {
            valueList = new ArrayList<>();
            methodInfos = new HashMap<>();
            resultSet = new HashMap<>();
            resourceIDs = new ArrayList<>(resourceList.keySet());
            
            if ((infoDescr == null) || !infoDescr.hasChildren()) {
                //all resources
                for (i = 0; i < resourceIDs.size(); i++)
                {
                    resourceID = resourceIDs.get(i);
                    infoResource = resourceList.get(resourceID);

                    methodInfo = new MethodInfo();
                    methodInfo.setServiceURI(infoResource);
                    methodInfo.setName("getValue");
                    methodInfo.setRtnType(TypeConst.OBJECT);
                    methodInfo.addParam(infoDescr);
                    methodInfos.put(infoResource.getUUID(), methodInfo);
                }
            }
            else {
                //specific list of resources
                try {
                    elemList = infoDescr.getChildren();
                    for (i = 0; i < elemList.size(); i++)
                    {
                        infoElem = (Element)elemList.get(i);

                        resourceID = infoElem.getText();                    
                        if ((resourceID != null) && !resourceID.equals("")) {
                            if (resourceIDs.contains(resourceID)) {
                                infoResource = resourceList.get(resourceID);
                                methodInfo = new MethodInfo();
                                methodInfo.setServiceURI(infoResource);
                                methodInfo.setName("getValue");
                                methodInfo.setRtnType(TypeConst.OBJECT);
                                methodInfo.addParam(infoDescr);
                                methodInfos.put(infoResource.getUUID(), methodInfo);
                            }
                        }
                    }
                }
                catch (Exception ex) {}
            }
            
            //run the resources on a thread pool
            if (!methodInfos.isEmpty()) {
                callPool = new CallPool(methodInfos);
                callPool.executeOnce();

                while (!callPool.getShutDown())
                {
                    Thread.currentThread().wait();
                }

                resultSet = callPool.getResults();
            }
              
            //process the results
            if ((resultSet != null) && !resultSet.isEmpty()) {
                for (i = 0; i < resourceIDs.size(); i++)
                {
                    try {
                        resourceID = resourceIDs.get(i);
                        infoResource = resourceList.get(resourceID);
                        resourceValue = resultSet.get(infoResource.getUUID());

                        if (resourceValue != null) {
                            valueList.add(resourceValue);
                        }
                    }
                    catch (Exception ex) {}
                }
            }
            
            return valueList;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getValue",
                null, ex);
        }
    }
}
