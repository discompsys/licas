/*
 * Link_M.java
 *
 * Created on 17 February 2007
 *
 * Version 1.7
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.link;


import org.ai_heuristic.tree.TreeNode;
import org.licas.PasswordHandler;
import org.licas.Service;
import org.licas.call.*;
import org.licas.service.spec.LinkSpec;
import org.licas.util.*;
import org.licas.util.exception.LicasException;
import org.licas_xml.abs.Element;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.CollectionHandler;

import java.util.*;


/**
 * This is an implementation of a linking service that also considers memory restrictions.
 * This is a much more complex operation, where the maximum allowed number of entries 
 * at each level of the linking structure can be specified. Entries might then need
 * to be removed or replaced to add a new one.
 * @author Kieran Greer
 */
public class Link_M extends Link_NM
{
    /** The logger */
    private static final Logger logger;
    
    /** 
     * The threshold values that store the currently selected minimum source.
     * Each path in the linking structure stores a linkSpec structure at the end, which
     * then stores the references to the linked sources at the different levels. This
     * field relates to the minimum source at the end of a path, which might then be
     * removed if the linking structure becomes full.
     */
    protected Thresholds minThresholds;
    
    /** Total number of link sources borrowed */
    protected int linkBorrowedCount;
    
    /** Total number of monitor sources borrowed */
    protected int monitorBorrowedCount;
    
    /** Total number of possible sources borrowed */
    protected int possibleBorrowedCount;
    
    /**
     * Link source slots lent to another component. 
     * Keys are the component ids and values are the number of slots.
     */
    protected HashMap<String, Integer> linkLent;
    
    /**
     * Link source slots borrowed from another component. 
     * Keys are the component ids and values are the number of slots.
     */
    protected HashMap<String, Integer> linkBorrowed;
    
    /**
     * Monitor source slots lent to another component. 
     * Keys are the component ids and values are the number of slots.
     */
    protected HashMap<String, Integer> monitorLent;
    
    /**
     * Monitor source slots borrowed from another component. 
     * Keys are the component ids and values are the number of slots.
     */
    protected HashMap<String, Integer> monitorBorrowed;
    /**
     * Possible source slots lent to another component. 
     * Keys are the component ids and values are the number of slots.
     */
    protected HashMap<String, Integer> possibleLent;
    
    /**
     * Possible source slots borrowed from another component. 
     * Keys are the component ids and values are the number of slots.
     */
    protected HashMap<String, Integer> possibleBorrowed;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(Link_M.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of Link_M. Need to call {@code setServiceDetails} later.
     * @throws Exception any error.
     */
    public Link_M() throws Exception
    {
        super();
        resetValues();
    }

    /**
     * Creates a new instance of Link_M.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public Link_M(Service service, PasswordHandler pHandler) throws Exception
    {
        super(service, pHandler);
        resetValues();
    }

    /**
     * Creates a new instance of Link_M.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @param thisLinkSpec the config to use for initialising the thresholds structures.
     * @throws java.lang.Exception any error.
     */
    public Link_M(Service service, PasswordHandler pHandler, LinkSpec thisLinkSpec) throws Exception
    {
        super(service, pHandler, thisLinkSpec);
        resetValues();
    }
    
    /** Reset the values */
    public void resetValues()
    {
        super.resetValues();

        linkBorrowedCount = 0;
        monitorBorrowedCount = 0;
        possibleBorrowedCount = 0;
        linkLent = new HashMap<>();
        linkBorrowed = new HashMap<>();
        monitorLent = new HashMap<>();
        monitorBorrowed = new HashMap<>();
        possibleLent = new HashMap<>();
        possibleBorrowed = new HashMap<>();
    }

    /**
     * Update the linkSpec structure. Add or update the new sources references
     * and also add these to the added sources list.
     * @param theThresholds the linkSpec structure.
     * @param conceptPath a preferred path to find in the tree.
     * @param newSources list of sources to add or update.
     * @param timeStamp time stamp for update.
     * @param sourcesAdded a list of all added sources over all of the update calls.
     * @param negative a list of negative source results. Can be empty.
     * @throws java.lang.Exception any error.
     */
    protected void updateThresholds(Thresholds theThresholds, ArrayList<String> conceptPath,
                                    ArrayList newSources, long timeStamp,
                                    ArrayList sourcesAdded, ArrayList negative) throws Exception
    {
        int i;
        boolean updateIndividual;               //true if update individual concepts
        boolean addNegative;                    //true if add negative concepts
        
        updateIndividual = LinkConfig.updateIndividual(linkSpec.linkMethod);
        addNegative = LinkConfig.addNegative(linkSpec.linkMethod);
        
        //move sources not used in this answer down if required
        moveSourcesDown(conceptPath, newSources, theThresholds);

        for (i = 0; i < newSources.size(); i++)
        {
            //add new source swapping existing sources if required
            if (addNewSource(conceptPath, newSources.get(i), theThresholds, timeStamp, updateIndividual)) {
                sourcesAdded.add(newSources.get(i));

                if (addNegative && ((negative != null) && !negative.isEmpty())) {
                    theThresholds.storeNegatives(newSources.get(i), negative);
                }
            }
        }

        if (logger.getDebug())
            LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "updateThresholds",
                "parent id: " + getUUID() +
                ", added sources: " + String.valueOf(sourcesAdded));
    }
    
    /**
     * Add or update the new source swapping other sources if required.
     * @param conceptPath a preferred path to find in the tree.
     * @param source the representation of the source used.
     * @param thisThresholds the parent thresholds structure.
     * @param timeStamp the current time for adding sources.
     * @param updateIndividual true if update individual links only.
     * @return true if new source is added.
     * @throws java.lang.Exception any error.
     */
    protected boolean addNewSource(ArrayList<String> conceptPath, Object source, Thresholds thisThresholds,
                                   long timeStamp, boolean updateIndividual) throws Exception
    {
        boolean sourceAdded;                    //true if source is added
        int nextMemory;                         //next memory
        int thresholdLevel;                     //the threshold level
        float newSourceValue;                   //new source value
        ThresholdSource reserveSource;          //the reserve source
        ThresholdSource minimumLSource;         //minimum link source
        ThresholdSource minimumMSource;         //minimum monitor source
        ThresholdSource minimumPSource;         //minimum possible source
        
        sourceAdded = false;
        newSourceValue = Float.MIN_VALUE;
        thisThresholds.maxNegative = maxNegative;
        thresholdLevel = thisThresholds.getSourceLevel(source);

        if (logger.getDebug())
            LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "addNewSource",
                "parent id: " + getUUID() +
                ", source: " + String.valueOf(source) +
                ", threshold level: " + String.valueOf(thresholdLevel));
        
        if (LinkConfig.includeReserve(linkSpec.linkMethod) && !updateIndividual) {
            //first add or increment new source
            if (thresholdLevel == Const.NOSOURCE) {
                //add source as reserve
                reserveSource = thisThresholds.getReserve();

                if ((reserveSource == null) || reserveSource.notAssigned()) {
                    reserveSource = thisThresholds.createNewThresholdSource(source);
                    reserveSource.timeStamp = timeStamp;
                    thisThresholds.setReserve(reserveSource);
                    newSourceValue = reserveSource.value;
                }
                else if (ObjectHandler.equals(reserveSource.source, source)) {
                    thisThresholds.incrementReserve(timeStamp);
                    newSourceValue = reserveSource.value;
                }
                else if (reserveSource.value <= linkSpec.linkIncrement) {
                    removeSource(thisThresholds, Const.NOSOURCE, reserveSource.source);
                    
                    reserveSource = thisThresholds.createNewThresholdSource(source);
                    reserveSource.timeStamp = timeStamp;
                    thisThresholds.setReserve(reserveSource);
                    newSourceValue = reserveSource.value;
                }
                else {
                    newSourceValue = Float.MIN_VALUE;
                }
            }
            else {
                newSourceValue = thisThresholds.incrementSource(thresholdLevel, source, timeStamp);
            }
        }
        else {
            //first get new source value
            if ((thresholdLevel == Const.NOSOURCE) && !updateIndividual) {
                newSourceValue = linkSpec.linkIncrement;
            }
            else if ((thresholdLevel == Const.POSSIBLESOURCE) && !updateIndividual) {
                newSourceValue = thisThresholds.incrementSource(thresholdLevel, source, timeStamp);
            }
            else if ((thresholdLevel != Const.NOSOURCE) && (thresholdLevel != Const.POSSIBLESOURCE)) {
                newSourceValue = thisThresholds.incrementSource(thresholdLevel, source, timeStamp);
            }
        }
        
        //check if need to swap with higher level
        if ((thresholdLevel == Const.NOSOURCE) && (newSourceValue > Float.MIN_VALUE)) {
           //if still places in possible sources then move up anyway, otherwise check if need to swap
           if (possibleCount < linkSpec.possibleNumber) {
               moveSourceUp(thisThresholds, Const.NOSOURCE, source);
               sourceAdded = true;
           }
           else {
               nextMemory = 0;

               //first try to borrow memory
               if (LinkConfig.canBorrow(linkSpec.linkMethod)) {
                   nextMemory = getMemory(Const.POSSIBLESOURCE, 1, conceptPath);

                   if (nextMemory == 0) {
                       nextMemory = askForMemory(Const.POSSIBLESOURCE, 1);
                   }
               }
               
               if (nextMemory == 0) {
                   minimumPSource = thisThresholds.getMinSource(Const.POSSIBLESOURCE);

                   if ((minimumPSource != null) && (minimumPSource.value <= newSourceValue)) {
                       if (LinkConfig.includeReserve(thisThresholds.getLinkMethod())) {
                            thisThresholds.swapSources(Const.POSSIBLESOURCE, minimumPSource.source, source);
                       }
                       else {
                           removeSource(thisThresholds, Const.POSSIBLESOURCE, minimumPSource.source);
                           moveSourceUp(thisThresholds, Const.NOSOURCE, source);
                       }

                       thresholdLevel = Const.POSSIBLESOURCE;
                       sourceAdded = true;
                   }
                   else if (minimumPSource == null) {
                       if (LinkConfig.includeReserve(thisThresholds.getLinkMethod())) {
                           minimumPSource = getMinimumSource(Const.POSSIBLESOURCE, conceptPath, null);
                       }
                       else {
                           minimumPSource = getMinimumSource(Const.POSSIBLESOURCE, conceptPath, Const.NULL);
                       }

                       //make less than as may be unrelated source
                       if ((minimumPSource != null) && (minimumPSource.value < newSourceValue)) {
                           removeSource(minThresholds, Const.POSSIBLESOURCE, minimumPSource.source);
                           moveSourceUp(thisThresholds, Const.NOSOURCE, source);
                           thresholdLevel = Const.POSSIBLESOURCE;
                           sourceAdded = true;
                       }
                   }
               }
               else {
                   moveSourceUp(thisThresholds, Const.NOSOURCE, source);                  
                   thresholdLevel = Const.POSSIBLESOURCE;
                   sourceAdded = true;
               }
           }       
        }
        
        //if threshold greater than monitor threshold then try to move up
        if ((thresholdLevel == Const.POSSIBLESOURCE) &&
            (newSourceValue > linkSpec.monitorThreshold)) {
            if (monitorCount < linkSpec.monitorNumber) {
                moveSourceUp(thisThresholds, thresholdLevel, source);               
                thresholdLevel = Const.MONITORSOURCE;
                sourceAdded = true;
            }
            else {
                nextMemory = 0;

                if (LinkConfig.canBorrow(linkSpec.linkMethod)) {
                    nextMemory = getMemory(Const.MONITORSOURCE, 1, conceptPath);

                    if (nextMemory == 0) {
                        nextMemory = askForMemory(Const.MONITORSOURCE, 1);
                    }
                }

                if (nextMemory > 0) {
                    moveSourceUp(thisThresholds, Const.POSSIBLESOURCE, source);                   
                    thresholdLevel = Const.MONITORSOURCE;
                    sourceAdded = true;
                }
                else {
                    minimumMSource = thisThresholds.getMinSource(Const.MONITORSOURCE);

                    if (minimumMSource != null) {
                        if (minimumMSource.value <= newSourceValue) {
                            thisThresholds.swapSources(Const.MONITORSOURCE, minimumMSource.source, source);
                            thresholdLevel = Const.MONITORSOURCE;
                            sourceAdded = true;
                        }
                    }   
                }
            }
        }
        
        //if threshold greater than link threshold then try to move up
        if ((thresholdLevel == Const.MONITORSOURCE) &&
            (newSourceValue > linkSpec.linkThreshold)) {
            if (linkCount < linkSpec.linkNumber) {
                moveSourceUp(thisThresholds, Const.MONITORSOURCE, source);
                sourceAdded = true;
            }
            else {
                nextMemory = 0;
               
                //first try to borrow memory
                if (LinkConfig.canBorrow(linkSpec.linkMethod)) {
                    nextMemory = getMemory(Const.LINKSOURCE, 1, conceptPath);
                    
                    if (nextMemory == 0) {
                        nextMemory = askForMemory(Const.LINKSOURCE, 1);
                    }
                }

                if (nextMemory > 0) {
                    moveSourceUp(thisThresholds, Const.MONITORSOURCE, source);
                    sourceAdded = true;
                }
                else {
                    minimumLSource = thisThresholds.getMinSource(Const.LINKSOURCE);

                    if (minimumLSource != null) {
                        if (minimumLSource.value <= newSourceValue) {
                            thisThresholds.swapSources(Const.LINKSOURCE, minimumLSource.source, source);
                            sourceAdded = true;
                        }
                    }    
                }
            }
        }
        
        return sourceAdded;
    }
    
    /**
     * Move any sources not used in the answer down a level if required.
     * @param conceptPath a preferred path to find in the tree.
     * @param sources the representations of the sources used.
     * @param thisThresholds the linkSpec structure.
     * @throws java.lang.Exception any error.
     */
    protected void moveSourcesDown(ArrayList<String> conceptPath, ArrayList<Object> sources,
                                   Thresholds thisThresholds) throws Exception
    {
        int i;
        int nextMSourceCount;                   //next monitor source count
        int nextPSourceCount;                   //next possible source count
        int difference;                         //difference between counts
        int nextMemory;                         //next memory
        ArrayList<Object> sourcesToMove;        //sources to move from one level to another
        ThresholdSource minimumMSource;         //minimum monitor source
        ThresholdSource minimumPSource;         //minimum possible source
        ThresholdSource reserveSource;          //reserve source
        Thresholds minThresholds2;              //minimum stored linkSpec

        //first decrement reserve if not the source
        if (LinkConfig.includeReserve(linkSpec.linkMethod)) {
            thisThresholds.decrementReserve(sources);
        }
        
        //get link sources to move down
        thisThresholds.resetUpdatedSources();
        sourcesToMove = thisThresholds.sourcesToMoveDown(Const.LINKSOURCE, sources);
        
        //if monitor full then move these down first
        nextMSourceCount = monitorCount + sourcesToMove.size();
        if (nextMSourceCount > linkSpec.monitorNumber) {
            difference = nextMSourceCount - linkSpec.monitorNumber;            
            for (i = 0; i < difference; i++)
            {
                minimumMSource = getMinimumSource(Const.MONITORSOURCE, conceptPath, Const.NULL);
                if (minimumMSource != null) {
                    //make copy of min linkSpec
                    minThresholds2 = minThresholds;
                    if (possibleCount >= linkSpec.possibleNumber) {
                        nextMemory = 0;

                        //first try to borrow memory
                        if (LinkConfig.canBorrow(linkSpec.linkMethod)) {
                            nextMemory = getMemory(Const.POSSIBLESOURCE, 1, conceptPath);

                            if (nextMemory == 0) {
                                nextMemory = askForMemory(Const.POSSIBLESOURCE, 1);
                            }
                        }

                        if (nextMemory == 0) {
                            minimumPSource = getMinimumSource(Const.POSSIBLESOURCE, conceptPath, Const.NULL);
                            removeSource(minThresholds, Const.POSSIBLESOURCE, minimumPSource.source);
                        }
                    }

                    moveSourceDown(minThresholds2, Const.MONITORSOURCE, minimumMSource.source);
                }
                else if (LinkConfig.canBorrow(linkSpec.linkMethod)) {
                    nextMemory = getMemory(Const.MONITORSOURCE, 1, conceptPath);

                    if (nextMemory == 0) {
                        nextMemory = askForMemory(Const.MONITORSOURCE, 1);

                        if (nextMemory == 0) {
                            throw new LicasException("Link_M.moveSourcesDown: No monitor memory to retrieve: " + getUUID());
                        }
                    }
                }
            }
        }
        
        //move link sources down
        for (i = 0; i < sourcesToMove.size(); i++)
        {
            moveSourceDown(thisThresholds, Const.LINKSOURCE, sourcesToMove.get(i));
        }

        //get monitor sources to move down
        sourcesToMove = thisThresholds.sourcesToMoveDown(Const.MONITORSOURCE, sources);
        
        //if possible full then remove these first
        nextPSourceCount = possibleCount + sourcesToMove.size();
        if (nextPSourceCount > linkSpec.possibleNumber) {
            difference = nextPSourceCount - linkSpec.possibleNumber;

            for (i=0; i < difference; i++)
            {
                minimumPSource = getMinimumSource(Const.POSSIBLESOURCE, conceptPath, Const.NULL);

                if (minimumPSource != null) {
                    removeSource(minThresholds, Const.POSSIBLESOURCE, minimumPSource.source);
                }
                else if (LinkConfig.canBorrow(linkSpec.linkMethod)) {
                    nextMemory = getMemory(Const.POSSIBLESOURCE, 1, conceptPath);

                    if (nextMemory == 0) {
                        nextMemory = askForMemory(Const.POSSIBLESOURCE, 1);
                       
                        if (nextMemory == 0) {
                          throw new LicasException("Link_M.moveSourcesDown: No possible memory to retrieve: " + getUUID());
                        }
                    }
                }
            }
        }
        
        //move monitor sources down
        for (i=0; i < sourcesToMove.size(); i++)
        {
            moveSourceDown(thisThresholds, Const.MONITORSOURCE, sourcesToMove.get(i));
        }
        
        //get possible sources to move down
        sourcesToMove = thisThresholds.sourcesToMoveDown(Const.POSSIBLESOURCE, sources);
        
        //remove possible sources
        for (i=0; i < sourcesToMove.size(); i++)
        {
            moveSourceDown(thisThresholds, Const.POSSIBLESOURCE, sourcesToMove.get(i));
        }
        
        //check if reserve source should now be moved up
        if (LinkConfig.includeReserve(linkSpec.linkMethod)) {
            minimumPSource = thisThresholds.getMinSource(Const.POSSIBLESOURCE);

            if (minimumPSource != null) {
                reserveSource = thisThresholds.getReserve();

                if ((reserveSource != null) && (reserveSource.value > minimumPSource.value)) {
                    thisThresholds.swapSources(Const.POSSIBLESOURCE, minimumPSource.source, reserveSource.source);
                }
            }
        }
    }
    
    /**
     * Get the minimum source details in the specified threshold structure.
     * Also store the linkSpec structure reference.
     * @param thresholdType The threshold structure to query: link, monitor or possible.
     * @param conceptPath a preferred path to find in the tree.
     * @param sourceType the type of source currently being added.
     * @return a full path to the minimum source.
     * @throws java.lang.Exception any error.
     */

    protected ThresholdSource getMinimumSource(int thresholdType, ArrayList<String> conceptPath, String sourceType) throws Exception
    {
        int i, j;
        boolean minIsPath;                      //true if min source from exact path to links
        boolean nextIsPath;                     //true if next source from exact path to links
        String nextKey;                         //next key
        ArrayList<String> keys;                 //keys
        ArrayList<String> keyValues;            //actual key values
        TreeNode nextTreeNode;                  //next tree node
        Thresholds nextThresholds;              //next set of linkSpec
        ThresholdSource nextTSource;            //next linkSpec source
        ThresholdSource minTSource;             //minimum linkSpec source
        Object nextObj;                         //next object

        try {
            minTSource = null;
            minIsPath = false;
            keyValues = new ArrayList<>();

            keys = linkTree.getChildNodeKeys();
            for (i = 0; i < keys.size(); i++)
            {
                nextKey = keys.get(i);
                keyValues.add(nextKey);

                nextTreeNode = linkTree.getChildNode(nextKey);
                nextObj = nextTreeNode.getValue();
                
                if (nextObj instanceof Thresholds) {
                    nextThresholds = (Thresholds)nextObj;
                    nextTSource = nextThresholds.getMinSource(thresholdType);

                    nextIsPath = true;
                    if (conceptPath != null) {
                        for (j = 0; nextIsPath && (j < keyValues.size()) && (j < conceptPath.size()); j++)
                        {
                            nextIsPath = keyValues.get(j).equals(conceptPath.get(j));
                        }
                    }

                    if (nextTSource != null) {
                        if (minTSource == null) {
                            minTSource = nextTSource;
                            minThresholds = nextThresholds;
                            minIsPath = nextIsPath;
                        }
                        else if (nextTSource.value < minTSource.value) {
                            minTSource = nextTSource;
                            minThresholds = nextThresholds;
                            minIsPath = nextIsPath;
                        }
                        else if (nextTSource.value == minTSource.value) {
                            //maybe should select if same source type even if value greater?
                            if (nextIsPath && minIsPath) {
                                if (nextTSource.timeStamp < minTSource.timeStamp) {
                                    minTSource = nextTSource;
                                    minThresholds = nextThresholds;
                                }
                            }
                            else if (nextIsPath) {
                                minTSource = nextTSource;
                                minThresholds = nextThresholds;
                                minIsPath = true;
                            }
                            else if (!minIsPath && (nextTSource.timeStamp < minTSource.timeStamp)) {
                                minTSource = nextTSource;
                                minThresholds = nextThresholds;
                                minIsPath = false;
                            }
                        }
                    }
                }

                minTSource = getMinimumSource(thresholdType, keyValues,
                        conceptPath, nextTreeNode, minTSource);

                keyValues.remove(keyValues.size()-1);
            }

            return minTSource;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "getMinimumSource", null, ex);
        }
    }
    
    /**
     * Get the minimum source details.
     * @param thresholdType The threshold structure to query: link, monitor or possible.
     * @param keyValues list of actual related sources key values.
     * @param conceptPath a preferred path to find in the tree.
     * @param treeNode next related sources structure.
     * @param minTSource the current minimum threshold source.
     * @return the minimum retrieved threshold source structure.
     * @throws java.lang.Exception any error.
     */
    protected ThresholdSource getMinimumSource(int thresholdType, ArrayList<String> keyValues,
                                               ArrayList<String> conceptPath, TreeNode treeNode,
                                               ThresholdSource minTSource) throws Exception
    {
        int i, j;
        boolean minIsPath;                      //true if min source from exact path to links
        boolean nextIsPath;                     //true if next source from exact path to links
        String nextKey;                         //next key
        ArrayList<String> keys;                 //keys
        TreeNode nextTreeNode;                  //related sources        
        Thresholds nextThresholds;              //next set of linkSpec
        ThresholdSource nextTSource;            //next linkSpec source
        Object nextObj;                         //next object

        try
        {
            minIsPath = false;

            keys = treeNode.getChildNodeKeys();
            for (i = 0; i < keys.size(); i++)
            {
                nextKey = keys.get(i);
                keyValues.add(nextKey);

                nextTreeNode = treeNode.getChildNode(nextKey);
                nextObj = nextTreeNode.getValue();
                
                if (nextObj instanceof Thresholds) {
                    nextThresholds = (Thresholds)nextObj;
                    nextTSource = nextThresholds.getMinSource(thresholdType);

                    nextIsPath = true;
                    if (conceptPath != null) {
                        for (j = 0; nextIsPath && (j < keyValues.size()) && (j < conceptPath.size()); j++)
                        {
                            nextIsPath = ObjectHandler.equals(keyValues.get(j), conceptPath.get(j));
                        }
                    }

                    if (nextTSource != null) {
                        if (minTSource == null) {
                            minTSource = nextTSource;
                            minThresholds = nextThresholds;
                            minIsPath = nextIsPath;
                        }
                        else if (nextTSource.value < minTSource.value) {
                            minTSource = nextTSource;
                            minThresholds = nextThresholds;
                            minIsPath = nextIsPath;
                        }
                        else if (nextTSource.value == minTSource.value) {
                            //maybe should select if same source type even if value greater?
                            if (nextIsPath && minIsPath) {
                                if (nextTSource.timeStamp < minTSource.timeStamp) {
                                    minTSource = nextTSource;
                                    minThresholds = nextThresholds;
                                }
                            }
                            else if (nextIsPath) {
                                minTSource = nextTSource;
                                minThresholds = nextThresholds;
                                minIsPath = true;
                            }
                            else if (!minIsPath && (nextTSource.timeStamp < minTSource.timeStamp)) {
                                minTSource = nextTSource;
                                minThresholds = nextThresholds;
                                minIsPath = false;
                            }
                        }
                    }
                }
                else {
                    minTSource = getMinimumSource(thresholdType, keyValues, 
                            conceptPath, nextTreeNode, minTSource);
                }

                keyValues.remove(keyValues.size()-1);
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "getMinimumSource", null, ex);
        }
        
        return minTSource;
    }
    
    /**
     * Move the specified source in the linkSpec structure down to the next level.
     * @param theThresholds the linkSpec structure.
     * @param thresholdType the threshold level moving down from.
     * @param source the source representation.
     * @throws java.lang.Exception any error.
     */
    protected void moveSourceDown(Thresholds theThresholds, int thresholdType, Object source) throws Exception
    {
        synchronized(syncOn) {
            theThresholds.moveSourceDown(thresholdType, source);

            if (thresholdType == Const.LINKSOURCE) {
                monitorCount++;
                linkCount--;
                if (linkCount < 0) linkCount = 0;
            } else if (thresholdType == Const.MONITORSOURCE) {
                possibleCount++;
                monitorCount--;
                if (monitorCount < 0) monitorCount = 0;
            } else if (thresholdType == Const.POSSIBLESOURCE) {
                possibleCount--;
                if (possibleCount < 0) possibleCount = 0;
            }
        }
    }

    /**
     * Move the specified source in the linkSpec structure up to the next level.
     * @param theThresholds the linkSpec structure.
     * @param thresholdType the threshold level moving up from.
     * @param source the source representation.
     * @throws java.lang.Exception any error.
     */
    protected void moveSourceUp(Thresholds theThresholds, int thresholdType, Object source)
            throws Exception
    {
        synchronized(syncOn) {
            theThresholds.moveSourceUp(thresholdType, source, timeStamp);

            if (thresholdType == Const.MONITORSOURCE) {
                linkCount++;
                monitorCount--;
                if (monitorCount < 0) monitorCount = 0;
            } else {
                if (thresholdType == Const.POSSIBLESOURCE) {
                    monitorCount++;
                    possibleCount--;
                    if (possibleCount < 0) possibleCount = 0;
                } else {
                    if (thresholdType == Const.NOSOURCE) {
                        possibleCount++;
                    }
                }
            }
        }
    }

    /**
     * Remove the specified source from the linkSpec structure.
     * @param theThresholds the thresholds structure.
     * @param thresholdType the threshold level.
     * @param source the source representation.
     * @throws java.lang.Exception any error.
     */
    public void removeSource(Thresholds theThresholds, int thresholdType, Object source)
            throws Exception
    {
        synchronized(syncOn)
        {
            theThresholds.removeSource(thresholdType, source);

            if (thresholdType == Const.LINKSOURCE) {
                linkCount--;
                if (linkCount < 0) linkCount = 0;
            }
            else {
                if (thresholdType == Const.MONITORSOURCE) {
                    monitorCount--;
                    if (monitorCount < 0) monitorCount = 0;
                }
                else {
                    if (thresholdType == Const.POSSIBLESOURCE) {
                        possibleCount--;
                        if (possibleCount < 0) possibleCount = 0;
                    }
                }
            }
        }
    }
    
    /**
     * Update the appropriate memory structure to record the new allowed amount of memory.
     * @param thresholdType the threshold structure type.
     * @param memory the amount of change. Can be positive or negative.
     * @throws java.lang.Exception any error.
     */
    public void changeCurrentMemory(int thresholdType, int memory) throws Exception
    {
        synchronized(syncOn) {
            if (thresholdType == Const.LINKSOURCE) {
                linkSpec.linkNumber += memory;
            } else {
                if (thresholdType == Const.MONITORSOURCE) {
                    linkSpec.monitorNumber += memory;
                } else {
                    if (thresholdType == Const.POSSIBLESOURCE) {
                        linkSpec.possibleNumber += memory;
                    }
                }
            }
        }
    }
    
    /**
     * The component must remove the specified number of slots from its relative structure.
     * @param componentID the id for the component retrieving its memory.
     * @param thresholdType the threshold structure.
     * @param slotNumber the number of slots to release.
     * @param conceptPath a preferred path to find in the tree.
     * @throws java.lang.Exception any error.
     */
    public void releaseMemory(String componentID, int thresholdType, int slotNumber,
                              ArrayList<String> conceptPath) throws Exception
    {
        int i;
        int allowedMemory;                      //memory allowed to be retrieved
        int difference;                         //difference between counts
        int difference2;                        //difference between counts
        ThresholdSource minimumLSource;         //minimum link source
        ThresholdSource minimumMSource;         //minimum monitor source
        ThresholdSource minimumPSource;         //minimum possible source
        Thresholds minThresholds2;              //minimum stored linkSpec
        
        synchronized(syncOn) {
            if (thresholdType == Const.LINKSOURCE) {
                allowedMemory = linkBorrowed.get(componentID);            
                if (slotNumber <= allowedMemory) {
                    //determine if link sources need to be moved down
                    difference = (slotNumber + linkCount - linkSpec.linkNumber);
                    if (difference > 0) {
                        //if monitor full then move these down first
                        difference2 = difference + monitorCount - linkSpec.monitorNumber;                    
                        if (difference2 > 0) {
                            for (i = 0; i < difference2; i++)
                            {
                                minimumMSource = getMinimumSource(Const.MONITORSOURCE, conceptPath, Const.NULL);
                                if (minimumMSource == null) {
                                    minimumLSource = getMinimumSource(Const.LINKSOURCE, conceptPath, Const.NULL);
                                    removeSource(minThresholds, Const.LINKSOURCE, minimumLSource.source);
                                    difference--;
                                }
                                else {
                                    //make copy of min linkSpec
                                    minThresholds2 = minThresholds;
                                    if (possibleCount >= linkSpec.possibleNumber) {
                                        minimumPSource = getMinimumSource(Const.POSSIBLESOURCE, conceptPath, Const.NULL);
                                        if (minimumPSource == null) {
                                            removeSource(minThresholds2, Const.MONITORSOURCE, minimumMSource.source);
                                        }
                                        else {
                                            removeSource(minThresholds, Const.POSSIBLESOURCE, minimumPSource.source);
                                            moveSourceDown(minThresholds2, Const.MONITORSOURCE, minimumMSource.source);
                                        }
                                    }
                                    else {
                                        moveSourceDown(minThresholds2, Const.MONITORSOURCE, minimumMSource.source);
                                    }
                                }
                            }
                        }

                        //move link sources down
                        for (i = 0; i < difference; i++)
                        {
                            minimumLSource = getMinimumSource(Const.LINKSOURCE, conceptPath, Const.NULL);
                            moveSourceDown(minThresholds, Const.LINKSOURCE, minimumLSource.source);
                        }
                    }
                }
                else {
                    throw new LicasException("Link_M.releaseMemory: Error: retrieved too much link memory from component: " + getUUID());
                }
            }
            else if (thresholdType == Const.MONITORSOURCE) {
                allowedMemory = monitorBorrowed.get(componentID);

                if (slotNumber <= allowedMemory) {
                    //determine if monitor sources need to be moved down
                    difference = slotNumber + monitorCount - linkSpec.monitorNumber;

                    if (difference > 0) {
                        //if possible full then remove these first
                        difference2 = difference + possibleCount - linkSpec.possibleNumber;

                        if (difference2 > 0) {
                            for (i = 0; i < difference2; i++)
                            {
                                minimumPSource = getMinimumSource(Const.POSSIBLESOURCE, conceptPath, Const.NULL);

                                if (minimumPSource == null) {
                                    minimumMSource = getMinimumSource(Const.MONITORSOURCE, conceptPath, Const.NULL);
                                    removeSource(minThresholds, Const.MONITORSOURCE, minimumMSource.source);
                                    difference--;
                                }
                                else {
                                    removeSource(minThresholds, Const.POSSIBLESOURCE, minimumPSource.source);
                                }                           
                            }
                        }

                        //move monitor sources down
                        for (i = 0; i < difference; i++)
                        {
                            minimumMSource = getMinimumSource(Const.MONITORSOURCE, conceptPath, Const.NULL);
                            moveSourceDown(minThresholds, Const.MONITORSOURCE, minimumMSource.source);
                        }
                    }
                }
                else {
                    throw new LicasException("Link_M.releaseMemory: Error: retrieved too much monitor memory from component: " + getUUID());
                }
            }
            else if (thresholdType == Const.POSSIBLESOURCE)
            {
                allowedMemory = possibleBorrowed.get(componentID);            

                if (slotNumber <= allowedMemory) {
                    //determine if possible sources need to be removed
                    difference = slotNumber + possibleCount - linkSpec.possibleNumber;

                    if (difference > 0) {
                        //remove possible sources
                        for (i=0; i < difference; i++)
                        {
                            minimumPSource = getMinimumSource(Const.POSSIBLESOURCE, conceptPath, Const.NULL);

                            if (minimumPSource != null) {
                                removeSource(minThresholds, Const.POSSIBLESOURCE, minimumPSource.source);
                            }
                            else {
                                throw new LicasException ("Link_M.releaseMemory: " + getUUID() +
                                    ", possibleCount: " + possibleCount +
                                    ", possibleNumber: " + linkSpec.possibleNumber +
                                    ", slotNumber: " + slotNumber +
                                    ", difference: " + difference);
                            }
                        }
                    }
                }
                else {
                    throw new LicasException("Link_M.releaseMemory: Error: retrieved too much possible memory from component: " + getUUID());
                }
            }

            changeBorrowedMemory(componentID, thresholdType, -slotNumber);
            checkCurrentMemory(thresholdType);
        }
    }
    
    /**
     * Ask the components stored here for any available memory they are not using.
     * @param thresholdType the threshold structure type.
     * @param slotNumber number of slots to release.
     * @return the total amount of memory that can be borrowed.
     * @throws java.lang.Exception any error.
     */
    public int askForMemory(int thresholdType, int slotNumber) throws Exception
    {
        int i;
        int nextMemory;                         //next amount of available memory
        int maxMemory;                          //maximum amount of available memory
        int totalMemory;                        //total amount of available memory
        String sibling;                         //best sibling
        String nextKey;                         //next key
        ArrayList<String> allKeys;              //all keys
        ArrayList<Object> params;               //method info parameters
        Element handle;                         //path handle
        MethodInfo methodInfo;                  //method info
        Service componentParent;                //parent of the component
        CallObject call;                        //object call

        if (service != null) {
            totalMemory = 0;
            call = new CallObject();

            //get the parent of this module's service, so can ask siblings for memory
            params = new ArrayList<>();
            params.add(passwordHandler.getAdminKey());
            methodInfo = MethodFactory.createMethodCall(MethodConst.GETPARENT, Service.class.getName(),
                    service, params, passwordHandler);
            componentParent = (Service)call.call(methodInfo);

            methodInfo = MethodFactory.createMethodCall(MethodConst.GETSERVICENAMES, TypeConst.ARRAYLIST,
                    componentParent, new ArrayList<>(), passwordHandler);
            allKeys = CollectionHandler.cloneVector((ArrayList) call.call(methodInfo));

            while ((allKeys.size() > 0) && (slotNumber > 0))
            {
                sibling = null;
                maxMemory = 0;

                for (i = 0; i < allKeys.size(); i++)
                {
                    nextKey = allKeys.get(i);
                    handle = componentParent.getFullPath();
                    handle = Handle.addToHandle(handle, Handle.asHandleElement(nextKey));
                    handle = Handle.addToHandle(handle, Handle.asHandleElement(ServiceConst.LINKER));

                    if (!getUuid(nextKey).equals(getUUID())) {
                        params = new ArrayList<>();
                        params.add(new Integer(thresholdType));

                        methodInfo = MethodFactory.createMethodCall(MethodConst.MEMORYTOLEND, TypeConst.INTEGER,
                                handle, params, passwordHandler);
                        nextMemory = ((Integer) call.call(methodInfo)).intValue();

                        if (nextMemory > maxMemory) {
                            maxMemory = nextMemory;
                            sibling = nextKey;
                        }
                    }
                }

                if (maxMemory > 0) {
                    if (maxMemory > slotNumber) maxMemory = slotNumber;
                    slotNumber -= maxMemory;
                    totalMemory += maxMemory;

                    handle = componentParent.getFullPath();
                    handle = Handle.addToHandle(handle, Handle.asHandleElement(sibling));
                    handle = Handle.addToHandle(handle, Handle.asHandleElement(ServiceConst.LINKER));

                    params = new ArrayList<>();
                    params.add(getUUID());
                    params.add(new Integer(thresholdType));
                    params.add(new Integer(maxMemory));

                    methodInfo = MethodFactory.createMethodCall(MethodConst.CHANGELENTMEMORY, TypeConst.VOID,
                            handle, params, passwordHandler);
                    call.call(methodInfo);

                    changeBorrowedMemory(getUuid(sibling), thresholdType, maxMemory);

                    allKeys.remove(sibling);
                }
                else {
                    break;
                }
            }

            checkCurrentMemory(thresholdType);
            checkAllMemory();

            return totalMemory;
        }
        else {
            throw new LicasException("Link_M.askForMemory: The linker has not been initialised with the parent service reference.");
        }
    }
    
    /**
     * Tell a component to give up some memory as the lender wants it back.
     * @param thresholdType the threshold structure type.
     * @param slotNumber number of slots to release.
     * @param conceptPath a preferred path to find in the tree.
     * @return int the amount of memory retrieved.
     * @throws java.lang.Exception any error.
     */
    public int getMemory(int thresholdType, int slotNumber, ArrayList<String> conceptPath) throws Exception
    {
        int totalMemory;                        //total amount of retrieved memory
        int amountToRelease;                    //amount of memory to release
        String nextKey;                         //next key
        Iterator<String> allKeys;               //all keys
        ArrayList<Object> params;               //method info parameters
        HashMap<String, Integer> lent;          //lent memory
        Element handle;                         //path handle
        MethodInfo methodInfo;                  //method info
        Service componentParent;                //parent of the component
        CallObject call;                        //object call
        
        totalMemory = 0;
        lent = null;
        call = new CallObject();

        if (service != null) {
            params = new ArrayList<>();
            params.add(passwordHandler.getAdminKey());
            methodInfo = MethodFactory.createMethodCall(MethodConst.GETPARENT, Service.class.getName(),
                    service, params, passwordHandler);
            componentParent = (Service)call.call(methodInfo);

            switch (thresholdType) {
                case Const.LINKSOURCE:
                    lent = linkLent;
                    break;
                case Const.MONITORSOURCE:
                    lent = monitorLent;
                    break;
                case Const.POSSIBLESOURCE:
                    lent = possibleLent;
                    break;
            }

            allKeys = lent.keySet().iterator();
            while (allKeys.hasNext() && (totalMemory < slotNumber))
            {
                nextKey = allKeys.next();
                handle = componentParent.getFullPath();
                handle = Handle.addToHandle(handle, Handle.asHandleElement(nextKey));
                handle = Handle.addToHandle(handle, Handle.asHandleElement(ServiceConst.LINKER));

                amountToRelease = lent.get(nextKey);
                if (amountToRelease > 0) {
                    if (amountToRelease > slotNumber) amountToRelease = slotNumber;
                    totalMemory += amountToRelease;

                    params = new ArrayList<>();
                    params.add(getUUID());
                    params.add(new Integer(thresholdType));
                    params.add(new Integer(amountToRelease));
                    params.add(conceptPath);

                    methodInfo = MethodFactory.createMethodCall(MethodConst.RELEASEMEMORY, TypeConst.VOID,
                            handle, params, passwordHandler);
                    call.call(methodInfo);

                    changeLentMemory(nextKey, thresholdType, -amountToRelease);
                }
                else {
                    throw new LicasException("Link_M.getMemory error: lent memory is 0");
                }
            }

            checkAllMemory();

            return totalMemory;
        }
        else {
            throw new LicasException("Link_M.getMemory: The linker has not been initialised with the parent service reference.");
        }
    }
    
    /**
     * Return the amount of memory that this component can lend.
     * @param thresholdType the threshold structure type.
     * @return the amount of memory that can be lent.
     * @throws java.lang.Exception any error.
     */
    public int memoryToLend(int thresholdType) throws Exception
    {
        int theCount;                           //current count
        int currentNumber;                      //existing available slot number
        int slotsAvailable;                     //number of available slots
        int totalBorrowed;                      //total amount of memory borrowed
        
        totalBorrowed = totalBorrowedMemory(thresholdType);
        currentNumber = getCurrentMemory(thresholdType);
        theCount = getCurrentCount(thresholdType);
        slotsAvailable = currentNumber - theCount - totalBorrowed;

        if (theCount > currentNumber) {
            throw new LicasException("Link_M.lendMemory: " + getUUID() +
                ", threshold: " + thresholdType +
                ", memory: " + currentNumber +
                ", count: " + theCount);
        }
        
        if (slotsAvailable < 0) slotsAvailable = 0;
        
        return slotsAvailable;      
    }
    
    /**
     * Update the appropriate memory structure to record the new lent amount of memory.
     * @param componentID the id of the component lending/retrieving its memory.
     * @param thresholdType the threshold structure type.
     * @param memory the amount of change. Can be positive or negative.
     * @throws java.lang.Exception any error.
     */
    public void changeLentMemory(String componentID, int thresholdType, int memory) throws Exception
    {
        int changeMemory;                                   //memory amount for change
        int currentMemory = 0;                              //existing memory                                 
        HashMap<String, Integer> lentMemory = null;         //lent memory

        switch (thresholdType) {
            case Const.LINKSOURCE:
                lentMemory = linkLent;
                break;
            case Const.MONITORSOURCE:
                lentMemory = monitorLent;
                break;
            case Const.POSSIBLESOURCE:
                lentMemory = possibleLent;
                break;
        }
        
        if (lentMemory.containsKey(componentID)) {
            currentMemory = lentMemory.get(componentID);
        }
        else if (memory < 0) {
            throw new LicasException("Link_M.changeLentMemory: " + getUUID() +
                ", threshold: " + thresholdType +
                ", change: " + memory);
        }
        
        if ((currentMemory + memory) < 0) {
            throw new LicasException("Link_M.changeLentMemory: " + getUUID() +
                ", threshold: " + thresholdType +
                ", memory: " + currentMemory +
                ", change: " + memory);
        }
        
        changeMemory = currentMemory + memory;
        lentMemory.put(componentID, new Integer(changeMemory));
        
        if (lentMemory.get(componentID) == 0) {
            lentMemory.remove(componentID);
        }

        changeCurrentMemory(thresholdType, -memory);
        checkCurrentMemory(thresholdType);
    }
    
    /**
     * Update the appropriate memory structure to record the new borrowed amount of memory.
     * @param componentID the id of the component lending/retrieving its memory.
     * @param thresholdType the threshold structure type.
     * @param memory the amount of change. Can be positive or negative.
     * @throws java.lang.Exception any error.
     */
    public void changeBorrowedMemory(String componentID, int thresholdType, int memory) throws Exception
    {
        HashMap<String, Integer> borrowedMemory = null;     //borrowed memory

        switch (thresholdType) {
            case Const.LINKSOURCE:
                borrowedMemory = linkBorrowed;
                linkBorrowedCount += memory;
                break;
            case Const.MONITORSOURCE:
                borrowedMemory = monitorBorrowed;
                monitorBorrowedCount += memory;
                break;
            case Const.POSSIBLESOURCE:
                borrowedMemory = possibleBorrowed;
                possibleBorrowedCount += memory;
                break;
        }
        
        changeCurrentMemory(thresholdType, memory);
        
        if (borrowedMemory.containsKey(componentID)) {
            memory += borrowedMemory.get(componentID);
        }
                    
        borrowedMemory.put(componentID, new Integer(memory));
        
        if (borrowedMemory.get(componentID) == 0) {
            borrowedMemory.remove(componentID);
        }
        
        checkCurrentMemory(thresholdType);
    }
    
    /**
     * Return the total amount of memory this component has borrowed.
     * @param thresholdLevel the threshold structure level.
     * @return the amount of borrowed memory at the specified level.
     * @throws java.lang.Exception any error.
     */
    public int totalBorrowedMemory(int thresholdLevel) throws Exception
    {
        int borrowedMemory = 0;                     //amount of borrowed memory
        
        //can only lend slots if less than original allowed number
        if (thresholdLevel == Const.LINKSOURCE) {
            borrowedMemory = linkBorrowedCount;
        }
        else if (thresholdLevel == Const.MONITORSOURCE) {
            borrowedMemory = monitorBorrowedCount;
        }
        else if (thresholdLevel == Const.POSSIBLESOURCE) {
            borrowedMemory = possibleBorrowedCount;
        }
        
        return borrowedMemory;
    }
    
    /**
     * Return the total amount of memory this component has lent.
     * @param thresholdLevel the threshold structure level.
     * @return the amount of lent memory at the specified level.
     * @throws java.lang.Exception any error.
     */
    public int totalLentMemory(int thresholdLevel) throws Exception
    {
        int lentMemory = 0;                         //amount of lent memory

        //can only lend slots if less than original allowed number
        if (thresholdLevel == Const.LINKSOURCE) {
            for (String key: linkLent.keySet())
            {
                lentMemory += linkLent.get(key);
            }
        }
        else if (thresholdLevel == Const.MONITORSOURCE) {
            for (String key: monitorLent.keySet())
            {
                lentMemory += monitorLent.get(key);
            }
        }
        else if (thresholdLevel == Const.POSSIBLESOURCE) {
            for (String key: possibleLent.keySet())
            {
                lentMemory += possibleLent.get(key);
            }
        }
        
        return lentMemory;
    }
    
    /**
     * Check that the memory for the threshold level is OK.
     * @param thresholdType the threshold level.
     * @throws java.lang.Exception any error.
     */
    public void checkCurrentMemory(int thresholdType) throws Exception
    {
        int currentNumber = getCurrentMemory(thresholdType);
        int theCount = getCurrentCount(thresholdType);
        int totalBorrowed = totalBorrowedMemory(thresholdType);
        
        if (currentNumber < 0) {
            throw new LicasException("Link_M.checkCurrentMemory: " + getUUID() +
                ", threshold: " + thresholdType +
                ", memory: " + currentNumber);
        }
        
        if (theCount > currentNumber) {
            throw new LicasException("Link_M.checkCurrentMemory: " + getUUID() +
                ", threshold: " + thresholdType +
                ", memory: " + currentNumber +
                ", count: " + theCount);
        }
        
        if (totalBorrowed > currentNumber) {
            throw new Exception("Link_M.checkCurrentMemory: " + getUUID() +
                ", threshold: " + thresholdType +
                ", memory: " + currentNumber +
                ", borrowed: " + totalBorrowed);
        }
    }
    
    /**
     * Check memory in all structures to make sure it totals to correct amount.
     * @throws java.lang.Exception any error.
     */
    public void checkAllMemory() throws Exception
    {
        int i;
        int totalPCount;                        //total possible count
        int totalMCount;                        //total monitor count
        int totalLCount;                        //total link count
        int totalPMemory;                       //total possible memory
        int totalMMemory;                       //total monitor memory
        int totalLMemory;                       //total link memory
        int correctCount;                       //correct number of slots
        String msg;                             //error message
        String nextKey;                         //next key
        ArrayList<String> allKeys;              //all service keys
        ArrayList<Object> params;               //method info parameters
        Element handle;                         //the handle path
        MethodInfo methodInfo;                  //method info
        Service componentParent;                //parent of the component
        CallObject call;                        //object call

        if (service != null) {
            msg = "";
            totalPCount = 0;
            totalMCount = 0;
            totalLCount = 0;
            totalPMemory = 0;
            totalMMemory = 0;
            totalLMemory = 0;
            call = new CallObject();

            //get the parent of this module's service, so can ask siblings for memory
            params = new ArrayList<>();
            params.add(passwordHandler.getAdminKey());
            methodInfo = MethodFactory.createMethodCall(MethodConst.GETPARENT, Service.class.getName(),
                    service, params, passwordHandler);
            componentParent = (Service)call.call(methodInfo);

            methodInfo = MethodFactory.createMethodCall(MethodConst.GETSERVICENAMES, TypeConst.ARRAYLIST,
                    componentParent, new ArrayList<>(), passwordHandler);
            allKeys = CollectionHandler.cloneVector((ArrayList) call.call(methodInfo));

            for (i = 0; i < allKeys.size(); i++)
            {
                nextKey = allKeys.get(i);
                handle = componentParent.getFullPath();
                handle = Handle.addToHandle(handle, Handle.asHandleElement(nextKey));
                handle = Handle.addToHandle(handle, Handle.asHandleElement(ServiceConst.LINKER));

                params = new ArrayList<>();
                params.add(new Integer(Const.LINKSOURCE));

                methodInfo = MethodFactory.createMethodCall(MethodConst.GETCURRENTCOUNT, TypeConst.INTEGER,
                        handle, params, passwordHandler);
                totalLCount += ((Integer) call.call(methodInfo)).intValue();

                params = new ArrayList<>();
                params.add(new Integer(Const.MONITORSOURCE));

                methodInfo = MethodFactory.createMethodCall(MethodConst.GETCURRENTCOUNT, TypeConst.INTEGER,
                        handle, params, passwordHandler);
                totalMCount += ((Integer) call.call(methodInfo)).intValue();

                params = new ArrayList<>();
                params.add(new Integer(Const.POSSIBLESOURCE));

                methodInfo = MethodFactory.createMethodCall(MethodConst.GETCURRENTCOUNT, TypeConst.INTEGER,
                        handle, params, passwordHandler);
                totalPCount += ((Integer) call.call(methodInfo)).intValue();

                params = new ArrayList<>();
                params.add(new Integer(Const.LINKSOURCE));

                methodInfo = MethodFactory.createMethodCall(MethodConst.GETCURRENTMEMORY, TypeConst.INTEGER,
                        handle, params, passwordHandler);
                totalLMemory += ((Integer) call.call(methodInfo)).intValue();

                params = new ArrayList<>();
                params.add(new Integer(Const.MONITORSOURCE));

                methodInfo = MethodFactory.createMethodCall(MethodConst.GETCURRENTMEMORY, TypeConst.INTEGER,
                        handle, params, passwordHandler);
                totalMMemory += ((Integer) call.call(methodInfo)).intValue();

                params = new ArrayList<>();
                params.add(new Integer(Const.POSSIBLESOURCE));

                methodInfo = MethodFactory.createMethodCall(MethodConst.GETCURRENTMEMORY, TypeConst.INTEGER,
                        handle, params, passwordHandler);
                totalPMemory += ((Integer) call.call(methodInfo)).intValue();
            }

            correctCount = linkSpec.possibleNumber * allKeys.size();
            if ((totalPCount > correctCount) || (totalPCount < 0)) {
                msg += ", Error: possible count: " +
                        totalPCount + " correct count: " + correctCount + " for sources: " + getUUID();
            }

            if (totalPMemory != correctCount) {
                msg += ", Error: possible memory: " +
                        totalPMemory + " correct count: " + correctCount + " for sources: " + getUUID();
            }

            correctCount = linkSpec.monitorNumber * allKeys.size();
            if ((totalMCount > correctCount) || (totalMCount < 0)) {
                msg += ", Error: monitor count: " +
                        totalMCount + " correct count: " + correctCount + " for sources: " + getUUID();
            }

            if (totalMMemory != correctCount) {
                msg += ", Error: monitor memory: " +
                        totalMMemory + " correct count: " + correctCount + " for sources: " + getUUID();
            }

            correctCount = linkSpec.linkNumber * allKeys.size();
            if ((totalLCount > correctCount) || (totalLCount < 0)) {
                msg += ", Error: link count: " +
                        totalLCount + " correct count: " + correctCount + " for sources: " + getUUID();
            }

            if (totalLMemory != correctCount) {
                msg += ", Error: link memory: " +
                        totalLMemory + " correct count: " + correctCount + " for sources: " + getUUID();
            }

            if (!msg.equals("")) {
                throw new Exception(msg);
            }
        }
        else {
            throw new LicasException("Link_M.checkAllMemory: The linker has not been initialised with the parent service reference.");
        }
    }

    /**
     * Get the current working amount of memory for the threshold level.
     * @param thresholdType the threshold structure type.
     * @return the amount of memory lent.
     */
    public int getCurrentMemory(int thresholdType)
    {
        int currentNumber = 0;                      //existing available slot number

        if (thresholdType == Const.LINKSOURCE) {
            currentNumber = linkSpec.linkNumber;
        }
        else {
            if (thresholdType == Const.MONITORSOURCE) {
                currentNumber = linkSpec.monitorNumber;
            }
            else {
                if (thresholdType == Const.POSSIBLESOURCE) {
                    currentNumber = linkSpec.possibleNumber;
                }
            }
        }

        return currentNumber;
    }

    /**
     * Get the original working amount of memory for the threshold level.
     * @param thresholdType the threshold structure type.
     * @return the amount of memory lent.
     */
    public int getOriginalMemory(int thresholdType)
    {
        int currentNumber = 0;                      //existing available slot number

        if (thresholdType == Const.LINKSOURCE) {
            currentNumber = linkSpec.linkNumber;
        }
        else {
            if (thresholdType == Const.MONITORSOURCE) {
                currentNumber = linkSpec.monitorNumber;
            }
            else {
                if (thresholdType == Const.POSSIBLESOURCE) {
                    currentNumber = linkSpec.possibleNumber;
                }
            }
        }

        return currentNumber;
    }
}
