/*
 * LinkSpec.java
 *
 * Created on 30 July 2014
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.service.spec;


import org.licas.service.link.LinkConfig;
import org.licas.util.Const;

import java.util.HashMap;


/**
 * This class can provide a general specification for linking classes, the dynamic
 * linking classes in particular.
 * @author Kieran Greer
 */
public class LinkSpec
{
    /** The threshold for a link level entry */
    public float linkThreshold;
    
    /** The threshold for a monitor level entry */
    public float monitorThreshold;
    
    /** Maximum number of allowed entries at the link level */
    public int linkNumber;
        
    /** Maximum number of allowed entries at the monitor level */
    public int monitorNumber;
        
    /** Maximum number of allowed entries at the possible level */
    public int possibleNumber;
    
    /** Link reference linkIncrement value */
    public float linkIncrement;
    
    /** Link reference linkWeightDec decrement value */
    public float linkWeightDec;
    
    /** Linking method */
    public String linkMethod;
    
    /** Linking activation function class name. Of type {@link LinkConfig}.{@code activationFunctions()} */
    public String functionActivate;
    
    /** Function config values. Key-value pairs. */
    public HashMap<String, String> functionConfig;
    
    /** 
     * Create a new instance of LinkSpec.
     */
    public LinkSpec()
    {
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        linkNumber = 0;        
        monitorNumber = 0;       
        possibleNumber = 0;    
        linkThreshold = (float)0.0; 
        monitorThreshold = (float)0.0;   
        linkIncrement = (float)0.0;   
        linkWeightDec = (float)0.0;   
        linkMethod = null;
        functionActivate = null;
        functionConfig = new HashMap<>();
    }
    
    /**
     * Validate the whole script and return a description of any errors.
     * @return a description of any errors or null if OK.
     */
    public String validateScript()
    {
        String validateReply;                   //validation errors
        
        validateReply = "";
        validateReply += validateVariable(Const.LINKNUMBER);
        validateReply += validateVariable(Const.MONITORNUMBER);
        validateReply += validateVariable(Const.POSSIBLENUMBER);
        validateReply += validateVariable(Const.LINKTHRESHOLD);
        validateReply += validateVariable(Const.MONITORTHRESHOLD);
        validateReply += validateVariable(Const.LINKINCREMENT);
        validateReply += validateVariable(Const.LINKWEIGTDECREMENT);
        validateReply += validateVariable(Const.LINKMETHOD);

        validateReply = validateReply.trim();
        if (validateReply.equals("")) validateReply = null;
        return validateReply;
    }
    
    /**
     * Validate the script variable and return a description if invalid.
     * @param varType the variable type.
     * @return a description of any error, of null if OK.
     */
    protected String validateVariable(String varType)
    {
        String validateError;                   //validate error
        
        validateError = "";
        if (linkMethod != null)
        {
            if (varType.equals(Const.LINKNUMBER))
            {
                try {
                    if (linkNumber <= 0)
                        validateError = (Const.LINKNUMBER + ": must be greater than 0.\n");
                }
                catch (Exception ex) {
                    validateError = (Const.LINKNUMBER + ": has incorrect format.\n");
                }
            }
            else if (varType.equals(Const.MONITORNUMBER))
            {
                try {
                    if (monitorNumber <= 0)
                        validateError = (Const.MONITORNUMBER + ": must be greater than 0.\n");
                }
                catch (Exception ex) {
                    validateError = (Const.MONITORNUMBER + ": has incorrect format.\n");
                }
            }
            else if (varType.equals(Const.POSSIBLENUMBER))
            {
                try {
                    if (possibleNumber <= 0)
                        validateError = (Const.POSSIBLENUMBER + ": must be greater than 0.\n");
                }
                catch (Exception ex) {
                    validateError = (Const.POSSIBLENUMBER + ": has incorrect format.\n");
                }
            }
            else if (varType.equals(Const.LINKTHRESHOLD))
            {
                try {
                    if (linkThreshold <= 0.0)
                        validateError = (Const.LINKTHRESHOLD + ": must be greater than 0.0.\n");
                }
                catch (Exception ex) {
                    validateError = (Const.LINKTHRESHOLD + ": has incorrect format.\n");
                }
            }
            else if (varType.equals(Const.MONITORTHRESHOLD))
            {
                try {
                    if (monitorThreshold <= 0.0)
                        validateError = (Const.MONITORTHRESHOLD + ": must be greater than 0.0.\n");
                    else if (monitorThreshold >= linkThreshold)
                        validateError = (Const.MONITORTHRESHOLD + ": must be less than " + 
                                Const.LINKTHRESHOLD + ".\n");
                }
                catch (Exception ex) {
                    validateError = (Const.MONITORTHRESHOLD + ": has incorrect format.\n");
                }
            }   
            else if (varType.equals(Const.LINKINCREMENT))
            {
                try {
                    if (linkIncrement <= 0.0)
                        validateError = (Const.LINKINCREMENT + ": must be greater than 0.0.\n");
                }
                catch (Exception ex) {
                    validateError = (Const.LINKINCREMENT + ": has incorrect format.\n");
                }
            }
            else if (varType.equals(Const.LINKWEIGTDECREMENT))
            {
                try {
                    if (linkWeightDec <= 0.0)
                        validateError = (Const.LINKWEIGTDECREMENT + ": must be greater than 0.0.\n");
                }
                catch (Exception ex) {
                    validateError = (Const.LINKWEIGTDECREMENT + ": has incorrect format.\n");
                }
            }
            else if (varType.equals(Const.LINKMETHOD))
            {
                try {
                    if (!LinkConfig.isLinkMethod(linkMethod))
                        validateError = (Const.LINKMETHOD + ": is not valid.\n");
                }
                catch (Exception ex) {
                    validateError = (Const.LINKMETHOD + ": has incorrect format.\n");
                }
            }
        }
        
        return validateError;
    }
    
    /**
     * Clone the parameter values into this spec.
     * @param thisSpec he spec to copy.
     */
    public void copy(LinkSpec thisSpec)
    {
        linkNumber = thisSpec.linkNumber;        
        monitorNumber = thisSpec.monitorNumber;       
        possibleNumber = thisSpec.possibleNumber;    
        linkThreshold = thisSpec.linkThreshold; 
        monitorThreshold = thisSpec.monitorThreshold;   
        linkIncrement = thisSpec.linkIncrement;   
        linkWeightDec = thisSpec.linkWeightDec;   
        linkMethod = thisSpec.linkMethod;
        functionActivate = thisSpec.functionActivate;
        functionConfig = (HashMap)thisSpec.functionConfig.clone();
    }
}
