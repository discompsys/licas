/*
 * Link_B.java
 *
 * Created on 20 July 2011
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.link;


import org.licas.PasswordHandler;
import org.licas.Service;
import org.licas.service.spec.LinkSpec;
import org.jlog2.*;

import java.util.ArrayList;


/**
 * This is the most basic implementation of a linking service that does not apply 
 * any memory restrictions and only increments link references. It might be useful
 * as an upper bound measurement on linking performance.
 * @author Kieran Greer
 */
public class Link_B extends Link
{
    /** The logger */
    private static final Logger logger;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(Link_B.class.getName());
        logger.setDebug(false);
    }

    /**
     * Creates a new instance of Link_B. Need to call {@code setServiceDetails} later.
     * @throws Exception any error.
     */
    public Link_B() throws Exception
    {
        super();
    }

    /**
     * Creates a new instance of Link_B.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public Link_B(Service service, PasswordHandler pHandler) throws Exception
    {
        super(service, pHandler);
    }

    /**
     * Creates a new instance of Link_B.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @param thisLinkSpec the config to use for initialising the thresholds structures.
     * @throws java.lang.Exception any error.
     */
    public Link_B(Service service, PasswordHandler pHandler, LinkSpec thisLinkSpec) throws Exception
    {
        super(service, pHandler, thisLinkSpec);
    }

    /**
     * Update the linkSpec structure. Add or update the new sources references
     * and also add these to the added sources list.
     * @param theThresholds the linkSpec structure.
     * @param conceptPath a preferred path to find in the tree.
     * @param newSources list of sources to add or update.
     * @param timeStamp time stamp for update.
     * @param sourcesAdded a list of all added sources over all of the update calls.
     * @param negative a list of negative source results. Can be empty.
     * @throws java.lang.Exception any error.
     */
    protected void updateThresholds(Thresholds theThresholds, ArrayList<String> conceptPath,
                                    ArrayList newSources, long timeStamp,
                                    ArrayList sourcesAdded, ArrayList negative) throws Exception
    {
        int i;
        boolean addNegative;                    //true if add negative concepts
        
        addNegative = LinkConfig.addNegative(linkSpec.linkMethod);        
        for (i = 0; i < newSources.size(); i++)
        {
            theThresholds.incAndMoveSourceUp(newSources.get(i), timeStamp);          
            sourcesAdded.add(newSources.get(i));

            if (addNegative && ((negative != null) && !negative.isEmpty())) {
                theThresholds.storeNegatives(newSources.get(i), negative);
            }
        }
    }

    /**
     * Create a new threshold object partially filled in.
     * @return the created threshold source object.
     * @throws java.lang.Exception any error.
     */
    public Thresholds createNewThresholds() throws Exception
    {
        return new Thresholds(this);
    }
}
