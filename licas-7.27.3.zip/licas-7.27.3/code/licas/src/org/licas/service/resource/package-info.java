/**
 * Resource objects are stored here and its sub-packages, used to reference data-specific information in different ways, as opposed to the more commplex service hierarchy and functionality.
 */
package org.licas.service.resource;