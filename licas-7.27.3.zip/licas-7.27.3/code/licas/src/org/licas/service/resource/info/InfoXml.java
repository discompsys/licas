/*
 * InfoXml.java
 *
 * Created on 17 September 2013
 *
 * Version 1.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.resource.info;


import org.licas.meta.MetaFactory;
import org.licas.parsers.Parsers;
import org.licas.parsers.types.DomParser;
import org.licas.service.resource.Resource;
import org.licas.util.*;
import org.licas.util.exception.LicasException;
import org.licas_xml.abs.*;
import org.licas_xml.model.XmlHandler;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;


/**
 * This is used by a Service to store XML-based information specifically.
 * Note that {@code getValue} returns an {@link org.w3c.dom.Document} as the XML object,
 * not a {@code nanoxml} Document that is used for the message passing.
 * @author Kieran Greer
 */
public class InfoXml extends Resource
{
    /** The logger */
    private static Logger logger;
    
     
    /** The xml data */
    private FileObject xmlData;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(InfoXml.class.getName());
        logger.setDebug(false);
    }

    
    /**
     * Create a new instance of InfoXml.
     * @param theDataType the resource data type.
     * @param dataXml a description of the initialisation parameters. Can be null.
     * @throws java.lang.Exception any error.
     */
    public InfoXml(String theDataType, Element dataXml) throws Exception
    {
        super(theDataType);
        xmlData = new FileObject();
        
        if ((dataXml != null) && !parseInfo(dataXml))
        {
            throw new LicasException("Could not parse the data description.");
        }
    }
    
    /**
     * Parse the data description in the document to create the data object.
     * This version should read a file path. It can then either load in the contents
     * or reference it dynamically.
     * @param dataXml the outermost element is not checked for, but might be a {@code DATA}
     * or {@code DATASET} element. This should include a {@link Const}.{@code VALUE} element
     * that stores a String-based file path description and possibly an {@code ACTION} element
     * that can define if the data is stored in the resource or dynamically retrieved upon request
     * through {@code <Data><Value>file path</Value><Action>the action</Action></Data>}.
     * The action ({@link AiConst}.{@code LOADREMOTE}) stores the file path to dynamically
     * retrieve the data upon request. Anything else, including no action, loads the data
     * into the resource as binary contents.
     * @return true if the file was successfully loaded, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean parseInfo(Element dataXml) throws Exception
    {
        String filePath;                            //the file path
        String actionType;                          //the type of action
        Element dataValueElem;                      //data value element
        
        try
        {
            setUUID(dataXml);
            dataValueElem = parseValueElem(dataXml);

            //value element can specify a file path or the data directly
            //if text value then a file path, if child element then data directly
            if (dataValueElem != null) {
                if (!dataValueElem.hasChildren()) {
                    filePath = dataValueElem.getText();
                    if (filePath != null) {
                        if (FileObject.isKnownFile(filePath) && FileObject.isXmlFile(filePath)) {
                            dataValueElem = dataXml.getChild(AiConst.ACTION);
                            if (dataValueElem != null) {
                                actionType = dataValueElem.getText();
                                if (actionType.equalsIgnoreCase(AiConst.LOADREMOTE)) {
                                    xmlData.setFilePath(filePath);
                                } else {
                                    xmlData.loadFile(filePath);
                                }

                                return true;
                            } else {
                                xmlData.loadFile(filePath);
                                return true;
                            }
                        }
                    }
                } else {
                    dataValueElem = (Element) dataValueElem.getChildren().elementAt(0);
                    dataValueElem.detach();
                    xmlData.setFileContents(dataValueElem);
                    return true;
                }
            }

            return false;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parseInfo",
                null, ex);
        }
    }
    
    /**
     * Get the currently loaded source information wrapped in an XML element.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * Can be null as not used in this version.
     * @return the value of the resource info as an XML element. This format is 
     * consistent with adding a {@code Data} element through an admin document.
     * @throws java.lang.Exception any error.
     */
    public Element getInfo(Element infoDescr) throws Exception
    {
        String xmlInfo;                             //xml info
        Element sourceInfo;                         //source info
        
        try
        {
            sourceInfo = XMLFactory.getInstance().createElement(Const.DATA);
            if (xmlData != null) 
            {
                xmlInfo = Parsers.serializeToString(xmlData.getFileContents());
                xmlInfo = DomParser.removeW3cSpec(xmlInfo);
                xmlInfo = XmlHandler.removeStringSpec(xmlInfo);

                sourceInfo = MetaFactory.getFactoryData().createDataTypeValue(dataType, xmlInfo);
            } 
            
            return sourceInfo;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getInfo",
                null, ex);
        } 
    }
    
    /**
     * Get the value itself and not a wrapped description.
     * @param infoDescr a description of the info resource value that should be retrieved.
     * Can be null as not used in this version.
     * @return the info value.
     * @throws java.lang.Exception any error.
     */
    public Object getValue(Element infoDescr) throws Exception
    {
        return xmlData.getFileContents();
    }
}
