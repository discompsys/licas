/*
 * LinkService.java
 *
 * Created on 14 July 2014
 *
 * Version 1.10.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.service.sci;


import org.ai_heuristic.eval.metric.MetricDataset;
import org.licas.Auto;
import org.licas.MessageInfo;
import org.licas.call.Handle;
import org.licas.data.*;
import org.licas.module.HeuristicModule;
import org.licas.module.ModuleHandler;
import org.licas.module.h_module.HM_Cluster;
import org.licas.module.s_module.*;
import org.licas.server.LocalServer;
import org.licas.service.link.Link_M;
import org.licas.util.*;
import org.licas_xml.abs.Element;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.licas_xml.model.XmlHandler;

import java.util.*;


/**
 * This class can be used for running a behaviour that evaluates data and creates links between 
 * services based on the result. As such, it uses the autonomous capabilities of the framework 
 * and therefore extends the {@link Auto} class. 
 * <p>
 * Through the {@code evaluateBehaviour} method, a service id is removed after only 1
 * evaluation with it and so the dataset values would be retrieved and compared only once.
 * <p>
 * This service can be used as part of the problem solving package and can be used with 
 * the clustering services there, for example.
 * @author Kieran Greer
 */
public class LinkService extends Auto
{
    /** The logger */
    private static final Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(LinkService.class.getName());
        logger.setDebug(false);
    }
    
    
    /**
     * Create a new instance of LinkService.
     * @throws java.lang.Exception any error.
     */
    public LinkService() throws Exception
    {
        super();
        initialise();
    }
    
    /** 
     * Creates a new instance of LinkService.
     * @param thisPassword the component password.
     * @param thisAdminKey the unique service key.
     * @throws java.lang.Exception any error.
     */
    public LinkService(String thisPassword, String thisAdminKey) throws Exception
    {
        super(thisPassword, thisAdminKey);
        initialise();
    }
    
    /** 
     * Creates a new instance of LinkService.
     * @param thisPassword the component password.
     * @param thisAdminKey the unique service key.
     * @param adminXml the admin info or description of this service.
     * @throws java.lang.Exception any error.
     */
    public LinkService(String thisPassword, String thisAdminKey, Element adminXml)
            throws Exception
    {
        super(thisPassword, thisAdminKey, adminXml);
        initialise();
    }

    /** 
     * Initialise some values.
     * @throws java.lang.Exception any error.
     */
    private void initialise() throws Exception
    {
        //can create the script if know the data type and using a link data service
        if (!serviceAdmin.getAdminInfo().getAdditional().containsKey(AiConst.PROCESS)) {
            if (!dm.isEmpty()) {
                autoEngine.setEventRuleAction(createProcessScript());
            }
        }
    }
    
    /**
     * Reset variables for another test run.
     */
    public void resetValues()
    {
        if (sm != null) {
            ((SM_Auto)sm).resetValues();
        }
    }

    /**
     * This behaviour compares service data and tries to cluster them. It then creates links
     * with services that it is closest to. Each service is asked to send its data and it gets
     * compared with the local dataset. The result is also sent to a {@code Behaviour Mediator}
     * service for viewing. The evaluation result is then returned as the method result.
     * @param messageInfo the message to evaluate. This service uses a {@link DataQueryModel}-derived
     * object that is configured in the method before being evaluated. If a DataQuery object
     * is passed as the message object, then it is updated in the method. If not, then the
     * message object is ignored and a new DataQuery object is created internally.
     * @return the result of executing the behaviour.
     * @throws java.lang.Exception any error.
     */
    protected MessageInfo behaviourAction(MessageInfo messageInfo) throws Exception
    {
        HeuristicModule evaluate;                   //heuristic evaluation module
        MessageInfo messageReply;                   //message reply

        try {
            //check that the heuristic has been created
            evaluate = null;
            if (hasService(ServiceConst.EVALUATE)) {
                evaluate = (HM_Cluster) getService(ServiceConst.EVALUATE,
                        passwordHandler.getPassword(), passwordHandler.getAdminKey());
            }

            //run the behaviour and evaluation
            messageReply = bm.behaviourAction(messageInfo, evaluate, (SM_Data)sm);

            //if cluster heuristic, convert the dynamic links into permanent ones
            if (evaluate != null) {
                dynamicLinksToPermanent(passwordHandler.getAdminKey());
            }

            //added in case the default script sets a value for the result
            if (getResultObj() != null) {
                dataXmlBM(passwordHandler.getAdminKey());
            }

            return messageReply;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "behaviourAction", null, ex);
        }
    }

    /**
     * Calculate the current state for the message and related conversation. If this
     * service is involved in conversations with several other services, for example,
     * each conversation can be at a different stage, resulting in a different state
     * for each conversation process. This method should be used to return the current
     * state for the specified conversation. It should be implemented by any derived 
     * class, but only called internally, inside the {@code messageReply} method, for example.
     * <p>
     * This link service version checks if the message parameter is a {@link MessageInfo} object.
     * If it is, it returns its {@code getMessageState} method call. If it is not, then it
     * returns the {@link AiConst}.{@code ACTION} value. 
     * @param communicationID the communication ID. This defines the communication
     * thread and therefore the conversation.
     * @param message an object representing a result from the other service in the
     * conversation. This can represent the result of the last conversation task, 
     * or can be null if no information is required.
     * @return the state of this service relating to the selected conversation.
     */
    protected String getMessageState(String communicationID, Object message)
    {
        if (message instanceof MessageInfo) {
            return ((MessageInfo)message).getMessageState();
        }
        
        return AiConst.ACTION;
    }

    /**
     * Add a dynamic link for the service with an empty path description.
     * @param serviceUri the full uri path for the service.
     * @return a list of the sources that have been added.
     * @throws Exception any error.
     */
    public ArrayList<?> addDynamicLink(Element serviceUri) throws Exception
    {
        ArrayList<Object> sourceList;              //sources list

        sourceList = new ArrayList<>();
        sourceList.add(serviceUri);
        return addDynamicLinks(sourceList, null);
    }
    
    /**
     * Add related sources to the dynamic linking service of this service. This is 
     * probably the easiest way to update dynamic links, where this default version
     * retrieves the linking service called {@code ServiceConst.LINKER} on this service.
     * This version no longer sends any information to a mediator.
     * @param sourceList the list of source uris to add. This is the list of source
     * links to update.
     * @param conceptList the list of concepts that would make up the linking path.
     * @return a list of the sources that have been added.
     * @throws Exception any error.
     */
    public ArrayList<?> addDynamicLinks(ArrayList<?> sourceList, ArrayList<String> conceptList)
            throws Exception
    {
        Link_M linker;                              //linking service

        linker = (Link_M)getService(ServiceConst.LINKER, passwordHandler.getServicePassword(ServiceConst.LINKER),
                passwordHandler.getAdminKey(ServiceConst.LINKER));
        
        return linker.addDynamicLinks(sourceList, conceptList);
    }

    /**
     * Update dynamic links for the services that are grouped together. This calls
     * {@code addDynamicLinks} on the linker utility service and also checks if
     * reliable links should be made permanent.
     * @param conceptList the path concept list, of any description.
     * @param serviceGroups the groups of services that are clustered together.
     * Each list element can be a service, where the value is a list of other services related to it,
     * as in {@code ArrayList<String>}. The value is therefore a list of related service names.
     * @param toPermanent if true, convert any dynamic links at the link level
     * into permanent links, or remove permanent links now moved down a level.
     * @param adminKey the service admin key.
     * @throws java.lang.Exception any error.
     */
    public void updateDynamicLinks(ArrayList<String> conceptList, ArrayList<?> serviceGroups, boolean toPermanent,
                                   String adminKey) throws Exception
    {
        int i, j;
        String linkUuid;                            //link uuid
        Element linkUri;                            //link uri
        ArrayList nextList;                         //next list
        ArrayList linkList;                         //link references
        Object nextListObj;                         //next list object

        try {
            for (i = 0; i < serviceGroups.size(); i++)
            {
                nextListObj = serviceGroups.get(i);
                linkList = new ArrayList();

                if (nextListObj instanceof ArrayList) {
                    nextList = (ArrayList)nextListObj;
                }
                else {
                    nextList = new ArrayList();
                    nextList.add(ObjectHandler.getValue(nextListObj));
                }

                for (j = 0; j < nextList.size(); j++)
                {
                    linkUuid = (String)nextList.get(j);
                    try {
                        linkUri = XmlHandler.stringToElement(linkUuid);
                        linkUuid = Handle.getLastServiceHandle(linkUri);
                    }
                    catch (Exception xmlex2) {
                        linkUri = Handle.createNewUrlHandle(LocalServer.getServerURL());
                        linkUri = Handle.addToHandle(linkUri, Handle.asHandleElement(linkUuid));
                    }

                    linkList.add(linkUri);
                }

                addDynamicLinks(linkList, conceptList);
            }

            if (toPermanent) {
                dynamicLinksToPermanent(adminKey);
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "updateDynamicLinks", null, ex);
        }
    }

    /**
     * Add a permanent link between this service and the service specified.
     * @param serviceUri the path to the service to add a permanent link to.
     */
    public void addPermanentLink(Element serviceUri)
    {
        String serviceUuid;

        serviceUuid = Handle.getLastServiceHandle(serviceUri);
        if (passwordHandler.hasServicePassword(serviceUuid)) {
            serviceLinks.getPermanentLinks().addLinkToService(serviceUuid, serviceUri);  
        }
    }
    
    /**
     * Remove a permanent link between this service and the service specified.
     * @param serviceUuid the uuid of the service to remove the permanent link to.
     */
    public void removePermanentLink(String serviceUuid)
    {
        if (passwordHandler.hasServicePassword(serviceUuid)) {
            serviceLinks.getPermanentLinks().removeLinkToService(serviceUuid);
        }
    }
    
    /**
     * Remove all of the permanent links from this service.
     */
    public void removeAllPermanentLinks()
    {
        int i;
        String selectedID;                          //selected id
        ArrayList<String> linkedIDs;                //list of linked to ids

        linkedIDs = serviceLinks.getPermanentLinks().getAllLinkToServiceIDs();
        for (i = 0; i < linkedIDs.size(); i++)
        {
            selectedID = linkedIDs.get(i);
            serviceLinks.getPermanentLinks().removeLinkToService(selectedID);
        }
    }

    /**
     * Randomly retrieve the next dataset for evaluation. This is from any 
     * service on the current list. This then also removes the service from the
     * list. Use {@code resetServiceIDs} to reset to the full list of other services again.  
     * This version calls {@code getValue} that uses the {@code EvaluateBase.valueFromString} 
     * method to try to parse a string-based representation of a value into a Java object, 
     * which will only automatically work for simple types, or XML.
     * @return the retrieved data as a MetricDataset object.
     * @throws java.lang.Exception and error.
     */
    public MetricDataset getDataRandomID() throws Exception
    {
        return ((SM_Auto)sm).getDataRandomID();
    }

    /**
     * Create the policy description that can be used as a default script for initialising the
     * auto engine of this service. This is for the service itself, not any related autonomic
     * manager.
     * @return a policy script to initialise the service with.
     * @throws java.lang.Exception any error.
     */
    public Element createProcessScript() throws Exception
    {
        if (ModuleHandler.isScriptModule(sm)) {
            return ((SM_LinkData) sm).createProcessScript();
        }

        return null;
    }
}
