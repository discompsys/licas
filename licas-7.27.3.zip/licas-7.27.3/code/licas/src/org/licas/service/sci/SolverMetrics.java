/*
 * SolverMetrics.java
 *
 * Created on 29 January 2016
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.service.sci;


import org.ai_heuristic.functs.*;
import org.licas.data.EvaluateData;

import java.util.*;


/**
 * This class is able to return a metric or function for a particular description. It does this
 * locally onl and is not extended by other solver packages. The {@code DefaultSolverMetrics}
 * class of the problem solver is extendable with external packages.
 * @author Kieran Greer
 */
public class SolverMetrics
{
    /**
     * Create a new instance of SolverMetrics.
     */
    public SolverMetrics()
    { }


    /**
     * Create and return the correct function/metric for the input parameters.
     * @param valueType the type of object being evaluated.
     * @param functionType the type of function to create.
     * @return the created evaluation function.
     * @throws java.lang.Exception any error.
     */
    public Function getEvaluationFunction(String valueType, String functionType)
            throws Exception
    {
        return getEvaluationFunction(valueType, functionType, null, null);
    }

    /**
     * Create and return the correct function/metric for the input parameters. This calls
     * {@link Function}.{@code createFunction} in the first instance and tries to configure it.
     * @param valueType the type of object being evaluated.
     * @param functionType the type of function to create.
     * @param evaluator the evaluator. Can be null for a default evaluator.
     * @param configParams a list of any input configuration parameters. Can be null for no parameters.
     * @return the created evaluation function.
     * @throws java.lang.Exception any error.
     */
    public Function getEvaluationFunction(String valueType, String functionType,
                                          EvaluateData evaluator, HashMap<String, ?> configParams) throws Exception
    {
        Function function;                          //the function

        if (configParams == null) {
            function = Function.createFunction(functionType, valueType);
        }
        else {
            function = Function.createFunction(functionType, valueType, configParams);
        }

        if ((function != null) && (evaluator != null))
        {
            if (evaluator.isCompareFunction()) {
                function.setEvaluator(evaluator.getMathCompare());
            }
        }

        return function;
    }
}
