/**
 * Contains base classes that can be used to build the (autonomic) services, including the
 * base {@code Service} and {@code Auto} classes and their main framework components. 
 */
package org.licas;