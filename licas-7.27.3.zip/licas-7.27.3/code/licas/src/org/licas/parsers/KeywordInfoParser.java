/*
 * KeywordInfoParser.java
 *
 * Created on 5 February 2018
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.parsers;


import org.ai_heuristic.def.ParserDef;
import org.licas.service.model.KeywordInfo;
import org.licas.util.Const;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;
import java.util.Vector;


/**
 * This class can be used to parse a {@link KeywordInfo} object to or from XML.
 * @author Kieran Greer
 */
public class KeywordInfoParser implements ParserDef
{
    /** Create a new instance of KeywordInfoParser */
    public KeywordInfoParser()
    {}
    
    /**
     * Serialize a KeywordInfo object to XML.
     * @param toSerialize the KeywordInfo object to serialize.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        int i;
        String nextKeyword;                         //next keyword
        ArrayList keywordList;                      //keyword list
        KeywordInfo keywordInfo;                    //keyword info
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        
        try
        {
            rootElem = XMLFactory.getInstance().createElement(Const.KEYWORDINFO);
            keywordInfo = (KeywordInfo)toSerialize;

            if (keywordInfo.getTopic() != null)
            {
                rootElem.setAttribute(Const.CONCEPT, keywordInfo.getTopic());
            }
            if (keywordInfo.getLanguage() != null)
            {
                rootElem.setAttribute(Const.LANGUAGE, keywordInfo.getLanguage());
            }
            if (keywordInfo.getSource() != null)
            {
                rootElem.setAttribute(Const.SOURCE, keywordInfo.getSource());
            }
            
            keywordList = keywordInfo.getKeywords();
            for (i = 0; i < keywordList.size(); i++)
            {
                nextKeyword = (String)keywordList.get(i);

                nextElem = XMLFactory.getInstance().createElement(Const.KEYWORD);
                nextElem.setText(nextKeyword);
                rootElem.addContent(nextElem);
            }

            return rootElem;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /**
     * Parse an XML description of a KeywordInfo object back into a Java object.
     * @param toParse the XML description to parse.
     * @return the KeywordInfo object that is created.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        int i;
        String concept;                             //concept name
        String language;                            //language
        String source;                              //source
        String keyword;                             //keyword
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Vector elemList;                            //element list
        KeywordInfo keywordInfo;                    //keyword handler

        try
        {
            keywordInfo = null;
            if (toParse.getName().equals(Const.KEYWORDINFO)  ||
                    toParse.getName().equals(Const.CONCEPT))
            {
                concept = toParse.getAttributeValue(Const.NAME);
                language = toParse.getAttributeValue(Const.LANGUAGE);
                source = toParse.getAttributeValue(Const.SOURCE);                   
                keywordInfo = new KeywordInfo(concept, language, source);
                
                elemList = toParse.getChildren();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);
                    if (nextNode instanceof Element)
                    {
                        nextElem = (Element)nextNode;
                        if (nextElem.getName().equals(Const.KEYWORD))
                        {
                            keyword = nextElem.getText();
                            keywordInfo.addKeyword(keyword);                                   
                        }
                    }
                }
            }

            return keywordInfo;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
