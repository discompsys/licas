/*
 * ParameterParser.java
 *
 * Created on 15 February 2013
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.parsers;


import org.ai_heuristic.def.ParserDef;
import org.licas.call.ParamInfo;
import org.licas.util.Const;
import org.licas.ws.wsdl.model.WsdlParamInfo;
import org.licas_xml.abs.Element;


/**
 * This class can be used to parse a {@link WsdlParamInfo} or a {@link ParamInfo} object to or from XML.
 * This parses all entries, whereas the method parser only parses the value part.
 * @author Kieran Greer
 */
public class ParameterParser implements ParserDef
{
    /**
     * Create a new instance of ParameterParser.
     */
    public ParameterParser()
    {}

    /**
     * Serialize a {@link ParamInfo} or {@link WsdlParamInfo} object to XML.
     * @param toSerialize the ParamInfo object to serialize.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        Element rootElem;                           //root element
        
        try
        {
            rootElem = null;
            if (toSerialize instanceof WsdlParamInfo) 
            {
                rootElem = ((WsdlParamInfo)toSerialize).toElement();
            }
            else if (toSerialize instanceof ParamInfo) 
            {
                rootElem = ((ParamInfo)toSerialize).toElement();
            }

            return rootElem;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /**
     * Parse an XML description of a {@link ParamInfo} or {@link WsdlParamInfo} object back into a Java object.
     * @param toParse the XML description to parse.
     * @return the parameter info object that is created.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        ParamInfo paramInfo;                        //parameter info
        WsdlParamInfo wsdlParamInfo;                //wsdl parameter info
        Object paramObj;                            //parameter object

        try
        {
            paramObj = null;
            if (toParse.getName().equals(Const.WSDLPARAMETER))
            {
                wsdlParamInfo = new WsdlParamInfo();
                wsdlParamInfo.fromElement(toParse);
                paramObj = wsdlParamInfo;
            }
            else if (toParse.getName().equals(Const.PARAMETER))
            {
                paramInfo = new ParamInfo();
                paramInfo.fromElement(toParse);
                paramObj = paramInfo;
            }
            
            return paramObj;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
