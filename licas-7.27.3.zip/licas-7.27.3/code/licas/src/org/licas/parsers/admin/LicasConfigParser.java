/*
 * LicasConfigParser.java
 *
 * Created on 28 October 2011
 *
 * Version 1.11
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.parsers.admin;


import org.ai_heuristic.model.FactoryInfo;
import org.jlog2.util.FileLoader;
import org.licas.meta.LicasConfig;
import org.licas.meta.model.ModuleInfo;
import org.licas.meta.model.ServiceModuleInfo;
import org.licas.security.SecurityWebManager;
import org.licas.server.model.ServerConfig;
import org.licas.util.Const;
import org.licas.util.MetaConst;
import org.licas.util.ServiceConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;


/**
 * This can parse a {@link LicasConfig} object that contains all configuration information,
 * including service types with related GUI interface classnames.
 * @author Kieran Greer
 */
public class LicasConfigParser
{
    /** Create a new instance of LicasConfigParser */
    public LicasConfigParser()
    {}

    /**
     * Serialize the object into an XML element.
     * @param licasConfig the licas configuration information.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(LicasConfig licasConfig) throws Exception
    {
        int i, j;
        String serviceType;                         //next service type
        String functionType;                        //next function type
        String filePath;                            //file path
        String className;                           //class name
        String moduleName;                          //module name
        ServerConfig serverConfig;                  //server config
        ServiceModuleInfo serviceInfo;              //service info
        Iterator typesList;                         //type keys
        Iterator modulesList;                       //modules list
        Iterator functionTypes;                     //function types
        HashMap allInfo;                            //all factory info
        HashMap defaultServices;                    //default services
        ServerConfigParser serverParser;            //server config parser
        ModuleInfo moduleInfo;                      //module info
        FactoryInfo factoryInfo;                    //factory info
        ModuleInfoParser moduleParser;              //module parser
        ServiceModuleInfoParser sModuleParser;      //service module parser
        SecurityWebManager swManager;               //security web manager
        SecurityManagerParser swParser;             //security manager parser
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Element nextElem3;                          //next element
        Element nextElem4;                          //next element
        Element nextElem5;                          //next element
        
        serverParser = new ServerConfigParser();
        sModuleParser = new ServiceModuleInfoParser();
        moduleParser = new ModuleInfoParser();
        
        rootElem = XMLFactory.getInstance().createElement(ServiceConst.LICASCONFIG); 
        
        serverConfig = licasConfig.getServerConfig();
        nextElem = serverParser.serialize(serverConfig);
        rootElem.addContent(nextElem);
               
        nextElem = XMLFactory.getInstance().createElement(ServiceConst.SERVERGUI);       
        rootElem.addContent(nextElem);
        
        if (licasConfig.getScientific())
        {
            nextElem2 = XMLFactory.getInstance().createElement(Const.SCIENTIFIC);
            nextElem.addContent(nextElem2);
        }
        
        nextElem2 = XMLFactory.getInstance().createElement(Const.ALLOWEXTERNALJARS);
        nextElem2.setText(Boolean.toString(licasConfig.getExternalJars()));
        nextElem.addContent(nextElem2);
        
        nextElem2 = XMLFactory.getInstance().createElement(Const.TIMEOUT);
        nextElem2.setText(Integer.toString(licasConfig.getTimeout()));
        nextElem.addContent(nextElem2);
        
        nextElem2 = XMLFactory.getInstance().createElement(Const.HORIZONTALGAP);
        nextElem2.setText(Integer.toString(licasConfig.getHorizGapFactor()));
        nextElem.addContent(nextElem2);
        
        nextElem2 = XMLFactory.getInstance().createElement(Const.VERTICALGAP);
        nextElem2.setText(Integer.toString(licasConfig.getVertGapFactor()));
        nextElem.addContent(nextElem2);
        
        nextElem2 = XMLFactory.getInstance().createElement(Const.NETWORKDEPTH);
        nextElem2.setText(Integer.toString(licasConfig.getMaxNetworkDepth()));
        nextElem.addContent(nextElem2);
        
        nextElem2 = XMLFactory.getInstance().createElement(Const.MAXNODES);
        nextElem2.setText(Integer.toString(licasConfig.getMaxNodes()));
        nextElem.addContent(nextElem2);
        
        nextElem2 = XMLFactory.getInstance().createElement(Const.REDRAWDELAY);
        nextElem2.setText(Integer.toString(licasConfig.getRedrawDelay()));
        nextElem.addContent(nextElem2);
        
        
        nextElem = XMLFactory.getInstance().createElement(ServiceConst.DEFAULTSERVICEFACTORY);       
        rootElem.addContent(nextElem);
        
        if (licasConfig.getDefaultServiceFactory().jarFilePath != null)
        {
            nextElem2 = XMLFactory.getInstance().createElement(ServiceConst.FILE);
            filePath = licasConfig.getDefaultServiceFactory().jarFilePath;   
            nextElem2.setText(filePath);
            nextElem.addContent(nextElem2);
            
            if (licasConfig.getDefaultServiceFactory().factoryClass != null)
            {
                nextElem2 = XMLFactory.getInstance().createElement(Const.CLASSNAME);
                className = licasConfig.getDefaultServiceFactory().factoryClass;   
                nextElem2.setText(className);
                nextElem.addContent(nextElem2);
            }
        }
        
        nextElem = XMLFactory.getInstance().createElement(ServiceConst.DEFAULTJARFACTORY);       
        rootElem.addContent(nextElem);
        
        if (licasConfig.getDefaultJarFactory().jarFilePath != null)
        {
            nextElem2 = XMLFactory.getInstance().createElement(ServiceConst.FILE);
            filePath = licasConfig.getDefaultJarFactory().jarFilePath;   
            nextElem2.setText(filePath);
            nextElem.addContent(nextElem2);
            
            if (licasConfig.getDefaultJarFactory().factoryClass != null)
            {
                nextElem2 = XMLFactory.getInstance().createElement(Const.CLASSNAME);
                className = licasConfig.getDefaultJarFactory().factoryClass;   
                nextElem2.setText(className);
                nextElem.addContent(nextElem2);
            }
            
            nextElem2 = XMLFactory.getInstance().createElement(Const.INCLUDE);
            nextElem2.setText(Boolean.toString(licasConfig.getDefaultJarFactory().start));
            nextElem.addContent(nextElem2);
        }
        
        nextElem = XMLFactory.getInstance().createElement(Const.MODULES);       
        rootElem.addContent(nextElem);

        modulesList = licasConfig.getModuleKeys().iterator();
        while (modulesList.hasNext())
        {
            moduleName = (String)modulesList.next();
            moduleInfo = (ModuleInfo)licasConfig.getModuleInfo(moduleName);           
            nextElem2 = moduleParser.serialize(moduleInfo);
            nextElem.addContent(nextElem2);
        }
        
        defaultServices = licasConfig.getAllServiceInfo();
        if ((defaultServices != null) && !defaultServices.isEmpty())
        {
            nextElem = XMLFactory.getInstance().createElement(ServiceConst.DEFAULTSERVICES);       
            rootElem.addContent(nextElem);

            typesList = defaultServices.keySet().iterator();
            while (typesList.hasNext())
            {
                serviceType = (String)typesList.next();
                serviceInfo = (ServiceModuleInfo)defaultServices.get(serviceType);                
                moduleName = serviceInfo.moduleName;
                if (moduleName == null) 
                {
                    serviceInfo.moduleName = ServiceConst.SERVICEFACTORY;
                }

                nextElem2 = sModuleParser.serialize(serviceInfo);
                nextElem.addContent(nextElem2);
            }
        }

        nextElem = XMLFactory.getInstance().createElement(ServiceConst.GUIHANDLER);       
        rootElem.addContent(nextElem);

        allInfo = licasConfig.getAllInfo(ServiceConst.GUI);
        typesList = allInfo.keySet().iterator();
        while (typesList.hasNext())
        {
            serviceType = (String)typesList.next();
            factoryInfo = (FactoryInfo)allInfo.get(serviceType);
            
            moduleName = factoryInfo.moduleName;
            if (moduleName == null) moduleName = ServiceConst.SERVICEFACTORY;
            
            nextElem2 = XMLFactory.getInstance().createElement(Const.SERVICETYPE);
            nextElem2.setAttribute(Const.NAME, serviceType);         
            nextElem2.setAttribute(Const.MODULE, moduleName);
            nextElem.addContent(nextElem2);
            
            nextElem3 = XMLFactory.getInstance().createElement(ServiceConst.GUICLASSNAME);
            nextElem3.setText(factoryInfo.className);
            nextElem2.addContent(nextElem3);
            
            if (factoryInfo.hasFilePath())
            {
                nextElem3 = XMLFactory.getInstance().createElement(ServiceConst.FILE);
                nextElem2.addContent(nextElem3);
                for (i = 0; i < factoryInfo.filePath.size(); i++)
                {
                    nextElem4 = XMLFactory.getInstance().createElement(ServiceConst.FILE);
                    nextElem4.setText((String)factoryInfo.filePath.get(i));
                    nextElem3.addContent(nextElem4);                       
                }
            }
        }
        
        nextElem = XMLFactory.getInstance().createElement(ServiceConst.FUNCTIONHANDLER);       
        rootElem.addContent(nextElem);

        functionTypes = licasConfig.getAllInfoFunctions().iterator();
        while (functionTypes.hasNext())
        {
            functionType = (String)functionTypes.next();
            if (!functionType.equals(ServiceConst.GUI))
            {
                nextElem2 = XMLFactory.getInstance().createElement(ServiceConst.FUNCTIONTYPE);  
                nextElem2.setAttribute(Const.NAME, functionType);
                nextElem.addContent(nextElem2);

                allInfo = licasConfig.getAllInfo(functionType);            
                typesList = allInfo.keySet().iterator();
                while (typesList.hasNext())
                {
                    serviceType = (String)typesList.next();
                    factoryInfo = (FactoryInfo)allInfo.get(serviceType);
                    moduleName = factoryInfo.moduleName;
                    if (moduleName == null) moduleName = ServiceConst.SERVICEFACTORY;

                    nextElem3 = XMLFactory.getInstance().createElement(Const.SERVICETYPE);
                    nextElem3.setAttribute(Const.NAME, serviceType);         
                    nextElem3.setAttribute(Const.MODULE, moduleName);
                    nextElem2.addContent(nextElem3);

                    nextElem4 = XMLFactory.getInstance().createElement(Const.CLASSNAME);
                    nextElem4.setText(LicasConfig.checkClassName(factoryInfo.className));
                    nextElem3.addContent(nextElem4);
                    
                    if (factoryInfo.serviceCategory != null)
                    {
                        nextElem4 = XMLFactory.getInstance().createElement(Const.SERVICECATEGORY);
                        nextElem4.setText(factoryInfo.serviceCategory);
                        nextElem3.addContent(nextElem4);
                    }

                    nextElem4 = XMLFactory.getInstance().createElement(ServiceConst.FILES);
                    nextElem3.addContent(nextElem4);                  
                    for (j = 0; j < factoryInfo.filePath.size(); j++)
                    {
                        nextElem5 = XMLFactory.getInstance().createElement(ServiceConst.FILE);
                        nextElem5.setText((String)factoryInfo.filePath.get(j));
                        nextElem4.addContent(nextElem5);                       
                    }
                    
                    if ((factoryInfo.description != null) && !factoryInfo.description.equals(""))
                    {
                        nextElem4 = XMLFactory.getInstance().createElement(Const.DESCRIPTION);
                        nextElem4.setText(factoryInfo.description);
                        nextElem3.addContent(nextElem4);
                    }
                }
            }
        }
        
        swManager = SecurityWebManager.getInstance();
        if (swManager != null)
        {
            swParser = new SecurityManagerParser();
            rootElem.addContent(swParser.serialize(swManager));
        }

        return rootElem;
    }

    /**
     * Write the gui config model to a file.
     * @param licasConfig the licas configuration to write.
     * @throws java.lang.Exception any error.
     */
    public void writeToFile(LicasConfig licasConfig) throws Exception
    {
        String filePath;                    //file path
        
        filePath = ServiceConst.CONFIGFILE;
        writeToFile(licasConfig, filePath);
    }
    
    /**
     * Write the gui config model to a file.
     * @param licasConfig the licas configuration to write.
     * @param filePath the path to the file to parse.
     * @throws java.lang.Exception any error.
     */
    public void writeToFile(LicasConfig licasConfig, String filePath) throws Exception
    {
        int index;                                          //index
        String dictStr;                                     //info as string
        String oldFilePath;                                 //old file path
        String bkupFilePath;                                //backup file path
        File configFile;                                    //config file
        File bkupFile;                                      //backup file
        Element rootElem;                                   //root element
        FileOutputStream writer;                            //file writer

        try
        {
            //first check and delete from old location
            oldFilePath = (ServiceConst.LICASHOME  + Const.DIRSEP + "licas_config.xml");
            if (new File(oldFilePath).exists()) 
            {
                new File(oldFilePath).delete();
            }
            oldFilePath = (ServiceConst.LICASHOME  + Const.DIRSEP + "licas_config.bkup");
            if (new File(oldFilePath).exists()) 
            {
                new File(oldFilePath).delete();
            }
        
            //create backup of existing file before re-writing
            configFile = new File(filePath);
            bkupFilePath = filePath;
            index = bkupFilePath.lastIndexOf(".");
            if (index > 0) bkupFilePath = bkupFilePath.substring(0, index);
            bkupFilePath += ".bkup";
            bkupFile = new File(bkupFilePath);
            
            if (configFile.exists())
            {
                if (!bkupFile.exists()) bkupFile.createNewFile();
                FileLoader.copyStream(configFile, bkupFile);
            }
            
            //serialize contents and write to the file
            rootElem = serialize(licasConfig);
            dictStr = XmlHandler.xmlToFormattedString(rootElem);
            dictStr = (Const.XMLHEADER + "\n" + dictStr);
            writer = new FileOutputStream(filePath);
            writer.write(dictStr.getBytes());
            writer.close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    
    /**
     * Parse an XML file back into the gui config model.
     * @return the parsed config model.
     * @throws java.lang.Exception any error.
     */
    public LicasConfig parseFromFile() throws Exception
    {
        String filePath;                    //file path
        
        filePath = ServiceConst.CONFIGFILE;
        if (!(new File(filePath).exists()))
        {
            filePath = (ServiceConst.LICASHOME + Const.DIRSEP + "licas_config.xml");
        }
        
        return parseFromFile(filePath);
    }
    
    /**
     * Parse an XML file back into the gui config model.
     * @param filePath the path to the file to parse.
     * @return the parsed config model.
     * @throws java.lang.Exception any error.
     */
    public LicasConfig parseFromFile(String filePath) throws Exception
    {
        LicasConfig licasConfig;                        //licas config
        Element rootElem;                               //root element
        
        licasConfig = new LicasConfig();
        try
        {
            if (new File(filePath).exists())
            {
                rootElem = XmlHandler.elementFromStream(new FileInputStream(filePath));
                licasConfig = parse(rootElem);
            }
        }
        catch (Exception ex)
        {}

        return licasConfig;
    }
    
    /**
     * Parse the XML element back into the appropriate Object.
     * @param toParse the element to parse.
     * @return the parsed gui classname lists.
     * @throws java.lang.Exception any error.
     */
    public LicasConfig parse(Element toParse) throws Exception
    {
        int i, j, k, l, m;
        String serviceType;                         //service type
        String filePath;                            //file path
        String className;                           //class name
        String moduleName;                          //module name
        String functionType;                        //function type
        String nextValue;                           //next value
        ServiceModuleInfo serviceInfo;              //service info
        LicasConfig licasConfig;                    //config info
        ServerConfig serverConfig;                  //server config
        ModuleInfo moduleInfo;                      //module info
        FactoryInfo factoryInfo;                    //factory info
        ServerConfigParser serverParser;            //server config parser
        ServiceModuleInfoParser sModuleParser;      //service module parser
        ModuleInfoParser moduleParser;              //module parser
        SecurityManagerParser swParser;             //security manager parser
        Node nextNode;                              //next node
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Element nextElem3;                          //next element
        Element nextElem4;                          //next element
        Element nextElem5;                          //next element
        Vector elemList;                            //element list
        Vector elemList2;                           //element list
        Vector elemList3;                           //element list
        Vector elemList4;                           //element list
        Vector elemList5;                           //element list
       
        licasConfig = new LicasConfig();
        serverParser = new ServerConfigParser();
        sModuleParser = new ServiceModuleInfoParser();
        moduleParser = new ModuleInfoParser();
        
        rootElem = toParse;
        if (rootElem.getName().equals(ServiceConst.LICASCONFIG))
        {
            elemList = rootElem.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(ServiceConst.SERVERCONFIG))
                    {
                        serverConfig = serverParser.parse(nextElem);
                        licasConfig.setServerConfig(serverConfig);
                    }
                    else if (nextElem.getName().equals(ServiceConst.SERVERGUI))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equals(Const.SCIENTIFIC))
                                {
                                    licasConfig.setScientific(true);
                                }
                                else if (nextElem2.getName().equals(Const.ALLOWEXTERNALJARS))
                                {
                                    nextValue = nextElem2.getText();
                                    licasConfig.setExternalJars(Boolean.parseBoolean(nextValue));
                                }
                                else if (nextElem2.getName().equals(Const.TIMEOUT))
                                {
                                    licasConfig.setTimeout(Integer.parseInt(nextElem2.getText()));
                                }
                                else if (nextElem2.getName().equals(Const.HORIZONTALGAP))
                                {
                                    licasConfig.setHorizGapFactor(Integer.parseInt(nextElem2.getText()));
                                }
                                else if (nextElem2.getName().equals(Const.VERTICALGAP))
                                {
                                    licasConfig.setVertGapFactor(Integer.parseInt(nextElem2.getText()));
                                }
                                else if (nextElem2.getName().equals(Const.NETWORKDEPTH))
                                {
                                    licasConfig.setMaxNetworkDepth(Integer.parseInt(nextElem2.getText()));
                                }
                                else if (nextElem2.getName().equals(Const.MAXNODES))
                                {
                                    licasConfig.setMaxNodes(Integer.parseInt(nextElem2.getText()));
                                }
                                else if (nextElem2.getName().equals(Const.REDRAWDELAY))
                                {
                                    licasConfig.setRedrawDelay(Integer.parseInt(nextElem2.getText()));
                                }
                            }
                        }
                    }
                    if (nextElem.getName().equals(Const.SERVER))
                    {
                        serverConfig = serverParser.parse(nextElem);
                        licasConfig.setServerConfig(serverConfig);
                        
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equals(Const.TIMEOUT))
                                {
                                    licasConfig.setTimeout(Integer.parseInt(nextElem2.getText()));
                                }
                                else if (nextElem2.getName().equals(Const.HORIZONTALGAP))
                                {
                                    licasConfig.setHorizGapFactor(Integer.parseInt(nextElem2.getText()));
                                }
                                else if (nextElem2.getName().equals(Const.VERTICALGAP))
                                {
                                    licasConfig.setVertGapFactor(Integer.parseInt(nextElem2.getText()));
                                }
                                else if (nextElem2.getName().equals(Const.NETWORKDEPTH))
                                {
                                    licasConfig.setMaxNetworkDepth(Integer.parseInt(nextElem2.getText()));
                                }
                                else if (nextElem2.getName().equals(Const.MAXNODES))
                                {
                                    licasConfig.setMaxNodes(Integer.parseInt(nextElem2.getText()));
                                }
                                else if (nextElem2.getName().equals(Const.REDRAWDELAY))
                                {
                                    licasConfig.setRedrawDelay(Integer.parseInt(nextElem2.getText()));
                                }
                            }
                        }
                    }
                    else if (nextElem.getName().equals(ServiceConst.DEFAULTSERVICEFACTORY))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equals(ServiceConst.FILE))
                                {
                                    filePath = nextElem2.getText();
                                    licasConfig.getDefaultServiceFactory().jarFilePath = filePath;
                                }
                                else if (nextElem2.getName().equals(Const.CLASSNAME))
                                {
                                    className = LicasConfig.checkClassName(nextElem2.getText());
                                    licasConfig.getDefaultServiceFactory().factoryClass = className;
                                }
                            }
                        }
                    }
                    else if (nextElem.getName().equals(ServiceConst.DEFAULTJARFACTORY))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equals(ServiceConst.FILE))
                                {
                                    filePath = nextElem2.getText();
                                    licasConfig.getDefaultJarFactory().jarFilePath = filePath;
                                }
                                else if (nextElem2.getName().equals(Const.CLASSNAME))
                                {
                                    className = LicasConfig.checkClassName(nextElem2.getText());
                                    licasConfig.getDefaultJarFactory().factoryClass = className;
                                }
                                else if (nextElem2.getName().equals(Const.INCLUDE))
                                {
                                    licasConfig.getDefaultJarFactory().start = 
                                        Boolean.valueOf(nextElem2.getText()).booleanValue();
                                }
                            }
                        }
                    }
                    else if (nextElem.getName().equals(Const.MODULES))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            moduleInfo = null;
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equals(Const.MODULE))
                                {
                                    moduleInfo = moduleParser.parse(nextElem2);
                                    if (moduleInfo != null) licasConfig.addModuleInfo(moduleInfo);
                                }
                            }
                        }
                    }
                    else if (nextElem.getName().equals(ServiceConst.DEFAULTSERVICES))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equals(Const.SERVICETYPE))
                                {
                                    serviceInfo = sModuleParser.parse(nextElem2);
                                    moduleName = serviceInfo.moduleName;
                                    if ((moduleName == null) || moduleName.equals("")) 
                                    {
                                        serviceInfo.moduleName = ServiceConst.SERVICEFACTORY;
                                    }
                                    
                                    moduleInfo = licasConfig.getModuleInfo(moduleName);
                                    if ((moduleInfo != null) && moduleInfo.include)
                                    {
                                        licasConfig.addServiceInfo(serviceInfo);
                                    }
                                }
                            }
                        }
                    }
                    else if (nextElem.getName().equals(ServiceConst.GUIHANDLER))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            factoryInfo = null;
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equals(Const.SERVICETYPE))
                                {
                                    factoryInfo = new FactoryInfo();
                                    serviceType = nextElem2.getAttributeValue(Const.NAME);
                                    factoryInfo.serviceType = serviceType;
                                    factoryInfo.serviceCategory = ServiceConst.ALLCATEGORIES;
                                    
                                    moduleName = nextElem2.getAttributeValue(Const.MODULE);
                                    if ((moduleName == null) || moduleName.equals("")) moduleName = ServiceConst.SERVICEFACTORY;
                                    factoryInfo.moduleName = moduleName;
                                    
                                    elemList3 = nextElem2.getChildren();
                                    for (k = 0; k < elemList3.size(); k++)
                                    {
                                        nextNode = (Node)elemList3.get(k);
                                        if (nextNode instanceof Element)
                                        {
                                            nextElem3 = (Element)nextNode;
                                            if (nextElem3.getName().equals(ServiceConst.GUICLASSNAME))
                                            {
                                                className = nextElem3.getText().trim();
                                                factoryInfo.className = className;
                                            }
                                            else if (nextElem3.getName().equals(ServiceConst.FILES) ||
                                                    (nextElem3.getName().equals(ServiceConst.FILE) && nextElem3.hasChildren()))
                                            {
                                                elemList4 = nextElem3.getChildren();
                                                for (l = 0; l < elemList4.size(); l++)
                                                {
                                                    nextNode = (Node)elemList4.get(l);
                                                    if (nextNode instanceof Element)
                                                    {
                                                        nextElem4 = (Element)nextNode;
                                                        if (nextElem4.getName().equals(ServiceConst.FILE))
                                                        {
                                                            className = nextElem4.getText().trim();
                                                            factoryInfo.filePath.add(className);
                                                        }
                                                    }
                                                }
                                            }
                                            else if (nextElem3.getName().equals(ServiceConst.FILE))
                                            {
                                                className = nextElem3.getText().trim();
                                                factoryInfo.filePath.add(className);
                                            }
                                            else if (nextElem3.getName().equals(Const.DESCRIPTION))
                                            {
                                                factoryInfo.description = nextElem3.getText().trim();
                                            }
                                        }
                                    }
                                    
                                    if (factoryInfo != null) licasConfig.addInfo(ServiceConst.GUI, factoryInfo);
                                }
                            }
                        }
                    }
                    else if (nextElem.getName().equals(ServiceConst.FUNCTIONHANDLER))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                functionType = nextElem2.getAttributeValue(Const.NAME);
                                
                                elemList3 = nextElem2.getChildren();
                                for (k = 0; k < elemList3.size(); k++)
                                {
                                    factoryInfo = null;
                                    nextNode = (Node)elemList3.get(k);
                                    if (nextNode instanceof Element)
                                    {
                                        nextElem3 = (Element)nextNode;
                                        if (nextElem3.getName().equals(Const.SERVICETYPE))
                                        {
                                            factoryInfo = new FactoryInfo();
                                            serviceType = nextElem3.getAttributeValue(Const.NAME);
                                            factoryInfo.serviceType = serviceType;
                                            factoryInfo.serviceCategory = ServiceConst.ALLCATEGORIES;
        
                                            moduleName = nextElem3.getAttributeValue(Const.MODULE);
                                            if ((moduleName == null) || moduleName.equals("")) moduleName = ServiceConst.SERVICEFACTORY;
                                            factoryInfo.moduleName = moduleName;

                                            elemList4 = nextElem3.getChildren();
                                            for (l = 0; l < elemList4.size(); l++)
                                            {
                                                nextNode = (Node)elemList4.get(l);
                                                if (nextNode instanceof Element)
                                                {
                                                    nextElem4 = (Element)nextNode;
                                                    if (nextElem4.getName().equals(Const.CLASSNAME))
                                                    {
                                                        className = nextElem4.getText().trim();
                                                        factoryInfo.className = LicasConfig.checkClassName(className);
                                                    }
                                                    else if (nextElem4.getName().equals(Const.SERVICECATEGORY))
                                                    {
                                                        factoryInfo.serviceCategory = nextElem4.getText().trim();
                                                    }
                                                    else if (nextElem4.getName().equals(ServiceConst.FILE))
                                                    {
                                                        className = nextElem4.getText().trim();
                                                        factoryInfo.filePath.add(className);
                                                    }
                                                    else if (nextElem4.getName().equals(ServiceConst.FILES))
                                                    {
                                                        elemList5 = nextElem4.getChildren();
                                                        for (m = 0; m < elemList5.size(); m++)
                                                        {
                                                            nextNode = (Node)elemList5.get(m);
                                                            if (nextNode instanceof Element)
                                                            {
                                                                nextElem5 = (Element)nextNode;
                                                                if (nextElem5.getName().equals(ServiceConst.FILE))
                                                                {
                                                                    className = nextElem5.getText().trim();
                                                                    factoryInfo.filePath.add(className);
                                                                }
                                                            }
                                                        }
                                                    }
                                                    else if (nextElem4.getName().equals(Const.DESCRIPTION))
                                                    {
                                                        factoryInfo.description = nextElem4.getText().trim();
                                                    }
                                                }
                                            }

                                            if (factoryInfo != null) licasConfig.addInfo(functionType, factoryInfo);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else if (nextElem.getName().equals(MetaConst.SECURITYMANAGER))
                    {
                        swParser = new SecurityManagerParser();
                        swParser.parse(nextElem);
                    }
                }
            }
        }

        return licasConfig;
    }
}
