/*
 * AutonomicManagerParser.java
 *
 * Created on 30 January 2011
 *
 * Version 1.0.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers.admin;


import org.licas.autonomic.AutonomicManager;
import org.licas.server.LocalServer;
import org.licas.util.AiConst;
import org.licas.util.Const;
import org.licas.util.FileObject;
import org.licas.util.MetaConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;

import java.util.ArrayList;
import java.util.Vector;


/**
 * This class can be used to parse the autonomic manager's xml config description
 * to add the appropriate modules to an {@link AutonomicManager}. It tries to create any of
 * the control loop modules and add the policy file if available. It adds these to 
 * the autonomic manager object that is also passed as a parameter.
 * @author Kieran Greer
 */
public class AutonomicManagerParser
{
    /**
     * Create a new instance of AutonomicManagerParser.
     */
    public AutonomicManagerParser()
    {}

    
    /**
     * Parse the XML description to determine the admin specification.
     * @param autoMan the autonomic manager object.
     * @param adminXml the XML description to parse.
     * @throws java.lang.Exception any error.
     */
    public void parse(AutonomicManager autoMan, Element adminXml) throws Exception
    {
        int i, j;
        String moduleType;                              //module type
        String className;                               //module class name
        String jarFile;                                 //module jar file
        ArrayList jarFiles;                                //all jar files
        Element policy;                                 //policy document
        Node nextNode;                                  //next node
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        Vector elemList;                                //element list
        Vector elemList2;                               //element list
                
        try
        {
            if ((adminXml != null) && adminXml.getName().equals(AiConst.AUTONOMICMANAGER))
            {
                elemList = adminXml.getChildren();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);
                    if (nextNode instanceof Element)
                    {
                        className = null;
                        policy = null;
                        jarFiles = new ArrayList();
                        nextElem = (Element)nextNode;

                        if (nextElem.getName().equals(AiConst.MONITOR) ||
                            nextElem.getName().equals(AiConst.ANALYZE) ||
                            nextElem.getName().equals(AiConst.PLAN) ||
                            nextElem.getName().equals(AiConst.EXECUTE))
                        {
                            moduleType = nextElem.getName();
                            elemList2 = nextElem.getChildren();

                            for (j = 0; j < elemList2.size(); j++)
                            {
                                nextNode = (Node)elemList2.get(j);
                                if (nextNode instanceof Element)
                                {
                                    nextElem2 = (Element)nextNode;
                                    if (nextElem2.getName().equals(MetaConst.POLICY))
                                    {
                                        policy = (Element)nextElem2.clone();
                                    }
                                    else if (nextElem2.getName().equals(Const.CLASSNAME))
                                    {
                                        className = nextElem2.getText();
                                    }
                                    else if (nextElem2.getName().equals(Const.JARFILEXML))
                                    {
                                        jarFile = nextElem2.getText();
                                        jarFiles = FileObject.getAllJarFilePaths(jarFile, LocalServer.getServerURL());
                                    }
                                }
                            }
                            
                            autoMan.addManagerModule(moduleType, className, new ArrayList(), jarFiles);
                            if (policy != null) autoMan.addPolicy(moduleType, policy);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            autoMan.setConfigured();
        }
    }
}
