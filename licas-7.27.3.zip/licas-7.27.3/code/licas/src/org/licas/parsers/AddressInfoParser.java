/*
 * AddressInfoParser.java
 *
 * Created on 24 September 2014.
 *
 * Version 1.2.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.parsers;


import org.ai_heuristic.def.ParserDef;
import org.licas.service.model.AddressInfo;
import org.licas.util.Const;
import org.licas.util.ServiceConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.Vector;


/**
 * This can parse an {@link AddressInfo} that contains a single service address with related info.
 * @author Kieran Greer
 */
public class AddressInfoParser implements ParserDef
{
    /** The original tag names*/
    private static final String SERVICEPASSWORD = "Service_Password";
    private static final String SERVICEKEY = "Service_Admin_Key";
    private static final String SERVERPASSWORD = "Server_Password";
    private static final String SERVERIP = "Server_IP";
    
    
    /** 
     * Create a new instance of AddressInfoParser.
     */
    public AddressInfoParser()
    {}
    
    /**
     * Serialize the object into an XML element.
     * @param toSerialize the address info object to serialize.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        String nextValue;                           //next value
        AddressInfo entry;                          //address book entry
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        
        entry = (AddressInfo)toSerialize;
        rootElem = XMLFactory.getInstance().createElement(ServiceConst.ADDRESSINFO);        
        rootElem.setAttribute(Const.NAME, entry.serviceID);
        
        nextElem = XMLFactory.getInstance().createElement(Const.SERVICEPASSWORD);
        nextElem.setText(entry.servicePassword);
        rootElem.addContent(nextElem);

        nextElem = XMLFactory.getInstance().createElement(Const.SERVICEKEY);
        nextElem.setText(entry.serviceAdminKey);
        rootElem.addContent(nextElem);

        nextElem = XMLFactory.getInstance().createElement(Const.SERVERADDRESS);
        nextElem.setText(entry.serverURL);
        rootElem.addContent(nextElem);

        nextElem = XMLFactory.getInstance().createElement(Const.SERVERPASSWORD);
        nextElem.setText(entry.serverPassword);
        rootElem.addContent(nextElem);
        
        if ((entry.imagePath != null) && !entry.imagePath.equals(""))
        {
            nextElem = XMLFactory.getInstance().createElement(Const.ICON);
            nextElem.setText(entry.imagePath);
            rootElem.addContent(nextElem);
        }
        
        if (entry.description != null)
        {
            nextValue = entry.description.trim();
            if (!nextValue.equals(""))
            {
                nextElem = XMLFactory.getInstance().createElement(Const.DESCRIPTION);
                nextElem.setText(nextValue);
                rootElem.addContent(nextElem);
            }
        }

        return rootElem;
    }
    
    /**
     * Parse the XML element back into the appropriate Object.
     * @param toParse the element to parse.
     * @return the parsed address lists.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        int i;
        String userID;                              //user ID
        String imagePath;                           //image path
        String description;                         //address description
        String nextValue;                           //next value
        AddressInfo entry;                          //address book entry
        Node nextNode;                              //next node
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        Vector elemList;                            //element list
        
        entry = null;
        rootElem = toParse;

        if (rootElem.getName().equals(ServiceConst.ADDRESSINFO) ||
            rootElem.getName().equals(ServiceConst.NEXTADDRESS))
        {
            entry = new AddressInfo();
            userID = rootElem.getAttributeValue(Const.NAME);
            entry.serviceID = userID;
                        
            elemList = rootElem.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(Const.SERVICEPASSWORD) ||
                        nextElem.getName().equals(SERVICEPASSWORD))
                    {
                        nextValue = nextElem.getText();
                        if (nextValue != null)
                        {
                            entry.servicePassword = nextValue.trim();
                        }
                    }
                    else if (nextElem.getName().equals(Const.SERVICEKEY) ||
                            nextElem.getName().equals(SERVICEKEY))
                    {
                        nextValue = nextElem.getText();
                        if (nextValue != null)
                        {
                            entry.serviceAdminKey = nextValue.trim();
                        }
                    }
                    else if (nextElem.getName().equals(Const.SERVERADDRESS) ||
                            nextElem.getName().equals(SERVERIP))
                    {
                        nextValue = nextElem.getText();
                        if (nextValue != null)
                        {
                            entry.serverURL = nextValue.trim();
                        }
                    }
                    else if (nextElem.getName().equals(Const.SERVERPASSWORD) ||
                            nextElem.getName().equals(SERVERPASSWORD))
                    {
                        nextValue = nextElem.getText();
                        if (nextValue != null)
                        {
                            entry.serverPassword = nextValue.trim();
                        }    
                    }
                    else if (nextElem.getName().equals(Const.ICON))
                    {
                        imagePath = nextElem.getText();
                        if ((imagePath != null) && !imagePath.trim().equals(""))
                        {
                            entry.imagePath = imagePath.trim();
                        }
                    }
                    else if (nextElem.getName().equals(Const.DESCRIPTION))
                    {
                        description = nextElem.getText();
                        if ((description != null) && !description.trim().equals(""))
                        {
                            entry.description = description.trim();
                        }
                    }
                }
            }
        }

        return entry;
    }
}
