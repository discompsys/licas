/*
 * ServiceMetaParser.java
 *
 * Created on 5 December 2008
 *
 * Version 1.8
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers.admin;


import org.ai_heuristic.def.ParserDef;
import org.licas.AdminInfo;
import org.licas.call.Handle;
import org.licas.meta.ServiceMeta;
import org.licas.service.model.KeywordHandler;
import org.licas.util.AiConst;
import org.licas.util.Const;
import org.licas.util.MetaConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.util.ArrayList;
import java.util.Vector;


/**
 * This provides methods to parse a service and return only its {@link ServiceMeta} description.
 * @author Kieran Greer
 */
public class ServiceMetaParser implements ParserDef
{
    /**
     * Create a new instance of ServiceMetaParser.
     */
    public ServiceMetaParser()
    {}
    
    /**
     * Serialise the object of type ServiceMeta into XML. Automatically serializes the 
     * permanent links.
     * @param toSerialize the service meta object of type ServiceMeta.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        return serialize(toSerialize, true);
    }
    
    /**
     * Serialise the object of type ServiceMeta into XML.
     * @param toSerialize the service meta object of type ServiceMeta.
     * @param permLinks if true serialize the permanent inks as well (link/association).
     * The dynamic links need to be serialized separately.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize, boolean permLinks) throws Exception
    {
        int i;
        String serviceUuid;                             //service uuid
        ServiceMeta serviceMeta;                        //service meta object
        ArrayList jarFile;                                 //jar file list
        ArrayList constructorMeta;                         //constructors meta
        ArrayList methodMeta;                              //methods meta
        Element rootElem;                               //root element
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        
        try
        {
            serviceMeta = (ServiceMeta)toSerialize;            
            rootElem = XMLFactory.getInstance().createElement(MetaConst.SERVICEMETA);
            
            if (serviceMeta.uuid != null)
            {
                try
                {
                    serviceUuid = Handle.getLastServiceHandle(XmlHandler.stringToElement(serviceMeta.uuid));
                }
                catch (Exception ex)
                {
                    serviceUuid = serviceMeta.uuid;
                }
                
                rootElem.setAttribute(Const.UUID, serviceUuid);
            }

            if (serviceMeta.serviceType != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.SERVICETYPE);
                nextElem.setText(serviceMeta.serviceType);
                rootElem.addContent(nextElem);
            }
            
            if (serviceMeta.serviceGrade != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.SERVICEGRADE);
                nextElem.setText(serviceMeta.serviceGrade);
                rootElem.addContent(nextElem);
            }
            
            if (serviceMeta.serviceCategory != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.SERVICECATEGORY);
                nextElem.setText(serviceMeta.serviceCategory);
                rootElem.addContent(nextElem);
            }
            
            if (serviceMeta.description != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.DESCRIPTION);
                nextElem.addContent((Element)serviceMeta.description.clone());
                rootElem.addContent(nextElem);
            }

            if (serviceMeta.serviceClass != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.CLASSNAME);
                nextElem.setText(serviceMeta.serviceClass);
                rootElem.addContent(nextElem);
            }

            if (serviceMeta.serviceUri != null)
            {
                rootElem.addContent((Element)serviceMeta.serviceUri.clone());
            }

            jarFile = serviceMeta.jarFile;
            if ((jarFile != null) && (jarFile.size() > 0))
            {
                nextElem = XMLFactory.getInstance().createElement(Const.JARFILESXML);
                rootElem.addContent(nextElem);
                
                for (i = 0; i < jarFile.size(); i++)
                {
                    nextElem2 = XMLFactory.getInstance().createElement(Const.JARFILEXML);
                    nextElem2.setText((String)jarFile.get(i));
                    nextElem.addContent(nextElem2);
                }
            }
            
            nextElem = serviceMeta.getKeywordXml();
            if (nextElem != null) rootElem.addContent(nextElem);

            constructorMeta = serviceMeta.constructorMeta;
            if ((constructorMeta != null) && (constructorMeta.size() > 0))
            {
                nextElem = XMLFactory.getInstance().createElement(Const.CONSTRUCTORS);
                rootElem.addContent(nextElem);

                for (i = 0; i < constructorMeta.size(); i++)
                {
                    nextElem.addContent((Element)((Element)constructorMeta.get(i)).clone());
                }
            }

            methodMeta = serviceMeta.methodMeta;
            if ((methodMeta != null) && (methodMeta.size() > 0))
            {
                nextElem = XMLFactory.getInstance().createElement(Const.METHODS);
                rootElem.addContent(nextElem);

                for (i = 0; i < methodMeta.size(); i++)
                {
                    nextElem.addContent((Element)((Element)methodMeta.get(i)).clone());
                }
            }

            if ((serviceMeta.childServiceMeta != null) && 
                    serviceMeta.childServiceMeta.hasChildren())
            {
                rootElem.addContent((Element)serviceMeta.childServiceMeta.clone());
            }

            if (permLinks)
            {
                if ((serviceMeta.linkServiceMeta != null) && 
                        serviceMeta.linkServiceMeta.hasChildren())
                {
                    rootElem.addContent((Element)serviceMeta.linkServiceMeta.clone());
                }
                if ((serviceMeta.serviceAssociations != null) && 
                        serviceMeta.serviceAssociations.hasChildren())
                {
                    rootElem.addContent((Element)serviceMeta.serviceAssociations.clone());
                }
            }
            
            if (serviceMeta.meta != null)
            {
                rootElem.addContent((Element)serviceMeta.meta.clone());
            }

            if (serviceMeta.data != null)
            {
                rootElem.addContent((Element)serviceMeta.data.clone());
            }
            
            if (serviceMeta.instanceValues != null)
            {
                rootElem.addContent((Element)serviceMeta.instanceValues.clone());
            }
            
            if (serviceMeta.parameters != null)
            {
                rootElem.addContent((Element)serviceMeta.parameters.clone());
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return rootElem;
    }

    /**
     * Parse the XML description back into the ServiceMeta object.
     * @param toParse the XML description to parse.
     * @return the ServiceMeta object with nested meta descriptions.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        int i, j;
        String theUuid;                             //the uuid
        String theServiceType;                      //the service type
        String theServiceGrade;                     //the service grade
        String theServiceCategory;                  //the service category
        String theServiceClass;                     //the service class
        Element theServicePath;                     //the service path
        Element theDescription;                     //the description
        Element theChildServiceMeta;                //child services
        Element theLinkServiceMeta;                 //permanent linked services
        Element associationsMeta;                   //association linked services
        Element theData;                            //any value-based metadata
        Element theMeta;                            //any other metadata
        Element theInstValues;                      //any instance-value-based metadata
        Element theParameters;                      //any constructor parameters metadata
        Element thePolicy;                          //auto service policy
        ArrayList theJarFile;                          //the jar file list
        ArrayList constructors;                        //list of constructor descriptions
        ArrayList methods;                             //list of method descriptions
        ServiceMeta serviceMeta;                    //service meta object
        AdminInfo adminInfo;                        //admin info
        KeywordHandler keywordHandler;              //keyword handler
        KeywordHandlerParser keywordParser;         //keyword parser
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Vector elemList;                            //element list
        Vector elemList2;                           //element list
               
        theUuid = null;
        theServiceType = null;
        theServiceGrade = null;
        theServiceCategory = null;
        theServiceClass = null;
        theServicePath = null;
        theDescription = null;
        theChildServiceMeta = null;
        theLinkServiceMeta = null;
        associationsMeta = null;
        theData = null;
        theMeta = null;
        theInstValues = null;
        theParameters = null;
        thePolicy = null;
        theJarFile = new ArrayList();
        constructors = new ArrayList();
        methods = new ArrayList();
        adminInfo = new AdminInfo();
        keywordHandler = null;
        keywordParser = new KeywordHandlerParser();
        
        try
        {
            if (toParse != null)
            {
                theUuid = toParse.getAttributeValue(Const.UUID);
                if (theUuid == null)
                {
                    nextElem = toParse.getChild(Const.UUID);
                    if (nextElem != null)
                    {
                        theUuid = nextElem.getText();
                    }
                }
                
                if ((theUuid != null) && !theUuid.equals(""))
                {
                    elemList = (Vector)toParse.getChildren().clone();
                    for (i = 0; i < elemList.size(); i++)
                    {
                        nextNode = (Node)elemList.get(i);
                        if (nextNode instanceof Element)
                        {
                            nextElem = (Element)nextNode;
                            if (nextElem.getName().equals(Const.SERVICETYPE))
                            {
                                theServiceType = nextElem.getValue();
                            }
                            else if (nextElem.getName().equals(Const.SERVICEGRADE))
                            {
                                theServiceGrade = nextElem.getValue();
                            }
                            else if (nextElem.getName().equals(Const.SERVICECATEGORY))
                            {
                                theServiceCategory = nextElem.getValue();
                            }
                            else if (nextElem.getName().equals(Const.DESCRIPTION))
                            {
                                elemList2 = (Vector)nextElem.getChildren().clone();
                                nextNode = (Node)elemList2.get(0);

                                if (nextNode instanceof Element)
                                {
                                    theDescription = (Element)nextNode.clone();
                                }
                            }
                            else if (nextElem.getName().equals(Const.HANDLE))
                            {
                                theServicePath = (Element)nextElem.clone();
                            }
                            else if (nextElem.getName().equals(Const.CLASSNAME))
                            {
                                theServiceClass = nextElem.getValue();
                            }
                            else if (nextElem.getName().equals(Const.JARFILESXML))
                            {                              
                                elemList2 = nextElem.getChildren();
                                for (j = 0; j < elemList2.size(); j++)
                                {
                                    nextElem2 = (Element)elemList2.get(j);
                                    theJarFile.add(nextElem2.getText());
                                } 
                            }
                            else if (nextElem.getName().equals(Const.KEYWORDS))
                            {
                                keywordHandler = (KeywordHandler)keywordParser.parse(nextElem);
                            }
                            else if (nextElem.getName().equals(Const.DATA))
                            {
                                theData = (Element)nextElem.clone();
                            }
                            else if (nextElem.getName().equals(Const.OTHERMETA))
                            {
                                theMeta = (Element)nextElem.clone();
                            }
                            else if (nextElem.getName().equals(Const.INSTANCEVALUES))
                            {
                                theInstValues = (Element)nextElem.clone();
                            }
                            else if (nextElem.getName().equals(Const.PARAMETERS))
                            {
                                theParameters = (Element)nextElem.clone();
                            }
                            else if (nextElem.getName().equals(AiConst.POLICY))
                            {
                                thePolicy = (Element)nextElem.clone();
                            }
                            else if (nextElem.getName().equals(Const.CONSTRUCTORS))
                            {
                                elemList2 = (Vector)nextElem.getChildren().clone();
                                for (j = 0; j < elemList2.size(); j++)
                                {
                                    nextNode = (Node)elemList2.get(j);
                                    if (nextNode instanceof Element)
                                    {
                                        nextElem2 = (Element)nextNode;
                                        if (nextElem2.getName().equals(Const.CONSTRUCTOR))
                                        {
                                            constructors.add((Element)nextElem2.clone());
                                        }
                                    }
                                }
                            }
                            else if (nextElem.getName().equals(Const.METHODS))
                            {
                                elemList2 = (Vector)nextElem.getChildren().clone();
                                for (j = 0; j < elemList2.size(); j++)
                                {
                                    nextNode = (Node)elemList2.get(j);
                                    if (nextNode instanceof Element)
                                    {
                                        nextElem2 = (Element)nextNode;
                                        if (nextElem2.getName().equals(Const.METHOD))
                                        {
                                            methods.add((Element)nextElem2.clone());
                                        }
                                    }
                                }
                            }
                            else if (nextElem.getName().equals(MetaConst.CHILDSERVICEMETA))
                            {
                                theChildServiceMeta = (Element)nextElem.clone();
                            }
                            else if (nextElem.getName().equals(MetaConst.PERMANENTLINKSERVICEMETA))
                            {
                                theLinkServiceMeta = (Element)nextElem.clone();
                            }
                            else if (nextElem.getName().equals(MetaConst.ASSOCIATEDLINKSERVICEMETA))
                            {
                                associationsMeta = (Element)nextElem.clone();
                            }
                        }
                    }
                }
            }
            
            serviceMeta = new ServiceMeta();
            adminInfo.setDescription(theDescription);
            if (theData != null) adminInfo.getAdditional().put(Const.DATA, theData);
            if (theMeta != null) adminInfo.getAdditional().put(Const.OTHERMETA, theMeta);
            if (theInstValues != null) adminInfo.getAdditional().put(Const.INSTANCEVALUES, theInstValues);
            if (thePolicy != null) adminInfo.getAdditional().put(AiConst.POLICY, thePolicy);
            
            if ((constructors.isEmpty()) && (methods.isEmpty()))
                serviceMeta.setServiceMeta(theUuid, theServiceType, theServiceGrade, theServiceClass, 
                        theServicePath, theJarFile, adminInfo);
            else
                serviceMeta.setServiceMeta(theUuid, theServiceType, theServiceGrade, theServiceClass, 
                        theServicePath, theJarFile, constructors, methods, adminInfo);

            if (keywordHandler != null)
                serviceMeta.setKeywordHandler(keywordHandler);
            
            serviceMeta.serviceCategory = theServiceCategory;
            serviceMeta.childServiceMeta = theChildServiceMeta;
            serviceMeta.linkServiceMeta = theLinkServiceMeta;           
            serviceMeta.serviceAssociations = associationsMeta;
            serviceMeta.parameters = theParameters;
            
            return serviceMeta;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
