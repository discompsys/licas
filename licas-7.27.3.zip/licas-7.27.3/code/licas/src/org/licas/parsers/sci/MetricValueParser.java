/*
 * MetricValueParser.java
 *
 * Created on 18 February 2016
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.parsers.sci;


import org.ai_heuristic.def.ParserDef;
import org.ai_heuristic.eval.metric.MetricValue;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas.parsers.Parsers;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;


/**
 * This can be used to parse a {@link MetricValue} object to or from XML.
 * If a parser exists, the stored value can be parsed using it.
 * @author Kieran Greer
 */
public class MetricValueParser implements ParserDef
{
    /** Create a new instance of MetricValueParser */
    public MetricValueParser()
    {}

    /**
     * Serialize the object into an XML element.
     * @param toSerialize the object to serialize. Of type {@link MetricValue}.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        MetricValue metricValue;                //metric value
        Element rootElem;                       //root element
        Element nextElem;                       //next element
        
        metricValue = (MetricValue)toSerialize;
        
        rootElem = XMLFactory.getInstance().createElement(AiHeuristicConst.METRICVALUE);
        if (metricValue.getName() != null)
        {
            rootElem.setAttribute(AiHeuristicConst.NAME, metricValue.getName());
        }
        
        nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.VALUETYPE);
        nextElem.setText(metricValue.getValueType());
        rootElem.addContent(nextElem);
        nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.VALUE);
        nextElem.addContent((Element)Parsers.serializeToElement(metricValue.getValue()));
        rootElem.addContent(nextElem);
        
        return rootElem;
    }

    /**
     * Parse the XML element back into a MetricValue object.
     * @param toParse the element to parse.
     * @return the parsed Tree.
     * @throws java.lang.Exception any error.
     */
    public MetricValue parse(Element toParse) throws Exception
    {
        String name;                            //value name
        String type;                            //value type
        Object value;                           //value
        MetricValue metricValue;                //the metric value
        Element rootElem;                       //root element
        Element nextElem;                       //next element
        
        type = null;
        metricValue = null;
        rootElem = toParse;
        
        if (rootElem.getName().equals(AiHeuristicConst.METRICVALUE))
        {
            name = rootElem.getAttributeValue(AiHeuristicConst.NAME);
            nextElem = rootElem.getChild(AiHeuristicConst.VALUETYPE);
            if (nextElem != null)
            {
                type = nextElem.getText();
            }
            nextElem = rootElem.getChild(AiHeuristicConst.VALUE);
            if (nextElem != null)
            {
                value = Parsers.parse(nextElem.getElementChildAtIndex(0));
                metricValue = MetricValue.toValue(name, type, value);
            }
        }

        return metricValue;
    }
}
