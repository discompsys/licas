/*
 * BehaviourScriptParser.java
 *
 * Created on 18 June 2012
 *
 * Version 1.5
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers;


import org.licas.PasswordHandler;
import org.licas.service.spec.BehaviourScript;
import org.licas.util.Const;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.io.FileInputStream;
import java.util.Vector;


/**
 * This class can read a script file and parse it into a {@link BehaviourScript} object,
 * or serialize back into XML again.
 * @author Kieran Greer
 */
public class BehaviourScriptParser extends ServiceSpecParser
{
    /** 
     * Create a new instance of BehaviourScriptParser.
     * @param thePasswordHandler for storing passwords.
     */
    public BehaviourScriptParser(PasswordHandler thePasswordHandler)
    {
        super(thePasswordHandler);
    }
    
    
    /**
     * Serialize the test script into XML.
     * @param testScript the test script to serialize.
     * @param forDisplay if true, create output for display purposes only.
     * @return the script in XML format.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(BehaviourScript testScript, boolean forDisplay) throws Exception
    {
        Element nextElem;                               //next element
        Element scriptElem;                             //the script element
        
        if (testScript != null)
        {
            scriptElem = super.serialize(testScript, forDisplay);
            scriptElem.setAttribute(Const.TYPE, Const.BEHAVIOURSCRIPT);
            
            nextElem = XMLFactory.getInstance().createElement(Const.MINVALUE);                   
            nextElem.setText(String.valueOf(testScript.minValue));
            scriptElem.addContent(nextElem);
            
            nextElem = XMLFactory.getInstance().createElement(Const.MAXVALUE);                   
            nextElem.setText(String.valueOf(testScript.maxValue));
            scriptElem.addContent(nextElem);

            return scriptElem;
        }
        
        return null;
    }
    
    /**
     * Parse the file path to create a test script for creating the test scenario from.
     * @param filePath the script file path.
     * @return the created test script object.
     * @throws java.lang.Exception any error.
     */
    public BehaviourScript parseFile(String filePath) throws Exception
    {
        Element scriptXml;                                  //document
        FileInputStream reader;                             //reader
        
        reader = new FileInputStream(filePath);
        scriptXml = XmlHandler.elementFromStream(reader);        
        return parse(scriptXml);
    }
    
    
    /**
     * Parse the file path to create a test script for creating the test scenario from.
     * @param scriptXml the script document in XML format.
     * @return the created test script object.
     * @throws java.lang.Exception any error.
     */
    public BehaviourScript parse(Element scriptXml) throws Exception
    {
        int i;
        Vector elemList;                                //element list
        Node nextNode;                                  //next node
        Element nextElem;                               //next element
        BehaviourScript testScript;                     //the test script
        
        
        testScript = new BehaviourScript(passwordHandler);
        if (scriptXml.getName().equals(Const.TESTSCRIPT))
        {
            super.parse(scriptXml, testScript);
            testScript.scriptType = scriptXml.getAttributeValue(Const.TYPE);
        
            elemList = scriptXml.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(Const.MINVALUE))
                    {
                        try {
                            testScript.minValue = Integer.parseInt(nextElem.getText().trim());
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(Const.MAXVALUE))
                    {
                        try {
                            testScript.maxValue = Integer.parseInt(nextElem.getText().trim());
                        } catch (Exception ex2) {}
                    }
                }
            }
        }
        
        return testScript;
    }
}
