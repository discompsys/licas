/*
 * KD_TreeNodeParser.java
 *
 * Created on 19 February 2016
 *
 * Version 1.0.1
 
 * Copyright (C) Kieran Greer
 */

package org.licas.parsers.sci;


import org.ai_heuristic.def.EvaluateMathDef;
import org.ai_heuristic.functs.FunctionMetric;
import org.ai_heuristic.tree.KD_TreeNode;
import org.ai_heuristic.model.NodeStats;
import org.ai_heuristic.tree.TreeNode;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas.util.classloader.LoadObject;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;
import java.util.Vector;


/**
 * This can be used to parse a {@link KD_TreeNode} node in a tree structure, although the root tree node
 * is parsed using {@link KD_TreeParser}.
 * Note that only the structure is parsed. Any stored value is cast only to a String.
 * @author Kieran Greer
 */
public class KD_TreeNodeParser extends TreeNodeParser
{
    /** Create a new instance of KD_TreeNodeParser */
    public KD_TreeNodeParser()
    {}

    /**
     * Serialize the object into an XML element.
     * @param toSerialize the object to serialize. Of type {@link TreeNode}.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        return serialize((KD_TreeNode)toSerialize);
    }
    
    /**
     * Serialize the object into an XML element.
     * @param treeNode the node to serialize.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(KD_TreeNode treeNode) throws Exception
    {
        NodeStatsParser statsParser;                //node stats parser
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        
        statsParser = new NodeStatsParser();
        
        rootElem = super.serialize(treeNode);
        rootElem.setName(AiHeuristicConst.KDTREENODE);
        
        nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.BS);
        nextElem.setText(String.valueOf(treeNode.getBucketSize()));
        rootElem.addContent(nextElem);
            
        if (treeNode.getMetricEvaluatorClass() != null)
        {
            nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.EVALUATOR);
            nextElem.setText(treeNode.getMetricEvaluatorClass());
            rootElem.addContent(nextElem);
        }
        
        if (treeNode.getMathEvaluatorClass() != null)
        {
            nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.MATHEVALUATOR);
            nextElem.setText(treeNode.getMathEvaluatorClass());
            rootElem.addContent(nextElem);
        }
        
        if (treeNode.getNodeStats() != null)
        {
            nextElem = statsParser.serialize(treeNode.getNodeStats());
            rootElem.addContent(nextElem);
        }

        return rootElem;
    }

    /**
     * Parse the XML element back into a TreeNode object.
     * @param toParse the element to parse.
     * @return the parsed tree node.
     * @throws java.lang.Exception any error.
     */
    public TreeNode parse(Element toParse) throws Exception
    {
        int i;
        String evalClass;                           //evaluator class
        String nextValue;                           //next value
        NodeStats nodeStats;                        //node stats
        FunctionMetric metricEval;                  //dataset evaluator
        EvaluateMathDef mathEval;                   //the math evaluator
        KD_TreeNode treeNode;                       //tree node
        NodeStatsParser statsParser;                //node stats parser
        Node nextNode;                              //next element node
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        Vector elemList;                            //element list
        
        treeNode = null;
        statsParser = new NodeStatsParser();
        rootElem = toParse;
        
        if (rootElem.getName().equals(AiHeuristicConst.KDTREE) ||
            rootElem.getName().equals(AiHeuristicConst.KDTREENODE))
        {
            treeNode = (KD_TreeNode)super.parse(rootElem);
            
            elemList = rootElem.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(AiHeuristicConst.BS))
                    {
                        nextValue = nextElem.getText();
                        treeNode.setBucketSize(Integer.parseInt(nextValue));
                    }
                    else if (nextElem.getName().equals(AiHeuristicConst.EVALUATOR))
                    {
                        evalClass = nextElem.getText();
                        metricEval = (FunctionMetric)LoadObject.loadObject(new ArrayList(), evalClass, new ArrayList());
                        treeNode.setMetricEvaluator(metricEval);
                    }
                    else if (nextElem.getName().equals(AiHeuristicConst.MATHEVALUATOR))
                    {
                        evalClass = nextElem.getText();
                        mathEval = (EvaluateMathDef)LoadObject.loadObject(new ArrayList(), evalClass, new ArrayList());
                        treeNode.setMathEvaluator(mathEval);
                    }
                    else if (nextElem.getName().equals(AiHeuristicConst.STATS))
                    {
                        nodeStats = statsParser.parse(nextElem);
                        treeNode.setNodeStats(nodeStats);
                    }
                }
            }
        }

        return treeNode;
    }
}
