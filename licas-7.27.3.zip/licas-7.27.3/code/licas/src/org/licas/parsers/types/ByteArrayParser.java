/*
 * ByteArrayParser.java
 *
 * Created on 29 May 2012
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer.
 *
 * Author: Kieran Greer
 */

package org.licas.parsers.types;


import org.ai_heuristic.def.ParserDef;
import org.licas.util.ByteArray;
import org.licas.util.TypeConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;


/**
 * This class parses a string-based representation of a {@link ByteArray} to or from XML.
 * NOTE: if the byte array contents are encoded, they are not decoded during the parsing.
 * An extra explicit operation is required at the end to decode the string from Base64.
 * @author Kieran Greer
 */
public class ByteArrayParser implements ParserDef
{
    /** Creates a new instance of ByteArrayParser */
    public ByteArrayParser() {
    }
    
    /**
     * Serialize a {@link ByteArray} object to XML.
     * @param toSerialize the ByteArray object to serialize.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        ByteArray byteArray;                                //byte array
        Element rootElem;                                   //root element
        
        try
        {
            rootElem = XMLFactory.getInstance().createElement(TypeConst.BYTELIST);
            byteArray = (ByteArray)toSerialize;
            rootElem.setText(byteArray.getByteArray());
            
            return rootElem;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /**
     * Parse an XML description of a {@link ByteArray} object back into a Java object.
     * @param toParse the XML description to parse.
     * @return the ByteArray object that is created.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        ByteArray byteArray;                            //byte array

        try
        {
            byteArray = null;
            if (toParse.getName().equals(TypeConst.BYTELIST))
            {
                byteArray = new ByteArray();
                byteArray.setByteArray(toParse.getText());
            }

            return byteArray;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
