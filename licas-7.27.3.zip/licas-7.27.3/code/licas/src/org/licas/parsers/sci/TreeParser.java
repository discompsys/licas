/*
 * TreeParser.java
 *
 * Created on 28 September 2013
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.parsers.sci;


import org.ai_heuristic.def.ParserDef;
import org.ai_heuristic.tree.Tree;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas_xml.abs.Element;


/**
 * This can be used to parse a whole {@link Tree} tree structure, starting from the root tree node.
 * @author Kieran Greer
 */
public class TreeParser implements ParserDef
{
    /** Create a new instance of TreeParser */
    public TreeParser()
    {}

    /**
     * Serialize the object into an XML element.
     * @param toSerialize the object to serialize. Of type {@link Tree}.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        return serialize((Tree)toSerialize);
    }
    
    /**
     * Serialize the object into an XML element.
     * @param tree the Tree to serialize.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Tree tree) throws Exception
    {
        Element rootElem;                           //root element
        TreeNodeParser nodeParser;                  //tree node parser

        nodeParser = new TreeNodeParser();
        rootElem = nodeParser.serialize(tree);
        rootElem.setName(AiHeuristicConst.TREE);

        return rootElem;
    }

    /**
     * Parse the XML element back into a Tree object.
     * @param toParse the element to parse.
     * @return the parsed Tree.
     * @throws java.lang.Exception any error.
     */
    public Tree parse(Element toParse) throws Exception
    {
        Tree tree;                                  //tree
        Element rootElem;                           //root element
        TreeNodeParser nodeParser;                  //tree node parser

        tree = null;
        rootElem = toParse;
        
        if (rootElem.getName().equals(AiHeuristicConst.TREE))
        {
            nodeParser = new TreeNodeParser();
            tree = (Tree)nodeParser.parse(rootElem);
        }

        return tree;
    }
}
