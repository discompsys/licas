/*
 * DataTransferParser.java
 *
 * Created on 24 February 2022
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers;


import org.ai_heuristic.def.ParserDef;
import org.licas.service.sci.DataTransfer;
import org.licas.util.Const;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.*;


/**
 * This class can be used to parse a {@link DataTransfer} object to or from XML.
 * @author Kieran Greer
 */
public class DataTransferParser implements ParserDef
{
    /**
     * Create a new instance of DataTransferParser.
     */
    public DataTransferParser()
    {}

    /**
     * Serialize a {@link DataTransfer} object to XML.
     * @param toSerialize the MethodInfo object to serialize.
     * @return an XML description of the object.
     * @throws Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        String stringValue;                     //string value
        DataTransfer dataInfo;                  //data query object
        Element rootElem;                       //root element
        Element nextElem;                       //next element
        Element objElem;                        //object parsed as an element
        
        try
        {
            dataInfo = (DataTransfer)toSerialize;
            rootElem = XMLFactory.getInstance().createElement(Const.DATAINFO);

            stringValue = dataInfo.type;
            if (stringValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.TYPE);
                nextElem.setText(stringValue);
                rootElem.addContent(nextElem);
            }

            if (dataInfo.dataQueue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.VALUE);
                objElem = Parsers.serializeToElement(dataInfo.dataQueue);
                nextElem.addContent(objElem);
                rootElem.addContent(nextElem);
            }

            return rootElem;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /**
     * Parse an XML description of a {@link DataTransfer} object back into the Java object.
     * @param toParse the XML description to parse.
     * @return the DataQuery object that is created.
     * @throws Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        int i;
        Node nextNode;                          //next node
        Element nextElem;                       //next element
        Element nextElem2;                      //next element
        Vector elemList;                        //element list
        DataTransfer dataInfo;                  //data info object

        try
        {
            dataInfo = new DataTransfer();
            if (toParse.getName().equals(Const.DATAINFO))
            {
                elemList = (Vector)toParse.getChildren().clone();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);

                    if (nextNode instanceof Element)
                    {
                        nextElem = (Element)nextNode;

                        if (nextElem.getName().equals(Const.TYPE))
                        {
                            dataInfo.type = nextElem.getText();
                        }
                        else if (nextElem.getName().equals(Const.VALUE))
                        {
                            nextElem2 = nextElem.getElementChildAtIndex(0);
                            dataInfo.dataQueue = ((HashMap)Parsers.parse(nextElem2));
                        }
                    }
                }
            }

            return dataInfo;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
