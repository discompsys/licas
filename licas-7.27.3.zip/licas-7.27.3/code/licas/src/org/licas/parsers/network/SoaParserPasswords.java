/*
 * SoaParserPasswords.java
 *
 * Created on 4 December 2012
 *
 * Version 1.4.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers.network;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.call.Handle;
import org.licas.server.LocalServer;
import org.licas.util.Const;
import org.licas.util.MetaConst;
import org.licas_text.util.XmlHtmlHandler;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.model.XmlHandler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;


/**
 * This class can be used to parse the passwords list stored for the local server services.
 * @author Kieran Greer
 */
public class SoaParserPasswords 
{
    /** The logger */
    private static final Logger logger;

    /** 
     * Full URL address relating to the server that the passwords are being
     * processed for / added to. If null then create URIs without a URL handle.
     */
    private String serverUrl;
    
    /**
     * All password for all services, as a keyed list of list of objects
     * for each service - state,password and key.
     */
    private HashMap<String, ArrayList<String>> allPasswords;
    
    /** 
     * All of the created services' passwords. Keys are the service ids of
     * type String and values are the nextService passwords of type String.
     */
    private HashMap<String, String> allServicePasswords;
    
    /** 
     * All of the created services' service keys. Keys are the service ids of
     * type String and values are the service keys of type String.
     */
    private HashMap<String, String> allServiceKeys;
    
    /** 
     * All of the created services' admin docs. Keys are the service ids of
     * type String and values are the doc file paths.
     */
    private HashMap<String, String> allAdminDocs;
    
    /** 
     * All of the created services' start thread running values. Keys are the service 
     * ids of type String and values are true (start) or false (do not start).
     */
    private HashMap<String, Boolean> allStartServices;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SoaParserPasswords.class.getName());
        logger.setDebug(true);
    }

    
    /**
     * Create a new instance of SoaParserPasswords.
     */
    public SoaParserPasswords()
    {
        initialise();
    }
    
    /**
     * Initialise some values.
     */
    private void initialise()
    {
        serverUrl = null;
        allPasswords = new HashMap<>();
        allServicePasswords = new HashMap<>();
        allServiceKeys = new HashMap<>();
        allAdminDocs = new HashMap<>();
        allStartServices = new HashMap<>();
    }
    
    /**
     * Serialise all passwords for all services on the server into XML.
     * @param password the password to access the server.
     * @param adminKey the admin key for the server.
     * @return an XML description of all passwords for all services.
     * @throws java.lang.Exception any error.
     */
    protected Element serialize(String password, String adminKey) throws Exception
    {
        Element rootElem;                           //root element
        
        try {
            rootElem = LocalServer.getApi(password).passwordsStateToXml(adminKey);
            parse(rootElem);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "serialize", null, ex);
        }
        
        return rootElem;
    }
    
    /**
     * Parse the passwords description to add all service passwords.
     * @param passwordsElem the root passwords element.
     * @return the passwords stored for each service. Keys are the service ids
     * of type full URI String and values are password-related values of type a
     * ArrayList of Objects, for service state, password and admin key.
     * @throws java.lang.Exception any error.
     */
    protected HashMap<String, ArrayList<String>> parse(Element passwordsElem) throws Exception
    {
        int i, j;
        String theUuid;                             //the uuid
        String theThreadState;                      //the thread state
        String thePassword;                         //the password
        String theAdminKey;                         //the nextService key
        String adminDocFile;                        //admin doc file
        ArrayList<String> nextPasswords;            //next passwords
        Node nextNode;                              //next node
        Element serviceUri;                         //the service uri
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Vector<Node> elemList;                      //element list
        Vector<Node> elemList2;                     //element list
                
        allPasswords = new HashMap<>();
        try
        {
            if (serverUrl == null) {
                try {
                    serverUrl = LocalServer.getServerURL();
                }
                catch (Exception ipex) {}
            }
            
            elemList = passwordsElem.getChildren();           
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = elemList.get(i);
                if (nextNode instanceof Element) {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(Const.NEXTPASSWORDS)) {
                        theUuid = XmlHtmlHandler.decodeXml(nextElem.getAttributeValue(Const.UUID));
                        theThreadState = null;
                        thePassword = null;
                        theAdminKey = null;
                        adminDocFile = null;
                        
                        elemList2 = nextElem.getChildren();            
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = elemList2.get(j);
                            if (nextNode instanceof Element) {
                                nextElem2 = (Element)nextNode;                                
                                if (nextElem2.getName().equals(Const.THREADSTATE)) {
                                    theThreadState = nextElem2.getValue();
                                }
                                else if (nextElem2.getName().equals(MetaConst.PASSWORD)) {
                                    thePassword = nextElem2.getValue();
                                }
                                else if (nextElem2.getName().equals(Const.SERVICEKEY)) {
                                    theAdminKey = nextElem2.getValue();
                                }
                                else if (nextElem2.getName().equals(Const.FILEURI)) {
                                    adminDocFile = nextElem2.getValue();
                                }
                            }
                        }
                        
                        //create the full uri before adding
                        if (serverUrl != null) {
                            serviceUri = Handle.createNewUrlHandle(serverUrl);
                            serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(theUuid));
                        }
                        else {
                            serviceUri = Handle.createNewHandleHandle(theUuid);
                        }
                        theUuid = Handle.handleToString(serviceUri);
                        
                        nextPasswords = new ArrayList<>();
                        nextPasswords.add(theThreadState);
                        nextPasswords.add(thePassword);
                        nextPasswords.add(theAdminKey);
                        if (adminDocFile != null) nextPasswords.add(adminDocFile);
                        
                        allPasswords.put(theUuid, nextPasswords);                     
                        allStartServices.put(theUuid, Boolean.valueOf(theThreadState));
                        allServicePasswords.put(theUuid, thePassword);
                        allServiceKeys.put(theUuid, theAdminKey);
                        if (adminDocFile != null) allAdminDocs.put(theUuid, adminDocFile);
                                                
                        //add the child service passwords in the same way
                        elemList2 = nextElem.getChildren();           
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = elemList2.get(j);
                            if (nextNode instanceof Element) {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equals(Const.NEXTPASSWORDS)) {
                                    parse(nextElem2, serviceUri);
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "parse", null, ex);
        }
        
        return allPasswords;
    }
    
    /**
     * Parse the passwords description to add all service passwords.
     * @param passwordsElem the root passwords element.
     * @param parentUri parent service URI, for constructing a full path.
     * @throws java.lang.Exception any error.
     */
    private void parse(Element passwordsElem, Element parentUri) throws Exception
    {
        int i;
        String theUuid;                             //the uuid
        String theThreadState;                      //the thread state
        String thePassword;                         //the password
        String theAdminKey;                         //the nextService key
        String adminDocFile;                        //admin doc file
        ArrayList<String> nextPasswords;            //next passwords
        Node nextNode;                              //next node
        Element serviceUri;                         //the service uri
        Element nextElem;                           //next element
        Vector<Node> elemList;                      //element list
                
        try
        {
            theUuid = XmlHtmlHandler.decodeXml(passwordsElem.getAttributeValue(Const.UUID));
            theThreadState = null;
            thePassword = null;
            theAdminKey = null;
            adminDocFile = null;
                        
            elemList = passwordsElem.getChildren();           
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = elemList.get(i);
                if (nextNode instanceof Element) {
                    nextElem = (Element)nextNode;                                
                    if (nextElem.getName().equals(Const.THREADSTATE)) {
                        theThreadState = nextElem.getValue();
                    }
                    else if (nextElem.getName().equals(MetaConst.PASSWORD)) {
                        thePassword = nextElem.getValue();
                    }
                    else if (nextElem.getName().equals(Const.SERVICEKEY)) {
                        theAdminKey = nextElem.getValue();
                    }
                    else if (nextElem.getName().equals(Const.FILEURI)) {
                        adminDocFile = nextElem.getValue();
                    }
                }
            }
                        
            //create the full uri before adding
            serviceUri = Handle.addToHandle(parentUri, Handle.asHandleElement(theUuid));
            theUuid = Handle.handleToString(serviceUri);

            nextPasswords = new ArrayList();
            nextPasswords.add(theThreadState);
            nextPasswords.add(thePassword);
            nextPasswords.add(theAdminKey);
            if (adminDocFile != null) nextPasswords.add(adminDocFile);
            
            allPasswords.put(theUuid, nextPasswords);                      
            allStartServices.put(theUuid, Boolean.valueOf(theThreadState));
            allServicePasswords.put(theUuid, thePassword);
            allServiceKeys.put(theUuid, theAdminKey);
            if (adminDocFile != null) allAdminDocs.put(theUuid, adminDocFile);
            
            //add the child service passwords in the same way
            elemList = passwordsElem.getChildren();           
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(Const.NEXTPASSWORDS)) {
                        parse(nextElem, serviceUri);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "parse", null, ex);
        }
    }
    
    /**
     * Get the service start thread state.
     * @param serviceID the id of the service to retrieve.
     * @return true if start the thread, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean getStartThread(String serviceID) throws Exception
    {
        boolean startThread;                        //true if start the thread
        Element serviceURI;                         //full service uri
        
        startThread = false;
        
        //check for password directly, or add handle with IP if not present
        if (allStartServices.containsKey(serviceID)) {
            startThread = ((Boolean)allStartServices.get(serviceID)).booleanValue();
        }
        else {
            serviceURI = Handle.createNewUrlHandle(serverUrl);
            serviceURI = Handle.addToHandle(serviceURI, Handle.asHandleElement(serviceID));
            serviceID = XmlHandler.xmlToString(serviceURI);
            
            if (allStartServices.containsKey(serviceID))
                startThread = ((Boolean)allStartServices.get(serviceID)).booleanValue();
        }
               
        return startThread;
    }
    
    /**
     * Get the service password.
     * @param serviceID the id of the service to retrieve.
     * @return the password or null if one does not exist.
     * @throws java.lang.Exception any error.
     */
    public String getPassword(String serviceID) throws Exception
    {
        String nextPassword;                            //next password
        Element serviceURI;                             //full service uri
        
        nextPassword = null;
        
        //check for password directly, or add handle with IP if not present
        if (allServicePasswords.containsKey(serviceID)) {
            nextPassword = allServicePasswords.get(serviceID);
        }
        
        if (nextPassword == null) {
            try {
                serviceID = Handle.getLastServiceHandle(XmlHandler.stringToElement(serviceID));
                nextPassword = allServicePasswords.get(serviceID);
            }
            catch (Exception ex) {}
        }  
        
        if (nextPassword == null) {
            serviceURI = Handle.createNewUrlHandle(serverUrl);
            serviceURI = Handle.addToHandle(serviceURI, Handle.asHandleElement(serviceID));
            serviceID = XmlHandler.xmlToString(serviceURI);

            if (allServicePasswords.containsKey(serviceID))
                nextPassword = allServicePasswords.get(serviceID);
        }

        return nextPassword;
    }
    
    /**
     * Get the service admin key.
     * @param serviceID the id of the service to retrieve.
     * @return the admin key or null if one does not exist.
     * @throws java.lang.Exception any error.
     */
    public String getAdminKey(String serviceID) throws Exception
    {
        String nextPassword;                            //next password
        Element serviceURI;                             //full service uri
        
        nextPassword = null;
        
        //check for password directly, or add handle with IP if not present
        if (allServiceKeys.containsKey(serviceID)) {
            nextPassword = (String)allServiceKeys.get(serviceID);
        }
        
        if (nextPassword == null) {
            try {
                serviceID = Handle.getLastServiceHandle(XmlHandler.stringToElement(serviceID));
                nextPassword = allServiceKeys.get(serviceID);
            }
            catch (Exception ex)
            {}
        }  
        
        if (nextPassword == null) {
            serviceURI = Handle.createNewUrlHandle(serverUrl);
            serviceURI = Handle.addToHandle(serviceURI, Handle.asHandleElement(serviceID));
            serviceID = XmlHandler.xmlToString(serviceURI);
            
            if (allServiceKeys.containsKey(serviceID))
                nextPassword = allServiceKeys.get(serviceID);
        }

        return nextPassword;
    }
    
    /**
     * Get the service admin doc file path.
     * @param serviceID the id of the service to retrieve.
     * @return the admin doc file path or null if one does not exist.
     * @throws java.lang.Exception any error.
     */
    public String getAdminDoc(String serviceID) throws Exception
    {
        String filePath;                                //file path
        Element serviceURI;                             //full service uri
        
        filePath = null;
        
        //check for password directly, or add handle with IP if not present
        if (allAdminDocs.containsKey(serviceID)) {
            filePath = (String)allAdminDocs.get(serviceID);
        }
        
        if (filePath == null) {
            try {
                serviceID = Handle.getLastServiceHandle(XmlHandler.stringToElement(serviceID));
                filePath = allAdminDocs.get(serviceID);
            }
            catch (Exception ex) {}
        }  
        
        if (filePath == null) {
            serviceURI = Handle.createNewUrlHandle(serverUrl);
            serviceURI = Handle.addToHandle(serviceURI, Handle.asHandleElement(serviceID));
            serviceID = XmlHandler.xmlToString(serviceURI);
            
            if (allAdminDocs.containsKey(serviceID))
                filePath = allAdminDocs.get(serviceID);
        }

        return filePath;
    }
    
    /**
     * Get the list of all password values for each service.
     * @return the value of allPasswords.
     */
    public HashMap<String, ArrayList<String>> getAllPasswords()
    {
        return allPasswords;
    }
}
