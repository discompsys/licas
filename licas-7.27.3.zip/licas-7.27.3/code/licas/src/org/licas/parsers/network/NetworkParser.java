/*
 * NetworkParser.java
 *
 * Created on 14 April 2014
 *
 * Version 1.0.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers.network;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.PasswordHandler;
import org.licas.ServiceLinks;
import org.licas.util.Const;
import org.licas.util.MetaConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;


/**
 * This class can be used to parse the registered servers running on a network to or from XML, 
 * so that it can be saved to a file and then reconstructed. This is a description of the distributed
 * servers only and relates to their passwords and links, so that the network can be re-constructed.
 * It is not a complete solution that saves everything.
 * @author Kieran Greer
 */
public class NetworkParser 
{
    /** The logger */
    private static final Logger logger;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(NetworkParser.class.getName());
        logger.setDebug(true);
    }

    
    /**
     * Create a new instance of NetworkParser.
     */
    public NetworkParser()
    {
        initialise();
    }
    
    /**
     * Initialise some values.
     */
    private void initialise()
    {}
    
    /**
     * Serialise the server details with relation to the network.
     * @param serverPath the path description to the server.
     * @param passwordHandler the passwords for the servers.
     * @param serviceLinks all service links.
     * @return an XML description of the network. This includes the links between the
     * different network nodes.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Element serverPath, PasswordHandler passwordHandler, 
            ServiceLinks serviceLinks) throws Exception
    {
        int i;
        String nextPassword;                        //next password
        ArrayList<Element> meta;                    //list of metadata elements
        Element passwordsElem;                      //passwords element
        Element linkPathElem;                       //link path element
        Element metaElem;                           //metadata element
        Element serverElem;                         //server element
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
              
        try {
            //serialize details for all registered servers
            serverElem = XMLFactory.getInstance().createElement(Const.SERVER);
            serverElem.addContent(serverPath);
            
            passwordsElem = XMLFactory.getInstance().createElement(Const.PASSWORDS);
            serverElem.addContent(passwordsElem);

            nextPassword = passwordHandler.getPassword();
            nextElem = XMLFactory.getInstance().createElement(MetaConst.PASSWORD);
            nextElem.setText(nextPassword);
            passwordsElem.addContent(nextElem);
            nextPassword = passwordHandler.getAdminKey();
            nextElem = XMLFactory.getInstance().createElement(Const.SERVICEKEY);
            nextElem.setText(nextPassword);
            passwordsElem.addContent(nextElem);
            
            metaElem = XMLFactory.getInstance().createElement(MetaConst.META);
            serverElem.addContent(metaElem);
            
            meta = (ArrayList)serviceLinks.getServiceAssociations().clone();
            if ((meta != null) && (meta.size() > 0)) {
                for (i = 0; i < meta.size(); i++)
                {
                    nextElem = XMLFactory.getInstance().createElement(MetaConst.ASSOCIATEDLINKSERVICEMETA);
                    linkPathElem = (Element)meta.get(i).detach();
                    nextElem.addContent(linkPathElem);
                    metaElem.addContent(nextElem);
                    
                    passwordsElem = XMLFactory.getInstance().createElement(Const.PASSWORDS);
                    nextElem.addContent(passwordsElem);
            
                    if (passwordHandler.hasServicePassword(linkPathElem)) {
                        nextPassword = passwordHandler.getServicePassword(linkPathElem);
                        nextElem2 = XMLFactory.getInstance().createElement(MetaConst.PASSWORD);
                        nextElem2.setText(nextPassword);
                        passwordsElem.addContent(nextElem2);
                    }
                    
                    if (passwordHandler.hasAdminKey(linkPathElem)) {
                        nextPassword = passwordHandler.getAdminKey(linkPathElem);
                        nextElem2 = XMLFactory.getInstance().createElement(Const.SERVICEKEY);
                        nextElem2.setText(nextPassword);
                        passwordsElem.addContent(nextElem2);
                    }
                }
            }
            
            return serverElem;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "serialize", null, ex);
        }
    }
    
    /**
     * Parse the XML description of the network and load it onto the server.
     * @param networkDoc the network with related links can be described in a single document.
     * @return a description of the registered servers, including passwords and links.
     * @throws java.lang.Exception any error.
     */
    public HashMap<String, Element> parse(Element networkDoc) throws Exception
    {
        int i;
        HashMap<String, Element> networkMeta;       //network metadata
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Vector<Node> elemList;                      //element list
        
        try {
            networkMeta = new HashMap<>();
            if (networkDoc.getName().equals(Const.SERVER)) {
                elemList = (Vector)networkDoc.getChildren().clone();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = elemList.get(i);
                    if (nextNode instanceof Element) {
                        nextElem = (Element)nextNode;
                        switch (nextElem.getName()) {
                            case Const.HANDLE:
                                networkMeta.put(Const.HANDLE, nextElem);
                                break;
                            case Const.PASSWORDS:
                                //probably do nothing
                                break;
                            case MetaConst.META:
                                networkMeta.put(MetaConst.META, (Element) nextElem.detach());
                                break;
                        }
                    }
                }
            }
            
            return networkMeta;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "parse", null, ex);
        }
    }
}
