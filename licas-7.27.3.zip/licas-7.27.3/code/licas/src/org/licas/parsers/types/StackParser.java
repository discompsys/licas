/*
 * StackParser.java
 *
 * Created on 9 June 2016
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers.types;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.util.Const;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;

import java.util.Stack;
import java.util.Vector;



/**
 * This class parses standard {@code Stack} structures. This includes parsing nested
 * lists and any objects that they might store.
 * @author Kieran Greer
 */
public class StackParser extends VectorParser
{
    /** The logger */
    private static Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(StackParser.class.getName());
        logger.setDebug(false);
    }

    
    /** Creates a new instance of StackParser */
    public StackParser() {
    }
    
    /**
     * Parse the information to return a list of the values.
     * @param toParse a description of the data.
     * @throws java.lang.Exception any error.
     * @return a ArrayList with real values contained.
     */
    public Object parse(Element toParse) throws Exception
    {
        if (isList(Stack.class, toParse))
            return elementToStack(toParse);
        else
            return null;
    }
    
    /**
     * Parse the information to return a ArrayList of the values.
     * @param toParse a description of the data.
     * @throws java.lang.Exception any error.
     * @return a ArrayList with real values contained.
     */
    private Stack elementToStack(Element toParse) throws Exception
    {
        Vector data;                    //the vector to store the data in
        Stack stack;                    //the stack
        
        data = new Vector();
        elementToVector(data, toParse);
        stack = new Stack();
        stack.addAll(data);
        
        return stack;
    }
    
    /**
     * Serialize a ArrayList to generate an xml representation.
     * @param toSerialize the data list.
     * @throws java.lang.Exception any error.
     * @return an element if a list or the original object if not a list.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        if ((toSerialize != null) && (toSerialize.getClass().getName().equals(Stack.class.getName())))
        {
            return stackToElement((Stack)toSerialize);
        }
        
        return null;
    }
    
    /**
     * Parse a Stack to generate an xml representation.
     * @param data the data vector.
     * @throws java.lang.Exception any error.
     * @return an xml representation of the list.
     */
    private Element stackToElement(Stack data) throws Exception
    {
        Element rootElem;                   //the root element
        
        rootElem = XMLFactory.getInstance().createElement(Const.PARAMETERS);
        rootElem.setAttribute(Const.CONVERSIONTYPE, Stack.class.getName());        
        vectorToElement((Vector)data, rootElem);

        return rootElem;
    }
}
