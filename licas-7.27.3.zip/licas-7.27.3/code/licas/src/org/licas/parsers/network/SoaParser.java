/*
 * SoaParser.java
 *
 * Created on 4 December 2012
 *
 * Version 1.5.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers.network;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.Service;
import org.licas.server.LocalServer;
import org.licas.util.Const;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;


/**
 * This class can be used to parse a whole service configuration, or SOA, to or from XML, 
 * so that it can be saved to a file and then reconstructed. This is configuration for
 * the services running on a single local server. This is not a complete solution, but can
 * be used for testing purposes, for example, to repeat test runs over the same set of services.
 * @author Kieran Greer
 */
public class SoaParser 
{
    /** The logger */
    private static final Logger logger;


    /** Passwords parser */
    private SoaParserPasswords passwordsParser;
    
    /** links parser */
    private SoaParserLinks linksParser;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SoaParser.class.getName());
        logger.setDebug(true);
    }

    
    /**
     * Create a new instance of SoaParser.
     */
    public SoaParser()
    {
        initialise();
    }
    
    /**
     * Initialise some values.
     */
    private void initialise()
    {
        passwordsParser = new SoaParserPasswords();
        linksParser = new SoaParserLinks(passwordsParser);
    }
    
    /**
     * Serialise the whole network into XML.
     * @param password the password to access the server.
     * @param adminKey the admin key for the server.
     * @return an XML description of the network. This is stored as a set of
     * XML documents, one for each parsed part. This includes the passwords as a 
     * separate list, the service information and the links as a separate list.
     * @throws java.lang.Exception any error.
     */
    public HashMap<String, Element> serialize(String password, String adminKey) throws Exception
    {
        int i;
        String nextServiceID;                       //next service id
        String nextPassword;                        //next password
        String nextAdminKey;                        //next admin key
        ArrayList<String> serviceIDs;               //list of service ids
        ArrayList<Service> allServices;             //all services
        HashMap<String, Element> serializedSoa;     //list of serialized documents
        Service nextService;                        //next service
        Element serverElem;                         //server element
        Element passwordsElem;                      //passwords element
        Element servicesElem;                       //services element
        Element linksElem;                          //links element
        Element rootElem;                           //root element
        Element nextElem;                           //next element
               
        serializedSoa = new HashMap<>();
        try {
            //serialize the passwords
            passwordsElem = passwordsParser.serialize(password, adminKey);
            
            //serialize details for the current local server
            rootElem = XMLFactory.getInstance().createElement(Const.SOA);
            serverElem = XMLFactory.getInstance().createElement(Const.SERVER);
            rootElem.addContent(serverElem);
            nextElem = XMLFactory.getInstance().createElement(Const.ALLOWADDSERVICES);
            nextElem.setText(Boolean.toString(LocalServer.getApi(password).getAllowAddService(adminKey)));
            serverElem.addContent(nextElem);
            
            //add the services
            servicesElem = XMLFactory.getInstance().createElement(Const.SERVICES);
            rootElem.addContent(servicesElem);
            
            allServices = new ArrayList<>();
            serviceIDs = LocalServer.getApi(password).getServiceNames();
            
            //serialize the services' metadata
            for (i = 0; i < serviceIDs.size(); i++)
            {
                nextServiceID = serviceIDs.get(i);
                nextPassword = passwordsParser.getPassword(nextServiceID);
                nextAdminKey = passwordsParser.getAdminKey(nextServiceID);
                
                nextService = (Service)LocalServer.getApi(password).getService(nextServiceID, nextPassword, nextAdminKey);
                allServices.add(nextService);
            }
            
            //add for each nested service
            for (i = 0; i < allServices.size(); i++)
            {
                nextService = allServices.get(i);
                serializeService(nextService, servicesElem);
            }
            
            //serialize the services' links
            linksElem = linksParser.serialize(password, adminKey, serviceIDs);
            
            serializedSoa.put(Const.PASSWORDS, passwordsElem);
            serializedSoa.put(Const.SERVER, rootElem);
            serializedSoa.put(Const.LINKS, linksElem);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "serialize", null, ex);
        }
        
        return serializedSoa;
    }
    
    /**
     * Serialise the object of type ServiceMeta into XML.
     * @param theService a direct reference to the service object.
     * @param servicesElem the root services element to add service metadata to.
     * @throws java.lang.Exception any error.
     */
    public void serializeService(Service theService, Element servicesElem) throws Exception
    {
        String rootUuid;                            //root element uuid
        String nextAdminKey;                        //next admin key
        Element rootElem;                           //root element
        
        try {
            rootUuid = theService.getUUID();
            nextAdminKey = passwordsParser.getAdminKey(rootUuid);
            rootElem = theService.serviceToXml(nextAdminKey);
            servicesElem.addContent(rootElem);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "serializeService", null, ex);
        }
    }

    /**
     * Parse the XML description of the network and load it onto the server.
     * @param networkDocs a list of XML-based documents that describe the network
     * structure. The network file is identified as having the key value 'Const.NETWORK' 
     * element, while the links document has a root 'Const.LINKS' element. The network
     * file at least must be present. Value is an XML element.
     * @param password the password to access the server.
     * @param adminKey the server admin key.
     * @return the password related values. Keys are the nextService ids of type
     * String and values are password/service related values of type ArrayList of Objects.
     * @throws java.lang.Exception any error.
     */
    public HashMap<String, ArrayList<String>> parse(HashMap<String, Element> networkDocs,
                                                    String password, String adminKey) throws Exception
    {
        int i, j;
        boolean allowAdd;                                   //true if allow add services
        String nextValue;                                   //next value
        HashMap<String, ArrayList<String>> allPasswords;    //all passwords
        Element passwordsElem;                              //passwords element
        Element networkElem;                                //network element
        Element linksElem;                                  //links element
        Node nextNode;                                      //next node
        Element nextElem;                                   //next element
        Element nextElem2;                                  //next element
        Vector<Node> elemList;                              //element list
        Vector<Node> elemList2;                             //element list
        
        allowAdd = true;
        passwordsElem = networkDocs.get(Const.PASSWORDS);
        networkElem = networkDocs.get(Const.SERVER);
        linksElem = networkDocs.getOrDefault(Const.LINKS, null);
                
        try {
            //parse the passwords
            allPasswords = passwordsParser.parse(passwordsElem);
            
            //parse the server services
            if (networkElem.getName().equals(Const.NETWORK) ||
                networkElem.getName().equals(Const.SOA)) {
                elemList = networkElem.getChildren();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = elemList.get(i);
                    if (nextNode instanceof Element) {
                        nextElem = (Element)nextNode;
                        if (nextElem.getName().equals(Const.SERVER)) {
                            elemList2 = nextElem.getChildren();
                            for (j = 0; j < elemList2.size(); j++)
                            {
                                nextNode = elemList2.get(j);
                                if (nextNode instanceof Element) {
                                    nextElem2 = (Element)nextNode;
                                    if (nextElem2.getName().equals(Const.ALLOWADDSERVICES)) {
                                        nextValue = nextElem2.getText();
                                        allowAdd = Boolean.parseBoolean(nextValue);
                                    }
                                }
                            }
                        }
                        else if (nextElem.getName().equals(Const.SERVICES)) {
                            elemList2 = nextElem.getChildren();
                            for (j = 0; j < elemList2.size(); j++)
                            {
                                nextNode = elemList2.get(j);
                                if (nextNode instanceof Element) {
                                    nextElem2 = (Element)nextNode;
                                    if (nextElem2.getName().equals(Const.SERVICE)) {
                                        parseService(nextElem2, password);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            //parse the service links
            if ((linksElem != null) && linksElem.getName().equals(Const.LINKS)) {
                linksParser.parse(linksElem, password, adminKey);
            }
            
            //set allow add after config loaded
            LocalServer.getApi(password).allowAddService(adminKey, allowAdd);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "parse", null, ex);
        }
        
        return allPasswords;
    }
    
    /**
     * Parse the service XML to create a service object.
     * @param serviceXml the XML description of the service.
     * @param password the parent service/server password.
     * @throws java.lang.Exception any error.
     */
    private void parseService(Element serviceXml, String password) throws Exception
    {
        String lServiceUuid;                            //service uuid
        String lServiceType;                            //service type
        Element nextElem;                               //next element
        Object theService;                              //the service
        
        //this should be OK, the licas config file should have loaded in
        //any services or jar files that would be used, before using this method
        try {
            if (serviceXml.getName().equals(Const.SERVICE)) {
                //retrieve the constructor information
                lServiceUuid = null;
                lServiceType = null;

                nextElem = serviceXml.getChild(Const.UUID);
                if (nextElem != null) {
                    lServiceUuid = nextElem.getText();
                }
                nextElem = serviceXml.getChild(Const.SERVICETYPE);
                if (nextElem != null) {
                    lServiceType = nextElem.getText();
                }
                if (lServiceUuid == null) {
                    lServiceUuid = serviceXml.getAttributeValue(Const.NAME);
                }
                if (lServiceType == null) {
                    lServiceType = serviceXml.getName();
                }
                
                theService = Service.xmlToService(serviceXml, password);
                if (theService != null) {
                    if (theService instanceof Service) {
                        LocalServer.getApi(password).addService(password, ((Service)theService).getUUID(), 
                            ((Service)theService).getServiceType(), theService);
                    }
                    else {
                        LocalServer.getApi(password).addService(password, lServiceUuid, 
                                lServiceType, theService);
                    }
                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "parseService", null, ex);
        }
    }
}
