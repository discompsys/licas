/*
 * LinkQueryParser.java
 *
 * Created on 8 April 2018
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers;


import org.ai_heuristic.def.ParserDef;
import org.licas.query.LinkQueryConfig;
import org.licas.util.Const;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.Vector;


/**
 * This class can be used to parse a {@link LinkQueryConfig} object to or from XML.
 * @author Kieran Greer
 */
public class LinkQueryParser implements ParserDef
{
    /**
     * Create a new instance of LinkQueryParser.
     */
    public LinkQueryParser()
    {}

    /**
     * Serialize a {@link LinkQueryConfig} object to XML.
     * @param toSerialize the LinkQueryConfig object to serialize.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        int i;
        String nextConcept;                     //next concept
        LinkQueryConfig linkConfig;             //link query object
        Element rootElem;                       //root element
        Element nextElem;                       //next element
        Element nextElem2;                      //next element
        
        try
        {
            linkConfig = (LinkQueryConfig)toSerialize;
            rootElem = XMLFactory.getInstance().createElement(Const.LINKQUERY);

            nextElem = XMLFactory.getInstance().createElement(Const.MAXNUMBER);
            nextElem.setText(String.valueOf(linkConfig.maxNumber));
            rootElem.addContent(nextElem);

            if ((linkConfig.conceptList != null) && !linkConfig.conceptList.isEmpty())
            {
                nextElem = XMLFactory.getInstance().createElement(Const.CONCEPTS);
                rootElem.addContent(nextElem);
                
                for (i = 0; i < linkConfig.conceptList.size(); i++)
                {
                    nextElem2 = XMLFactory.getInstance().createElement(Const.CONCEPT);
                    nextConcept = linkConfig.conceptList.get(i);
                    nextElem2.setText(nextConcept);
                    nextElem.addContent(nextElem2);
                }
            }

            return rootElem;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /**
     * Parse an XML description of a {@link LinkQueryConfig} object back into the Java object.
     * @param toParse the XML description to parse.
     * @return the LinkQueryConfig object that is created.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        LinkQueryConfig linkConfig;             //data info object

        linkConfig = new LinkQueryConfig();
        parseInfo(toParse, linkConfig);

        return linkConfig;
    }

    /**
     * Parse an XML description of a {@link LinkQueryConfig} object back into the Java object.
     * @param toParse the XML description to parse.
     * @param linkConfig the query config object to place the parsed content in.
     * @throws java.lang.Exception any error.
     */
    public void parseInfo(Element toParse, LinkQueryConfig linkConfig) throws Exception
    {
        int i, j;
        String nextValue;                       //next value
        Node nextNode;                          //next node
        Element nextElem;                       //next element
        Element nextElem2;                      //next element
        Vector elemList;                        //element list
        Vector elemList2;                       //element list
        
        try
        {
            if (toParse.getName().equals(Const.LINKQUERY))
            {
                elemList = (Vector)toParse.getChildren().clone();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);
                    if (nextNode instanceof Element)
                    {
                        nextElem = (Element)nextNode;
                        if (nextElem.getName().equals(Const.MAXNUMBER))
                        {
                            nextValue = nextElem.getText();
                            linkConfig.maxNumber = Integer.parseInt(nextValue);
                        }
                        else if (nextElem.getName().equals(Const.CONCEPTS))
                        {
                            elemList2 = nextElem.getChildren();
                            for (j = 0; j < elemList2.size(); j++)
                            {
                                nextElem2 = (Element)elemList2.elementAt(j);
                                if (nextElem2.getName().equals(Const.CONCEPT))
                                {
                                    nextValue = nextElem2.getText();
                                    linkConfig.conceptList.add(nextValue);
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
