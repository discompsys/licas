/*
 * LinkSpecParser.java
 *
 * Created on 6 August 2014
 *
 * Version 1.0.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers;


import org.ai_heuristic.def.ParserDef;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas.service.link.LinkConfig;
import org.licas.service.spec.LinkSpec;
import org.licas.util.AiConst;
import org.licas.util.Const;
import org.licas.util.ObjectHandler;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;


/**
 * This class can read a {@link LinkSpec} script file and parse it to or from XML.
 * @author Kieran Greer
 */
public class LinkSpecParser implements ParserDef
{
    /** 
     * Create a new instance of LinkSpecParser.
     */
    public LinkSpecParser()
    {}
    
    
    /**
     * Serialize the link spec script specification into XML.
     * @param toSerialize the {@link LinkSpec} object to serialize.
     * @return the script in XML format.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        Element scriptElem;                             //the script element
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        LinkSpec linkSpec;                              //linking specification
        
        scriptElem = XMLFactory.getInstance().createElement(Const.THRESHOLDSCONFIG);                
        if (toSerialize != null)
        {  
            linkSpec = (LinkSpec)toSerialize;      
            if (linkSpec.linkMethod != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.MONITORTHRESHOLD);                   
                nextElem.setText(String.valueOf(linkSpec.monitorThreshold));
                scriptElem.addContent(nextElem);
                nextElem = XMLFactory.getInstance().createElement(Const.LINKTHRESHOLD);                   
                nextElem.setText(String.valueOf(linkSpec.linkThreshold));
                scriptElem.addContent(nextElem);
                nextElem = XMLFactory.getInstance().createElement(Const.POSSIBLENUMBER);                   
                nextElem.setText(String.valueOf(linkSpec.possibleNumber));
                scriptElem.addContent(nextElem);
                nextElem = XMLFactory.getInstance().createElement(Const.MONITORNUMBER);                   
                nextElem.setText(String.valueOf(linkSpec.monitorNumber));
                scriptElem.addContent(nextElem);
                nextElem = XMLFactory.getInstance().createElement(Const.LINKNUMBER);                   
                nextElem.setText(String.valueOf(linkSpec.linkNumber));
                scriptElem.addContent(nextElem);
                nextElem = XMLFactory.getInstance().createElement(Const.LINKINCREMENT);                   
                nextElem.setText(String.valueOf(linkSpec.linkIncrement));
                scriptElem.addContent(nextElem);
                nextElem = XMLFactory.getInstance().createElement(Const.LINKWEIGTDECREMENT);                   
                nextElem.setText(String.valueOf(linkSpec.linkWeightDec));
                scriptElem.addContent(nextElem);
                
                if (linkSpec.linkMethod != null)
                {
                    nextElem = XMLFactory.getInstance().createElement(Const.LINKMETHOD);                   
                    nextElem.setText(linkSpec.linkMethod);
                    scriptElem.addContent(nextElem);
                }
                if (linkSpec.functionActivate != null)
                {
                    nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.FUNCTION);
                    nextElem2 = XMLFactory.getInstance().createElement(Const.CLASSNAME);                 
                    nextElem2.setText(linkSpec.functionActivate);
                    nextElem.addContent(nextElem2);
                    nextElem2 = serializeOptions(linkSpec.functionConfig);
                    nextElem.addContent(nextElem2);
                    scriptElem.addContent(nextElem);
                }
            }
        }
        
        return scriptElem;
    }
    
    /**
     * Parse the linking spec config back into a {@link LinkSpec} object.
     * @param toParse the XML-based description.
     * @return the parsed link spec object.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        int j;
        String nextValue;                               //next value
        String classType;                               //class type
        HashMap configOptions;                        //config options
        Vector elemList;                                //element list
        Node nextNode;                                  //next node
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        LinkSpec linkSpec;                              //linking spec
                        
        linkSpec = new LinkSpec();
        if (toParse.getName().equals(Const.THRESHOLDSCONFIG) ||
                toParse.getName().equals(Const.DYNAMICLINKS))
        {
            elemList = toParse.getChildren();
            for (j = 0; j < elemList.size(); j++)
            {
                nextNode = (Node)elemList.get(j);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(Const.MONITORTHRESHOLD))
                    {
                        try {
                            nextValue = nextElem.getText().trim();
                            linkSpec.monitorThreshold = Float.parseFloat(nextValue);
                        } catch (Exception ex2) {}
                    }
                    if (nextElem.getName().equals(Const.LINKTHRESHOLD))
                    {                    
                        try {
                            nextValue = nextElem.getText().trim();
                            linkSpec.linkThreshold = Float.parseFloat(nextValue);
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(Const.POSSIBLENUMBER))
                    {
                        try {
                            nextValue = nextElem.getText().trim();
                            linkSpec.possibleNumber = Integer.parseInt(nextValue);
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(Const.MONITORNUMBER))
                    {
                        try {
                            nextValue = nextElem.getText().trim();
                            linkSpec.monitorNumber = Integer.parseInt(nextValue);
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(Const.LINKNUMBER))
                    {
                        try {
                            nextValue = nextElem.getText().trim();
                            linkSpec.linkNumber = Integer.parseInt(nextValue);
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(Const.LINKINCREMENT))
                    {
                        try {
                            nextValue = nextElem.getText().trim();
                            linkSpec.linkIncrement = Float.parseFloat(nextValue);
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(Const.LINKWEIGTDECREMENT))
                    {
                        try {
                            nextValue = nextElem.getText().trim();
                            linkSpec.linkWeightDec = Float.parseFloat(nextValue);
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(Const.LINKMETHOD))
                    {
                        try {
                            linkSpec.linkMethod = LinkConfig.fixLinkMethod(nextElem.getText().trim());
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(AiHeuristicConst.FUNCTION))
                    {
                        nextElem2 = nextElem.getChild(Const.CLASSNAME);
                        classType = nextElem2.getText();
                        nextElem2 = nextElem.getChild(AiConst.HEURISTICOPTIONS);
                        configOptions = parseOptions(nextElem2);
                        
                        try {
                            linkSpec.functionActivate = classType;
                            linkSpec.functionConfig = configOptions;
                        } catch (Exception ex2) {}
                    }
                }
            }
        }
        
        return linkSpec;
    }
    
    /**
     * Serialize the list of options into an ML-based description.
     * @param optionsList the list of options to serialize.
     * @return the list as an XML-based description.
     * @throws java.lang.Exception any error.
     */
    public static Element serializeOptions(HashMap optionsList) throws Exception
    {
        int i;
        String nextKey;                                 //next key
        String classType;                               //class type
        Object nextValue;                               //next value
        Iterator allKeys;                               //all keys
        Element scriptElem;                             //script element
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        
        scriptElem = XMLFactory.getInstance().createElement(AiConst.HEURISTICOPTIONS);
        if (optionsList.size() > 0)
        {
            allKeys = optionsList.keySet().iterator();
            while (allKeys.hasNext())
            {
                nextKey = (String)allKeys.next();
                nextValue = optionsList.get(nextKey);

                nextElem = XMLFactory.getInstance().createElement(AiConst.HEURISTICOPTION);
                nextElem.setAttribute(Const.NAME, nextKey);
                scriptElem.addContent(nextElem);

                if (!nextValue.equals(Const.NULL))
                {
                    classType = nextValue.getClass().getName();
                    nextElem2 = XMLFactory.getInstance().createElement(Const.CLASSNAME);
                    nextElem2.setText(classType);
                    nextElem.addContent(nextElem2);

                    nextElem2 = XMLFactory.getInstance().createElement(Const.VALUE);
                    nextElem2.setText(ObjectHandler.valueToString(classType, nextValue));
                    nextElem.addContent(nextElem2);
                }
            }
        }
        
        return scriptElem;
    }
    
    /**
     * Parse the service script list of options as key-value pairs.
     * @param hashXml an XML-based description of the options list.
     * @return the list as a HashMap. Create any objects where possible.
     */
    public static HashMap parseOptions(Element hashXml)
    {
        int i;
        String nextValue;                               //next value
        String nextName;                                //next name
        String classType;                               //class type
        Vector elemList;                                //element list
        HashMap hashList;                             //list of options
        Node nextNode;                                  //next node
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        
        hashList = new HashMap();
        if (hashXml.getName().equals(AiConst.HEURISTICOPTIONS))
        {
            elemList = hashXml.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(AiConst.HEURISTICOPTION))
                    {
                        nextName = nextElem.getAttributeValue(Const.NAME);
                        classType = null;
                        nextValue = null;

                        nextElem2 = nextElem.getChild(Const.CLASSNAME);
                        if (nextElem2 != null)
                        {
                            classType = nextElem2.getText();
                            nextElem2 = nextElem.getChild(Const.VALUE);
                            if (nextElem2 != null)
                            {
                                nextValue = nextElem2.getText();
                            }
                        }

                        if ((nextValue != null) && (classType != null))
                        {
                            try {                                               
                                hashList.put(nextName, ObjectHandler.valueFromString(classType, nextValue));
                            } catch (Exception ex2) {}
                        }
                        else
                        {
                            hashList.put(nextName, Const.NULL);
                        }
                    }
                }
            }
        }
        
        return hashList;
    }
}
