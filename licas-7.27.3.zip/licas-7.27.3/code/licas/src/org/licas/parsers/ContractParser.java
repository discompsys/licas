/*
 * ContractParser.java
 *
 * Created on 13 November 2012
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer.
 */

package org.licas.parsers;


import org.ai_heuristic.def.ParserDef;
import org.licas.def.ContractDef;
import org.licas.service.model.Contract;
import org.licas.util.MetaConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;


/**
 * This class parses a {@link Contract} representation to or from XML.
 * @author Kieran Greer
 */
public class ContractParser implements ParserDef
{
    /** Creates a new instance of ContractParser */
    public ContractParser() {
    }
    
    /**
     * Serialize a Contract object to XML.
     * @param toSerialize the Contract object to serialize.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        ContractDef contract;                        //the contract
        Element rootElem;                            //root element
        
        try
        {
            contract = (ContractDef)toSerialize;
            rootElem = XMLFactory.getInstance().createElement(MetaConst.CONTRACT);
            rootElem.addContent(contract.getContract());
            
            return rootElem;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /**
     * Parse an XML description of a Contract object back into a Java object.
     * @param toParse the XML description to parse.
     * @return the Contract object that is created.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        Element contractInfo;                       //contract info
        Contract contract;                          //the contract
        
        try
        {
            contract = null;
            if (toParse.getName().equals(MetaConst.CONTRACT))
            {
                contractInfo = (Element)toParse.getElementChildAtIndex(0).detach();
                contract = new Contract(contractInfo);
            }

            return contract;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
