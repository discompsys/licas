/*
 * HttpEntityParser.java
 *
 * Created on 2 March 2020
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers;


import org.ai_heuristic.util.AiHeuristicConst;
import org.licas.parsers.types.HashMapParser;
import org.licas.server.model.*;
import org.licas.util.Const;
import org.licas_xml.abs.*;
import java.util.*;
import org.ai_heuristic.def.ParserDef;
import org.licas_xml.model.XmlHandler;


/**
 *
 * @author Kieran Greer
 */
public class HttpEntityParser implements ParserDef
{
    /**
     * Serialize the object into an XML element.
     * @param toSerialize the address info object to serialize.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        String nextValue;                           //next value
        HttpEntity entity;                          //http entity
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        
        entity = (HttpEntity)toSerialize;
        rootElem = XMLFactory.getInstance().createElement(Const.HTTPENTITY);        
        rootElem.setAttribute(Const.TYPE, entity.getType());
        rootElem.setAttribute(Const.METHOD, entity.getMethod());

        if ((entity.getHeaders() != null) && !entity.getHeaders().isEmpty())
        {
            nextElem = XMLFactory.getInstance().createElement(Const.HEADERS);
            nextElem.addContent((new HashMapParser()).serialize(entity.getHeaders()));
            rootElem.addContent(nextElem);
        }

        nextElem = XMLFactory.getInstance().createElement(Const.VALUE);
        nextElem.addContent(Parsers.serializeToElement(entity.getValue()));
        rootElem.addContent(nextElem);

        nextElem = XMLFactory.getInstance().createElement(Const.STATUS);
        nextValue = String.valueOf(entity.getStatusCode());
        nextElem.setText(nextValue);
        rootElem.addContent(nextElem);

        return rootElem;
    }
    
    /**
     * Parse the XML element back into the appropriate Object.
     * @param toParse the element to parse.
     * @return the parsed address lists.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        int i;
        Integer statusCode;                         //status code
        String type;                                //type
        String method;                              //method
        HashMap headers;                            //headers list
        Object value;                               //entity value
        HttpEntity entity;                          //entity
        Node nextNode;                              //next node
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        Vector elemList;                            //element list
        
        entity = null;
        headers = null;
        value = null;
        statusCode = Integer.MIN_VALUE;
        rootElem = toParse;

        if (rootElem.getName().equals(Const.HTTPENTITY))
        {
            type = rootElem.getAttributeValue(Const.TYPE);
            method = rootElem.getAttributeValue(Const.METHOD);
            
            elemList = rootElem.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(Const.HEADERS))
                    {
                        headers = new HashMap();
                        if (nextElem.hasChildren())
                        {
                            HashMapParser.elementToHashMap(headers, nextElem.getElementChildAtIndex(0));
                        }
                    }
                    else if (nextElem.getName().equals(AiHeuristicConst.VALUE))
                    {
                        if (nextElem.hasChildren())
                        {
                            value = Parsers.parse(nextElem.getElementChildAtIndex(0));
                        }
                    }
                    else if (nextElem.getName().equals(Const.STATUS))
                    {
                        statusCode = Integer.parseInt(nextElem.getText());                        
                    }
                }
            }
            
            entity = HttpEntity.createEntity(type, method, headers, value);
            if (statusCode != Integer.MIN_VALUE) entity.setStatusCode(statusCode);            
        }

        return entity;
    }
}
