/*
 * KeywordHandlerParser.java
 *
 * Created on 12 September 2011
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.parsers.admin;


import org.ai_heuristic.def.ParserDef;
import org.licas.parsers.KeywordInfoParser;
import org.licas.service.model.KeywordHandler;
import org.licas.service.model.KeywordInfo;
import org.licas.util.Const;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;


/**
 * This class can be used to parse a {@link KeywordHandler} object to or from XML.
 * @author Kieran Greer
 */
public class KeywordHandlerParser implements ParserDef
{
    /** Create a new instance of KeywordHandlerParser */
    public KeywordHandlerParser()
    {}
    
    /**
     * Serialize a KeywordHandler object to XML.
     * @param toSerialize the KeywordHandler object to serialize.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        int i, j;
        String nextConcept;                         //next concept
        String nextLanguage;                        //next language
        String nextSource;                          //next source
        Iterator conceptList;                       //concept list
        ArrayList languageList;                     //language list
        ArrayList sourceList;                       //source list
        HashMap keywordLists;                       //all keyword lists
        HashMap languageLists;                      //all language lists
        HashMap sourceLists;                        //source lists
        KeywordHandler keywordHandler;              //keyword handler
        KeywordInfo keywordInfo;                    //keyword info
        KeywordInfoParser keywordParser;            //keyword info parser
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        
        try
        {
            rootElem = XMLFactory.getInstance().createElement(Const.KEYWORDS);
            keywordHandler = (KeywordHandler)toSerialize;
            keywordLists = keywordHandler.getKeywordLists();
            keywordParser = new KeywordInfoParser();
            
            conceptList = keywordLists.keySet().iterator();
            while (conceptList.hasNext())
            {
                nextConcept = (String)conceptList.next();
                
                languageLists = (HashMap)keywordLists.get(nextConcept);              
                if (languageLists.size() > 0)
                {
                    languageList = new ArrayList(languageLists.keySet());
                    for (i = 0; i < languageList.size(); i++)
                    {
                        nextLanguage = (String)languageList.get(i);
                        sourceLists = (HashMap)languageLists.get(nextLanguage);
                        
                        sourceList = new ArrayList(sourceLists.keySet());
                        for (j = 0; j < sourceList.size(); j++)
                        {
                            nextSource = (String)sourceList.get(j);
                            keywordInfo = (KeywordInfo)sourceLists.get(nextSource);
                            nextElem = keywordParser.serialize(keywordInfo);
                            rootElem.addContent(nextElem);
                        }
                    }
                }
            }

            return rootElem;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /**
     * Parse an XML description of a KeywordHandler object back into a Java object.
     * @param toParse the XML description to parse.
     * @return the KeywordHandler object that is created.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        int i;
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Vector elemList;                            //element list
        KeywordHandler keywordHandler;              //keyword handler
        KeywordInfo keywordInfo;                    //keyword info
        KeywordInfoParser keywordParser;            //keyword info parser
        
        try
        {
            keywordHandler = null;
            keywordParser = new KeywordInfoParser();
            
            if (toParse.getName().equals(Const.KEYWORDS))
            {
                keywordHandler = new KeywordHandler();
                
                elemList = toParse.getChildren();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);
                    if (nextNode instanceof Element)
                    {
                        nextElem = (Element)nextNode;
                        if (nextElem.getName().equals(Const.KEYWORDINFO) ||
                            nextElem.getName().equals(Const.CONCEPT))
                        {
                            keywordInfo = (KeywordInfo)keywordParser.parse(nextElem);                           
                            keywordHandler.addKeywordList(keywordInfo);
                        }
                    }
                }
            }

            return keywordHandler;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
