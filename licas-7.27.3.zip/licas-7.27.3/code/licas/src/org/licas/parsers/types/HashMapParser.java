/*
 * HashMapParser.java
 *
 * Created on 19 May 2014
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer.
 */

package org.licas.parsers.types;

import org.licas.parsers.Parsers;
import org.licas.util.Const;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;



/**
 * This class parses standard {@code HashMap} structures. This includes parsing nested
 * lists and any objects that they might store.
 * @author Kieran Greer
 */
public class HashMapParser extends ListParser 
{
    /** Creates a new instance of HashMapParser */
    public HashMapParser() {
    }
    
    /**
     * Parse the information to return a list of the values.
     * @param toParse a description of the data.
     * @throws java.lang.Exception any error.
     * @return a HashMap with real values contained.
     */
    public Object parse(Element toParse) throws Exception
    {
        if (isList(HashMap.class, toParse))
            return elementToHashMap(toParse);
        else
            return null;
    }
    
    /**
     * Parse the information to return a HashMap of the values.
     * @param toParse a description of the data.
     * @throws java.lang.Exception any error.
     * @return a HashMap with real values contained.
     */
    private static HashMap elementToHashMap(Element toParse) throws Exception
    {
        HashMap data;                    //the HashMap to store the data in
        
        data = new HashMap();
        elementToHashMap(data, toParse);               
        return data;
    }
    
    /**
     * Parse a HashMap to generate an xml representation.
     * @param toSerialize the data list.
     * @throws java.lang.Exception any error.
     * @return an element if a list or the original object if not a list.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        if ((toSerialize != null) && toSerialize.getClass().getName().equals(HashMap.class.getName()))
        {
            return hashMapToElement((HashMap)toSerialize);
        }
        
        return null;
    }
    
    /**
     * Parse a HashMap to generate an xml representation.
     * @param data the data HashMap.
     * @throws java.lang.Exception any error.
     * @return an xml representation of the list.
     */
    private Element hashMapToElement(HashMap data) throws Exception
    {
        Element rootElem;                   //the root element
        
        rootElem = XMLFactory.getInstance().createElement(Const.PARAMETERS);
        rootElem.setAttribute(Const.CONVERSIONTYPE, HashMap.class.getName());        
        hashMapToElement(data, rootElem);
        
        return rootElem;
    }
    
    /**
     * Parse the information to return a HashMap of the values.
     * @param data the HashMap to store the data in.
     * @param paramXml a description of the {@link Const}.{@code PARAMETER} data.
     * @throws java.lang.Exception any error.
     */
    public static void elementToHashMap(HashMap data, Element paramXml) throws Exception
    {
        int i, j, k;
        boolean dataAdded;                          //true if data added
        String nextKey;                             //next key
        String nextType;                            //next data type
        String nextValue;                           //next data value
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Element nextElem3;                          //next element
        Element nextElem4;                          //next element
        Vector elemList;                            //child elements
        Vector elemList2;                           //child elements
        Vector elemList3;                           //child elements
        Vector elemList4;                           //child elements
        
        try 
        {        
            elemList = paramXml.getChildren();            
            for (i=0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;                    
                    if (nextElem.getName().equalsIgnoreCase(Const.KEY))
                    {
                        nextKey = nextElem.getAttributeValue(Const.NAME);
                        
                        elemList2 = nextElem.getChildren();
                        for (j=0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);                                
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;                            
                                if (nextElem2.getName().equalsIgnoreCase(Const.PARAMETER))
                                {
                                    dataAdded = false;
                                    nextType = null;
                                    nextValue = null;
                                    nextElem3 = null;
                                    elemList4 = null;

                                    elemList3 = nextElem2.getChildren();
                                    for (k=0; k < elemList3.size(); k++)
                                    {
                                        nextNode = (Node)elemList3.get(k);
                                        if (nextNode instanceof Element)                         
                                        {
                                            nextElem3 = (Element)nextNode;
                                            if (nextElem3.getName().equalsIgnoreCase(Const.TYPE))
                                            {
                                                nextType = nextElem3.getValue();
                                            }
                                            else if (nextElem3.getName().equalsIgnoreCase(Const.VALUE))
                                            {
                                                elemList4 = nextElem3.getChildren();
                                                nextValue = nextElem3.getValue();      
                                            }
                                            else
                                            {
                                                data.put(nextKey, Parsers.parse(nextElem3));
                                                dataAdded = true;
                                            }
                                        }
                                    }

                                    if (!dataAdded)
                                    {
                                        nextElem4 = null;
                                        if (elemList4 != null)
                                        {                
                                            for (k=0; k < elemList4.size(); k++)
                                            {
                                                nextNode = (Node)elemList4.get(k);
                                                if (nextNode instanceof Element)
                                                {
                                                    nextElem4 = (Element)nextNode;
                                                    break;
                                                }
                                            }
                                        } 

                                        createAddMapObject(data, nextType, nextKey, 
                                                nextValue, nextElem4);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception ex) {
            throw ex;
        }
    }
    
    /**
     * Parse a HashMap to generate an xml representation.
     * @param data the data HashMap.
     * @param rootElem the root element.
     * @throws java.lang.Exception any error.
     */
    public static void hashMapToElement(HashMap data, Element rootElem) throws Exception
    {
        String nextKey;                     //next key
        Iterator allKeys;                   //all keys
        Element nextElem;                   //next element
        Object nextObj;                     //next object
        
        try 
        {  
            allKeys = data.keySet().iterator();
            while (allKeys.hasNext())
            {
                nextKey = (String)allKeys.next();
                              
                nextElem = XMLFactory.getInstance().createElement(Const.KEY);
                nextElem.setAttribute(Const.NAME, nextKey);
                rootElem.addContent(nextElem);
                
                nextObj = data.get(nextKey);
                Parsers.createParameterElement(nextObj, nextElem);
            }    
        } catch (Exception ex) {
            throw ex;
        }
    }
}
