/*
 * WebServiceMethodInfoParser.java
 *
 * Created on 3 March 2010
 *
 * Version 1.4.1
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.parsers;


import org.ai_heuristic.def.ParserDef;
import org.licas.call.MethodInfo;
import org.licas.util.Const;
import org.licas.ws.WsMethodInfo;
import org.licas_text.util.MetaConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.Vector;


/**
 * This class can be used to parse a {@link WsMethodInfo} object to or from XML.
 * This is an extension of the standard {@link MethodInfo} object that is used instead,
 * for calling web services.
 * @author Kieran Greer
 */
public class WebServiceMethodInfoParser implements ParserDef
{
    /**
     * Create a new instance of WebServiceMethodInfoParser.
     */
    public WebServiceMethodInfoParser()
    {}

    /**
     * Serialize a WsMethodInfo object to XML.
     * @param toSerialize the MethodInfo object to serialize.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        String nextValue;                               //next value
        String[] localWS;                               //locally run ws
        WsMethodInfo methodInfo;                        //method info object
        MethodInfoParser methodInfoParser;              //method info parser
        Element rootElem;                               //root element
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        
        try
        {
            rootElem = null;
            methodInfoParser = new MethodInfoParser();
            methodInfo = (WsMethodInfo)toSerialize;
            rootElem = XMLFactory.getInstance().createElement(Const.WEBSERVICEMETHODINFO);

            nextValue = methodInfo.getWsUsername();
            if (nextValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(MetaConst.USERNAME);
                nextElem.setText(nextValue);
                rootElem.addContent(nextElem);
            }
            
            nextValue = methodInfo.getPassword();
            if (nextValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(MetaConst.PASSWORD);
                nextElem.setText(nextValue);
                rootElem.addContent(nextElem);
            }
            
            nextValue = methodInfo.getSoapWebService();
            if (nextValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.WEBSERVICE);
                nextElem.setText(nextValue);
                rootElem.addContent(nextElem);
            }

            nextValue = methodInfo.getSoapEndpointAddress();
            if (nextValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.ENDPOINT);
                nextElem.setText(nextValue);
                rootElem.addContent(nextElem);
            }

            nextValue = methodInfo.getSoapActionUri();
            if (nextValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.SOAPACTION);
                nextElem.setText(nextValue);
                rootElem.addContent(nextElem);
            }

            nextValue = methodInfo.getNamespace();
            if (nextValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.NAMESPACE);
                nextElem.setText(nextValue);
                rootElem.addContent(nextElem);
            }

            localWS = methodInfo.getLocalWS();
            if (localWS != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.LOCALWS);
                rootElem.addContent(nextElem);

                if (localWS.length > 0) {
                    nextElem2 = XMLFactory.getInstance().createElement(Const.VALUE);
                    nextElem2.setText(localWS[0]);
                    nextElem.addContent(nextElem2);
                }
                if (localWS.length > 1) {
                    nextElem2 = XMLFactory.getInstance().createElement(Const.VALUE);
                    nextElem2.setText(localWS[1]);
                    nextElem.addContent(nextElem2);
                }
                if (localWS.length > 2) {
                    nextElem2 = XMLFactory.getInstance().createElement(Const.VALUE);
                    nextElem2.setText(localWS[2]);
                    nextElem.addContent(nextElem2);
                }
                if (localWS.length > 3) {
                    nextElem2 = XMLFactory.getInstance().createElement(Const.VALUE);
                    nextElem2.setText(localWS[3]);
                    nextElem.addContent(nextElem2);
                }
            }
            
            rootElem.addContent(methodInfoParser.serialize(methodInfo));            
            return rootElem;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /**
     * Parse an XML description of a WsMethodInfo object back into a Java object.
     * @param toParse the XML description to parse.
     * @return the WsMethodInfo object that is created.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        int i, j;
        String username;                                //username
        String password;                                //password
        String webService;                              //web service name
        String endPoint;                                //endpoint address
        String soapAction;                              //soap action
        String namespace;                               //namespace
        String nextValue;                               //next value
        String[] localWS;                               //local web service
        WsMethodInfo methodInfo;                        //method info object
        MethodInfoParser methodInfoParser;              //method info parser
        Node nextNode;                                  //next node
        Element nextElem;                               //next element
        Vector elemList;                                //element list

        try
        {
            methodInfo = null;
            username = null;
            password = null;
            webService = null;
            endPoint = null;
            soapAction = null;
            namespace = null;
            localWS = null;
            methodInfoParser = new MethodInfoParser();

            if (toParse.getName().equals(Const.WEBSERVICEMETHODINFO))
            {
                methodInfo = new WsMethodInfo();
                elemList = toParse.getChildren();

                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);

                    if (nextNode instanceof Element)
                    {
                        nextElem = (Element)nextNode;

                        if (nextElem.getName().equals(Const.UUID) ||
                            nextElem.getName().equals(MetaConst.USERNAME))
                        {
                            username = nextElem.getText();
                        }
                        else if (nextElem.getName().equals(MetaConst.PASSWORD))
                        {
                            password = nextElem.getText();
                        }
                        else if (nextElem.getName().equals(Const.WEBSERVICE))
                        {
                            webService = nextElem.getText();
                        }
                        else if (nextElem.getName().equals(Const.ENDPOINT))
                        {
                            endPoint = nextElem.getText();
                        }
                        else if (nextElem.getName().equals(Const.SOAPACTION))
                        {
                            soapAction = nextElem.getText();
                        }
                        else if (nextElem.getName().equals(Const.NAMESPACE))
                        {
                            namespace = nextElem.getText();
                        }
                        else if (nextElem.getName().equals(Const.LOCALWS))
                        {
                            localWS = new String[nextElem.getChildren().size()];
                            for (j = 0; j < nextElem.getChildren().size(); j++) {
                                nextValue = ((Element) nextElem.getChildren().get(j)).getText();
                                localWS[j] = nextValue;
                            }
                        }
                        else if (nextElem.getName().equals(Const.METHODINFO))
                        {
                            methodInfoParser.parseInfo(nextElem, methodInfo);
                        }
                    }
                }
            }

            if (username != null) methodInfo.setWsUsername(username);
            if (password != null) methodInfo.setPassword(password);
            if (webService != null) methodInfo.setSoapWebService(webService);
            if (endPoint != null) methodInfo.setSoapEndpointAddress(endPoint);
            if (soapAction != null) methodInfo.setSoapActionUri(soapAction);
            if (namespace != null) methodInfo.setNamespace(namespace);
            if (localWS != null) methodInfo.setLocalWS(localWS);

            return methodInfo;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
