/*
 * KD_TreeParser.java
 *
 * Created on 19 February 2016
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.parsers.sci;


import org.ai_heuristic.def.ParserDef;
import org.ai_heuristic.tree.KD_Tree;
import org.ai_heuristic.tree.Tree;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas_xml.abs.Element;


/**
 * This can be used to parse a whole {@link KD_Tree} tree structure, starting from the root tree node.
 * @author Kieran Greer
 */
public class KD_TreeParser implements ParserDef
{
    /** Create a new instance of KD_TreeParser */
    public KD_TreeParser()
    {}

    /**
     * Serialize the object into an XML element.
     * @param toSerialize the object to serialize. Of type {@link KD_Tree}.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        return serialize((Tree)toSerialize);
    }
    
    /**
     * Serialize the object into an XML element.
     * @param tree the Tree to serialize.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(KD_Tree tree) throws Exception
    {
        KD_TreeNodeParser nodeParser;               //tree node parser
        Element rootElem;                           //root element
        
        nodeParser = new KD_TreeNodeParser();
        rootElem = nodeParser.serialize(tree);
        rootElem.setName(AiHeuristicConst.KDTREE);
        
        return rootElem;
    }

    /**
     * Parse the XML element back into a KD_Tree object.
     * @param toParse the element to parse.
     * @return the parsed Tree.
     * @throws java.lang.Exception any error.
     */
    public KD_Tree parse(Element toParse) throws Exception
    {
        KD_Tree tree;                               //tree
        KD_TreeNodeParser nodeParser;               //tree node parser
        Element rootElem;                           //root element
        
        tree = null;
        rootElem = toParse;
        
        if (rootElem.getName().equals(AiHeuristicConst.KDTREE))
        {
            nodeParser = new KD_TreeNodeParser();
            tree = (KD_Tree)nodeParser.parse(rootElem);
        }

        return tree;
    }
}
