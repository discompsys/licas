/*
 * ArrayParser.java
 *
 * Created on 4 March 2014
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer.
 *
 * Author: Kieran Greer
 */

package org.licas.parsers.types;


import org.ai_heuristic.def.ParserDef;
import org.jlog2.util.StringHandler;
import org.licas.util.Const;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;


/**
 * This class parses a String-based representation of an array to or from XML.
 * Only arrays of simple types can be handled - String/Integer/Float/Double/Byte/Boolean.
 * The values should be represented by a single String-based description with brackets at either end.
 * Note that {@code Const.ARRAYSEP} or '|' is used to tokenise each individual element and so you 
 * should always use this class to serialize or parse your array.
 * <p>
 * For example:
 * 1. An array of int's might have a classname of [I and a string value of [1, 2, 3].
 * 2. An array of String's might have a classname of [Ljava.lang.String; and a string value of [str1, str2, str3].
 * @author Kieran Greer
 */
public class ArrayParser implements ParserDef
{
    /** Creates a new instance of ArrayParser */
    public ArrayParser() 
    {}
    
    /**
     * Serialize the array object to XML.
     * @param toSerialize the Array object to serialize.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        int i;
        String arrayType;                           //array type
        String value;                               //param value
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        
        boolean[] boolArray;                        //boolean-based array
        byte[] byteArray;                           //byte-based array
        int[] intArray;                             //int-based array
        float[] floatArray;                         //float-based array
        double[] doubleArray;                       //double-based array
        Boolean[] BoolArray;                        //boolean-based array
        Byte[] ByteArray;                           //byte-based array
        Integer[] IntArray;                         //integer-based array
        Float[] FloatArray;                         //float-based array
        Double[] DoubleArray;                       //double-based array
        String[] stringArray;                       //string-based array
        
        try
        {
            arrayType = toSerialize.getClass().getName();
            value = "[";
            
            rootElem = XMLFactory.getInstance().createElement(Const.PARAMETERS);
            rootElem.setAttribute(Const.CONVERSIONTYPE, arrayType);
            nextElem = XMLFactory.getInstance().createElement(Const.PARAMETER);
            rootElem.addContent(nextElem);
            
            if (arrayType.equals("[Z"))
            {
                boolArray = (boolean[])toSerialize;
                for (i = 0; i < boolArray.length; i++)
                {
                    value += Boolean.toString(boolArray[i]);
                    if (i < boolArray.length-1) value += Const.ARRAYSEP;
                }
            }
            else if (arrayType.equals("[B"))
            {
                byteArray = (byte[])toSerialize;
                for (i = 0; i < byteArray.length; i++)
                {
                    value += Byte.toString(byteArray[i]);
                    if (i < byteArray.length-1) value += Const.ARRAYSEP;
                }
            }
            else if (arrayType.equals("[I"))
            {
                intArray = (int[])toSerialize;
                for (i = 0; i < intArray.length; i++)
                {
                    value += Integer.toString(intArray[i]);
                    if (i < intArray.length-1) value += Const.ARRAYSEP;
                }
            }
            else if (arrayType.equals("[F"))
            {
                floatArray = (float[])toSerialize;
                for (i = 0; i < floatArray.length; i++)
                {
                    value += Float.toString(floatArray[i]);
                    if (i < floatArray.length-1) value += Const.ARRAYSEP;
                }
            }
            else if (arrayType.equals("[D"))
            {
                doubleArray = (double[])toSerialize;
                for (i = 0; i < doubleArray.length; i++)
                {
                    value += Double.toString(doubleArray[i]);
                    if (i < doubleArray.length-1) value += Const.ARRAYSEP;
                }
            }
            else if (arrayType.equals("[Ljava.lang.Boolean;"))
            {
                BoolArray = (Boolean[])toSerialize;
                for (i = 0; i < BoolArray.length; i++)
                {
                    value += Boolean.toString(BoolArray[i].booleanValue());
                    if (i < BoolArray.length-1) value += Const.ARRAYSEP;
                }
            }
            else if (arrayType.equals("[Ljava.lang.Byte;"))
            {
                ByteArray = (Byte[])toSerialize;
                for (i = 0; i < ByteArray.length; i++)
                {
                    value += Byte.toString(ByteArray[i].byteValue());
                    if (i < ByteArray.length-1) value += Const.ARRAYSEP;
                }
            }
            else if (arrayType.equals("[Ljava.lang.Integer;"))
            {
                IntArray = (Integer[])toSerialize;
                for (i = 0; i < IntArray.length; i++)
                {
                    value += Integer.toString(IntArray[i].intValue());
                    if (i < IntArray.length-1) value += Const.ARRAYSEP;
                }
            }
            else if (arrayType.equals("[Ljava.lang.Float;"))
            {
                FloatArray = (Float[])toSerialize;
                for (i = 0; i < FloatArray.length; i++)
                {
                    value += Float.toString(FloatArray[i].floatValue());
                    if (i < FloatArray.length-1) value += Const.ARRAYSEP;
                }
            }
            else if (arrayType.equals("[Ljava.lang.Double;"))
            {
                DoubleArray = (Double[])toSerialize;
                for (i = 0; i < DoubleArray.length; i++)
                {
                    value += Double.toString(DoubleArray[i].doubleValue());
                    if (i < DoubleArray.length-1) value += Const.ARRAYSEP;
                }
            }
            else if (arrayType.equals("[Ljava.lang.String;"))
            {
                stringArray = (String[])toSerialize;
                for (i = 0; i < stringArray.length; i++)
                {
                    value += stringArray[i];
                    if (i < stringArray.length-1) value += Const.ARRAYSEP;
                }
            }
            else 
            {
                stringArray = (String[])toSerialize;
                for (i = 0; i < stringArray.length; i++)
                {
                    value += stringArray[i];
                    if (i < stringArray.length-1) value += Const.ARRAYSEP;
                }
            }
            
            value += "]";
            nextElem.setText(value);
            
            return rootElem;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /**
     * Parse an XML description of an Array back into a Java object.
     * @param toParse the XML description to parse.
     * @return the array object that is created.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        String arrayType;                           //array type
        String value;                               //param value
        
        try
        {
            arrayType = toParse.getAttributeValue(Const.CONVERSIONTYPE);
            value = toParse.getChild(Const.PARAMETER).getText();
            return parseToArray(arrayType, value);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    
    /**
     * Parse an XML description of an Array back into a Java object.
     * @param arrayType type of array to parse.
     * @param arrayValues array description as a string.
     * @return the array object that is created.
     * @throws java.lang.Exception any error.
     */
    public Object parseToArray(String arrayType, String arrayValues) throws Exception
    {
        int i;
        String value;                               //param value
        ArrayList paramValues;                         //list of parameter values
        
        boolean[] boolArray;                        //boolean-based array
        byte[] byteArray;                           //byte-based array
        int[] intArray;                             //int-based array
        float[] floatArray;                         //float-based array
        double[] doubleArray;                       //double-based array
        Boolean[] BoolArray;                        //boolean-based array
        Byte[] ByteArray;                           //byte-based array
        Integer[] IntArray;                         //integer-based array
        Float[] FloatArray;                         //float-based array
        Double[] DoubleArray;                       //double-based array
        String[] stringArray;                       //string-based array
        
        try
        {
            //this should be a vector-style string, such as [v1, v2]
            paramValues = new ArrayList();
            
            if (arrayValues.startsWith("[")) arrayValues = arrayValues.substring(1);
            if (arrayValues.endsWith("]")) arrayValues = arrayValues.substring(0, arrayValues.length()-1);
            paramValues = StringHandler.tokenize(arrayValues, Const.ARRAYSEP, false);
                
            if (arrayType.equals("[Z"))
            {
                boolArray = new boolean[paramValues.size()];
                for (i = 0; i < paramValues.size(); i++)
                {
                    value = (String)paramValues.get(i);
                    boolArray[i] = Boolean.getBoolean(value.trim());
                }
                
                return boolArray;
            }
            else if (arrayType.equals("[B"))
            {
                byteArray = new byte[paramValues.size()];
                for (i = 0; i < paramValues.size(); i++)
                {
                    value = (String)paramValues.get(i);
                    byteArray[i] = Byte.parseByte(value.trim());
                }
                
                return byteArray;
            }
            else if (arrayType.equals("[I"))
            {
                intArray = new int[paramValues.size()];
                for (i = 0; i < paramValues.size(); i++)
                {
                    value = (String)paramValues.get(i);
                    intArray[i] = Integer.parseInt(value.trim());
                }
                
                return intArray;
            }
            else if (arrayType.equals("[F"))
            {
                floatArray = new float[paramValues.size()];
                for (i = 0; i < paramValues.size(); i++)
                {
                    value = (String)paramValues.get(i);
                    floatArray[i] = Float.parseFloat(value.trim());
                }
                
                return floatArray;
            }
            else if (arrayType.equals("[D"))
            {
                doubleArray = new double[paramValues.size()];
                for (i = 0; i < paramValues.size(); i++)
                {
                    value = (String)paramValues.get(i);
                    doubleArray[i] = Double.parseDouble(value.trim());
                }
                
                return doubleArray;
            }
            else if (arrayType.equals("[Ljava.lang.Boolean;"))
            {
                BoolArray = new Boolean[paramValues.size()];
                for (i = 0; i < paramValues.size(); i++)
                {
                    value = (String)paramValues.get(i);
                    BoolArray[i] = Boolean.valueOf(value.trim());
                }
                
                return BoolArray;
            }
            else if (arrayType.equals("[Ljava.lang.Byte;"))
            {
                ByteArray = new Byte[paramValues.size()];
                for (i = 0; i < paramValues.size(); i++)
                {
                    value = (String)paramValues.get(i);
                    ByteArray[i] = Byte.valueOf(value.trim());
                }
                
                return ByteArray;
            }
            else if (arrayType.equals("[Ljava.lang.Integer;"))
            {
                IntArray = new Integer[paramValues.size()];
                for (i = 0; i < paramValues.size(); i++)
                {
                    value = (String)paramValues.get(i);
                    IntArray[i] = Integer.getInteger(value.trim());
                }
                
                return IntArray;
            }
            else if (arrayType.equals("[Ljava.lang.Float;"))
            {
                FloatArray = new Float[paramValues.size()];
                for (i = 0; i < paramValues.size(); i++)
                {
                    value = (String)paramValues.get(i);
                    FloatArray[i] = Float.valueOf(value.trim());
                }
                
                return FloatArray;
            }
            else if (arrayType.equals("[Ljava.lang.Double;"))
            {
                DoubleArray = new Double[paramValues.size()];
                for (i = 0; i < paramValues.size(); i++)
                {
                    value = (String)paramValues.get(i);
                    DoubleArray[i] = Double.valueOf(value.trim());
                }
                
                return DoubleArray;
            }
            else if (arrayType.equals("[Ljava.lang.String;"))
            {
                stringArray = new String[paramValues.size()];
                for (i = 0; i < paramValues.size(); i++)
                {
                    value = (String)paramValues.get(i);
                    stringArray[i] = String.valueOf(value.trim());
                }
                
                return stringArray;
            }
            else 
            {
                stringArray = new String[paramValues.size()];
                for (i = 0; i < paramValues.size(); i++)
                {
                    value = (String)paramValues.get(i);
                    stringArray[i] = String.valueOf(value.trim());
                }
                
                return stringArray;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
