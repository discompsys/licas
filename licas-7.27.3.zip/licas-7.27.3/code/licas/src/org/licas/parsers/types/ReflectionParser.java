/*
 * ReflectionParser.java
 *
 * Created on 17 January 2009
 *
 * Version 1.5
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers.types;


import org.ai_heuristic.util.SymbolHandler;
import org.jlog2.util.StringHandler;
import org.licas.Service;
import org.licas.call.MethodInfo;
import org.licas.call.ParamInfo;
import org.licas.util.Const;
import org.licas.util.ObjectHandler;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Vector;


/**
 * This class parses objects created through reflection. For example, convert a
 * {@code java.lang.Reflect} {@code Method} or {@code Constructor} object into an XML-based description.
 * @author Kieran Greer
 */
public class ReflectionParser 
{
    /** List of methods from the base Object type */
    public static final ArrayList objectMethods;
    
    /** List of methods from the base Service type that might be useful */
    public static final ArrayList defaultMethods;
    
    /** List of methods names the base Service type that might be useful */
    private static final ArrayList defaultMethodNames;
    
    static
    {
        int i;
        Method[] methods;
        
        defaultMethodNames = new ArrayList();
        defaultMethodNames.add("getUUID");
        defaultMethodNames.add("getFullPath");
        defaultMethodNames.add("getThreadState");
        defaultMethodNames.add("getDescription");
        defaultMethodNames.add("getServiceType");
        defaultMethodNames.add("getServiceNames");
        defaultMethodNames.add("getServiceTypes");
              
        //create a list of Object and Thread methods not to be returned
        objectMethods = new ArrayList();
        methods = getMethods(Object.class);
        for (i = 0; i < methods.length; i++)
        {
            objectMethods.add(methods[i].getName());
        }
        
        methods = getMethods(Thread.class);
        for (i = 0; i < methods.length; i++)
        {
            objectMethods.add(methods[i].getName());
        }
        
        //create a list of default methods that might be useful
        defaultMethods = new ArrayList();
        methods = getMethods(Service.class);
        for (i = 0; i < methods.length; i++)
        {
            if (defaultMethodNames.contains(methods[i].getName()))
            {
                defaultMethods.add(methods[i]);
            }
        }
    }
    
    /**
     * Create a new instance of ReflectionParser.
     */
    public ReflectionParser()
    {}
    
    /**
     * Retrieve the constructors for the specified class.
     * @param theClass the class instance.
     * @return a list of constructors.
     */
    public static Constructor[] getConstructors(Class theClass)
    {
        return theClass.getConstructors();
    }

    /**
     * Retrieve a list of all public methods in the class.
     * @param theClass the class instance.
     * @return a list of all public methods.
     */
    public static Method[] getMethods(Class theClass)
    {
        return theClass.getMethods();
    }
    
    /**
     * Check all constructors to see if any match the input parameters or super classes
     * of the input psarameters.
     * @param constructors a list of constructors.
     * @param paramTypes the parameter type classes.
     * @return the constructor that matches the input parameters. 
     */
    public static Constructor getConstructor(Constructor[] constructors, Class[] paramTypes)
    {
        boolean isOK;                           //true if params OK
        int i, j;
        Constructor nextConstructor;            //next constructor
        Constructor theConstructor;             //the correct constructor
        Class[] conParams;                      //constructor parameters

        theConstructor = null;

        for (i = 0; i < constructors.length; i++)
        {
            nextConstructor = constructors[i];
            conParams = nextConstructor.getParameterTypes();

            if (conParams.length == paramTypes.length)
            {
                isOK = true;
                for (j=0; j < conParams.length; j++)
                {
                    if (!ObjectHandler.classInstance(conParams[j], paramTypes[j]))
                    {
                        isOK = false;
                        break;
                    }
                }

                if (isOK)
                {
                    theConstructor = nextConstructor;
                    break;
                }
            }
        }

        return theConstructor;
    }
    
    /**
     * Create an element to describe the constructor that is passed in.
     * @param constructor the constructor description from a reflection
     * @return the constructor info in XML format.
     */
    public static Element constructorToXML(Constructor constructor)
    {
        int i;
        Class[] paramTypes;                 //parameter types
        ArrayList tokens;                      //token list
        Element rootElem;                   //root element
        Element nextElem;                   //next element
        Element nextElem2;                  //next element
        Element nextElem3;                  //next element
        
        rootElem = XMLFactory.getInstance().createElement(Const.CONSTRUCTOR);
        
        nextElem = XMLFactory.getInstance().createElement(Const.METHODNAME);
        tokens = StringHandler.tokenize(constructor.getName(), ".", false);
        nextElem.setText((String)tokens.get(tokens.size()-1));
        rootElem.addContent(nextElem);
        
        paramTypes = constructor.getParameterTypes();
        if (paramTypes.length > 0)
        {
            nextElem = XMLFactory.getInstance().createElement(Const.PARAMETERS);
            rootElem.addContent(nextElem);
            
            for (i=0; i < paramTypes.length; i++)
            { 
                nextElem2 = XMLFactory.getInstance().createElement(Const.NEXTPARAMETER);
                nextElem.addContent(nextElem2);
                
                nextElem3 = XMLFactory.getInstance().createElement(Const.PARAMETERTYPE);
                nextElem3.setText(paramTypes[i].getName());
                nextElem2.addContent(nextElem3);
            }
        }
        
        return rootElem;
    }
    
    /**
     * Create a shortened element to describe the constructor that is passed in.
     * @param constructor the constructor description from a reflection
     * @return the constructor info in XML format.
     */
    public static Element constructorToShortXML(Constructor constructor)
    {
        int i;
        Class[] paramTypes;                 //parameter types
        ArrayList tokens;                      //token list
        Element rootElem;                   //root element
        Element nextElem;                   //next element
        
        rootElem = XMLFactory.getInstance().createElement(Const.CONSTRUCTOR);
        
        nextElem = XMLFactory.getInstance().createElement(Const.METHODNAME);
        tokens = StringHandler.tokenize(constructor.getName(), ".", false);
        nextElem.setText((String)tokens.get(tokens.size()-1));
        rootElem.addContent(nextElem);
        
        paramTypes = constructor.getParameterTypes();
        if (paramTypes.length > 0)
        {
            for (i=0; i < paramTypes.length; i++)
            { 
                nextElem = XMLFactory.getInstance().createElement(Const.PARAMETERTYPE);
                nextElem.setText(paramTypes[i].getName());
                rootElem.addContent(nextElem);
            }
        }
        
        return rootElem;
    }
    
    /**
     * Create an element to describe the method that is passed in.
     * @param method the method description from a reflection process.
     * @return the method info in XML format.
     */
    public static Element methodToXML(Method method)
    {
        return ReflectionParser.methodToXML(method, null);
    }
    
    /**
     * Create an element to describe the method that is passed in.
     * @param method the method description from a reflection process.
     * @param paramNames a list of names to assign to each method parameter. They get added
     * in the order that they are specified. If null then the name field does not get added.
     * @return the method info in XML format.
     */
    public static Element methodToXML(Method method, ArrayList paramNames)
    {
        int i;
        Class[] paramTypes;                     //parameter types
        ArrayList pNames;                          //list of parameter names
        Element rootElem;                       //root element
        Element nextElem;                       //next element
        Element nextElem2;                      //next element
        Element nextElem3;                      //next element
        
        if (paramNames == null) pNames = new ArrayList();
        else pNames = paramNames;
        
        rootElem = XMLFactory.getInstance().createElement(Const.METHOD);
        
        nextElem = XMLFactory.getInstance().createElement(Const.METHODNAME);
        nextElem.setText(method.getName());
        rootElem.addContent(nextElem);
        
        nextElem = XMLFactory.getInstance().createElement(Const.RETURNTYPE);
        nextElem.setText(method.getReturnType().getName());   
        rootElem.addContent(nextElem);
        
        paramTypes = method.getParameterTypes();
        if (paramTypes.length > 0)
        {
            nextElem = XMLFactory.getInstance().createElement(Const.PARAMETERS);
            rootElem.addContent(nextElem);
            
            for (i = 0; i < paramTypes.length; i++)
            { 
                nextElem2 = XMLFactory.getInstance().createElement(Const.NEXTPARAMETER);
                nextElem.addContent(nextElem2);
                
                if (pNames.size() > i)
                {
                    nextElem3 = XMLFactory.getInstance().createElement(Const.PARAMETERNAME);
                    nextElem3.setText((String)pNames.get(i));
                    nextElem2.addContent(nextElem3);
                }
                
                nextElem3 = XMLFactory.getInstance().createElement(Const.PARAMETERTYPE);
                nextElem3.setText(paramTypes[i].getName());
                nextElem2.addContent(nextElem3);
            }
        }
        
        return rootElem;
    }
    
    /**
     * Create a shortened element to describe the method that is passed in.
     * @param method the method description from a reflection
     * @return the method info in XML format.
     */
    public static Element methodToShortXML(Method method)
    {
        int i;
        Class[] paramTypes;                 //parameter types
        Element rootElem;                   //root element
        Element nextElem;                   //next element
        
        rootElem = XMLFactory.getInstance().createElement(Const.METHOD);
        
        nextElem = XMLFactory.getInstance().createElement(Const.METHODNAME);
        nextElem.setText(method.getName());
        rootElem.addContent(nextElem);
        
        nextElem = XMLFactory.getInstance().createElement(Const.RETURNTYPE);
        nextElem.setText(method.getReturnType().getName());   
        rootElem.addContent(nextElem);
        
        paramTypes = method.getParameterTypes();
        if (paramTypes.length > 0)
        {
            for (i=0; i < paramTypes.length; i++)
            { 
                nextElem = XMLFactory.getInstance().createElement(Const.PARAMETERTYPE);
                nextElem.setText(paramTypes[i].getName());
                rootElem.addContent(nextElem);
            }
        }
        
        return rootElem;
    }
    
    /**
     * Create a MethodInfo object from the XML description.
     * @param methodXml the method description.
     * @return the method info object constructed from the description.
     * @throws java.lang.Exception any error.
     */
    public static MethodInfo xmlToMethod(Element methodXml) throws Exception
    {
        int i, j, k;
        MethodInfo method;                      //method object
        ParamInfo paramInfo;                    //parameter info
        Node nextNode;                          //next node
        Element nextElem;                       //next element
        Element nextElem2;                      //next element
        Element nextElem3;                      //next element
        Vector elemList;                        //element list
        Vector elemList2;                       //element list
        Vector elemList3;                       //element list
        
        
        method = new MethodInfo();
        
        elemList = methodXml.getChildren();
        for (i = 0; i < elemList.size(); i++)
        {
            nextNode = (Node)elemList.get(i);
            
            if (nextNode instanceof Element)
            {
                nextElem = (Element)nextNode;
                
                if (nextElem.getName().equals(Const.METHODNAME))
                {
                    method.setName(nextElem.getText());
                }
                else if (decodeParameterName(method.getName(),
                        nextElem.getName()).equals(Const.RETURNTYPE))
                {
                    if (nextElem.hasChildren())
                    {
                        nextElem2 = nextElem.getChild(Const.PARAMETERTYPE);
                        if (nextElem2 != null)
                        {
                            method.setRtnType(nextElem2.getText());
                        }
                    }
                    else
                    {
                        method.setRtnType(nextElem.getText());
                    }
                }
                else if (nextElem.getName().equals(Const.PARAMETERS))
                {
                    elemList2 = nextElem.getChildren();
                    for (j = 0; j < elemList2.size(); j++)
                    {
                        nextNode = (Node)elemList2.get(j);
                        if (nextNode instanceof Element)
                        {
                            nextElem2 = (Element)nextNode;
                            if (nextElem2.getName().equals(Const.NEXTPARAMETER))
                            {
                                paramInfo = new ParamInfo();
                                
                                elemList3 = nextElem2.getChildren();
                                for (k = 0; k < elemList3.size(); k++)
                                {
                                    nextNode = (Node)elemList3.get(k);
                                    if (nextNode instanceof Element)
                                    {
                                        nextElem3 = (Element)nextNode;
                                        if (nextElem3.getName().equals(Const.PARAMETERNAME))
                                        {
                                            paramInfo.setName(nextElem3.getText());
                                        }
                                        else if (nextElem3.getName().equals(Const.PARAMETERTYPE))
                                        {
                                            paramInfo.setType(nextElem3.getText());
                                        }
                                    }
                                }
                                
                                method.addParam(paramInfo);
                            }
                        }
                    }
                }
                else if (nextElem.getName().equals(Const.PARAMETERTYPE))
                {
                    method.addParam(new ParamInfo(nextElem.getText()));
                }
            }
        }
        
        return method;
    }
    
    /**
     * Convert the class names into a formatted version for displaying.
     * @param theClassName the fully qualified class name with path details.
     * @return a formatted version of the form 'class name (class path)'.
     */
    public static String formatClassName(String theClassName)
    {
        int index;                              //index
        String newClassDescr;                   //new class description
        
        newClassDescr = "";
            
        index = theClassName.lastIndexOf(".");
        newClassDescr = theClassName.substring(index + 1, theClassName.length());
        newClassDescr += " (" + theClassName.substring(0, index) + ")";
        
        return newClassDescr;
    }
    
    /**
     * Convert the formatted classname back to its binary form.
     * @param serviceClass the current service class specification.
     * @return the serviceClass value converted back to the binary form.
     */
    public static String unformatClassName(String serviceClass)
    {
        String theClassName;            //the converted class name
        
        theClassName = StringHandler.replaceAll(serviceClass, ".class", "").trim();
        theClassName = StringHandler.replaceAll(theClassName, "class ", "").trim();
        theClassName = StringHandler.replaceAll(theClassName, "/", ".");
        
        return theClassName;
    }
    
    /**
     * Code the parameter name if required to make it unique. This version checks
     * for a return type parameter and adds the method name if it is, otherwise it
     * does nothing.
     * @param methodName the method name.
     * @param paramName the parameter name.
     * @return the coded name.
     */
    public static String codeParameterName(String methodName, String paramName)
    {
        String formattedName;                       //the formatted name
        
        formattedName = paramName;
        if (formattedName != null)
        {
            formattedName = (methodName + SymbolHandler.US + formattedName);
        }
        
        return formattedName;
    }
    
    /**
     * Decode the parameter name if required. This version checks for a return type
     * parameter and removes any other text if it is, otherwise it does nothing.
     * @param methodName the method name.
     * @param paramName the parameter name.
     * @return the formatted method name.
     */
    public static String decodeParameterName(String methodName, String paramName)
    {
        String formattedName;                       //the formatted name
        
        formattedName = paramName;
        if (formattedName != null)
        {
            methodName = (methodName + SymbolHandler.US);    
            formattedName = StringHandler.replaceFirst(formattedName, methodName, "");
        }
        
        return formattedName;
    }
}
