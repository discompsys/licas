/*
 * WorkInfoParser.java
 *
 * Created on 5 February 2018
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer.
 */

package org.licas.parsers;


import org.ai_heuristic.def.ParserDef;
import org.licas.call.MethodInfo;
import org.licas.def.ContractDef;
import org.licas.service.model.KeywordInfo;
import org.licas.service.model.WorkInfo;
import org.licas.util.Const;
import org.licas.util.MetaConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.Vector;


/**
 * This class parses a {@link WorkInfo} representation to or from XML.
 * @author Kieran Greer
 */
public class WorkInfoParser implements ParserDef
{
    /** Creates a new instance of WorkInfoParser */
    public WorkInfoParser() {
    }
    
    /**
     * Serialize a WorkInfo object to XML.
     * @param toSerialize the WorkInfo object to serialize.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        WorkInfo workInfo;                          //the info to serialize
        KeywordInfoParser keyParser;                //keyword parser
        MethodInfoParser methodParser;              //method parser
        ContractParser contractParser;              //contract parser
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        
        try
        {
            rootElem = XMLFactory.getInstance().createElement(MetaConst.WORKINFO);
            if (toSerialize instanceof WorkInfo)
            {
                workInfo = (WorkInfo)toSerialize;

                nextElem = XMLFactory.getInstance().createElement(Const.PROTOCOL);
                nextElem.setText(String.valueOf(workInfo.workProtocol));
                rootElem.addContent(nextElem);

                if (workInfo.info != null)
                {
                    nextElem = XMLFactory.getInstance().createElement(Const.DATA);
                    nextElem.setText(String.valueOf(workInfo.info));
                    rootElem.addContent(nextElem);
                }

                if (workInfo.keywordInfo != null)
                {
                    keyParser = new KeywordInfoParser();
                    nextElem = keyParser.serialize(workInfo.keywordInfo);
                    rootElem.addContent(nextElem);
                }

                if (workInfo.methodInfo != null)
                {
                    methodParser = new MethodInfoParser();
                    nextElem = methodParser.serialize(workInfo.methodInfo);
                    rootElem.addContent(nextElem);
                }
                
                if (workInfo.contract != null)
                {
                    contractParser = new ContractParser();
                    nextElem = contractParser.serialize(workInfo.contract);
                    rootElem.addContent(nextElem);
                }

                nextElem = XMLFactory.getInstance().createElement(Const.VALUE);
                nextElem.setText(String.valueOf(workInfo.score));
                rootElem.addContent(nextElem);
            }
            
            return rootElem;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /**
     * Parse an XML description of a WorkInfo object back into a Java object.
     * @param toParse the XML description to parse.
     * @return the WorkInfo object that is created.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        int i;
        String nextValue;                           //next value
        WorkInfo workInfo;                          //the info to serialize
        KeywordInfoParser keyParser;                //keyword parser
        MethodInfoParser methodParser;              //method parser
        ContractParser contractParser;              //contract parser
        Node nextNode;                              //next node
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        Vector elemList;                            //element list
        
        try
        {
            workInfo = null;
            if (toParse != null)
            {
                rootElem = toParse;
                if (rootElem.getName().equals(MetaConst.WORKINFO))
                {
                    workInfo = new WorkInfo();
                    
                    elemList = rootElem.getChildren();
                    for (i = 0; i < elemList.size(); i++)
                    {
                        nextNode = (Node)elemList.elementAt(i);
                        if (nextNode instanceof Element)
                        {
                            nextElem = (Element)nextNode;
                            if (nextElem.getName().equals(Const.PROTOCOL))
                            {
                                nextValue = nextElem.getText();
                                workInfo.workProtocol = Integer.parseInt(nextValue);
                            }
                            else if (nextElem.getName().equals(Const.DATA))
                            {
                                nextValue = nextElem.getText();
                                workInfo.info = nextValue;
                            }
                            else if (nextElem.getName().equals(Const.KEYWORDINFO))
                            {
                                keyParser = new KeywordInfoParser();
                                workInfo.keywordInfo = (KeywordInfo)keyParser.parse(nextElem);
                            }
                            else if (nextElem.getName().equals(Const.METHODINFO))
                            {
                                methodParser = new MethodInfoParser();
                                workInfo.methodInfo = (MethodInfo)methodParser.parse(nextElem);
                            }
                            else if (nextElem.getName().equals(MetaConst.CONTRACT))
                            {
                                contractParser = new ContractParser();
                                workInfo.contract = (ContractDef)contractParser.parse(nextElem);
                            }
                            else if (nextElem.getName().equals(Const.VALUE))
                            {
                                nextValue = nextElem.getText();
                                workInfo.score = Float.parseFloat(nextValue);
                            }
                        }
                    }
                }
            }

            return workInfo;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
