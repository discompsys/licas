/*
 * TreeNodeParser.java
 *
 * Created on 28 September 2013
 *
 * Version 1.2.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.parsers.sci;


import org.ai_heuristic.def.ParserDef;
import org.ai_heuristic.eval.metric.MetricDataset;
import org.ai_heuristic.tree.Tree;
import org.ai_heuristic.tree.TreeNode;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas.parsers.Parsers;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;
import java.util.Vector;


/**
 * This can be used to parse a {@link TreeNode} node in a tree structure, although the root tree node
 * is parsed using {@link TreeParser}.
 * @author Kieran Greer
 */
public class TreeNodeParser implements ParserDef
{
    /** Create a new instance of TreeNodeParser */
    public TreeNodeParser()
    {}

    /**
     * Serialize the object into an XML element.
     * @param toSerialize the object to serialize. Of type {@link TreeNode}.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        return serialize((TreeNode)toSerialize);
    }
    
    /**
     * Serialize the object into an XML element.
     * @param treeNode the node to serialize.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(TreeNode treeNode) throws Exception
    {
        int i;
        String nextKey;                             //next key
        ArrayList keyList;                             //list of keys
        TreeNode nextTreeNode;                      //next tree node
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        
        rootElem = XMLFactory.getInstance().createElement(AiHeuristicConst.TREENODE);
        if (treeNode.getName() != null) rootElem.setAttribute(AiHeuristicConst.NAME, treeNode.getName()); 
        if (treeNode.getValueType() != null) rootElem.setAttribute(AiHeuristicConst.TYPE, treeNode.getValueType()); 
        
        if (treeNode.getValue() != null)
        {
            nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.VALUE);
            nextElem.addContent((Element)Parsers.serializeToElement(treeNode.getValue()));
            rootElem.addContent(nextElem);
        }
        
        nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.COUNT);
        nextElem.setText(String.valueOf(treeNode.getCount()));
        rootElem.addContent(nextElem);
            
        keyList = treeNode.getChildNodeKeys();
        for (i = 0; i < keyList.size(); i++)
        {
            nextKey = (String)keyList.get(i);
            nextTreeNode = (TreeNode) treeNode.getChildNode(nextKey);
            rootElem.addContent(serialize(nextTreeNode));
        }

        return rootElem;
    }

    /**
     * Parse the XML element back into a TreeNode object.
     * @param toParse the element to parse.
     * @return the parsed tree node.
     * @throws java.lang.Exception any error.
     */
    public TreeNode parse(Element toParse) throws Exception
    {
        int i;
        String name;                                //node name
        String valueType;                           //node value type
        Object nodeValue;                           //the node value
        TreeNode treeNode;                          //tree node
        Node nextNode;                              //next element node
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        Vector elemList;                            //element list
        
        treeNode = null;
        rootElem = toParse;
        
        if (rootElem.getName().equals(AiHeuristicConst.TREE) ||
            rootElem.getName().equals(AiHeuristicConst.TREENODE))
        {
            name = rootElem.getAttributeValue(AiHeuristicConst.NAME);
            valueType = rootElem.getAttributeValue(AiHeuristicConst.TYPE);
            
            if (rootElem.getName().equals(AiHeuristicConst.TREE))
                treeNode = new Tree(name, valueType);
            else
                treeNode = new TreeNode(name, valueType);
            
            elemList = rootElem.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(AiHeuristicConst.VALUE))
                    {
                        nodeValue = Parsers.parse(nextElem.getElementChildAtIndex(0));
                        treeNode.setValue(MetricDataset.toDataset(nodeValue));
                    }
                    else if (nextElem.getName().equals(AiHeuristicConst.COUNT))
                    {
                        treeNode.setCount(Float.parseFloat(nextElem.getText()));
                    }
                    else
                    {
                        treeNode.addChildNode(parse(nextElem));
                    }
                }
            }
        }

        return treeNode;
    }
}
