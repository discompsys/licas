/**
 * Default parsers to process the objects that licas services may use.
 */
package org.licas.parsers;