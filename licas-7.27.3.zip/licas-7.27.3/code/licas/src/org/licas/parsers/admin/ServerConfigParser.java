/*
 * ServerConfigParser.java
 *
 * Created on 27 September 2014
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.parsers.admin;


import org.licas.server.model.ServerConfig;
import org.licas.util.Const;
import org.licas.util.ServiceConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.Vector;


/**
 * This can parse a {@link ServerConfig} object that contains server configuration information.
 * @author Kieran Greer
 */
public class ServerConfigParser
{
    /** Create a new instance of ServerConfigParser */
    public ServerConfigParser()
    {}

    /**
     * Serialize the object into an XML element.
     * @param serverConfig the server configuration information.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(ServerConfig serverConfig) throws Exception
    {
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        
        rootElem = XMLFactory.getInstance().createElement(ServiceConst.SERVERCONFIG);       
        
        nextElem = XMLFactory.getInstance().createElement(Const.PORT);
        nextElem.setText(Integer.toString(serverConfig.getServerPort()));
        rootElem.addContent(nextElem);
        
        if ((serverConfig.getServerIP() != null) && !serverConfig.getServerIP().equals(""))
        {
            nextElem = XMLFactory.getInstance().createElement(Const.SERVERADDRESS);
            nextElem.setText(serverConfig.getServerIP());
            rootElem.addContent(nextElem);
        }
        
        nextElem = XMLFactory.getInstance().createElement(Const.SERVICEPASSWORD);
        nextElem.setText(serverConfig.getServerPassword());
        rootElem.addContent(nextElem);
        
        nextElem = XMLFactory.getInstance().createElement(Const.SERVICEKEY);
        nextElem.setText(serverConfig.getServerAdminKey());
        rootElem.addContent(nextElem);
        
        if ((serverConfig.getServerContact() != null) && !serverConfig.getServerContact().equals(""))
        {
            nextElem = XMLFactory.getInstance().createElement(Const.SERVERCONTACT);
            nextElem.setText(serverConfig.getServerContact());
            rootElem.addContent(nextElem);
        }
        
        nextElem = XMLFactory.getInstance().createElement(Const.PASSWORDSREQUIRED);
        nextElem.setText(String.valueOf(serverConfig.getPasswordsRequired()));
        rootElem.addContent(nextElem);
        
        nextElem = XMLFactory.getInstance().createElement(Const.ASHTTPS);
        nextElem.setText(String.valueOf(serverConfig.getAsHttps()));
        rootElem.addContent(nextElem);

        return rootElem;
    }

    /**
     * Parse the XML element back into the appropriate Object.
     * @param toParse the element to parse.
     * @return the parsed gui classname lists.
     * @throws java.lang.Exception any error.
     */
    public ServerConfig parse(Element toParse) throws Exception
    {
        int i;
        boolean boolValue;                          //boolean value
        String nextValue;                           //next value
        ServerConfig serverConfig;                  //server info
        Node nextNode;                              //next node
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        Vector elemList;                            //element list
        
        
        serverConfig = new ServerConfig();
        rootElem = toParse;

        if (rootElem.getName().equals(ServiceConst.SERVERCONFIG) ||
            rootElem.getName().equals(Const.SERVER))
        {
            elemList = rootElem.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(Const.PORT))
                    {
                        serverConfig.setServerPort(Integer.parseInt(nextElem.getText()));
                    }
                    else if (nextElem.getName().equals(Const.SERVERADDRESS))
                    {
                        serverConfig.setServerIP(nextElem.getText());
                    }
                    else if (nextElem.getName().equals(Const.SERVICEPASSWORD))
                    {
                        serverConfig.setServerPassword(nextElem.getText());
                    }
                    else if (nextElem.getName().equals(Const.SERVICEKEY))
                    {
                        serverConfig.setServerAdminKey(nextElem.getText());
                    }
                    else if (nextElem.getName().equals(Const.SERVERCONTACT))
                    {
                        serverConfig.setServerContact(nextElem.getText());
                    }
                    else if (nextElem.getName().equals(Const.PASSWORDSREQUIRED))
                    {
                        nextValue = nextElem.getText();
                        boolValue = Boolean.valueOf(nextValue).booleanValue();
                        serverConfig.setPasswordsRequired(boolValue);
                    }
                    else if (nextElem.getName().equals(Const.ASHTTPS))
                    {
                        nextValue = nextElem.getText();
                        boolValue = Boolean.valueOf(nextValue).booleanValue();
                        serverConfig.setAsHttps(boolValue);
                    }
                }
            }
        }

        return serverConfig;
    }
}
