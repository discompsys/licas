/*
 * NodeStatsParser.java
 *
 * Created on 18 February 2016
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.parsers.sci;


import org.ai_heuristic.def.ParserDef;
import org.ai_heuristic.model.NodeStats;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas.parsers.Parsers;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.Vector;


/**
 * This can be used to parse a {@link NodeStats} object to or from XML.
 * This stores some stats for a balanced tree node, for example.
 * @author Kieran Greer
 */
public class NodeStatsParser implements ParserDef
{
    /** Create a new instance of NodeStatsParser */
    public NodeStatsParser()
    {}

    /**
     * Serialize the object into an XML element.
     * @param toSerialize the object to serialize. Of type {@link NodeStats}.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        NodeStats nodeStats;                    //node stats
        Element rootElem;                       //root element
        Element nextElem;                       //next element
        
        nodeStats = (NodeStats)toSerialize;
        
        rootElem = XMLFactory.getInstance().createElement(AiHeuristicConst.STATS);
        if (nodeStats.minValue != null)
        {
            nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.MIN);
            nextElem.addContent((Element)Parsers.serializeToElement(nodeStats.minValue));
            rootElem.addContent(nextElem);
        }
        if (nodeStats.maxValue != null)
        {
            nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.MAX);
            nextElem.addContent((Element)Parsers.serializeToElement(nodeStats.maxValue));
            rootElem.addContent(nextElem);
        }
        
        return rootElem;
    }

    /**
     * Parse the XML element back into a NodeStats object.
     * @param toParse the element to parse.
     * @return the parsed stats object.
     * @throws java.lang.Exception any error.
     */
    public NodeStats parse(Element toParse) throws Exception
    {
        int i;
        Object value;                               //value
        NodeStats nodeStats;                        //node stats
        Node nextNode;                              //next element node
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        Vector elemList;                            //element list
        
        nodeStats = new NodeStats();
        rootElem = toParse;
        
        if (rootElem.getName().equals(AiHeuristicConst.STATS))
        {
            elemList = rootElem.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(AiHeuristicConst.MIN))
                    {
                        value = Parsers.parse(nextElem.getElementChildAtIndex(0));
                        nodeStats.minValue = value;
                    }
                    else if (nextElem.getName().equals(AiHeuristicConst.MAX))
                    {
                        value = Parsers.parse(nextElem.getElementChildAtIndex(0));
                        nodeStats.maxValue = value;
                    }
                }
            }
        }

        return nodeStats;
    }
}
