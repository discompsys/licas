/*
 * SecurityManagerParser.java
 *
 * Created on 2 January 2014
 *
 * Version 1.0.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers.admin;


import org.licas.security.FilePermission;
import org.licas.security.PermissionsList;
import org.licas.security.SecurityWebManager;
import org.licas.util.Const;
import org.licas.util.MetaConst;
import org.licas_text.util.QueryConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;


/**
 * This provides methods to parse security settings, for the {@link SecurityWebManager}, to of from XML.
 * @author Kieran Greer
 */
public class SecurityManagerParser
{
    /**
     * Create a new instance of SecurityManagerParser.
     */
    public SecurityManagerParser()
    {}
    
    /**
     * Serialise the object of type SecurityWebManager into XML.
     * @param swManager the SecurityWebManager to serialize.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(SecurityWebManager swManager) throws Exception
    {
        int i;
        String permissionType;                          //permission type
        String permissionKey;                           //permission key
        Iterator permissionTypes;                       //stored permission types
        Iterator permissionKeys;                        //permission keys
        HashMap swPermissions;                        //security/web permissions
        PermissionsList permissionsList;                //permissions list
        FilePermission filePermission;                  //local file permission
        Element rootElem;                               //root element
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        Element nextElem3;                              //next element
        
        try
        {
            swPermissions = swManager.getLocalPermissions();
            rootElem = XMLFactory.getInstance().createElement(MetaConst.SECURITYMANAGER);
            
            if (!swPermissions.isEmpty())
            {
                nextElem = XMLFactory.getInstance().createElement(MetaConst.PERMISSIONS);
                rootElem.addContent(nextElem);
                
                permissionTypes = swPermissions.keySet().iterator();
                while (permissionTypes.hasNext())
                {
                    permissionType = (String)permissionTypes.next();
                    permissionsList = (PermissionsList)swPermissions.get(permissionType);
                    
                    permissionKeys = permissionsList.keySet().iterator();                   
                    while (permissionKeys.hasNext())
                    {
                        permissionKey = (String)permissionKeys.next();
                        if (permissionType.equals(MetaConst.FILEPERMISSION))
                        {
                            filePermission = (FilePermission)permissionsList.get(permissionKey);
                            
                            nextElem2 = XMLFactory.getInstance().createElement(MetaConst.NEXTPERMISSION);                      
                            nextElem2.setAttribute(Const.TYPE, permissionType);
                            nextElem.addContent(nextElem2);
                            
                            nextElem3 = XMLFactory.getInstance().createElement(QueryConst.FILEPATH);                      
                            nextElem3.setText(filePermission.folderPath);
                            nextElem2.addContent(nextElem3);
                            
                            for (i = 0; i < filePermission.permissions.size(); i++)
                            {
                                nextElem3 = XMLFactory.getInstance().createElement(Const.ACCESS);                      
                                nextElem3.setText((String)filePermission.permissions.get(i));
                                nextElem2.addContent(nextElem3);
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return rootElem;
    }

    /**
     * Parse the XML description back into the SecurityWebManager object. This is
     * created and stored as a global static instance and so no value is returned.
     * @param toParse the XML description to parse.
     * @throws java.lang.Exception any error.
     */
    public void parse(Element toParse) throws Exception
    {
        int i, j, k;
        String permissionType;                          //permission type
        String permissionKey;                           //permission key
        String permissionValue;                         //permission value
        SecurityWebManager swManager;                   //security web manager
        Node nextNode;                                  //next node
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        Element nextElem3;                              //next element
        Vector elemList;                                //element list
        Vector elemList2;                               //element list
        Vector elemList3;                               //element list
        
        
        swManager = SecurityWebManager.getInstance();
        try
        {
            if ((toParse != null) && toParse.getName().equals(MetaConst.SECURITYMANAGER))
            {
                elemList = toParse.getChildren();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);
                    if (nextNode instanceof Element)
                    {
                        nextElem = (Element)nextNode;
                        if (nextElem.getName().equals(MetaConst.PERMISSIONS))
                        {
                            elemList2 = nextElem.getChildren();
                            for (j = 0; j < elemList2.size(); j++)
                            {
                                nextNode = (Node)elemList2.get(j);
                                if (nextNode instanceof Element)
                                {
                                    nextElem2 = (Element)nextNode;
                                    if (nextElem2.getName().equals(MetaConst.NEXTPERMISSION))
                                    {
                                        permissionType = nextElem2.getAttributeValue(Const.TYPE);
                                        permissionKey = null;
                                        permissionValue = null;
                                        
                                        elemList3 = nextElem2.getChildren();
                                        for (k = 0; k < elemList3.size(); k++)
                                        {
                                            nextNode = (Node)elemList3.get(k);
                                            if (nextNode instanceof Element)
                                            {
                                                nextElem3 = (Element)nextNode;
                                                if (nextElem3.getName().equals(QueryConst.FILEPATH))
                                                {
                                                    permissionKey = nextElem3.getText();
                                                }
                                                else if (nextElem3.getName().equals(Const.ACCESS))
                                                {
                                                    permissionValue = nextElem3.getText();
                                                    if (permissionKey != null)
                                                    {
                                                        swManager.addPermission(permissionType, permissionKey, permissionValue);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
