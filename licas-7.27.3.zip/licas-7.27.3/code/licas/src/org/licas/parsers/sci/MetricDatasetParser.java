/*
 * MetricDatasetParser.java
 *
 * Created on 18 February 2016
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.parsers.sci;


import org.ai_heuristic.def.ParserDef;
import org.ai_heuristic.eval.metric.MetricDataset;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas.parsers.Parsers;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * This can be used to parse a {@link MetricDataset} object to or from XML.
 * Any stored value is cast only to a String, so complex objects are not included.
 * @author Kieran Greer
 */
public class MetricDatasetParser implements ParserDef
{
    /** Create a new instance of MetricDatasetParser */
    public MetricDatasetParser()
    {}

    /**
     * Serialize the object into an XML element.
     * @param toSerialize the object to serialize. Of type {@link MetricDataset}.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        MetricDataset metricDataset;            //metric dataset
        Element rootElem;                       //root element
        Element nextElem;                       //next element
        
        metricDataset = (MetricDataset)toSerialize;
        
        rootElem = XMLFactory.getInstance().createElement(AiHeuristicConst.METRICDATASET);
        if (metricDataset.getName() != null)
        {
            rootElem.setAttribute(AiHeuristicConst.NAME, metricDataset.getName());        
        }
        
        nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.VALUETYPE);
        nextElem.setText(metricDataset.getValueType());
        rootElem.addContent(nextElem);
        nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.VALUE);
        nextElem.addContent(Parsers.serializeToElement(metricDataset.getData()));
        rootElem.addContent(nextElem);
        nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.PARAMLIST);
        nextElem.addContent(Parsers.serializeToElement(metricDataset.getParams()));
        rootElem.addContent(nextElem);
        
        return rootElem;
    }

    /**
     * Parse the XML element back into a MetricValue object.
     * @param toParse the element to parse.
     * @return the parsed Tree.
     * @throws java.lang.Exception any error.
     */
    public MetricDataset parse(Element toParse) throws Exception
    {
        String name;                            //value name
        String type;                            //value type
        Object value;                           //value
        MetricDataset metricDataset;            //the metric dataset
        Element rootElem;                       //root element
        Element nextElem;                       //next element
        
        name = null;
        type = null;
        metricDataset = null;
        rootElem = toParse;
        
        if (rootElem.getName().equals(AiHeuristicConst.METRICDATASET))
        {
            name = rootElem.getAttributeValue(AiHeuristicConst.NAME);
            nextElem = rootElem.getChild(AiHeuristicConst.VALUETYPE);
            if (nextElem != null)
            {
                type = nextElem.getText();
            }
            
            nextElem = rootElem.getChild(AiHeuristicConst.VALUE);
            if (nextElem != null)
            {
                //assumes an outer vector
                value = Parsers.parse(nextElem.getElementChildAtIndex(0));
                metricDataset = MetricDataset.toDataset(name, type, (ArrayList)value);
            }
            nextElem = rootElem.getChild(AiHeuristicConst.PARAMLIST);
            if (nextElem != null)
            {
                //assumes an outer vector
                value = Parsers.parse(nextElem.getElementChildAtIndex(0));
                if (metricDataset != null) 
                {
                    metricDataset.setParams((HashMap)value);
                }
            }
        }

        return metricDataset;
    }
}
