/*
 * ElementParser.java
 *
 * Created on 28 March 2007
 *
 * Version 1.4
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers.types;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.util.Const;
import org.licas_text.util.XmlHtmlHandler;
import org.licas_xml.abs.*;
import org.licas_xml.model.XmlHandler;

import java.util.ArrayList;
import java.util.Vector;


/**
 * This parses an xml {@link Element} to or from a String.
 * @author Kieran Greer
 */
public class ElementParser 
{
    /** The logger */
    private static Logger logger;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ElementParser.class.getName());
        logger.setDebug(false);
    }

    
    /** Creates a new instance of ElementParser */
    public ElementParser() 
    {}
    
    /**
     * Remove the element prefixes and return.
     * @param xmlStr the string to remove prefixes from.
     * @return the modified string.
     */
    public static String replaceElementSpecs(String xmlStr)
    {
        xmlStr = XmlHandler.removeElementSpecs(xmlStr);
        return xmlStr;
    }
    
    /**
     * Add an attribute to the element with the specified values.
     * @param attributeName the attribute name.
     * @param attributeValue the attribute value.
     * @param elemObj the xml element.
     */
    public static void setAttribute(String attributeName, String attributeValue, 
            Element elemObj)
    {
        elemObj.setAttribute(attributeName, attributeValue);
    }
    
    /**
     * Get an attribute value from the element with the specified name.
     * @param attributeName the attribute name.
     * @param elemObj the xml element.
     * @return the attribute value.
     */
    public static String getAttributeValue(String attributeName, Element elemObj)
    {
        return elemObj.getAttributeValue(attributeName);
    }
    
    /**
     * Get a value from a nested element with the {@link Const}.{@code PARAMETER} 
     * name and a {@code VALUE} element inside of that. If this is missing, then 
     * return null.
     * @param elemObj the xml element with the nested parameter element.
     * @return the value as a String.
     * @throws java.lang.Exception any error.
     */
    public static String getParameterValue(Element elemObj) throws Exception
    {
        Element xmlElem;                        //xml element
        Element valueElem;                      //value element
               
        xmlElem = elemObj;
        valueElem = xmlElem.getChild(Const.PARAMETER);
        if (valueElem != null)
        {
            valueElem = valueElem.getChild(Const.VALUE);
            if (valueElem != null)
            {
                return valueElem.getValue();
            }
        }
        
        return null;
    }
    
    /**
     * Convert an xml element into the format as specified by the class name.
     * @param elemObj an xml element to parse.
     * @param className the class name of the object to create.
     * @return the converted xml element.
     * @throws java.lang.Exception any error.
     */
    public static Object convertToElementClass(Element elemObj, String className)
            throws Exception
    {
        String xmlStr;                          //xml as string
        Object rtnElem;                         //return element

        if (elemObj.getClass().getName().equals(className))
        {
            //if an element, then detach description from parent
            rtnElem = (Element)elemObj.detach();
        }
        else 
        {
            //convert XML elements into String-based equivalent
            xmlStr = serializeNextElement((Node)elemObj);
            xmlStr = XmlHandler.addElementSpec(xmlStr);
            rtnElem = parse(xmlStr);
        }

        return rtnElem;
    }
    
    /**
     * Parse the xml String to return the xml element.
     * @param xmlStr a description of the data.
     * @return the xml elements or the original String if not xml.
     * @throws java.lang.Exception any error.
     */
    public static Object parse(String xmlStr) throws Exception
    {
        String encXmlStr;                   //encoded xml string
        Object rootElement = null;          //root element
        Document document;                  //document

        if (XmlHandler.isElementSpec(xmlStr))
        {
            try
            {
                xmlStr = replaceElementSpecs(xmlStr);
                document = XMLFactory.getInstance().createDocument();
                rootElement = document.parse(xmlStr);
            }
            catch (Exception ex)
            {
                try {
                    //do a check that the element values need encoding first
                    encXmlStr = XmlHtmlHandler.encodeXmlContent(xmlStr);
                    document = XMLFactory.getInstance().createDocument();
                    rootElement = document.parse(encXmlStr);
                }
                catch (Exception ex2) {
                    ExceptionHandler.handleException(logger, LoggerHandler.WARN, "parse",
                            null, ex);

                    rootElement = xmlStr;
                }
            }
        }
        else {
            rootElement = xmlStr;
        }

        return rootElement;
    }
    
    /**
     * Convert the object into an XML-based String.
     * @param nextObj the xml element to convert.
     * @return the xml element converted into a String.
     * @throws java.lang.Exception any error.
     */
    public static String serialize(Element nextObj) throws Exception
    {
        String meta;                        //String-based version of the XML

        meta = serializeNextElement((Node)nextObj);
        meta = XmlHandler.addElementSpec(meta);
        return meta;
    }
    
    /**
     * Convert an xml element and its subelements into String format.
     * @param rootElem the root element.
     * @return the root and subelements in String format.
     * @throws java.lang.Exception any error.
     */
    protected static String serializeNextElement(Node rootElem) throws Exception
    {
        int i;
        String nextValue;                       //next value
        String xmlAsStr;                        //xml as string
        Attribute nextAttribute;                //next attribute
        Node nextNode;                          //next node
        Element nextElem;                       //next element
        ArrayList attrList;                     //attribute list
        Vector elemList;                        //child elements
                
        xmlAsStr = "";
        nextElem = (Element)rootElem;
        xmlAsStr += XmlHandler.LT_TAG + rootElem.getName();

        attrList = (ArrayList)nextElem.getAttributeList();
        for (i = 0; i < attrList.size(); i++)
        {               
            nextAttribute = (Attribute)attrList.get(i);
            xmlAsStr += " " + nextAttribute.getName() + "=\"" +
                    XmlHtmlHandler.encodeXml(nextAttribute.getValue()) + "\"";
        }
        
        xmlAsStr += XmlHandler.GT_TAG;
            
        if (!rootElem.hasChildren())
        {
            nextValue = rootElem.getValue();
            if (nextValue != null)
            {
                xmlAsStr += XmlHtmlHandler.encodeXml(nextValue);
            }
        }
        else
        {  
            elemList = nextElem.getChildren();
            for (i=0; i < elemList.size(); i++)
            {               
                nextNode = (Node)elemList.get(i);
                xmlAsStr += serializeNextElement(nextNode);
            }
        }
        
        xmlAsStr += XmlHandler.END_LT_TAG + rootElem.getName() + XmlHandler.GT_TAG;
        return xmlAsStr;
    }
}
