/**
 * Parsers for processing the admin metadata scripts.
 */
package org.licas.parsers.admin;