/*
 * MethodInfoParser.java
 *
 * Created on 18 June 2009
 *
 * Version 1.2.3
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.parsers;


import org.ai_heuristic.def.ParserDef;
import org.licas.call.MethodInfo;
import org.licas.call.ParamInfo;
import org.licas.parsers.types.ArrayListParser;
import org.licas.parsers.types.ReflectionParser;
import org.licas.util.Const;
import org.licas_text.util.MetaConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;
import java.util.Vector;


/**
 * This class can be used to parse a {@link MethodInfo} object to or from XML.
 * @author Kieran Greer
 */
public class MethodInfoParser implements ParserDef
{
    /**
     * Create a new instance of MethodInfoParser.
     */
    public MethodInfoParser()
    {}

    /**
     * Serialize a MethodInfo object to XML.
     * @param toSerialize the MethodInfo object to serialize.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        int i;
        int packetSize;                             //packet size
        int callTimeout;                            //call timeout
        String stringValue;                         //string value
        Element elementValue;                       //element value
        ArrayList params;                           //parameter list
        ArrayList paramValues;                      //parameter values
        ParamInfo nextParam;                        //next parameter
        MethodInfo methodInfo;                      //method info object
        ArrayListParser arrParser;                  //list parser
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        
        try
        {
            arrParser = new ArrayListParser();
            methodInfo = (MethodInfo)toSerialize;
            rootElem = XMLFactory.getInstance().createElement(Const.METHODINFO);

            packetSize = methodInfo.getPacketSize();
            nextElem = XMLFactory.getInstance().createElement(Const.PACKETSIZE);
            nextElem.setText(String.valueOf(packetSize));
            rootElem.addContent(nextElem);

            callTimeout = methodInfo.getCallTimeout();
            nextElem = XMLFactory.getInstance().createElement(Const.TIMEOUT);
            nextElem.setText(String.valueOf(callTimeout));
            rootElem.addContent(nextElem);

            nextElem = XMLFactory.getInstance().createElement(Const.ISREMOTE);
            nextElem.setText(Boolean.toString(methodInfo.getIsRemote()));
            rootElem.addContent(nextElem);

            stringValue = methodInfo.getCallType();
            nextElem = XMLFactory.getInstance().createElement(Const.CALLTYPE);
            nextElem.setText(stringValue);
            rootElem.addContent(nextElem);

            stringValue = methodInfo.getName();
            if (stringValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.NAME);
                nextElem.setText(stringValue);
                rootElem.addContent(nextElem);
            }

            stringValue = methodInfo.getRtnType();
            if (stringValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.RETURNTYPE);
                nextElem.setText(stringValue);
                rootElem.addContent(nextElem);
            }

            stringValue = methodInfo.getServiceRtnType();
            if (stringValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.SERVICERETURNTYPE);
                nextElem.setText(stringValue);
                rootElem.addContent(nextElem);
            }

            stringValue = methodInfo.getServerPassword();
            if (stringValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.SERVERPASSWORD);
                nextElem.setText(stringValue);
                rootElem.addContent(nextElem);
            }

            stringValue = methodInfo.getPassword();
            if (stringValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(MetaConst.PASSWORD);
                nextElem.setText(stringValue);
                rootElem.addContent(nextElem);
            }

            stringValue = methodInfo.getCommunicationID();
            if (stringValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.COMMUNICATIONID);
                nextElem.setText(stringValue);
                rootElem.addContent(nextElem);
            }

            elementValue = methodInfo.getClientURI();
            if (elementValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.CLIENTURI);
                nextElem.addContent((Element)elementValue.clone());
                rootElem.addContent(nextElem);
            }

            elementValue = (Element)methodInfo.getServiceURI();
            if ((elementValue != null) && (elementValue instanceof Element))
            {
                nextElem = XMLFactory.getInstance().createElement(Const.SERVICEURI);
                nextElem.addContent((Element)elementValue.clone());
                rootElem.addContent(nextElem);
            }

            elementValue = methodInfo.getRestOfServiceURI();
            if (elementValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.RESTOFSERVICEURI);
                nextElem.addContent((Element)elementValue.clone());
                rootElem.addContent(nextElem);
            }

            params = methodInfo.getParams();
            if (params.size() > 0)
            {
                paramValues = new ArrayList();
                for (i = 0; i < params.size(); i++)
                {
                    nextParam = (ParamInfo)params.get(i);
                    paramValues.add(nextParam.getValue());
                }

                nextElem = arrParser.serialize(paramValues);
                if (nextElem != null) rootElem.addContent(nextElem);
            }

            return rootElem;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /**
     * Parse an XML description of a MethodInfo object back into a Java object.
     * @param toParse the XML description to parse.
     * @return the MethodInfo object that is created.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        MethodInfo methodInfo;                          //method info object

        methodInfo = new MethodInfo();
        parseInfo(toParse, methodInfo);

        return methodInfo;
    }

    /**
     * Parse an XML description of a MethodInfo object back into a Java object.
     * @param toParse the XML description to parse.
     * @param methodInfo the method info object to place the parsed content in.
     * @throws java.lang.Exception any error.
     */
    public void parseInfo(Element toParse, MethodInfo methodInfo) throws Exception
    {
        int i, j;
        int packetSize;                             //packet size
        int callTimeout;                            //call timeout
        ArrayList paramValues;                      //parameter values
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Vector elemList;                            //element list
        ArrayListParser arrParser;                  //arraylist parser
        

        try
        {
            arrParser = new ArrayListParser();
            if (toParse.getName().equals(Const.METHODINFO))
            {
                elemList = (Vector)toParse.getChildren().clone();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);

                    if (nextNode instanceof Element)
                    {
                        nextElem = (Element)nextNode;

                        if (nextElem.getName().equals(Const.PACKETSIZE))
                        {
                            packetSize = Integer.parseInt(nextElem.getText());
                            methodInfo.setPacketSize(packetSize);
                        }
                        else if (nextElem.getName().equals(Const.TIMEOUT))
                        {
                            callTimeout = Integer.parseInt(nextElem.getText());
                            methodInfo.setCallTimeout(callTimeout);
                        }
                        else if (nextElem.getName().equals(Const.CALLTYPE))
                        {
                            methodInfo.setCallType(nextElem.getText());
                        }
                        else if (nextElem.getName().equals(Const.NAME))
                        {
                            methodInfo.setName(nextElem.getText());
                        }
                        else if (ReflectionParser.decodeParameterName(methodInfo.getName(),
                                nextElem.getName()).equals(Const.RETURNTYPE))
                        {
                            methodInfo.setRtnType(nextElem.getText());
                        }
                        else if (nextElem.getName().equals(Const.SERVICERETURNTYPE))
                        {
                            methodInfo.setServiceRtnType(nextElem.getText());
                        }
                        else if (nextElem.getName().equals(Const.SERVERPASSWORD))
                        {
                            methodInfo.setServerPassword(nextElem.getText());
                        }
                        else if (nextElem.getName().equals(MetaConst.PASSWORD))
                        {
                            methodInfo.setPassword(nextElem.getText());
                        }
                        else if (nextElem.getName().equals(Const.COMMUNICATIONID))
                        {
                            methodInfo.setCommunicationID(nextElem.getText());
                        }
                        else if (nextElem.getName().equals(Const.CLIENTURI))
                        {
                            if (nextElem.getChildrenCount() > 0)
                                methodInfo.setClientURI((Element)nextElem.getElementChildAtIndex(0).detach());
                        }
                        else if (nextElem.getName().equals(Const.SERVICEURI))
                        {
                            if (nextElem.getChildrenCount() > 0)
                                methodInfo.setServiceURI((Element)nextElem.getElementChildAtIndex(0).detach());
                        }
                        else if (nextElem.getName().equals(Const.RESTOFSERVICEURI))
                        {
                            if (nextElem.getChildrenCount() > 0)
                                methodInfo.setRestOfServiceURI((Element)nextElem.getElementChildAtIndex(0).detach());
                        }
                        else if (nextElem.getName().equals(Const.PARAMETERS))
                        {
                            paramValues = (ArrayList)arrParser.parse(nextElem);
                            for (j = 0; j < paramValues.size(); j++)
                            {
                                methodInfo.addParam(new ParamInfo(paramValues.get(j)));
                            }
                        }
                    }
                }
            }

            methodInfo.setIfRemote();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
