/*
 * AdminParser.java
 *
 * Created on 17 January 2009
 *
 * Version 1.7.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers.admin;


import org.licas.AdminInfo;
import org.licas.parsers.types.ReflectionParser;
import org.licas.util.*;
import org.licas_xml.abs.*;

import java.util.*;


/**
 * This class can be used to parse the administrator's xml description of a service.
 * This class accepts the XML-based admin document description and creates an {@link AdminInfo}
 * object from it.
 * @author Kieran Greer
 */
public class AdminParser
{ 
    /**
     * Create a new instance of AdminParser.
     */
    public AdminParser()
    {}

    /**
     * Serialize the admin info object into an XML-based description.
     * @param adminInfo the admin info object to serialize.
     * @return an xml-based description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(AdminInfo adminInfo) throws Exception
    {
        int i;
        String uuid;                                    //the service uuid
        String serviceType;                             //the service type
        String filePath;                                //the admin doc file path
        String nextKey;                                 //next key
        ArrayList<String> allKeys;                      //list of keys
        Element description;                            //the service description
        Element autoManAdmin;                           //the auto man config
        Element serviceLevelAdmin;                      //the service level agreements config
        Element loadServices;                           //services to load metadata
        Element serializeVars;                          //variables to serialize
        Element rootElem;                               //root element
        Element serviceElem;                            //services element
        Element nextElem;                               //next element
        HashMap<String, Element> accessLevels;          //the access levels

        rootElem = XMLFactory.getInstance().createElement(MetaConst.ADMIN);
        serviceElem = XMLFactory.getInstance().createElement(Const.SERVICES);

        uuid = adminInfo.getUuid();
        if ((uuid != null) && !uuid.equals(""))
        {
            nextElem = XMLFactory.getInstance().createElement(Const.UUID);
            nextElem.setText(uuid);
            rootElem.addContent(nextElem);
        }

        serviceType = adminInfo.getType();
        if ((serviceType != null) && !serviceType.equals(""))
        {
            nextElem = XMLFactory.getInstance().createElement(Const.SERVICETYPE);
            nextElem.setText(serviceType);
            rootElem.addContent(nextElem);
        }

        serviceType = adminInfo.getCategory();
        if ((serviceType != null) && !serviceType.equals(""))
        {
            nextElem = XMLFactory.getInstance().createElement(Const.SERVICECATEGORY);
            nextElem.setText(serviceType);
            rootElem.addContent(nextElem);
        }

        filePath = adminInfo.getAdminFilePath();
        if ((filePath != null) && !filePath.equals(""))
        {
            nextElem = XMLFactory.getInstance().createElement(Const.FILEURI);
            nextElem.setText(filePath);
            rootElem.addContent(nextElem);
        }

        nextElem = XMLFactory.getInstance().createElement(Const.METAACCESSALLOWED);
        nextElem.setText(Boolean.toString(adminInfo.getMetaAccessAllowed()));
        rootElem.addContent(nextElem);
        nextElem = XMLFactory.getInstance().createElement(Const.NESTEDACCESSALLOWED);
        nextElem.setText(Boolean.toString(adminInfo.getNestedAccessAllowed()));
        rootElem.addContent(nextElem);

        description = adminInfo.getDescription();
        if (description != null)
        {
            nextElem = XMLFactory.getInstance().createElement(Const.DESCRIPTION);
            nextElem.addContent((Element)description.clone());
            rootElem.addContent(nextElem);
        }

        accessLevels = adminInfo.getAccessLevels();
        allKeys = adminInfo.getLevelOrder();
        for (i = 0; i < allKeys.size(); i++)
        {
            nextKey = allKeys.get(i);
            nextElem = accessLevels.get(nextKey);
            serviceElem.addContent((Element)nextElem.clone());
        }

        if (serviceElem.hasChildren()) rootElem.addContent(serviceElem);
        serviceLevelAdmin = adminInfo.getServicelevelContracts();
        if (serviceLevelAdmin != null)
        {
            serviceLevelAdmin = (Element)serviceLevelAdmin.clone();
            rootElem.addContent(serviceLevelAdmin);
        }

        autoManAdmin = adminInfo.getAutonomicManagerAdmin();
        if (autoManAdmin != null)
        {
            autoManAdmin = (Element)autoManAdmin.clone();
            rootElem.addContent(autoManAdmin);
        }

        loadServices = adminInfo.getLoadServices();
        if (loadServices != null)
        {
            loadServices = (Element)loadServices.clone();
            rootElem.addContent(loadServices);
        }

        serializeVars = adminInfo.getSerializeValues();
        if (serializeVars != null)
        {
            serializeVars = (Element)serializeVars.clone();
            rootElem.addContent(serializeVars);
        }

        //additional includes metadata and data descriptions
        allKeys = new ArrayList<>(adminInfo.getAdditional().keySet());
        for (i = 0; i < allKeys.size(); i++)
        {
            nextKey = allKeys.get(i);
            nextElem = adminInfo.getAdditional().get(nextKey);
            rootElem.addContent((Element)nextElem.clone());
        }

        return rootElem;
    }
    
    /**
     * Parse the XML description to determine the admin specification.
     * @param adminXml the XML description to parse.
     * @return the parsed admin information.
     * @throws java.lang.Exception any error.
     */
    public AdminInfo parse(Element adminXml) throws Exception
    {
        int i, j, k, l;
        boolean metaAccessAllowed;                      //true if meta access is allowed
        boolean nestedAccessAllowed;                    //true if nested access is allowed
        boolean descriptionFound;                       //true if the description is found
        String uuid;                                    //the service uuid
        String serviceType;                             //the service type
        String serviceCategory;                         //the service category
        String filePath;                                //the admin doc file path
        String levelType;                               //the level type
        String nextLevel;                               //next level type
        String levelPassword;                           //the level password
        String nextGroup;                               //next group
        ArrayList<String> groupLevels;                  //group levels
        ArrayList<String> levelOrder;                   //the level order
        HashMap<String, String> levelGroups;            //levels with their groups
        HashMap<String, String> levelPasswords;         //the level passwords
        HashMap<String, Element> accessLevels;          //the access levels
        HashMap<String, ArrayList<String>> allGroups;   //all groups
        HashMap<String, ArrayList<String>> allExclude;  //all excluded levels
        HashMap<String, Element> additional;            //additional elements
        AdminInfo adminInfo;                            //the admin info
        Element description;                            //the service description
        Element autoManAdmin;                           //the auto man config
        Element serviceLevelAdmin;                      //the service level agreements config
        Element loadServices;                           //child services metadata
        Element instanceValues;                         //variable instance values
        Element serializeValues;                        //variable serialize values
        Node nextNode;                                  //next node
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        Element nextElem3;                              //next element
        Element nextElem4;                              //next element
        Vector elemList;                                //element list
        Vector elemList2;                               //element list
        Vector elemList3;                               //element list
        Vector elemList4;                               //element list
        
        adminInfo = null;
        uuid = null;
        metaAccessAllowed = true;
        nestedAccessAllowed = true;
        serviceType = null;
        serviceCategory = null;
        filePath = null;
        description = null;
        serviceLevelAdmin = null;
        autoManAdmin = null;
        loadServices = null;
        instanceValues = null;
        serializeValues = null;
        levelOrder = new ArrayList<>();
        levelGroups = new HashMap<>();
        levelPasswords = new HashMap<>();
        accessLevels = new HashMap<>();
        allGroups = new HashMap<>();
        allExclude = new HashMap<>();
        additional = new HashMap<>();

        if (adminXml != null)
        {
            adminInfo = new AdminInfo();

            elemList = (Vector)adminXml.getChildren().clone();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(Const.UUID))
                    {
                        uuid = nextElem.getText();
                    }
                    else if (nextElem.getName().equals(Const.SERVICETYPE))
                    {
                        serviceType = nextElem.getText();
                    }
                    else if (nextElem.getName().equals(Const.SERVICECATEGORY))
                    {
                        serviceCategory = nextElem.getText();
                    }
                    else if (nextElem.getName().equals(Const.FILEURI))
                    {
                        filePath = nextElem.getText();
                    }
                    else if (nextElem.getName().equals(Const.METAACCESSALLOWED))
                    {
                        metaAccessAllowed = Boolean.valueOf(nextElem.getText());
                    }
                    else if (nextElem.getName().equals(Const.NESTEDACCESSALLOWED))
                    {
                        nestedAccessAllowed = Boolean.valueOf(nextElem.getText());
                    }
                    else if (nextElem.getName().equals(Const.DESCRIPTION))
                    {
                        if (nextElem.hasChildren())
                        {
                            descriptionFound = false;
                            elemList2 = nextElem.getChildren();
                            for (j = 0; !descriptionFound && (j < elemList2.size()); j++)
                            {
                                nextNode = (Node)elemList2.get(j);
                                if (nextNode instanceof Element)
                                {
                                    description = (Element)nextNode.clone();
                                    descriptionFound = true;
                                }
                            }
                        }
                        else
                        {
                            description = (Element)nextElem.clone();
                        }
                    }
                    else if (nextElem.getName().equals(Const.SERVICES))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equals(Const.SERVICESTOLOAD))
                                {
                                    loadServices = nextElem2;
                                }
                                else if (nextElem2.getName().equals(Const.ACCESSLEVEL))
                                {
                                    levelType = nextElem2.getAttributeValue(Const.LEVELTYPE);
                                    levelOrder.add(levelType);

                                    if (levelType.equals(Const.GLOBAL))
                                        levelPassword = Const.ANON;
                                    else
                                        levelPassword = nextElem2.getAttributeValue(MetaConst.PASSWORD);

                                    levelPasswords.put(levelType, levelPassword);
                                    accessLevels.put(levelType, (Element)nextElem2.clone());

                                    elemList3 = nextElem2.getChildren();
                                    for (k = 0; k < elemList3.size(); k++)
                                    {
                                        nextNode = (Node)elemList3.get(k);
                                        if (nextNode instanceof Element)
                                        {
                                            nextElem3 = (Element)nextNode;
                                            if (nextElem3.getName().equals(Const.GROUP))
                                            {
                                                elemList4 = nextElem3.getChildren();
                                                for (l = 0; l < elemList4.size(); l++)
                                                {
                                                    nextNode = (Node)elemList4.get(l);
                                                    if (nextNode instanceof Element)
                                                    {
                                                        nextElem4 = (Element)nextNode;
                                                        if (nextElem4.getName().equals(Const.NAME))
                                                        {
                                                            nextGroup = nextElem4.getValue();
                                                            if (allGroups.containsKey(nextGroup))
                                                            {
                                                                groupLevels = allGroups.get(nextGroup);
                                                            }
                                                            else
                                                            {
                                                                groupLevels = new ArrayList<>();
                                                                allGroups.put(nextGroup, groupLevels);
                                                            }

                                                            groupLevels.add(levelType);
                                                            levelGroups.put(levelType, nextGroup);
                                                        }
                                                        else if (nextElem4.getName().equals(Const.EXCLUDE))
                                                        {
                                                            nextLevel = nextElem4.getValue();
                                                            if (allExclude.containsKey(levelType))
                                                            {
                                                                groupLevels = allExclude.get(levelType);
                                                            }
                                                            else
                                                            {
                                                                groupLevels = new ArrayList<>();
                                                                allExclude.put(levelType, groupLevels);
                                                            }

                                                            groupLevels.add(nextLevel);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else if (nextElem.getName().equals(MetaConst.SERVICELEVELCONTRACTS))
                    {
                        serviceLevelAdmin = (Element)nextElem.detach();
                    }
                    else if (nextElem.getName().equals(AiConst.AUTONOMICMANAGER))
                    {
                        autoManAdmin = (Element)nextElem.detach();
                    }
                    else if (nextElem.getName().equals(Const.INSTANCEVALUES))
                    {
                        instanceValues = (Element)nextElem.detach();
                    }
                    else if (nextElem.getName().equals(Const.SERIALISEVALUES))
                    {
                        serializeValues = (Element)nextElem.detach();
                    }
                    else if (!AdminInfo.isDistinctAdminTag(nextElem.getName()))
                    {
                        additional.put(nextElem.getName(), (Element)nextElem.detach());
                    }
                }
            }

            adminInfo.setUuid(uuid);
            adminInfo.setType(serviceType);
            adminInfo.setCategory(serviceCategory);
            adminInfo.setAdminFilePath(filePath);
            adminInfo.setMetaAccessAllowed(metaAccessAllowed);
            adminInfo.setNestedAccessAllowed(nestedAccessAllowed);
            adminInfo.setDescription(description);
            adminInfo.setAutonomicManagerAdmin(autoManAdmin);
            adminInfo.setServiceLevelContracts(serviceLevelAdmin);
            adminInfo.setLoadServices(loadServices);
            adminInfo.setInstanceValues(instanceValues);
            adminInfo.setSeializeValues(serializeValues);
            adminInfo.setLevelOrder(levelOrder);
            adminInfo.setLevelPasswords(levelPasswords);
            adminInfo.setAccessLevels(accessLevels);
            adminInfo.setLevelGroups(levelGroups);
            adminInfo.setAllGroups(allGroups);
            adminInfo.setAllExclude(allExclude);
            adminInfo.getAdditional().putAll(additional);
        }
        
        return adminInfo;
    }
    
    /**
     * Return true if the access info passed in contains a match to the method info.
     * @param accessXml an xml description of the access level.
     * @param methodXml an xml description of the method.
     * @return true if the method spec is contained in the access level spec.
     */
    public static boolean isAccessLevel(Element accessXml, Element methodXml)
    {
        int i;
        boolean isAccessLevel;                          //true if is access level
        Node nextNode;                                  //next node
        Element nextElem;                               //next element
        Vector elemList;                                //element list
        
        isAccessLevel = false;
        
        if (accessXml.getName().equals(Const.ACCESSLEVEL))
        {
            elemList = accessXml.getChildren();
            for (i = 0; !isAccessLevel && (i < elemList.size()); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(Const.METHOD))
                    {
                        isAccessLevel = methodsMatch(nextElem, methodXml);
                    }
                }
            }
        }
        
        return isAccessLevel;
    }
    
    /**
     * Return true if the two xml method descriptions are the same.
     * @param methodXml the first XML method description.
     * @param methodXml2 the second XML method description.
     * @return true if the two descriptions match.
     */
    public static boolean methodsMatch(Element methodXml, Element methodXml2)
    {
        int i, j, k;
        boolean match;                                  //true if match
        String methodName;                              //the method name
        String methodName2;                             //the method name
        String rtnType;                                 //the return type
        String rtnType2;                                //the return type
        ArrayList<String> paramTypes;                   //parameter types
        ArrayList<String> paramTypes2;                  //parameter types
        Node nextNode;                                  //next node
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        Element nextElem3;                              //next element
        Vector elemList;                                //element list
        Vector elemList2;                               //element list
        Vector elemList3;                               //element list
        
        
        methodName = null;
        methodName2 = null;
        rtnType = null;
        rtnType2 = null;
        paramTypes = new ArrayList<>();
        paramTypes2 = new ArrayList<>();
        
        //parse the first method description
        if (methodXml.getName().equals(Const.METHOD))
        {
            elemList = methodXml.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(Const.METHODNAME))
                    {
                        methodName = nextElem.getValue();
                    }
                    else if (ReflectionParser.decodeParameterName(methodName,
                            nextElem.getName()).equals(Const.RETURNTYPE))
                    {
                        if (nextElem.hasChildren())
                        {
                            nextElem2 = nextElem.getChild(Const.PARAMETERTYPE);
                            if (nextElem2 != null)
                            {
                                rtnType = nextElem2.getText();
                            }
                        }
                        else
                        {
                            rtnType = nextElem.getText();
                        }
                    }
                    else if (nextElem.getName().equals(Const.PARAMETERS))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equals(Const.NEXTPARAMETER))
                                {
                                    elemList3 = nextElem2.getChildren();
                                    for (k = 0; k < elemList3.size(); k++)
                                    {
                                        nextNode = (Node)elemList3.get(k);
                                        if (nextNode instanceof Element)
                                        {
                                            nextElem3 = (Element)nextNode;
                                            if (nextElem3.getName().equals(Const.PARAMETERTYPE))
                                            {
                                                paramTypes.add(nextElem3.getValue());
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        //parse the second method description
        if (methodXml2.getName().equals(Const.METHOD))
        {
            elemList = methodXml2.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(Const.METHODNAME))
                    {
                        methodName2 = nextElem.getValue();
                    }
                    else if (ReflectionParser.decodeParameterName(methodName2,
                            nextElem.getName()).equals(Const.RETURNTYPE))
                    {
                        if (nextElem.hasChildren())
                        {
                            nextElem2 = nextElem.getChild(Const.PARAMETERTYPE);
                            if (nextElem2 != null)
                            {
                                rtnType2 = nextElem2.getText();
                            }
                        }
                        else
                        {
                            rtnType2 = nextElem.getText();
                        }
                    }
                    else if (nextElem.getName().equals(Const.PARAMETERS))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equals(Const.NEXTPARAMETER))
                                {
                                    elemList3 = nextElem2.getChildren();
                                    for (k = 0; k < elemList3.size(); k++)
                                    {
                                        nextNode = (Node)elemList3.get(k);
                                        if (nextNode instanceof Element)
                                        {
                                            nextElem3 = (Element)nextNode;
                                            if (nextElem3.getName().equals(Const.PARAMETERTYPE))
                                            {
                                                paramTypes2.add(nextElem3.getValue());
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        if ((methodName != null) && (methodName2 != null))
            match = methodName.equals(methodName2);
        else
            match = false;
        
        if (match)
        {
            if ((rtnType != null) && (rtnType2 != null))
                match = rtnType.equals(rtnType2);
            else
                match = false;
        }
        
        if (match)
        {
            if (paramTypes.size() == paramTypes2.size())
            {
                for (i=0; match && (i < paramTypes.size()); i++)
                { 
                    match = (paramTypes.get(i).equals(paramTypes2.get(i)));
                }
            }
            else
            {
                match = false;
            }
        }
        
        return match;
    }
    
    /**
     * Get a list of all of the methods in this admin document.
     * @param adminInfo the admin info.
     * @param removeBase if true remove known base 'Object' methods.
     * @return the list of all method descriptions in the admin document in XML format.
     */
    public ArrayList<Element> getAllMethods(AdminInfo adminInfo, boolean removeBase)
    {
        ArrayList<Element> allMethods;                  //all methods
        HashMap<String, Element> accessLevels;          //access levels
        Element nextAccessLevel;                        //next access level
        
        allMethods = new ArrayList<>();
        if (adminInfo != null)
        {
            accessLevels = adminInfo.getAccessLevels();
            if ((accessLevels != null) && (accessLevels.size() > 0))
            {
                for (String key : accessLevels.keySet())
                {
                    nextAccessLevel = accessLevels.get(key);
                    allMethods.addAll(getMethods(nextAccessLevel, removeBase));
                }
            }
        }
        
        return allMethods;
    }
    
    /**
     * Get a list of all of the methods in this access level.
     * @param accessXml the access level info.
     * @param removeBase if true remove known base 'Object' methods.
     * @return the list of methods at this level in XML format.
     */
    public ArrayList<Element> getMethods(Element accessXml, boolean removeBase)
    {
        int i;
        String methodName;                              //method name
        Node nextNode;                                  //next node
        Element nextMethod;                             //next method
        ArrayList<Element> allMethods;                  //all methods
        Element methodElem;                             //method element
        Vector elemList;                                //element list
        
        allMethods = new ArrayList<>();
        elemList = accessXml.getChildren();
        
        for (i = 0; i < elemList.size(); i++)
        {
            nextNode = (Node)elemList.get(i);
            if (nextNode instanceof Element)
            {
                nextMethod = (Element)nextNode;
                if (nextMethod.getName().equals(Const.METHOD))
                {
                    methodElem = nextMethod.getChild(Const.METHODNAME);
                    if (methodElem != null)
                    {
                        methodName = methodElem.getText();
                        if (removeBase && !ReflectionParser.objectMethods.contains(methodName))
                            allMethods.add((Element)nextMethod.clone());
                    }
                }
            }
        }
        
        return allMethods;
    } 
    
    /**
     * Get a list of all of the methods names in this access level.
     * @param accessXml the access level info.
     * @return the list of method names at this level. Values are of type String.
     */
    public static ArrayList<String> getMethodNames(Element accessXml)
    {
        int i, j;
        Node nextNode;                              //next node
        Element nextMethod;                         //next method
        ArrayList<String> allMethods;               //all methods
        Element nextElem;                           //next element
        Vector elemList;                            //element list
        Vector elemList2;                           //element list
        
        allMethods = new ArrayList<>();
        elemList = accessXml.getChildren();
        
        for (i = 0; i < elemList.size(); i++)
        {
            nextNode = (Node)elemList.get(i);
            if (nextNode instanceof Element)
            {
                nextMethod = (Element)nextNode;
                if (nextMethod.getName().equals(Const.METHOD))
                {
                    elemList2 = nextMethod.getChildren();        
                    for (j = 0; j < elemList2.size(); j++)
                    {
                        nextNode = (Node)elemList2.get(j);
                        if (nextNode instanceof Element)
                        {
                            nextElem = (Element)nextNode;
                            if (nextElem.getName().equals(Const.METHODNAME))
                            {
                                allMethods.add(nextElem.getValue());
                            }
                        }
                    }
                }
            }
        }
        
        return allMethods;
    }
    
    /**
     * Retrieve the name part of the method xml description.
     * @param methodXml the method description in xml.
     * @return the method name.
     */
    public static String getMethodName(Element methodXml)
    {
        int i;
        boolean nameFound;                          //true if name is found
        String methodName;                          //the method name
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Vector elemList;                            //element list
                
        nameFound = false;
        methodName = null;
        
        if (methodXml.getName().equals(Const.METHOD))
        {
            elemList = methodXml.getChildren();
            for (i = 0; !nameFound && (i < elemList.size()); i++)
            {
                nextNode = (Node)elemList.get(i);
                
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    
                    if (nextElem.getName().equals(Const.METHODNAME))
                    {
                        methodName = nextElem.getText();
                        nameFound = true;
                    }
                }
            }
        }
        
        return methodName;
    }
    
    /**
     * Retrieve the description part of the method xml description.
     * @param methodXml the method description in xml.
     * @return the description part.
     */
    public static Element getMethodDescription(Element methodXml)
    {
        int i, j;
        boolean descriptionFound;                   //true if description is found
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Element description;                        //the xml description
        Vector elemList;                            //element list
        Vector elemList2;                           //element list
        
        
        descriptionFound = false;
        description = null;
        
        if (methodXml.getName().equals(Const.METHOD))
        {
            elemList = methodXml.getChildren();
            for (i = 0; !descriptionFound && (i < elemList.size()); i++)
            {
                nextNode = (Node)elemList.get(i);
                
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    
                    if (nextElem.getName().equals(Const.DESCRIPTION))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; !descriptionFound && (j < elemList2.size()); j++)
                        {
                            nextNode = (Node)elemList2.get(j);

                            if (nextNode instanceof Element)
                            {
                                description = (Element)nextNode.clone();
                                descriptionFound = true;
                            }
                        }
                    }
                }
            }
        }
        
        return description;
    }
    
    /**
     * Retrieve the password part of the access level xml description.
     * @param accessXml the access level description in xml.
     * @return the description part.
     */
    public static String getPassword(Element accessXml)
    {
        String password = null;                     //the password
        
        
        if (accessXml.getName().equals(Const.ACCESSLEVEL))
        {
            password = accessXml.getAttributeValue(MetaConst.PASSWORD);
        }
        
        return password;
    }
}
