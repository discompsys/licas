/*
 * ObjectParser.java
 *
 * Created on 14 April 2007
 *
 * Version 1.2.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers.types;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.StringHandler;
import org.licas_xml.model.XmlHandler;

import java.io.Serializable;


/**
 * This class serialises and parses an Object that extends {@code java.io.Serializable}.
 * The serialization process involves converting the object into {@code Base64} format, using
 * the {@link Base64} parser.
 * @author Kieran Greer
 */
public class ObjectParser 
{
    /** The logger */
    private static Logger logger;
    
    /** Defines serialized object */
    public static final String SERIALIZED = "Serialized_Object";
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ObjectParser.class.getName());
        logger.setDebug(false);
    }

    
    /** Creates a new instance of ObjectParser */
    public ObjectParser() {
    }
    
    /**
     * Parse the String-based description back into the object.
     * @param objStr a serialized description of the object.
     * @return the original object, or the {@code objStr} parameter if this is not
     * a recognised Base64 encoded object description.
     * @throws java.lang.Exception any error.
     */
    public static Object parse(String objStr) throws Exception
    {
        Object parseObj;                        //parsed object
        Base64 base64;                          //base64 encoder/decoder
        
        try
        {
            base64 = new Base64();
            parseObj = base64.decodeToObject(objStr);            
            return parseObj;
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "parse",
                null, ex);
            
            return objStr;
        }
    }
    
    /**
     * Convert the object into a serialized String-based description.
     * @param nextObj the object to convert.
     * @return the object converted into a Base64 encoded String.
     */
    public static String serialize(Object nextObj)
    {
        String objStr;                          //object as a string
        Base64 base64;                          //base64 encoder/decoder
        
        try
        {
            base64 = new Base64();
            objStr = base64.encodeObject((Serializable)nextObj);
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "serialize",
                null, ex);
            
            objStr = null;
        }
        
        return objStr;
    }
}
