/*
 * ServiceSpecParser.java
 *
 * Created on 6 August 2014
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers;


import org.jlog2.util.FileLoader;
import org.licas.PasswordHandler;
import org.licas.service.spec.BehaviourScript;
import org.licas.service.spec.LinkSpec;
import org.licas.service.spec.ServiceSpec;
import org.licas.util.AiConst;
import org.licas.util.Const;
import org.licas.util.ObjectHandler;
import org.licas.util.ServiceConst;
import org.licas_text.util.QueryConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;


/**
 * This class can read a script file and parse it into a {@link ServiceSpec} object,
 * or serialize back into XML again. You would typically use a {@link BehaviourScript} and
 * related parser, so this is just for convenience.
 * @author Kieran Greer
 */
public class ServiceSpecParser 
{
    /** For storing passwords */
    protected PasswordHandler passwordHandler;
    
    /** 
     * Create a new instance of ServiceSpecParser.
     * @param thePasswordHandler for storing passwords.
     */
    public ServiceSpecParser(PasswordHandler thePasswordHandler)
    {
        passwordHandler = thePasswordHandler;
    }
    
    
    /**
     * Serialize the base service script specification into XML.
     * @param testScript the test script to serialize.
     * @param forDisplay if true, create output for display purposes only.
     * @return the script in XML format.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(ServiceSpec testScript, boolean forDisplay) throws Exception
    {
        int i, j;
        String nextKey;                                 //next key
        Iterator allKeys;                               //all keys
        ArrayList jarFileList;                             //list of jar files
        Element conElem;                                //constructor element
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        Element nextElem3;                              //next element
        Element nextElem4;                              //next element
        Element scriptElem;                             //the script element
        LinkSpecParser linkParser;                      //link config parser
        Object nextConstructor;                         //next constructor
        Object[] fileParam;                             //file parameter
                
        if (testScript != null)
        {
            linkParser = new LinkSpecParser();
            scriptElem = XMLFactory.getInstance().createElement(Const.TESTSCRIPT);
            
            allKeys = testScript.serviceClasses.keySet().iterator();
            if (allKeys.hasNext())
            {
                nextElem = XMLFactory.getInstance().createElement(Const.SERVICES); 
                scriptElem.addContent(nextElem);
                
                while (allKeys.hasNext())
                {
                    nextKey = (String)allKeys.next();
                    nextElem2 = XMLFactory.getInstance().createElement(Const.SERVICE); 
                    nextElem2.setAttribute(Const.NAME, nextKey);
                    nextElem.addContent(nextElem2);
                    
                    nextElem3 = XMLFactory.getInstance().createElement(Const.CLASSNAME); 
                    nextElem3.setText(ServiceConst.checkClassName((String)testScript.serviceClasses.get(nextKey)));
                    nextElem2.addContent(nextElem3);

                    jarFileList = (ArrayList)testScript.serviceJarFiles.get(nextKey);
                    if ((jarFileList != null) && !jarFileList.isEmpty())
                    {
                        nextElem3 = XMLFactory.getInstance().createElement(Const.JARFILESXML); 
                        nextElem2.addContent(nextElem3);

                        for (i = 0; i < jarFileList.size(); i++)
                        {
                            nextElem4 = XMLFactory.getInstance().createElement(Const.JARFILEXML); 
                            nextElem4.setText((String)jarFileList.get(i));
                            nextElem3.addContent(nextElem4);
                        }
                    }
                } 
            }            
            if (testScript.constructorParams.size() > 0)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.CONSTRUCTORS);
                for (i = 0; i < testScript.constructorParams.size(); i++)
                {
                    nextElem2 = XMLFactory.getInstance().createElement(Const.CONSTRUCTOR);
                    nextConstructor = testScript.constructorParams.get(i);
                    if (ObjectHandler.isString(nextConstructor))
                    {
                        nextElem2.setText((String)nextConstructor);
                    }
                    else if (nextConstructor instanceof Object[])
                    {
                        fileParam = (Object[])nextConstructor;                       
                        conElem = XMLFactory.getInstance().createElement(QueryConst.FILEPATH);
                        conElem.setText((String)fileParam[0]);
                        nextElem2.addContent(conElem);
                        if (!forDisplay) nextElem2.addContent((Element)fileParam[1]);
                    }
                    else if (ObjectHandler.isElement(nextConstructor))
                    {
                        nextElem2.addContent((Element)nextConstructor);
                    }
                    
                    nextElem.addContent(nextElem2);
                }
                
                scriptElem.addContent(nextElem);
            }
            
            if (testScript.heuristicType != null)
            {
                nextElem = XMLFactory.getInstance().createElement(AiConst.HEURISTICTYPE);                   
                nextElem.setText(testScript.heuristicType);
                scriptElem.addContent(nextElem);
            }
            if (testScript.metricType != null)
            {
                nextElem = XMLFactory.getInstance().createElement(AiConst.METRICTYPE);                   
                nextElem.setText(testScript.metricType);
                scriptElem.addContent(nextElem);
            }
            if (testScript.servicesNum > 0)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.SOLUTIONS);                   
                nextElem.setText(String.valueOf(testScript.servicesNum));
                scriptElem.addContent(nextElem);
            }
            
            if (testScript.datasetType != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.DATASETTYPE);                   
                nextElem.setText(testScript.datasetType);
                scriptElem.addContent(nextElem);
            }
            
            if (testScript.dirPath != null)
            {
                nextElem = XMLFactory.getInstance().createElement(QueryConst.FILEPATH);                   
                nextElem.setText(testScript.dirPath);
                scriptElem.addContent(nextElem);
            }
            
            if (testScript.tokenizer != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.TOKENIZER);                   
                nextElem.setText(testScript.tokenizer);
                scriptElem.addContent(nextElem);
            }
            
            if (testScript.externalScript != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.OTHERSCRIPT);                   
                nextElem.setText(testScript.externalScript);
                scriptElem.addContent(nextElem);
            }
            
            nextElem = XMLFactory.getInstance().createElement(Const.SERVER);                   
            scriptElem.addContent(nextElem);            
            nextElem2 = XMLFactory.getInstance().createElement(Const.CREATESERVICES);                   
            nextElem2.setText(String.valueOf(testScript.createServices));
            nextElem.addContent(nextElem2);
            nextElem2 = XMLFactory.getInstance().createElement(Const.STARTTHREADS);                   
            nextElem2.setText(String.valueOf(testScript.serverSpec.startThreads));
            nextElem.addContent(nextElem2);
            nextElem2 = XMLFactory.getInstance().createElement(Const.SERVERADDRESS);                   
            nextElem2.setText(testScript.serverSpec.serverAddress);
            nextElem.addContent(nextElem2);
            nextElem2 = XMLFactory.getInstance().createElement(Const.SERVERPASSWORD);                   
            nextElem2.setText(testScript.serverSpec.password);
            nextElem.addContent(nextElem2);
            nextElem2 = XMLFactory.getInstance().createElement(Const.SERVERKEY);                   
            nextElem2.setText(testScript.serverSpec.adminKey);
            nextElem.addContent(nextElem2);
            
            if (testScript.heuristicOptions.size() > 0)
            {
                scriptElem.addContent(LinkSpecParser.serializeOptions(testScript.heuristicOptions));
            }
            
            if (testScript.linkSpec.linkMethod != null)
            {
                nextElem = linkParser.serialize(testScript.linkSpec);                
                scriptElem.addContent(nextElem);
            }

            return scriptElem;
        }
        
        return null;
    }
    
    /**
     * Parse the file path to create a base service script specification.
     * @param scriptXml the script document in XML format.
     * @param serviceSpec the service script specification object.
     * @throws java.lang.Exception any error.
     */
    public void parse(Element scriptXml, ServiceSpec serviceSpec) throws Exception
    {
        int i, j, k, l;
        String serviceType;                             //service type
        String nextValue;                               //next value
        ArrayList jarFiles;                                //jar file list
        Vector elemList;                                //element list
        Vector elemList2;                               //element list
        Vector elemList3;                               //element list
        Vector elemList4;                               //element list
        Node nextNode;                                  //next node
        Element fileElem;                               //file element
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        Element nextElem3;                              //next element
        Element nextElem4;                              //next element
        ServiceSpec testScript;                         //the test script
        LinkSpecParser linkParser;                      //link config parser
        Object[] fileParam;                             //file parameter
                        
        testScript = serviceSpec;
        linkParser = new LinkSpecParser();
        
        if (scriptXml.getName().equals(Const.TESTSCRIPT))
        {
            elemList = scriptXml.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(Const.SERVICES))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equals(Const.SERVICE))
                                {
                                    serviceType = nextElem2.getAttributeValue(Const.NAME);
                                    
                                    elemList3 = nextElem2.getChildren();                                 
                                    for (k = 0; k < elemList3.size(); k++)
                                    {
                                        nextNode = (Node)elemList3.get(k);
                                        if (nextNode instanceof Element)
                                        {
                                            nextElem3 = (Element)nextNode;
                                            if (nextElem3.getName().equals(Const.CLASSNAME))
                                            {
                                                testScript.serviceClasses.put(serviceType, 
                                                        ServiceConst.checkClassName(nextElem3.getText()));
                                            }
                                            else if (nextElem3.getName().equals(Const.JARFILESXML))
                                            {
                                                elemList4 = nextElem3.getChildren();
                                                for (l = 0; l < elemList4.size(); l++)
                                                {
                                                    nextNode = (Node)elemList4.get(l);
                                                    if (nextNode instanceof Element)
                                                    {
                                                        nextElem4 = (Element)nextNode;
                                                        if (nextElem4.getName().equals(Const.JARFILEXML))
                                                        {
                                                            try 
                                                            {
                                                                if (!testScript.serviceJarFiles.containsKey(serviceType))
                                                                    testScript.serviceJarFiles.put(serviceType, new ArrayList());

                                                                jarFiles = testScript.serviceJarFiles.get(serviceType);
                                                                jarFiles.add(nextElem4.getText().trim());
                                                            } 
                                                            catch (Exception ex2) {}
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else if (nextElem.getName().equals(AiConst.HEURISTICTYPE))
                    {
                        try {
                            testScript.heuristicType = nextElem.getText().trim();
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(AiConst.METRICTYPE))
                    {
                        try {
                            testScript.metricType = nextElem.getText().trim();
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(AiConst.HEURISTICOPTIONS))
                    {
                        testScript.heuristicOptions = LinkSpecParser.parseOptions(nextElem);
                    }
                    else if (nextElem.getName().equals(Const.CONSTRUCTORS))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equals(Const.CONSTRUCTOR))
                                {
                                    if (nextElem2.hasChildren())
                                    {
                                        fileParam = new Object[2];
                                        fileElem = nextElem2.getChild(QueryConst.FILEPATH);
                                        if (fileElem != null) 
                                        {
                                            fileParam[0] = fileElem.getText();
                                            nextElem2.getChild(QueryConst.FILEPATH).detach();
                                        } 
                                        
                                        if (nextElem2.hasChildren())
                                        {
                                            fileParam[1] = nextElem2.getElementChildAtIndex(0).detach();
                                        }
                                        else
                                        {
                                            fileParam[1] = XmlHandler.stringToElement(FileLoader.getInputStream((String)fileParam[0]));
                                        }
                                        
                                        testScript.constructorParams.add(fileParam);
                                    }
                                    else
                                    {
                                        testScript.constructorParams.add(nextElem2.getText());
                                    }
                                }
                            }
                        }
                    }
                    else if (nextElem.getName().equals(Const.SOLUTIONS))
                    {
                        try {
                            nextValue = nextElem.getText().trim();
                            testScript.servicesNum = Integer.parseInt(nextValue);
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(Const.DATASETTYPE))
                    {
                        try {
                            testScript.datasetType = nextElem.getText().trim();
                        } catch (Exception ex2) {}
                    }
                    else if (nextElem.getName().equals(QueryConst.FILEPATH))
                    {
                        try {
                            testScript.dirPath = nextElem.getText().trim();
                        } catch (Exception ex2) {}                          
                    }
                    else if (nextElem.getName().equals(Const.TOKENIZER))
                    {
                        try {
                            testScript.tokenizer = nextElem.getText().trim();
                        } catch (Exception ex2) {}                          
                    }
                    else if (nextElem.getName().equals(Const.OTHERSCRIPT))
                    {
                        try {
                            testScript.externalScript = nextElem.getText().trim();
                        } catch (Exception ex2) {}                          
                    }
                    else if (nextElem.getName().equals(Const.SERVER))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equals(Const.CREATESERVICES))
                                {
                                    try {
                                        nextValue = nextElem2.getText().trim();
                                        testScript.createServices = Boolean.valueOf(nextValue).booleanValue();
                                    } catch (Exception ex2) {}
                                }
                                if (nextElem2.getName().equals(Const.STARTTHREADS))
                                {
                                    try {
                                        nextValue = nextElem2.getText().trim();
                                        testScript.serverSpec.startThreads = Boolean.valueOf(nextValue).booleanValue();
                                    } catch (Exception ex2) {}
                                }
                                else if (nextElem2.getName().equals(Const.SERVERADDRESS))
                                {
                                    try {
                                        testScript.serverSpec.serverAddress = nextElem2.getText().trim();
                                    } catch (Exception ex2) {}
                                }
                                else if (nextElem2.getName().equals(Const.SERVERPASSWORD))
                                {
                                    try {
                                        testScript.serverSpec.password = nextElem2.getText().trim();
                                    } catch (Exception ex2) {}
                                }
                                else if (nextElem2.getName().equals(Const.SERVERKEY))
                                {
                                    try {
                                        testScript.serverSpec.adminKey = nextElem2.getText().trim();
                                    } catch (Exception ex2) {}
                                }
                            }
                        }
                    }
                    else if (nextElem.getName().equals(Const.DYNAMICLINKS) ||
                            nextElem.getName().equals(Const.THRESHOLDSCONFIG))
                    {
                        testScript.linkSpec = (LinkSpec)linkParser.parse(nextElem);
                    }
                }
            }
        }
    }
}
