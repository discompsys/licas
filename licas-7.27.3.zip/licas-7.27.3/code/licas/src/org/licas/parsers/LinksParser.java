/*
 * LinksParser.java
 *
 * Created on 6 August 2014
 *
 * Version 1.3.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers;


import org.ai_heuristic.eval.metric.MetricDataset;
import org.ai_heuristic.tree.Tree;
import org.ai_heuristic.tree.TreeNode;
import org.ai_heuristic.util.SymbolHandler;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.service.link.Link;
import org.licas.service.link.Thresholds;
import org.licas.service.spec.LinkSpec;
import org.licas.util.Const;
import org.licas.util.MetaConst;
import org.licas.util.ObjectHandler;
import org.licas.util.TypeConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;


/**
 * This class serialises and parses the different linking lists to or from XML.
 * The saved value is restricted to be single strings.
 * @author Kieran Greer
 */
public class LinksParser 
{
    /** The logger */
    private static final Logger logger;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(LinksParser.class.getName());
        logger.setDebug(false);
    }

    
    /** Creates a new instance of LinksParser */
    public LinksParser() {
    }
    
    /**
     * Get the initial threshold config for this component. This is the method to call to 
     * initialise the threshold values. All other linking structures that are created in 
     * this service are then initialised with the same values that are set here.
     * @param thresholdsXml the root config element.  
     * @return the parsed thresholds config spec.
     * @throws java.lang.Exception any error. 
     */
    public LinkSpec xmlToThresholdsConfig(Element thresholdsXml) throws Exception
    {
        LinkSpecParser linkParser;              //link spec parser
        
        if (thresholdsXml.getName().equals(Const.THRESHOLDSCONFIG) ||
                thresholdsXml.getName().equals(Const.DYNAMICLINKS))
        {
            linkParser = new LinkSpecParser();
            return (LinkSpec)linkParser.parse(thresholdsXml);
        }
        
        return null;
    }
    
    /**
     * Return all linked sources as a list of XML elements.
     * @param linkSpec stores the original config values.
     * @param linkStructure the linking structure itself.
     * @param allLevels if true, return all 3 levels, if false only return the top link level
     * references.
     * @param indent for formatting purposes, can be null.
     * @return an XML representation of all linked sources.
     * @throws java.lang.Exception any error.
     */
    public String dynamicLinksToString(LinkSpec linkSpec, Tree linkStructure, boolean allLevels,
            String indent) throws Exception
    {
        int i;
        String linkStr;                         //link string
        String nextKey;                         //next key
        ArrayList allKeys;                      //all keys
        Object nextConcept;                     //next concept
        TreeNode nextTreeNode;                  //next tree node
        HashMap linkStrings;                    //links strings
               
        linkStrings = new HashMap();
        if (indent == null) indent = "";
        linkStrings.put(Const.LINK, indent);
        linkStrings.put(Const.MONITOR, indent);
        linkStrings.put(Const.POSSIBLE, indent);
        
        //add the link paths and references
        allKeys = linkStructure.getChildNodeKeys();     
        for (i = 0; i < allKeys.size(); i++)
        {
            nextConcept = allKeys.get(i);
            nextKey = ObjectHandler.getKey(nextConcept);

            nextTreeNode = linkStructure.getChildNode(nextKey);
            nextDynamicLinksToString(nextTreeNode, linkStrings, allLevels);
        }
        
        linkStr = (indent + linkStrings.get(Const.LINK));
        linkStr += (SymbolHandler.NL + indent + linkStrings.get(Const.MONITOR));
        linkStr += (SymbolHandler.NL + indent + linkStrings.get(Const.POSSIBLE));
        
        return linkStr;
    }
    
    /**
     * Return all linked sources as a list of XML elements.
     * @param linkSources the next tree of concepts or links to check.
     * @param linkStrings list of strings to add to.
     * @param allLevels if true, return all 3 levels, if false only return the top link level
     * references.
     * @return an XML representation of all linked sources.
     * @throws java.lang.Exception any error.
     */
    private void nextDynamicLinksToString(TreeNode linkSources, HashMap linkStrings,
                                          boolean allLevels) throws Exception
    {
        int i;
        String nextKey;                         //next key
        ArrayList allKeys;                      //all keys
        Object nextConcept;                     //next concept
        Object nextValue;                       //next value
        TreeNode nextTreeNode;                  //next tree node
        Thresholds nextThresholds;              //next set of thresholds
        
        nextValue = linkSources.getValue();               
        if ((nextValue != null) && (nextValue instanceof Thresholds))
        {
            nextThresholds = (Thresholds)nextValue;            
            nextThresholds.linksToString(linkStrings, allLevels);
        }
                
        allKeys = linkSources.getChildNodeKeys();
        for (i = 0; i < allKeys.size(); i++)
        {
            nextConcept = allKeys.get(i);
            nextKey = ObjectHandler.getKey(nextConcept);
            nextTreeNode = linkSources.getChildNode(nextKey);

            if (nextTreeNode != null) {
                nextDynamicLinksToString(nextTreeNode, linkStrings, allLevels);
            }
        }
    }

    /**
     * Return all linked sources as a list of XML elements.
     * @param uuid a parent service uuid, for info purposes only.
     * @param linkSpec stores the original link spec. Can be null, when not included.
     * @param linkStructure the linking structure itself.
     * @param allLevels if true, return all 3 levels, if false only return the top link level
     * references.
     * @param configValues if false, return just the path and source info.
     * If true, include other values, such as weights or link spec.
     * @return an XML representation of all linked sources.
     * @throws java.lang.Exception any error.
     */
    public Element dynamicLinksToXml(String uuid, LinkSpec linkSpec, Tree linkStructure, 
            boolean allLevels, boolean configValues) throws Exception
    {
        int i;
        String nextKey;                         //next key
        ArrayList allKeys;                      //all keys
        Object nextConcept;                     //next concept
        TreeNode nextTreeNode;                  //next tree node
        Element rootElem;                       //the root dynamic links element
        Element sourceElem;                     //source element
        Element pathElem;                       //path element
        Element nextElem;                       //next element
        LinkSpecParser linkParser;              //link spec parser
               
        linkParser = new LinkSpecParser();
        rootElem = XMLFactory.getInstance().createElement(MetaConst.DYNAMICLINKSERVICEMETA);
        sourceElem = XMLFactory.getInstance().createElement(Const.SOURCE);
        nextElem = XMLFactory.getInstance().createElement(Const.UUID);
        nextElem.setText(uuid);
        sourceElem.addContent(nextElem);
        
        //add original threshold config
        if (configValues && (linkSpec != null))
        {
            nextElem = linkParser.serialize(linkSpec);       
            sourceElem.addContent(nextElem);
            rootElem.addContent(sourceElem);
        }

        //add the link paths and references
        allKeys = linkStructure.getChildNodeKeys();     
        for (i = 0; i < allKeys.size(); i++)
        {
            nextConcept = allKeys.get(i);
            nextKey = ObjectHandler.getKey(nextConcept);

            pathElem = XMLFactory.getInstance().createElement(Const.PATH);
            pathElem.setAttribute(Const.VALUE, nextKey);
            rootElem.addContent(pathElem);

            nextTreeNode = linkStructure.getChildNode(nextKey);
            if (nextTreeNode != null) {
                nextDynamicLinksToXml(nextTreeNode, pathElem, allLevels, configValues);
            }
        }
        
        return rootElem;
    }
    
    /**
     * Return all linked sources as a list of XML elements.
     * @param linkSources the next tree of concepts or links to check.
     * @param rootElem the root element to add to.
     * @param allLevels if true, return all 3 levels, if false only return the top link level
     * references.
     * @param configValues if false, return just the path and source info.
     * If true, include other values, such as weights or link spec.
     * @return an XML representation of all linked sources.
     * @throws java.lang.Exception any error.
     */
    private void nextDynamicLinksToXml(TreeNode linkSources, Element rootElem, 
            boolean allLevels, boolean configValues) throws Exception
    {
        int i;
        String nextKey;                         //next key
        ArrayList allKeys;                      //all keys
        Object nextConcept;                     //next concept
        Object nextValue;                       //next value
        TreeNode nextTreeNode;                  //next tree node
        Thresholds nextThresholds;              //next set of thresholds
        Element pathElem;                       //path element

        nextValue = linkSources.getValue();               
        if ((nextValue != null) && (nextValue instanceof Thresholds))
        {
            nextThresholds = (Thresholds)nextValue;            
            rootElem.addContent(nextThresholds.linksToXml(allLevels, configValues));
        }
                
        allKeys = linkSources.getChildNodeKeys();
        for (i = 0; i < allKeys.size(); i++)
        {
            nextConcept = allKeys.get(i);
            nextKey = ObjectHandler.getKey(nextConcept);

            pathElem = XMLFactory.getInstance().createElement(Const.PATH);
            pathElem.setAttribute(Const.VALUE, nextKey);
            rootElem.addContent(pathElem);

            nextTreeNode = linkSources.getChildNode(nextKey);
            if (nextTreeNode != null) {
                nextDynamicLinksToXml(nextTreeNode, pathElem, allLevels, configValues);
            }
        }
    }
    
    /**
     * Return all linked sources as a list of XML elements.
     * @param uuid a parent service uuid, for info purposes only.
     * @param sources list of selected link sources. 
     * @return an XML representation of all linked sources.
     * @throws java.lang.Exception any error.
     */
    public Element linkSourcesToXml(String uuid, ArrayList sources) throws Exception
    {
        int i;
        String nextKey;                         //next key
        Object nextSource;                      //next source
        Element rootElem;                       //the root dynamic links element
        Element sourceElem;                     //source element
        Element pathElem;                       //path element
        Element nextElem;                       //next element
               
        rootElem = XMLFactory.getInstance().createElement(MetaConst.DYNAMICLINKSERVICEMETA);
        sourceElem = XMLFactory.getInstance().createElement(Const.SOURCE);
        nextElem = XMLFactory.getInstance().createElement(Const.UUID);
        nextElem.setText(uuid);
        sourceElem.addContent(nextElem);
        
        //add the link paths and references
        for (i = 0; i < sources.size(); i++)
        {
            nextSource = sources.get(i);
            nextKey = ObjectHandler.getKey(nextSource);

            pathElem = XMLFactory.getInstance().createElement(Const.LINK);
            pathElem.setText(nextKey);
            rootElem.addContent(pathElem);
        }
        
        return rootElem;
    }
    
    /**
     * Parse the xml description and fill the link spec and structure with the dynamic links.
     * @param linker the parent linker service.
     * @param linksElem the dynamic links description.
     * @throws java.lang.Exception any error.
     */
    public void xmlToDynamicLinks(Link linker, Element linksElem)
            throws Exception
    {
        int i;
        Element configElem;                     //config element
        Element nextElem;                       //next element
        Vector elemList;                        //element list
        
        if (linksElem.getName().equalsIgnoreCase(MetaConst.DYNAMICLINKSERVICEMETA))
        {
            elemList = linksElem.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextElem = (Element)elemList.get(i);
                if (nextElem.getName().equalsIgnoreCase(Const.SOURCE))
                {
                    configElem = nextElem.getChild(Const.THRESHOLDSCONFIG);
                    if (configElem != null)
                    {
                        linker.getLinkSpec().copy(xmlToThresholdsConfig(configElem));
                    }
                }
                else if (nextElem.getName().equalsIgnoreCase(Const.PATH))
                {
                    nextXmlToDynamicLinks(linker, linker.getLinkTree(), nextElem);
                }
            }
        }
    }
    
    /**
     * Parse the xml description and fill the link spec and structure with the dynamic links.
     * @param linker the parent linker service.
     * @param linkStructure the tree structure to store the links.
     * @param linksElem the dynamic links description.
     * @throws java.lang.Exception any error.
     */
    private void nextXmlToDynamicLinks(Link linker, TreeNode linkStructure, Element linksElem) throws Exception
    {
        int i;
        String pathValue;                       //path element value
        Element nextElem;                       //next element
        Vector elemList;                        //element list
        TreeNode newNode;                       //new tree node
        Thresholds nextThresholds;              //next set of thresholds


        //add path value first
        pathValue = linksElem.getAttributeValue(Const.VALUE);
        newNode = new TreeNode(pathValue, TypeConst.STRING);
        linkStructure.addChildNode(newNode);

        //then add the subtree
        elemList = linksElem.getChildren();
        for (i = 0; i < elemList.size(); i++)
        {
            nextElem = (Element)elemList.get(i);
            if (nextElem.getName().equalsIgnoreCase(Const.PATH))
            {
                nextXmlToDynamicLinks(linker, newNode, nextElem);
            }
            else if (nextElem.getName().equalsIgnoreCase(Const.LINKS))
            {
                nextThresholds = linker.createNewThresholds();
                nextThresholds.xmlToLinks(nextElem);
                newNode.setValue(MetricDataset.toDataset(nextThresholds));
            }
        }
    }
}
