/*
 * ComparisonQueryModelParser.java
 *
 * Created on 24 November 2015
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers;


import org.ai_heuristic.def.ParserDef;
import org.ai_heuristic.eval.metric.MetricDataset;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas.data.ComparisonQueryModel;
import org.licas.data.DataQueryModel;
import org.licas.util.Const;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.LinkedHashMap;
import java.util.Vector;


/**
 * This class can be used to parse a {@link DataQueryModel} object to or from XML.
 * @author Kieran Greer
 */
public class ComparisonQueryModelParser implements ParserDef
{
    /**
     * Create a new instance of DataInfoQuery.
     */
    public ComparisonQueryModelParser()
    {}

    /**
     * Serialize a MethodInfo object to XML.
     * @param toSerialize the MethodInfo object to serialize.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        String stringValue;                     //string value
        ComparisonQueryModel dataInfo;          //data query object
        DataQueryModelParser dataParser;        //data parser
        Element rootElem;                       //root element
        Element nextElem;                       //next element
        Element objElem;                        //object parsed as an element
        
        try
        {
            dataInfo = (ComparisonQueryModel)toSerialize;
            dataParser = new DataQueryModelParser();
            rootElem = dataParser.serialize(dataInfo);

            stringValue = dataInfo.getFunctionClass();
            if (stringValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.EVALUATORCLASS);
                nextElem.setText(stringValue);
                rootElem.addContent(nextElem);
            }

            stringValue = dataInfo.getOperator();
            if (stringValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.OPERATOR);
                nextElem.setText(stringValue);
                rootElem.addContent(nextElem);
            }

            if (dataInfo.getCompareWith() != null)
            {
                nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.VALUE2);
                objElem = Parsers.serializeToElement(dataInfo.getCompareWith().getData());
                nextElem.addContent(objElem);
                rootElem.addContent(nextElem);
            }

            return rootElem;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /**
     * Parse an XML description of a {@link ComparisonQueryModel} object back into the Java object.
     * @param toParse the XML description to parse.
     * @return the DataQuery object that is created.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        ComparisonQueryModel dataInfo;          //data info object

        dataInfo = new ComparisonQueryModel();
        parseInfo(toParse, dataInfo);

        return dataInfo;
    }

    /**
     * Parse an XML description of a DataQuery object back into the Java object.
     * @param toParse the XML description to parse.
     * @param dataInfo the data info object to place the parsed content in.
     * @throws java.lang.Exception any error.
     */
    public void parseInfo(Element toParse, ComparisonQueryModel dataInfo) throws Exception
    {
        int i;
        LinkedHashMap data;                     //data map
        MetricDataset md;                       //metric dataset
        Node nextNode;                          //next node
        Element nextElem;                       //next element
        Element nextElem2;                      //next element
        Vector elemList;                        //element list
        DataQueryModelParser dataParser;        //data parser
        
        try
        {
            if (toParse.getName().equals(Const.DATAINFO))
            {
                dataParser = new DataQueryModelParser();
                dataParser.parseInfo(toParse, dataInfo);
                
                elemList = (Vector)toParse.getChildren().clone();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);

                    if (nextNode instanceof Element)
                    {
                        nextElem = (Element)nextNode;

                        if (nextElem.getName().equals(Const.EVALUATORCLASS))
                        {
                            dataInfo.setFunctionClass(nextElem.getText());
                        }
                        else if (nextElem.getName().equals(AiHeuristicConst.OPERATOR))
                        {
                            dataInfo.setOperator(nextElem.getText());
                        }
                        else if (nextElem.getName().equals(AiHeuristicConst.VALUE2))
                        {
                            nextElem2 = nextElem.getElementChildAtIndex(0);
                            data = (LinkedHashMap)Parsers.parse(nextElem2);
                            md = MetricDataset.toDataset(dataInfo.getDataType(), data);
                            dataInfo.setCompareWith(md);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
