/*
 * ReplySetParser.java
 *
 * Created on 7 March 2016
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.parsers.sci;


import org.ai_heuristic.def.ParserDef;
import org.ai_heuristic.eval.metric.ReplySet;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas.parsers.Parsers;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;


/**
 * This can be used to parse a {@link ReplySet} object to or from XML.
 * If a parser exists, the stored value can be parsed using it.
 * @author Kieran Greer
 */
public class ReplySetParser implements ParserDef
{
    /** Create a new instance of ReplySetParser */
    public ReplySetParser()
    {}

    /**
     * Serialize the object into an XML element.
     * @param toSerialize the object to serialize. Of type {@link ReplySet}.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        ReplySet replySet;                      //reply set
        Element rootElem;                       //root element
        Element nextElem;                       //next element
        
        replySet = (ReplySet)toSerialize;        
        rootElem = XMLFactory.getInstance().createElement(AiHeuristicConst.REPLYSET);
        nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.VALUETYPE);
        nextElem.setText(replySet.getValueType());
        rootElem.addContent(nextElem);
        nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.VALUE);
        nextElem.addContent((Element)Parsers.serializeToElement(replySet.getValue()));
        rootElem.addContent(nextElem);
        
        return rootElem;
    }

    /**
     * Parse the XML element back into a ReplySet object.
     * @param toParse the element to parse.
     * @return the parsed Tree.
     * @throws java.lang.Exception any error.
     */
    public ReplySet parse(Element toParse) throws Exception
    {
        String type;                            //value type
        Object value;                           //value
        ReplySet replySet;                      //the reply value
        Element rootElem;                       //root element
        Element nextElem;                       //next element
        
        type = null;
        replySet = null;
        rootElem = toParse;
        
        if (rootElem.getName().equals(AiHeuristicConst.REPLYSET))
        {
            nextElem = rootElem.getChild(AiHeuristicConst.VALUETYPE);
            if (nextElem != null)
            {
                type = nextElem.getText();
            }
            nextElem = rootElem.getChild(AiHeuristicConst.VALUE);
            if (nextElem != null)
            {
                value = Parsers.parse(nextElem.getElementChildAtIndex(0));
                replySet = new ReplySet(type, value);
            }
        }

        return replySet;
    }
}
