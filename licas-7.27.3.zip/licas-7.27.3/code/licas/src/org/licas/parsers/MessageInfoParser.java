/*
 * MessageInfoParser.java
 *
 * Created on 4 February 2016
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.parsers;


import org.ai_heuristic.def.ParserDef;
import org.licas.MessageInfo;
import org.licas.util.AiConst;
import org.licas.util.Const;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.Vector;


/**
 * This class can be used to parse a {@link MessageInfo} object to or from XML.
 * @author Kieran Greer
 */
public class MessageInfoParser implements ParserDef
{
    /**
     * Create a new instance of MessageInfoParser.
     */
    public MessageInfoParser()
    {}

    /**
     * Serialize a {@link MessageInfo} object to XML.
     * @param toSerialize the MessageInfo object to serialize.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        long timeStamp;                             //call timestamp
        String stringValue;                         //string value
        MessageInfo messageInfo;                    //message info object
        Object messageObj;                          //message object
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        
        try
        {
            messageInfo = (MessageInfo)toSerialize;
            rootElem = XMLFactory.getInstance().createElement(Const.MESSAGEINFO);

            timeStamp = messageInfo.getTimeStamp();
            nextElem = XMLFactory.getInstance().createElement(Const.TIMESTAMP);
            nextElem.setText(String.valueOf(timeStamp));
            rootElem.addContent(nextElem);

            stringValue = messageInfo.getCommID();
            if (stringValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.COMMUNICATIONID);
                nextElem.setText(stringValue);
                rootElem.addContent(nextElem);
            }
            
            stringValue = messageInfo.getServiceState();
            if (stringValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.SERVICESTATE);
                nextElem.setText(stringValue);
                rootElem.addContent(nextElem);
            }
            
            stringValue = messageInfo.getMessageState();
            if (stringValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.MESSAGESTATE);
                nextElem.setText(stringValue);
                rootElem.addContent(nextElem);
            }
            
            stringValue = messageInfo.getInOut();
            if (stringValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.MESSAGETYPE);
                nextElem.setText(stringValue);
                rootElem.addContent(nextElem);
            }

            
            messageObj = messageInfo.getMessage();
            if (messageObj != null)
            {
                nextElem = XMLFactory.getInstance().createElement(AiConst.MI_OBJECT);
                nextElem2 = (Element)(Element)Parsers.serializeToElement(messageObj);
                nextElem.addContent(nextElem2);
                rootElem.addContent(nextElem);
            }

            return rootElem;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /**
     * Parse an XML description of a {@link MessageInfo} object back into a Java object.
     * @param toParse the XML description to parse.
     * @return the MessageInfo object that is created.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        int i;
        long timeStamp;                             //call timestamp
        String commID;                              //communication id
        String serviceState;                        //service state
        String messageState;                        //message state
        String messageType;                         //message type
        Object messageObj;                          //message object
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Vector elemList;                            //element list
        MessageInfo messageInfo;                    //message info

        try
        {
            timeStamp = -1;
            commID = null;
            serviceState = null;
            messageState = null;
            messageType = null;
            messageObj = null;
            
            if (toParse.getName().equals(Const.MESSAGEINFO))
            {
                elemList = (Vector)toParse.getChildren().clone();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);
                    if (nextNode instanceof Element)
                    {
                        nextElem = (Element)nextNode;
                        if (nextElem.getName().equals(Const.TIMESTAMP))
                        {
                            timeStamp = Long.parseLong(nextElem.getText());
                        }
                        else if (nextElem.getName().equals(Const.COMMUNICATIONID))
                        {
                            commID = nextElem.getText();
                        }
                        else if (nextElem.getName().equals(Const.SERVICESTATE))
                        {
                            serviceState = nextElem.getText();
                        }
                        else if (nextElem.getName().equals(Const.MESSAGESTATE))
                        {
                            messageState = nextElem.getText();
                        }
                        else if (nextElem.getName().equals(Const.MESSAGETYPE))
                        {
                            messageType = nextElem.getText();
                        }
                        else if (nextElem.getName().equals(AiConst.MI_OBJECT) &&
                                nextElem.hasChildren())
                        {
                            nextElem = nextElem.getElementChildAtIndex(0);
                            messageObj = Parsers.parse(nextElem);
                        }
                    }
                }
            }

            if (commID == null)
            {
                messageInfo = new MessageInfo(messageObj);
            }
            else
            {
                messageInfo = new MessageInfo(commID, messageObj);
            }
            if (timeStamp >= 0)
            {
                messageInfo.setTimeStamp(timeStamp);
            }
            if (serviceState != null)
            {
                messageInfo.setServiceState(serviceState);
            }
            if (messageState != null)
            {
                messageInfo.setMessageState(messageState);
            }
            if (messageType != null)
            {
                messageInfo.setInOut(messageType);
            }
            
            return messageInfo;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
