/*
 * DateParser.java
 *
 * Created on 21 April 2016
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers.types;


import org.ai_heuristic.def.ParserDef;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.util.TypeConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;

import java.util.Date;


/**
 * This class serialises and parses a {@link Date} object to or from XML.
 * @author Kieran Greer
 */
public class DateParser implements ParserDef
{
    /** The logger */
    private static Logger logger;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(DateParser.class.getName());
        logger.setDebug(false);
    }

    
    /** Creates a new instance of DateParser */
    public DateParser() {
    }
    
    
    /**
     * Serialize a {@link Date} object to XML.
     * @param toSerialize the ByteArray object to serialize.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        Date date;                          //date-time object
        Element rootElem;                   //root element
        
        rootElem = XMLFactory.getInstance().createElement(TypeConst.DATE);
        date = (Date)toSerialize;
        rootElem.setText(String.valueOf(date.getTime()));
        
        return rootElem;
    }
    
    /**
     * Parse an XML description of a {@link Date} object back into a Java object.
     * @param toParse the XML description to parse.
     * @return the Date object that is created.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        long timesecs;                      //time in milliseconds
        
        timesecs = Long.parseLong(toParse.getText().trim());
        return new Date(timesecs);
    }
}
