/*
 * DataQueryModelParser.java
 *
 * Created on 13 November 2015
 *
 * Version 1.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers;


import org.ai_heuristic.def.ParserDef;
import org.ai_heuristic.eval.metric.MetricDataset;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas.call.MethodInfo;
import org.licas.data.DataQueryModel;
import org.licas.util.Const;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.LinkedHashMap;
import java.util.Vector;


/**
 * This class can be used to parse a {@link DataQueryModel} object to or from XML.
 * @author Kieran Greer
 */
public class DataQueryModelParser implements ParserDef
{
    /**
     * Create a new instance of DataQueryModelParser.
     */
    public DataQueryModelParser()
    {}

    /**
     * Serialize a {@link DataQueryModel} object to XML.
     * @param toSerialize the MethodInfo object to serialize.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        String stringValue;                     //string value
        DataQueryModel dataInfo;                //data query object
        Element rootElem;                       //root element
        Element nextElem;                       //next element
        Element objElem;                        //object parsed as an element
        
        try
        {
            dataInfo = (DataQueryModel)toSerialize;
            rootElem = XMLFactory.getInstance().createElement(Const.DATAINFO);

            stringValue = dataInfo.getDataType();
            if (stringValue != null)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.DATASETTYPE);
                nextElem.setText(stringValue);
                rootElem.addContent(nextElem);
            }

            if (dataInfo.getDataset() != null)
            {
                nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.VALUE1);
                objElem = Parsers.serializeToElement(dataInfo.getDataset().getData());
                nextElem.addContent(objElem);
                rootElem.addContent(nextElem);
            }

            if (dataInfo.getFunctionClass() != null) {
                nextElem = XMLFactory.getInstance().createElement(AiHeuristicConst.FUNCTION);
                nextElem.setText(dataInfo.getFunctionClass());
                rootElem.addContent(nextElem);
            }

            if ((dataInfo != null) && !dataInfo.getParams().isEmpty())
            {
                nextElem = XMLFactory.getInstance().createElement(Const.PARAMETERS);
                objElem = Parsers.serializeToElement(dataInfo.getParams());
                nextElem.addContent(objElem);
                rootElem.addContent(nextElem);
            }

            return rootElem;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /**
     * Parse an XML description of a {@link DataQueryModel} object back into the Java object.
     * @param toParse the XML description to parse.
     * @return the DataQuery object that is created.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element toParse) throws Exception
    {
        DataQueryModel dataInfo;                //data info object

        dataInfo = new DataQueryModel();
        parseInfo(toParse, dataInfo);

        return dataInfo;
    }

    /**
     * Parse an XML description of a {@link DataQueryModel} object back into the Java object.
     * @param toParse the XML description to parse.
     * @param dataInfo the data info object to place the parsed content in.
     * @throws java.lang.Exception any error.
     */
    public void parseInfo(Element toParse, DataQueryModel dataInfo) throws Exception
    {
        int i;
        LinkedHashMap data;                     //data map
        MetricDataset md;                       //metric dataset
        Node nextNode;                          //next node
        Element nextElem;                       //next element
        Element nextElem2;                      //next element
        Vector elemList;                        //element list
        
        try
        {
            if (toParse.getName().equals(Const.DATAINFO))
            {
                elemList = (Vector)toParse.getChildren().clone();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);

                    if (nextNode instanceof Element)
                    {
                        nextElem = (Element)nextNode;

                        if (nextElem.getName().equals(Const.DATASETTYPE))
                        {
                            dataInfo.setDataType(nextElem.getText());
                        }
                        else if (nextElem.getName().equals(AiHeuristicConst.VALUE1))
                        {
                            nextElem2 = nextElem.getElementChildAtIndex(0);
                            data = (LinkedHashMap)Parsers.parse(nextElem2);
                            md = MetricDataset.toDataset(dataInfo.getDataType(), data);
                            dataInfo.setDataset(md);
                        }
                        else if (nextElem.getName().equals(AiHeuristicConst.FUNCTION))
                        {
                            dataInfo.setFunctionClass(nextElem.getText());
                        }
                        else if (nextElem.getName().equals(Const.PARAMETERS))
                        {
                            nextElem2 = nextElem.getElementChildAtIndex(0);
                            dataInfo.setParams((LinkedHashMap)Parsers.parse(nextElem2));
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
