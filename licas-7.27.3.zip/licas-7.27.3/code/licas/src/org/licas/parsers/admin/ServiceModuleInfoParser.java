/*
 * ServiceModuleInfoParser.java
 *
 * Created on 1 December 2015
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.parsers.admin;


import org.licas.meta.LicasConfig;
import org.licas.meta.model.ServiceModuleInfo;
import org.licas.util.Const;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.Vector;


/**
 * This can parse a {@link ServiceModuleInfo} object that contains jar and class info for an
 * external service module.
 * @author Kieran Greer
 */
public class ServiceModuleInfoParser
{
    /** Create a new instance of ServiceModuleInfoParser */
    public ServiceModuleInfoParser()
    {}

    /**
     * Serialize the object into an XML element.
     * @param serviceInfo the service module information.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(ServiceModuleInfo serviceInfo) throws Exception
    {
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        
        rootElem = XMLFactory.getInstance().createElement(Const.SERVICETYPE);                 
        rootElem.setAttribute(Const.NAME, serviceInfo.serviceType); 
        if (serviceInfo.moduleName != null)
        {
            rootElem.setAttribute(Const.MODULE, serviceInfo.moduleName);
        }
        
        nextElem = XMLFactory.getInstance().createElement(Const.CLASSNAME);
        nextElem.setText(LicasConfig.checkClassName(serviceInfo.className));
        rootElem.addContent(nextElem);

        nextElem = XMLFactory.getInstance().createElement(Const.SERVICECATEGORY);
        nextElem.setText(serviceInfo.serviceCategory);
        rootElem.addContent(nextElem);

        if ((serviceInfo.description != null) && !serviceInfo.description.equals(""))
        {
            nextElem = XMLFactory.getInstance().createElement(Const.DESCRIPTION);
            nextElem.setText(serviceInfo.description);
            rootElem.addContent(nextElem);
        }

        if (serviceInfo.iconFile != null)
        {
            nextElem = XMLFactory.getInstance().createElement(Const.ICON);
            nextElem.setText(serviceInfo.iconFile);
            rootElem.addContent(nextElem);
        }

        if (serviceInfo.timeStamp > 0)
        {
            nextElem = XMLFactory.getInstance().createElement(Const.TIMESTAMP);
            nextElem.setText(String.valueOf(serviceInfo.timeStamp));
            rootElem.addContent(nextElem);
        }

        return rootElem;
    }
    
    /**
     * Parse the XML element back into the appropriate Object.
     * @param toParse the element to parse.
     * @return the parsed gui classname lists.
     * @throws java.lang.Exception any error.
     */
    public ServiceModuleInfo parse(Element toParse) throws Exception
    {
        int i;
        String serviceType;                         //service type
        String className;                           //class name
        String moduleName;                          //module name
        ServiceModuleInfo serviceInfo;              //service info
        Node nextNode;                              //next node
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        Vector elemList;                            //element list
        
        serviceInfo = null;
        rootElem = toParse;

        if (rootElem.getName().equals(Const.SERVICETYPE))
        {
            serviceInfo = new ServiceModuleInfo();
            serviceType = rootElem.getAttributeValue(Const.NAME);
            serviceInfo.serviceType = serviceType;
            moduleName = rootElem.getAttributeValue(Const.MODULE);
            serviceInfo.moduleName = moduleName;
                    
            elemList = rootElem.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(Const.CLASSNAME))
                    {
                        className = nextElem.getText().trim();
                        serviceInfo.className = LicasConfig.checkClassName(className);
                    }
                    else if (nextElem.getName().equals(Const.SERVICECATEGORY))
                    {
                        serviceInfo.serviceCategory = nextElem.getText().trim();
                    }
                    else if (nextElem.getName().equals(Const.DESCRIPTION))
                    {
                        serviceInfo.description = nextElem.getText().trim();
                    }
                    else if (nextElem.getName().equals(Const.ICON))
                    {
                        serviceInfo.iconFile = nextElem.getText().trim();
                    }
                    else if (nextElem.getName().equals(Const.TIMESTAMP))
                    {
                        serviceInfo.timeStamp = Long.parseLong(nextElem.getText().trim());
                    }
                }
            }
        }

        return serviceInfo;
    }
}
