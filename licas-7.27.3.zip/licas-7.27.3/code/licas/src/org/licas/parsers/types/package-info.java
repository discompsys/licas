/**
 * Parsers for processing basic data types and lists, where most of the XML-RPC information that you pass can be handled by these.
 */
package org.licas.parsers.types;