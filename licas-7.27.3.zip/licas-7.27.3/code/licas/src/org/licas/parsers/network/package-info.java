/**
 * Parsers for limited storage and re-construction of Network or SOA configurations.
 */
package org.licas.parsers.network;