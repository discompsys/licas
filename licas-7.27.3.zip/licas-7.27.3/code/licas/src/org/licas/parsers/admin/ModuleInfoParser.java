/*
 * ModuleInfoParser.java
 *
 * Created on 1 December 2015
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.parsers.admin;


import org.licas.meta.model.ModuleInfo;
import org.licas.util.Const;
import org.licas.util.ServiceConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.Vector;


/**
 * This can parse a {@link ModuleInfo} object that contains jar and class info for an
 * external module.
 * @author Kieran Greer
 */
public class ModuleInfoParser
{
    /** Create a new instance of ModuleInfoParser */
    public ModuleInfoParser()
    {}

    /**
     * Serialize the object into an XML element.
     * @param moduleInfo the module information.
     * @return the serialized object.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(ModuleInfo moduleInfo) throws Exception
    {
        int i;
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        
        rootElem = XMLFactory.getInstance().createElement(Const.MODULE);
        if (moduleInfo.moduleName != null)
        {
            rootElem.setAttribute(Const.NAME, moduleInfo.moduleName);
        }
        
        nextElem = XMLFactory.getInstance().createElement(ServiceConst.FILE);
        nextElem.setText(moduleInfo.filePath);
        rootElem.addContent(nextElem);
        
        if ((moduleInfo.tpJars != null) && !moduleInfo.tpJars.isEmpty())
        {
            nextElem = XMLFactory.getInstance().createElement(Const.JARFILESXML);
            rootElem.addContent(nextElem);
            
            for (i = 0; i < moduleInfo.tpJars.size(); i++)
            {
                nextElem2 = XMLFactory.getInstance().createElement(Const.JARFILEXML);
                nextElem2.setText((String)moduleInfo.tpJars.get(i));
                nextElem.addContent(nextElem2);
            }
        }
        
        nextElem = XMLFactory.getInstance().createElement(Const.INCLUDE);
        nextElem.setText(String.valueOf(moduleInfo.include));
        rootElem.addContent(nextElem);

        if (moduleInfo.timeStamp > 0)
        {
            nextElem = XMLFactory.getInstance().createElement(Const.TIMESTAMP);
            nextElem.setText(String.valueOf(moduleInfo.timeStamp));
            rootElem.addContent(nextElem);
        }

        return rootElem;
    }
    
    /**
     * Parse the XML element back into the appropriate Object.
     * @param toParse the element to parse.
     * @return the parsed gui classname lists.
     * @throws java.lang.Exception any error.
     */
    public ModuleInfo parse(Element toParse) throws Exception
    {
        int i, j;
        String moduleName;                          //module name
        ModuleInfo moduleInfo;                      //module info
        Node nextNode;                              //next node
        Element rootElem;                           //root element
        Element nextElem;                          //next element
        Element nextElem2;                          //next element
        Vector elemList;                            //element list
        Vector elemList2;                           //element list
                
        rootElem = toParse;
        moduleInfo = null;

        if (rootElem.getName().equals(Const.MODULE))
        {
            moduleInfo = new ModuleInfo();
            moduleName = rootElem.getAttributeValue(Const.NAME);
            moduleInfo.moduleName = moduleName;

            elemList = rootElem.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;   
                    if (nextElem.getName().equals(ServiceConst.FILE))
                    {
                        moduleInfo.filePath = nextElem.getText().trim();
                    }
                    else if (nextElem.getName().equals(Const.INCLUDE))
                    {
                        moduleInfo.include = Boolean.valueOf(nextElem.getText().trim()).booleanValue();
                    }
                    else if (nextElem.getName().equals(Const.JARFILESXML))
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equals(Const.JARFILEXML))
                                {
                                    moduleInfo.tpJars.add(nextElem2.getText().trim());
                                }
                            }
                        }
                    }
                    else if (nextElem.getName().equals(Const.TIMESTAMP))
                    {
                        moduleInfo.timeStamp = Long.parseLong(nextElem.getText().trim());
                    }
                }
            }
        }

        return moduleInfo;
    }
}
