/*
 * ArrayListParser.java
 *
 * Created on 19 May 2014
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers.types;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.parsers.Parsers;
import org.licas.util.Const;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.util.ArrayList;
import java.util.Vector;



/**
 * This class parses standard {@code ArrayList} structures. This includes parsing nested
 * lists and any objects that they might store.
 * @author Kieran Greer
 */
public class ArrayListParser extends ListParser
{
    /** The logger */
    private static Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ArrayListParser.class.getName());
        logger.setDebug(false);
    }

    
    /** Creates a new instance of ArrayListParser */
    public ArrayListParser() {
    }
    
    /**
     * Parse the toParse information to return a list of the values.
     * @param toParse a description of the data.
     * @throws java.lang.Exception any error.
     * @return a list with real values contained.
     */
    public Object parse(Element toParse) throws Exception
    {
        if (isList(ArrayList.class, toParse))
            return elementToArrayList(toParse);
        else
            return null;
    }
    
    /**
     * Parse the toParse information to return an ArrayList of the values.
     * @param toParse a description of the data.
     * @throws java.lang.Exception any error.
     * @return a list with real values contained.
     */
    private ArrayList elementToArrayList(Element toParse) throws Exception
    {
        ArrayList data;                     //the list to store the data in
        
        data = new ArrayList();
        elementToArrayList(data, toParse);        
        return data;
    }
    
    /**
     * Parse an ArryList to generate an xml representation.
     * @param toSerialize the data list.
     * @throws java.lang.Exception any error.
     * @return an element if a list or the original object if not a list.
     */
    public Element serialize(Object toSerialize) throws Exception
    {
        if ((toSerialize != null) && toSerialize.getClass().getName().equals(ArrayList.class.getName()))
        {
            return arrayListToElement((ArrayList)toSerialize);
        }
        
        return null;
    }
    
    /**
     * Parse an ArrayList to generate an xml representation.
     * @param data the data list.
     * @throws java.lang.Exception any error.
     * @return an xml representation of the list.
     */
    private Element arrayListToElement(ArrayList data) throws Exception
    {
        Element rootElem;                   //the root element
        
        rootElem = XMLFactory.getInstance().createElement(Const.PARAMETERS);
        rootElem.setAttribute(Const.CONVERSIONTYPE, ArrayList.class.getName());        
        arrayListToElement(data, rootElem);

        return rootElem;
    }
    
    /**
     * Parse the information to return an ArrayList of the values.
     * @param data the list to store the data in.
     * @param paramXml a description of the {@link Const}.{@code PARAMETER} data.
     * @throws java.lang.Exception any error.
     */
    public static void elementToArrayList(ArrayList data, Element paramXml) throws Exception
    {
        int i, j;
        boolean dataAdded;                          //true if data added
        String nextType;                            //next data type
        String nextValue;                           //next data value
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Element nextElem3;                          //next element
        Vector elemList;                            //child elements
        Vector elemList2;                           //child elements
        Vector elemList3;                           //child elements
        
        try 
        {
            elemList = paramXml.getChildren();
            for (i=0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    XmlHandler.xmlToString((Element)nextNode);
                
                    if (nextElem.getName().equalsIgnoreCase(Const.PARAMETER))
                    {
                        dataAdded = false;
                        nextType = null;
                        nextValue = null;
                        nextElem3 = null;
                        elemList3 = null;

                        elemList2 = nextElem.getChildren();
                        for (j=0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);                            
                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;
                                if (nextElem2.getName().equalsIgnoreCase(Const.TYPE))
                                {
                                    nextType = nextElem2.getValue();
                                }
                                else if (nextElem2.getName().equalsIgnoreCase(Const.VALUE))
                                {
                                    elemList3 = nextElem2.getChildren();
                                    nextValue = nextElem2.getValue();
                                }
                                else
                                {
                                    data.add(Parsers.parse(nextElem2));
                                    dataAdded = true;
                                }
                            }
                        }

                        if (!dataAdded)
                        {
                            nextElem3 = null;                       
                            if (elemList3 != null)
                            {
                                for (j=0; j < elemList3.size(); j++)
                                {
                                    nextNode = (Node)elemList3.get(j);
                                    if (nextNode instanceof Element)
                                    {
                                        nextElem3 = (Element)nextNode;
                                        break;
                                    }
                                }
                            } 
                           
                            createAddListObject(data, nextType, nextValue, nextElem3);
                        }
                    }
                }
            }
        } 
        catch (Exception ex) 
        {
            throw ex;
        }
    }
    
    /**
     * Parse an ArrayList to generate an xml representation.
     * @param data the data list.
     * @param rootElem the root element.
     * @throws java.lang.Exception any error.
     */
    public static void arrayListToElement(ArrayList data, Element rootElem) throws Exception
    {
        int i;
        
        try 
        {        
            for (i = 0; i < data.size(); i++)
            {
                Parsers.createParameterElement(data.get(i), rootElem);
            }    
        } 
        catch (Exception ex) 
        {
            throw ex;
        }
    }
}
