/*
 * DomParser.java
 *
 * Created on 29 January 2018
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers.types;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.util.StringHandler;
import org.licas.util.ObjectHandler;
import org.w3c.dom.Document;
import org.w3c.dom.bootstrap.DOMImplementationRegistry;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSSerializer;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.StringReader;
import java.io.StringWriter;


/**
 * This class serialises and parses a {@link org.w3c.dom.Document} object to or from XML.
 * https://www.journaldev.com/1237/java-convert-string-to-xml-document-and-xml-document-to-string
 * @author Kieran Greer
 */
public class DomParser
{
    /** The logger */
    private static Logger logger;
    
    /** Codes a string as a w3c dom document */
    public static final String W3CDOM = "#1orgw3cdom1#";

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(DomParser.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Return true if the object is a w3c {@link Document} type.
     * @param xmlElem the string parameter.
     * @return true if not null and w3c Document type, false otherwise.
     */
    public static boolean isW3cDom(String xmlElem)
    {
        return ((xmlElem != null) && xmlElem.trim().startsWith(W3CDOM));
    }
    
    /**
     * Return true if the object is a w3c {@link Document} type.
     * @param xmlElem the element parameter.
     * @return true if not null and w3c Document type, false otherwise.
     */
    public static boolean isW3cDom(Object xmlElem)
    {
        if (xmlElem != null)
        {
            if (ObjectHandler.isString(xmlElem)) return isW3cDom((String)xmlElem);
            else return (xmlElem instanceof org.w3c.dom.Node);
        }
        
        return false;
    }
    
    /**
     * Serialize a {@link org.w3c.dom.Document} object to XML.
     * @param toSerialize the ByteArray object to serialize.
     * @return an XML description of the object.
     * @throws java.lang.Exception any error.
     */
    public static String serialize(Document toSerialize) throws Exception
    {
        String output = "";                     //output string
        
        if (toSerialize != null)
        {
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer transformer;

            transformer = tf.newTransformer();
            // below code to remove XML declaration
            // transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(toSerialize), new StreamResult(writer));
            output = writer.getBuffer().toString();
        }
        
        output = addW3cSpec(output);
        return output;
    }
    
    /**
     * Parse a String description of a {@link org.w3c.dom.Document} object back into a Java object.
     * @param toParse the XML description to parse.
     * @return the Document object that is created.
     * @throws java.lang.Exception any error.
     */
    public static Document parse(String toParse) throws Exception
    {
        Document doc = null;            //dom document
        
        if (toParse != null)
        {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
            DocumentBuilder builder;  

            builder = factory.newDocumentBuilder();  
            toParse = removeW3cSpec(toParse);
            doc = builder.parse(new InputSource(new StringReader(toParse))); 
        }
        
        return doc;
    }
    
    /**
     * Add the special characters indicating a string of {@code org.wc3.dom XML} format that should
     * not be converted into anything else. The Parsers however will automatically
     * try to remove this coding as part of a final parsing event.
     * @param xmlStr the original String.
     * @return the String with the special characters included.
     */
    public static String addW3cSpec(String xmlStr)
    {
        if (xmlStr == null) xmlStr = "";
        xmlStr = xmlStr.trim();
        if (!xmlStr.startsWith(W3CDOM)) xmlStr = (W3CDOM + xmlStr);
        
        return xmlStr;
    }
    
    /**
     * Remove the special characters indicating a string of {@code org.wc3.dom XML} format
     * that should not be converted into anything else.
     * @param xmlStr the original String with the special characters included.
     * @return the String with the special characters removed.
     */
    public static String removeW3cSpec(String xmlStr)
    {
        if (xmlStr == null)
        {
            xmlStr = "";
        }
        else 
        {
            xmlStr = xmlStr.trim();
            if (xmlStr.startsWith(W3CDOM))
            {
                xmlStr = StringHandler.replaceFirst(xmlStr, W3CDOM, "");
            }
        }

        return xmlStr.trim();
    }

	/**
     * Pretty format the w3c document and return the string representation.
     * @param doc the w3c document.
     * @param keepDeclaration true if keep the header declaration.
     * @return the text where the XML is appropriately formatted wrt indentation.
     * @throws java.lang.Exception any error.
     */
    public static String prettyFormatXml(org.w3c.dom.Document doc, boolean keepDeclaration) throws Exception
    {
        //https://stackoverflow.com/questions/139076/how-to-pretty-print-xml-from-java
        DOMImplementationRegistry registry = DOMImplementationRegistry.newInstance();
        DOMImplementationLS impl = (DOMImplementationLS) registry.getDOMImplementation("LS");
        LSSerializer writer = impl.createLSSerializer();
        writer.getDomConfig().setParameter("format-pretty-print", Boolean.TRUE);
        writer.getDomConfig().setParameter("xml-declaration", keepDeclaration);
        return writer.writeToString((org.w3c.dom.Node)doc.getDocumentElement());
    }
}
