/*
 * MyObjectInputStream.java
 *
 * Created on 30 April 2007
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 *
 * Author: Kieran Greer
 */

package org.licas.parsers.types;

import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.util.ObjectHandler;
import org.licas.util.classloader.LoadObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;


/**
 * This class extends a Java {@code ObjectInputStream} to allow a specified class loader to be used.
 * @author Kieran Greer
 */
public class MyObjectInputStream extends ObjectInputStream
{
    /** The logger */
    private static Logger logger;
    
    /** The class loader */
    protected ClassLoader myLoader = null;
 
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(MyObjectInputStream.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Construct a new MyObjectinputyStream class.
     * @param theStream the input stream.
     * @throws java.lang.Exception any error.
     */
    public MyObjectInputStream(InputStream theStream) throws Exception
    {
        super(theStream);
    }
    
    /**
     * Construct a new MyObjectInputStream class.
     * @param theLoader the class loader to use.
     * @param theStream the input stream.
     * @throws java.lang.Exception any error.
     */
    public MyObjectInputStream(ClassLoader theLoader, InputStream theStream) throws Exception
    {
        super(theStream);
        myLoader = theLoader;
    }
    
    /**
     * Resolve the class.
     * @param osc the class to resolve.
     * @return an instance of the class, or null if there is an error.
     * @throws IOException for errors.
     * @throws ClassNotFoundException for errors.
     */
    protected Class resolveClass(ObjectStreamClass osc) throws IOException, ClassNotFoundException
    {
        Class theClass = null;
        
        try
        {
            theClass = Class.forName(ObjectHandler.toObjectClass(osc.getName()), true, myLoader);
            theClass = LoadObject.getClass(osc.getName());
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "resolveClass",
                null, ex);
        }
        
        return theClass;
    }
}
