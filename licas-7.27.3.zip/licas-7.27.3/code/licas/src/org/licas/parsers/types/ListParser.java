/*
 * ListParser.java
 *
 * Created on 24 February 2007
 *
 * Version 1.4
 *
 * Copyright (c) Kieran Greer.
 *
 * Author: Kieran Greer
 */

package org.licas.parsers.types;


import org.ai_heuristic.def.ParserDef;
import org.licas.parsers.Parsers;
import org.licas.util.Const;
import org.licas.util.ObjectHandler;
import org.licas_xml.abs.Element;

import java.util.List;
import java.util.Map;


/**
 * This class parses standard list structures of simple types or other list structures.
 * This class is extended by the {@code HashMap} and the {@code ArrayList} parsers.
 * @author Kieran Greer
 */
public abstract class ListParser implements ParserDef
{
    /** Defines an array class */
    public static final String ARRAYCLASS = "[";
    
    
    /** Creates a new instance of ListParser */
    public ListParser() {
    }
    
    /**
     * Create and add the object as specified by the parameters.
     * @param data the list to store the data in.
     * @param type the object type.
     * @param value the object value if there is one.
     * @param rootElem root element if need to parse further.
     * @throws java.lang.Exception any error.
     */
    protected static void createAddListObject(List data, String type, String value,
        Element rootElem) throws Exception
    {
        if (value != null)
        {
            data.add(Parsers.createObject(type, value));
        }
        else
        {
            data.add(Parsers.createObject(type, rootElem));
        }
    }
    
    /**
     * Create and add the object as specified by the parameters.
     * @param data the map to store the data in.
     * @param type the object type.
     * @param key the entry key.
     * @param value the object value if there is one.
     * @param rootElem root element if need to parse further.
     * @throws java.lang.Exception any error.
     */
    protected static void createAddMapObject(Map data, String type, String key, 
            String value, Element rootElem) throws Exception
    {
        Object parserObj;                           //parser object
        
        if (value != null)
        {
            parserObj = Parsers.createObject(type, value);
        }
        else
        {
            parserObj = Parsers.createObject(type, rootElem);
        }
        
        if (parserObj != null)
        {
            data.put(key, parserObj);
        }
    }
    
    /**
     * Return true if the xml element is a parsed list of the same type as the 
     * class passed in. It should also be either a ArrayList, a HashMap or an Array[
     * of simple types String/Integer/Float/Double/Byte/Boolean.
     * @param param1 the parameter class to compare.
     * @param xmlElem the xml element.
     * @return true if its root element contains the list type as an attribute.
     */
    public static boolean isList(Class param1, Element xmlElem)
    {
        String className;                   //element class
        
        className = ElementParser.getAttributeValue(Const.CONVERSIONTYPE, xmlElem);       
        if (className != null)
        {
            if (ObjectHandler.isArrayList(param1.getName()) ||
                ObjectHandler.isVector(param1.getName()) ||
                ObjectHandler.isHashtable(param1.getName()) ||
                ObjectHandler.isHashMap(param1.getName()) ||
                ObjectHandler.isLinkedList(param1.getName()) ||
                ObjectHandler.isLinkedHashMap(param1.getName()) ||
                ObjectHandler.isStack(param1.getName()) ||
                ObjectHandler.isArrayType(param1.getName()))
            {
                return (className.equals(param1.getName()));
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
}
