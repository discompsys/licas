/*
 * FileObjectParser.java
 *
 * Created on 30 April 2012
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 *
 * Author: Kieran Greer
 */

package org.licas.parsers.types;


import org.ai_heuristic.def.ParserDef;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.util.*;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;
import java.util.Vector;


/**
 * This class parses a {@link FileObject} to or from XML.
 * @author Kieran Greer
 */
public class FileObjectParser implements ParserDef
{
    /** The logger */
    private static Logger logger;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(FileObjectParser.class.getName());
        logger.setDebug(false);
    }

    
    /** Creates a new instance of FileObjectParser */
    public FileObjectParser() 
    {}
    
    /**
     * Parse the xml element to return the java object.
     * @param fileXml a description of the file object.
     * @return the xml elements or the original String if not xml.
     * @throws java.lang.Exception any error.
     */
    public Object parse(Element fileXml) throws Exception
    {
        int i;
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Vector elemList;                            //element list
        ByteArrayParser byteParser;                 //byte array parser
        FileObject fileObj;                         //file object
        ArrayListParser arrParser;                  //vector parser
        Object parsed;                              //parsed object
        
        fileObj = null;
        try
        {
            fileObj = new FileObject();
            byteParser = new ByteArrayParser();
            arrParser = new ArrayListParser();
            
            if (fileXml.getName().equals(Const.FILEOBJECT))
            {
                elemList = fileXml.getChildren();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);
                    if (nextNode instanceof Element)
                    {
                        nextElem = (Element)nextNode;
                        if (nextElem.getName().equals(Const.FILEURI))
                        {
                            fileObj.setFilePath(nextElem.getText());
                        }
                        else if (nextElem.getName().equals(Const.CLASSNAME))
                        {
                            fileObj.setClassType(nextElem.getText());
                        }
                        else if (nextElem.getName().equals(Const.ASBYTES))
                        {
                            fileObj.setAsBytes(Boolean.valueOf(nextElem.getText()).booleanValue());
                        }
                        else if (nextElem.getName().equals(Const.PASSWORD))
                        {
                            fileObj.setPassword(nextElem.getText());
                        }
                        else if (nextElem.getName().equals(Const.FILECONTENT))
                        {
                            if (nextElem.hasChildren())
                            {
                                nextElem2 = nextElem.getElementChildAtIndex(0);
                                if (nextElem2.getName().equals(TypeConst.BYTELIST))
                                    parsed = byteParser.parse(nextElem2);
                                else
                                    parsed = arrParser.parse(nextElem2);
                                
                                if (parsed == null) parsed = nextElem2;                         
                                fileObj.setFileContents(parsed);
                            }
                            else
                            {
                                fileObj.setFileContents(nextElem.getText());
                            }
                        }
                    }
                }
            }
            
            return fileObj;
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "parse",
                null, ex);
            
            return fileObj;
        }
    }
    
    /**
     * Convert the file object into xml format if a parser exists.
     * @param nextObj the object to convert.
     * @return the object converted into an XML-based description.
     */
    public Element serialize(Object nextObj)
    {
        FileObject fileObj;                         //file object
        Element objXml;                             //file object as xml
        Element nextElem;                           //next element
        ByteArrayParser byteParser;                 //byte array parser
        ArrayListParser arrParser;                  //arraylist parser
        
        try
        {
            objXml = null;
            byteParser = new ByteArrayParser();
            arrParser = new ArrayListParser();
            
            if (nextObj != null)
            {
                fileObj = (FileObject)nextObj;
                objXml = XMLFactory.getInstance().createElement(Const.FILEOBJECT);
                
                if (fileObj.getFilePath() != null)
                {
                    nextElem = XMLFactory.getInstance().createElement(Const.FILEURI);
                    nextElem.setText(fileObj.getFilePath());
                    objXml.addContent(nextElem);
                }
                
                if (fileObj.getClassType() != null)
                {
                    nextElem = XMLFactory.getInstance().createElement(Const.CLASSNAME);
                    nextElem.setText(fileObj.getClassType());
                    objXml.addContent(nextElem);
                }
                
                nextElem = XMLFactory.getInstance().createElement(Const.ASBYTES);
                nextElem.setText(Boolean.toString(fileObj.getAsBytes()));
                objXml.addContent(nextElem);
                
                nextElem = XMLFactory.getInstance().createElement(Const.PASSWORD);
                nextElem.setText(fileObj.getPassword());
                objXml.addContent(nextElem);
                
                if (fileObj.getFileContents() != null)
                {
                    nextElem = XMLFactory.getInstance().createElement(Const.FILECONTENT);                            
                    if (fileObj.getFileContents() instanceof ByteArray)
                    {
                        nextElem.addContent(byteParser.serialize(fileObj.getFileContents()));                      
                        objXml.addContent(nextElem);
                    }
                    else if (ObjectHandler.isString(fileObj.getFileContents()))
                    {
                        nextElem.setText((String)fileObj.getFileContents());                      
                        objXml.addContent(nextElem);
                    }
                    else if (DomParser.isW3cDom(fileObj.getFileContents()))
                    { 
                        nextElem.setText(DomParser.serialize((org.w3c.dom.Document)fileObj.getFileContents()));
                        objXml.addContent(nextElem);
                    }
                    else if (fileObj.getFileContents() instanceof Element)
                    { 
                        nextElem.setText(ElementParser.serialize((Element)fileObj.getFileContents()));
                        objXml.addContent(nextElem);
                    }
                    else if (fileObj.getFileContents() instanceof ArrayList)
                    {
                        nextElem.addContent(arrParser.serialize(fileObj.getFileContents()));
                        objXml.addContent(nextElem);
                    }
                }
            }
            
            return objXml;
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "serialize",
                null, ex);
            
            return null;
        }
    }
}
