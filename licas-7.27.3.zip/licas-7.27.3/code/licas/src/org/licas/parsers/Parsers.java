/*
 * Parsers.java
 *
 * Created on 27 March 2007
 *
 * Version 1.14.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers;


import org.ai_heuristic.def.ParserDef;
import org.ai_heuristic.eval.metric.MetricDataset;
import org.ai_heuristic.eval.metric.MetricValue;
import org.ai_heuristic.eval.metric.ReplySet;
import org.ai_heuristic.model.BagOfWords;
import org.ai_heuristic.model.MetaBagOfWords;
import org.ai_heuristic.model.NodeStats;
import org.ai_heuristic.parser.BagOfWordsParser;
import org.ai_heuristic.parser.MetaBagOfWordsParser;
import org.ai_heuristic.tree.*;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.StringHandler;
import org.jlog2.util.UuidHandler;
import org.licas.AdminInfo;
import org.licas.MessageInfo;
import org.licas.call.MethodInfo;
import org.licas.call.ParamInfo;
import org.licas.data.ComparisonQueryModel;
import org.licas.data.DataQueryModel;
import org.licas.meta.ServiceMeta;
import org.licas.parsers.admin.AdminParser;
import org.licas.parsers.admin.KeywordHandlerParser;
import org.licas.parsers.admin.ServiceMetaParser;
import org.licas.parsers.sci.*;
import org.licas.parsers.types.*;
import org.licas.query.LinkQueryConfig;
import org.licas.server.model.*;
import org.licas.service.model.*;
import org.licas.service.sci.DataTransfer;
import org.licas.service.spec.LinkSpec;
import org.licas.util.*;
import org.licas.util.exception.LicasException;
import org.licas.ws.WsMethodInfo;
import org.licas.ws.wsdl.model.WsdlParamInfo;
import org.licas_text.parser.QueryParser;
import org.licas_text.query.model.QueryModel;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.io.FileWriter;
import java.io.Serializable;
import java.util.*;

import static org.licas.parsers.types.ObjectParser.SERIALIZED;


/**
 * The communication parsing goes through this class. It stores the appropriate parser 
 * to parse any of the registered data structures. This class initiates the parsing procedure 
 * to convert a Java object into XML or String and back again.
 * <p>
 * There are a number of default parsers for standard Java objects, that
 * this parser will load when it is initiated. These will parse a number of different
 * list types, XML elements, or other standard objects. You can then add your own parser
 * for any objects that you might pass as part of a communication process. The
 * {@code addParser} method adds the parser here, in the form of the parser itself
 * and the name of the class that it will parse. To add a parser to a remote server,
 * you invoke the addParser method on the server instead. The parsing process will
 * also try to Base64 serialize objects if there is no XML parser available and they have
 * extended the Java {@link Serializable} interface.
 * @author Kieran Greer
 */
public class Parsers 
{
    /** The logger */
    private static Logger logger;
    
    /** Parser parse method */
    protected static final String PARSE = "parse";
        
    /** Parser serialize method */
    protected static final String SERIALIZE = "serialize";
    
    /** 
     * A list of parsers. Parsers are stored in this structure, where the key is
     * the name of the class that is to be parsed and the value is the parser itself.
     * When an object needs to be parsed, the class name is retrieved and looked for
     * as the key to a parser in this list. If a parser with that key name exists, it
     * is then used to try to parse the object.
     */
    private static HashMap parsers;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(Parsers.class.getName());
        logger.setDebug(false);
        
        //add default parsers
        parsers = new HashMap();        
        parsers.put(AdminInfo.class.getName(), new AdminParser());
        parsers.put(ServiceMeta.class.getName(), new ServiceMetaParser());
        parsers.put(MethodInfo.class.getName(), new MethodInfoParser());
        parsers.put(WsMethodInfo.class.getName(), new WebServiceMethodInfoParser());
        parsers.put(MessageInfo.class.getName(), new MessageInfoParser());
        parsers.put(DataQueryModel.class.getName(), new DataQueryModelParser());
        parsers.put(DataTransfer.class.getName(), new DataTransferParser());
        parsers.put(ComparisonQueryModel.class.getName(), new ComparisonQueryModelParser());
        parsers.put(WorkInfo.class.getName(), new WorkInfoParser());
        parsers.put(Contract.class.getName(), new ContractParser());
        parsers.put(QueryModel.class.getName(), new QueryParser());
        parsers.put(KeywordHandler.class.getName(), new KeywordHandlerParser());
        parsers.put(KeywordInfo.class.getName(), new KeywordInfoParser());
        parsers.put(ParamInfo.class.getName(), new ParameterParser());
        parsers.put(WsdlParamInfo.class.getName(), new ParameterParser());
        parsers.put(AddressInfo.class.getName(), new AddressInfoParser());
        parsers.put(BagOfWords.class.getName(), new BagOfWordsParser());
        parsers.put(MetaBagOfWords.class.getName(), new MetaBagOfWordsParser());
        parsers.put(MetricDataset.class.getName(), new MetricDatasetParser());
        parsers.put(MetricValue.class.getName(), new MetricValueParser());
        parsers.put(ReplySet.class.getName(), new ReplySetParser());
        parsers.put(Tree.class.getName(), new TreeParser());
        parsers.put(TreeNode.class.getName(), new TreeNodeParser());
        parsers.put(KD_Tree.class.getName(), new KD_TreeParser());
        parsers.put(KD_TreeNode.class.getName(), new KD_TreeNodeParser());
        parsers.put(NodeStats.class.getName(), new NodeStatsParser());
        parsers.put(LinkSpec.class.getName(), new LinkSpecParser());
        parsers.put(LinkQueryConfig.class.getName(), new LinkQueryParser());
        parsers.put(Vector.class.getName(), new VectorParser());
        parsers.put(ArrayList.class.getName(), new ArrayListParser());
        parsers.put(LinkedList.class.getName(), new LinkedListParser());
        parsers.put(Hashtable.class.getName(), new HashtableParser());
        parsers.put(HashMap.class.getName(), new HashMapParser());
        parsers.put(LinkedHashMap.class.getName(), new LinkedHashMapParser());
        parsers.put(Stack.class.getName(), new StackParser());
        parsers.put(ListParser.ARRAYCLASS, new ArrayParser());
        parsers.put(Element.class.getName(), new ElementParser());
        parsers.put(java.util.Date.class.getName(), new DateParser());
        parsers.put(FileObject.class.getName(), new FileObjectParser());
        parsers.put(ByteArray.class.getName(), new ByteArrayParser());
        parsers.put(HttpEntity.class.getName(), new HttpEntityParser());
    }


    /** Creates a new instance of Parsers */
    public Parsers() {       
    }
    
    /**
     * Return true if a parser for the specified class type exists.
     * @param classType the class type of the object that needs parsing.
     * @return true if a parser has been added for that class type,
     * false otherwise.
     */
    public static boolean hasParser(String classType)
    {
        return parsers.containsKey(classType);
    }
    
    /**
     * Add a new parser to the list, but do not overwrite an existing parser for that class.
     * @param className the class name of the object that the parser will parse.
     * @param parser the parser. Must implement ParserDef interface.
     * @return true if the parser is added, false otherwise.
     */
    public static boolean addParser(String className, Object parser)
    {
        if (parser instanceof ParserDef)
        {
            if (parsers == null) parsers = new HashMap();
            if (!parsers.containsKey(className))
            {
                parsers.put(className, parser);
                return true;
            }
        }

        return false;
    }
    
    /**
     * Add a new parser to the list.
     * @param className the class name of the object to parse.
     * @return true if the operation was OK.
     */
    public static boolean removeParser(String className)
    {
        if (parsers.containsKey(className)) parsers.remove(className);
        return true;
    }
    
    /**
     * Return a parser for the specified class type if one exists.
     * @param classType the class type of the object that needs parsing.
     * @return a parser if one has been added for that class type,
     * null otherwise.
     */
    public static ParserDef getParser(String classType)
    {
        if (parsers.containsKey(classType))
        {
            return (ParserDef)parsers.get(classType);
        }
        
        return null;
    }
    
    /**
     * Parse an object representation back into the correct object. This adds another
     * layer above the {@code parse} methods, before calling them.
     * NOTE: The class type is assumed to be what the object itself is.
     * @param toParse the object description to convert.
     * @return a converted description, or the object itself if that was not possible.
     * @throws java.lang.Exception any error.
     */
    public static Object parseObject(Object toParse) throws Exception
    {
        String classType;                   //clas type
        Element objElem;                    //object element

        if (toParse != null)
        {
            //toParse can still be previously serialized element, so check if element
            // and has conversiontype attribute, if object then parse as that
            if (ObjectHandler.isElement(toParse)) {
                objElem = (Element)toParse;
                classType = objElem.getAttributeValue(Const.CONVERSIONTYPE);
                if ((classType == null) || classType.equals(""))
                {
                    classType = toParse.getClass().getName();
                }
            }
            else {
                classType = toParse.getClass().getName();
            }

            return parseObject(classType, toParse);
        }
        else
        {
            return null;
        }
    }
    
    /**
     * Parse an object representation back into the correct object. This adds another
     * layer above the {@code parse} methods, before calling them.
     * @param className the object class name, in case different to the representation object.
     * @param toParse the object description to convert.
     * @return a converted description, or the object itself if that was not possible.
     * @throws java.lang.Exception any error.
     */
    public static Object parseObject(String className, Object toParse) throws Exception
    {
        if (toParse != null)
        {
            if (TypeConst.isSimpleType(className))
            {
                if (ObjectHandler.isString(toParse))
                {
                    return Parsers.createObject(className, (String)toParse);
                }
                else if (ObjectHandler.isElement(toParse))
                {
                    return Parsers.createObject(className, (Element)toParse);
                }
            }
            else
            {
                if (ObjectHandler.isString(toParse))
                {
                    return Parsers.parse((String)toParse);
                }
                else if (ObjectHandler.isElement(toParse))
                {
                    return Parsers.parse((Element)toParse);
                }
            }
        }
        
        return toParse;
    }
    
    /**
     * If a parser is available for the object then convert the String-based
     * xml description of the element back to the object. The process is to
     * convert this into an Element and parse again, or de-serialize and return.
     * @param toParse the object description to parse back.
     * @return the original object, or null if {@code toParse} is null.
     * @throws java.lang.Exception any error.
     */
    public static Object parse(String toParse) throws Exception
    {
        Object origObj;                     //the original object
        
        origObj = null;
        if (toParse != null)
        {
            if (DomParser.isW3cDom(toParse))
            {
                //w3c document is converted separately - to 'Document' only
                //code is removed first
                origObj = DomParser.parse(toParse);
            }
            else
            {
                if (toParse.equals(Const.NULL))
                {
                    origObj = null;
                }
                else if (toParse.startsWith(SERIALIZED + XmlHandler.SEPARATOR))
                {
                    toParse = removeCoding(toParse);
                    origObj = ObjectParser.parse(toParse);
                }
                else
                {
                    //try to parse to element then object
                    //if still a String then not in correct format, so just return
                    origObj = ElementParser.parse(toParse);
                    if ((origObj != null) && ObjectHandler.isElement(origObj))
                    {
                        origObj = parse((Element)origObj);
                    }
                    else
                    {
                        //may be string description of other object in XML, so try to force conversion
                        //if not, then reset to original string, same as this section missing
                        try
                        {
                            origObj = XmlHandler.stringToElement(toParse);
                            if ((origObj != null) && ObjectHandler.isElement(origObj))
                            {
                                origObj = parse((Element)origObj);
                            }
                        }
                        catch (Exception ex)
                        {
                            origObj = toParse;
                        }
                    }
                }
            }
        }
        
        return origObj;
    }
    
    /**
     * If a parser is available for the object then convert the element
     * back to the object. If no conversion type attribute, as part of a
     * parameter description, then return the original toParse Element.
     * @param toParse the object to parse back.
     * @return the original object.
     * @throws java.lang.Exception any error.
     */
    public static Object parse(Element toParse) throws Exception
    {
        String theClassName;                //class name
        Object origObj;                     //the original object
        
        try
        {
            theClassName = ElementParser.getAttributeValue(Const.CONVERSIONTYPE, toParse);
            if (theClassName != null) origObj = parse(theClassName, toParse);
            else origObj = toParse;
            
            return origObj;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parse",
                    null, ex);
        }
    }
    
    /**
     * If a parser is available for the object then convert the element
     * back to the object. See also {@code parseObject}.
     * @param className the class name of the object to create.
     * @param toParse the element to parse back into a java object.
     * @return the original object.
     * @throws java.lang.Exception any error.
     */
    private static Object parse(String className, Element toParse) throws Exception
    {
        ParserDef parser;                   //the parser
        Object origObj;                     //the original object
        
        try
        {
            origObj = toParse;
            if (origObj != null)
            {
                if (className != null)
                {
                    if (className.startsWith(ListParser.ARRAYCLASS))
                        className = ListParser.ARRAYCLASS;
                    
                    if (parsers.containsKey(className) && (!XmlHandler.isElement(className)))
                    {
                        parser = (ParserDef)parsers.get(className);                        
                        origObj = parser.parse(toParse);
                    }
                    else if (TypeConst.isSimpleType(className))
                    {
                        origObj = createObject(className, toParse);
                    }
                }
            }

            return origObj;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parse",
                    null, ex);
        }
    }
    
    /**
     * Convert the object into an xml String format if a parser exists.
     * @param toSerialize the object to convert.
     * @return the object parsed into xml-based String.
     * @throws java.lang.Exception any error.
     */
    public static String serializeToString(Object toSerialize) throws Exception
    {
        String reply;                           //serialized reply
        
        reply = (String)serialize(toSerialize, true);
        if (reply == null) reply = Const.NULL;       
        
        return reply;
    }
    
    /**
     * Convert the object into an xml Element if a parser exists. If a String
     * reply is serialized, then wrap that in a single element before returning.
     * @param toSerialize the object to convert.
     * @return the parsed object, wrapped in an xml {@link Element}.
     * @throws java.lang.Exception any error.
     */
    public static Element serializeToElement(Object toSerialize) throws Exception
    {
        Element xmlElem;                        //xml element
        Object reply;                           //serialized reply
        
        xmlElem = null;
        reply = serialize(toSerialize, false);
        if (reply == null) reply = Const.NULL;       
        
        if (ObjectHandler.isString(reply))
        {
            xmlElem = XMLFactory.getInstance().createElement(Const.OBJECT);
            xmlElem.setText((String)reply);
            ElementParser.setAttribute(Const.CONVERSIONTYPE, reply.getClass().getName(), 
                    xmlElem);
        }
        else
        {
            xmlElem = (Element)reply;
        }
        
        return xmlElem;
    }
    
    /**
     * Convert the object into an xml-based description if a parser exists and
     * save it to a file. Create a {@code PacketInfo} object to represent the file.
     * @param toSerialize the object to convert.
     * @return the {@code PacketInfo} object with the information. This can then be 
     * read in parts, for example.
     * @throws java.lang.Exception any error.
     */
    public static PacketInfo serializeToFile(Object toSerialize) throws Exception
    {
        String fileName;                    //name of the file if used
        String reply;                       //serialized reply
        FileWriter fileOutput;              //the file to write to
        PacketInfo packetInfo;              //info about the file writen to
        
        reply = serializeToString(toSerialize);
        if (reply == null) reply = Const.NULL;       
        
        fileName = UuidHandler.getUuid(10) + ".xml";
        packetInfo = new PacketInfo(fileName, 0);

        if (packetInfo.createFile())
        {
            fileOutput = packetInfo.getFileWriter();
            fileOutput.write(Const.XMLHEADER + " " + reply);
            if (packetInfo.getInputStream() == null) packetInfo = null;
        }
        else
        {
            throw new LicasException("Parsers Error: could not create file: " + fileName);
        }
        
        return packetInfo;
    }
    
    /**
     * Convert the object into an xml element or an xml String-based format, if the correct 
     * parser exists. If {@code xmlToString} is true then convert any Element-based description
     * further into a String-based one. If false, then the element-based description can be
     * returned.
     * <p/>
     * NOTE: This will return simply a String value regardless of other settings, 
     * if the input object is simply a String itself. It is most often used as part 
     * of the communication process serializing. See also {@code serializeToElement} 
     * for forcing an Element reply.
     * @param toSerialize the object to serialize.
     * @param xmlToString if true then continue serialization from XML element to 
     * XML-based string. If false then terminate the serialization after the XML 
     * element description is created. The default for remote communications should 
     * be true.
     * @return the serialized object Xml or String representation, or null if serializing 
     * is not possible.
     * @throws java.lang.Exception any error.
     */
    private static Object serialize(Object toSerialize, boolean xmlToString) 
            throws Exception
    {
        String xmlStr;                  //xml converted to a string if used
        Object xmlElem;                 //xml element

        try
        {
            xmlElem = toSerialize;
            if ((xmlElem != null) && !ObjectHandler.isString(xmlElem))
            {
                if (DomParser.isW3cDom(xmlElem))
                {
                    //w3c document is converted separately and automatically
                    //code is added so not parsed back accidentally
                    xmlStr = DomParser.serialize((org.w3c.dom.Document)xmlElem);
                    xmlElem = xmlStr;
                }
                else
                {
                    if (!(XmlHandler.isElement(xmlElem.getClass().getName())))
                    {
                        xmlElem = serializeObj(toSerialize);
                        if (xmlElem == null)
                        {
                            //create a serialized String instead
                            xmlElem = ObjectParser.serialize(toSerialize);
                            if (xmlElem != null)
                            {
                                xmlElem = (SERIALIZED + XmlHandler.SEPARATOR +
                                        (String)xmlElem);
                            }
                        }
                    }

                    //if serialized object is now an element, check for further serialization
                    if ((xmlElem != null) && XmlHandler.isElement(xmlElem.getClass().getName()))
                    {
                        ElementParser.setAttribute(Const.CONVERSIONTYPE, 
                                toSerialize.getClass().getName(), (Element)xmlElem);

                        if (xmlToString)
                        {
                            xmlStr = ElementParser.serialize((Element)xmlElem);
                            xmlElem = xmlStr;
                        }
                    }
                }
            }

            //should be a string or an element
            return xmlElem;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "serialize",
                    null, ex);
        }
    }
    
    /**
     * If a parser is available for the object convert to an XML element representation.
     * @param toSerialize the object to convert into xml.
     * @return the object in xml format or null if this is not possible.
     * @throws java.lang.Exception any error.
     */
    private static Element serializeObj(Object toSerialize) throws Exception
    {
        String theClassName;                //class name
        Element xmlElem;                    //xml element
        ParserDef parser;                   //the parser
        
        xmlElem = null;
        theClassName = toSerialize.getClass().getName();
        if (theClassName.startsWith(ListParser.ARRAYCLASS)) 
        {
            theClassName = ListParser.ARRAYCLASS;
        }

        if (TypeConst.isSimpleType(theClassName))
        {
            xmlElem = XMLFactory.getInstance().createElement(Const.PARAMETERS);
            ElementParser.setAttribute(Const.CONVERSIONTYPE, toSerialize.getClass().getName(), xmlElem);
            createParameterElement(toSerialize, (Element)xmlElem);
        }
        else if (parsers.containsKey(theClassName))
        {
            parser = (ParserDef)parsers.get(theClassName);
            xmlElem = parser.serialize(toSerialize);
        }
        
        return xmlElem;
    }
    
    /**
     * Create a specific {@link Const}.{@code PARAMTER} element for the specified object.
     * @param toSerialize the object to parse.
     * @param rootElem root element, if the created element gets added to one.
     * @throws java.lang.Exception any error.
     */
    public static void createParameterElement(Object toSerialize, Element rootElem) 
            throws Exception
    {
        String type;                        //object type
        String value;                       //object value
        Element nextElem;                   //next element
        Element nextElem2;                  //next element
        Element nextElem3;                  //next element
        Element nextObj;                    //next object
        
        
        nextElem = XMLFactory.getInstance().createElement(Const.PARAMETER);
        rootElem.addContent(nextElem);
        
        if (toSerialize != null)
        {
            type = ObjectHandler.typeCode(toSerialize.getClass().getName());
            if (type.equals(Vector.class.getName()))
            {
                nextElem2 = XMLFactory.getInstance().createElement(Const.PARAMETERS);
                nextElem2.setAttribute(Const.CONVERSIONTYPE, Vector.class.getName());
                nextElem.addContent(nextElem2);

                if (((Vector)toSerialize).size() > 0)
                {
                    VectorParser.vectorToElement((Vector)toSerialize, nextElem2);
                }
                else
                {
                    nextElem3 = XMLFactory.getInstance().createElement(Const.VALUE);
                    nextElem2.addContent(nextElem3);
                }
            }
            else if (type.equals(ArrayList.class.getName()))
            {
                nextElem2 = XMLFactory.getInstance().createElement(Const.PARAMETERS);
                nextElem2.setAttribute(Const.CONVERSIONTYPE, ArrayList.class.getName());
                nextElem.addContent(nextElem2);

                if (((ArrayList)toSerialize).size() > 0)
                {
                    ArrayListParser.arrayListToElement((ArrayList)toSerialize, nextElem2);
                }
                else
                {
                    nextElem3 = XMLFactory.getInstance().createElement(Const.VALUE);
                    nextElem2.addContent(nextElem3);
                }
            }
            else if (type.equals(Hashtable.class.getName()))
            {
                nextElem2 = XMLFactory.getInstance().createElement(Const.PARAMETERS);
                nextElem2.setAttribute(Const.CONVERSIONTYPE, Hashtable.class.getName());
                nextElem.addContent(nextElem2);

                if (((Hashtable)toSerialize).size() > 0)
                {
                    HashtableParser.hashtableToElement((Hashtable)toSerialize, nextElem2);
                }
                else
                {
                    nextElem3 = XMLFactory.getInstance().createElement(Const.KEY);
                    nextElem2.addContent(nextElem3);
                }
            }
            else if (type.equals(HashMap.class.getName()))
            {
                nextElem2 = XMLFactory.getInstance().createElement(Const.PARAMETERS);
                nextElem2.setAttribute(Const.CONVERSIONTYPE, HashMap.class.getName());
                nextElem.addContent(nextElem2);

                if (((HashMap)toSerialize).size() > 0)
                {
                    HashMapParser.hashMapToElement((HashMap)toSerialize, nextElem2);
                }
                else
                {
                    nextElem3 = XMLFactory.getInstance().createElement(Const.KEY);
                    nextElem2.addContent(nextElem3);
                }
            }
            else if (XmlHandler.isElement(type))
            {
                nextElem3 = (Element)toSerialize;
                if (nextElem3.getName().equals(Const.PARAMETERS))
                {
                    nextElem.addContent(nextElem3);
                }
                else
                {
                    nextElem2 = XMLFactory.getInstance().createElement(Const.TYPE);
                    nextElem2.setText(type);
                    nextElem.addContent(nextElem2);

                    nextElem2 = XMLFactory.getInstance().createElement(Const.VALUE);
                    nextElem2.addContent(nextElem3);
                    nextElem.addContent(nextElem2);
                }
            }
            else
            { 
                if (TypeConst.isSimpleType(type))
                {
                    value = String.valueOf(toSerialize);

                    nextElem2 = XMLFactory.getInstance().createElement(Const.TYPE);
                    nextElem2.setText(type);
                    nextElem.addContent(nextElem2);

                    nextElem2 = XMLFactory.getInstance().createElement(Const.VALUE);
                    nextElem2.setText(value);                
                    nextElem.addContent(nextElem2);
                }
                else
                {
                    nextObj = Parsers.serializeToElement(toSerialize);
                    if (nextObj != null)
                    {
                        nextElem.addContent(nextObj);
                    }
                }
            }
        }
        else
        {
            nextElem.setText(Const.NULL);
        }
    }
    
    /**
     * Create the object as specified by the string.
     * @param className the object class name.
     * @param value the object value as a String-based description.
     * @return the created object.
     * @throws java.lang.Exception any error.
     */
    public static Object createObject(String className, String value) throws Exception
    {
        DomParser domParser;                        //dom parser
        
        try
        {
            if (className != null)
            {
                if (value != null)
                {
                    if (className.equals(TypeConst.BOOLEAN) || className.equals(TypeConst.BOOLEANOBJ))
                    {
                        return Boolean.valueOf(value);
                    }
                    else if (className.equals(TypeConst.BYTE) || className.equals(TypeConst.BYTEOBJ) ||
                            className.equals(TypeConst.BYTEOBJCODE))
                    {
                        return Byte.valueOf(value);
                    }
                    else if (className.equals(TypeConst.DATE))
                    {
                        return new Date(Long.parseLong(value));
                    }
                    else if (className.equals(TypeConst.CHARACTER) || className.equals(TypeConst.CHARACTEROBJ))
                    {
                        char newData = value.charAt(0);
                        return new Character(newData);
                    }
                    else if (className.equals(TypeConst.SHORT) || className.equals(TypeConst.SHORTOBJ))
                    {
                        return Short.valueOf(value);
                    }
                    else if (className.equals(TypeConst.INTEGER) || className.equals(TypeConst.INTEGEROBJ))
                    {
                        return Integer.valueOf(value);
                    }
                    else if (className.equals(TypeConst.LONG) || className.equals(TypeConst.LONGOBJ))
                    {
                        return Long.valueOf(value);
                    }
                    else if (className.equals(TypeConst.FLOAT) || className.equals(TypeConst.FLOATOBJ))
                    {
                        return Float.valueOf(value);
                    }
                    else if (className.equals(TypeConst.DOUBLE) || className.equals(TypeConst.DOUBLEOBJ))
                    {
                        return Double.valueOf(value);
                    }
                    else
                    {
                        if (value.equals(Const.NULL))
                        {
                            return null;
                        }
                        else if (value.startsWith(SERIALIZED + XmlHandler.SEPARATOR))
                        {
                            return Parsers.parse(value);
                        }
                        else if (DomParser.isW3cDom(value))
                        {
                            return DomParser.parse(value);                   
                        }
                        else
                        {
                            return XmlHandler.removeStringSpec(value);
                        }
                    }
                }
            }
            
            return value;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "createObject",
                    null, ex);
        }
    }
    
    /**
     * Create the object as specified by the element.
     * @param className the object class name.
     * @param xmlElem root element if this stores the information and value is null.
     * @return the created object.
     * @throws java.lang.Exception any error.
     */
    public static Object createObject(String className, Element xmlElem) throws Exception
    {
        String value;                       //string-based description
        DomParser domParser;                //dom parser
        
        try
        {
            value = null;
            if ((className != null) && (xmlElem != null))
            {
                //test for the specific parameters structure first
                if (TypeConst.isSimpleType(className))
                {
                    try
                    {
                        value = ElementParser.getParameterValue(xmlElem);
                    }
                    catch (Exception ex)
                    {}
                }

                if (value != null)
                {
                    return createObject(className, value);
                }
                else
                {
                    value = xmlElem.getValue();
                    if (DomParser.isW3cDom(value))
                    {
                        return DomParser.parse(value);                   
                    }
                    else if (TypeConst.isSimpleType(className))
                    {
                        return ObjectHandler.valueFromString(className, value);
                    }
                    else if (XmlHandler.isElement(className))
                    {
                        return xmlElem;
                    }
                    else if (className.equals(Vector.class.getName()))
                    {
                        Vector newData = new Vector();
                        VectorParser.elementToVector(newData, (Element)xmlElem);
                        return newData;
                    }
                    else if (className.equals(ArrayList.class.getName()))
                    {
                        ArrayList newData = new ArrayList();
                        ArrayListParser.arrayListToElement(newData, (Element)xmlElem);
                        return newData;
                    }
                    else if (className.equals(Hashtable.class.getName()))
                    {
                        Hashtable newData = new Hashtable();
                        HashtableParser.elementToHashtable(newData, (Element)xmlElem);
                        return newData;
                    }
                    else if (className.equals(HashMap.class.getName()))
                    {
                        HashMap newData = new HashMap();
                        HashMapParser.elementToHashMap(newData, (Element)xmlElem);
                        return newData;
                    }
                }
            }
            
            //if get here with no return, then try for complex object
            if ((className != null) && !TypeConst.isSimpleType(className))
            {
                return Parsers.parse(xmlElem);
            }
            else
            {
                //unsuccessful object creation
                return null;
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "createObject",
                    null, ex);
        }
    }
    
    /**
     * Check if the second parameter is an XML element type that should be 
     * converted into an object.
     * @param param the first parameter class.
     * @param obj the second parameter object.
     * @return true if should convert the parameter.
     */
    public static boolean shouldConvert(Class param, Object obj)
    {
        boolean convert = false;            //true if should convert
        
        if (obj != null)
        {
            if (XmlHandler.isElement(obj.getClass().getName()))
            {
                convert = parsers.containsValue(param.getName());                
                if (!convert) convert = param.getName().startsWith(ListParser.ARRAYCLASS);
            }
            else if (obj.getClass().getName().equals(String.class.getName()))
            {
                convert = XmlHandler.isElementSpec((String)obj);
            }
        }
                
        return convert;
    }

    /**
     * Remove all element prefixes and extra coding to clean the string completely.
     * @param xmlStr the string to remove prefixes from.
     * @return the modified string.
     */
    public static String removeCoding(String xmlStr)
    {
        xmlStr = XmlHandler.removeCoding(xmlStr);
        xmlStr = replaceElementSpecs(xmlStr);
        xmlStr = StringHandler.replaceAll(xmlStr, DomParser.W3CDOM, "");
        return xmlStr;
    }

    /**
     * Remove the serialized prefixes and return.
     * @param xmlStr the string to remove prefixes from.
     * @return the modified string.
     */
    private static String replaceElementSpecs(String xmlStr)
    {
        xmlStr = StringHandler.replaceAll(xmlStr, SERIALIZED + XmlHandler.SEPARATOR, "");
        return xmlStr;
    }

    /**
     * Retrieve the list of classes that can be parsed by the parsers.
     * @return the list of classes that can be parsed. Values are of type String.
     */
    public static ArrayList getParsedClasses()
    {
        return new ArrayList(parsers.keySet());
    }
}
