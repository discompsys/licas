/*
 * SoaParserLinks.java
 *
 * Created on 4 December 2012
 *
 * Version 1.6
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.parsers.network;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.Service;
import org.licas.call.Handle;
import org.licas.server.LocalServer;
import org.licas.util.Const;
import org.licas.util.MetaConst;
import org.licas.util.exception.LicasException;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.util.ArrayList;
import java.util.Vector;



/**
 * This class can be used to parse only the linking structures of the local server services.
 * @author Kieran Greer
 */
public class SoaParserLinks 
{
    /** The logger */
    private static Logger logger;


    /** The passwords parser - should have already parsed the values */
    private SoaParserPasswords passwordsParser;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SoaParserLinks.class.getName());
        logger.setDebug(true);
    }

    
    /**
     * Create a new instance of SoaParserLinks.
     * @param thePasswordsParser the passwords parser. This should have already been
     * used to parse the passwords, when they are retrieved only in this class.
     */
    public SoaParserLinks(SoaParserPasswords thePasswordsParser)
    {
        passwordsParser = thePasswordsParser;
        initialise();
    }
    
    /**
     * Initialise some values.
     */
    private void initialise()
    {}
    
    /**
     * Serialise the whole network into XML.
     * @param password the password to access the server.
     * @param adminKey the admin key for the server.
     * @param serviceIDs list of IDs of base services running on the network.
     * @return an XML description of the linking structure for all services in the network.
     * @throws java.lang.Exception any error.
     */
    public Element serialize(String password, String adminKey, ArrayList serviceIDs) throws Exception
    {
        int i;
        String nextServiceID;                           //next nextService id
        String nextPassword;                            //next password
        String nextAdminKey;                            //next admin key
        Service nextService;                            //next service
        Element linksElem;                              //links element
        Element rootElem;                               //root element
        
        rootElem = null;
        try
        {
            if ((serviceIDs != null) && !serviceIDs.isEmpty())
            {
                rootElem = XMLFactory.getInstance().createElement(Const.LINKS);
            
                //parse all service links structures
                for (i = 0; i < serviceIDs.size(); i++)
                {
                    nextServiceID = (String)serviceIDs.get(i);
                    nextPassword = passwordsParser.getPassword(nextServiceID);
                    nextAdminKey = passwordsParser.getAdminKey(nextServiceID);

                    nextService = (Service)LocalServer.getApi(password).getService(nextServiceID, nextPassword, nextAdminKey);
                    linksElem = nextService.linksToXml(adminKey);
                    if (linksElem != null) 
                    {
                        rootElem.addContent(linksElem);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "serialize", null, ex);
        }
        
        return rootElem;
    }

    /**
     * Parse the XML description of the links and add them to the related service.
     * @param linksElem the XML description of all links for all services on the network.
     * @param password the password to access the server.
     * @param adminKey the server admin key.
     * @throws java.lang.Exception any error.
     */
    public void parse(Element linksElem, String password, String adminKey) throws Exception
    {
        int i, j;
        String serviceUuid;                                 //service uuid
        Node nextNode;                                      //next node
        Element nextElem;                                   //next element
        Element nextElem2;                                  //next element
        Vector elemList;                                    //element list
        Vector elemList2;                                   //element list
        
        serviceUuid = null;
        try
        {
            if (linksElem.getName().equals(Const.LINKS))
            {
                elemList = linksElem.getChildren();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);
                    if (nextNode instanceof Element)
                    {
                        nextElem = (Element)nextNode;
                        if (nextElem.getName().equals(Const.LINKS))
                        {
                            serviceUuid = nextElem.getAttributeValue(Const.UUID);
                            
                            elemList2 = nextElem.getChildren();
                            for (j = 0; j < elemList2.size(); j++)
                            {
                                nextNode = (Node)elemList2.get(j);
                                if (nextNode instanceof Element)
                                {
                                    nextElem2 = (Element)nextNode;
                                    if (nextElem2.getName().equals(MetaConst.PERMANENTLINKSERVICEMETA))
                                    {
                                        parseLinks(serviceUuid, nextElem2, password, adminKey);
                                    }
                                    else if (nextElem2.getName().equals(MetaConst.DYNAMICLINKSERVICEMETA))
                                    {
                                        parseLinks(serviceUuid, nextElem2, password, adminKey);
                                    }
                                    else if (nextElem2.getName().equals(MetaConst.ASSOCIATEDLINKSERVICEMETA))
                                    {
                                        parseLinks(serviceUuid, nextElem2, password, adminKey);
                                    }
                                }
                            }
                        }
                    }                   
                }
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "parse", null, ex);
        }
    }
    
    /**
     * Parse the links element to add the defined links.
     * @param serviceUuid the uuid of the service to add links to.
     * @param linkElem The XML description of the links.
     * @param password the server password.
     * @param adminKey the server admin key.
     * @throws java.lang.Exception any error.
     */
    protected void parseLinks(String serviceUuid, Element linkElem, String password,
            String adminKey) throws Exception
    {
        int i, j;
        boolean isOK;                                   //true if ok
        String toID;                                    //the to service id
        String passwordsUuid;                           //passwords uuid
        String nextPassword;                            //next password
        String nextAdminKey;                            //next admin key
        Element toPath;                                 //the to service path
        Element linkTo;                                 //link to
        Element serverUri;                              //base server uri
        Element serviceUri;                             //service uri
        Service theService;                             //the nextService
        Node nextNode;                                  //next node
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        Vector elemList;                                //element list
        Vector elemList2;                               //element list
                
        try
        {
            serverUri = Handle.createNewUrlHandle(LocalServer.getServerURL());
            serviceUri = Handle.addToHandle(serverUri, Handle.asHandleElement(serviceUuid));
            passwordsUuid = XmlHandler.xmlToString(serviceUri);
            
            nextPassword = passwordsParser.getPassword(passwordsUuid);
            nextAdminKey = passwordsParser.getAdminKey(passwordsUuid);
            theService = (Service)LocalServer.getApi(password).getService(serviceUuid, nextPassword, nextAdminKey);
              
            if (theService != null)
            {
                if (linkElem.getName().equals(MetaConst.PERMANENTLINKSERVICEMETA))
                {
                    elemList = linkElem.getChildren();
                    for (i = 0; i < elemList.size(); i++)
                    {
                        nextNode = (Node)elemList.get(i);
                        if (nextNode instanceof Element)
                        {
                            nextElem = (Element)nextNode;
                            if (nextElem.getName().equals(Const.LINK))
                            {
                                elemList2 = nextElem.getChildren();                            
                                for (j = 0; j < elemList2.size(); j++)
                                {
                                    nextNode = (Node)elemList2.get(j);
                                    if (nextNode instanceof Element)
                                    {
                                        nextElem2 = (Element)nextNode;
                                        if (nextElem2.getName().equals(Const.HANDLE))
                                        {
                                            toPath = (Element)nextElem2.clone();                                      
                                            if (toPath != null)
                                            {
                                                //add a local permanent link only, so update the URL
                                                toID = Handle.getLastServiceHandle(toPath);
                                                linkTo = Handle.addToHandle(serverUri, Handle.asHandleElement(toID));
                                                isOK = theService.createPermanentLinkTo(nextAdminKey, toID, 
                                                        passwordsParser.getAdminKey(XmlHandler.xmlToString(linkTo)), linkTo);

                                                if (!isOK)
                                                {
                                                    throw new LicasException("Error: could not create permanent links from NetworkParser");
                                                }
                                            }
                                        }
                                    }
                                }     
                            }
                        }
                    }
                }
                else if (linkElem.getName().equals(MetaConst.ASSOCIATEDLINKSERVICEMETA))
                {
                    elemList = linkElem.getChildren();
                    for (i = 0; i < elemList.size(); i++)
                    {
                        nextNode = (Node)elemList.get(i);
                        if (nextNode instanceof Element)
                        {
                            nextElem = (Element)nextNode;
                            if (nextElem.getName().equals(Const.NEXTLINK))
                            {
                                elemList2 = nextElem.getChildren();                            
                                for (j = 0; j < elemList2.size(); j++)
                                {
                                    nextNode = (Node)elemList2.get(j);
                                    if (nextNode instanceof Element)
                                    {
                                        nextElem2 = (Element)nextNode.clone();
                                        theService.addServiceAssociation(nextAdminKey, nextElem2, 
                                            passwordsParser.getPassword(XmlHandler.xmlToString(nextElem2)));
                                    }
                                }     
                            }
                        }
                    }
                }
                else if (linkElem.getName().equals(MetaConst.DYNAMICLINKSERVICEMETA))
                {
                    //ToDo: this is not currently possible
                    theService.xmlToDynamicLinks(linkElem, nextAdminKey);
                }
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "parseLinks", null, ex);
        }
    }
}
