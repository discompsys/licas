/*
 * AutoEngine.java
 *
 * Created on 16 June 2014.
 *
 * Version 1.5.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.autonomic.script;


import org.dcs.query_process.Script_Engine;
import org.dcs.query_process.Script_Factory;
import org.dcs.query_process.model.Script_Process;
import org.dcs.query_process.model.activity.Script_Auto;
import org.dcs.query_process.model.data.Script_VariableInstance;
import org.dcs.query_process.model.event.Script_Event;
import org.dcs.query_process.model.event.Script_Execute;
import org.dcs.query_process.util.Script_Const;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.Auto;
import org.licas.MessageInfo;
import org.licas.PasswordHandler;
import org.licas.Service;
import org.licas.util.AiConst;
import org.licas.util.Const;
import org.licas.util.KeyValue;
import org.licas.util.ObjectHandler;
import org.licas.util.exception.LicasException;
import org.licas_xml.abs.Element;

import java.util.ArrayList;


/**
 * This is a default implementation of an engine that can be used to interpret and execute 
 * the provided default script, possibly for the autonomic manager or one of its modules,
 * or for an autonomous service in general. The script can be made up of a number of 
 * {@link AutoEngineInfo} objects that get processed in order.
 * Evaluation takes place through the {@code process} method, where the {@link MessageInfo}
 * object should pass a {@code ArrayList} of parameter values to pass to the evaluation method.
 * This is partially dynamic, where a parameter list be specified as a {@link KeyValue} set,
 * where the key can be the actual variable name in the method or class itself. This can
 * then be matched to the auto engine method script that defines what parameters are required.
 * It can include the parameter or variable name that should be used, where {@link AiConst}.{@code QUERY}
 * is reserved for the {@code input} variable of this class and {@code REPLY} is reserved for
 * the evaluator reply. If any name is missing, then it does not have to be added.
 * <p>
 * So a specific list of variable names will use only those variables and can include or 
 * omit anything specified/not specified. If a list of objects is passed, they are used in 
 * that order. If the list is replaced by a single object, then only that single value gets added.
 * @author Kieran Greer
 */
public class AutoEngine
{
    /** For logging */
    private static final Logger logger;
    
    /**
     * The engine to return the script elements in order.
     */
    protected Script_Engine engine;
    
    /**
     * The process model to execute.
     */
    protected Script_Process process;
    
    /**
     * List of all named entities in the script, referenced by their unique public id.
     * Key is the id and value is the script element converted into its object instance.
     */
    protected ObjectsMap objectsMap;
    
    /** References to the currently (while) active loop evaluators */
    private static final LoopStack loopStack;
    
    /** Parent service's admin key */
    private final String adminKey;
    
    /** The parent service. This is identified in the script by the {@code this} keyword. */
    private Service parent;
    
    /** Password handler for service invocation */
    private final PasswordHandler passwordHandler;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(AutoEngine.class.getName());
        logger.setDebug(false);
        
        loopStack = new LoopStack();
    }
    
    
    /** 
     * Create a new instance of AutoEngine. Parameters can be null if not used.
     * @param thisParent the parent service. This is required if the {@code this} keyword is used.
     * @param thisPasswordHandler the parent password handler.
     */
    public AutoEngine(Service thisParent, PasswordHandler thisPasswordHandler)
    {
        initialise();
        passwordHandler = thisPasswordHandler;
        adminKey = passwordHandler.getAdminKey();
        parent = thisParent;
    }

    /** 
     * Initialise some values.
     */
    private void initialise() 
    {
        engine = null;
        process = null;
        objectsMap = new ObjectsMap();
    }
    
    /**
     * Return true if the engine has a process script loaded, false otherwise.
     * @return true if process is not null, false otherwise.
     */
    public boolean hasProcess()
    {
        return (process != null);
    }
    
    /**
     * Return true if there are no further script elements to process.
     * @return true if at the end of the process stack. If the loop stack
     * still has elements, then these would normally be processed.
     * @throws java.lang.Exception any error.
     */
    public boolean isFinished() throws Exception
    {
        return (engine.getIsFinished() && loopStack.isEmpty());
    }
    
    /**
     * Parse the event-rule-action script part and create the related objects.
     * @param policyElem the policy section of the script.
     * @throws java.lang.Exception any error.
     */
    public void setEventRuleAction(Element policyElem) throws Exception
    {
        Element scriptElem;                         //the script element
        
        if (policyElem != null) {
            if (policyElem.getName().equalsIgnoreCase(Script_Const.PROCESS)) {
                scriptElem = policyElem;
            }
            else {
                scriptElem = policyElem.getChild(Script_Const.PROCESS);
            }
            
            if (scriptElem != null) {
                objectsMap.clear();
                if (!ObjectHandler.isNull(parent)) objectsMap.put(AiConst.THIS, parent);

                process = (Script_Process)Script_Factory.elementFromScript(scriptElem, null);           
                resetEventRuleAction();
            }
        }
    }
    
    /**
     * Reset the already created event-rule-action script part so that it can be run again.
     * @throws java.lang.Exception any error.
     */
    public void resetEventRuleAction() throws Exception
    {
        int i;
        String nextID;                                  //next id value
        Script_VariableInstance scriptElem;             //script element
        ArrayList<Script_VariableInstance> instList;    //list of instances
        Object varInst;                                 //variable instance
        
        if (process != null) {
            process.setForUse();           
            engine = new Script_Engine();
            engine.resetValues(process.getEvents());

            //add any variables instances so that they are available later
            instList = new ArrayList<>(process.getVariableInstances().values());
            for (i = 0; i < instList.size(); i++)
            {
                scriptElem = instList.get(i);

                nextID = scriptElem.getID();           
                varInst = AutoEngineInfo.parseToObject(scriptElem, process);
                if (varInst != null) objectsMap.put(nextID, varInst);
            }
        }
    }
    
    /**
     * Process the script data and return the result. This default version will evaluate the 
     * message and execute any method using invocation. It will also replace named or tagged
     * variables with actual instances from the parameter list included in the input
     * {@code messageInfo} object. A BPEL-like script is used, but it is limited.
     * @param messageInfo the message to evaluate. In this case it should be a {@code ArrayList}
     * of parameter values (as {@link KeyValue}) as the message ({@code messageInfo.getMessage()}) that then update 
     * the method parameters. It can be {@code null} if there are no additional parameter values.
     * @return the result of the monitoring. Note that this should not change the input message
     * and is a list of actions to carry out in sequence, as {@code KeyValue} pairs.
     * @throws java.lang.Exception any error.
     */
    public ArrayList<KeyValue> process(MessageInfo messageInfo) throws Exception
    {
        boolean isOK;                               //true if OK
        ArrayList paramList;                        //parameters list
        ArrayList<KeyValue> replyList;              //reply list
        Object paramValue;                          //parameter value
        KeyValue keyValue;                          //key-value pair
        AutoEngineInfo autoInfo;                    //auto engine info
        AutoOut effList;                            //resulting effector list
        Script_Event scriptElem;                    //script event to process

        try
        {
            isOK = false;
            autoInfo = null;
            paramList = new ArrayList();
            replyList = new ArrayList<>();

            //add input parameters if there are any
            if (!isFinished() && (messageInfo != null)) {
                paramValue = messageInfo.getMessage();
                if (paramValue != null) {
                    if (paramValue instanceof ArrayList) {
                        paramList = (ArrayList)paramValue;
                    }
                    else {
                        if (!ObjectHandler.isNull(paramValue)) {
                            paramList.add(paramValue);
                        }
                    }
                }
            }

            //get next statement and process
            scriptElem = engine.nextProcessStep();
            if (scriptElem == null) {
                if (!loopStack.isEmpty()) {
                    autoInfo = (AutoEngineInfo)loopStack.pop();
                    isOK = true;
                }
            }
            else {
                autoInfo = new AutoEngineInfo(this);
                isOK = autoInfo.createInfo(scriptElem, process, objectsMap);
            }
            
            if ((autoInfo != null) && isOK) {
                //if (while) loop add to stack
                if (autoInfo.controlLoop) {
                    loopStack.addControlLoop(autoInfo); 
                }

                //if info does not have executable objects then need to parse to next level
                if (autoInfo.canExecute()) {
                    //always true means to always execute the element
                    if (autoInfo.alwaysTrue) {
                        effList = executeScriptElement(autoInfo);
                    }
                    else {
                        //more often used, as in conditional statement, for example
                        //the returned effector is for any (nested) element that gets executed
                        effList = invokeMethod(autoInfo, paramList);
                    }

                    //add evaluation result to the reply list
                    if (autoInfo.getMethodReply() != null) {
                        //not null means a result is available
                        keyValue = new KeyValue();
                        keyValue.key = Const.REPLY;
                        keyValue.value = autoInfo.getMethodReply();
                        replyList.add(keyValue);
                        
                        //positive evaluation may be from nested element,
                        //so need to check any control loop condition as well
                        if (autoInfo.controlLoop) {
                            AutoReply autoReply = new AutoReply(autoInfo.getMethodReply());
                            if (autoReply.evaluate(autoInfo.senInput.filter,
                                autoInfo.senInput.function, objectsMap)) {
                                effList = autoInfo.getEffOutput();  
                            } 
                            else {
                                //shutdown the loop if condition ended
                                loopStack.popLastLoop(autoInfo.eventID);
                            }
                        }
                    }

                    //add effectors to the reply list
                    if (effList != null) {
                        if (effList.isOK()) {
                            keyValue = new KeyValue();
                            keyValue.key = AiConst.EFFECTOR;
                            keyValue.value = effList;
                            replyList.add(keyValue);
                        }
                        else if (effList.isError()) {
                            //shutdown loop if an error
                            loopStack.popLastLoop(autoInfo.eventID);
                        }
                    }
                }
            }
            else {
                engine.setIsFinished();
            }

            return replyList;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "process", null, ex);
        }
    }
    
    /**
     * Execute the script element if appropriate and then return the result.
     * This is probably the saved effector actions list, as {@link AutoEngineInfo} objects.
     * @param rootInfo the root info object for execution.
     * @return the value of effOutput.
     */
    protected AutoOut executeScriptElement(AutoEngineInfo rootInfo)
    {
        AutoEngineInfo autoInfo;                //info to execute
        
        autoInfo = rootInfo;
        while (autoInfo.next != null) autoInfo = autoInfo.next;
        
        if (autoInfo.evaluator != null) {
            if (autoInfo.evaluator instanceof Script_Execute) {
                if (((Script_Execute)autoInfo.evaluator).execute()) {
                    return autoInfo.getEffOutput();
                }
                else {
                    return null;
                }
            }
            else {
                return autoInfo.getEffOutput();
            }
        }
        else {
            return autoInfo.getEffOutput();
        }
    }
    
    /**
     * Invoke the method in the {@code autoInfo} object, making variable replacements first.
     * From that object, the {@code evaluator} is used to execute the {@code method}.
     * The evaluation can be compared to the {@code function}. The {@code input} can 
     * be used to replace a tagged {@link Const}.{@code QUERY} parameter and so should be an
     * XML element. If the reply is OK, the autoInfo {@code effOutput} is returned as
     * the next set of actions.
     * @param rootInfo the root process script for execution.
     * @param paramList an external set of {@link KeyValue} objects that can replace
     * named or tagged fields in the method parameter lists. If empty or no match, then
     * nothing gets changed.
     * @return the result of the evaluation. This is the {@code effector list} of the
     * input parameter if the evaluation is true, or an empty list if it is false.
     * Evaluating to true can include matching exactly to an XML description, or just have
     * any result, for example, by using a {@code checkReply} method.
     * @throws LicasException for a licas-specific mapping problem.
     * @throws java.lang.Exception any error.
     */
    public AutoOut invokeMethod(AutoEngineInfo rootInfo, ArrayList<KeyValue> paramList)
            throws LicasException, Exception
    {
        AutoEngineInfo autoInfo;                //info to execute
        AutoInvokeThread im;                    //invokes the method
        
        autoInfo = rootInfo;
        while (autoInfo.next != null) autoInfo = autoInfo.next;
        
        im = new AutoInvokeThread();
        return im.run(autoInfo, paramList, objectsMap, parent);
    }
    
    /**
     * Get the first message in the auto manager's queue, retrieved using the specified function.
     * @param scriptAuto description of the message to retrieve.
     * @return the message if it exists, or null if there are none, or there is no 
     * parent service or queue.
     */
    protected MessageInfo getAutoQueueMessage(Script_Auto scriptAuto)
    {
        MessageInfo messageInfo;                //message info
        
        messageInfo = null;
        try {
            if ((parent != null) && (parent instanceof Auto)) {
                return ((Auto)parent).autoQueueMessage(scriptAuto, adminKey);
            }
        }
        catch (Exception ex) {}
      
        return messageInfo;
    }
    
    /** 
     * Set the parent service.
     * @param thisParent the parent service.
     */
    public void setParent(Service thisParent) 
    {
        parent = thisParent;
    }
    
    /**
     * Get the script engine that processes and returns script elements in order.
     * @return the value of engine.
     */
    public Script_Engine getScriptEngine()
    {
        return engine;
    }
    
    /**
     * Get the password handler.
     * @return the value of passwordHandler.
     */
    protected PasswordHandler getPasswordHandler()
    {
        return passwordHandler;
    }
}
