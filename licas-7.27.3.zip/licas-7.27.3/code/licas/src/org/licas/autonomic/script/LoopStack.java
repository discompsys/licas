/*
 * LoopStack.java
 *
 * Created on 6 January 2018
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.autonomic.script;


import java.util.Stack;


/**
 * This is a stack that stores script loop evaluators, from a While loop.
 * @author Kieran Greer
 */
public class LoopStack 
{
    /** References to the currently (while) active loop evaluators */
    private final Stack<AutoEngineInfo> loopStack;
    
    /**
     * Create a new instance of LoopStack.
     */
    public LoopStack()
    {
        loopStack = new Stack<>();
    }
    
    /**
     * Return true if the loop stack is empty.
     * @return true if no element on the stack.
     */
    protected boolean isEmpty()
    {
        return loopStack.empty();
    }
    
    /**
     * Removes the object at the top of this stack and returns that object as the value of this function.
     * @return the object at the top of this stack.
     */
    protected Object pop()
    {
        return loopStack.pop();
    }
    
    /**
     * Looks at the object at the top of this stack without removing it from the stack.
     * @return the object at the top of this stack.
     */
    protected AutoEngineInfo peek()
    {
        return loopStack.peek();
    }
    
    /**
     * Pushes an item onto the top of this stack.
     * @param item the object to add.
     */
    protected void push(AutoEngineInfo item)
    {
        loopStack.push(item);
    }
    
    /**
     * Add the control loop element if not already on the stack.
     * @param autoInfo the info element to add.
     */
    protected void addControlLoop(AutoEngineInfo autoInfo)           
    {
        AutoEngineInfo topInfo;             //top info on the stack
        
        if (autoInfo != null)
        {
            if (loopStack.empty())
            {
                loopStack.push(autoInfo);
            }
            else
            {
                topInfo = loopStack.peek();
                if (!topInfo.eventID.equals(autoInfo.eventID))
                {
                    loopStack.push(autoInfo);
                }
            }
        }
    }
    
    /**
     * Pop the last control loop element, if the internal ID matches.
     * @param internalID internal ID of the element last evaluated.
     */
    protected void popLastLoop(String internalID)
    {
        AutoEngineInfo autoInfo;               //loop element
        
        if (!loopStack.empty())
        {
            autoInfo = loopStack.peek();
            if (autoInfo.eventID.equals(internalID))
            {
                loopStack.pop();
            }
        }
    }
}
