/**
 * Autonomic Manager components framework. 
 */
package org.licas.autonomic;