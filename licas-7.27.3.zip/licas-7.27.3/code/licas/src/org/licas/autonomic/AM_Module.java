/*
 * AM_Module.java
 *
 * Created on 27 January 2011
 *
 * Version 1.5
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.autonomic;


import org.dcs.query_process.util.Script_Const;
import org.licas.MessageInfo;
import org.licas.PasswordHandler;
import org.licas.Service;
import org.licas.autonomic.script.AutoEngine;
import org.licas.util.AiConst;
import org.licas.util.Const;
import org.licas.util.KeyValue;
import org.licas_xml.abs.Element;

import java.util.ArrayList;


/**
 * Interface for implementing a basic autonomic manager module. These modules are
 * stored in and used by an {@link AutonomicManager}. An autonomic manager can be used to
 * implement a self-monitoring system. In this case, separate MAPE modules can be
 * implemented to monitor, analyze, plan, or execute the plan, based on the input that
 * each module receives. The rules or results of this control loop can be determined by a 
 * policy document that should be included with each module implementation. The default
 * versions however can perform some automatic processing by themselves, without an
 * additional policy document. 
 * <p>
 * As part of a typical process, on receiving its input, the module will process the 
 * information based on the implemented code, compare that with the policy and return 
 * a {@link MessageInfo} object with the appropriate reply. Each base service is wrapped
 * by an autonomic manager with a default monitor module. You can change this through the
 * admin script for the service. The default modules will only queue the messages and
 * return them to the service upon request. It now also stores some basic metrics or stats.
 * Therefore, any information sent to the default manager is returned in exactly the same format.
 * <p>
 * If you implement and add new modules, they might check for errors, for example, and then
 * change what gets returned if something suspicious is found. If any derived module implements 
 * this interface, then this process will be consistent throughout the whole control loop.
 * @author Kieran Greer
 */
public abstract class AM_Module
{
    /** Admin key for full access to the autonomic manager methods */
    protected String adminKey;
    
    /** 
     * The policy document. This is an XML script that can represent anything,
     * but needs to be understood by the module that uses it.
     */
    protected Element policy;
    
    /** A message representing the immediate last evaluation process */
    protected MessageInfo evaluationMessage;
    
    /** The parent autonomic manager */
    protected AutonomicManager autoMan;
    
    /* To interpret and execute the policy script */
    protected AutoEngine autoEngine;
    
    /** The parent service's password handler */
    protected PasswordHandler passwordHandler;
    
    /** 
     * Create a new instance of AM_Module. You can only use the {@link AutoEngine} if the
     * {@link AutonomicManager} wraps a licas {@link Service}-derived object.
     * @param serviceObj the service object wrapped by the autonomic manager.
     * @param passwordHandler the service's password handler, for the auto script engine.
     */
    public AM_Module(Service serviceObj, PasswordHandler passwordHandler)
    {
        initialise();
        this.passwordHandler = passwordHandler;
        adminKey = passwordHandler.getAdminKey();
        autoEngine = new AutoEngine(serviceObj, passwordHandler);
    }

    /** Initialise some values */
    private void initialise()
    {
        policy = null;
        evaluationMessage = null;
    }

    /**
     * Set the parent autonomic manager.
     * @param thisAutoMan the value of autoMan.
     */
    protected void setAutonomicManager(AutonomicManager thisAutoMan)
    {
        autoMan = thisAutoMan;
    }
    
    /**
     * Set the policy for the monitor.
     * @param document the policy document.
     * @throws java.lang.Exception any error.
     */
    public void setPolicy(Element document) throws Exception 
    {
        if (policy == null) {
            policy = document;
            if (policy.getChild(Script_Const.PROCESS) != null) {
                autoEngine.setEventRuleAction(policy);
            }
        }
    }

    /**
     * Process the data and return the result. this default version will evaluate the 
     * message, using any declared default method, to determine if it matches with the policy.
     * As this is only one monitoring implementation version, it is possible that you will
     * need to override this method to implement a more application-specific one, but it
     * will provide some flexibility, as it can be configured through the {@code setEventRuleAction}
     * method, for example.
     * @param messageInfo the message to evaluate.
     * @return the result of the monitoring. Note that this should not change the input message
     * and is a list of actions to carry out in sequence. Each action is a list of {@link KeyValue}
     * objects that can include a {@link Const}.{@code REPLY} object and {@link AiConst}.{@code EFFECTOR}
     * method XML description, or other objects. These are typically all included with each action message,
     * where they have to be identified by the related key value.
     * @throws java.lang.Exception any error.
     */
    protected abstract ArrayList<KeyValue> process(MessageInfo messageInfo) throws Exception;
    
    /**
     * Get a newly created message from the module, representing its evaluation and
     * result of the immediate last process.
     * @return the value of evaluationMessage.
     */
    protected MessageInfo evaluationMessage()
    {
        return evaluationMessage;
    }
}
