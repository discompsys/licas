/*
 * AutoIn.java
 *
 * Created on 7 January 2018
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer.
 */

package org.licas.autonomic.script;


import org.ai_heuristic.eval.Condition;

import java.util.HashMap;


/**
 * Input evaluation conditions for the related filter list to be selected.
 * @author Kieran Greer
 */
public class AutoIn 
{   
    /** 
     * The method that the evaluator uses to produce some result. 
     * Can be an XML element, but if parsed from wsdl later, then it is just the operation 
     * name. If retrieved from the auto message queue, then already a MethodInfo object.
     */
    public Object method;
    
    /** 
     * The input variable mappings for the evaluator method.
     * Key is the method parameter name and value is the variable instance name.
     */
    public HashMap<String, String> input;
    
    /** The method result */
    public Object output;
    
    /** An filter evaluation to be made on the method reply, typically a query */
    public Object filter;
    
    /** 
     * An additional function that the filtered result can match with.
     * This defaults to {@code true}, or a not {@code null} result.
     */
    public Condition function;
    
    
    /** 
     * Create a new instance of AutoIn.
     * @throws java.lang.Exception any error.
     */
    public AutoIn() throws Exception
    {
        method = null;
        input = new HashMap<>();
        output = null;
        filter = null;
        function = Condition.trueCondition();
    }   
}
