/*
 * AM_MonitorDefault.java
 *
 * Created on 8 May 2014
 *
 * Version 1.5.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.autonomic;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.MessageInfo;
import org.licas.PasswordHandler;
import org.licas.Service;
import org.licas.security.Metrics;
import org.licas.util.AiConst;
import org.licas.util.Const;
import org.licas.util.KeyValue;

import java.util.ArrayList;


/**
 * This class is an example of a default autonomic manager monitor. It can provide
 * limited information, based on the number of messages/transactions that pass through
 * the manager, that gets added to its {@link Metrics} object. Each separate message
 * can also be processed by the auto engine, using the monitor's policy script.
 * @author Kieran Greer
 */
public class AM_MonitorDefault extends AM_Module
{
    /** For logging */
    private static final Logger logger;

    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(AM_MonitorDefault.class.getName());
        logger.setDebug(false);
    }

    /** 
     * Create a new instance of AM_MonitorDefault. You can only use the {@code AutoEngine} if the
     * {@link AutonomicManager} wraps a licas {@link Service}-derived object.
     * @param serviceObj the service object wrapped by the autonomic manager.
     * @param passwordHandler the service's password handler, for the auto script engine.
     */
    public AM_MonitorDefault(Service serviceObj, PasswordHandler passwordHandler)
    {
        super(serviceObj, passwordHandler);
    }

    /** Reset some values */
    public void resetValues()
    {}
    
    /**
     * Process the data and return the result. This default version will evaluate the 
     * message, using the {@code autoEngine} and declared process script, to determine a 
     * message result. The process is also defined as the module's policy (script).
     * As this is only one monitoring possibility, it is likely that you will need to override 
     * this method to implement a more application-specific one, but this version can provide 
     * some flexibility, as it can be configured through the {@code AutoEngine.setEventRuleAction} 
     * method, for example.
     * @param messageInfo the message to evaluate. This should be indexed in a script with the 
     * key name of {@link AiConst}.{@code MI_OBJECT}.
     * @return the result of the monitoring. Note that this should not change the input message
     * and is a list of actions to carry out in sequence. Each action is a list of {@link KeyValue}
     * objects that can include a {@link Const}.{@code REPLY} object and {@link AiConst}.{@code EFFECTOR}
     * method XML description, or other objects. These are typically all included with each action message,
     * where they have to be identified by the related key value.
     * @throws java.lang.Exception any error.
     */
    protected ArrayList<KeyValue> process(MessageInfo messageInfo) throws Exception
    {
        Object messageObj;                          //the message value
        ArrayList<KeyValue> messageList;            //message list
        KeyValue keyValue;                          //to index the message value
        MessageInfo processMessage;                 //message to process
        
        messageList = new ArrayList<>();
        
        messageObj = messageInfo.getMessage();        
        if (messageObj != null)
        {
            if (!(messageObj instanceof ArrayList))
            {
                keyValue = new KeyValue();
                keyValue.key = AiConst.MI_OBJECT;
                keyValue.value = messageObj;
                messageList.add(keyValue);
            }
            else
            {
                messageList = (ArrayList)messageObj;
            }
        }
        
        if (autoEngine.hasProcess())
        {
            evaluationMessage = messageInfo;
            autoEngine.resetEventRuleAction();
            processMessage = new MessageInfo(messageInfo.getCommID(), messageList);

            return autoEngine.process(processMessage);
        }
        else
        {
            return messageList;
        }
    }
}
