/*
 * AutoInvoke.java
 *
 * Created on 6 January 2018
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.autonomic.script;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.Service;
import org.licas.call.*;
import org.licas.call.client.CallHandler;
import org.licas.def.RemoteCallDef;
import org.licas.meta.MetaFactory;
import org.licas.parsers.types.ReflectionParser;
import org.licas.service.model.Contract;
import org.licas.util.*;
import org.licas.util.exception.LicasException;
import org.licas.ws.WsFactory;
import org.licas.ws.WsMethodInfo;
import org.licas_text.util.MetaConst;
import org.licas_xml.abs.Element;

import java.util.ArrayList;


/**
 * This performs all of the necessary operations to invoke a script method and process the result.
 * @author Kieran Greer
 */
public class AutoInvoke 
{
    /** For logging */
    private static final Logger logger;
    
    
    /** The script element converted into info objects to execute */
    private final AutoEngineInfo autoInfo;
    
    /** For a list of method parameters */
    private ArrayList paramList;
    
    /** Mapping between marker names and object instances */
    private final ObjectsMap objectsMap;
    
    /** The service to execute on */
    private final Service service;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(AutoInvoke.class.getName());
        logger.setDebug(false);
    }
    
    
    /**
     * Create a new instance of AutoInvoke and set the method variables and objects.
     * @param thisAutoInfo the process script elements parsed into their actual objects
     * and definitions.
     * @param thisParamList an external set of {@link KeyValue} objects that can replace
     * named or tagged fields in the method parameter lists. If empty or no match, then
     * nothing gets changed.
     * @param thisObjectsMap mapping of variable names to instances. This method can ad more
     * variables, but should be for the method invocation only, so immediately cloned.
     * @param thisService the service to execute on.
     */
    public AutoInvoke(AutoEngineInfo thisAutoInfo, ArrayList thisParamList, ObjectsMap thisObjectsMap,
            Service thisService)
    {
        autoInfo = thisAutoInfo;
        paramList = thisParamList;
        //use copy of objects map so vars added are for this invocation only
        objectsMap = (ObjectsMap)thisObjectsMap.clone();
        service = thisService;
    }
    
    /**
     * Invoke the method in the {@code autoInfo} object, making variable replacements first.
     * From that object, the {@code evaluator} is used to execute the {@code method}.
     * The evaluation can be compared to the {@code function}. The {@code input} can 
     * be used to replace a tagged {@link Const}.{@code QUERY} parameter and so should be an
     * XML element. If the reply is OK, the autoInfo {@code effOutput} is returned as
     * the next set of actions.
     * @return the result of the evaluation. This is the {@code effector list} of the
     * input parameter if the evaluation is true, or an empty list if it is false.
     * Evaluating to true can include matching exactly to an XML description, or just have
     * any result, for example, by using a {@code checkReply} method.
     * @throws LicasException for a licas-specific mapping problem.
     * @throws java.lang.Exception any error.
     */
    public AutoOut invokeMethod() throws LicasException, Exception
    {
        int i;
        boolean isWebService;                       //true if the info is a web service
        int paramCount;                             //number of parameters
        String paramName;                           //parameter name
        String serviceName;                         //licas service name
        String serverPassword;                      //server password
        String servicePassword;                     //service password
        Element servicePath;                        //path description
        KeyValue keyValue;                          //key-value pair
        ParamInfo paramInfo;                        //next param info
        MethodInfo methodInfo;                      //method info
        ActionParallel actPar;                      //parallel action
        AutoReply autoReply;                        //the auton engine reply
        Service autoService;                        //the wrapped auto service
        Object filterClone;                         //filter clone
        Object messObj;                             //message object
        CallObject callObj;                         //licas call object
        RemoteCallDef mCall;                        //method call
               
        try {
            methodInfo = null;
            callObj = new CallObject();
            
            if (!ObjectHandler.isNull(autoInfo.evaluator) && !ObjectHandler.isNull(autoInfo.senInput.method)) {
                //parallel should be direct method calls on a service type
                if (isParallelAction(autoInfo.evaluator)) {
                    //method can still be in Xml format, so update first
                    if (autoInfo.senInput.method instanceof Element) {
                        autoInfo.senInput.method = ReflectionParser.xmlToMethod((Element)autoInfo.senInput.method);
                    }

                    //add mapped values to empty parameter values if stored
                    paramList = ((MethodInfo)autoInfo.senInput.method).getParams();
                    objectsMap.mapToVars(paramList);
                    
                    actPar = (ActionParallel)autoInfo.evaluator;
                    autoInfo.senInput.output = actPar.parallel(paramList, objectsMap);
                }
                //call on service itself can be direct
                else if ((ObjectHandler.isString(autoInfo.evaluator) &&
                        autoInfo.evaluator.equals(AiConst.THIS)) &&
                        (autoInfo.senInput.method instanceof MethodInfo)) {
                    //probably retrieved auto queue message
                    //check and reset passwords
                    methodInfo = (MethodInfo)autoInfo.senInput.method;
                    autoInfo.senInput.output = ObjectInvoker.invokeMethod(methodInfo, service);
                }
                //can be call to any resource
                else {
                    //need to map variables and determine the correct method type
                    isWebService = false;
                    objectsMap.varsToMap(paramList);
                    
                    if (ObjectHandler.isString(autoInfo.evaluator) && WsFactory.hasInstance()) {
                        try {
                            //check for a wsdl document URI, stored as a string
                            //if so then need to parse from the document first
                            methodInfo = WsFactory.getInstance().toMethodInfo((String)autoInfo.senInput.method, (String)autoInfo.evaluator);
                            if (objectsMap.containsKey(MetaConst.USERNAME)) {
                                ((WsMethodInfo)methodInfo).setWsUsername((String)objectsMap.get(MetaConst.USERNAME));
                            }
                            if (objectsMap.containsKey(MetaConst.PASSWORD)) {
                                methodInfo.setPassword((String)objectsMap.get(MetaConst.PASSWORD));
                            }

                            autoInfo.evaluator = methodInfo;
                            isWebService = true;
                        }
                        catch (Exception wsex) {
                            isWebService = false;
                        }
                    }

                    //if not web service, then local object or licas service
                    if (!isWebService) {
                        methodInfo = ReflectionParser.xmlToMethod((Element)autoInfo.senInput.method);
                    }

                    //if method parsed, can try to execute it
                    if (methodInfo != null) {
                        //update the parameters list - need to check for some replacements first
                        paramCount = methodInfo.getParams().size();
                        if (paramList != null) {
                            //evaluation function is typically true-false, but might be other (XML)
                            //so keep option for the more flexible evaluation
                            if (autoInfo.senInput.filter != null) {
                                if (autoInfo.senInput.filter instanceof Element) {
                                    filterClone = ((Element)autoInfo.senInput.filter).clone();
                                    MetaFactory.replaceValue((Element)filterClone, paramList);
                                }
                            }

                            //create a list of parameter values
                            for (i = 0; i < paramCount; i++)
                            {
                                paramInfo = methodInfo.getParams().get(i);
                                paramName = paramInfo.getName();

                                if (!ObjectHandler.isNull(paramName)) {
                                    if (ObjectHandler.isNull(paramInfo.getValue())) {
                                        if (objectsMap.containsKey(paramName)) {
                                            keyValue = new KeyValue();
                                            keyValue.key = paramName;
                                            keyValue.value = objectsMap.get(paramName);
                                            paramList.add(keyValue);
                                        }
                                        else if (objectsMap.containsKey(paramName.toLowerCase())) {
                                            keyValue = new KeyValue();
                                            keyValue.key = paramName;
                                            keyValue.value = objectsMap.get(paramName.toLowerCase());
                                            paramList.add(keyValue);
                                        }
                                    }
                                    else {
                                        paramList.add(Const.NULL);
                                    }
                                }
                            }

                            //replace the empty value slots in the method with any 
                            //related values in the param list, considering kay name changes
                            objectsMap.mapToParams(methodInfo.getParams(), autoInfo.senInput.input);    
                            MethodFactory.mapToParams(methodInfo, paramList);

                            //evaluate the function - can be licas, web service, or local
                            if (isLicasCall(autoInfo.evaluator)) {
                                //get object to invoke or setup correct handle description to access it.
                                autoService = null;
                                serverPassword = null;
                                servicePassword = null;
                                servicePath = null;

                                if (objectsMap.containsKey(AiConst.THIS)) {
                                    messObj = objectsMap.get(AiConst.THIS);
                                    if (messObj instanceof Service) autoService = (Service)messObj;
                                }
                                if (objectsMap.containsKey(Const.SERVERPASSWORD)) {
                                    serverPassword = (String)objectsMap.get(Const.SERVERPASSWORD);
                                }                    
                                if (objectsMap.containsKey(Const.SERVICEPASSWORD)) {
                                    //without service name need to rely on stored value
                                    servicePassword = (String)objectsMap.get(Const.SERVICEPASSWORD);
                                }                    
                                if ((autoService != null) && (servicePassword == null)) {
                                    try {
                                        servicePassword = autoService.getPassword(Const.ANON, Contract.getYesContract());
                                    }
                                    catch(Exception ex) {}
                                }
                                //if password still null, try anon
                                if (serverPassword == null) serverPassword = Const.ANON;
                                if (servicePassword == null) servicePassword = Const.ANON;

                                if (ObjectHandler.isString(autoInfo.evaluator)) {
                                    serviceName = (String)autoInfo.evaluator;
                                    if (autoService != null) {
                                        servicePath = Handle.createServiceHandle(autoService.getUUID());
                                        if (!serviceName.equalsIgnoreCase(autoService.getUUID())) {
                                            servicePath = Handle.addToHandle(servicePath, Handle.asHandleElement(serviceName));
                                        }
                                    }
                                }
                                else {
                                    servicePath = (Element)autoInfo.evaluator;
                                }

                                if (servicePath != null) {
                                    methodInfo.setServiceURI(servicePath);
                                    methodInfo.setServerPassword(serverPassword);
                                    methodInfo.setPassword(servicePassword);
                                    autoInfo.senInput.output = callObj.call(methodInfo);
                                }
                                else {
                                    throw new LicasException("Could not retrieve all (licas) values from the script.");
                                }
                            }
                            else if (isWsCall(autoInfo.evaluator)) {
                                mCall = CallHandler.getRemoteCommunicationObject((MethodInfo)autoInfo.evaluator);
                                autoInfo.senInput.output = mCall.execute(methodInfo);
                            }
                            else {
                                //invoke an local object that is not a licas service
                                autoInfo.senInput.output = ObjectInvoker.invokeMethod(methodInfo, autoInfo.evaluator);
                            }
                        }
                    }
                    else {
                        throw new LicasException("Could not parse the script to create the MethodInfo to call.");
                    }
                }

                //check for valid reply
                /** This can evaluate the reply object for success */
                autoReply = new AutoReply(autoInfo.getMethodReply());
                if (!autoReply.evaluate(autoInfo.senInput.filter,
                    autoInfo.senInput.function, objectsMap)) {
                    if (autoInfo.hasEffOutput()) {
                        autoInfo.getEffOutput().setToError();
                    }
                }
            }

            return autoInfo.getEffOutput();
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "invokeMethod", null, ex);
        }
    }
    
    /**
     * Return true if the evaluator object indicates a licas service that should be invoked.
     * @param evaluator the evaluator object.
     * @return true if it indicates a licas service to perform the evaluation.
     */
    protected boolean isLicasCall(Object evaluator)
    {
        return (ObjectHandler.isString(evaluator) || ObjectHandler.isElement(evaluator));
    }
    
    /**
     * Return true if the evaluator object indicates a web service that should be invoked.
     * @param evaluator the evaluator object.
     * @return true if it indicates a web service to perform the evaluation.
     */
    protected boolean isWsCall(Object evaluator)
    {
        MethodInfo methodInfo;                  //method info
        
        try {
            methodInfo = (MethodInfo)evaluator;
            return CallHandler.isWsCall(methodInfo);
        }
        catch (Exception ex) {}
        
        return false;
    }
    
        /**
     * Return true if the evaluator is a parallel action.
     * @param evaluator the current script evaluator.
     * @return true if of type {@link ActionParallel}.
     */
    private boolean isParallelAction(Object evaluator)
    {
        return (evaluator instanceof ActionParallel);
    }
}
