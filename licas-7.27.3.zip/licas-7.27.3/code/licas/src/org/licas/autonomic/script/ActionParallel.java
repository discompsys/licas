/*
 * ActionParallel.java
 *
 * Created on 7 January 2018
 *
 * Version 1.2.1
 *
 * Copyright (c) Kieran Greer.
 */

package org.licas.autonomic.script;


import org.ai_heuristic.eval.Condition;
import org.ai_heuristic.util.AiHeuristicConst;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.MessageInfo;
import org.licas.PasswordHandler;
import org.licas.call.CallPool;
import org.licas.call.Handle;
import org.licas.call.MethodFactory;
import org.licas.call.MethodInfo;
import org.licas.server.LocalServer;
import org.licas.util.Const;
import org.licas.util.TypeConst;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;

import java.util.*;


/**
 * This manages a single parallel action executed on an {@link AutoEngine} script.
 * This class is created internally, so only ever create an {@link ActionSequential} when
 * writing the script code. This is then one event in the sequence.
 * @author Kieran Greer
 */
public class ActionParallel
{
    /** The logger */
    private static final Logger logger;
    
    /** 
     * If true return first true result, if false return the best true result when all 
     * replies have been received. 
     */
    private final boolean firstOrBest;
    
    /** True when completed */
    private boolean completed;
    
    /** The type of service to invoke */
    private final String serviceType;
    
    /** Specific list of sources to use instead of a source type */
    private ArrayList<Element> sources;
    
    /** Parent info object with the other information */
    private final AutoEngineInfo autoInfo;
    
    /** List of method invokes */
    private HashMap<String, MethodInfo> autoInvokes;
    
    /** To manage the parallel threads */
    private CallPool callPool;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ActionParallel.class.getName());
        logger.setDebug(false);
    }
    
    /** 
     * Create a new instance of ActionParallel.
     * @param theServiceType the type of service to invoke.
     * @param theAutoInfo the process element description to be executed.
     * @param thisFirstOrBest if true return first true result, if false return the best
     * true result when all replies have been received.
     */
    public ActionParallel(String theServiceType, AutoEngineInfo theAutoInfo, boolean thisFirstOrBest)
    {
        serviceType = theServiceType;
        sources = null;
        autoInfo = theAutoInfo;
        firstOrBest = thisFirstOrBest;
        completed = false;
        autoInvokes = null;
    }
    
    /** 
     * Create a new instance of ActionParallel.
     * @param theSources specific list of sources to invoke.
     * @param theAutoInfo the process element description to be executed.
     * @param thisFirstOrBest if true return first true result, if false return the best
     * true result when all replies have been received.
     */
    public ActionParallel(ArrayList<Element> theSources, AutoEngineInfo theAutoInfo, boolean thisFirstOrBest)
    {
        serviceType = null;
        sources = theSources;
        autoInfo = theAutoInfo;
        firstOrBest = thisFirstOrBest;
        completed = false;
        autoInvokes = null;
    }
       
    /**
     * Invoke the parallel method list and return the result.
     * @param paramList an external set of objects that can replace named or tagged fields in
     *                  the method parameter lists. If empty or no match, then nothing gets changed.
     * @param objectsMap mapping of variable names to instances. This method can ad more
     * variables, but should be for the method invocation only, so immediately cloned.
     * @return the result of the evaluation. This is the {@code effectorList} of the
     * input parameter if the evaluation is true, or an empty list if it is false.
     * Evaluating to true can include matching exactly to an XML description, or just have
     * any result, for example, by using a {@code checkReply} method.
     * @throws java.lang.Exception any error.
     */
    protected Object parallel(ArrayList<?> paramList, ObjectsMap objectsMap) throws Exception
    {
        int i, j;
        String serviceName;                         //service name
        String serverPassword;                      //server password
        String servicePassword;                     //service password
        String[] passwords;                         //passwords
        Element serviceUri;                         //service to invoke
        ArrayList<String> serviceTypes;             //list of service types
        ArrayList<String> serviceNames;             //list of service names
        PasswordHandler passwordHandler;            //password handler
        MethodInfo methodInfo;                      //method info
        MethodInfo callBack;                        //call-back method info
        Object result;                              //method result or reply
        
        try
        {
            //get list of services from type and execute method on each
            passwordHandler = autoInfo.engine.getPasswordHandler();
            serverPassword = Const.ANON;
            
            if (sources == null) {
                serviceTypes = new ArrayList<>();
                serviceTypes.add(serviceType);

                if (passwordHandler.hasServicePassword(LocalServer.getServerHandle())) {
                    serverPassword = passwordHandler.getServicePassword(LocalServer.getServerHandle());
                }
                serviceNames = LocalServer.getApi(serverPassword).getServiceNames(serviceTypes);
                
                sources = new ArrayList<>();
                for (i = 0; i < serviceNames.size(); i++)
                {
                    serviceName = serviceNames.get(i);
                    serviceUri = Handle.createNewUrlHandle(LocalServer.getServerURL());
                    serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceName));
                    sources.add(serviceUri);
                }
            }
            
            //maybe don't need to use AutoInvoke if can make service call
            autoInvokes = new HashMap<>();
            for (i = 0; i < sources.size(); i++)
            {
                serviceUri = sources.get(i);

                servicePassword = Const.ANON;
                passwords = objectsMap.getPasswords(serviceUri, passwordHandler);
                if (passwords[1] != null) servicePassword = passwords[1];

                methodInfo = (MethodInfo)((MethodInfo)autoInfo.senInput.method).clone();
                methodInfo.setServiceURI(serviceUri);
                methodInfo.setServerPassword(serverPassword);
                methodInfo.setPassword(servicePassword);
                methodInfo.clearParams();

                for (j = 0; j < paramList.size(); j++)
                {
                    methodInfo.addParam(paramList.get(j));
                }

                autoInvokes.put(XmlHandler.xmlToString(serviceUri), methodInfo);
            }

            //create the call pool
            if (firstOrBest)
            {
                callPool = CallPool.syncExecuteOnce(autoInvokes, null);  
                result = waitEvaluateFirstReply(objectsMap);
            }
            else
            {
                completed = false;
                callBack = MethodFactory.createMethodCall("setCompleted", TypeConst.VOID, 
                    this, null, passwordHandler);
                
                callPool = CallPool.syncExecuteOnce(autoInvokes, callBack);  
                result = waitEvaluateBestReply(objectsMap);
            }

            if (result instanceof MessageInfo) {
                return ((MessageInfo)result).getMessage();
            }
            else {
                return result;
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, 
                    "parallel", null, ex);
        }
    }
    
    /**
     * Execute the callpool and evaluate as the first reply returned.
     * @param objectsMap mapping of variable names to instances. This method can ad more
     * variables, but should be for the method invocation only, so immediately cloned.
     * @return the result of the evaluation. This is the {@code effectorList} of the
     * input parameter if the evaluation is true, or an empty list if it is false.
     * Evaluating to true can include matching exactly to an XML description, or just have
     * any result, for example, by using a {@code checkReply} method.
     * @throws java.lang.Exception any error.
     */
    protected Object waitEvaluateFirstReply(ObjectsMap objectsMap) throws Exception
    {
        int counter;                                //to synchronize with
        String methodKey;                           //method key
        Iterator<String> it;                        //list of keys
        AutoReply autoReply;                        //auto reply
        Map<String, Object> results;                //synchronized results
        Object result;                              //method result or reply
        Object nextResult;                          //next result
        
        try {
            //counter synchronizes and allows additional final pass after callpool has shut-down
            counter = 0;
            result = null;
            
            while ((result == null) && (counter < 2))
            {
                results = callPool.getResults();
                if ((results != null) && !results.isEmpty()) {
                    //check results until positive one returned
                    it = results.keySet().iterator();
                    while ((result == null) && it.hasNext())
                    {
                        methodKey = it.next();
                        if (methodKey != null) {
                            nextResult = results.get(methodKey);

                            //if OK then shutdown callpool
                            autoReply = new AutoReply(nextResult);
                            if (autoReply.evaluate(autoInfo.senInput.filter,
                                autoInfo.senInput.function, objectsMap)) {
                                callPool.shutDown();
                                result = new MessageInfo(nextResult);
                            }
                        }
                    }
                }

                Thread.sleep(10);
                if (!callPool.getShutDown()) counter = 0;
                else counter++;
            }

            return result;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, 
                    "waitEvaluateFirstReply", null, ex);
        }
        finally {
            callPool.shutDown();
        }
    }
    
    /**
     * Execute the callpool and evaluate as the best reply returned over all replies.
     * @param objectsMap mapping of variable names to instances. This method can ad more
     * variables, but should be for the method invocation only, so immediately cloned.
     * @return the result of the evaluation. This is the {@code effectorList} of the
     * input parameter if the evaluation is true, or an empty list if it is false.
     * Evaluating to true can include matching exactly to an XML description, or just have
     * any result, for example, by using a {@code checkReply} method.
     * @throws java.lang.Exception any error.
     */
    protected Object waitEvaluateBestReply(ObjectsMap objectsMap) throws Exception
    {
        String methodKey;                           //method key
        Iterator<String> it;                        //list of keys
        Condition condition;                        //results comparison
        AutoReply autoReply;                        //auto reply
        Map<String, Object> results;                //synchronized results
        MessageInfo result;                         //method result or reply
        Object nextResult;                          //next result
        
        try
        {
            result = null;
            while (!completed)
            {
                Thread.sleep(10);
            }
            
            results = callPool.getResults();
            if ((results != null) && !results.isEmpty()) {
                //check results until positive one returned
                it = results.keySet().iterator();
                while (it.hasNext())
                {
                    methodKey = it.next();
                    if (methodKey != null) {
                        nextResult = results.get(methodKey);

                        //if OK then shutdown callpool
                        autoReply = new AutoReply(nextResult);
                        if (autoReply.evaluate(autoInfo.senInput.filter,
                            autoInfo.senInput.function, objectsMap)) {

                            if (result == null) {
                                result = new MessageInfo(nextResult);
                            }
                            else {
                                //if nextResult GT result, set result to nextResult
                                condition = new Condition();
                                condition.valueType = autoInfo.senInput.function.valueType;
                                condition.op = AiHeuristicConst.GT;
                                condition.value = result.getMessage();
                                
                                if (condition.compareWith(nextResult)) {
                                    result = new MessageInfo(nextResult);
                                }
                            }
                        }
                    }
                }
            }

            return result;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, 
                    "waitEvaluateBestReply", null, ex);
        }
        finally {
            callPool.shutDown();
        }
    }
    
    /** To indicate that the call pool has completed */
    public void setCompleted()
    {
        completed = true;
    }
}
