/*
 * AutoOut.java
 *
 * Created on 7 January 2018
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer.
 */

package org.licas.autonomic.script;


import org.licas.util.ObjectHandler;

import java.util.ArrayList;


/**
 * A list of effectors that relate to a positive evaluator result.
 * @author Kieran Greer
 */
public class AutoOut 
{
    /** Indicates a script execution reply error */
    private static final String ERR = "err:aubaidzqqf";
    
    
    /** Effector actions to carry out if the evaluation is true. Of type AutoEngineInfo */
    private ArrayList<AutoEngineInfo> effectorList;
    
    
    /** Create a new instance of AutoEffector */
    public AutoOut()
    {
        resetEffectors();
    }
    
    /** Set the effector reply to indicate an error. */
    public void setToError()
    {
        AutoEngineInfo autoInfo;                //error info
        
        autoInfo = new AutoEngineInfo(null);
        autoInfo.evaluator = ERR;
        
        effectorList.clear();
        effectorList.add(autoInfo);
    }
    
    /**
     * Return true if effector reply is OK for processing.
     * @return true if contains list of effector statement(s).
     */
    protected boolean isOK()
    {
        return (!isError() && (effectorList != null) && (effectorList.size() > 0));
    }
    
    /**
     * Return true if effector reply is Not OK for processing.
     * @return true if empty list or error statement.
     */
    protected boolean notOK()
    {
        return (isOK() && !isError());
    }
    
    /**
     * Return true if effector reply contains a specific error statement.
     * @return true if contains specific error statement.
     */
    protected boolean isError()
    {
        AutoEngineInfo autoInfo;                //error info
        
        if ((effectorList != null) && (effectorList.size() == 1))
        {
            autoInfo = effectorList.get(0);
            if (ObjectHandler.isString(autoInfo.evaluator))
            {
                return ((String)autoInfo.evaluator).equalsIgnoreCase(ERR);
            }
        }
        
        return false;
    }
    
    /** In case need to reset the effectors to empty list again */
    public void resetEffectors()
    {
        effectorList = new ArrayList<>();
    }
    
    /**
     * Get the number of effectors in the list. If set to error, then return 0.
     * @return the size of effectorList, or 0 if an error.
     */
    public int getEffectorsSize()
    {
        if (!isError()) return effectorList.size();
        else return 0;
    }
    
    /**
     * Get the effectors list. If an error then return null.
     * @return the value of effectorList, or null if an error.
     */
    public ArrayList<AutoEngineInfo> getEffectors()
    {
        if (!isError()) return effectorList;
        else return null;
    }
}
