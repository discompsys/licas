/*
 * MessageQueue.java
 *
 * Created on 26 January 2011
 *
 * Version 1.4.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.autonomic;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.MessageInfo;
import org.licas.call.MethodInfo;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * This class stores lists of messages for processing by the system. The messages
 * can be accessed in an ordered manner or based on communication ID. When an
 * autonomic component receives a message, it can put it onto a message queue if
 * it is wrapped inside of an {@link AutonomicManager}. The {@code Auto.messageReply(...)}
 * method will do this automatically. The manager then has full access to all 
 * messages and can use its control loop to process them and try to detect 
 * errors or faults.
 * @author Kieran Greer
 */
public class MessageQueue
{
    /** For logging */
    private static final Logger logger;

    /** 
     * List of messages received by this manager. A list keeps the order in
     * which they were received and are stored as {@link MessageInfo} objects.
     */
    private ArrayList<MessageInfo> messageQueue;

    /**
     * List of messages received by this manager for each communication ID.
     * Key is the communication ID and value is the list of related messages
     * of type {@link MessageInfo}.
     */
    private HashMap<String, ArrayList<MessageInfo>> messageComms;

    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(MessageQueue.class.getName());
        logger.setDebug(false);
    }


    /** Create a new instance of MessageQueue */
    public MessageQueue()
    {
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        messageQueue = new ArrayList<>();
        messageComms = new HashMap<>();
    }

    /**
     * Get the lit of current communication IDs.
     * @return the key list for the messageComms structure.
     */
    protected ArrayList<String> getCommIDs()
    {
        return new ArrayList<>(messageComms.keySet());
    }
    
    /**
     * Add a new message to the list. The message is added to the end of
     * the message queue and also the related conversation.
     * @param messageInfo a full {@code MessageInfo} description. The unique communication 
     * ID is required.
     */
    public void addMessage(MessageInfo messageInfo)
    {
        String commID;                              //communication ID
        ArrayList<MessageInfo> messageList;         //current list of messages
        
        commID = messageInfo.getCommID();
        if (commID != null) {
            //add to communications list
            if (!messageComms.containsKey(commID)) {
                messageList = new ArrayList<>();
                messageComms.put(commID, messageList);
            }

            messageList = messageComms.get(commID);
            messageList.add(messageInfo);

            //add to message queue
            messageQueue.add(messageInfo);
        }
    }

    /**
     * Return true if the message queue is empty, meaning no message in the queue.
     * @return true if empty.
     */
    public boolean isEMpty() {
        return messageQueue.isEmpty();
    }

    /**
     * Get the size of the message queue.
     * @return the size of messageQueue.
     */
    public int queueSize()
    {
        return messageQueue.size();
    }
    
    /**
     * Get the message at position {@code index} in the queue, but keep the message in all queues.
     * @param index index of the message to retrieve.
     * @return the message at position {@code index} in the queue, or null if out of range.
     */
    public MessageInfo getMessageAt(int index)
    {
        MessageInfo messageInfo;                        //message info

        messageInfo = null;
        if (messageQueue.size() > index) {
            messageInfo = messageQueue.get(index);
        }

        return messageInfo;
    }
    
    /**
     * Get the next message in the queue, but keep the message in all queues.
     * @return the next message in the queue.
     */
    public MessageInfo getNextMessage()
    {
        MessageInfo messageInfo;                        //message info

        messageInfo = null;
        if (messageQueue.size() > 0) {
            messageInfo = messageQueue.get(0);
        }

        return messageInfo;
    }
    
    /**
     * Get the message at position {@code index} in the queue and remove the message from all queues.
     * @param index index of the message to retrieve.
     * @return the message at position {@code index} in the queue, or null if out of range.
     */
    public MessageInfo getAndRemoveMessageAt(int index)
    {
        int i;
        String commID;                                  //communication id
        ArrayList<MessageInfo> messageList;             //message list
        MessageInfo messageInfo;                        //message info
        MessageInfo nextMessageInfo;                    //next message info

        messageInfo = null;
        if (messageQueue.size() > index) {
            messageInfo = messageQueue.remove(index);
            commID = messageInfo.getCommID();
            messageList = messageComms.get(commID);
            
            for (i = 0; i < messageList.size(); i++)
            {
                nextMessageInfo = messageList.get(i);
                if (messageInfo.isSameObj(nextMessageInfo)) {
                    messageList.remove(i);
                    break;
                }
            }
        }

        return messageInfo;
    }
    
    /**
     * Get the next message in the queue and remove the message from all queues.
     * @return the next message in the queue.
     */
    public MessageInfo getAndRemoveNextMessage()
    {
        String commID;                                  //communication id
        ArrayList<MessageInfo> messageList;             //message list
        MessageInfo messageInfo;                        //message info

        messageInfo = null;
        if (messageQueue.size() > 0) {
            messageInfo = messageQueue.remove(0);
            commID = messageInfo.getCommID();
            messageList = messageComms.get(commID);
            messageList.remove(0);
        }

        return messageInfo;
    }

    /**
     * Get the next message in the queue relating to a particular time interval.
     * Return the first message that lies inside the time interval.
     * This also automatically removes the message from all queues.
     * @param startTimeStamp the start time interval for the message.
     * @param endTimeStamp the end time interval for the message.
     * @return the next message in the queue.
     */
    public MessageInfo getAndRemoveNextMessageTime(long startTimeStamp, long endTimeStamp)
    {
        int i, j;
        boolean messageFound;                           //true if message found
        String commID;                                  //communication id
        ArrayList<MessageInfo> messageList;             //message list
        MessageInfo messageInfo;                        //message info
        MessageInfo messageComm;                        //message comm info

        messageInfo = null;
        messageFound = false;

        for (i = 0; !messageFound && (i < messageQueue.size()); i++)
        {
            messageInfo = messageQueue.get(i);
            if ((messageInfo.getTimeStamp() >= startTimeStamp) &&
                (messageInfo.getTimeStamp() <= endTimeStamp)) {
                messageFound = true;
                messageInfo = messageQueue.remove(i);
                commID = messageInfo.getCommID();

                messageList = messageComms.get(commID);
                for (j = 0; j < messageList.size(); j++)
                {
                    messageComm = messageList.get(j);
                    if (messageInfo.isSameID(messageComm)) {
                        messageList.remove(j);
                        break;
                    }
                }
            }
        }

        if (messageFound) return messageInfo;
        else return null;
    }
    
    /**
     * Get the next message in the queue relating to a particular time interval.
     * This is an exact time stamp, probably relating to only one message.
     * This also automatically removes the message from all queues.
     * @param timeStamp the exact timestamp for the message.
     * @return the next message in the queue.
     */
    public MessageInfo getAndRemoveNextMessageTime(long timeStamp)
    {
        int i, j;
        boolean messageFound;                           //true if message found
        String commID;                                  //communication id
        ArrayList<MessageInfo> messageList;             //message list
        MessageInfo messageInfo;                        //message info
        MessageInfo messageComm;                        //message comm info

        messageInfo = null;
        messageFound = false;

        for (i = 0; !messageFound && (i < messageQueue.size()); i++)
        {
            messageInfo = messageQueue.get(i);
            if (messageInfo.getTimeStamp() == timeStamp) {
                messageFound = true;
                messageInfo = messageQueue.remove(i);
                commID = messageInfo.getCommID();

                messageList = messageComms.get(commID);
                for (j = 0; j < messageList.size(); j++)
                {
                    messageComm = messageList.get(j);
                    if (messageInfo.isSameID(messageComm)) {
                        messageList.remove(j);
                        break;
                    }
                }
            }
        }

        if (messageFound) return messageInfo;
        else return null;
    }
    
    /**
     * Get the next message in the queue relating to a particular method name.
     * This must be a {@link MethodInfo} object and it also automatically removes the 
     * message from all queues.
     * @param methodName the name of the method to retrieve.
     * @return the next message in the queue with the specified name.
     */
    public MessageInfo getAndRemoveNextMessageName(String methodName)
    {
        int i, j;
        boolean messageFound;                           //true if message found
        String commID;                                  //communication id
        ArrayList<MessageInfo> messageList;             //message list
        MessageInfo messageInfo;                        //message info
        MessageInfo messageComm;                        //message comm info
        MethodInfo methodInfo;                          //method info
        Object methodObj;                               //any method object

        messageInfo = null;
        messageFound = false;

        for (i = 0; !messageFound && (i < messageQueue.size()); i++)
        {
            messageInfo = messageQueue.get(i);
            methodObj = messageInfo.getMessage();

            if (methodObj instanceof MethodInfo) {
                methodInfo = (MethodInfo)methodObj;

                if (methodInfo.getName().equalsIgnoreCase(methodName)) {
                    messageFound = true;
                    messageInfo = messageQueue.remove(i);
                    commID = messageInfo.getCommID();

                    messageList = messageComms.get(commID);
                    for (j = 0; j < messageList.size(); j++)
                    {
                        messageComm = messageList.get(j);
                        if (messageInfo.isSameID(messageComm)) {
                            messageList.remove(j);
                            break;
                        }
                    }
                }
            }
        }

        if (messageFound) return messageInfo;
        else return null;
    }

    /**
     * Remove all messages, from both lists, with the specified communication ID.
     * @param commID the message communication ID.
     */
    public void removeAllMessages(String commID)
    {
        int i;
        MessageInfo nextMessage;                    //next message
        
        i = 0;
        while (i < messageQueue.size()) 
        {
            nextMessage = messageQueue.get(i);
            if (nextMessage.getCommID().equals(commID)) {
                messageQueue.remove(i);
            }
            else {
                i++;
            }
        }
        
        messageComms.remove(commID);
    }
    
    /**
     * Return the message to the start of the message queue
     * and update all other message lists.
     * @param nextMessage the message to add again.
     */
    protected void returnLastMessage(MessageInfo nextMessage)
    {
        String commID;                              //communication id
        ArrayList<MessageInfo> messageList;         //message list
        
        commID = nextMessage.getCommID();
        messageQueue.add(0, nextMessage);

        if (!messageComms.containsKey(commID)) {
            messageList = new ArrayList<>();
            messageComms.put(commID, messageList);
        }

        messageList = messageComms.get(commID);
        messageList.add(0, nextMessage);
    }

    /**
     * Get the number of messages related to a particular communication ID.
     * @param commID the communication ID.
     * @return the number of messages in the related message queue, or
     * 0 if there are no messages.
     */
    protected int getConversationLength(String commID)
    {
        if (messageComms.containsKey(commID)) {
            return messageComms.get(commID).size();
        }
        else {
            return 0;
        }
    }

    /**
     * Get a copy of the specified message in the specified conversation.
     * This returns a copy that does not change the original message queue, but
     * the message itself can be changed by the calling program.
     * Use {@code getAndRemoveMessage} to retrieve the message and also remove it from the queue.
     * @param commID the communication ID.
     * @param position the position of the message in the communication queue.
     * @return a copy of the specified message.
     */
    protected MessageInfo copyConversationMessage(String commID, int position)
    {
        ArrayList<MessageInfo> messageList;             //message list
        MessageInfo messageInfo;                        //message info

        messageInfo = null;
        if (messageComms.containsKey(commID)) {
            messageList = messageComms.get(commID);
            if (messageList.size() > position) {
                messageInfo = (MessageInfo)messageList.get(position).clone();
            }
        }

        return messageInfo;
    }

    /**
     * Get a copy of all messages time stamped between the two time intervals.
     * This returns a copy that does not change the original message queue, but
     * the message itself can be changed by the calling program.
     * Use {@code getAndRemoveMessage} to retrieve the message and also remove it from the queue.
     * @param startTime the start of the time interval.
     * @param endTime the end of the time interval.
     * @return a copy of the specified message.
     */
    protected ArrayList<MessageInfo> copyMessageInterval(long startTime, long endTime)
    {
        int i;
        long timeStamp;                                 //time stamp
        ArrayList<MessageInfo> copyList;                //list of copied messages
        MessageInfo messageInfo;                        //message info
        
        copyList = new ArrayList<>();
        for (i = 0; i < messageQueue.size(); i++)
        {
            messageInfo = messageQueue.get(i);
            timeStamp = messageInfo.getTimeStamp();

            if ((timeStamp >= startTime) && (timeStamp <= endTime)) {
                messageInfo = (MessageInfo)messageInfo.clone();
                copyList.add(messageInfo);
            }
        }

        return copyList;
    }
}
