/*
 * AM_PlanDefault.java
 *
 * Created on 8 May 2014
 *
 * Version 1.5.1
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.autonomic;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.MessageInfo;
import org.licas.PasswordHandler;
import org.licas.Service;
import org.licas.util.AiConst;
import org.licas.util.Const;
import org.licas.util.KeyValue;

import java.util.ArrayList;


/**
 * This class is an example of a default autonomic manager planner, but does not
 * process anything as default. It needs to be managed by a policy script.
 * This still needs to be completed.
 * @author Kieran Greer
 */
public class AM_PlanDefault extends AM_Module
{
    /** For logging */
    private static final Logger logger;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(AM_PlanDefault.class.getName());
        logger.setDebug(false);
    }


    /** 
     * Create a new instance of AM_PlanDefault. You can only use the {@code AutoEngine} if the
     * {@link AutonomicManager} wraps a licas {@link Service}-derived object.
     * @param serviceObj the service object wrapped by the autonomic manager.
     * @param passwordHandler the service's password handler, for the auto script engine.
     */
    public AM_PlanDefault(Service serviceObj, PasswordHandler passwordHandler)
    {
        super(serviceObj, passwordHandler);
    }

    /**
     * Process the data and return the result. this default version will evaluate the 
     * message, using any declared default method, to determine if it matches with the policy.
     * As this is only one monitoring implementation version, it is possible that you will
     * need to override this method to implement a more application-specific one, but it
     * will provide some flexibility, as it can be configured through the {@code setEventRuleAction}
     * method, for example.
     * @param messageInfo the message to evaluate.
     * @return the result of the monitoring. Note that this should not change the input message
     * and is a list of actions to carry out in sequence. Each action is a list of {@link KeyValue}
     * objects that can include a {@link Const}.{@code REPLY} object and {@link AiConst}.{@code EFFECTOR}
     * method XML description, or other objects. These are typically all included with each action message,
     * where they have to be identified by the related key value.
     * @throws java.lang.Exception any error.
     */
    protected ArrayList<KeyValue> process(MessageInfo messageInfo) throws Exception
    {
        if (autoEngine.hasProcess()) {
            return autoEngine.process(messageInfo);
        }
        else {
            return new ArrayList<>();
        }
    }
}
