/**
 * Specifically for the autonomic Execution Engine and execution script. 
 */
package org.licas.autonomic.script;