/*
 * ActionSequential.java
 *
 * Created on 12 December 2017
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer.
 */

package org.licas.autonomic.script;


import org.licas.MessageInfo;
import org.licas.util.*;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;

import java.util.ArrayList;


/**
 * This manages a sequential action executed on an {@link AutoEngine} script.
 * This should execute a sequence of instructions until an effector list is returned 
 * or the end of the script is reached.
 * @author Kieran Greer
 */
public class ActionSequential 
{
    /** The logger */
    private static final Logger logger;
    
    
    /** Variable list for the evaluator methods */
    private ArrayList<KeyValue> evalVars;
    
    /** Variable list for the effector methods */
    private ArrayList<KeyValue> effVars;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ActionSequential.class.getName());
        logger.setDebug(false);
    }
        
        
    /**
     * Create a new instance of ActionSequential.
     */
    public ActionSequential()
    {
        evalVars = new ArrayList<>();
        effVars = new ArrayList<>();
    }
    
    /**
     * Execute a configurable autonomic event, based on the evaluation result.
     * @param commID a communication thread ID, from the MessageInfo object, for example.
     * @param autoEngine the execution engine. May already have some variables stored.
     * @return the finally evaluated effector method result.
     * @throws java.lang.Exception any error.
     */
    public Object sequential(String commID, AutoEngine autoEngine) throws Exception
    {
        int i;
        boolean trueEvent;                      //true if a true auto event
        ArrayList<KeyValue> replyList;          //reply list
        KeyValue keyValue;                      //key-value pair
        MessageInfo messageInfo;                //auto evaluation message
        AutoEngineInfo autoReply;               //auto engine reply
        AutoOut effectorList;                   //effector methods list
        Object reply;                           //auto engine reply
        
        try {
            //if there is a message result and it indicates an effector,
            //try to execute the script method that it describes on the service that it specifies
            trueEvent = false;
            effectorList = null;
            reply = null;

            autoEngine.resetEventRuleAction();
            while (!trueEvent && !autoEngine.isFinished())
            {
                messageInfo = new MessageInfo(commID, evalVars.clone());

                //determine reply and/or effector action list
                replyList = autoEngine.process(messageInfo);
                if ((replyList != null) && !replyList.isEmpty()) {
                    //get reply value and effector list - only use effector list here
                    for (i = 0; i < replyList.size(); i++)
                    {
                        keyValue = replyList.get(i);
                        if (keyValue.key.equals(Const.REPLY)) {
                            reply = keyValue.value;
                        }
                        else if (keyValue.key.equals(AiConst.EFFECTOR)) {
                            effectorList = (AutoOut)keyValue.value;
                        }
                    }
                }

                //if list of effector actions then run these and end sequence
                if ((effectorList != null) && effectorList.isOK()) {
                    trueEvent = true;

                    //execute the effector methods in order
                    for (i = 0; i < effectorList.getEffectorsSize(); i++)
                    {
                        autoReply = effectorList.getEffectors().get(i);
                        reply = autoEngine.invokeMethod(autoReply, (ArrayList)effVars.clone());
                    }
                }
            }

            return reply;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, 
                    "sequential", null, ex);
        }
    }
    
    /**
     * Set the list of evaluator variables.
     * @param varList variable values list.
     */
    public void setEvalVars(ArrayList varList)
    {
        evalVars = varList;
    }
    
    /**
     * Set the list of effector variables.
     * @param varList effector variable values.
     */
    public void setEffVars(ArrayList varList)
    {
        effVars = varList;
    }
}
