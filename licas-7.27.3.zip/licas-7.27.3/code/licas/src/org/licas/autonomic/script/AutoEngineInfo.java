/*
 * AutoEngineInfo.java
 *
 * Created on 16 July 2014.
 *
 * Version 1.4.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.autonomic.script;


import org.ai_heuristic.parser.ConditionParser;
import org.dcs.query_process.Script_Engine;
import org.dcs.query_process.Script_Factory;
import org.dcs.query_process.model.Script_Element;
import org.dcs.query_process.model.Script_Model;
import org.dcs.query_process.model.activity.Script_Auto;
import org.dcs.query_process.model.activity.Script_Parallel;
import org.dcs.query_process.model.data.Script_VarMap;
import org.dcs.query_process.model.data.Script_Variable;
import org.dcs.query_process.model.event.Script_Event;
import org.dcs.query_process.model.event.Script_Invoke;
import org.dcs.query_process.model.link.Script_Source;
import org.dcs.query_process.model.link.Script_Target;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.MessageInfo;
import org.licas.call.MethodInfo;
import org.licas.parsers.Parsers;
import org.licas.util.*;
import org.licas.util.classloader.LoadObject;
import org.licas_text.util.MetaConst;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;

import java.util.ArrayList;


/**
 * This class stores a set of info objects that the {@link AutoEngine} uses to evaluate
 * a single policy event.
 * @author Kieran Greer
 */
public class AutoEngineInfo
{
    /** The logger */
    private static final Logger logger;
    
    /** True if a control loop element */
    public boolean controlLoop;
    
    /** True if the evaluation function is always true */
    public boolean alwaysTrue;
        
    /** Unique ID for the auto info object and related script event */
    public String eventID;
    
    /* The object that carries out the evaluation, or service the methods are executed on */
    public Object evaluator;
    
    /** Input evaluation conditions for the effector list to be selected */
    public AutoIn senInput;
    
    /** Actions to carry out if the evaluation is true. List of type AutoEngineInfo */
    public AutoOut effOutput;
           
    /** The engine that executes the info scripts */
    protected AutoEngine engine;
    
    /** Traversal to an executable element may be required */
    protected AutoEngineInfo parent;
    protected AutoEngineInfo next;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(AutoEngineInfo.class.getName());
        logger.setDebug(false);
    }
    
    
    /** 
     * Create a new instance of AutoEngineInfo.
     * @param theEngine the engine that executes this info object.
     */
    public AutoEngineInfo(AutoEngine theEngine) 
    {
        engine = theEngine;
        initialise();
    }

    /** Initialise some values */
    private void initialise() 
    {
        eventID = null;
        controlLoop = false;
        alwaysTrue = false;
        evaluator = null;
        senInput = null;
        effOutput = null;
        parent = next = null;
    }
    
    /**
     * Create the info object and convert the script descriptions into the appropriate
     * objects for executing the process event. If the script element does not contain
     * the correct entry, then try its sub-elements.
     * @param eventElem the process event element.
     * @param scriptModel the whole script model, with access to all element types.
     * @param objectsMap list of already created objects from script elements.
     * @return true if info retrieved OK, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean createInfo(Script_Event eventElem, Script_Model scriptModel, ObjectsMap objectsMap) 
            throws Exception
    {
        int i;
        boolean isOK;                           //true if OK
        String nextValue;                       //next value or id
        ArrayList<String> attrNames;            //list of attribute names
        ArrayList<String> attrValues;           //attribute values list
        Element scriptXml;                      //script xml version
        Element fElem;                          //function element
        MessageInfo messageInfo;                //message info
        ConditionParser cParser;                //condition parser
        Script_Element scriptElem;              //script element
        Script_Element invokeElem;              //next script element
        Script_Variable scriptVar;              //script variable
        Script_Engine scriptEngine;             //script engine
               
        try {
            isOK = true;
            invokeElem = null;
            
            //convert to xml to retrieve attribute tag names
            eventID = eventElem.getInternalID();
            alwaysTrue = Script_Factory.isAlwaysTrue(eventElem);
            controlLoop = Script_Factory.isControlLoop(eventElem);
            senInput = new AutoIn();

            if (!alwaysTrue) {
                if (Script_Factory.isAutoElement(eventElem)) {
                    messageInfo = engine.getAutoQueueMessage((Script_Auto)eventElem);

                    if (messageInfo != null) {
                        //this is for a single direct invocation on the service
                        evaluator = AiConst.THIS;

                        MethodInfo methodInfo = new MethodInfo();
                        methodInfo.setName(MethodConst.INVOKEBEHAVIOUR);
                        methodInfo.setRtnType(Const.OBJECT);
                        methodInfo.addParam(messageInfo);
                        senInput.method = methodInfo;
                    }
                }
                else {
                    scriptXml = eventElem.toXml();

                    //if parallel element, then the evaluator description is different
                    //sequential can be on specific targets
                    //parallel is on a service type
                    if (Script_Factory.isParallel(eventElem)) {
                        attrNames = Script_Factory.typeNames();

                        attrValues = Script_Factory.getAttrValues(scriptXml, attrNames, true);

                        if (!attrValues.isEmpty()) {
                            nextValue = attrValues.get(0);
                            evaluator = nextValue;
                        }
                        
                        //move to invoke description for rest of processing
                        scriptEngine = new Script_Engine();
                        if (eventElem.usesSubEvents()) {
                            scriptEngine.resetValues(eventElem.getEvents());
                        }
                        
                        invokeElem = scriptEngine.nextProcessStep();
                        scriptXml = invokeElem.toXml();
                    }
                    
                    //parse all (other) script values
                    attrNames = Script_Factory.sourceNames();       
                    attrValues = Script_Factory.getAttrValues(scriptXml, attrNames, true);

                    if (!attrValues.isEmpty()) {
                        nextValue = attrValues.get(0);

                        if (objectsMap.containsKey(nextValue)) {
                            evaluator = objectsMap.get(nextValue);
                        }
                        else {
                            scriptElem = scriptModel.getScriptWithID(nextValue);

                            if (scriptElem != null) {
                                checkUsernamePassword(scriptElem, objectsMap);
                                evaluator = parseToObject(scriptElem, scriptModel);

                                if (evaluator != null) {
                                    objectsMap.put(nextValue, evaluator);
                                }
                            }
                        }
                    }
                    
                    //get the evaluation method and related function - should be only one
                    //this can include single operation names or names with result conditions
                    attrNames = Script_Factory.operationNames();     
                    attrValues = Script_Factory.getAttrValues(scriptXml, attrNames, false);

                    if (!attrValues.isEmpty()) {
                        //check if compound name, including a function part
                        //also check if default 'true' function
                        nextValue = attrValues.get(0);
                        if (nextValue.equalsIgnoreCase("true")) {
                            evaluator = new Boolean(true);
                            senInput.method = new Boolean(true);
                        }
                        else if (objectsMap.containsKey(nextValue)) {
                            senInput.method = objectsMap.get(nextValue);
                        }
                        else {
                            scriptElem = scriptModel.getScriptWithID(nextValue);            
                            if (scriptElem != null) {
                                senInput.method = parseToObject(scriptElem, scriptModel);
                            }
                            else {
                                senInput.method = nextValue;
                            }

                            if (senInput.method != null) {
                                objectsMap.put(nextValue, senInput.method);
                            }
                        }
                    }

                    //if not boolean case then add the remaining variables
                    //an filter variable replaces a string-based function
                    if (!(evaluator instanceof Boolean)) {
                        //get the input variable mappings
                        if (eventElem.getVariables() != null) {
                            for (i = 0; i < eventElem.getVariables().size(); i++)
                            {
                                scriptVar = eventElem.getVariables().get(i);
                                senInput.input.put(scriptVar.getID(), (String)scriptVar.getValue());
                            } 
                        }
                        
                        //get the filter variable - should be only one
                        attrNames = Script_Factory.filterNames();       
                        attrValues = Script_Factory.getAttrValues(scriptXml, attrNames, false);        
                        if (!attrValues.isEmpty()) {
                            nextValue = attrValues.get(0);
                            if (objectsMap.containsKey(nextValue)) {
                                senInput.filter = objectsMap.get(nextValue);
                            }
                            else {
                                scriptElem = scriptModel.getScriptWithID(nextValue);            
                                if (scriptElem != null) {
                                    senInput.filter = parseToObject(scriptElem, scriptModel);
                                    if (senInput.filter != null) {
                                        objectsMap.put(nextValue, senInput.filter);
                                    }
                                }
                            }

                            //also check the seconds or desired result type
                            //if true can ignore, but if function, can add to the objects list
                            if (attrValues.size() > 1) {
                                nextValue = attrValues.get(1);
                                if (!(nextValue.equalsIgnoreCase(Boolean.toString(true)) ||
                                    nextValue.equalsIgnoreCase(Boolean.toString(false)))) {
                                    if (!objectsMap.containsKey(nextValue)) objectsMap.put(nextValue, nextValue);
                                }
                            }
                        }
                    }
                    
                    //additional string function on the filter is possible
                    fElem = Script_Factory.functionElement(scriptXml);
                    if (fElem != null) {
                        cParser = new ConditionParser();
                        senInput.function = cParser.parse(fElem);
                    }
                }
            }
            else {
                evaluator = eventElem;
            }

            
            //convert to parallel action if that is the script element
            if (canExecute()) {
                if (Script_Factory.isParallel(eventElem)) {
                    convertToParallel((Script_Parallel)eventElem);
                    createEffectorActions(invokeElem, scriptModel, objectsMap);
                }
                else {
                    //any event can have a sequence of actions to invoke, so parse these and add
                    createEffectorActions(eventElem, scriptModel, objectsMap);
                }
            }
            else {
                //parse next event to try and construct an executable info
                Script_Event nestedElem = eventElem.getEvents().get(0);
                AutoEngineInfo nestedInfo = new AutoEngineInfo(engine);
                isOK = nestedInfo.createInfo(nestedElem, scriptModel, objectsMap);
                
                if (isOK) {
                    nestedInfo.parent = this;
                    next = nestedInfo;
                }
            }
            
            return isOK;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "createInfo", null, ex);
        }
    }
    
    /** 
     * Convert to a parallel action if appropriate.
     * @param eventElem the parallel event element.
     */
    private void convertToParallel(Script_Parallel eventElem) throws Exception
    {
        int i;
        boolean firstOrBest;                    //first reply or best reply
        String serviceType;                     //current script evaluator
        String serviceAddress;                  //service address
        Element serviceUri;                     //service uri
        ArrayList<Element> sources;             //list of sources
        ArrayList<Script_Event> subEvents;      //sub-events
        Script_Target scriptTarget;             //script target
        Script_Event scriptEvent;               //script event
        ActionParallel actPar;                  //parallel action
        
        //script evaluator should be a service type
        firstOrBest = eventElem.firstOrBest();        
        subEvents = eventElem.getEvents();
        
        if (subEvents.isEmpty()) {
            //no specific sources so use service type
            serviceType = (String)evaluator;
            actPar = new ActionParallel(serviceType, this, firstOrBest);
        }
        else {
            scriptEvent = subEvents.get(0);
            if (scriptEvent instanceof Script_Invoke) {
                subEvents = scriptEvent.getEvents();
            }
            
            if (subEvents.isEmpty()) {
                //no specific sources so use service type
                serviceType = (String)evaluator;
                actPar = new ActionParallel(serviceType, this, firstOrBest);
            }
            else {
                //specific sources, so parse and use
                sources = new ArrayList<>();
                for (i = 0; i < subEvents.size(); i++)
                {
                    scriptTarget = (Script_Target)subEvents.get(i);
                    serviceAddress = scriptTarget.getLink();
                    serviceUri = XmlHandler.stringToElement(serviceAddress);
                    sources.add(serviceUri);
                }

                actPar = new ActionParallel(sources, this, firstOrBest);
            }
        }
        
        //evaluator can now be a parallel action
        evaluator = actPar;
    }
    
    /**
     * Check the script element for a username or password. Need to check each time a
     * new event is processed or executed. Then overwrites for current service.
     * @param scriptElem the script element.
     * @param objectsMap the hashmap to add the values to.
     */
    private void checkUsernamePassword(Script_Element scriptElem, ObjectsMap objectsMap) 
            throws Exception
    {
        Script_Source scriptSource;                     //script source
        
        if (scriptElem instanceof Script_Source) {
            scriptSource = (Script_Source)scriptElem;

            if (scriptSource.getUsername() != null) {
                objectsMap.put(MetaConst.USERNAME, scriptSource.getUsername());
            }
            if (scriptSource.getPassword() != null) {
                objectsMap.put(MetaConst.PASSWORD, scriptSource.getPassword());
            }
        }
    }
    
    /**
     * Parse the value related to the script element into a Java object.
     * @param scriptElem the element with the initial definition.
     * @param scriptModel the whole script model, with access to all element types.
     * @return the parsed object, or null if the operation is not possible.
     * @throws java.lang.Exception any error.
     */
    protected static Object parseToObject(Script_Element scriptElem, Script_Model scriptModel)
            throws Exception
    {
        String nextID;                                  //next id value
        String nextType;                                //variable type
        Object nextValue;                               //variable value
        Object javaObj;                                 //parsed object
        Script_Element indexElem;                       //next script element
        
        javaObj = null;
        if ((scriptElem != null) && !(scriptElem instanceof Script_VarMap)) {
            nextID = scriptElem.getObjType();
            nextValue = scriptElem.getValue();

            if ((nextID != null) && (nextValue != null)) {
                indexElem = scriptModel.getScriptWithID(nextID);

                if (indexElem != null) {
                    nextType = (String)indexElem.getValue();
                    javaObj = Parsers.parseObject(nextType, nextValue);
                }
                else if (nextID.equalsIgnoreCase(Const.OBJECT)) {
                    //try to create java object with empty constructor list
                    try {
                        Class.forName(ObjectHandler.toObjectClass(String.valueOf(nextValue)));
                        javaObj = LoadObject.loadObject(new ArrayList<>(), String.valueOf(nextValue), new ArrayList<>());
                    }
                    catch (Exception loex) {
                        //set to string cast of value, for possible replacement later
                        javaObj = String.valueOf(nextValue);
                    }
                }
                else if (TypeConst.isSimpleType(nextID)) {
                    //direct cast, probably a simple type
                    javaObj = Parsers.createObject(nextID, String.valueOf(nextValue));
                }
                else if (nextID.equalsIgnoreCase(TypeConst.ELEMENT)) {
                    //XML element so store as is
                    javaObj = (Element)nextValue;
                }
                else {
                    //try cast to string
                    javaObj = String.valueOf(nextValue);
                }
            }
            else if (nextValue != null) {
                //try to create java object with empty constructor list
                javaObj = LoadObject.loadObject(new ArrayList<>(), String.valueOf(nextValue),
                        new ArrayList<>());
            }
            else if (nextID != null) {
                //keep variable marker in case can re-place later
                javaObj = nextID;
            }
        }
        
        return javaObj;
    }
    
    /**
     * Create the list of effector actions.
     * @param eventElem the script element to start parsing from.
     * @param scriptModel the whole script model, with access to all element types.
     * @param objectsMap list of already created objects from script elements.
     * @throws java.lang.Exception any error.
     */
    private void createEffectorActions(Script_Element eventElem, Script_Model scriptModel, 
            ObjectsMap objectsMap) throws Exception
    {
        AutoEngineInfo autoInfo;                        //auto engine info
        Script_Event scriptEvent;                       //script element
        Script_Engine scriptEngine;                     //script engine
        
        try {
            effOutput = new AutoOut();

            if (eventElem != null) {
                scriptEngine = new Script_Engine();

                if (eventElem.usesSubEvents()) {
                    scriptEngine.resetValues(((Script_Event)eventElem).getEvents());
                }
                
                while (!scriptEngine.getIsFinished())
                {
                    scriptEvent = scriptEngine.nextProcessStep();
                    if (scriptEvent != null) {
                        autoInfo = new AutoEngineInfo(engine);
                        autoInfo.createInfo(scriptEvent, scriptModel, objectsMap);
                        effOutput.getEffectors().add(autoInfo);
                    }
                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "createEffectorActions", null, ex);
        }
    }
    
    /**
     * Return true if this info object can be executed.
     * @return true if method and evaluator exist, false otherwise.
     */
    public boolean canExecute()
    {
        boolean canExe;                 //true if can execute
        
        canExe = (!ObjectHandler.isNull(evaluator) && !ObjectHandler.isNull(senInput.method));
        if (!canExe && (next != null)) {
            canExe = next.canExecute();
        }
        
        return canExe;
    }
    
    /**
     * Get the method reply. This can be stored in a child element that is executed.
     * @return the method reply, can be nested if this is a control loop.
     */
    public Object getMethodReply()
    {
        if (senInput.output != null) {
            return senInput.output;
        }
        else if (next != null) {
            return next.getMethodReply();
        }
        
        return null;
    }
    
    /** 
     * Return true if an effector filter method list is added to this element.
     * @return true if effector list is added, false otherwise.
     */
    public boolean hasEffOutput()
    {
        boolean hasOutput;              //true if has effector output
        
        hasOutput = false;
        if (effOutput != null) {
            hasOutput = (effOutput.getEffectors().size() > 0);
        }
        
        return hasOutput;
    }
    
    /**
     * Get the saved effector actions list, as {@link AutoEngineInfo} objects.
     * @return the value of effOutput.
     */
    public AutoOut getEffOutput()
    {        
        return effOutput;
    }
    
    /**
     * Create and return a string-based description of this AutoInfo object.
     * @return a string-based description of this object.
     */
    public String toString()
    {
        int i;
        StringBuilder infoDescr;                    //info description
        AutoEngineInfo nextActionInfo;              //next action info
        
        infoDescr = new StringBuilder();
        try {
            infoDescr.append("Evaluator: ").append(ObjectHandler.getValue(evaluator)).append("\n");
        }
        catch (Exception ex) {}

        infoDescr.append("Condition: ").append(senInput.function).append("\n");

        if (senInput.method != null) {
            try {
                if (senInput.method instanceof Element)
                    infoDescr.append("Evaluation Method: ").append(XmlHandler.xmlToFormattedString((Element) senInput.method)).append("\n");
                else
                    infoDescr.append("Evaluation Method: ").append(senInput.method).append("\n");
            }
            catch (Exception ex) {
                infoDescr.append("Evaluation Method: did not parse.\n");
            }
        }
        else {
            infoDescr.append("Evaluation Method: null.\n");
        }
        
        if ((effOutput != null) && (effOutput.getEffectors() != null)) {
            infoDescr.append("Action list:\n");
            for (i = 0; i < effOutput.getEffectors().size(); i++)
            {
                nextActionInfo = effOutput.getEffectors().get(i);
                infoDescr.append(nextActionInfo.toString()).append("\n");
            }
        }
        else {
            infoDescr.append("Action list is empty.\n");
        }
        
        return infoDescr.toString();
    }
}
