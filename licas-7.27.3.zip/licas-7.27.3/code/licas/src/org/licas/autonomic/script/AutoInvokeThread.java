/*
 * AutoInvokeThread.java
 *
 * Created on 8 January 2018
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer.
 */

package org.licas.autonomic.script;


import org.licas.Service;
import org.licas.util.KeyValue;
import org.licas.util.exception.LicasException;

import java.util.ArrayList;


/**
 * This manages a script event by running it in a thread.
 * @author Kieran Greer
 */
public class AutoInvokeThread
{
    /** Create a new instance of AutoInvokeThread */
    public AutoInvokeThread()
    {}
    
    
    /**
     * Invoke the parallel method list and return the result.
     * @param autoInfo the process script elements parsed into their actual objects
     * and definitions.
     * @param paramList an external set of {@link KeyValue} objects that can replace
     * named or tagged fields in the method parameter lists. If empty or no match, then
     * nothing gets changed.
     * @param objectsMap mapping of variable names to instances. This method can ad more
     * variables, but should be for the method invocation only, so immediately cloned.
     * @param service the service to execute on.
     * @return the result of the evaluation. This is the {@code effectorList} of the
     * input parameter if the evaluation is true, or an empty list if it is false.
     * Evaluating to true can include matching exactly to an XML description, or just have
     * any result, for example, by using a {@code checkReply} method.
     * @throws LicasException for a licas-specific mapping problem.
     * @throws java.lang.Exception any error.
     */
    protected AutoOut run(AutoEngineInfo autoInfo, ArrayList paramList, ObjectsMap objectsMap,
            Service service) throws LicasException, Exception
    {
        AutoInvoke im;                        //invokes the method
        
        //parallel action determined inside the AutoInvoke
        im = new AutoInvoke(autoInfo, paramList, objectsMap, service);
        return im.invokeMethod();
    }
}
