/*
 * AutonomicManagerDefault.java
 *
 * Created on 25 January 2011
 *
 * Version 1.10.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.autonomic;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.Monitor;
import org.licas.Auto;
import org.licas.MessageInfo;
import org.licas.autonomic.script.AutoEngineInfo;
import org.licas.call.Handle;
import org.licas.parsers.admin.AutonomicManagerParser;
import org.licas.server.LocalServer;
import org.licas.util.*;
import org.licas.util.exception.LicasException;
import org.licas.util.exception.PasswordException;
import org.licas.util.exception.ServiceException;
import org.licas_xml.abs.Element;

import java.util.*;


/**
 * This class is a default implementation of an autonomic manager. It is a service wrapper 
 * that can also be used to manage an {@link Auto} service's data history. This default 
 * implementation does not implement any of the monitoring modules. It does however implement 
 * a message queueing system that can be used to control the messages that are submitted to 
 * the service (controlled element). The monitoring modules should extend the base {@link AM_Module} 
 * class and can be either to monitor, analyze, plan or execute.
 * Descriptions of the monitoring process can be found in related papers. These modules
 * should be added using the pre-defined default keyword names of either
 * {@link Const}.{@code MONITOR}, {@code ANALYZE}, {@code PLAN}, or {@code EXECUTE} 
 * to identify each one. The MAPE loop is synchronised, but any resulting action or 
 * effector list is not.
 * @author Kieran Greer
 */
public class AutonomicManagerDefault extends AutonomicManager
{
    /** The logger. */
    private static final Logger logger;
    

    /** To synchronize o */
    private final Object syncOn = new Object();


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(AutonomicManagerDefault.class.getName());
        logger.setDebug(false);
    }

    
    /** 
     * Creates a new instance of AutonomicManagerDefault.
     * @param theService the service to monitor.
     * @throws java.lang.Exception any error.
     */
    public AutonomicManagerDefault(Auto theService) throws Exception
    {
        super(theService);
        initialise(null);
    }
    
    /** 
     * Creates a new instance of AutonomicManagerDefault.
     * @param theService the service to monitor.
     * @param adminXml the admin document describing the auto manager.
     * @throws java.lang.Exception any error.
     */
    public AutonomicManagerDefault(Auto theService, Element adminXml) throws Exception
    {
        super(theService);
        initialise(adminXml);
    }

    /**
     * Initialise some values.
     * @param adminXml the admin document describing the auto manager.
     * @throws java.lang.Exception any error.
     */
    private void initialise(Element adminXml) throws Exception
    {
        AutonomicManagerParser autoManParser;       //autonomic manager parser

        //parse the admin document to load in any modules
        if (adminXml != null) {
            autoManParser = new AutonomicManagerParser();
            autoManParser.parse(this, adminXml);
        }
    }

    /**
     * This is the default method to start the service thread.
     * This default process periodically executes and evaluates a behaviour.
     */
    public void run()
    {
        try {
            while (!getShutDown())
            {
                try {
                    try {
                        if (!getShutDown()) {
                            if (service != null) {
                                if (messageQueue.queueSize() > 0) {
                                    ((Auto)service).autoAction(AiConst.ACTION, passwordHandler.getAdminKey());
                                }
                            }
                        }
                    }
                    catch (Exception ex1) {
                        ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "run", null, ex1);
                        setShutDown(true);
                    }
                    finally {
                        ThreadHandler.notifyEvents();
                        Thread.sleep(TimeConst.MILLISECOND);
                    }      
                } 
                catch (InterruptedException iex) {
                    setShutDown(true);
                } 
                catch (Exception ex2) {
                    ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "run", null, ex2);
                    setShutDown(true);
                }

                if (!getShutDown()) {
                    try {
                        setShutDown(LocalServer.getApi(getServerPassword()).getServerShutDown());
                    }
                    catch (Exception ex) {
                        setShutDown(true);
                    }
                }
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "run", null, ex);
        }
    }
    
    /**
     * Monitor a conversation message and add if a new conversation. The autonomous loops
     * can repeat a request to monitor something, and so this method does not throw an exception
     * if the comm ID is not new. It is up to the user to check the comm ID. If the communication
     * ID is {@code null} then the message is ignored and not checked.
     * @param theMessage the message that the service has produced / received.
     * @param theAdminKey the admin key for the parent service.
     * @throws PasswordException if the admin key is incorrect.
     * @throws LicasException if the communication ID is not part of a current conversation.
     * @throws java.lang.Exception any error.
     */
    public void monitor(MessageInfo theMessage, String theAdminKey) 
            throws PasswordException, LicasException, Exception
    {
        String serviceID;                   //the service id
        String commID;                      //communication id
        
        if (service != null) {
            serviceID = service.getUUID();
            if ((theMessage != null) && passwordHandler.getAdminKey().equals(theAdminKey)) {
                commID = theMessage.getCommID();
                if (commID != null) {
                    //add the communication id if new, but monitoring can repeat,
                    //so do not throw error if comm id already exists
                    checkCommID(commID, theMessage.getMessage(), NEWCONVERSATION);
                    monitorMessage(theMessage, theAdminKey);
                }
            }
            else {
                throw new PasswordException("The admin key is incorrect for service " + serviceID);
            }
        }
        else {
            throw new ServiceException("The Autonomic Manager does not wrap a service, service is null.");
        }
    }
    
    /**
     * Monitor a message using a MAPE control loop. This occurs after the message has been added
     * to the queue and retrieved for processing. In this case, the message must be recognised as
     * part of an existing conversation, from its comm ID. If the comm ID is {@code null}, then an
     * exception is thrown. If it new, then the message is added to a quarantine list and an exception
     * is thrown. The MAPE loop is synchronised, but any resulting action or effector list is not.
     * @param theMessage the message that the service has produced / received.
     * @param theAdminKey the admin key for the parent service.
     * @throws java.lang.Exception any error.
     */
    protected void monitorMessage(MessageInfo theMessage, String theAdminKey) 
            throws Exception
    {
        int i, j;
        boolean trueEvent;                                  //true if a true auto event
        String serviceID;                                   //the service id
        String commID;                                      //communication id
        String nextKey;                                     //next key
        ArrayList<String> monitorKeys;                      //monitor keys
        ArrayList<KeyValue> actionVars;                     //action/variables list
        ArrayList<KeyValue> paramList;                      //effector variable instances
        ArrayList<AutoEngineInfo> effectorList;             //effector list
        HashMap<String, ArrayList<KeyValue>> replyList;     //list of reply actions
        MessageInfo autoMessage;                            //clone as added to
        KeyValue keyValue;                                  //key-value pair
        AutoEngineInfo autoReply;                           //effector event
        Object reply;                                       //auto evaluation reply
        
        try {
            if (service != null) {
                serviceID = service.getUUID();
                if ((theMessage != null) && passwordHandler.getAdminKey().equals(theAdminKey)) {
                    synchronized (syncOn)
                    {
                        monitorKeys = new ArrayList<>();
                        monitorKeys.add(AiConst.MONITOR);
                        monitorKeys.add(AiConst.ANALYZE);
                        monitorKeys.add(AiConst.PLAN);
                        monitorKeys.add(AiConst.EXECUTE);
                        paramList = new ArrayList<>();
                        replyList = new HashMap<>();

                        commID = theMessage.getCommID();
                        if (commID != null) {
                            if (checkCommID(commID, theMessage.getMessage(), CONVERSATIONEXISTS)) {
                                //null reply means that no behaviour evaluation took place so ignore
                                autoMessage = (MessageInfo)theMessage.clone();

                                keyValue = new KeyValue();
                                keyValue.key = AiConst.MI_OBJECT;
                                keyValue.value = theMessage.getMessage();
                                paramList.add(keyValue);
                                keyValue = new KeyValue();
                                keyValue.key = AiConst.THIS;
                                keyValue.value = service;
                                paramList.add(keyValue);
                                keyValue = new KeyValue();
                                keyValue.key = Const.SERVERPASSWORD;
                                keyValue.value = passwordHandler.getServicePassword(Handle.createNewServerHandle(LocalServer.getServerURL()));
                                paramList.add(keyValue);
                                keyValue = new KeyValue();
                                keyValue.key = Const.SERVICEPASSWORD;
                                keyValue.value = passwordHandler.getPassword();
                                paramList.add(keyValue);
                                autoMessage.setMessage(paramList);

                                //create an action list for each module that is present
                                if (monitor != null) {
                                    replyList.put(AiConst.MONITOR, monitor.process(autoMessage));
                                    autoMessage = monitor.evaluationMessage();
                                }
                                if (analyzer != null) {
                                    replyList.put(AiConst.ANALYZE, analyzer.process(autoMessage));
                                    autoMessage = analyzer.evaluationMessage();
                                }
                                if (planner != null) {
                                    replyList.put(AiConst.PLAN, planner.process(autoMessage));
                                    autoMessage = planner.evaluationMessage();
                                }
                                if (executor != null) {
                                    replyList.put(AiConst.EXECUTE, executor.process(autoMessage));
                                    autoMessage = executor.evaluationMessage();
                                }
                            }
                            else {
                                quarantineQueue.addMessage(theMessage);
                                throw new ServiceException("Comm ID " + commID + " is not part of an existing conversation for service " + service.getUUID());
                            }
                        }
                        else {
                            throw new ServiceException("Autonomic Manager key cannot be created for conversation with service " + serviceID);
                        }
                    }

                    //if there is an action list for any of the module evaluations,
                    //then this default version will simply execute the actions in order
                    for (i = 0; i < monitorKeys.size(); i++) {
                        nextKey = monitorKeys.get(i);
                        if (replyList.containsKey(nextKey)) {
                            //auto engine reply so need to sort - evaluation result plus list of actions
                            effectorList = new ArrayList<>();
                            reply = null;

                            //get reply value and effector list - only use effector list here
                            actionVars = replyList.get(nextKey);
                            if ((actionVars != null) && !actionVars.isEmpty()) {
                                for (j = 0; j < actionVars.size(); j++)
                                {
                                    keyValue = actionVars.get(j);
                                    if (keyValue.key.equals(Const.REPLY)) {
                                        reply = keyValue.value;
                                    }
                                    else if (keyValue.key.equals(AiConst.EFFECTOR)) {
                                        effectorList = (ArrayList)keyValue.value;
                                    }
                                }
                            }

                            //true if output reply or new list of actions
                            trueEvent = ObjectHandler.valueIsTrue(reply);
                            if (trueEvent) {
                                //execute the effector methods in order
                                for (j = 0; j < effectorList.size(); j++)
                                {
                                    autoReply = effectorList.get(j);
                                    autoEngine.invokeMethod(autoReply, paramList);
                                }
                            }
                        }
                    }
                }
                else {
                    throw new PasswordException("The admin key is incorrect for service " + service.getUUID());
                }
            }
            else {
                throw new ServiceException("The Autonomic Manager does not wrap a service, service is null.");
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "monitorMessage", 
                    null, ex);
        }
    }
    
    /**
     * Add a new module to the manager - monitor, analyze, plan or execute.
     * @param moduleType the type of module. This is pre-defined and should be either
     * {@link Const}.{@code MONITOR}, {@code ANALYZE}, {@code PLAN}, or {@code EXECUTE}
     * to identify each particular module.
     * @param moduleClass the class name of the module to be loaded.
     * @param params initialisation parameters.
     * @param theJarUris uris from which the remote object can be loaded, only if needed.
     * @throws java.lang.Exception any error.
     */
    public void addManagerModule(String moduleType, String moduleClass,
                                 ArrayList<Object> params, ArrayList<String> theJarUris) throws Exception
    {
        if (!isConfigured) {
            params.add(service);
            params.add(passwordHandler);

            if (moduleType.equals(AiConst.MONITOR)) {
                if (moduleClass == null) moduleClass = AM_MonitorDefault.class.getName();
                monitor = (AM_Module)loadObject(theJarUris, moduleClass, params);
                monitor.setAutonomicManager(this);
            }
            else if (moduleType.equals(AiConst.ANALYZE)) {
                if (moduleClass == null) moduleClass = AM_AnalyzeDefault.class.getName();
                analyzer = (AM_Module)loadObject(theJarUris, moduleClass, params);
                analyzer.setAutonomicManager(this);
            }
            else if (moduleType.equals(AiConst.PLAN)) {
                if (moduleClass == null) moduleClass = AM_PlanDefault.class.getName();
                planner = (AM_Module)loadObject(theJarUris, moduleClass, params);
                planner.setAutonomicManager(this);
            }
            else if (moduleType.equals(AiConst.EXECUTE)) {
                if (moduleClass == null) moduleClass = AM_ExecuteDefault.class.getName();
                executor = (AM_Module)loadObject(theJarUris, moduleClass, params);
                executor.setAutonomicManager(this);
            }
        }
    }

    /**
     * Add a new policy to the auto manager.
     * @param policyType the type of policy.
     * To add to a monitoring module, use one of the pre-defined keywords -
     * {@link Const}.{@code MONITOR}, {@code ANALYZE}, {@code PLAN}, or {@code EXECUTE}.
     * @param document the policy document.
     * @throws java.lang.Exception any error.
     */
    public void addPolicy(String policyType, Element document) throws Exception
    {
        if (!isConfigured) {
            switch (policyType) {
                case AiConst.MONITOR:
                    monitor.setPolicy(document);
                    break;
                case AiConst.ANALYZE:
                    analyzer.setPolicy(document);
                    break;
                case AiConst.PLAN:
                    planner.setPolicy(document);
                    break;
                case AiConst.EXECUTE:
                    executor.setPolicy(document);
                    break;
            }
        }
    }
}
