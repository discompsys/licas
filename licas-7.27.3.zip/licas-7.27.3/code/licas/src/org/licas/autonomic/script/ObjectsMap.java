/*
 * ObjectsMap.java
 *
 * Created on 17 March 2018
 *
 * Version 1.2.2
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.autonomic.script;


import org.licas.PasswordHandler;
import org.licas.call.Handle;
import org.licas.call.ParamInfo;
import org.licas.query.LicasQueryConst;
import org.licas.server.LocalServer;
import org.licas.util.AiConst;
import org.licas.util.Const;
import org.licas.util.KeyValue;
import org.licas.util.ObjectHandler;
import org.licas_xml.abs.Element;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * Stores mapping and functions from object keys to instances.
 * @author Kieran Greer
 */
public class ObjectsMap
{
    /** The mapped objects */
    protected HashMap<Object, Object> objectsMap;
    
    /**
     * Create a new instance of ObjectsMap.
     */
    public ObjectsMap()
    {
        objectsMap = new HashMap<>();
    }
    
    /**
     * Remove any key-value pairs that use the known variable key name and add to the
     * list of mapped objects.
     * @param paramList the list of input parameters from the input message info object.
     */
    public void varsToMap(ArrayList<Object> paramList)
    {
        int i;
        String nextKey;                             //next key
        KeyValue keyValue;                          //next key-value pair
        ParamInfo paramInfo;                        //next param info
        Object nextValue;                           //next value
        
        if (paramList != null) {
            for (i = 0; i < paramList.size(); i++)
            {
                nextValue = paramList.get(i);

                if (nextValue instanceof KeyValue) {
                    keyValue = (KeyValue)nextValue;
                    nextKey = keyValue.key;

                    if (!ObjectHandler.isNull(keyValue.value)) {
                        objectsMap.put(nextKey, keyValue.value);
                    }
                }
                else if (nextValue instanceof ParamInfo) {
                    paramInfo = (ParamInfo)nextValue;
                    nextKey = paramInfo.getName();

                    if (!ObjectHandler.isNull(paramInfo.getValue())) {
                        objectsMap.put(nextKey, paramInfo.getValue());
                    }
                }
            }
        }
    }
    
        /**
     * Replace any {@code null} values in the parameter list with values in the map 
     * if they exist.
     * @param paramList the list of input parameters from the input message info object.
     */
    public void mapToVars(ArrayList<?> paramList)
    {
        int i;
        String nextKey;                             //next key
        KeyValue keyValue;                          //next key-value pair
        ParamInfo paramInfo;                        //next param info
        Object nextValue;                           //next value
        
        if (paramList != null) {
            for (i = 0; i < paramList.size(); i++)
            {
                nextValue = paramList.get(i);

                if (nextValue instanceof KeyValue) {
                    keyValue = (KeyValue)nextValue;
                    nextKey = keyValue.key;

                    if (objectsMap.containsKey(nextKey) && (keyValue.value == null)) {
                        keyValue.value = objectsMap.get(nextKey);
                    }
                }
                else if (nextValue instanceof ParamInfo) {
                    paramInfo = (ParamInfo)nextValue;
                    nextKey = paramInfo.getName();

                    if (objectsMap.containsKey(nextKey) && (paramInfo.getValue() == null)) {
                        paramInfo.setValue(objectsMap.get(nextKey));
                    }
                }
            }
        }
    }
    
    /**
     * Replace any {@code null} values in the parameter list with values in the map 
     * if they exist. This is a specific mapping from the event itself.
     * @param paramList the list of input parameters from the input message info object.
     * @param eventVars list of key-value pairs from the event method itself.
     */
    public void mapToParams(ArrayList<ParamInfo> paramList, HashMap<String, String> eventVars)
    {
        int i;
        String nextKey;                             //next key
        ParamInfo paramInfo;                        //next param info
        
        if (paramList != null) {
            for (i = 0; i < paramList.size(); i++)
            {
                paramInfo = paramList.get(i);
                nextKey = paramInfo.getName();

                if (eventVars.containsKey(nextKey)) {
                    nextKey = eventVars.get(nextKey);

                    if (objectsMap.containsKey(nextKey)) {
                        paramInfo.setValue(objectsMap.get(nextKey));
                    }
                }
            }
        }
    }
    
    /**
     * Determine the passwords for both the local server and the service in question.
     * The {@code passwordHandler} is tried first. If the password is missing, then the mapped
     * lit is tried.
     * @param serviceID the service uuid.
     * @param passwordHandler list of passwords stored for the parent engine and service.
     * @return the two passwords: server-service, where null means it is missing.
     */
    protected String[] getPasswords(String serviceID, PasswordHandler passwordHandler)
    {
        String[] passwords;                 //server and service passwords
        Element serviceUri;                 //full service uri
        
        passwords = new String[2];
        passwords[0] = null;
        passwords[1] = null;
        
        try {
            serviceUri = LocalServer.getServerHandle();
            if (passwordHandler.hasServicePassword(serviceUri)) {
                passwords[0] = passwordHandler.getServicePassword(serviceUri);
            }
            else if (objectsMap.containsKey(Const.SERVERPASSWORD)) {
                passwords[0] = (String)objectsMap.get(Const.SERVERPASSWORD);
            }                   
        }
        catch (Exception ex) {}
        
        try {
            serviceUri = Handle.createNewUrlHandle(LocalServer.getServerURL());
            serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceID));
            
            if (passwordHandler.hasServicePassword(serviceUri)) {
                passwords[1] = passwordHandler.getServicePassword(serviceUri);
            }
            else if (objectsMap.containsKey(Const.SERVICEPASSWORD)) {
                passwords[1] = (String)objectsMap.get(Const.SERVICEPASSWORD);
            }
        }
        catch (Exception ex) {}
        
        return passwords;
    }
    
    /**
     * Determine the passwords for both the local server and the service in question.
     * The {@code passwordHandler} is tried first. If the password is missing, then the mapped
     * lit is tried.
     * @param servicePath full uri path description for the service.
     * @param passwordHandler list of passwords stored for the parent engine and service.
     * @return the two passwords: server-service, where null means it is missing.
     */
    protected String[] getPasswords(Element servicePath, PasswordHandler passwordHandler)
    {
        String[] passwords;                 //server and service passwords
        Element serviceUri;                 //full service uri
        
        passwords = new String[2];
        passwords[0] = null;
        passwords[1] = null;
        
        try {
            serviceUri = Handle.createNewServerHandle(Handle.getURL(servicePath));
            if (passwordHandler.hasServicePassword(serviceUri)) {
                passwords[0] = passwordHandler.getServicePassword(serviceUri);
            }
            else if (objectsMap.containsKey(Const.SERVERPASSWORD)) {
                passwords[0] = (String)objectsMap.get(Const.SERVERPASSWORD);
            }                   
        }
        catch (Exception ex) {}
        
        try {
            serviceUri = servicePath;
            if (passwordHandler.hasServicePassword(serviceUri)) {
                passwords[1] = passwordHandler.getServicePassword(serviceUri);
            }
            else if (objectsMap.containsKey(Const.SERVICEPASSWORD)) {
                passwords[1] = (String)objectsMap.get(Const.SERVICEPASSWORD);
            }
        }
        catch (Exception ex) {}
        
        return passwords;
    }
    
    /**
     * Set the list of mapped objects.
     * @param theObjectsMap key-value pairs.
     */
    public void setObjectsMap(HashMap<Object, Object> theObjectsMap)
    {
        objectsMap = theObjectsMap;
    }
    
    /**
     * Get the list of mapped objects.
     * @return the value of objectMaps.
     */
    public HashMap<Object, Object> getObjectsMap()
    {
        return objectsMap;
    }
    
    /**
     * Clear the mapped list.
     */
    public void clear()
    {
        objectsMap.clear();
    }
    
    /**
     * Return true if the objects list contains the specified key.
     * @param key the key value.
     * @return true if list contains the key value.
     */
    public boolean containsKey(Object key)
    {
        return objectsMap.containsKey(key);
    }
    
    /**
     * Ann an object to the map list.
     * @param key object key value.
     * @param value object value.
     */
    public void put(Object key, Object value)
    {
        objectsMap.put(key, value);
    }
    
    /**
     * Get a value from the mapped list.
     * @param key object key value.
     * @return object value.
     */
    public Object get(Object key)
    {
        return objectsMap.get(key);
    }
    
    /**
     * Return true if the keyword is a known mapping to a variable.
     * @param keyWord the keyword.
     * @return true if maps to a known variable type.
     */
    protected boolean isVariableKey(String keyWord)
    {
        return (keyWord.equalsIgnoreCase(AiConst.THIS) ||
                keyWord.equalsIgnoreCase(Const.SERVERPASSWORD) ||
                keyWord.equalsIgnoreCase(Const.SERVICEPASSWORD) ||
                keyWord.equalsIgnoreCase(AiConst.EFFECTOR) ||
                keyWord.equalsIgnoreCase(Const.REPLY) ||
                keyWord.equalsIgnoreCase(LicasQueryConst.QUERYMODEL) ||
                keyWord.equalsIgnoreCase(LicasQueryConst.QUERYREPLY) ||
                keyWord.equalsIgnoreCase(Const.METHOD) ||
                keyWord.equalsIgnoreCase(AiConst.MI_OBJECT));
    }
    
    /**
     * Create a clone of this object.
     * @return a light clone of this object.
     */
    public Object clone()
    {
        ObjectsMap newMap;
        
        newMap = new ObjectsMap();
        newMap.setObjectsMap((HashMap)objectsMap.clone());
        
        return newMap;
    }
}
