/*
 * AutonomicManager.java
 *
 * Created on 26 January 2011
 *
 * Version 1.8.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.autonomic;


import org.licas.*;
import org.licas.autonomic.script.AutoEngine;
import org.licas.meta.MetaFactory;
import org.licas.util.exception.LicasException;
import org.licas.util.exception.PasswordException;
import org.licas.util.exception.ServiceException;
import org.licas_xml.abs.Element;

import java.util.ArrayList;


/**
 * This is the abstract base class that should be extended to implement an autonomic manager.
 * The autonomic manager can be used to allow a service to autonomously (or independently)
 * monitor itself, with regard to errors in its interaction with its environment. This base class
 * defines the methods that can be used to implement an autonomic manager with a self-control
 * loop and a message queue. The modules that process the information then implement
 * the {@link AM_Module} interface. In this case, separate modules should be
 * implemented to monitor, analyze, plan, or execute the plan, based on the input that
 * each module receives. Each module should be controlled by a policy that
 * can be entered as an XML document. On receiving its input, the module
 * will process the information based on the policy and return a {@link MessageInfo} object
 * with the appropriate reply. If all of the modules implement this interface then 
 * this process will be consistent through the whole control loop.
 * @author Kieran Greer
 */
public abstract class AutonomicManager extends ServiceWrapper
{
    protected static boolean NEWCONVERSATION = true;
    protected static boolean CONVERSATIONEXISTS = false;
    
    /** Monitor module. */
    protected AM_Module monitor;

    /** Analysis module. */
    protected AM_Module analyzer;

    /** Planner module. */
    protected AM_Module planner;

    /** Execution module. */
    protected AM_Module executor;
    
    /** List of messages received by this manager. */
    protected MessageQueue messageQueue;
    
    /** List of messages quarantined by this manager. */
    protected MessageQueue quarantineQueue;
    
    /* To interpret and execute the policy script. */
    protected AutoEngine autoEngine;
    
    /** Set to true when this manager has been configured. */
    protected boolean isConfigured;
   

    /**
     * Creates a new instance of AutonomicManager.
     * @param theService the service to monitor.
     * @throws java.lang.Exception any error.
     */
    public AutonomicManager(Auto theService) throws Exception
    {
        super(theService);
        initialise();
    }

    /** Initialise some values. */
    private void initialise()
    {
        isConfigured = false;
        autoEngine = new AutoEngine(service, passwordHandler);
        
        messageQueue = new MessageQueue();
        quarantineQueue = new MessageQueue();
        monitor = null;
        analyzer = null;
        planner = null;
        executor = null;
    }
    
    /**
     * Monitor the first message of a conversation to check for irregular values. 
     * The message must not be recognised locally with a stored comm id.
     * @param theMessage the message that the service has produced / received.
     * @param theAdminKey the admin key for the parent service.
     * @throws PasswordException if the admin key is incorrect.
     * @throws LicasException if the communication ID is not part of a current conversation.
     * @throws java.lang.Exception any error.
     */
    public abstract void monitor(MessageInfo theMessage, String theAdminKey) 
            throws PasswordException, LicasException, Exception;
    
    /**
     * Monitor a message using a MAPE control loop. This occurs after the message has been added
     * to the queue and retrieved for processing. In this case, the message must be recognised as
     * part of an existing conversation, from its comm ID.
     * @param theMessage the message that the service has produced / received.
     * @param theAdminKey the admin key for the parent service.
     * @throws PasswordException if the admin key is incorrect.
     * @throws LicasException if the communication ID is not part of a current conversation.
     * @throws java.lang.Exception any error.
     */
    protected abstract void monitorMessage(MessageInfo theMessage, String theAdminKey) 
            throws PasswordException, LicasException, Exception;
    
    /**
     * Add a new module to the manager - monitor, analyze, plan or execute.
     * @param moduleType the type of module.
     * @param moduleClass the class name of the module to be loaded.
     * @param params initialisation parameters.
     * @param theJarUris uris from which the remote object can be loaded, only if needed.
     * @throws java.lang.Exception any error.
     */
    public abstract void addManagerModule(String moduleType, String moduleClass, ArrayList<Object> params,
            ArrayList<String> theJarUris) throws Exception;

    /**
     * Add a new policy to the auto manager.
     * @param policyType the type of policy.
     * @param document the policy document.
     * @throws java.lang.Exception any error.
     */
    public abstract void addPolicy(String policyType, Element document) throws Exception;

    /**
     * Return true if the stored object is derived from the licas {@link Service} object.
     * @return true in this case.
     */
    public boolean isService()
    {
        return true;
    }

    /**
     * Return true if the stored object is derived from the licas {@link Auto} object.
     * @return true in this case.
     */
    public boolean isAuto()
    {
        return true;
    }

    /**
     * Return true if the stored object is legacy code, false if a licas service.
     * @return false here.
     */
    public boolean storesLegacy()
    {
        return false;
    }

    /**
     * Add a message to the queue for a particular communication thread. In this case,
     * the message must be recognised as part of an existing conversation, from its comm ID.
     * If the comm ID is {@code null}, then an exception is thrown. If it new, then the
     * message is added to a quarantine list and an exception is thrown.
     * @param messageInfo the message to add.
     * @param theAdminKey the admin key for the parent service.
     * @throws PasswordException if the admin key is incorrect.
     * @throws LicasException if the comm ID is not already stored, as it is then
     * not part of a conversation.
     * @throws java.lang.Exception any error.
     */
    public void addMessage(MessageInfo messageInfo, String theAdminKey) 
            throws PasswordException, LicasException, Exception
    {
        String serviceID;                   //the service id
        String commID;                      //communication id
        
        if (service != null) {
            serviceID = service.getUUID();

            if (passwordHandler.getAdminKey().equals(theAdminKey)) {
                commID = messageInfo.getCommID();

                if (commID != null) {
                    if (checkCommID(commID, messageInfo.getMessage(), CONVERSATIONEXISTS)) {
                        messageQueue.addMessage(messageInfo);
                        monitorMessage(messageInfo, theAdminKey);
                    }
                    else {
                        quarantineQueue.addMessage(messageInfo);
                        throw new ServiceException("Comm ID " + commID + " is not part of an existing conversation for service " + serviceID);
                    }
                }
                else {
                    throw new ServiceException("Autonomic Manager key cannot be created for conversation with service " + serviceID);
                }
            }
            else {
                throw new PasswordException("The admin key is incorrect for service " + serviceID);
            }
        }
        else {
            throw new ServiceException("The Autonomic Manager does not wrap a service, service is null.");
        }
    }
    
    /**
     * Get the next message in the queue.
     * @param theAdminKey the admin key for the parent service.
     * @param remove if true also remove the message.
     * @return the first message in the queue.
     */
    public MessageInfo getNextMessage(String theAdminKey, boolean remove)
    {
        if (passwordHandler.getAdminKey().equals(theAdminKey)) {
            if (remove) return messageQueue.getAndRemoveNextMessage();
            else return messageQueue.getNextMessage();
        }
        
        return null;
    }
    
    /**
     * Return the message to the start of the message queue
     * and update all other message lists.
     * @param nextMessage the message to add again.
     * @param theAdminKey the service's service key.
     */
    public void returnLastMessage(String theAdminKey, MessageInfo nextMessage)
    {
        if (passwordHandler.getAdminKey().equals(theAdminKey)) {
            messageQueue.returnLastMessage(nextMessage);
        }
    }

    /**
     * Get the message queue.
     * @param theAdminKey the admin key for the parent service.
     * @return the message queue for the service of this manager.
     */
    public MessageQueue getMessageQueue(String theAdminKey)
    {
        if (passwordHandler.getAdminKey().equals(theAdminKey)) {
            return messageQueue;
        }

        return null;
    }
    
    /**
     * Get the quarantined message queue.
     * @param theAdminKey the admin key for the parent service.
     * @return the quarantined message queue for the service of this manager.
     */
    public MessageQueue getQuarantineMessageQueue(String theAdminKey)
    {
        if (passwordHandler.getAdminKey().equals(theAdminKey)) {
            return messageQueue;
        }

        return null;
    }

    /**
     * Get the client URI associated with a communication ID.
     * @param communicationID the communication ID.
     * @return the clientURI stored in the messageinfo object.
     */
    protected Object getClientURI(String communicationID)
    {
        return ServiceComm.getClientURI(communicationID, service);
    }

    /**
     * Remove the communication ID reference from the Service, or stored {@code obj} reference.
     * @param communicationID the communication ID.
     */
    protected void removeCommID(String communicationID)
    {
        ServiceComm.removeCommunicationID(communicationID, service);
    }
    
    /**
     * Check if the communication ID can be added as new, or if it already exists.
     * The {@code tryNew} parameter sets the condition with the following rules:<br>
     * 1. If true then try to add the conversation key as new and throw an exception if
     * it already exists.<br>
     * 2. If false then check that the conversation key is part of an existing conversation
     * and throw an exception if it is new.<br>
     * 3. The exception to this is a general 'service-level' ID that ends with {@code Service}
     * or {@code Fault} and is allowed for any case.
     * @param commID the communication ID to check.
     * @param clientURI the client URI representation.
     * @param tryNew true if check for new entry,  or false for an existing conversation.
     * @return true if condition is OK, false otherwise.
     * @throws java.lang.Exception any error.
     */
    protected boolean checkCommID(String commID, Object clientURI, boolean tryNew) throws Exception
    {
        boolean isOK = false;                       //true if OK

        if (tryNew) {
            if (!ServiceComm.hasCommunicationID(commID, service)) {
                isOK = ServiceComm.addCommunicationID(commID, clientURI, service);
            }
        }
        else {
            isOK = ServiceComm.hasCommunicationID(commID, service);
            if (isOK) {
                isOK = ServiceComm.hasCommunicationID(commID, service);
            }
        }
        
        //if not stored or new, check if general service-level comm id
        if (!isOK) {
            isOK = (MetaFactory.getFactoryService().isServiceComm(commID) ||
                    MetaFactory.getFactoryService().isFaultComm(commID));
        }

        return isOK;
    }
    
    /** Call to indicate that the manager has now been configured */
    public void setConfigured()
    {
        isConfigured = true;
    }
    
    /**
     * This method is re-implemented here to allow the thread to be shut down.
     */
    public void interrupt()
    { 
        try {
            setShutDown(true);
            if (!isInterrupted()) super.interrupt();
        } 
        catch (Exception ex) {}
    }
}
