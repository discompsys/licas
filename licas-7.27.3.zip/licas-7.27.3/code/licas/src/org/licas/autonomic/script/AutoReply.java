/*
 * AutoReply.java
 *
 * Created on 17 March 2018
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer.
 */

package org.licas.autonomic.script;


import org.ai_heuristic.eval.Condition;
import org.licas.util.ObjectHandler;
import org.licas_text.query.QueryMediator;
import org.licas_text.util.MetaConst;
import org.licas_xml.abs.Element;


/**
 * This class can evaluate a reply object for a true-false response, or success-failure,
 * with regard to using it further in the process.
 * @author Kieran Greer
 */
public class AutoReply
{
    /** An object returned by some evaluation */
    private final Object reply;
    
    /**
     * Create a new instance of AutoReply.
     * @param theReply the reply object to evaluate.
     */
    public AutoReply(Object theReply)
    {
        reply = theReply;
    }
    
    /**
     * Check the reply based on any filter query or function, which can be a simple description, such as
     * the default set programmed into the licas script. The following checks are made:
     * <p>
     * 1. If filter and function are {@code null}, then return true. If either are not null,
     * then try to evaluate that.<br>
     * 2. If filter is an Element, then try a metadata {@code structure} match.<br>
     * 3. If filter is Boolean, then try a true/false match, as for the function.<br>
     * 4. If filter is any other Object, try an {@code Object.Equals} with the reply.
     * 5. If function can be cast to a Boolean, then:<br>
     * 5.1 If true, a {@code not null} reply is true, otherwise it is false.<br>
     * 5.2 If false, a {@code null} reply is true, otherwise it is false.<br>
     * 6 Otherwise compare the function condition with the result object for true result.<br>
     * @param filter to filter the method result first, with a matching query or other.
     * @param function a function on the filtered result to satisfy, typically true.
     * @param objectsMap mapping of variable keys to instance value.
     * @return if true, then reply is not null, if false, then reply is null.
     * @throws java.lang.Exception any error.
     */
    protected boolean evaluate(Object filter, Condition function, ObjectsMap objectsMap) throws Exception
    {
        boolean replyOK;                        //true if the reply is OK
        boolean boolCond;                       //boolean function
        float matchType;                        //matching type
        
        replyOK = true;
        if ((filter != null) || (function != null))
        {
            //evaluate the method reply
            if (filter != null) 
            {
                //first retrieve value if a variable ID
                if (objectsMap.containsKey(filter))
                {
                    filter = objectsMap.get(filter);
                }

                if (ObjectHandler.isString(filter))
                {
                    try
                    {
                        boolCond = Boolean.parseBoolean((String)filter);
                        if (boolCond) 
                        {
                            replyOK = !ObjectHandler.isNull(reply);
                        }
                        else 
                        {
                            replyOK = ObjectHandler.isNull(reply);
                        }
                    }
                    catch (Exception ex)
                    {
                        if (!ObjectHandler.isNull(reply))
                        {
                            replyOK = String.valueOf(filter).equals(String.valueOf(reply));
                        }
                    }
                }
                else if (!ObjectHandler.isNull(reply))
                {
                    if ((filter instanceof Element) && (reply instanceof Element))
                    {
                        matchType = QueryMediator.compareMetadata((Element)filter, 
                                (Element)reply, MetaConst.ALLEXACT);

                        replyOK = (matchType == 1.0);
                    }
                    else
                    {
                        replyOK = filter.equals(reply);
                    }
                }
            }
            
            //function evaluation on the result
            if (replyOK && (function != null))
            {
                try
                {
                    replyOK = function.compareWith(reply);
                }
                catch (Exception ex)
                {
                    replyOK = false;
                }
            }
        }
        
        return replyOK;
    }
}
