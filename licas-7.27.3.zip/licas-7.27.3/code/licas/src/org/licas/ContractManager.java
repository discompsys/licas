/*
 * ContractManager.java
 *
 * Created on 28 January 2011
 *
 * Version 1.1.4
 *
 * Copyright (c) 2011 Kieran Greer
 */

package org.licas;


import org.licas.server.LocalServer;
import org.licas.service.model.Contract;
import org.licas.util.Const;
import org.licas.util.FileObject;
import org.licas.util.MetaConst;
import org.licas.util.classloader.LoadObject;
import org.licas.util.exception.ServiceException;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;


/**
 * This class can be used to store and process service level agreements, or
 * contracts between a client and a service. This implementation is a basic 
 * default version that simply tries to find the appropriate service level agreement 
 * object and asks it to evaluate the contract proposal that is passed in.
 * You can derive your own contract handler from this class and implement
 * the methods in any way you want your contracts to be processed. The contract
 * manager essentially has to agree to release or send the correct password, after
 * which the service's related methods are open to be invoked.
 * @author Kieran Greer
 */
public class ContractManager
{
    /**
     * Stores the service level agreements.
     * Key is the service level and value if of type {@link ServiceLevel}.
     */
    protected HashMap<String, ServiceLevel> serviceLevelAgreements;

    /**
     * Create a new instance of ContractManager.
     * @param document the service level agreements document to parse to
     * create the service level agreements.
     * @throws java.lang.Exception any error.
     */
    public ContractManager(Element document) throws Exception
    {
        initialise(document);
    }

    /**
     * Initialise some values.
     * @param document the service level agreements document to parse.
     * @throws java.lang.Exception any error.
     */
    private void initialise(Element document) throws Exception
    {
        serviceLevelAgreements = new HashMap<>();
        parseServiceContracts(document);
    }

    /**
     * Parse the admin or service level agreements document to store the
     * contract details for each service level.
     * This default implementation does nothing.
     * You need to implement your own functionality in any derived class.
     * @param document an XML-based document that stores the relevant details.
     * @throws java.lang.Exception any error.
     */
    public void parseServiceContracts(Element document) throws Exception
    {
        int i;
        String serviceLevel;                        //service level
        String className;                           //module class name
        String jarFile;                             //module jar file
        ArrayList<String> jarFiles;                 //all jar files
        ArrayList<Object> params;                   //parameters
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Vector<Node> elemList;                      //list of elements
        Contract theContract;                       //the contract
        ServiceLevel sla;                           //the service level agreement

        if (document != null)
        {
            className = null;
            jarFiles = new ArrayList<>();

            elemList = (Vector)document.getChildren().clone();            
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (nextElem.getName().equals(Const.CLASSNAME)) {
                        className = nextElem.getText();
                    }
                    else if (nextElem.getName().equals(Const.JARFILEXML)) {
                        jarFile = nextElem.getText();
                        jarFiles = FileObject.getAllJarFilePaths(jarFile, LocalServer.getServerURL());
                    }
                    else if (nextElem.getName().equals(MetaConst.SERVICELEVELCONTRACT)) {
                        //only add new sla if neither of the two default types are present
                        if (!contractDefaultYes() && !contractDefaultNo())
                        {
                            theContract = new Contract((Element)nextElem.clone());
                            serviceLevel = Contract.getElementValue(MetaConst.SERVICELEVEL, theContract);                        
                            if (serviceLevel != null)
                            {
                                if (className != null) {
                                    params = new ArrayList<>();
                                    params.add(serviceLevel);
                                    params.add(this);
                                    params.add(nextElem.detach());

                                    sla = (ServiceLevel)LoadObject.loadObject(jarFiles, className, params);
                                }
                                else {
                                    sla = new ServiceLevel(serviceLevel, this, theContract);
                                }

                                if (Contract.isYesContract(theContract) || Contract.isNoContract(theContract))
                                    serviceLevelAgreements.clear();
                                
                                serviceLevelAgreements.put(serviceLevel, sla);
                            }
                            else
                            {
                                throw new ServiceException("Error: Service Level admin document missing service levels. Please check this.");
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Parse the negotiation contract to determine if it is OK. If this service
     * does not have any contracts installed, then a default value of true is 
     * returned, no matter what the contract parameter contains. This service
     * however can have a default 'yes' or 'no' contract installed, that will
     * again override any negotiation contract that is passed in.
     * @param theContract a wrapper for an XML-based document that stores the 
     * contract proposal as an arbitrary description. It must however contain
     * certain standard elements, such as the service level, relating to the
     * service level agreement licas contract that it wants to satisfy. This parameter
     * can also be set to null, to check if the service has a default 'yes' or 'no'
     * agreement contract installed.
     * @return true if the reply is OK, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean contractIsOK(Contract theContract) throws Exception
    {
        boolean contractOK;                         //true if the contract is OK
        String serviceLevel;                        //the service level
        ServiceLevel sla;                           //service level agreement

        contractOK = serviceLevelAgreements.isEmpty();
        if (!contractOK)
        {
            contractOK = !contractDefaultNo();
            if (contractOK)
            {
                contractOK = contractDefaultYes();
                if (!contractOK)
                {
                    if (theContract != null)
                    {
                        serviceLevel = Contract.getElementValue(MetaConst.SERVICELEVEL, theContract);
                        if (serviceLevel != null)
                        {
                            if (serviceLevelAgreements.containsKey(serviceLevel))
                            {
                                sla = serviceLevelAgreements.get(serviceLevel);
                                contractOK = sla.contractIsOK(theContract);
                            }
                        }
                    }
                }
            }
        }

        return contractOK;
    }
    
    /**
     * Determines if the contract is OK by default.
     * @return true if always OK, false otherwise.
     */
    private boolean contractDefaultYes()
    {
        int i;
        boolean contractOK;                         //true if the contract is OK
        ArrayList<ServiceLevel> serviceLevels;      //all service levels
        ServiceLevel serviceLevel;                  //service level
        
        contractOK = false;
        if (!serviceLevelAgreements.isEmpty())
        {
            //should be only one entry, but can check all entries
            serviceLevels = new ArrayList(serviceLevelAgreements.values());
            for (i = 0; !contractOK && (i < serviceLevels.size()); i++) {
                serviceLevel = serviceLevels.get(i);
                contractOK = Contract.isYesContract(serviceLevel.contract);
            }
        }
        
        return contractOK;
    }
    
    /**
     * Determines if the contract is not OK by default.
     * @return true if always not OK, false otherwise.
     */
    private boolean contractDefaultNo()
    {
        int i;
        boolean contractOK;                         //true if the contract is OK
        ArrayList<ServiceLevel> serviceLevels;      //all service levels
        ServiceLevel serviceLevel;                  //service level
        
        contractOK = false;
        if (!serviceLevelAgreements.isEmpty())
        {
            //should be only one entry, but can check all entries
            serviceLevels = new ArrayList(serviceLevelAgreements.values());
            for (i = 0; !contractOK && (i < serviceLevels.size()); i++) {
                serviceLevel = serviceLevels.get(i);
                contractOK = Contract.isNoContract(serviceLevel.contract);
            }
        }
        
        return contractOK;
    }

    /**
     * Process the specified contract to determine if it meets the requirements
     * for the service level. This is the contract proposed by the client.
     * @param clientID the id of the client making the request.
     * @param theContract the client contract.
     * @return the reply from the service, indicating if the contract is acceptable or not.
     * @throws java.lang.Exception any error.
     */
    public Contract processClientContract(String clientID, Contract theContract)
            throws Exception
    {
        String serviceLevel;                        //the service level
        Contract contractReply;                     //contract reply
        ServiceLevel sla;                           //service level agreement
        
        contractReply = null;
        serviceLevel = Contract.getElementValue(MetaConst.SERVICELEVEL, theContract);
        if (serviceLevel != null)
        {
            if (serviceLevelAgreements.containsKey(serviceLevel)) {
                sla = serviceLevelAgreements.get(serviceLevel);
                contractReply = sla.contractReply(clientID, theContract);
            }
        }
        
        return contractReply;
    }
}
