/*
 * LicasWsFactory.java
 *
 * Created on 4 May 2016.
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws;


import org.licas.call.MethodInfo;
import org.licas.ws.soap.Soap_BaseHandler;
import org.licas.ws.soap.Soap_MethodHandler;
import org.licas.ws.wsdl.model.*;
import org.licas.ws.wsdl.parse.WsdlParser;
import org.licas.util.Const;
import javax.xml.soap.SOAPMessage;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.util.*;


/**
 * Factory object for web services.
 * @author Kieran Greer
 */
public class LicasWsFactory extends WsFactory
{
    /** For logging */
    private static Logger logger;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(LicasWsFactory.class.getName());
        logger.setDebug(false);
    }
    
    
    public void LicasWsFactory()
    {}
    
    
    /**
     * Create and return a method info object for invoking a web service using the SOAP protocol.
     * @param operationName the name of the operation to call.
     * @param setRtn true if set the return Object type.
     * @param paramValues if true add the parameter values as {@code WsdlParamInfo} objects.
     * @param lWsdlModel the wsdl model that stores the description.
     * @return a web service info object with the appropriate values.
     * @throws java.lang.Exception any error.
     */
    public WsMethodInfo createSoapCall(String operationName, boolean setRtn,
        boolean paramValues, LicasWsdlModel lWsdlModel) throws Exception
    {
        boolean opFound;                            //true if the operaiton has been found
        String nextKey;                             //next key
        String nextKey2;                            //next key
        String nextPort;                            //next port
        String webService;                          //web service name
        String endpointAddress;                     //port address
        String soapActionUri;                       //soap action uri
        String namespace;                           //web service namespace
        Iterator allKeys;                           //all keys
        Iterator allKeys2;                          //all keys
        ArrayList methodParams;                     //method params list
        HashMap allEndpoints;                       //all endpoints
        WsdlService wsdlService;                    //wsdl service
        WsdlEndpoint wsdlEndpoint;                  //wsdl endpoint
        WsdlPort wsdlPort;                          //wsdl port
        WsdlOperation wsdlOperation;                //wsdl operation
        WsMethodInfo webServiceInfo;                //web service info    
        WsdlModel wsdlModel;                        //wsdl model
        
        try
        {
            opFound = false;
            wsdlModel = (WsdlModel)lWsdlModel;
            namespace = wsdlModel.getLocalNamespace().getLocalPart();
           
            webService = null;
            endpointAddress = null;
            webServiceInfo = null;

            wsdlOperation = wsdlModel.getOperation(operationName);
            if (wsdlOperation != null)
            {
                soapActionUri = wsdlOperation.getSoapAction();

                allKeys = wsdlModel.getServices().keySet().iterator();
                while (!opFound && allKeys.hasNext())
                {
                    nextKey = (String)allKeys.next();
                    wsdlService = wsdlModel.getService(nextKey);
                    webService = wsdlService.getName();
                    allEndpoints = wsdlService.getEndpoints();
                    
                    allKeys2 = allEndpoints.keySet().iterator();
                    while (!opFound && allKeys2.hasNext())
                    {
                        nextKey2 = (String)allKeys2.next();
                        
                        wsdlEndpoint = (WsdlEndpoint)allEndpoints.get(nextKey2);
                        endpointAddress = wsdlEndpoint.getAddress();
                        nextPort = wsdlEndpoint.getName();
                        wsdlPort = wsdlModel.getPort(nextPort);

                        if (wsdlPort != null)
                        {
                            opFound = wsdlPort.containsOperation(operationName);
                        }
                    }
                }

                if (opFound)
                {
                    methodParams = null;
                    if (paramValues) 
                    {
                        methodParams = wsdlOperation.getMethodInfoParams(wsdlOperation.getCommProtocol());
                        removeMessageNamedParams(wsdlModel, methodParams);
                    }

                    webServiceInfo = createSoapCall(webService, operationName, endpointAddress, 
                            soapActionUri, namespace, methodParams, setRtn);
                }
            }

            return webServiceInfo;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "createSoapCall", null, ex);
        }
    }
    
    /**
     * Create and return a method info object for invoking a web service using the SOAP protocol.
     * Note that this does not work for a locally run web service, but only a remote one (not on licas).
     * @param webService the service name.
     * @param operation the name of the operation to call.
     * @param endpointAddress the server endpoint address.
     * @param soapActionUri soap action uri type.
     * @param namespace ontology namespace.
     * @param parameters list of {@code WsdlParamInfo} objects that store parameter types and values.
     * @param setRtn true if set the return Object type.
     * @return a web service info object with the appropriate values.
     * @throws java.lang.Exception any error.
     */
    public WsMethodInfo createSoapCall(String webService, String operation, String endpointAddress,
        String soapActionUri, String namespace, ArrayList parameters, boolean setRtn) throws Exception
    {
        WsMethodInfo methodInfo;
        
        methodInfo = new WsMethodInfo(Const.SOAP, webService, operation,
                endpointAddress, soapActionUri, namespace, null, parameters);
        
        if (setRtn) methodInfo.setRtnType(SOAPMessage.class.getName());
        
        return methodInfo;
    }
    
    /**
     * The original message type parameter may still be stored, as it can list several
     * other parameters, so remove it here and only add its child list if necessary.
     * @param methodParams list of parameters for the {@link MethodInfo} object.
     */
    private void removeMessageNamedParams(WsdlModel wsdlModel, ArrayList methodParams)
    {
        int i;
        ArrayList childList;                               //list of child parameters
        WsdlParamInfo paramInfo;                        //param info
        
        if ((methodParams != null) && !methodParams.isEmpty())
        {
            paramInfo = (WsdlParamInfo)methodParams.get(0);
            if (wsdlModel.getMessage(paramInfo.getName()) != null)
            {
                childList = paramInfo.getChildElements();
                if ((childList != null) && !childList.isEmpty())
                {
                    methodParams.clear();
                    for (i = 0; i < childList.size(); i++)
                    {
                        methodParams.add(childList.get(i));
                    }
                }
            }
        }
    }
       
    /**
     * Create the client soap method handler.
     * @return a soap handler derived from {@link Soap_BaseHandler}.
     */
    public Soap_BaseHandler createSoapMethodHandler()
    {
        return new Soap_MethodHandler();
    }
    
    /**
     * Required by some string-based requests, to convert them back into the method 
     * info object. A script might require parsing from a string, for example.
     * @param method the method name.
     * @param descr the method call description.
     * @return the related method info object.
     * @throws java.lang.Exception any error.
     */
    public WsMethodInfo toMethodInfo(String method, String descr) throws Exception
    {
        WsdlParser wsdlParser;                      //wsdl parser
        WsdlModel wsdlModel;                        //wsdl model
        
        wsdlParser = new WsdlParser();
        wsdlModel = wsdlParser.parse(descr);
        wsdlModel.convertMessagesToParameters();
        return wsdlModel.getWebServiceInfo(method);                           
    }
}
