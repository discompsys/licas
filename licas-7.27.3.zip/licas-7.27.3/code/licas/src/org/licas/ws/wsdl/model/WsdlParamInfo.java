/*
 * WsdlParamInfo.java
 *
 * Created on 15 June 2009
 *
 * Version 1.3.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws.wsdl.model;


import org.licas.call.ParamInfo;
import org.licas.util.Const;
import org.licas.ws.WsFactory;
import org.licas.ws.wsdl.WsdlConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;
import java.util.Vector;


/**
 * This class stores parameter details for a web services message.
 * @author Kieran Greer
 */
public class WsdlParamInfo extends ParamInfo
{
    /** Parameter description */
    private String documentation;

    /** Indicates if an input or output parameter */
    private String inOut;

    /** The parameter element name */
    private String element;

    /** The parameter namespace */
    private String namespace;

    /** ArrayList of child elements. Of type WsdlParamInfo */
    private ArrayList<WsdlParamInfo> childElements;


    /** 
     * Creates a new instance of WsdlParamInfo.
     */
    public WsdlParamInfo()
    {
        super();        
        name = null;
        initialise();
    }
    
    /** 
     * Creates a new instance of WsdlParamInfo.
     * @param thisName the parameter name.
     */
    public WsdlParamInfo(String thisName)
    {
        super();        
        name = WsFactory.removePrefix(thisName);
        initialise();
    }

    /**
     * Creates a new instance of WsdlParamInfo.
     * @param thisName the parameter name.
     * @param valueObj a value to add to values.
     */
    public WsdlParamInfo(String thisName, Object valueObj)
    {
        super(valueObj);
        name = thisName;
        initialise();
    }

    /**
     * Initialise some values.
     */
    private void initialise()
    {
        documentation = "";
        inOut = "";
        element = null;
        namespace = null;
        childElements = new ArrayList<>();
    }

    /**
     * Return true if this param info object has child elements.
     * @return true if childElements is not empty, false otherwise.
     */
    public boolean hasChildren()
    {
        return (!childElements.isEmpty());
    }
    
    /**
     * Set the description of the service.
     * @param theDocumentation the service documentation.
     */
    public void setDocumentation(String theDocumentation)
    {
        documentation = theDocumentation;
    }

    /**
     * Get the service documentation.
     * @return the value of documentation.
     */
    public String getDocumentation()
    {
        return documentation;
    }

    /**
     * Set the value describing if an input or output parameter.
     * @param thisInOut the input/output parameter value.
     */
    public void setInOut(String thisInOut)
    {
        inOut = thisInOut;
    }

    /**
     * Get the value describing in an input or output parameter.
     * @return the value of inOut.
     */
    public String getInOut()
    {
        return inOut;
    }

    /**
     * Set the element name.
     * @param thisElement the element name.
     */
    public void setElement(String thisElement)
    {
        element = thisElement;
    }

    /**
     * Get the element name.
     * @return the value of element.
     */
    public String getElement()
    {
        return element;
    }
    
    /**
     * This represents a simple or a complex parameter type. If the type is set 
     * return this, otherwise if the element part is not null return this.
     * @return the value of type first, or element if null.
     */
    public String getTypeElement()
    {
        String typeName;                    //parameter type name

        typeName = type;
        if (typeName == null) typeName = element;
        return typeName;
    }

    /**
     * Set the parameter namespace.
     * @param thisNamespace the namespace for the parameter.
     */
    public void setNamespace(String thisNamespace)
    {
        namespace = thisNamespace;
    }

    /**
     * Get the parameter namespace.
     * @return the value of namespace.
     */
    public String getNamespace()
    {
        return namespace;
    }

    /**
     * Clear the child elements list.
     */
    public void clearChildElements()
    {
        childElements.clear();
    }

    /**
     * Add a child element to the list of child elements. If a child
     * element with the same name already exists then this parameter
     * is not added.
     * @param thisChildElement the element to add.
     * @return true if added, false otherwise.
     */
    public boolean addChildElement(WsdlParamInfo thisChildElement)
    {
        int i;
        boolean alreadyAdded;                   //true if already added
        String paramName;                       //parameter name
        WsdlParamInfo nextParamInfo;            //next param info
        
        alreadyAdded = false;
        paramName = thisChildElement.getName();
        
        for (i = 0; !alreadyAdded && (i < childElements.size()); i++)
        {
            nextParamInfo = childElements.get(i);
            alreadyAdded = nextParamInfo.getName().equals(paramName);
        }
        
        if (!alreadyAdded) childElements.add(thisChildElement);        
        return !alreadyAdded;
    }

    /**
     * Get the list of child elements.
     * @return the value of childElements.
     */
    public ArrayList<WsdlParamInfo> getChildElements()
    {
        return childElements;
    }
    
    /**
     * Get the child element with the specified name.
     * @param paramName the parameter name.
     * @return the child element with the specified name, or null if
     * none exist.
     */
    public WsdlParamInfo getChildElement(String paramName)
    {
        int i;
        WsdlParamInfo childParamInfo;               //child param info
        WsdlParamInfo nextParamInfo;                //next param info
        
        childParamInfo = null;
        for (i = 0; (childParamInfo == null) && (i < childElements.size()); i++)
        {
            nextParamInfo = childElements.get(i);
            if (nextParamInfo.getName().equals(paramName))
                childParamInfo = nextParamInfo;
        }
        
        return childParamInfo;
    }
    
    /**
     * Remove the child element with the specified name.
     * @param paramName the parameter name.
     * @return true if removed or false if it does not exist.
     */
    public boolean removeChildElement(String paramName)
    {
        int i;
        boolean isRemoved;                          //true if removed
        WsdlParamInfo nextParamInfo;                //next param info
        
        isRemoved = false;
        for (i = 0; !isRemoved && (i < childElements.size()); i++)
        {
            nextParamInfo = childElements.get(i);
            if (nextParamInfo.getName().equalsIgnoreCase(paramName)) {
                childElements.remove(i);
                isRemoved = true;
            }
        }
        
        return isRemoved;
    }
    
    /**
     * Convert the parameter description to an xml element.
     * @return the parameter description as an xml element.
     * @throws java.lang.Exception any error.
     */
    public Element toElement() throws Exception
    {
        int i;
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        WsdlParamInfo nextParam;                    //next parameter
        
        rootElem = super.toElement();
        if (rootElem != null) {
            rootElem.setName(Const.WSDLPARAMETER);
            
            nextElem = XMLFactory.getInstance().createElement(Const.SOURCE);
            nextElem.setText(inOut);
            rootElem.addContent(nextElem);
            
            nextElem = XMLFactory.getInstance().createElement(WsdlConst.ELEMENT);
            nextElem.setText(element);
            rootElem.addContent(nextElem);
            
            nextElem = XMLFactory.getInstance().createElement(Const.NAMESPACE);
            nextElem.setText(element);
            rootElem.addContent(nextElem);
            
            nextElem = XMLFactory.getInstance().createElement(Const.DESCRIPTION);
            nextElem.setText(documentation);
            rootElem.addContent(nextElem);
        
            if (!childElements.isEmpty()) {
                nextElem = XMLFactory.getInstance().createElement(Const.CHILDELEMENTS);
                rootElem.addContent(nextElem);
            
                for (i = 0; i < childElements.size(); i++)
                {
                    nextParam = childElements.get(i);
                    nextElem.addContent(nextParam.toElement());
                }
            }
        }
        
        return rootElem;
    }
    
    /**
     * Set the values in this ParamInfo object from the XML-based description.
     * @param rootElem the root element with the specific parameter values.
     * @throws java.lang.Exception any error.
     */
    public void fromElement(Element rootElem) throws Exception
    {
        int i, j;
        WsdlParamInfo childParam;                   //child param info
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Vector<Node> elemList;                      //element list
        Vector<Node> elemList2;                     //element list
        
        if (rootElem.getName().equals(Const.PARAMETER)) {
            super.fromElement(rootElem);
            
            elemList = rootElem.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextElem = (Element)elemList.get(i);
                if (nextElem.getName().equals(Const.SOURCE)) {
                    inOut = nextElem.getText();
                }
                else if (nextElem.getName().equals(WsdlConst.ELEMENT)) {
                    element = nextElem.getText();
                }
                else if (nextElem.getName().equals(Const.NAMESPACE)) {
                    namespace = nextElem.getText();
                }
                else if (nextElem.getName().equals(Const.DESCRIPTION)) {
                    documentation = nextElem.getText();
                }
                else if (nextElem.getName().equals(Const.CHILDELEMENTS)) {
                    elemList2 = nextElem.getChildren();
                    for (j = 0; j < elemList2.size(); j++)
                    {
                        childParam = new WsdlParamInfo();
                        nextElem2 = (Element)elemList2.get(j);
                        childParam.fromElement(nextElem2);

                        childElements.add(childParam);
                    }
                }
            }
        }
    }

    /**
     * Get a String-based description of this object that can be displayed.
     * @param indent indentation for formatting purposes.
     * @return a description of the contents of this object.
     */
    public String toDisplayString(String indent)
    {
        int i;
        StringBuilder description;              //description
        String newIndent;                       //new indent
        WsdlParamInfo paramInfo;                //param info

        description = new StringBuilder();
        newIndent = (indent + "   ");
        
        if (indent.equals("")) description.append(indent).append("Parameter: ").append(name);
        else description.append(indent).append("Child Element:\n").append(name);
        if (type != null) description.append(" (").append(type).append(")");
        if (value != null) description.append("\n").append(indent).append("Value: ").append(String.valueOf(value));

        for (i = 0; i < childElements.size(); i++)
        {
            paramInfo = childElements.get(i);
            description.append("\n").append(paramInfo.toDisplayString(newIndent));
        }

        return description.toString();
    }
    
    /**
     * Get a String description of this object.
     * @return a description of the contents of this object.
     */
    public String ToString()
    {
        int i;
        StringBuilder description;              //description
        WsdlParamInfo paramInfo;                //param info

        description = new StringBuilder();
        description.append("Name: ").append(name);
        
        if (inOut != null) description.append("\nInput/Output: ").append(inOut);
        if (namespace != null) description.append("\nNamespace: ").append(namespace);
        if (type != null) description.append("\nType: ").append(type);
        if (element != null) description.append("\nElement: ").append(element);
        if (value != null) description.append("\nValue: ").append(String.valueOf(value));

        for (i = 0; i < childElements.size(); i++)
        {
            paramInfo = childElements.get(i);
            description.append("\n   Child Element: ").append(paramInfo.ToString());
        }

        return description.toString();
    }
    
    /**
     * Get a clone of this object. This is a deep clone, but without any actual values.
     * @return a clone copy of this object
     */
    public WsdlParamInfo cloneEmptyValue()
    {
        int i;
        WsdlParamInfo paramClone;               //cloned object

        paramClone = new WsdlParamInfo(name);
        paramClone.setInOut(inOut);
        paramClone.setNamespace(namespace);
        paramClone.setType(type);
        paramClone.setElement(element);
        paramClone.setDocumentation(documentation);

        for (i = 0; i < childElements.size(); i++)
        {
            paramClone.addChildElement((WsdlParamInfo)childElements.get(i).clone());
        }

        return paramClone;
    }

    /**
     * Get a clone of this object. This is a deep clone, but some values may be references.
     * @return a clone copy of this object
     */
    public Object clone()
    {
        int i;
        WsdlParamInfo paramClone;               //cloned object

        paramClone = new WsdlParamInfo(name);
        paramClone.setInOut(inOut);
        paramClone.setNamespace(namespace);
        paramClone.setElement(element);
        paramClone.setDocumentation(documentation);
        paramClone.setValue(value);
        paramClone.setType(type);
        
        for (i = 0; i < childElements.size(); i++)
        {
            paramClone.addChildElement((WsdlParamInfo)childElements.get(i).clone());
        }

        return paramClone;
    }
}
