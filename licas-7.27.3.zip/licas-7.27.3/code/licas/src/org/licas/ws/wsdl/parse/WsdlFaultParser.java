/*
 * WsdlFaultParser.java
 *
 * Created on 25 June 2009
 *
 * Version 1.0.2
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.ws.wsdl.parse;


import org.licas.ws.wsdl.WsdlConst;
import org.licas.ws.wsdl.model.*;

import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.licas.ws.WsFactory;
import org.licas_xml.abs.*;


/**
 * This class can be used to parse a fault to its Java equivalent.
 * This is from a WSDL script description and not from other Java objects.
 * @author Kieran Greer
 */
public class WsdlFaultParser
{
    /** The logger */
    private static Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(WsdlFaultParser.class.getName());
        logger.setDebug(true);
    }


    /**
     * Create a new instance of WsdlFaultParser.
     */
    public WsdlFaultParser()
    {}

     /**
     * Parse and return a fault object.
     * @param rootElem the element to parse.
     * @return the created fault object.
     * @throws java.lang.Exception any error.
     */
    public WsdlFault parse(Element rootElem) throws Exception
    {
        String name;                            //name
        String faultElem;                       //fault element
        String faultMessage;                    //fault message
        WsdlFault wsdlFault;                    //wsdl fault

        try
        {
            wsdlFault = null;

            name = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.NAME));
            if ((name == null) || name.equals(""))
            {
                name = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.REF));
            }

            if ((name != null) && !name.equals(""))
            {
                faultElem = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.ELEMENT));
                faultMessage = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.MESSAGELABEL));

                wsdlFault = new WsdlFault(name);
                wsdlFault.setElement(faultElem);
                wsdlFault.setMessage(faultMessage);
            }

            return wsdlFault;
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parse", null, ex);            
            
            if (logger.getDebug())
            {
                LoggerHandler.debugMessage(logger, LoggerHandler.ERROR , "parse", null);
                LoggerHandler.debugError(logger, LoggerHandler.ERROR , ex);
            }

            throw ex;
        }
    }
}
