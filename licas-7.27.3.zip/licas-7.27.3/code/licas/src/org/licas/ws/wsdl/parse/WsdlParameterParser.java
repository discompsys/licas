/*
 * WsdlParameterParser.java
 *
 * Created on 25 June 2009
 *
 * Version 1.0.4
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.ws.wsdl.parse;


import org.licas.ws.wsdl.WsdlConst;
import org.licas.ws.wsdl.model.*;

import org.licas_xml.abs.*;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.util.*;
import org.licas.ws.WsFactory;


/**
 * This class can be used to parse a parameter to its Java equivalent. 
 * This is from a WSDL script description and not from other Java objects.
 * @author Kieran Greer
 */
public class WsdlParameterParser
{
    /** The logger */
    private static Logger logger;


    /** Current wsdl types */
    private WsdlTypes wsdlTypes;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(WsdlParameterParser.class.getName());
        logger.setDebug(true);
    }


    /**
     * Create a new instance of WsdlParameterParser.
     * @param theWsdlTypes the current wsdl types object.
     */
    public WsdlParameterParser(WsdlTypes theWsdlTypes)
    {
        wsdlTypes = theWsdlTypes;
    }
    
    /**
     * Parse the next parameter type.
     * @param rootElem the root element for the parameter.
     * @return the parsed document.
     * @throws java.lang.Exception any error.
     */
    public WsdlParamInfo parse(Element rootElem) throws Exception
    {
        int i;
        String name;                                //parameter name
        String name2;                               //parameter name
        String type;                                //parameter type
        String type2;                               //parameter type
        WsdlParamInfo parameter;                    //next parameter
        WsdlParamInfo parameter2;                   //next parameter
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Vector elemList;                              //element list

        try
        {
            parameter = null;
            name = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.NAME));
            type = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.TYPE));

            if ((name != null) && !name.equals(""))
            {
                if ((type != null) && !type.equals(""))
                {
                    parameter = new WsdlParamInfo(name);
                    parameter.setType(type);
                }
                else
                {
                    if (rootElem.hasChildren())
                    {
                        nextElem = rootElem.getElementChildAtIndex(0);

                        //check if traverse one more level for 'all' element and then traverse child elements
                        if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.ALL))
                        {
                            elemList = nextElem.getChildren();
                        }
                        else
                        {
                            elemList = rootElem.getChildren();
                        }
                    }
                    else
                    {
                        elemList = new Vector();
                    }
                    
                    for (i = 0; i < elemList.size(); i++)
                    {
                        nextNode = (Node)elemList.get(i);

                        if (nextNode instanceof Element)
                        {
                            nextElem = (Element)nextNode;

                            if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.ATTRIBUTE) ||
                                WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.ELEMENT))
                            {
                                if (parameter == null)
                                {
                                    parameter = new WsdlParamInfo(name);
                                    parameter.setType(WsdlConst.COMPLEXTYPE);
                                }

                                name2 = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.NAME));
                                type2 = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.TYPE));

                                if ((name2 != null) && !name2.equals("") &&
                                    (type2 != null) && !type2.equals(""))
                                {
                                    parameter2 = new WsdlParamInfo(name2);
                                    parameter2.setType(type2);
                                    parameter.addChildElement(parameter2);
                                }
                            }
                            else if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.COMPLEXTYPE) ||
                                    WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.COMPLEXCONTENT))
                            {
                                parameter = new WsdlParamInfo(name);
                                parameter.setType(WsdlConst.COMPLEXTYPE);
                                parseComplexType(parameter, nextElem, name);
                            }
                            else if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.RESTRICTION) ||
                                    WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.ENUMERATION))
                            {
                                if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.RESTRICTION))
                                    type = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.BASE));
                                else
                                    type = WsdlConst.SIMPLETYPE;
                                
                                parameter = new WsdlParamInfo(name);
                                parameter.setType(type);
                                parseSimpleType(parameter, nextElem, name);
                            }
                            else if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.SEQUENCE))
                            {
                                parameter = new WsdlParamInfo(name);
                                parameter.setType(WsdlConst.SEQUENCE);
                                parseComplexType(parameter, nextElem, name);
                            }
                        }
                    }
                }
            }

            return parameter;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, 
                    "parse", null, ex);
        }
    }

    /**
     * Parse the complex type part of the parameter type.
     * @param parameter the parameter info to add the complex type to.
     * @param rootElem the root element for the parameter.
     * @param parentName the name of the parent element. Can be null.
     * @throws java.lang.Exception any error.
     */
    public void parseComplexType(WsdlParamInfo parameter, Element rootElem, String parentName)
        throws Exception
    {
        int i, j;
        String name;                                //parameter name
        String type;                                //parameter type
        String elementType;                         //element type
        WsdlParamInfo nextParam;                    //next parameter
        WsdlParamInfo baseParam;                    //base parameter
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Vector elemList;                            //element list
        Vector elemList2;                           //element list


        try
        {
            elemList = rootElem.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);

                if (nextNode instanceof Element)
                {
                    nextParam = null;
                    nextElem = (Element)nextNode;

                    elementType = WsFactory.removePrefix(nextElem.getName());
                    if (elementType.equalsIgnoreCase(WsdlConst.EXTENSION))
                    {
                        name = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.BASE));

                        if ((name != null) && !name.equals(""))
                        {
                            baseParam = wsdlTypes.getType(name);
                            if (baseParam != null)
                            {
                                nextParam = (WsdlParamInfo)baseParam.clone();
                                parameter.addChildElement(nextParam);
                            }
                        }
                    }
                    else
                    {
                        name = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.NAME));
                        if (name == null) name = parentName;

                        if ((name != null) && !name.equals(""))
                        {
                            type = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.TYPE));

                            if ((type != null) && !type.equals(""))
                            {
                                nextParam = new WsdlParamInfo(name);
                                nextParam.setType(type);
                                parameter.addChildElement(nextParam);
                            }
                        }
                    }

                    if (nextElem.hasChildren())
                    {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextNode = (Node)elemList2.get(j);

                            if (nextNode instanceof Element)
                            {
                                nextElem2 = (Element)nextNode;

                                if (WsFactory.removePrefix(nextElem2.getName()).equalsIgnoreCase(WsdlConst.ATTRIBUTE) ||
                                    WsFactory.removePrefix(nextElem2.getName()).equalsIgnoreCase(WsdlConst.ELEMENT))
                                {
                                    if (parameter == null)
                                    {
                                        parameter = new WsdlParamInfo(name);
                                        parameter.setType(WsdlConst.COMPLEXTYPE);
                                    }

                                    name = WsFactory.removePrefix(nextElem2.getAttributeValue(WsdlConst.NAME));
                                    type = WsFactory.removePrefix(nextElem2.getAttributeValue(WsdlConst.TYPE));

                                    if ((name != null) && !name.equals("") &&
                                        (type != null) && !type.equals(""))
                                    {
                                        nextParam = new WsdlParamInfo(name);
                                        nextParam.setType(type);
                                        parameter.addChildElement(nextParam);
                                    }
                                }
                                else if (WsFactory.removePrefix(nextElem2.getName()).equalsIgnoreCase(WsdlConst.COMPLEXTYPE) ||
                                        WsFactory.removePrefix(nextElem2.getName()).equalsIgnoreCase(WsdlConst.COMPLEXCONTENT))
                                {
                                    if (nextParam == null)
                                    {
                                        nextParam = new WsdlParamInfo(name);
                                        nextParam.setType(WsdlConst.COMPLEXTYPE);
                                        parameter.addChildElement(nextParam);
                                    }

                                    parseComplexType(nextParam, nextElem2, name);
                                }
                                else if (WsFactory.removePrefix(nextElem2.getName()).equalsIgnoreCase(WsdlConst.SEQUENCE))
                                {
                                    if (nextParam == null)
                                    {
                                        nextParam = new WsdlParamInfo(name);
                                        nextParam.setType(WsdlConst.SEQUENCE);
                                        parameter.addChildElement(nextParam);
                                    }

                                    parseComplexType(nextParam, nextElem2, name);
                                }
                            }
                        }
                    }
                }                   
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, 
                    "parseComplex", null, ex);
        }
    }
    
    /**
     * Parse a simple type of enumeration defined values.
     * @param parameter the parameter info to add the complex type to.
     * @param rootElem the root element for the parameter.
     * @param parentName the name of the parent element. Can be null.
     * @throws java.lang.Exception any error.
     */
    public void parseSimpleType(WsdlParamInfo parameter, Element rootElem, String parentName)
        throws Exception
    {
        int i;
        String name;                                //parameter name
        String elementType;                         //element type
        WsdlParamInfo nextParam;                    //next parameter
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Vector elemList;                            //element list

        try
        {
            elemList = rootElem.getChildren();
            
            //do not store restriction on element type, only store enum values
            if (elemList.size() == 1)
            {
                nextElem = (Element)elemList.get(0);
                if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.RESTRICTION))
                {
                    elemList = nextElem.getChildren();
                }
            }
            
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);

                if (nextNode instanceof Element)
                {
                    nextParam = null;
                    nextElem = (Element)nextNode;

                    elementType = WsFactory.removePrefix(nextElem.getName());
                    if (elementType.equalsIgnoreCase(WsdlConst.ENUMERATION))
                    {
                        name = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.VALUE));
                        if ((name != null) && !name.equals(""))
                        {
                            nextParam = new WsdlParamInfo(name);
                            nextParam.setType(WsdlConst.ENUMERATION);
                            parameter.addChildElement(nextParam);
                        }
                    }
                }                   
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parseSimple", 
                    null, ex);
        }
    }
}
