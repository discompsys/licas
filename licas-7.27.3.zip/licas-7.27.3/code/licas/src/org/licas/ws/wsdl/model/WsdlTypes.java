/*
 * WsdlTypes.java
 *
 * Created on 17 June 2009
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws.wsdl.model;

import java.util.HashMap;
import javax.xml.namespace.QName;

/**
 * This class stores the type definitions for a wsdl document.
 * @author Kieran Greer
 */
public class WsdlTypes
{
    /** The local namespace */
    private QName localNamespace;

    /** The xml schema namespace */
    private QName xmlNamespace;

    /**
     * The different parameter type definitions. Keys are the type names
     * while values are of type WsdlParamInfo.
     */
    private HashMap types;

    /**
     * Create a new instance of WsdlTypes.
     */
    public WsdlTypes()
    {
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        localNamespace = null;
        xmlNamespace = null;
        types = new HashMap();
    }

    /**
     * Set the local namespace.
     * @param thisLocalNamespace the local namespace.
     */
    public void setLocalNamespace(QName thisLocalNamespace)
    {
        localNamespace = thisLocalNamespace;
    }

    /**
     * Get the local namespace.
     * @return the value of localNamespace.
     */
    public QName getLocalNamespace()
    {
        return localNamespace;
    }

    /**
     * Set the xml namespace.
     * @param thisXmlNamespace the xml namespace.
     */
    public void setXmlNamespace(QName thisXmlNamespace)
    {
        xmlNamespace = thisXmlNamespace;
    }

    /**
     * Get the xml namespace.
     * @return the value of xmlNamespace.
     */
    public QName getXmlNamespace()
    {
        return xmlNamespace;
    }

    /**
     * Add a new parameter type.
     * @param type the type to add.
     * @return true if a new type or false otherwise.
     */
    public boolean addType(WsdlParamInfo type)
    {
        if (!types.containsKey(type.getName().toLowerCase()))
        {
            types.put(type.getName().toLowerCase(), type);
            return true;
        }

        return false;
    }

    /**
     * Get the type with the specified name.
     * @param typeName the type name.
     * @return the type with the specified name or null if none exist.
     */
    public WsdlParamInfo getType(String typeName)
    {
        if ((typeName != null) && types.containsKey(typeName.toLowerCase()))
            return (WsdlParamInfo)types.get(typeName.toLowerCase());
        else
            return null;
    }

    /**
     * Get all types.
     * @return the value of types.
     */
    public HashMap getTypes()
    {
        return types;
    }
}
