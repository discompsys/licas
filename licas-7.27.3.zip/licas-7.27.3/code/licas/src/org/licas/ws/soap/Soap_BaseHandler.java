/*
 * Soap_BaseHandler
 *
 * Created on 6 November 2012
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws.soap;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.def.RemoteCallDef;
import org.licas.util.Const;

import java.util.StringTokenizer;


/**
 * This class acts an an interface for making soap calls to Web Services.
 * A version of this class was used previously on the Icons project at UU.
 * @author Kieran Greer
 */
public abstract class Soap_BaseHandler implements RemoteCallDef
{
    /** The timeout amount for the calls */
    public static final int TIMEOUT = 5000;

    /** The logger */
    private static final Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(Soap_BaseHandler.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of Soap_BaseHandler.
     */
    public Soap_BaseHandler()
    {}

    /**
     * Return true if the soap action uri is a method call.
     * @param uri the uri.
     * @param namespace the soap body namespace.
     * @return boolean true if a method call.
     */
    protected boolean isMethodCall(String uri, String namespace)
    {
        String nextTkn = "";				//next token
        StringTokenizer strTkn;				//String tokenizer

        //if namespace exists return false as operation needs to be included
        if ((namespace != null) && (!namespace.equalsIgnoreCase(Const.NULL)))
                return false;

        //if uri is missing then not a method call
        if ((uri == null) || (uri.equalsIgnoreCase("")) || (uri.equalsIgnoreCase(Const.NULL)))
                return false;

        //if directory then not a method
        if (uri.endsWith("/")) return false;

        //if starts with urn: then not a method call
        if (uri.startsWith("urn:")) return false;

        //get last token and check not a page (indicated by full stop)
        strTkn = new StringTokenizer(uri, "/", false);

        while (strTkn.hasMoreTokens())
        {
            nextTkn = strTkn.nextToken();
        }

        return (!nextTkn.contains("."));
    }

    /**
     * Return the namespace if it exists.
     * @param uri the uri.
     * @return String the namespace or null if it does not exist.
     */
    protected String rtnNamespace(String uri)
    {
        if (uri == null) return uri;
        else if (uri.equalsIgnoreCase("")) return null;
        else if (uri.equalsIgnoreCase(Const.NULL)) return null;
        else return uri;
    }
}
