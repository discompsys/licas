/*
 * Soap_MethodHandler
 *
 * Created on 15 June 2009
 *
 * Version 1.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws.soap;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import org.licas.ws.WsMethodInfo;
import org.licas.call.MethodInfo;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;

import javax.xml.soap.*;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.*;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import org.jlog2.util.StringHandler;
import org.licas.call.CallObject;
import org.licas.parsers.MethodInfoParser;
import org.licas.util.Const;
import org.licas.util.TypeConst;
import org.licas.util.classloader.LoadObject;
import org.licas.util.exception.LicasException;
import org.licas.ws.wsdl.WsdlConst;
import org.licas_xml.model.XmlHandler;


/**
 * This acts as an interface for making SOAP-style calls on Web Services.
 * @author Kieran Greer
 */
public class Soap_MethodHandler extends Soap_BaseHandler
{
    /** The logger */
    private static Logger logger;


    /** The remote call type, for example Const.XML-RPC, REST or SOAP */
    private String callType;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(Soap_MethodHandler.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of Soap_MethodHandler.
     */
    public Soap_MethodHandler()
    {
        callType = Const.SOAP;
    }

    /**
     * Execute a soap call. Use this method to pass the dataset in a single call.
     * @param methodInfo the {@link WsMethodInfo} that describes the call.
     * @return Object the reply to the call.
     * @throws java.lang.Exception any error.
     */
    public Object execute(MethodInfo methodInfo) throws Exception
    {
        int index;
        String wsName;                          //web service name
        String infName;                         //interface name
        String endpointAddress;                 //target endpoint address
        String tns;                             //target namespace
        String classValue;                      //class value
        String[] localConfig;                   //if locally run (on licas)
        SOAPConnectionFactory scFactory;	//creates soap connection
        SOAPConnection con;			//soap connection
        SOAPMessage message;			//soap message
        SOAPMessage response;			//returned soap message
        URL endpoint;				//endpoint address
        WsMethodInfo wsInfo;                    //web service method info
        CallObject callObj;                     //for local ws call (on licas)
        
        con = null;
        try
        {
            //dynamically construct and invoke the soap message
            wsInfo = (WsMethodInfo)methodInfo;
            endpointAddress = wsInfo.getSoapEndpointAddress();  
            
            if (org.licas_internet.ConnectionManager.pingURL(endpointAddress, 3000))
            {
                message = construct(methodInfo);

                //create a connection to make the call
                scFactory = SOAPConnectionFactory.newInstance();
                con = scFactory.createConnection();
                endpoint = new URL(endpointAddress);

                if (!wsInfo.getCallType().equalsIgnoreCase(Const.WSRPC))
                {
                    response = con.call(message, endpoint);
                    if (response.saveRequired()) response.saveChanges();
                    return response;
                }
                else
                {
                    //maybe new RPC type and then use this if error with soap
                    localConfig = wsInfo.getLocalWS();
                    if (localConfig != null)
                    {
                        wsName = wsInfo.getLocalWS()[0];
                        tns = wsInfo.getLocalWS()[1];
                        classValue = wsInfo.getLocalWS()[2];

                        if (wsName.endsWith("Impl"))
                        {
                            index = 0;
                            while (wsName.indexOf("Impl", (index+1)) > 0)
                            {
                                index = wsName.indexOf("Impl", (index+1));
                            }
                            
                            infName = wsName.substring(0, index);
                        }
                        else
                        {
                            infName = wsName;
                            wsName = (infName + "Impl");
                        }
                        
                        //interface stub also required, so local classes needed
                        Class c = LoadObject.getClass(classValue + "." + infName);
                        URL url = new URL(endpointAddress + "?wsdl");
                        QName qname = new QName(tns, wsName);
                        Service service = Service.create(url, qname);
                        qname = new QName(tns, (wsName + "Port"));
                        Object uc = service.getPort(qname, c);

                        //make call to retrieve string-based result, not XML
                        callObj = new CallObject();
                        methodInfo = new MethodInfo();
                        methodInfo.setServiceObj(uc);
                        methodInfo.setName(wsInfo.getName());
                        methodInfo.setRtnType(wsInfo.getRtnType());
                        methodInfo.getParams().addAll(wsInfo.getParams());
                        Object reply = callObj.call(methodInfo);
                        return reply;
                    }
                    else
                    {
                        return null;
                    }
                }  
            }
            else
            {
                LoggerHandler.logMessage(logger, LoggerHandler.INFO, "execute", 
                        "The connection " + endpointAddress + " is currently down.");
                return null;
            }
        } 
        catch (Exception ex) 
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "execute", null, ex);
        }
        finally
        {
            if (con != null) con.close();
        }
    }
       
    /**
     * Construct a SOAP message from a {@link WsMethodInfo} description. Note that
     * the endpoint, or http address to send to, is not included in the returned message, 
     * but it is still included in the method info object.
     * @param methodInfo the {@link WsMethodInfo} object to parse.
     * @return the constructed soap message.
     * @throws java.lang.Exception any error.
    */
    public SOAPMessage construct(MethodInfo methodInfo) throws Exception
    {
        String operation = null;                //local operation name
        String soapActionUri = null;            //the uri of the soap action
        String namespace = null;                //the operation namespace
        MessageFactory factory;			//creates message
        SOAPMessage message;			//soap message
        SOAPPart soapPart;			//soap part of message
        SOAPEnvelope envelope;			//soap envelope
        SOAPBody body;				//body of soap envelope
        SOAPHeader header;			//header of soap envelope
        SoapMessage soapMessage;                //construct the soap message to call
        MimeHeaders headers;			//mime headers
        WsMethodInfo wsInfo;                    //web service method info
        ArrayList params;                          //method parameters
        
        try
        {
            soapMessage = new SoapMessage();
            wsInfo = (WsMethodInfo)methodInfo;

            soapActionUri = wsInfo.getSoapActionUri();
            namespace = rtnNamespace(wsInfo.getNamespace());

            //if soap action is not a method call the need to include the operation
            if (!isMethodCall(soapActionUri, namespace)) operation = wsInfo.getName();

            //dynamically construct the soap message
            factory = MessageFactory.newInstance();
            message = factory.createMessage();

            //may force a soap-only execution type, which is OK as can then change if fault
            headers = message.getMimeHeaders();
            headers.setHeader(SoapConst.SOAPACTION, soapActionUri);

            soapPart = message.getSOAPPart();
            envelope = soapPart.getEnvelope();
            header = envelope.getHeader();
            header.detachNode();
            body = envelope.getBody();

            params = wsInfo.getParams();
            soapMessage.constructSoapMessage(envelope, body, params, operation, namespace, wsInfo);           
            message.saveChanges();

            return message;
        } 
        catch (Exception ex) 
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "construct", null, ex);
        }
    }
    
    /**
     * Get the value indicating the type of remote call.
     * @return the value of callType.
     */
    public String getCallType()
    {
        return callType;
    }
}
