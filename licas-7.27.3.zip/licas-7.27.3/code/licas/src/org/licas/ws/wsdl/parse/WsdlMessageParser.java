/*
 * WsdlMessageParser.java
 *
 * Created on 26 June 2009
 *
 * Version 1.1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws.wsdl.parse;


import org.licas.ws.wsdl.model.*;
import org.licas.ws.wsdl.WsdlConst;
import org.licas.util.*;

import org.jlog2.*;
import org.licas_xml.abs.*;

import java.util.*;
import org.jlog2.exception.ExceptionHandler;
import org.licas.ws.WsFactory;


/**
 * This class can be used to parse a message to its Java equivalent.
 * @author Kieran Greer
 */
public class WsdlMessageParser
{
    /** The logger */
    private static Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(WsdlMessageParser.class.getName());
        logger.setDebug(true);
    }


    /**
     * Create a new instance of WsdlMessageParser.
     */
    public WsdlMessageParser()
    {}

    /**
     * Parse the next message element.
     * @param rootElem the root element for the message.
     * @return the parsed message as a message object.
     * @throws java.lang.Exception any error.
     */
    public WsdlMessage parse(Element rootElem) throws Exception
    {
        int i, j;
        String name;                                //message name
        String type;                                //part type
        String partName;                            //part name
        String partElement;                         //part element name
        WsdlMessage wsdlMessage;                    //wsdl message
        WsdlMessage messagePart;                    //message part
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Vector elemList;                            //element list
        Vector elemList2;                           //element list


        try
        {
            wsdlMessage = null;
            name = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.NAME));

            if ((name != null) && !name.equals(""))
            {
                wsdlMessage = new WsdlMessage(name);

                if (rootElem.hasChildren())
                {
                    elemList = rootElem.getChildren();
                    for (i = 0; i < elemList.size(); i++)
                    {
                        nextNode = (Node)elemList.get(i);
                        if (nextNode instanceof Element)
                        {
                            nextElem = (Element)nextNode;
                            if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.PART))
                            {
                                partName = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.NAME));
                                partElement = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.ELEMENT));
                                type = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.TYPE));

                                if ((partName != null) && !partName.equals(""))
                                {
                                    messagePart = new WsdlMessage(partName);
                                    wsdlMessage.addMessagePart(messagePart);

                                    if ((partElement != null) && !partElement.equals(""))
                                    {
                                        if (TypeConst.isSimpleType(partElement))
                                            messagePart.setType(partElement);
                                        else
                                            messagePart.setPartElement(partElement);
                                    }

                                    if ((type != null) && !type.equals(""))
                                        messagePart.setType(type);

                                    elemList2 = nextElem.getChildren();
                                    for (j = 0; j < elemList2.size(); j++)
                                    {
                                        nextNode = (Node)elemList2.get(j);
                                        if (nextNode instanceof Element)
                                        {
                                            nextElem2 = (Element)nextNode;
                                            if (WsFactory.removePrefix(nextElem2.getName()).equalsIgnoreCase(WsdlConst.DOCUMENTATION))
                                            {
                                                messagePart.setDocumentation(nextElem2.getText().trim());
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return wsdlMessage;
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parse", null, ex);
            throw ex;
        }
    }
}
