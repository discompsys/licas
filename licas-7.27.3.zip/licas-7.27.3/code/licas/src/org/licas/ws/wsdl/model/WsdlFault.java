/*
 * WsdlFault.java
 *
 * Created on 17 June 2009
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.ws.wsdl.model;

import org.licas.ws.WsFactory;


/**
 * This class store information for a wsdl fault process description.
 * @author Kieran Greer
 */
public class WsdlFault
{
    /** The operation name */
    private String name;

    /** The fault element */
    private String element;

    /** The fault message */
    private String message;

    /**
     * Create a new instance of WsdlFault.
     * @param thisName the fault name.
     */
    public WsdlFault(String thisName)
    {
        name = WsFactory.removePrefix(thisName);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        element = null;
        message = null;
    }

    /**
     * Get the fault name.
     * @return the value of name.
     */
    public String getName()
    {
        return name;
    }

    /**
     * Set the fault element value.
     * @param thisElement the element value.
     */
    public void setElement(String thisElement)
    {
        element = thisElement;
    }

    /**
     * Get the fault element name.
     * @return the value of element.
     */
    public String getElement()
    {
        return element;
    }

    /**
     * Set the fault message value.
     * @param thisMessage the message value.
     */
    public void setMessage(String thisMessage)
    {
        message = thisMessage;
    }

    /**
     * Get the fault message value.
     * @return the value of message.
     */
    public String getMessage()
    {
        return message;
    }
}
