/*
 * WsdlServiceParser.java
 *
 * Created on 25 June 2009
 *
 * Version 1.1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws.wsdl.parse;


import org.licas.ws.WsFactory;
import org.licas.ws.wsdl.WsdlConst;
import org.licas.ws.wsdl.model.*;

import org.licas_xml.abs.*;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.util.*;


/**
 * This class can be used to parse a service to its Java equivalent.
 * This is from a WSDL script description and not from other Java objects.
 * @author Kieran Greer
 */
public class WsdlServiceParser
{
    /** The logger */
    private static Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(WsdlServiceParser.class.getName());
        logger.setDebug(true);
    }

    /**
     * Create a new instance of WsdlServiceParser.
     */
    public WsdlServiceParser()
    {}

    /**
     * Parse the wsdl document and extract the service elements.
     * @param rootElem the document root element.
     * @return the parsed service.
     * @throws java.lang.Exception any error.
	 */
	public WsdlService parse(Element rootElem) throws Exception
    {
        int i;
        String nextName;                        //next name
        WsdlService wsdlService;                //wsdl service
        WsdlEndpoint wsdlEndpoint;              //wsdl endpoint
        WsdlEndpointParser endpointParser;      //endpoint parser
        Node nextNode;                          //next node
        Element nextElem;                       //next element
        Vector elemList;                          //element list


        try
        {
            wsdlService = null;
            endpointParser = new WsdlEndpointParser();
            
            if (WsFactory.removePrefix(rootElem.getName()).equalsIgnoreCase(WsdlConst.SERVICE))
            {
                nextName = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.NAME));

                if ((nextName != null) && !nextName.equals(""))
                {
                    wsdlService = new WsdlService(nextName);

                    nextName = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.INTERFACE));
                    if ((nextName != null) && !nextName.equals(""))
                        wsdlService.setServiceInterface(nextName);

                    //parse endpoints
                    elemList = rootElem.getChildren();
                    for (i = 0; i < elemList.size(); i++)
                    {
                        nextNode = (Node)elemList.get(i);

                        if (nextNode instanceof Element)
                        {
                            nextElem = (Element)nextNode;

                            if (nextElem.getName().equals(WsdlConst.DOCUMENTATION))
                            {
                                wsdlService.setDocumentation(nextElem.getText());
                            }
                            else if (nextElem.getName().equals(WsdlConst.PORT))
                            {
                                wsdlEndpoint = endpointParser.parse(nextElem);
                                if (wsdlEndpoint != null) wsdlService.addEndPoint(wsdlEndpoint);
                            }
                        }
                    }
                }
            }

            return wsdlService;
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parse", null, ex);
            
            if (logger.getDebug())
            {
                LoggerHandler.debugMessage(logger, LoggerHandler.ERROR , "parse", null);
                LoggerHandler.debugError(logger, LoggerHandler.ERROR , ex);
            }

            throw ex;
        }
	}
}
