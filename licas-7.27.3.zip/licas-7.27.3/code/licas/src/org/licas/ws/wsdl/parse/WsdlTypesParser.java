/*
 * WsdlTypesParser.java
 *
 * Created on 25 June 2009
 *
 * Version 1.1.2
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.ws.wsdl.parse;


import org.licas.ws.WsFactory;
import org.licas.ws.soap.SoapConst;
import org.licas.ws.wsdl.WsdlConst;
import org.licas.ws.wsdl.model.*;

import org.jlog2.*;
import org.licas_xml.abs.*;
import org.jlog2.exception.ExceptionHandler;

import java.util.*;
import javax.xml.namespace.QName;



/**
 * This class can be used to parse type descriptions to its Java equivalent.
 * This is from a WSDL script description and not from other Java objects.
 * @author Kieran Greer
 */
public class WsdlTypesParser
{
    /** The logger */
    private static Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(WsdlTypesParser.class.getName());
        logger.setDebug(true);
    }


    /**
     * Create a new instance of WsdlTypesParser.
     */
    public WsdlTypesParser()
    {}

    /**
     * Parse the types section of a wsdl document and store the parameter type definitions.
     * @param rootElem the root element to parse.
     * @return the parsed types object.
     * @throws java.lang.Exception any error.
     */
    public WsdlTypes parse(Element rootElem) throws Exception
    {
        int i;
        String namespaceKey;                            //namespace key
        String namespaceUri;                            //namespace uri
        ArrayList namespaces;                              //all namespaces
        WsdlTypes wsdlTypes;                            //wsdl types
        WsdlParameterParser paramParser;                //wsdl parameter parser
        WsdlParamInfo paramInfo;                        //parameter info
        Attribute nextAttr;                             //next attribute
        Node nextNode;                                  //next node
        Element nextElem;                               //next element
        Vector elemList;                                //element list
        Vector childElemList;                           //child element list

        try
        {
            wsdlTypes = new WsdlTypes();
            paramParser = new WsdlParameterParser(wsdlTypes);

            namespaces = (ArrayList)rootElem.getAttributeList();
            for (i = 0; i < namespaces.size(); i++)
            {
                nextAttr = (Attribute)namespaces.get(i);
                namespaceKey = nextAttr.getName();
                namespaceUri = nextAttr.getValue();

                if (namespaceUri.equalsIgnoreCase(SoapConst.XMLSCHEMAURL))
                {
                    wsdlTypes.setXmlNamespace(new QName(namespaceKey, namespaceUri));
                }
                else if (namespaceUri.equalsIgnoreCase(WsdlConst.TARGETNAMESPACE))
                {
                    wsdlTypes.setLocalNamespace(new QName(namespaceKey, namespaceUri));
                }
            }

            //parse to store all schema types child elements
            childElemList = new Vector();
            elemList = rootElem.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (WsFactory.removePrefix(nextElem.getName()).equals(WsdlConst.SCHEMA))
                    {
                        childElemList.addAll(nextElem.getChildren());
                    }
                }
            }
            
            //parse all schema types
            elemList = childElemList;
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);
                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (WsFactory.removePrefix(nextElem.getName()).equals(WsdlConst.ELEMENT))
                    {
                        paramInfo = paramParser.parse(nextElem);
                        if (paramInfo != null) wsdlTypes.addType(paramInfo);
                    }
                    else if (WsFactory.removePrefix(nextElem.getName()).equals(WsdlConst.COMPLEXTYPE))
                    {
                        paramInfo = paramParser.parse(nextElem);
                        if (paramInfo != null) wsdlTypes.addType(paramInfo);
                    }
                    else if (WsFactory.removePrefix(nextElem.getName()).equals(WsdlConst.SIMPLETYPE))
                    {
                        paramInfo = paramParser.parse(nextElem);
                        if (paramInfo != null) wsdlTypes.addType(paramInfo);
                    }
                }
            }

            return wsdlTypes;
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parse", null, ex);
            
            if (logger.getDebug())
            {
                LoggerHandler.debugMessage(logger, LoggerHandler.ERROR , "parse", null);
                LoggerHandler.debugError(logger, LoggerHandler.ERROR , ex);
            }

            throw ex;
        }
    }
}
