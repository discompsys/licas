/*
 * WsdlEndpoint.java
 *
 * Created on 16 June 2009
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws.wsdl.model;

import org.licas.ws.WsFactory;

/**
 * This class stores information on an endpoint address for a service.
 * @author Kieran Greer
 */
public class WsdlEndpoint
{
    /** The name of the endpoint */
    private String name;

    /** The type of the endpoint */
    private String type;

    /** The endpoint binding */
    private String binding;

    /** The endpoint address */
    private String address;


    /**
     * Create a new instance of WsdlEndpoint.
     * @param thisName the endpoint name.
     * @param thisType the endpoint type.
     * @param thisBinding the endpoint binding.
     * @param thisAddress the endpoint address.
     */
    public WsdlEndpoint(String thisName, String thisType, String thisBinding,
            String thisAddress)
    {
        name = WsFactory.removePrefix(thisName);
        type = thisType;
        binding = thisBinding;
        address = thisAddress;
    }

    /**
     * Get the endpoint name.
     * @return the value of name.
     */
    public String getName()
    {
        return name;
    }

    /**
     * Get the endpoint type.
     * @return the value of type.
     */
    public String getType()
    {
        return type;
    }

    /**
     * Get the endpoint binding.
     * @return the value of binding.
     */
    public String getBinding()
    {
        return binding;
    }

    /**
     * Get the endpoint address.
     * @return the value of address.
     */
    public String getAddress()
    {
        return address;
    }
}
