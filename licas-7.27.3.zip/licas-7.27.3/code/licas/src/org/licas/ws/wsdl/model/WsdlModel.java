/*
 * WsdlModel.java
 *
 * Created on 17 June 2009
 *
 * Version 1.5
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.ws.wsdl.model;


import org.licas.call.MethodFactory;
import org.licas.ws.WsMethodInfo;
import org.licas.ws.soap.*;
import org.licas.ws.wsdl.WsdlConst;

import javax.xml.namespace.QName;
import org.jlog2.exception.ExceptionHandler;
import org.licas_internet.util.HttpConst;
import org.jlog2.*;

import java.util.*;


/**
 * This class describes an entire wsdl document and stores the info in Java objects.
 * @author Kieran Greer
 */
public class WsdlModel extends LicasWsdlModel
{
    /** The logger */
    private static Logger logger;


    /** Optional web service name */
    private String name;
    
    /** The local namespace */
    private QName localNamespace;

    /** The xml schema namespace */
    private QName xmlNamespace;

    /** 
     * The services in the model. Keys are the service names while values are 
     * of type WsdlService.
     */
    private HashMap services;

    /**
     * The service messages.
     * Keys are the message names while values are of type WsdlMessage.
     */
    private HashMap messages;

    /**
     * The service bindings.
     * Keys are the binding names while values are of type WsdlBinding.
     */
    private HashMap bindings;

    /**
     * The service ports.
     * Keys are the port names while values are of type WsdlPort.
     */
    private HashMap ports;

    /**
     * The service operations.
     * Keys are the operation names while values are of type WsdlOperation.
     */
    private HashMap operations;

    /** The parameter type descriptions */
    private WsdlTypes wsdlTypes;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(WsdlModel.class.getName());
        logger.setDebug(true);
    }


    /**
     * Create a new instance of WsdlModel.
     */
    public WsdlModel()
    {
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        name = null;
        localNamespace = null;
        xmlNamespace = null;
        services = new HashMap();
        messages = new HashMap();
        bindings = new HashMap();
        ports = new HashMap();
        operations = new HashMap();
        wsdlTypes = null;
    }

    /**
     * Generate and return the appropriate information to call an operation on
     * a web service. This automatically sets the return type and adds the parameter values.
     * @param operationName the name of the operation to call.
     * @return a web service info object with the appropriate values.
     * @throws java.lang.Exception any error.
     */
    public WsMethodInfo getWebServiceInfo(String operationName) throws Exception
    {
        return MethodFactory.createSoapCall(operationName, true, true, this);
    }

    /**
     * Generate and return the appropriate information to call an operation on
     * a web service.
     * @param operationName the name of the operation to call.
     * @param setRtn true if set the return type.
     * @param paramValues if true add the parameter values as {@link WsdlParamInfo} objects.
     * @return a web service info object with the appropriate values.
     * @throws java.lang.Exception any error.
     * @deprecated You should use {@link MethodHandler}.{code createSoapCall} instead.
     */
    private WsMethodInfo getWebServiceInfo(String operationName, boolean setRtn,
            boolean paramValues) throws Exception
    {
        try
        {        
            return MethodFactory.createSoapCall(operationName, setRtn, paramValues, this);
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "getWebServiceInfo", null, ex);
        }
    }
    
    /**
     * Traverse all of the stored operations and convert the related message parts
     * into empty parameter info elements as part of a complete nested structure.
     */
    public void convertMessagesToParameters()
    {
        int i;
        ArrayList opList;                              //list of operations
        WsdlOperation operation;                    //next operation
        
        opList = new ArrayList(operations.values());
        for (i = 0; i < opList.size(); i++)
        {
            operation = (WsdlOperation)opList.get(i);
            operation.messageTypePartsToParams();
        }
    }

    /**
     * Set the web service name.
     * @param thisName the optional web service name.
     */
    public void setName(String thisName)
    {
        name = thisName;
    }

    /**
     * Get the web service name.
     * @return the value of name.
     */
    public String getName()
    {
        return name;
    }

    /**
     * Set the local namespace.
     * @param thisLocalNamespace the local namespace.
     */
    public void setLocalNamespace(QName thisLocalNamespace)
    {
        localNamespace = thisLocalNamespace;
    }
    
    /**
     * Get the local namespace.
     * @return the value of localNamespace.
     */
    public QName getLocalNamespace()
    {
        return localNamespace;
    }
    
    /**
     * Set the xml namespace.
     * @param thisXmlNamespace the xml namespace.
     */
    public void setXmlNamespace(QName thisXmlNamespace)
    {
        xmlNamespace = thisXmlNamespace;
    }

    /**
     * Get the xml namespace.
     * @return the value of xmlNamespace.
     */
    public QName getXmlNamespace()
    {
        return xmlNamespace;
    }
    
    /**
     * Return a list of service names.
     * @return ArrayList a list of service names, of type String.
     */
    public ArrayList getServiceNames()
    {
        if (services != null) return new ArrayList(services.keySet());
        else return null;
    }
    
    /**
     * Add a new service to the model.
     * @param service the service to add.
     * @return true if a new service or false otherwise.
     */
    public boolean addService(WsdlService service)
    {
        String serviceName;                        //service name

        serviceName = service.getName().toLowerCase();

        if (!services.containsKey(serviceName))
        {
            services.put(serviceName, service);
            return true;
        }

        return false;
    }

    /**
     * Get the service with the specified name.
     * @param serviceName the service name.
     * @return the service with the specified name or null if none exist.
     */
    public WsdlService getService(String serviceName)
    {
        serviceName = serviceName.toLowerCase();

        if (services.containsKey(serviceName))
            return (WsdlService)services.get(serviceName);
        else
            return null;
    }

    /**
     * Get all services.
     * @return the value of services.
     */
    public HashMap getServices()
    {
        return services;
    }

    /**
     * Add a new message to the model.
     * @param message the message to add.
     * @return true if a new message or false otherwise.
     */
    public boolean addMessage(WsdlMessage message)
    {
        String messageName;                         //message name

        messageName = message.getName().toLowerCase();
        if (!messages.containsKey(messageName))
        {
            messages.put(messageName, message);
            return true;
        }

        return false;
    }

    /**
     * Get the message with the specified name.
     * @param messageName the message name.
     * @return the message with the specified name or null if none exist.
     */
    public WsdlMessage getMessage(String messageName)
    {
        messageName = messageName.toLowerCase();
        if (messages.containsKey(messageName))
            return (WsdlMessage)messages.get(messageName);
        else
            return null;
    }

    /**
     * Get all messages.
     * @return the value of messages.
     */
    public HashMap getMessages()
    {
        return messages;
    }

    /**
     * Add a new interface object to the model.
     * @param wsdlInterface the interface to add. Could be a port or binding, for example.
     * @return true if a new interface or false otherwise.
     */
    public boolean addInterface(WsdlInterface wsdlInterface)
    {
        if (wsdlInterface instanceof WsdlBinding)
        {
            return addBinding((WsdlBinding)wsdlInterface);
        }
        else if (wsdlInterface instanceof WsdlPort)
        {
            return addPort((WsdlPort)wsdlInterface);
        }

        return false;
    }

    /**
     * Add a new binding to the model.
     * @param binding the binding to add.
     * @return true if a new binding or false otherwise.
     */
    public boolean addBinding(WsdlBinding binding)
    {
        boolean isAdded = false;                    //true if added
        String bindingName;                        //binding name

        //add the binding under both its name and type
        bindingName = binding.getName().toLowerCase();
        if (!bindings.containsKey(bindingName))
        {
            bindings.put(bindingName, binding);
            isAdded = true;
        }

        bindingName = binding.getType().toLowerCase();
        if (!bindings.containsKey(bindingName))
        {
            bindings.put(bindingName, binding);
            isAdded = true;
        }

        return isAdded;
    }

    /**
     * Get the binding with the specified name.
     * @param bindingName the binding name.
     * @return the binding with the specified name or null if none exist.
     */
    public WsdlBinding getBinding(String bindingName)
    {
        bindingName = bindingName.toLowerCase();

        if (bindings.containsKey(bindingName))
        {
            return (WsdlBinding)bindings.get(bindingName);
        }
        else
        {
            bindingName = convertToBindingType(bindingName);

            if (bindings.containsKey(bindingName))
            {
                return (WsdlBinding)bindings.get(bindingName);
            }
        }

        return null;
    }

    /**
     * Get all bindings.
     * @return the value of bindings.
     */
    public HashMap getBindings()
    {
        return bindings;
    }

    /**
     * Add a new port to the model.
     * @param port the port to add.
     * @return true if a new port or false otherwise.
     */
    public boolean addPort(WsdlPort port)
    {
        String portName;                            //port name

        portName = port.getName().toLowerCase();

        if (!ports.containsKey(portName))
        {
            ports.put(portName,port);
            return true;
        }

        return false;
    }

    /**
     * Get the port with the specified name.
     * @param portName the port name.
     * @return the port with the specified name or null if none exist.
     */
    public WsdlPort getPort(String portName)
    {
        WsdlPort returnPort;                    //port to return
        
        returnPort = null;
        portName = portName.toLowerCase();

        if (ports.containsKey(portName))
        {
            returnPort = (WsdlPort)ports.get(portName);
        }
        
        //if name does not match, return first port by default
        if (returnPort == null)
        {
            returnPort = (WsdlPort)(new ArrayList(ports.values())).get(0);
        }

        return returnPort;
    }

    /**
     * Get all pports.
     * @return the value of ports.
     */
    public HashMap getPorts()
    {
        return ports;
    }

    /**
     * Add a new operation to the model.
     * @param operation the operation to add.
     * @return true if a new operation or false otherwise.
     */
    public boolean addOperation(WsdlOperation operation)
    {
        String operationName;                           //operation name

        operationName = operation.getName().toLowerCase();
        if (!operations.containsKey(operationName))
        {
            operations.put(operationName, operation);
            return true;
        }

        return false;
    }

    /**
     * Get the operation with the specified name.
     * @param operationName the operation name.
     * @return the operation with the specified name or null if none exist.
     */
    public WsdlOperation getOperation(String operationName)
    {
        operationName = operationName.toLowerCase();        
        if (operations.containsKey(operationName))
            return (WsdlOperation)operations.get(operationName);
        else
            return null;
    }

    /**
     * Get all operations.
     * @return the value of operations.
     */
    public HashMap getOperations()
    {
        return operations;
    }

    /**
     * Set the parameter type descriptions.
     * @param thisWsdlTypes the type descriptions.
     */
    public void setTypes(WsdlTypes thisWsdlTypes)
    {
        wsdlTypes = thisWsdlTypes;
    }

    /**
     * Get the parameter type descriptions.
     * @return the value of wsdlTypes.
     */
    public WsdlTypes getTypes()
    {
        return wsdlTypes;
    }

    /**
     * Return true if the tag indicates an interface element.
     * @param elementName the element name.
     * @return true if an interface element.
     */
    public static boolean isInterface(String elementName)
    {
        return (elementName.equalsIgnoreCase(WsdlConst.BINDING) ||
                elementName.equalsIgnoreCase(WsdlConst.PORTTYPE) ||
                elementName.equalsIgnoreCase(WsdlConst.INTERFACE));
    }

    /**
     * Convert the port name to a port type tag.
     * @param portName the port name.
     * @return the name converted to the appropriate tag value.
     */
    public static String createPortTypeTag(String portName)
    {
        return (portName + WsdlConst.TYPE).toLowerCase();
    }

    /**
     * Convert the binding name to a binding type tag.
     * @param bindingName the binding name.
     * @return the name converted to the appropriate tag value.
     */
    public static String convertToBindingType(String bindingName)
    {
        return (bindingName + WsdlConst.TYPE).toLowerCase();
    }
}
