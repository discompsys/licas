/*
 * WsdlEndpointParser.java
 *
 * Created on 25 June 2009
 *
 * Version 1.0.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws.wsdl.parse;


import org.licas.ws.wsdl.WsdlConst;
import org.licas.ws.wsdl.*;
import org.licas.ws.wsdl.model.*;

import org.jlog2.*;
import org.licas_xml.abs.*;

import java.util.*;
import org.jlog2.exception.ExceptionHandler;
import org.licas.ws.WsFactory;


/**
 * This class can be used to parse an endpoint to its Java equivalent.
 * This is from a WSDL script description and not from other Java objects.
 * @author Kieran Greer
 */
public class WsdlEndpointParser
{
    /** The logger */
    private static Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(WsdlEndpointParser.class.getName());
        logger.setDebug(true);
    }


    /**
     * Create a new instance of WsdlEndpointParser.
     */
    public WsdlEndpointParser()
    {}

    /**
     * Parse the element to retrieve the service endpoint information.
     * @param rootElem the root element for the endpoint information.
     * @return the parsed endpoint.
     * @throws java.lang.Exception any error.
     */
    public WsdlEndpoint parse(Element rootElem) throws Exception
    {
        int i;
	String name;                                //name
        String type;                                //endpoint type
        String binding;                             //binding
        String address;                             //address
        WsdlEndpoint endPoint;                      //next endpoint
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Vector elemList;                              //element list


        try
        {
            endPoint = null;

            type = rootElem.getName();
            name = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.NAME));
            binding = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.BINDING));
            address = null;

            elemList = rootElem.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);

                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;
                    if (WsFactory.removePrefix(nextElem.getName()).equals(WsdlConst.ADDRESS))
                    {
                        address = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.LOCATION));
                    }
                }
            }

            if ((name != null) && !name.equals("") &&
                (address != null) && !address.equals(""))
            {
                endPoint = new WsdlEndpoint(name, type, binding, address);
            }
            
            return endPoint;
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parse", null, ex);            
            
            if (logger.getDebug())
            {
                LoggerHandler.debugMessage(logger, LoggerHandler.ERROR , "parse", null);
                LoggerHandler.debugError(logger, LoggerHandler.ERROR , ex);
            }

            throw ex;
        }
    }
}
