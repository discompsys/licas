/**
 * Parsers for the different WSDL sections.
 */
package org.licas.ws.wsdl.parse;