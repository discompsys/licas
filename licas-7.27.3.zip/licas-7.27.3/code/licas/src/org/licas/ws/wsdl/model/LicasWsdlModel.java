/*
 * LicasWsdlModel.java
 *
 * Created on 4 May 2016
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.ws.wsdl.model;


/**
 * This is an empty base class to allow for compatibility with the licas soap package.
 * @author Kieran Greer
 */
public abstract class LicasWsdlModel
{
    
}
