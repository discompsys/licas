/*
 * WebSoapService.java
 *
 * Created on 20 April 2012
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws.soap;


import org.licas.call.CallObject;
import org.licas.call.client.Rest_MethodHandler;
import org.licas.ws.WsMethodInfo;
import org.licas.ws.wsdl.model.*;
import org.licas.ws.wsdl.WsdlConst;
import org.licas.util.ObjectHandler;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.util.*;
import org.licas.call.client.CallHandler;
import org.licas.parsers.WebServiceMethodInfoParser;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;



/**
 * Can be used to make calls to web services using the SOAP protocol from licas objects.
 * @author Kieran Greer
 */
public class WebSoapService
{
    /** The logger */
    private static Logger logger;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(WebSoapService.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Create a new instance of CallWebService.
     * @throws java.lang.Exception any error.
     */
    public WebSoapService() throws Exception
    {}
    
    /**
     * Make a web service call using the selected values. In this case, the 
     * parameter values are retrieved from a wsdl operation object and added to
     * the method description.
     * @param commProtocol the communication protocol type - HTTP, POST, GET
     * @param wsdlOperation the selected operation description.
     * @param webServiceInfo the constructed method info.
     * @return the soap message reply from making the call. This can also be an
     * error message, so return an Object here and cast in calling method.
     * @throws java.lang.Exception any error.
     */
    public Object webServiceCall(String commProtocol, WsdlOperation wsdlOperation,
            WsMethodInfo webServiceInfo) throws Exception
    {
        int i, j;
        ArrayList params;                           //list of parameters
        ArrayList paramHolder;                      //parameter holder
        HashMap paramsSet;                          //set of parameters
        WsdlParamInfo wsdlParameter;                //wsdl parameter
        
        try
        {
            if (webServiceInfo != null)
            {
                paramsSet = wsdlOperation.getInParams(commProtocol);  
                if (paramsSet != null)
                {
                    params = new ArrayList(paramsSet.values());
                    if (!params.isEmpty())
                    {
                        for (i = 0; i < params.size(); i++)
                        {
                            paramHolder = new ArrayList();
                            wsdlParameter = (WsdlParamInfo)params.get(i);
                            if (!ObjectHandler.isNull(wsdlParameter.getValue()))
                                paramHolder.add(wsdlParameter);
                            
                            paramHolder = removeNullValues(paramHolder, wsdlParameter);
                            for (j = 0; j < paramHolder.size(); j++)
                            {
                                wsdlParameter = (WsdlParamInfo)paramHolder.get(j);
                                if (webServiceInfo.getParameter(wsdlParameter.getName()) != null)
                                {
                                    webServiceInfo.getParameter(wsdlParameter.getName()).setValue(wsdlParameter.getValue(), false);
                                }
                                else
                                {
                                    webServiceInfo.addParam(wsdlParameter);
                                }
                            }
                        }
                    }
                    
                    //make the call, with some final checks
                    return soapRpcCall(commProtocol, webServiceInfo);
                }
            }
            
            return null;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "webServiceCall",
                null, ex);
        }
    }
    
    /**
     * Make a web service call using the selected values. In this case, the 
     * parameter values are already stored in the method description.
     * @param commProtocol the communication protocol type - Soap, Rest or WSRPC
     * @param webServiceInfo the constructed method info.
     * @return the soap message reply from making the call. This can also be an
     * error message, so return an Object here and cast in calling method.
     * @throws java.lang.Exception any error.
     */
    public Object webServiceCall(String commProtocol, WsMethodInfo webServiceInfo) 
        throws Exception
    {
        if (commProtocol.equalsIgnoreCase(WsdlConst.REST))
        {
            return restCall(webServiceInfo);
        }
        else
        {
            return soapRpcCall(commProtocol, webServiceInfo);
        }
    }
    
    /**
     * Make a web service call using the selected values. In this case, the 
     * parameter values are retrieved from a wsdl operation object and added to
     * the method description.
     * @param commProtocol the communication protocol type - Soap or WSRPC.
     * @param webServiceInfo the constructed method info.
     * @return the soap message reply from making the call. This can also be an
     * error message, so return an Object here and cast in calling method.
     * @throws java.lang.Exception any error.
     */
    protected Object soapRpcCall(String commProtocol, WsMethodInfo webServiceInfo) 
        throws Exception
    {        
        CallObject callObject;                      //call object
        
        try
        {
            callObject = new CallObject();           
            if (webServiceInfo != null)
            {
                //after setting values, a RPC protocol needs value type to be correct
                //whereas soap can use all strings, so update that as well
                if (CallHandler.isSOAP(webServiceInfo.getCallType()))
                {
                    webServiceInfo.checkParamValues();
                }
                
                return callObject.call(webServiceInfo);
            }
            
            return null;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "soapRpcCall",
                null, ex);
        }
    }
    
    /**
     * Make a web service call using the selected values. In this case, the 
     * parameter values are retrieved from a wsdl operation object and added to
     * the method description.
     * @param webServiceInfo the constructed method info - gets converted to a REST
     * message first.
     * @return the rest message reply from making the call. This can also be an
     * error message, so return an Object here and cast in calling method.
     * @throws java.lang.Exception any error.
     */
    protected Object restCall(WsMethodInfo webServiceInfo) 
        throws Exception
    {  
        try
        {
            return (new Rest_MethodHandler()).execute(webServiceInfo);
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "restCall",
                null, ex);
        }
    }
    
    /**
     * Remove any parameters with null values.
     * @param paramHolder to store valid parameters in.
     * @param rootParam the parameter to parse from.
     * @return a new list of parameters without the null ones.
     */
    protected ArrayList removeNullValues(ArrayList paramHolder, WsdlParamInfo rootParam)
    {
        int i;
        boolean addToHolder;                        //true if add directly to the holder
        ArrayList childList;                           //child parameter list
        WsdlParamInfo paramInfo;                    //param info
        
        //not recursive - only parses to a further depth of 1
        addToHolder = paramHolder.isEmpty();
        
        childList = rootParam.getChildElements();        
        for (i = 0; i < childList.size(); i++)
        {
            paramInfo = (WsdlParamInfo)childList.get(i);
            if (!ObjectHandler.isNull(paramInfo.getValue()))
            {
                if (addToHolder) paramHolder.add(paramInfo);
            }
        }
        
        return paramHolder;
    }
}
