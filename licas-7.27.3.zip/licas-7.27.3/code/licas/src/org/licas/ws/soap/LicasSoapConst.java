/*
 * SoapConst
 *
 * Created on 15 June 2009
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.ws.soap;


/**
 * This class stores basic types for local wsdl interactions. It is extended in the
 * licas soap package.
 * @author Kieran Greer.
 */
public class LicasSoapConst
{
    /**Indicate a type.*/
    public static final String TYPE = "type";

    /**Indicate an array.*/
    public static final String ARRAYOF = "ArrayOf";

    /**Indicate start of array dimension.*/
    public static final String ARRAYDIM = "[";

    /**Indicate end of array dimension.*/
    public static final String ENDDIM = "[";

    /**Indicate another dimension in an array.*/
    public static final String ANOTHERDIM = ",";

    /**Prefix separator tag.*/
    public static final String SEP = ":";
}
