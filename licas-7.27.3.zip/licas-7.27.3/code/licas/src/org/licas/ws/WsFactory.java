/*
 * WsFactory.java
 *
 * Created on 4 May 2016.
 *
 * Version 1.1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws;


import org.licas.call.MethodInfo;
import org.licas.ws.soap.LicasSoapConst;
import org.licas.ws.soap.Soap_BaseHandler;
import org.licas.ws.wsdl.WsdlConst;
import org.licas.ws.wsdl.model.LicasWsdlModel;
import org.licas.ws.wsdl.model.WsdlParamInfo;
import org.licas_internet.util.HttpConst;

import java.util.ArrayList;


/**
 * Factory object for web services. You must set an instance of this in your main
 * program using the {@code setInstance} method. Your instance should extend {@link Soap_BaseHandler}.
 * @author Kieran Greer
 */
public abstract class WsFactory
{
    /** The web service factory instance */
    private static volatile WsFactory instance = null;
    
    /**
     * Return true if an instance of the factory has been set.
     * @return true if instance is not null.
     */
    public static boolean hasInstance()
    {
        return (instance != null);
    }
    
    /**
     * Set the web service factory instance if null.
     * @param thisInstance the factory instance.
     */
    public static void setInstance(WsFactory thisInstance)
    {
        if (instance == null) {
            instance = thisInstance;
        }
    }
    
    /**
     * Get the web service factory instance.
     * @return the value of instance.
     */
    public static WsFactory getInstance()
    {
        return instance;
    }
    
    /**
     * Create and return a method info object for invoking a web service using the SOAP protocol.
     * @param operationName the name of the operation to call.
     * @param setRtn true if set the return Object type.
     * @param paramValues if true add the parameter values as {@link WsdlParamInfo} objects.
     * @param lWsdlModel the wsdl model that stores the description.
     * @return a web service info object with the appropriate values.
     * @throws java.lang.Exception any error.
     */
    public abstract WsMethodInfo createSoapCall(String operationName, boolean setRtn,
            boolean paramValues, LicasWsdlModel lWsdlModel) throws Exception;
    
    /**
     * Create and return a method info object for invoking a web service using the SOAP protocol.
     * @param webService the service name.
     * @param operation the name of the operation to call.
     * @param endpointAddress the server endpoint address.
     * @param soapActionUri soap action uri type.
     * @param namespace ontology namespace.
     * @param parameters list of {@link WsdlParamInfo} objects that store parameter types and values.
     * @param setRtn true if set the return Object type.
     * @return a web service info object with the appropriate values.
     * @throws java.lang.Exception any error.
     */
    public abstract WsMethodInfo createSoapCall(String webService, String operation, String endpointAddress,
        String soapActionUri, String namespace, ArrayList<WsdlParamInfo> parameters, boolean setRtn) throws Exception;
    
    
    /**
     * Create the client soap method handler.
     * @return a soap handler derived from {@link Soap_BaseHandler}.
     */
    public abstract Soap_BaseHandler createSoapMethodHandler();
    
    /**
     * Required by some string-based requests, to convert them back into the method 
     * info object. A script might require parsing from a string, for example.
     * @param method the method name.
     * @param descr the method call description.
     * @return the related method info object.
     * @throws java.lang.Exception any error.
     */
    public abstract WsMethodInfo toMethodInfo(String method, String descr) throws Exception;
        
    /**
     * Convert the method info into a Web-Service type equivalent.
     * @param methodInfo the method info to convert.
     * @return the same information in a WsMethodInfo object.
     * @throws java.lang.Exception any error.
     */
    public static WsMethodInfo toMethodInfo(MethodInfo methodInfo) throws Exception
    {
        WsMethodInfo wsMethodInfo;              //web-service version
        
        wsMethodInfo = new WsMethodInfo();
        wsMethodInfo.copyValues(methodInfo);
        
        return wsMethodInfo;
    }
    
    /**
     * Return the String value with the namespace prefix removed.
     * @param prefix the namespace prefix.
     * @param value the value for which the prefix should be removed
     * @return the value with the namespace prefix removed
     */
    public static String addPrefix(String prefix, String value)
    {
        return (prefix + LicasSoapConst.SEP + value);
    }

    /**
     * Return the String value with the namespace prefix removed.
     * @param value the value for which the prefix should be removed
     * @return the value with the namespace prefix removed
     */
    public static String removePrefix(String value)
    {
        int index;				//position of prefix separator
        String rtnValue;			//return value

        rtnValue = null;
        if (value != null)
        {
            if (!isStartURI(value))
            {
                index = value.indexOf(WsdlConst.NAMESPACESEPARATOR);

                if (index > -1)
                    rtnValue = value.substring(index+1);
                else
                    rtnValue = value;
            }
            else
            {
                rtnValue = value;
            }
        }

        return rtnValue;
    }
    
        /**
     * Return true if the uri starts with a protocol indicator.
     * @param uri the uri string.
     * @return true if prefix indicates a remote uri protocol.
     */
    private static boolean isStartURI(String uri)
    {
        return (HttpConst.startsWithHttp(uri));
    }
}
