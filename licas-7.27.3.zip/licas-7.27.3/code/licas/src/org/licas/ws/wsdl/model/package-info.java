/**
 * For compatibility with the soap package, the parameter info is local here.
 */
package org.licas.ws.wsdl.model;