/*
 * WsdlBinding.java
 *
 * Created on 23 June 2009
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.ws.wsdl.model;


/**
 * This class stores service binding details.
 * @author Kieran Greer
 */
public class WsdlBinding extends WsdlInterface
{
    /** The binding style */
    private String style;

    /** The binding type */
    private String type;

    /** The binding transport */
    private String transport;

    /**
     * Create a new instance of WsdlBinding.
     * @param thisName the port name.
     */
    public WsdlBinding(String thisName)
    {
        super(thisName);
        initialise();
    }

    /**
     * Initialise some values.
     */
    private void initialise()
    {
        style = null;
        type = null;
        transport = null;
    }

    /**
     * Set the style for the binding.
     * @param thisStyle the style type.
     */
    public void setStyle(String thisStyle)
    {
        style = thisStyle;
    }

    /**
     * Get the binding style.
     * @return the value of style.
     */
    public String getStyle()
    {
        return style;
    }

    /**
     * Set the type for the binding.
     * @param thisType the binding type.
     */
    public void setType(String thisType)
    {
        type = thisType;
    }

    /**
     * Get the binding type.
     * @return the value of type.
     */
    public String getType()
    {
        return type;
    }

    /**
     * Set the transport uri for the binding.
     * @param thisTransport the transport uri.
     */
    public void setTransport(String thisTransport)
    {
        transport = thisTransport;
    }

    /**
     * Get the binding transport uri.
     * @return the value of transport.
     */
    public String getTransport()
    {
        return transport;
    }
}
