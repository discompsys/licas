/*
 * WsMethodInfo.java
 *
 * Created on 15 June 2009
 *
 * Version 1.4
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws;

import org.jlog2.util.StringHandler;
import org.licas.call.MethodInfo;
import org.licas.call.ParamInfo;
import org.licas.util.Const;
import org.licas.util.ObjectHandler;
import org.licas.ws.wsdl.WsdlConst;
import org.licas.ws.wsdl.model.WsdlParamInfo;

import java.io.Serializable;
import java.util.ArrayList;


/**
 * This class stores some specific details required to make a Web Service call, such as
 * the web service name, or uri, etc. This version extends the {@link MethodInfo} class used in
 * licas to store all required information for a remote method call.
 * @author Kieran Greer
 */
public class WsMethodInfo extends MethodInfo implements Serializable
{
    /**A username for a private web service.*/
    private String wsUsername;
    
    /**A password for a private web service.*/
    private String wsPassword;
    
    /**The web service providing the service.*/
    private String soapWebService;

    /**The endpoint address for the soap web service.*/
    private String soapEndpointAddress;

    /**The soap action uri.*/
    private String soapActionUri;

    /**The soap body namespace.*/
    private String namespace;
    
    //optional entries if running own web service
    /** The web service name - final part in URI */
    public static final int NAME = (int)0;
    
    /** The target namespace address - also the class path reversed */
    public static final int TARGETNS = (int)1;
    
    /** The class path for any classes */
    public static final int PATH = (int)2;
    
    /** List of additional values for a locally run (on licas) web service */
    private String[] localWS;


    /**
     * Create a WsMethodInfo object with dummy values.
     * @throws java.lang.Exception any error.
     */
    public WsMethodInfo() throws Exception
    {
        super();
        initialise();
    }

    /**
     * Create a WsMethodInfo object with the parameters passed in.
     * @param thisCallType the protocol type, can be {@link Const}.{@code REST} or {@code SOAP}.
     * @param thisWebService the web service name.
     * @param thisOperation the global operation name.
     * @param thisEndpointAddress the web service location.
     * @param thisSoapActionUri the soap action location.
     * @param thisNamespace the soap namespace.
     * @param thisLocalWS optional set of parameters for a locally running Web Service, RPC type.
     * This can be empty for a remote (not on licas) service.
     * @param thisParameters the operation parameter values. Should be of type {@link WsdlParamInfo}.
     * @throws java.lang.Exception any error.
     */
    public WsMethodInfo(String thisCallType, String thisWebService, String thisOperation, String thisEndpointAddress,
        String thisSoapActionUri, String thisNamespace, String[] thisLocalWS, ArrayList thisParameters) throws Exception
    {
        super();
        
        initialise();
        setCallType(thisCallType);
        setName(thisOperation);
        soapWebService = thisWebService;
        soapEndpointAddress = thisEndpointAddress;
        soapActionUri = thisSoapActionUri;
        namespace = thisNamespace;
        if (thisParameters != null) params = thisParameters;  
        localWS = thisLocalWS;
    }

    
    /** Initialise some values */
    private void initialise()
    {
        wsUsername = null;
        wsPassword = null;
        soapWebService = null;
        soapEndpointAddress = null;
        soapActionUri = null;
        namespace = null;
        localWS = null;
		
        setRtnType(Object.class.getName());
    }
    
        
    /**
     * Configure the method info to include the definition for a locally run web service.
     */
    public void configLocalWS()
    {
        int i;
        String nextValue;                   //next value
        String classpath;                   //path
        ArrayList tokens;                      //parsed path
        
        localWS = new String[3];
        localWS[0] = getSoapWebService();
        
        classpath = namespace;
        localWS[1] = classpath;
        
        classpath = classpath.substring(classpath.indexOf("//")+2, classpath.length()-1);
        tokens = StringHandler.tokenize(classpath, ".", false);
        for (i = (tokens.size()-1); i >= 0; i--)
        {
            nextValue = (String)tokens.get(i);
            if (i == (tokens.size()-1)) classpath = nextValue;
            else classpath += ("." + nextValue);
        }
        
        localWS[2] = classpath;
    }
    
    /** 
     * Change each parameter from a string into its actual type, required for RPC web service call.
     * @throws java.lang.Exception any error.
     */
    public void checkParamValues() throws Exception
    {
        int i;
        String paramType;                       //param type
        String paramValue;                      //param value
        Object paramObj;                        //might not be ws param
        WsdlParamInfo paramInfo;                //param info
        WsdlParamInfo newParamInfo;             //param info
        ArrayList paramList;                    //new param list
        Object objValue;                        //param value
        
        if (!params.isEmpty())
        {
            paramList = new ArrayList();
            for (i = 0; i < params.size(); i++)
            {
                paramObj = params.get(i);
                if (paramObj instanceof WsdlParamInfo) {
                    paramInfo = (WsdlParamInfo) params.get(i);
                }
                else {
                    paramInfo = new WsdlParamInfo();
                    paramInfo.fromElement(((ParamInfo)paramObj).toElement());
                    paramInfo.setInOut(WsdlConst.INPUT);
                }

                paramType = paramInfo.getType();
                objValue = paramInfo.getValue();
                if (ObjectHandler.isString(objValue))
                {
                    paramValue = (String)objValue;
                    objValue = ObjectHandler.valueFromString(paramType, paramValue);
                }
                
                newParamInfo = new WsdlParamInfo();
                newParamInfo.setName(paramInfo.getName());
                newParamInfo.setInOut(paramInfo.getInOut());
                newParamInfo.setNamespace(paramInfo.getNamespace());
                newParamInfo.setType(paramType);
                newParamInfo.setValue(objValue);
                paramList.add(newParamInfo);
            }
            
            params = paramList;
        }
    }
    
    /**
     * Get the private web service username.
     * @return the value of wsUsername.
     */
    public String getWsUsername()
    {
        return wsUsername;
    }

    /**
     * Set the private web service username.
     * @param thisUsername a private web service wsUsername
     */
    public void setWsUsername(String thisUsername)
    {
        wsUsername = thisUsername;
    }
    
    /**
     * Get the private web service password.
     * @return the value of wsPassword.
     */
    public String getWsPassword()
    {
        return wsPassword;
    }

    /**
     * Set the private web service password.
     * @param thisPassword for access to a private web service.
     */
    public void setWsPassword(String thisPassword)
    {
        wsPassword = thisPassword;
    }

    /**
     * Get the web service name.
     * @return the value of soapWebService.
     */
    public String getSoapWebService()
    {
        return soapWebService;
    }

    /**
     * Set the web service name.
     * @param thisSoapWebService the soap web service name.
     */
    public void setSoapWebService(String thisSoapWebService)
    {
        soapWebService = thisSoapWebService;
    }

    /**
     * Get the endpoint address.
     * @return value of soapEndpointAddress.
     */
    public String getSoapEndpointAddress()
    {
        return soapEndpointAddress;
    }

    /**
     * Set the endpoint address.
     * @param thisSoapEndpointAddress the web service location.
     */
    public void setSoapEndpointAddress(String thisSoapEndpointAddress)
    {
        soapEndpointAddress = thisSoapEndpointAddress;
    }

    /**
     * Get the soap action address.
     * @return value of soapActionUri.
     */
    public String getSoapActionUri()
    {
        return soapActionUri;
    }

    /**
     * Set the soap action address.
     * @param thisSoapActionUri the soap action location.
     */
    public void setSoapActionUri(String thisSoapActionUri)
    {
        soapActionUri = thisSoapActionUri;
    }

    /**
     * Get the namespace address.
     * @return the value of namespace.
     */
    public String getNamespace()
    {
        return namespace;
    }

    /**
     * Set the namespace address to the value passed in.
     * @param thisNamespace the namespace address.
     */
    public void setNamespace(String thisNamespace)
    {
        namespace = thisNamespace;
    }

    /**
     * Get a list of additional values for a locally run (on licas) web service.
     * @return the value of localWS.
     */
    public String[] getLocalWS()
    {
        return localWS;
    }
    
    /**
     * Set the local web service values.
     * @param thisLocalWS the local web service definition set.
     */
    public void setLocalWS(String[] thisLocalWS)
    {
        localWS = thisLocalWS;
    }
    
    /**
     * Get a String representation of this object.
     * @return a String-based description of this object.
     */
    public String toString()
    {
        String infoStr;                     //info as a String

        infoStr = "Web service: " + soapWebService;
        if (wsUsername != null) infoStr += "\nUsername: " + wsUsername;
        if (wsPassword != null) infoStr += "\nPassword: " + wsPassword;
        infoStr += "\nOperation: " + getName();
        infoStr += "\nEndpoint address: " + soapEndpointAddress;
        infoStr += "\nSoap action: " + soapActionUri;
        infoStr += "\nNamespace: " + namespace;
        infoStr += "\nReturn type: " + getRtnType();
        if (localWS != null) infoStr += ("\n" + String.valueOf(localWS));

        return infoStr;
    }
}