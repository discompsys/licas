/*
 * WsdlInterfaceParser.java
 *
 * Created on 25 June 2009
 *
 * Version 1.0.4
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.ws.wsdl.parse;


import org.licas.ws.wsdl.WsdlConst;
import org.licas.ws.wsdl.model.*;

import org.jlog2.*;
import org.licas_xml.abs.*;

import java.util.*;
import org.jlog2.exception.ExceptionHandler;
import org.licas.ws.WsFactory;


/**
 * This class can be used to parse an interface to its Java equivalent.
 * This is from a WSDL script description and not from other Java objects.
 * @author Kieran Greer
 */
public class WsdlInterfaceParser
{
    /** The logger */
    private static Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(WsdlInterfaceParser.class.getName());
        logger.setDebug(true);
    }


    /**
     * Create a new instance of WsdlInterfaceParser.
     */
    public WsdlInterfaceParser()
    {}

    /**
     * Parse the element to retrieve the interface information.
     * @param rootElem the root element for the interface information.
     * @param wsdlModel the wsdl model.
     * @throws java.lang.Exception any error.
     */
    public void parse(Element rootElem, WsdlModel wsdlModel) throws Exception
    {
        int i;
        String name;                                //name
        String type;                                //type
        String style;                               //style
        String transport;                           //transport
        WsdlInterface wsdlInterface;                //wsdl interface
        WsdlOperationParser operationParser;        //operation parser
        WsdlFaultParser faultParser;                //fault parser
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Vector elemList;                            //element list

        try
        {
            wsdlInterface = null;
            operationParser = new WsdlOperationParser();
            faultParser = new WsdlFaultParser();

            name = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.NAME));
            type = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.TYPE));

            if ((name != null) && !name.equals(""))
            {
                if (WsFactory.removePrefix(rootElem.getName()).equals(WsdlConst.BINDING))
                {
                    wsdlInterface = new WsdlBinding(name);

                    if ((type != null) && !type.equals(""))
                        ((WsdlBinding)wsdlInterface).setType(type);
                }
                else if (WsFactory.removePrefix(rootElem.getName()).equals(WsdlConst.PORTTYPE) ||
                        WsFactory.removePrefix(rootElem.getName()).equals(WsdlConst.INTERFACE))
                {
                    wsdlInterface = new WsdlPort(name);
                }

                elemList = rootElem.getChildren();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextNode = (Node)elemList.get(i);

                    if (nextNode instanceof Element)
                    {
                        nextElem = (Element)nextNode;

                        if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.BINDING))
                        {
                            style = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.STYLE));
                            if (style == null) style = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.STYLE));
                            transport = WsFactory.removePrefix(rootElem.getAttributeValue(WsdlConst.TRANSPORT));
                            if (transport == null) transport = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.TRANSPORT));

                            if ((style != null) && !style.equals(""))
                                ((WsdlBinding)wsdlInterface).setStyle(style);

                            if ((transport != null) && !transport.equals(""))
                                ((WsdlBinding)wsdlInterface).setTransport(transport);
                        }
                        else if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.OPERATION))
                        {
                            name = WsFactory.removePrefix(nextElem.getAttributeValue(WsdlConst.NAME));

                            if ((name != null) && !name.equals(""))
                            {
                                wsdlInterface.addOperation(name);
                                operationParser.parse(nextElem, wsdlModel);
                            }
                        }
                        else if (WsFactory.removePrefix(nextElem.getName()).equalsIgnoreCase(WsdlConst.FAULT))
                        {
                            wsdlInterface.setFault(faultParser.parse(nextElem));
                        }
                    }
                }
            }
            
            wsdlModel.addInterface(wsdlInterface);
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parse", null, ex);            
            
            if (logger.getDebug())
            {
                LoggerHandler.debugMessage(logger, LoggerHandler.ERROR , "parse", null);
                LoggerHandler.debugError(logger, LoggerHandler.ERROR , ex);
            }

            throw ex;
        }
    }
}
