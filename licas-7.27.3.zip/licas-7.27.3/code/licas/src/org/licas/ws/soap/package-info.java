/**
 * For processing Web service calls using the SOAP protocol.
 */
package org.licas.ws.soap;