/*
 * WsdlPort.java
 *
 * Created on 23 June 2009
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.ws.wsdl.model;


/**
 * This class stores details for a single port type relating to a specific service.
 * @author Kieran Greer
 */
public class WsdlPort extends WsdlInterface
{
    /**
     * Create a new instance of WsdlPort.
     * @param thisName the port name.
     */
    public WsdlPort(String thisName)
    {
        super(thisName);
    }
}
