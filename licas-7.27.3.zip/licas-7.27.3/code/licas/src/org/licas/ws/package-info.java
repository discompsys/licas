/**
 * Web service parsers and processors.
 */
package org.licas.ws;