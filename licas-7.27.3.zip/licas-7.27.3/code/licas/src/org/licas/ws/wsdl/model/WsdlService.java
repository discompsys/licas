/*
 * WsdlService.java
 *
 * Created on 16 June 2009
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.ws.wsdl.model;


import org.licas.ws.wsdl.WsdlConst;

import java.util.*;
import org.licas.ws.WsFactory;


/**
 * This class stores information on a single Web Service service call.
 * @author Kieran Greer
 */
public class WsdlService
{
    /** The service name */
    private String name;

    /** Service description */
    private String documentation;

    /** The service interface */
    private String serviceInterface;

    /** A list of service endpoints. Keys are the endpoint names while values
     * are of type WsdlEndpoint.
     */
    private HashMap endPoints;

    /** The list of port names */
    private ArrayList portNames;


    /**
     * Create a new instance of WsdlService.
     * @param thisName the service name.
     */
    public WsdlService(String thisName)
    {
        name = WsFactory.removePrefix(thisName);
        initialise();
    }

    /**
     * Initialise some values.
     */
    private void initialise()
    {
        documentation = null;
        serviceInterface = null;
        endPoints = new HashMap();
        portNames = new ArrayList();
    }

    /**
     * Get the service name.
     * @return the value of name.
     */
    public String getName()
    {
        return name;
    }

    /**
     * Set the description of the service.
     * @param theDocumentation the service documentation.
     */
    public void setDocumentation(String theDocumentation)
    {
        documentation = theDocumentation;
    }

    /**
     * Get the service documentation.
     * @return the value of documentation.
     */
    public String getDocumentation()
    {
        return documentation;
    }

    /**
     * Set the service interface value.
     * @param thisServiceInterface the interface value.
     */
    public void setServiceInterface(String thisServiceInterface)
    {
        serviceInterface = thisServiceInterface;
    }

    /**
     * Get the service interface.
     * @return the value of serviceInterface.
     */
    public String getServiceInterface()
    {
        return serviceInterface;
    }

    /**
     * Add a new endpoint to the service.
     * @param endPoint the endpoint to add.
     * @return true if a new endpoint or false otherwise.
     */
    public boolean addEndPoint(WsdlEndpoint endPoint)
    {
        String endpointName;                        //endpoint name

        endpointName = endPoint.getName().toLowerCase();

        if (!endPoints.containsKey(endpointName))
        {
            endPoints.put(endpointName, endPoint);

            if (endPoint.getType().equals(WsdlConst.PORT))
            {
                addPortName(endPoint.getName());
            }

            return true;
        }

        return false;
    }
    
    /**
     * Get the endpoint with the specified name.
     * @param endpointName the endpoint name.
     * @return the endpoint with the specified name or null if none exist.
     */
    public WsdlEndpoint getEndPoint(String endpointName)
    {
        endpointName = endpointName.toLowerCase();

        if (endPoints.containsKey(endpointName))
            return (WsdlEndpoint)endPoints.get(endpointName);
        else
            return null;
    }

    /**
     * Get all endpoints.
     * @return the value of endPoints.
     */
    public HashMap getEndpoints()
    {
        return endPoints;
    }

    /**
     * Add the port name to the list of port names.
     * @param portName the port name to add.
     */
    private void addPortName(String portName)
    {
        portNames.add(portName);
    }

    /**
     * Get the list of port names.
     * @return the value of portNames.
     */
    public ArrayList getPortNames()
    {
        return portNames;
    }
}
