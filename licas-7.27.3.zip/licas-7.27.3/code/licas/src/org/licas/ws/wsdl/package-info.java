/**
 * For compatibility with the soap package, some values are required here.
 */
package org.licas.ws.wsdl;