/*
 * WsdlMessage.java
 *
 * Created on 26 June 2009
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws.wsdl.model;


import java.util.*;


/**
 * This class can be used ot store wsdl message information.
 * @author Kieran Greer
 */
public class WsdlMessage
{
    /** The message name */
    private String name;

    /** Message type */
    private String type;

    /** Message documentation */
    private String documentation;

    /** The message part element */
    private String partElement;

    /** Stores the message part entries. Of type WsdlMessage */
    private ArrayList messageParts;


    /**
     * Create a new instance of WsdlMessage.
     * @param thisName the message name.
     */
    public WsdlMessage(String thisName)
    {
        name = thisName;
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        type = null;
        documentation = null;
        partElement = null;
        messageParts = new ArrayList();
    }

    /**
     * This represents a simple or a complex parameter type, as follows:<br>
     * 1. If the type is not null return this.<br>
     * 2. Otherwise if the element part name is not null return this.<br>
     * 3. Otherwise if the first message part is not null return the name from that.<br>
     * @return the value of type first, or element if null.
     */
    public String getTypeElement()
    {
        String typeName;                    //parameter type name
        WsdlMessage messagePart;            //message part

        typeName = type;
        if (typeName == null) 
        {
            typeName = partElement;
        }
        if (typeName == null)
        {
            if (!messageParts.isEmpty())
            {
                messagePart = (WsdlMessage)messageParts.get(0);
                typeName = messagePart.getTypeElement();
            }
        }
        
        return typeName;
    }
    
    /**
     * Get the message name.
     * @return the value of name.
     */
    public String getName()
    {
        return name;
    }

    /**
     * Set the message part type.
     * @param thisType the message part type.
     */
    public void setType(String thisType)
    {
        type = thisType;
    }

    /**
     * Get the message part type.
     * @return the value of type.
     */
    public String getType()
    {
        return type;
    }

    /**
     * Set the message documentation.
     * @param thisDocumentation the message documentation.
     */
    public void setDocumentation(String thisDocumentation)
    {
        documentation = thisDocumentation;
    }

    /**
     * Get the message documentation.
     * @return the value of documentation.
     */
    public String getDocumentation()
    {
        return documentation;
    }

    /**
     * Set the message part element.
     * @param thisPartElement the message part element.
     */
    public void setPartElement(String thisPartElement)
    {
        partElement = thisPartElement;
    }

    /**
     * Get the message part element.
     * @return the value of partElement.
     */
    public String getPartElement()
    {
        return partElement;
    }

    /**
     * Set the message part entries.
     * @param theMessageParts the part entries, of type WsdlMessage.
     */
    public void setMessageParts(ArrayList theMessageParts)
    {
        messageParts = theMessageParts;
    }

    /**
     * Add a new part entry to the message.
     * @param messagePart the entry to add.
     */
    public void addMessagePart(WsdlMessage messagePart)
    {
        messageParts.add(messagePart);
    }

    /**
     * Get the message part entries.
     * @return the value of messageParts.
     */
    public ArrayList getMessageParts()
    {
        return messageParts;
    }

    /**
     * Get a string-based description of this message part.
     * @return the contents in string format.
     */
    public String toString()
    {
        int i;
        String messageStr;                              //description as a string
        WsdlMessage messagePart;                        //message part

        messageStr = ("\nName: " + name);
        messageStr += ("\nType: " + type);
        messageStr += ("\nDocumentation: " + documentation);
        messageStr += ("\nPart element: " + partElement);

        for (i = 0; i < messageParts.size(); i++)
        {
            messagePart = (WsdlMessage)messageParts.get(i);
            messageStr += ("\nMessage part:");
            messageStr += messagePart.toString();
        }

        return messageStr;
    }
}
