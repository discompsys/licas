/*
 * WsdlInterface.java
 *
 * Created on 17 June 2009
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.ws.wsdl.model;

import java.util.ArrayList;
import org.licas.ws.WsFactory;


/**
 * This class describes a particular web services interface, by storing related
 * operation names.
 * @author Kieran Greer
 */
public class WsdlInterface
{
    /** The interface name */
    protected String name;

    /** Interface description */
    private String documentation;

    /** A list of related operation names. Of type String. */
    protected ArrayList operations;

    /** A fault process description */
    protected WsdlFault fault;


    /**
     * Create a new instance of WsdlInteface.
     * @param thisName the interface name.
     */
    public WsdlInterface(String thisName)
    {
        name = WsFactory.removePrefix(thisName);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        documentation = null;
        operations = new ArrayList();
        fault = null;
    }

    /**
     * Get the interface name.
     * @return the value of name.
     */
    public String getName()
    {
        return name;
    }

    /**
     * Set the description of the service.
     * @param theDocumentation the service documentation.
     */
    public void setDocumentation(String theDocumentation)
    {
        documentation = theDocumentation;
    }

    /**
     * Get the service documentation.
     * @return the value of documentation.
     */
    public String getDocumentation()
    {
        return documentation;
    }

    /**
     * Return true if this interface contains the operation. Note that the
     * operation name might need to be converted to be compatable with the
     * stored values.
     * @param operation the operation name.
     * @return true if this interface contains the operation.
     */
    public boolean containsOperation(String operation)
    {
        if (operation != null)
        {
            operation = operation.toLowerCase();
            return operations.contains(operation);
        }

        return false;
    }

    /**
     * Add the specified operation name to the list.
     * @param operation the operation name.
     * @return true if added of false if it already exists.
     */
    public boolean addOperation(String operation)
    {
        operation = WsFactory.removePrefix(operation.toLowerCase());

        if (!operations.contains(operation))
        {
            operations.add(operation);
            return true;
        }

        return false;
    }

    /**
     * Get the list of operation names.
     * @return the value of operations.
     */
    public ArrayList getOperations()
    {
        return operations;
    }

    /**
     * Set the interface fault process.
     * @param thisFault the fault.
     */
    public void setFault(WsdlFault thisFault)
    {
        fault = thisFault;
    }

    /**
     * Get the interface process fault.
     * @return the value of fault.
     */
    public WsdlFault getFault()
    {
        return fault;
    }
}
