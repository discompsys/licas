/*
 * WsdlParser.java
 *
 * Created on 16 June 2009
 *
 * Version 1.0.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws.wsdl.parse;


import org.licas.ws.WsFactory;
import org.licas.ws.wsdl.WsdlConst;
import org.licas.ws.wsdl.model.*;
import org.licas.ws.soap.SoapConst;

import org.licas_text.filter.FilterHtml;
import org.licas_xml.abs.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;

import javax.xml.namespace.QName;

import java.io.*;
import java.util.*;


/**
 * This class parses a wsdl document.
 * A much modified version of the class used previously on the icons project at UU.
 * @author Kieran Greer
 */
public class WsdlParser
{
    /** The logger */
    private static Logger logger;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(WsdlParser.class.getName());
        logger.setDebug(true);
    }

    /**
     * Create a new instance of WsdlParser.
     */
    public WsdlParser()
    {}


    /**
     * Creates definition and document objects by retrieving the wsdl document
     * from the specified address.
     * @param wsdlAddress the uri for the wsdl document.
     * @return the wsdl model generated from the parsed document.
     * @throws java.lang.Exception any error.
     */
    public WsdlModel parse(String wsdlAddress) throws Exception
    {
        int i;
        String namespaceKey;                            //namespace key
        String namespaceUri;                            //namespace uri
        String nextLine;                                //next line
        String wsdlStr;                                 //wsdl document as a String
        ArrayList namespaces;                           //all namespaces
        WsdlModel wsdlModel;                            //generated wsdl model
        WsdlService nextService;                        //next service
        WsdlTypes wsdlTypes;                            //wsdl types
        WsdlMessage nextMessage;                        //next message
        WsdlServiceParser serviceParser;                //service parser
        WsdlMessageParser messageParser;                //message parser
        WsdlInterfaceParser interfaceParser;            //interface parser
        WsdlTypesParser typesParser;                    //types parser
        Document doc;                                   //xml document
        Attribute nextAttr;                             //next attribute
        Node nextNode;                                  //next node
        Element rootElem;                               //root element
        Element nextElem;                               //next element
        Vector elemList;                                //element list
        XMLReader xmlReader;                            //xml reader
        FilterHtml filterHtml;                          //to filter html
        BufferedReader buffReader;                      //buffered reader
        ByteArrayInputStream baInputStream;             //byte array input stream

        nextLine = "";
        try
        {
            wsdlModel = new WsdlModel();
            filterHtml = new FilterHtml();
            serviceParser = new WsdlServiceParser();
            messageParser = new WsdlMessageParser();
            interfaceParser = new WsdlInterfaceParser();
            typesParser = new WsdlTypesParser();

            doc = XMLFactory.getInstance().createDocument();

            try
            {
                xmlReader = XMLFactory.getInstance().createReader(null, wsdlAddress);
                buffReader = new BufferedReader(xmlReader.openStream(null, wsdlAddress));
            }
            catch (Exception ex)
            {
                buffReader = new BufferedReader(new FileReader(wsdlAddress));
            }

            wsdlStr = "";
            filterHtml.resetForParsing();
            nextLine = buffReader.readLine();
            
            while (nextLine != null)
            {
                if (!nextLine.trim().equals("")) 
                {
                    nextLine = filterHtml.removeHtmlFormatting(nextLine);
                    wsdlStr += nextLine;
                }
                
                nextLine = buffReader.readLine();
            }

            try
            {
                baInputStream = new ByteArrayInputStream(wsdlStr.getBytes());
                rootElem = doc.parse(baInputStream);
            }
            catch (Exception ex)
            {
                if (logger.getDebug()) System.out.println(wsdlStr);
                throw ex;
            }

            namespaces = (ArrayList)rootElem.getAttributeList();
            for (i = 0; i < namespaces.size(); i++)
            {
                nextAttr = (Attribute)namespaces.get(i);
                namespaceKey = nextAttr.getName();
                namespaceUri = nextAttr.getValue();

                if (namespaceKey.equalsIgnoreCase(SoapConst.XMLSCHEMAURL))
                {
                    wsdlModel.setXmlNamespace(new QName(namespaceKey, namespaceUri));
                }
                else if (namespaceKey.equalsIgnoreCase(WsdlConst.TARGETNAMESPACE))
                {
                    wsdlModel.setLocalNamespace(new QName(namespaceKey, namespaceUri));
                }
                else if (namespaceKey.equalsIgnoreCase(WsdlConst.NAME))
                {
                    wsdlModel.setName(namespaceUri);
                }
            }

            //parse the child elements
            elemList = rootElem.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = (Node)elemList.get(i);

                if (nextNode instanceof Element)
                {
                    nextElem = (Element)nextNode;

                    if (WsFactory.removePrefix(nextElem.getName()).equals(WsdlConst.SERVICE))
                    {
                        nextService = serviceParser.parse(nextElem);
                        wsdlModel.addService(nextService);
                    }
                    else if (WsdlModel.isInterface(WsFactory.removePrefix(nextElem.getName())))
                    {
                        interfaceParser.parse(nextElem, wsdlModel);
                    }
                    else if (WsFactory.removePrefix(nextElem.getName()).equals(WsdlConst.TYPES))
                    {
                        wsdlTypes = typesParser.parse(nextElem);
                        wsdlModel.setTypes(wsdlTypes);
                    }
                    else if (WsFactory.removePrefix(nextElem.getName()).equals(WsdlConst.MESSAGE))
                    {
                        nextMessage = messageParser.parse(nextElem);
                        wsdlModel.addMessage(nextMessage);
                    }
                }
            }

            return wsdlModel;
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "parse", null, ex);
            
            if (logger.getDebug())
            {
                LoggerHandler.debugMessage(logger, LoggerHandler.ERROR , "parse", null);
                LoggerHandler.debugError(logger, LoggerHandler.ERROR , ex);
            }

            throw ex;
        }
    }

    /**
     * Return the String value with the dimensions removed.
     * @param value the type with the dimensions
     * @return the type with the dimensions removed
     */
    public static String removeDimensions(String value)
    {
        int index;			//position of first dimension indiactor
        String rtnValue;		//return value

        index = value.indexOf(SoapConst.ARRAYDIM);

        if (index > -1)
            rtnValue = value.substring(0, index);
        else
            rtnValue = value;

        return rtnValue;
    }

    /**
     * Return the number of dimensions in an array if an array exists or return 0.
     * @param value the type with possible array dimensions
     * @return the number of dimensions
     */
    public static int countDimensions(String value)
    {
        int index;			//position of first dimension indicator
        int count = 0;			//the number of dimensions
        String dimensions;              //dimensions

        index = value.indexOf(SoapConst.ARRAYDIM);

        if (index > -1)
        {
            dimensions = value.substring(index+1, value.length());
            count++;

            //first count commas
            index = dimensions.indexOf(SoapConst.ANOTHERDIM);

            if (index > -1)
            {
                while (index > -1)
                {
                    count++;
                    dimensions = dimensions.substring(index+1, dimensions.length());
                    index = dimensions.indexOf(SoapConst.ANOTHERDIM);
                }
            }
            else
            {
                //count brackets
                index = dimensions.indexOf(SoapConst.ARRAYDIM);

                while (index > -1)
                {
                    count++;
                    dimensions = dimensions.substring(index+1, dimensions.length());
                    index = dimensions.indexOf(SoapConst.ARRAYDIM);
                }
            }
        }

        return count;
    }
}