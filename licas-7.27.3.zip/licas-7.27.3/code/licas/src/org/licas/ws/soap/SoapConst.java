/*
 * SoapConst
 *
 * Created on 15 June 2009
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.ws.soap;


import java.util.ArrayList;


/**
 * This class stores basic types used in ontology objects and wsdl parser.
 * @author Kieran Greer.
 */
public class SoapConst extends LicasSoapConst
{
    /** Web Service namespace constants */
    public static final String SOAPENC = "http://schemas.xmlsoap.org/soap/encoding/";
    //XMLConstants.NSURI_SOAP_ENCODING;
    public static final String XSD = "xsd";
    //NamespaceConstants.NSPREFIX_SCHEMA_XSD;
    public static final String XSI = "xsi";
    //NamespaceConstants.NSPREFIX_SCHEMA_XSI;
    public static final String XMLNS = "xmlns";
    public static final String XMLSCHEMAURL = "http://www.w3.org/2001/XMLSchema";
    //NamespaceConstants.NSURI_SCHEMA_XSD;
    public static final String XMLSCHEMAINSTANCEURL = "http://www.w3.org/2001/XMLSchema-instance";
    //NamespaceConstants.NSURI_SCHEMA_XSI;
    public static final String ENVELOPEURL = "http://schemas.xmlsoap.org/soap/envelope/";
    //NamespaceConstants.NSURI_SOAP_ENVELOPE;

    public static final String ENVELOPENAMESPACE = "SOAP-ENV";
    public static final String ENVELOPETAG = "Envelope";
    public static final String BODYTAG = "Body";

    /**Indicate header tag.*/
    public static final String HEADER = "Header";

    /**Indicate body tag.*/
    public static final String BODY = "Body";

    /**Indicate soap action tag.*/
    public static final String SOAPACTION = "SOAPAction";

    /**Indicate a complex type.*/
    public static final String COMPLEXTYPE = "complexType";

    /**Indicate a simple type.*/
    public static final String SIMPLETYPE = "simpleType";

    /**Indicate another schema.*/
    public static final String SCHEMA = "schema";

    /**Indicates simple array type.*/
    public static final String ARRAY = "Array";

    /**Indicates an array type definition.*/
    public static final String ARRAYTYPE = "arrayType";

    /**Indicates a date time.*/
    public static final String DATETIME = "dateTime";

    /**Indicates a binary data type.*/
    public static final String BINARY = "binary";

    /**Indicates a binary data type.*/
    public static final String BASE64BINARY = "base64Binary";

    /**Indicates a boolean variable.*/
    public static final String BOOLEAN = "boolean";

    /**Indicates a String type.*/
    public static final String STRING = "string";

    /**Indicates a positive or negative integer.*/
    public static final String DECIMAL = "decimal";

    /**Indicates a positive integer value.*/
    public static final String INTEGER = "int";

    /**Indicates a long value.*/
    public static final String LONG = "long";

    /**Indicates a negative integer value.*/
    public static final String NEGATIVEINTEGER = "negativeInteger";

    /**Indicates a float value.*/
    public static final String FLOAT = "float";

    /**Indicates a double value.*/
    public static final String DOUBLE = "double";

    /**Indicates any type.*/
    public static final String ANYTYPE = "anyType";


    /**
     * Return true if the type input is a simple type as defined in this class.
     * @param type the type to be checked
     * @return boolean true if the type is a simple type
     */
    public static boolean isSimpleType(String type)
    {
        return ((type.equalsIgnoreCase(STRING)) || (type.equalsIgnoreCase(INTEGER)) ||
                (type.equalsIgnoreCase(NEGATIVEINTEGER)) || (type.equalsIgnoreCase(FLOAT)) ||
                (type.equalsIgnoreCase(DOUBLE)) || (type.equalsIgnoreCase(SCHEMA)) ||
                (type.equalsIgnoreCase(DATETIME)) || (type.equalsIgnoreCase(BINARY)) ||
                (type.equalsIgnoreCase(DECIMAL)) || (type.equalsIgnoreCase(BOOLEAN)) ||
                (type.equalsIgnoreCase(LONG)) || (type.equalsIgnoreCase(ANYTYPE)) ||
                (type.equalsIgnoreCase(BASE64BINARY)));
    }

    /**
     * Return true if type os a binary type.
     * @param type the type
     * @return boolean true if a binary type
     */
    public static boolean isBinary(String type)
    {
        return ((type.equalsIgnoreCase(BINARY)) ||
        (type.equalsIgnoreCase(BASE64BINARY)));
    }


    /**
     * Return the different types stored in a vector.
     * @return ArrayList the type names stored in a ArrayList
     */
    public static ArrayList getTypes()
    {
        ArrayList types = new ArrayList();			//different types

        types.add(ARRAYOF);
        types.add(COMPLEXTYPE);
        types.add(BOOLEAN);
        types.add(BINARY);
        types.add(BASE64BINARY);
        types.add(STRING);
        types.add(DECIMAL);
        types.add(INTEGER);
        types.add(LONG);
        types.add(NEGATIVEINTEGER);
        types.add(FLOAT);
        types.add(DOUBLE);
        types.add(DATETIME);
        types.add(SCHEMA);
        types.add(ANYTYPE);

        return types;
    }

    /**
     * Return the String value with the dimensions removed.
     * @param value the type with the dimensions
     * @return the type with the dimensions removed
     */
    public static String removeDimensions(String value)
    {
        int index;						//position of first dimension indiactor
        String rtnValue;					//return value

        index = value.indexOf(ARRAYDIM);

        if (index > -1)
                rtnValue = value.substring(0, index);
        else
                rtnValue = value;

        return rtnValue;
    }

    /**
     * Return the number of dimensions in an array if an array exists or return 0.
     * @param value the type with possible array dimensions
     * @return the number of dimensions
     */
    public static int countDimensions(String value)
    {
        int index;				//position of first dimension indicator
        int count = 0;				//the number of dimensions
        String dimensions;			//dimensions

        index = value.indexOf(ARRAYDIM);

        if (index > -1)
        {
            dimensions = value.substring(index+1, value.length());
            count++;

            //first count commas
            index = dimensions.indexOf(ANOTHERDIM);

            if (index > -1)
            {
                while (index > -1)
                {
                    count++;
                    dimensions = dimensions.substring(index+1, dimensions.length());
                    index = dimensions.indexOf(ANOTHERDIM);
                }
            }
            else
            {
                //count brackets
                index = dimensions.indexOf(ARRAYDIM);

                while (index > -1)
                {
                    count++;
                    dimensions = dimensions.substring(index+1, dimensions.length());
                    index = dimensions.indexOf(ARRAYDIM);
                }
            }
        }

        return count;
    }
}
