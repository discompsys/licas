/*
 * WsdlConst.java
 *
 * Created on 15 June 2009
 *
 * Version 1.3.1
 *
 * Copyright (c) 2006 Kieran Greer.
 */

package org.licas.ws.wsdl;


import org.licas.util.Const;
import org.licas.ws.wsdl.model.WsdlParamInfo;

import java.util.ArrayList;


/** 
 * This class contains some constant values related to wsdl documents.
 * @author Kieran Greer.
 */
public class WsdlConst
{
    /** Different protocols */
    public static final String SOAP = "SOAP";
    public static final String REST = "Rest";
    public static final String SOAPIN = "soapin";
    public static final String SOAPOUT = "soapout";
    public static final String SOAPIN2 = "soaprequest";
    public static final String SOAPOUT2 = "soapresponse";
    public static final String GET = "GET";
    public static final String GETIN = "httpgetin";
    public static final String GETOUT = "httpgetout";
    public static final String GETIN2 = "httpgetrequest";
    public static final String GETOUT2 = "httpgetresponse";
    public static final String POST = "POST";
    public static final String POSTIN = "httppostin";
    public static final String POSTOUT = "httppostout";
    public static final String POSTIN2 = "httppostrequest";
    public static final String POSTOUT2 = "httppostrequest";
    
    /**Constant definitions.*/
    public static final String SCHEMA = "schema";
    public static final String TARGETNAMESPACE = "targetNamespace";
    public static final String NAMESPACESEPARATOR = ":";
    public static final String SERVICE = "service";
    public static final String ATTRIBUTE = "attribute";
    public static final String ELEMENT = "element";
    public static final String MESSAGE = "message";
    public static final String MESSAGELABEL = "messageLabel";
    public static final String EXTENSION = "extension";
    public static final String ENUMERATION = "enumeration";
    public static final String DOCUMENTATION = "documentation";
    public static final String HEAD = "head";
    public static final String BODY = "body";
    public static final String USE = "use";
    public static final String BASE = "base";
    public static final String NAME = "name";
    public static final String INTERFACE = "interface";
    public static final String BINDING = "binding";
    public static final String PORT = "port";
    public static final String PORTTYPE = "portType";
    public static final String ADDRESS = "address";
    public static final String OPERATION = "operation";
    public static final String SOAPACTION = "soapAction";
    public static final String TRANSPORT = "transport";
    public static final String LOCATION = "location";
    public static final String FAULT = "fault";
    public static final String INPUT = "input";
    public static final String OUTPUT = "output";
    public static final String PATTERN = "pattern";
    public static final String STYLE = "style";
    public static final String TYPES = "types";
    public static final String TYPE = "type";
    public static final String PART = "part";
    public static final String PARAMETERS = "parameters";
    public static final String SIMPLETYPE = "simpleType";
    public static final String COMPLEXTYPE = "complexType";
    public static final String INFAULT = "infault";
    public static final String OUTFAULT = "outfault";
    public static final String SEQUENCE = "sequence";
    public static final String COMPLEXCONTENT = "complexContent";
    public static final String ALL = "All";
    public static final String RESTRICTION = "restriction";
    public static final String VALUE = "value";
    public static final String REF = "ref";
    public static final String ANY = "any";
    public static final String MINOCCURS = "minOccurs";
    public static final String ZERO = "0";
    public static final String HEADER = "Header";
    
    /**
     * Get the ending assigned to related input parameters for the specified protocol type.
     * @param protocol the protocol type.
     * @return the ending assigned to the related input parameters.
     */
    public static ArrayList<String> getInProtocolType(String protocol)
    {
        ArrayList<String> protocols;                //suitable protocols
        
        protocols = new ArrayList<>();
        if (protocol.equalsIgnoreCase(SOAP)) {
            protocols.add(SOAPIN);
            protocols.add(SOAPIN2);
        }
        else if (protocol.equalsIgnoreCase(GET)) {
            protocols.add(GETIN);
            protocols.add(GETIN2);
        }
        else if (protocol.equalsIgnoreCase(POST)) {
            protocols.add(POSTIN);
            protocols.add(POSTIN2);
        }        
        
        return protocols;
    }
    
    /**
     * Get the ending assigned to related output parameters for the specified protocol type.
     * @param protocol the protocol type.
     * @return the ending assigned to the related output parameters.
     */
    public static ArrayList<String> getOutProtocolType(String protocol)
    {
        ArrayList<String> protocols;                //suitable protocols
        
        protocols = new ArrayList<>();
        if (protocol.equalsIgnoreCase(SOAP)) {
            protocols.add(SOAPOUT);
            protocols.add(SOAPOUT2);
        }
        else if (protocol.equalsIgnoreCase(GET)) {
            protocols.add(GETOUT);
            protocols.add(GETOUT2);
        }
        else if (protocol.equalsIgnoreCase(POST)) {
            protocols.add(POSTOUT);
            protocols.add(POSTOUT2);
        }        
        
        return protocols;
    }
    
    /**
     * Get the list of possible protocols that can be used to make the call.
     * @return the list of possible protocols - soap, http post or get.
     */
    public static ArrayList<String> getProtocols()
    {
        ArrayList<String> protocolList;             //protocol list
        
        protocolList = new ArrayList<>();
        protocolList.add(SOAP);
        protocolList.add(Const.WSRPC);
        
        return protocolList;
    }
    
    /**
     * Return true if the parameter type describes a complex type.
     * @param paramInfo the parameter to check.
     * @return true if this describes an empty complex type, false otherwise.
     */
    public static boolean isEmptyComplexType(WsdlParamInfo paramInfo)
    {
        String paramName;                       //parameter name
        String paramType;                       //parameter type
        
        paramName = paramInfo.getName();
        paramType = paramInfo.getTypeElement();
        
        if ((paramName != null) && paramName.equalsIgnoreCase(PARAMETERS)) {
            return ((paramType != null) && (paramType.equals(COMPLEXTYPE) || 
                    paramType.equals(COMPLEXCONTENT)));
        }
        
        return false;
    }
    
    /**
     * Return true if the parameter type describes a set of values rather than a 
     * parameter, such as an enumeration.
     * @param paramType the parameter type to check.
     * @return true if this describes a set of values.
     */
    public static boolean isValueSetType(String paramType)
    {
        if (paramType != null) {
            paramType = paramType.toLowerCase();
            return (paramType.equals(ENUMERATION));
        }
        
        return false;
    }
}