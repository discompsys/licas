/*
 * SoapMessage.java
 *
 * Created on 15 June 2009
 *
 * Version 1.2.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws.soap;


import org.licas.ws.WsMethodInfo;
import java.util.*;
import javax.xml.namespace.QName;
import javax.xml.soap.*;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.licas.util.*;
import org.licas.ws.wsdl.WsdlConst;
import org.licas.ws.wsdl.model.WsdlParamInfo;


/**
 * This class creates the soap message that can be used to call a web service.
 * A version of this class was used previously on the Icons project at UU.
 * @author Kieran Greer
 */
public class SoapMessage
{
    /** The logger */
    private static Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SoapMessage.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of SoapMessage.
     */
    public SoapMessage()
    {}

   /**
    * Create and add the soap body elements to the soap body.
    * @param envelope the soap envelope.
    * @param body the soap body.
    * @param parameters the operation parameters.
    * @param operation the operation name. May be null if soap action uri is used
    * @param targetUri the soap body namespace. May be null or empty.
    * @param wsInfo web service method info.
    * @throws java.lang.Exception any error.
    */
   public void constructSoapMessage(SOAPEnvelope envelope, SOAPBody body,
       ArrayList parameters, String operation, String targetUri, WsMethodInfo wsInfo) 
       throws Exception
   {
        boolean headerAdded = false;                //true if header added
        SOAPHeader header;                          //soap header
        SOAPBodyElement sbElem;                     //soap body element
        SOAPElement usernameToken;                  //security username token
        SOAPElement username;                       //security username
        SOAPElement password;                       //security password
        Name elemName;                              //name of soap body element
        WsdlParamInfo nextParam;                    //next parameter
        Iterator iter1;                             //list iterator

        envelope = (SOAPEnvelope)envelope.addNamespaceDeclaration(SoapConst.XSD,
        SoapConst.XMLSCHEMAURL);
        envelope = (SOAPEnvelope)envelope.addNamespaceDeclaration(SoapConst.XSI,
        SoapConst.XMLSCHEMAINSTANCEURL);

        if (targetUri != null)
        {
            body = (SOAPBody)body.addNamespaceDeclaration("", targetUri);
        }

        //first check if any header information needs to be added
        iter1 = parameters.iterator();
        while (iter1.hasNext())
        {
            nextParam = (WsdlParamInfo)iter1.next();
            if ((isHeader(nextParam)) && (nextParam.getInOut().equalsIgnoreCase(WsdlConst.INPUT)))
            {
                if (!headerAdded)
                {
                    header = envelope.addHeader();
                    headerAdded = true;
                }

                createHeaderElements(envelope, nextParam.getChildElements(), targetUri);
            }
        }

        //then add soap message with or without operation as root element
        iter1 = parameters.iterator();
        if (operation == null)
        {
            //soap action uri defines the operation as in .NET web service
            while (iter1.hasNext())
            {
                nextParam = (WsdlParamInfo)iter1.next();
                if ((!isHeader(nextParam)) && (nextParam.getInOut().equalsIgnoreCase(WsdlConst.INPUT)))
                    createBodyElements(envelope, body, nextParam, targetUri);
            }
        }
        else
        {
            //if operation name is included it must be the operation to be called
            elemName = envelope.createName(operation, "", targetUri);
            sbElem = body.addBodyElement(elemName);

            while (iter1.hasNext())
            {
                nextParam = (WsdlParamInfo)iter1.next();

                if ((!isHeader(nextParam)) && (nextParam.getInOut().equalsIgnoreCase(WsdlConst.INPUT)))
                    createChildElements(envelope, sbElem, nextParam, targetUri);
            }
        }
        
        //add security header if there are passwords
        if (wsInfo.getWsUsername() != null)
        {
            header = envelope.addHeader();
            SOAPElement security = header.addChildElement("Security", "wsse", 
                    "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd");
 
            usernameToken = security.addChildElement("UsernameToken", "wsse");
            usernameToken.addAttribute((Name)(new QName("xmlns:wsu")), "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd");
 
            username = usernameToken.addChildElement("Username", "wsse");
            username.addTextNode(wsInfo.getWsUsername());
 
            password = usernameToken.addChildElement("Password", "wsse");
            password.setAttribute("Type", "wsse:PasswordText");
            password.addTextNode(wsInfo.getWsPassword());
        }
    }

   /**
    * Add header information to the message.
    * @param envelope the SOAP envelope object
    * @param parameters the list of header parameters
    * @param targetUri the local namespace uri of ws site.
    * @throws java.lang.Exception any error.
    */
   public void createHeaderElements(SOAPEnvelope envelope, ArrayList parameters,
       String targetUri) throws Exception
   {
        String localName;				//local parameter name
        String value;					//parameter value
        String type;					//parameter type
        String arrayType;				//type of array
        String namespace = null;			//uri of schema defining target object types
        SOAPHeaderElement newElem;			//soap header element
        SOAPHeader header;				//soap header
        Name elemName;					//name of soap element
        Name attrName;					//attribute name
        Iterator iter1;                     		//list iterator
        Iterator iter2;                     		//list iterator
        WsdlParamInfo childParam;                       //child parameter
        WsdlParamInfo parameter;                        //header parameter

        try
        {
            header = envelope.getHeader();
            iter1 = parameters.iterator();

            while(iter1.hasNext())
            {
                parameter = (WsdlParamInfo)iter1.next();

                localName = parameter.getName();
                namespace = parameter.getNamespace();
                elemName = envelope.createName(localName, "", namespace);
                newElem = header.addHeaderElement(elemName);
                if (targetUri != null)
                {
                    newElem.addNamespaceDeclaration("", targetUri);
                }
                
                //check if array definitions need to be added
                type = parameter.getType();
                if (SoapConst.countDimensions(type) > 0)
                {
                    arrayType = SoapConst.removeDimensions(type);

                    if (SoapConst.isSimpleType(arrayType)) value = type;
                    else value = type;

                    attrName = envelope.createName(SoapConst.ARRAYTYPE, SoapConst.SOAPENC,
                        SOAPConstants.URI_NS_SOAP_ENCODING);
                    newElem.addAttribute(attrName, value);
                }
                else
                {
                    //check if basic types attribute definitions need to be added
                    if (SoapConst.isSimpleType(type))
                    {
                        value = SoapConst.XSD + SoapConst.SEP + type;
                        attrName = envelope.createName(SoapConst.TYPE, SoapConst.XSI, "");
                        newElem.addAttribute(attrName, value);
                    }
                }

                if (parameter.getChildElements().size() == 0)
                {
                    value = ObjectHandler.getValue(parameter.getValue());
                    if (value != null) newElem.addTextNode(value);
                }

                //add child elements
                iter2 = parameter.getChildElements().iterator();
                while (iter2.hasNext())
                {
                    childParam = (WsdlParamInfo)iter2.next();
                    createChildElements(envelope, newElem, childParam, targetUri);
                }
            }
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "createHeaderElements", null, ex);
            
            if (logger.getDebug())
            {
                LoggerHandler.debugMessage(logger, LoggerHandler.ERROR, "createHeaderElements", "");
                LoggerHandler.debugError(logger, LoggerHandler.ERROR, ex);
            }

            throw ex;
        }
    }

   /**
    * Create and add the soap body elements to the soap body.
    * @param envelope the soap envelope
    * @param body the soap body
    * @param parameter the operation parameter
    * @param targetUri the local namespace uri of ws site.
    * @throws java.lang.Exception any error.
    */
   public void createBodyElements(SOAPEnvelope envelope, SOAPBody body, WsdlParamInfo parameter,
       String targetUri) throws Exception
   {
        String localName;				//local parameter name
        String type;					//parameter type
        String arrayType;				//type of array
        String namespace = null;                        //uri of schema defining target object types
        String value;					//parameter value
        SOAPBodyElement sbElem;                         //soap body element
        Name elemName;					//name of soap body element
        Name attrName;					//attribute name
        Iterator iter1;                                 //list iterator
        WsdlParamInfo childParam;                       //child parameter

        try
        {
            localName = parameter.getName();
            namespace = parameter.getNamespace();
            elemName = envelope.createName(localName, "", namespace);
            sbElem = body.addBodyElement(elemName);
            
            //check if array definitions need to be added
            type = parameter.getType();

            if (SoapConst.countDimensions(type) > 0)
            {
                arrayType = SoapConst.removeDimensions(type);

                if (SoapConst.isSimpleType(arrayType)) value = type;
                else value = type;

                attrName = envelope.createName(SoapConst.ARRAYTYPE, SoapConst.SOAPENC,
                        SOAPConstants.URI_NS_SOAP_ENCODING);

                sbElem.addAttribute(attrName, value);
            }
            else
            {
                //check if basic types attribute definitions need to be added
                if (SoapConst.isSimpleType(type))
                {
                    value = SoapConst.XSD + SoapConst.SEP + type;
                    attrName = envelope.createName(SoapConst.TYPE, SoapConst.XSI, "");
                    sbElem.addAttribute(attrName, value);
                }
            }

            if (parameter.getChildElements().isEmpty())
            {
                value = ObjectHandler.getValue(parameter.getValue());
                if (value != null) sbElem.addTextNode(value);
            }

            //add child elements
            iter1 = parameter.getChildElements().iterator();
            while (iter1.hasNext())
            {
                childParam = (WsdlParamInfo)iter1.next();
                createChildElements(envelope, sbElem, childParam, targetUri);
            }
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "createBodyElements", null, ex);
            
            if (logger.getDebug())
            {
                LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "createBodyElements", "");
                LoggerHandler.debugError(logger, LoggerHandler.INFO, ex);
            }

            throw ex;
        }
    }

   /**
    * Create and add the soap child elements to the soap body element.
    * @param envelope the soap envelope.
    * @param sbElem the soap body element.
    * @param parameter the operation parameter.
    * @param targetUri the local namespace uri of ws site.
    */
   private void createChildElements(SOAPEnvelope envelope, SOAPBodyElement sbElem,
           WsdlParamInfo parameter, String targetUri) throws Exception
   {

        String localName;				//local parameter name
        String type;					//parameter type
        String arrayType;				//type of array
        String value;					//parameter value
        SOAPElement sElem;                              //soap element
        Name elemName;					//name of soap body element
        Name attrName;					//attribute name
        Iterator iter1;                                 //list iterator
        WsdlParamInfo childParam;                       //child parameter

        try
        {
            localName = parameter.getName();
            elemName = envelope.createName(localName, "", targetUri);
            sElem = sbElem.addChildElement(elemName);
            
            //check if array definitions need to be added
            type = parameter.getType();
            if (type != null)
            {
                if (SoapConst.countDimensions(type) > 0)
                {
                    arrayType = SoapConst.removeDimensions(type);
                    if (SoapConst.isSimpleType(arrayType)) value = type;
                    else value = type;

                    attrName = envelope.createName(SoapConst.ARRAYTYPE, SoapConst.SOAPENC,
                            SOAPConstants.URI_NS_SOAP_ENCODING);

                    sElem.addAttribute(attrName, value);
                }
                else
                {
                    //check if basic types attribute definitions need to be added
                    if (SoapConst.isSimpleType(type))
                    {
                        value = SoapConst.XSD + SoapConst.SEP + type;
                        attrName = envelope.createName(SoapConst.TYPE, SoapConst.XSI, "");
                        sElem.addAttribute(attrName, value);
                    }
                }
            }

            if (parameter.getChildElements().isEmpty())
            {
                value = ObjectHandler.getValue(parameter.getValue());
                if (value != null) sElem.addTextNode(value);
            }

            //add child elements
            iter1 = parameter.getChildElements().iterator();
            while (iter1.hasNext())
            {
                childParam = (WsdlParamInfo)iter1.next();
                createChildElements(envelope, sElem, childParam, targetUri);
            }
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "createChildElements", null, ex);
            
            if (logger.getDebug())
            {
                LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "createChildElements", "");
                LoggerHandler.debugError(logger, LoggerHandler.INFO, ex);
            }

            throw ex;
        }
    }

   /**
    * Create and add the soap child elements to the soap element.
    * @param envelope the soap envelope
    * @param sElem the soap element
    * @param parameter the operation parameter
    * @param targetUri the local namespace uri of ws site.
    */
    private void createChildElements(SOAPEnvelope envelope, SOAPElement sElem,
            WsdlParamInfo parameter, String targetUri) throws Exception
    {
        String localName;				//local parameter name
        String type;					//parameter type
        String arrayType;				//type of array
        String value;					//parameter value
        SOAPElement newElem;				//soap element
        Name elemName;					//name of soap element
        Name attrName;					//attribute name
        Iterator iter1;                                 //list iterator
        WsdlParamInfo childParam;                       //child parameter

        try
        {
            localName = parameter.getName();
            elemName = envelope.createName(localName, "", targetUri);
            newElem = sElem.addChildElement(elemName);
            
            //check if array definitions need to be added
            type = parameter.getType();
            if (SoapConst.countDimensions(type) > 0)
            {
                arrayType = SoapConst.removeDimensions(type);

                if (SoapConst.isSimpleType(arrayType)) value = type;
                else value = type;

                attrName = envelope.createName(SoapConst.ARRAYTYPE, SoapConst.SOAPENC,
                        SOAPConstants.URI_NS_SOAP_ENCODING);

                newElem.addAttribute(attrName, value);
            }
            else
            {
                //check if basic types attribute definitions need to be added
                if (SoapConst.isSimpleType(type))
                {
                    value = SoapConst.XSD + SoapConst.SEP + type;
                    attrName = envelope.createName(SoapConst.TYPE, SoapConst.XSI, "");
                    newElem.addAttribute(attrName, value);
                }
            }

            if (parameter.getChildElements().isEmpty())
            {
                value = ObjectHandler.getValue(parameter.getValue());
                if (value != null) newElem.addTextNode(value);
            }

            //add child elements
            iter1 = parameter.getChildElements().iterator();
            while (iter1.hasNext())
            {
                childParam = (WsdlParamInfo)iter1.next();
                createChildElements(envelope, newElem, childParam, targetUri);
            }
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "createChildElements", null, ex);
            
            if (logger.getDebug())
            {
                LoggerHandler.debugMessage(logger, LoggerHandler.ERROR, "createChildElements", "");
                LoggerHandler.debugError(logger, LoggerHandler.ERROR, ex);
            }
            
            throw ex;
        }
    }

    /**
     * Return true if parameter is a header element.
     * @param parameter the parameter
     * @return true if a header element
     */
    private boolean isHeader(WsdlParamInfo parameter)
    {
        return ((parameter.getName() != null) &&
                parameter.getName().equalsIgnoreCase(WsdlConst.HEADER));
    }
}
