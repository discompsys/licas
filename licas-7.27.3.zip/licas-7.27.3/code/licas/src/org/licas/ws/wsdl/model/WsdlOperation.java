/*
 * WsdlOperation.java
 *
 * Created on 17 June 2009
 *
 * Version 1.4.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.ws.wsdl.model;


import org.licas.ws.WsMethodInfo;
import org.licas.ws.wsdl.WsdlConst;

import java.util.*;
import org.licas.ws.WsFactory;


/**
 * This class describes an operation that can be called on a web service. As this is what
 * the classes typically work with, the {@code commProtocol} is set to {@link WsdlConst}.{@code SOAP}
 * by default.
 * @author Kieran Greer
 */
public class WsdlOperation
{
    /** The operation name */
    private String name;

    /** Operation description */
    private String documentation;

    /** The operation pattern */
    private String pattern;

    /** The operation style */
    private String style;

    /** The operation soap action */
    private String soapAction;

    /** The input operation use */
    private String inputUse;

    /** The output operation use */
    private String outputUse;

    /** The communication protocol */
    private String commProtocol;
    
    /**
     * The operation input parameters.
     * Keys are the parameter names while values are of type WsdlParamInfo.
     */
    private HashMap inParams;

    /**
     * The operation output parameters.
     * Keys are the parameter names while values are of type WsdlParamInfo.
     */
    private HashMap outParams;

    /** The input fault process */
    private WsdlFault inFault;

    /** The output fault process */
    private WsdlFault outFault;
    
    /** The complete parent model */
    private WsdlModel parentModel;
    
    /** List of already created parameter types */
    private HashMap parsedTypes;


    /**
     * Create a new instance of WsdlOperation.
     * @param theModel the complete parent wsdl model.
     * @param thisName the operation name.
     */
    public WsdlOperation(WsdlModel theModel, String thisName)
    {
        parentModel = theModel;
        name = WsFactory.removePrefix(thisName);
        initialise();
    }

    /** Initialise some values */
    private void initialise()
    {
        documentation = null;
        pattern = null;
        style = null;
        soapAction = null;
        inputUse = null;
        outputUse = null;
        commProtocol = WsdlConst.SOAP;
        inParams = new HashMap();
        outParams = new HashMap();
        parsedTypes = new HashMap();
        inFault = null;
        outFault = null;
    }

    /**
     * Get the operation name.
     * @return the value of name.
     */
    public String getName()
    {
        return name;
    }

    /**
     * Set the description of the service.
     * @param theDocumentation the service documentation.
     */
    public void setDocumentation(String theDocumentation)
    {
        documentation = theDocumentation;
    }

    /**
     * Get the service documentation.
     * @return the value of documentation.
     */
    public String getDocumentation()
    {
        return documentation;
    }

    /**
     * Set the pattern for the operation.
     * @param thisPattern the pattern type.
     */
    public void setPattern(String thisPattern)
    {
        pattern = thisPattern;
    }

    /**
     * Get the operation pattern.
     * @return the value of pattern.
     */
    public String getPattern()
    {
        return pattern;
    }

    /**
     * Set the style for the operation.
     * @param thisStyle the style type.
     */
    public void setStyle(String thisStyle)
    {
        style = thisStyle;
    }

    /**
     * Get the operation style.
     * @return the value of style.
     */
    public String getStyle()
    {
        return style;
    }

    /**
     * Set the soap action for the operation.
     * @param thisSoapAction the soap action description.
     */
    public void setSoapAction(String thisSoapAction)
    {
        soapAction = thisSoapAction;
    }

    /**
     * Get the soap action description.
     * @return the value of soapAction.
     */
    public String getSoapAction()
    {
        return soapAction;
    }
    
    /**
     * Set the communication protocol.
     * @param thisCommProtocol the communication protocol.
     */
    public void setCommProtocol(String thisCommProtocol)
    {
        commProtocol = thisCommProtocol;
    }

    /**
     * Get the communication protocol.
     * @return the value of commProtocol.
     */
    public String getCommProtocol()
    {
        return commProtocol;
    }

    /**
     * Set the input use for the operation.
     * @param thisInputUse the operation use.
     */
    public void setInputUse(String thisInputUse)
    {
        inputUse = thisInputUse;
    }

    /**
     * Get the input operation use.
     * @return the value of inputUse.
     */
    public String getInputUse()
    {
        return inputUse;
    }

    /**
     * Set the output use for the operation.
     * @param thisOutputUse the operation use.
     */
    public void setOutputUse(String thisOutputUse)
    {
        outputUse = thisOutputUse;
    }

    /**
     * Get the output operation use.
     * @return the value of outputUse.
     */
    public String getOutputUse()
    {
        return outputUse;
    }

    /**
     * Add a parameter to one of the lists.
     * @param thisParam the input or output parameter.
     */
    public void addParameter(WsdlParamInfo thisParam)
    {
        String paramName;                       //parameter name

        paramName = thisParam.getName().toLowerCase();
        if (thisParam.getInOut().equals(WsdlConst.INPUT))
            inParams.put(paramName, thisParam);
        else
            outParams.put(paramName, thisParam);
    }

    /**
     * Get the parameter with the specified name. Can be either an input
     * or an output parameter. The input list is checked first.
     * @param paramName the parameter name.
     * @return the parameter or null if none exist.
     */
    public WsdlParamInfo getParameter(String paramName)
    {
        paramName = paramName.toLowerCase();

        if (inParams.containsKey(paramName))
            return (WsdlParamInfo)inParams.get(paramName);
        else if (outParams.containsKey(paramName))
            return (WsdlParamInfo)outParams.get(paramName);

        return null;
    }
    
    /**
     * Get the input parameter with the specified name.
     * @param paramName the parameter name.
     * @return the parameter or null if none exist.
     */
    public WsdlParamInfo getInParameter(String paramName)
    {
        paramName = paramName.toLowerCase();

        if (inParams.containsKey(paramName))
            return (WsdlParamInfo)inParams.get(paramName);
        
        return null;
    }
    
    /**
     * Get the output parameter with the specified name.
     * @param paramName the parameter name.
     * @return the parameter or null if none exist.
     */
    public WsdlParamInfo getOutParameter(String paramName)
    {
        paramName = paramName.toLowerCase();

        if (outParams.containsKey(paramName))
        {
            return (WsdlParamInfo)outParams.get(paramName);
        }

        return null;
    }
    
    /**
     * Guess what the return type is by parsing the output parameter list and returning
     * the value of the first found 'return' parameter.
     * @return likely return value type.
     */
    public String getReturnType()
    {
        String nextKey;                     //next key
        String nextType;                    //next type
        Iterator allKeys;                   //all keys
        WsdlParamInfo paramInfo;            //param info

        allKeys = outParams.keySet().iterator();
        while (allKeys.hasNext())
        {
            nextKey = (String)allKeys.next();
            paramInfo = (WsdlParamInfo)outParams.get(nextKey);
            if (paramInfo.getName().equalsIgnoreCase("return"))
            {
                return String.valueOf(paramInfo.getType());
            }
            
            nextType = getReturnType(paramInfo);
            if (nextType != null) return nextType;
        }

        return null;
    }
    
    /**
     * Guess what the return type is by parsing the output parameter list and returning
     * the value of the first found 'return' parameter.
     * @param rootInfo the root parameter to parse from.
     * @return likely return value type.
     */
    private String getReturnType(WsdlParamInfo rootInfo)
    {
        int i;
        String nextType;                //next type
        WsdlParamInfo paramInfo;        //param info

        for (i = 0; i < rootInfo.getChildElements().size(); i++)
        {
            paramInfo = (WsdlParamInfo)rootInfo.getChildElements().get(i);
            if (paramInfo.getName().equalsIgnoreCase("return"))
            {
                return String.valueOf(paramInfo.getType());
            }
            
            nextType = getReturnType(paramInfo);
            if (nextType != null) return nextType;
        }

        return null;
    }
    
    /**
     * Get a representation of the child input parameter at the specified nested position.
     * The search is performed depth first, or child elements before sibling elements.
     * The nested or complex structures are originally stored as WsdlMessage objects. 
     * If the parameter at the specified index is missing, then it is retrieved from 
     * the WsdlModel message object list instead.
     * @param baseName the name of the base or top-most parameter to parse.
     * @param nestedCount the final count position. The very first parameter has 
     * a value of 0 and its first child part, or the next part, the value of 1.
     * @return the child element if at this level, or null if not.
     */
    public WsdlParamInfo getInParamAt(String baseName, int nestedCount)
    {
        int i;
        int currentCount;                           //current count
        ArrayList paramElements;                       //list of child parameter elements
        ArrayList paramHolder;                         //parameter holder
        WsdlParamInfo paramInfo;                    //param info
        WsdlParamInfo nextParamInfo;                //next param info
        WsdlParamInfo indexParam;                   //param info at specified index
        
        indexParam = null;
        paramHolder = new ArrayList();
        currentCount = 0;        
        baseName = baseName.toLowerCase();
        
        if ((nestedCount >= 0) && inParams.containsKey(baseName))
        {
            paramInfo = (WsdlParamInfo)inParams.get(baseName);
            if (nestedCount == 0) 
            {
                indexParam = paramInfo;
            }
            else
            {
                paramElements = paramInfo.getChildElements();                
                if (!paramElements.isEmpty())
                {
                    for (i = 0; paramHolder.isEmpty() && (currentCount < nestedCount) &&
                            (i < paramElements.size()); i++)
                    {
                        nextParamInfo = (WsdlParamInfo)paramElements.get(i);
                        currentCount = getNextParamAt(nextParamInfo, currentCount, 
                                nestedCount, paramHolder);
                    }
                    
                    if (!paramHolder.isEmpty())
                    {
                        indexParam = (WsdlParamInfo)paramHolder.get(0);                       
                    }
                }
            }
        }
        
        return indexParam;
    }
    
    /**
     * Get a representation of the child output parameter at the specified nested position.
     * The search is performed depth first, or child elements before sibling elements.
     * The nested or complex structures are originally stored as WsdlMessage objects. 
     * If the parameter at the specified index is missing, then it is retrieved from 
     * the WsdlModel message object list instead.
     * @param baseName the name of the base or top-most parameter to parse.
     * @param nestedCount the final count position. The very first parameter has 
     * a value of 0 and its first child part, or the next part, the value of 1.
     * @return the child element if at this level, or null if not.
     */
    public WsdlParamInfo getOutParamAt(String baseName, int nestedCount)
    {
        int i;
        int currentCount;                           //current count
        ArrayList paramElements;                       //list of child parameter elements
        ArrayList paramHolder;                         //parameter holder
        WsdlParamInfo paramInfo;                    //param info
        WsdlParamInfo nextParamInfo;                //next param info
        WsdlParamInfo indexParam;                   //param info at specified index
        
        indexParam = null;
        paramHolder = new ArrayList();
        currentCount = 0;       
        baseName = baseName.toLowerCase();
        
        if ((nestedCount >= 0) && outParams.containsKey(baseName))
        {
            paramInfo = (WsdlParamInfo)outParams.get(baseName);
            if (nestedCount == 0) 
            {
                indexParam = paramInfo;
            }
            else
            {
                paramElements = paramInfo.getChildElements();               
                if (!paramElements.isEmpty())
                {
                    for (i = 0; paramHolder.isEmpty() && (currentCount < nestedCount) &&
                            (i < paramElements.size()); i++)
                    {
                        nextParamInfo = (WsdlParamInfo)paramElements.get(i);
                        currentCount = getNextParamAt(nextParamInfo, currentCount, 
                                nestedCount, paramHolder);
                    }
                    
                    if (!paramHolder.isEmpty())
                    {
                        indexParam = (WsdlParamInfo)paramHolder.get(0);                       
                    }
                }
            }
        }
        
        return indexParam;
    }
    
    /**
     * Get the name for the child parameter at the specified nested position.
     * The search is performed depth first, or child elements before sibling elements.
     * @param rootParam the parameter to parse from.
     * @param currentCount the current nested count.
     * @param nestedCount the final count position.
     * @param paramHolder the holder to place the found parameter.
     * @return the current nested count.
     */
    private int getNextParamAt(WsdlParamInfo rootParam, int currentCount, 
            int nestedCount, ArrayList paramHolder)
    {
        int i;
        ArrayList paramElements;                       //list of child parameter elements
        WsdlParamInfo nextParamInfo;                //parameter info
        
        currentCount++;
        paramElements = new ArrayList();
        
        if (nestedCount == currentCount) 
        {
            paramHolder.add(rootParam);
        }
        else
        {
            paramElements = rootParam.getChildElements();
            if (!paramElements.isEmpty())
            {
                for (i = 0; paramHolder.isEmpty() && (currentCount < nestedCount) &&
                        (i < paramElements.size()); i++)
                {
                    nextParamInfo = (WsdlParamInfo)paramElements.get(i);
                    currentCount = getNextParamAt(nextParamInfo, currentCount, 
                        nestedCount, paramHolder);
                }
            }
        }
        
        return currentCount;
    }
    
    /**
     * Traverse all of the stored message and type parts in the model and convert them
     * into empty parameter info elements as part of a complete nested structure.
     * This should be called only once.
     */
    public void messageTypePartsToParams()
    {
        String paramName;                           //parameter name
        Iterator paramNames;                        //parameter names
        WsdlParamInfo paramInfo;                    //param info
        WsdlMessage nextMessage;                    //next message
        
        try
        {
            parsedTypes = new HashMap();
            if (!inParams.isEmpty())
            {
                paramNames = inParams.keySet().iterator();
                while (paramNames.hasNext())
                {
                    paramName = (String)paramNames.next();
                    paramInfo = (WsdlParamInfo)inParams.get(paramName);
                    nextMessage = (WsdlMessage)parentModel.getMessages().get(paramName);
                    nextMessagePartsToParameters(paramInfo, nextMessage);
                }
            }

            if (!outParams.isEmpty())
            {
                paramNames = outParams.keySet().iterator();
                while (paramNames.hasNext())
                {
                    paramName = (String)paramNames.next();
                    paramInfo = (WsdlParamInfo)outParams.get(paramName);
                    nextMessage = (WsdlMessage)parentModel.getMessages().get(paramName);
                    nextMessagePartsToParameters(paramInfo, nextMessage);
                }
            }

            //remove the complex type descriptive elements 
            //that are not actually parameters
            removeComplexTypeDescriptions();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        finally
        {
            parsedTypes = new HashMap();
        }
    }
    
    /**
     * Traverse all of the stored message parts in the model and convert them
     * into empty parameter info elements as part of a complete nested structure.
     * @param rootParam root param info to add new parameters to.
     * @param rootMessage root message to convert child parts into parameters.
     */
    private void nextMessagePartsToParameters(WsdlParamInfo rootParam, WsdlMessage rootMessage)
    {
        int i;
        String paramName;                           //parameter name
        String paramType;                           //parameter type
        ArrayList messageElements;                     //list of child message elements
        WsdlParamInfo paramInfo;                    //param info
        WsdlParamInfo nextParamType;                //next param type
        WsdlMessage nextMessage;                    //next message
        WsdlTypes complexTypes;                     //complex param types
        
        complexTypes = parentModel.getTypes();
        messageElements = rootMessage.getMessageParts();  
        
        for (i = 0; i < messageElements.size(); i++)
        {
            nextMessage = (WsdlMessage)messageElements.get(i);
            paramName = nextMessage.getName();
            paramType = nextMessage.getTypeElement();
            
            if ((paramType != null) && !paramType.equals(""))
                nextParamType = complexTypes.getType(paramType);
            else
                nextParamType = null;
            
            paramInfo = rootParam.getChildElement(paramName);            
            if (paramInfo == null)
            {
                paramInfo = new WsdlParamInfo(paramName);
                paramInfo.setInOut(rootParam.getInOut());
                rootParam.addChildElement(paramInfo);
                    
                if (nextParamType != null)
                    paramInfo.setType(nextParamType.getType());
                else
                    paramInfo.setType(nextMessage.getType());                
            }
            
            if (nextParamType != null)
                nextTypesToParameters(paramInfo, nextParamType);
            else
                nextMessagePartsToParameters(paramInfo, nextMessage);
        }
    }
    
    /**
     * Traverse all of the stored complex type parts in the model and convert them
     * into empty parameter info elements as part of a complete nested structure.
     * @param rootParam root param info to add new parameters to.
     * @param roottype root complex type to convert child parts into parameters.
     */
    private void nextTypesToParameters(WsdlParamInfo rootParam, WsdlParamInfo rootType)
    {
        int i;
        String paramName;                           //parameter name
        String paramType;                           //parameter type
        ArrayList typeElements;                        //list of child type elements
        WsdlParamInfo paramInfo;                    //param info
        WsdlParamInfo cloneInfo;                    //cloned param info
        WsdlParamInfo nextParamType;                //param type
        WsdlTypes complexTypes;                     //complex param types
        
        complexTypes = parentModel.getTypes();
        typeElements = rootType.getChildElements();  
        
        for (i = 0; i < typeElements.size(); i++)
        {
            nextParamType = (WsdlParamInfo)typeElements.get(i);
            paramName = nextParamType.getName();
            paramType = nextParamType.getTypeElement();
             
            //if valid type try to add
            if (paramName != null)
            {
                if (parsedTypes.containsKey(paramName))
                {
                    cloneInfo = (WsdlParamInfo)parsedTypes.get(paramName);
                    paramInfo = (WsdlParamInfo)cloneInfo.clone();
                    paramInfo.setName(paramName);
                    paramInfo.setInOut(rootParam.getInOut());

                    rootParam.addChildElement(paramInfo);
                }
                else
                {
                    paramInfo = new WsdlParamInfo(paramName);
                    paramInfo.setInOut(rootParam.getInOut());
                    paramInfo.setType(paramType);

                    parsedTypes.put(paramName, paramInfo);

                    if (complexTypes.getType(paramType) != null)
                    {
                        nextTypesToParameters(paramInfo, complexTypes.getType(paramType));  
                    }

                    rootParam.addChildElement(paramInfo);
                }
            }
        }
    }
    
    /**
     * Remove the complex type descriptive elements that are not actually parameters.
     * These would typically be defined with the 'parameters' name. Other complex type
     * elements need to be kept as they also define nested complex objects.
     */
    private void removeComplexTypeDescriptions()
    {
        String paramName;                           //parameter name
        Iterator paramNames;                        //parameter names
        WsdlParamInfo paramInfo;                    //param info
        
        if (!inParams.isEmpty())
        {
            paramNames = inParams.keySet().iterator();
            while (paramNames.hasNext())
            {
                paramName = (String)paramNames.next();
                paramInfo = (WsdlParamInfo)inParams.get(paramName);
                removeNextComplexTypeDescriptions(null, paramInfo);
            }
        }
        
        if (!outParams.isEmpty())
        {
            paramNames = outParams.keySet().iterator();
            while (paramNames.hasNext())
            {
                paramName = (String)paramNames.next();
                paramInfo = (WsdlParamInfo)outParams.get(paramName);
                removeNextComplexTypeDescriptions(null, paramInfo);
            }
        }
    }
    
    /**
     * Remove the complex type descriptive elements that are not actually parameters.
     * These would typically be defined with the 'parameters' name. Other complex type
     * elements need to be kept as they also define nested complex objects.
     * @param parentParam the parent of the root parameter to add its children to.
     * @param rootParam the root parameter to parse from.
     */
    private void removeNextComplexTypeDescriptions(WsdlParamInfo parentParam, 
            WsdlParamInfo rootParam)
    {
        int i;
        String paramName;                               //parameter name
        String paramType;                               //parameter type
        ArrayList childParams;                          //child parameters
        WsdlParamInfo paramInfo;                        //param info
        
        paramName = rootParam.getName();
        paramType = rootParam.getTypeElement();
        childParams = rootParam.getChildElements();
            
        if ((paramType != null) && WsdlConst.isEmptyComplexType(rootParam))
        {
            parentParam.removeChildElement(paramName);
            parentParam.getChildElements().addAll(childParams);
            rootParam = parentParam;
        }
        
        //parse through the child parameters now to perform the same check
        for (i = 0; i < childParams.size(); i++)
        {
            paramInfo = (WsdlParamInfo)childParams.get(i);
            removeNextComplexTypeDescriptions(rootParam, paramInfo);
        }
    }
    
    /**
     * Set the input parameter values.
     * @param thisInParams the set of input parameters.
     */
    public void setInParams(HashMap thisInParams)
    {
        int i;
        ArrayList paramList;                            //param list
        WsdlParamInfo wsdlParamInfo;                    //wsdl param info
        
        inParams = thisInParams;
        paramList = new ArrayList(inParams.values());
        for (i = 0; i < paramList.size(); i++)
        {
            wsdlParamInfo = (WsdlParamInfo)paramList.get(i);
            wsdlParamInfo.setInOut(WsdlConst.INPUT);
        }
    }
    
    /**
     * Get the input parameter names list only.
     * @return a list of the input parameters names only.
     */
    public ArrayList getInParamNames()
    {
        return new ArrayList(inParams.keySet());
    }
    
    /**
     * Get the input parameter names list for the specified comm protocol.
     * @param protocol the protocol type - SOAP, GET or POST
     * @return list of parameter names only that end with the defined protocol ending.
     */
    public ArrayList getInParamNames(String protocol)
    {
        int i, j;
        String paramName;                           //parameter name
        String paramEnd;                            //parameter ending
        ArrayList protoEnds;                        //protocol endings
        ArrayList paramNames;                       //parameter names
        ArrayList paramKeep;                        //names to keep
        
        paramKeep = new ArrayList();
        paramNames = getInParamNames();
        
        if (paramNames.size() == 1)
        {
            paramName = ((String)paramNames.get(0)).toLowerCase();
            paramKeep.add(paramName);
        }
        else
        {
            protoEnds = WsdlConst.getInProtocolType(protocol);
            for (i = 0; i < protoEnds.size(); i++)
            {
                paramEnd = (String)protoEnds.get(i);           
                for (j = 0; j < paramNames.size(); j++)
                {
                    paramName = ((String)paramNames.get(j)).toLowerCase();
                    if (paramName.endsWith(paramEnd)) paramKeep.add(paramName);
                }
            }
        }
        
        return paramKeep;
    }

    /**
     * Get the input parameters.
     * @return the value of inParams.
     */
    public HashMap getInParams()
    {
        return inParams;
    }
    
    /**
     * Get the input parameters for the specified comm protocol.
     * @param protocol the protocol type - SOAP, GET or POST
     * @return the value of inParams that end with the defined protocol ending.
     */
    public HashMap getInParams(String protocol)
    {
        int i;
        String paramName;                           //parameter name
        String paramEnd;                            //parameter ending
        Iterator paramNames;                        //parameter names
        ArrayList protoEnds;                        //protocol endings
        HashMap protocolParams;                     //list of protocol params
        
        paramNames = inParams.keySet().iterator();
        protocolParams = new HashMap();
        
        if (inParams.keySet().size() == 1)
        {
            paramName = ((String)paramNames.next()).toLowerCase();
            protocolParams.put(paramName, inParams.get(paramName));
        }
        else
        {
            protoEnds = WsdlConst.getInProtocolType(protocol);
            for (i = 0; i < protoEnds.size(); i++)
            {
                paramEnd = (String)protoEnds.get(i);
                while (paramNames.hasNext())
                {
                    paramName = ((String)paramNames.next()).toLowerCase();
                    if (paramName.endsWith(paramEnd))
                        protocolParams.put(paramName, inParams.get(paramName));
                }
            }
        }
        
        return protocolParams;
    }
    
    /**
     * Get the input parameters for the specified comm protocol, for a {@link WsMethodInfo} object.
     * @param protocol the protocol type - SOAP, GET or POST.
     * @return the list of input parameters as {@code WsdlParamInfo} objects.
     */
    public ArrayList getMethodInfoParams(String protocol)
    {
        int i, j;
        String paramName;                               //parameter name
        String paramEnd;                                //parameter ending
        Iterator paramNames;                            //parameter names
        ArrayList protoEnds;                            //protocol endings
        ArrayList childElems;                           //child elements
        ArrayList methodParams;                         //list of method params
        WsdlParamInfo wsdlParamInfo;                    //wsdl param info
        WsdlParamInfo paramInfo;                        //param info
        
        paramNames = inParams.keySet().iterator();
        methodParams = new ArrayList();
        
        if (inParams.keySet().size() == 1)
        {
            paramName = ((String)paramNames.next()).toLowerCase();
            wsdlParamInfo = (WsdlParamInfo)inParams.get(paramName);
            paramInfo = (WsdlParamInfo)wsdlParamInfo.clone();
            methodParams.add(paramInfo);
        }
        else
        {
            protoEnds = WsdlConst.getInProtocolType(protocol);
            for (i = 0; i < protoEnds.size(); i++)
            {
                paramEnd = (String)protoEnds.get(i);
                while (paramNames.hasNext())
                {
                    paramName = ((String)paramNames.next()).toLowerCase();
                    if (paramName.endsWith(paramEnd))
                    {
                        wsdlParamInfo = (WsdlParamInfo)inParams.get(paramName);
                        
                        //params stored as a list of child elements
                        childElems = wsdlParamInfo.getChildElements();
                        for (j = 0; j < childElems.size(); j++)
                        {
                            wsdlParamInfo = (WsdlParamInfo)childElems.get(j);
                            paramInfo = (WsdlParamInfo)wsdlParamInfo.clone();
                            methodParams.add(paramInfo);
                        }
                    }
                }
            }
        }
        
        return methodParams;
    }
    
    /**
     * Set the output parameter values.
     * @param thisOutParams the set of output parameters.
     */
    public void setOutParams(HashMap thisOutParams)
    {
        int i;
        ArrayList paramList;                               //param list
        WsdlParamInfo wsdlParamInfo;                    //wsdl param info
        
        outParams = thisOutParams;
        paramList = new ArrayList(outParams.values());
        for (i = 0; i < paramList.size(); i++)
        {
            wsdlParamInfo = (WsdlParamInfo)paramList.get(i);
            wsdlParamInfo.setInOut(WsdlConst.OUTPUT);
        }
    }
    
    /**
     * Get the output parameter names list only.
     * @return a list of the output parameters names only.
     */
    public ArrayList getOutParamNames()
    {
        return new ArrayList(outParams.keySet());
    }
    
    /**
     * Get the output parameter names list for the specified comm protocol.
     * @param protocol the protocol type - SOAP, GET or POST
     * @return list of parameter names only that end with the defined protocol ending.
     */
    public ArrayList getOutParamNames(String protocol)
    {
        int i, j;
        String paramName;                           //parameter name
        String paramEnd;                            //parameter ending
        ArrayList protoEnds;                           //protocol endings
        ArrayList paramNames;                          //parameter names
        ArrayList paramKeep;                           //names to keep
        
        paramKeep = new ArrayList();
        paramNames = getOutParamNames();
        
        if (paramNames.size() == 1)
        {
            paramName = ((String)paramNames.get(0)).toLowerCase();
            paramKeep.add(paramName);
        }
        else
        {
            protoEnds = WsdlConst.getOutProtocolType(protocol);
            for (i = 0; i < protoEnds.size(); i++)
            {
                paramEnd = (String)protoEnds.get(i);
                for (j = 0; j < paramNames.size(); j++)
                {
                    paramName = ((String)paramNames.get(j)).toLowerCase();
                    if (paramName.endsWith(paramEnd)) paramKeep.add(paramName);
                }
            }
        }
        
        return paramKeep;
    }

    /**
     * Get the output parameters.
     * @return the value of outParams.
     */
    public HashMap getOutParams()
    {
        return outParams;
    }
    
    /**
     * Get the output parameters for the specified comm protocol.
     * @param protocol the protocol type - SOAP, GET or POST
     * @return the value of outParams that end with the defined protocol ending.
     */
    public HashMap getOutParams(String protocol)
    {
        int i;
        String paramName;                           //parameter name
        String paramEnd;                            //parameter ending
        Iterator paramNames;                        //parameter names
        ArrayList protoEnds;                           //protocol endings
        HashMap protocolParams;                   //list of protocol params
        
        protocolParams = new HashMap();
        paramNames = outParams.keySet().iterator();
        
        if (outParams.keySet().size() == 1)
        {
            paramName = ((String)paramNames.next()).toLowerCase();
            protocolParams.put(paramName, outParams.get(paramName));
        }
        else
        {
            protoEnds = WsdlConst.getOutProtocolType(protocol);
            for (i = 0; i < protoEnds.size(); i++)
            {
                paramEnd = (String)protoEnds.get(i);
                while (paramNames.hasNext())
                {
                    paramName = ((String)paramNames.next()).toLowerCase();
                    if (paramName.endsWith(paramEnd))
                        protocolParams.put(paramName, outParams.get(paramName));
                }
            }
        }
        
        return protocolParams;
    }

    /**
     * Set the input fault value.
     * @param thisInFault the input fault description.
     */
    public void setInFault(WsdlFault thisInFault)
    {
        inFault = thisInFault;
    }

    /**
     * Get the input fault value.
     * @return the value of inFault.
     */
    public WsdlFault getInFault()
    {
        return inFault;
    }

    /**
     * Set the output fault value.
     * @param thisOutFault the output fault description.
     */
    public void setOutFault(WsdlFault thisOutFault)
    {
        outFault = thisOutFault;
    }

    /**
     * Get the output fault value.
     * @return the value of outFault.
     */
    public WsdlFault getOutFault()
    {
        return outFault;
    }
    
    /**
     * Get a clone of this object. This is a deep clone, but not 100% guaranteed.
     * @return a clone copy of this object, without the fault information.
     */
    public Object clone()
    {
        int i;
        ArrayList paramList;                               //list of parameters
        WsdlParamInfo paramInfo;                        //param info
        WsdlOperation operationClone;                   //cloned object

        operationClone = new WsdlOperation(parentModel, name);
        operationClone.setDocumentation(documentation);
        operationClone.setPattern(pattern);
        operationClone.setStyle(style);
        operationClone.setSoapAction(soapAction);
        operationClone.setInputUse(inputUse);
        operationClone.setOutputUse(outputUse);
        
        paramList = new ArrayList(inParams.values());
        for (i = 0; i < paramList.size(); i++)
        {
            paramInfo = (WsdlParamInfo)((WsdlParamInfo)paramList.get(i)).clone();
            operationClone.addParameter(paramInfo);
        }
        
        paramList = new ArrayList(outParams.values());
        for (i = 0; i < paramList.size(); i++)
        {
            paramInfo = (WsdlParamInfo)((WsdlParamInfo)paramList.get(i)).clone();
            operationClone.addParameter(paramInfo);
        }

        return operationClone;
    }
}
