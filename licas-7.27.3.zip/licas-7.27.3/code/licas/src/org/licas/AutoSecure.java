/*
 * AutoSecure.java
 *
 * Created on 22 March 2016
 *
 * Version 1.2.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas;


import org.licas.parsers.Parsers;
import org.licas.util.Const;
import org.licas.util.MetaConst;
import org.licas.util.MethodConst;
import org.licas.util.ReflectionHandler;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Vector;


/**
 * This is a more secure version of the {@link Auto} class in which the only methods that
 * can be executed are ones that add and remove messages from the autonomic manager queue.
 * Allowing access to all methods might break some logic as part of a queueing system and
 * this class even overrides any admin script security settings.
 * The {@code canAccess} method has new settings so that any remote call that tries to
 * invoke a method must use one of the {@code run}, {@code invokeBehaviour}, or {@code messageReply}
 * methods. There are also the following conditions:<br>
 * 1. If the Thread's {@code run} method has started, then {@code invokeBehaviour} is
 * disabled, so the behaviours can only execute in the loop, using the internal {@code evaluateBehaviour}
 * method, so as not to break some logic here.<br>
 * 2. If the Thread's {@code run} method has not started, then {@code invokeBehaviour} is
 * allowed, for single instance executions.<br>
 * 3. The {@code messageReply} method is always open and will queue any messages it receives.
 * @author Kieran Greer
 */
public abstract class AutoSecure extends Auto
{
    /** The logger */
    private static final Logger logger;
    
    
    /** List of class paths that are not allowed to be loaded */
    private static final ArrayList<String> classPaths;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(AutoSecure.class.getName());
        logger.setDebug(false);
        
        //set the secured class paths
        classPaths = new ArrayList<>();
        classPaths.add("org.licas");
        classPaths.add("org.licas.autonomic");
        classPaths.add("org.licas.autonomic.script");
        classPaths.add("org.licas.call");
        classPaths.add("org.licas.call.client");
        classPaths.add("org.licas.call.rest");
        classPaths.add("org.licas.call.thread");
        classPaths.add("org.licas.parsers");
        classPaths.add("org.licas.security");
        classPaths.add("org.licas.server");
        classPaths.add("org.licas.server.esb");
        classPaths.add("org.licas.server.model");
    }

    /** 
     * Creates a new instance of AutoSecure.
     * Password and service key set to {@code anon} by default.
     * @throws java.lang.Exception any error.
     */
    public AutoSecure() throws Exception
    {
        super();        
        initialise();
    }
    
    /** 
     * Creates a new instance of AutoSecure.
     * @param thisPassword password to invoke this service.
     * @param thisAdminKey admin key for this service.
     * @throws java.lang.Exception any error.
     */
    public AutoSecure(String thisPassword, String thisAdminKey) throws Exception
    {
        super(thisPassword, thisAdminKey);        
        initialise();
    }
    
    /** 
     * Creates a new instance of AutoSecure.
     * @param thisPassword password to invoke this service.
     * @param thisAdminKey admin key for this service.
     * @param adminXml the admin info or description of this service.
     * @throws java.lang.Exception any error.
     */
    public AutoSecure(String thisPassword, String thisAdminKey, Element adminXml)
            throws Exception
    {
        super(thisPassword, thisAdminKey, adminXml);
        initialise();
    }
    
    /** 
     * Initialise some values.
     */
    private void initialise()
    {}
    
    /**
     * Set actual values for variable instances if they are defined.
     * <p>
     * {@code NOTE:} you must add this method to your own derived class if you use it,
     * so that the private variables in that class can be accessed. It is ignored
     * unless it gets called through the script initialisation process.
     * @param instanceValues the admin script part that defines instance values.
     * @throws java.lang.Exception any error.
     */
    protected void setInstanceValues(Element instanceValues) throws Exception
    {
        int i;
        String varName;                             //variable name
        Element instanceValue;                      //instance value
        Element nextElem;                           //next element
        Vector<Node> elemList;                      //list of elements
        Field instField;                            //instance field
        Object valueObj;                            //value object
        
        if (instanceValues != null)
        {
            elemList = instanceValues.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                instanceValue = (Element)elemList.get(i);  
                varName = instanceValue.getAttributeValue(Const.NAME);               
                nextElem = instanceValue.getElementChildAtIndex(0);
                valueObj = Parsers.parse(nextElem);               
                if (valueObj != null)
                {
                    instField = ReflectionHandler.getInstanceField(this, varName);
                    if (instField != null)
                    {
                        try {
                            instField.set(this, valueObj);
                        }
                        catch (Exception ex) {}
                    }
                }
            }
        }
    }
    
    /**
     * Get the value of the specified variable if it exists.
     * <p>
     * {@code NOTE:} you must add this method to your own derived class if you use it,
     * so that the private variables in that class can be accessed. It is ignored
     * unless it gets called through the script initialisation process.
     * @param varName the name of the variable to check for.
     * @throws java.lang.Exception any error.
     */
    protected Object getInstanceValue(String varName) throws Exception
    {
        int i;
        Field nextField;                            //next field
        Field[] fields;                             //fields from this class
        Object fieldValue;                          //field value

        fieldValue = null;
        if ((varName != null) && !varName.equals(""))
        {
            fields = this.getClass().getDeclaredFields();
            for (i = 0; (fieldValue == null) && (i < fields.length); i++)
            {
                nextField = fields[i];
                if (nextField.getName().equalsIgnoreCase(varName))
                {
                    try {
                        fieldValue = fields[i].get(this);
                    }
                    catch (Exception ex) {
                        fieldValue = null;
                    }
                }
            }

            if (fieldValue == null)
            {
                fields = this.getClass().getFields();
                for (i = 0; (fieldValue == null) && (i < fields.length); i++)
                {
                    nextField = fields[i];
                    if (nextField.getName().equalsIgnoreCase(varName))
                    {
                        try {
                            fieldValue = fields[i].get(this);
                        }
                        catch (Exception ex) {
                            fieldValue = null;
                        }
                    }
                }
            }
        }

        return fieldValue;
    }
    
    /**
     * Set actual values for serialized variable instances if they are defined.
     * <p>
     * {@code NOTE:} you must add this method to your own derived class if you
     * use it, so that the private variables in that class can be accessed.
     * @param serializeXml the admin script part that defines serialize instance
     * values.
     * @throws java.lang.Exception any error.
     */
    protected void setSerializeValues(Element serializeXml) throws Exception
    {
        int i;
        String varName;                             //variable name
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Vector<Node> elemList;                      //element list
        Field instField;                            //instance field
        Object valueObj;                            //value object

        if (serializeXml != null)
        {
            elemList = serializeXml.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextElem = (Element) elemList.get(i);
                if (nextElem.getName().equals(Const.SERIALISEVALUE))
                {
                    varName = nextElem.getAttributeValue(Const.NAME);
                    if (!varName.equals(MetaConst.ADMIN))
                    {
                        if (nextElem.hasChildren())
                        {
                            nextElem2 = nextElem.getElementChildAtIndex(0);
                            valueObj = Parsers.parse(nextElem2);
                            if (valueObj != null)
                            {
                                instField = ReflectionHandler.getInstanceField(this, varName);
                                if (instField != null)
                                {
                                    try {
                                        instField.set(this, valueObj);
                                    }
                                    catch (Exception ex) {}
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Return true if the method is one that can be safely called on a secure Auto class.
     * This version only allows the autonomous loop methods as default.
     * @param methodName the name of the method.
     * @return true if the method can be freely called.
     */
    public boolean isSecureMethod(String methodName)
    {
        return getSecureMethods().contains(methodName);
    }
    
    /**
     * Return true if the password allows the calling component to access this component.
     * @param thePassword the password to use.
     * @param methodName the method name that needs to be called.
     * @param theMethod the method that needs to be called.
     * @return true if the entered password is the correct password or
     * there is no password.
     * @throws java.lang.Exception any error.
     */
    protected boolean canAccess(String thePassword, String methodName, Method theMethod) throws Exception
    {
        boolean access;                         //true if can access
        
        access = isSecureMethod(methodName);
        
        //if access is allowed, check for specific settings
        if (access) {
            //if thread is running then not allowed to execute invokeBehaviour
            if (isAlive()) {
                access = !(methodName.equals(MethodConst.INVOKEBEHAVIOUR));
            }
        }
        
        return access;
    }
    
    /**
     * Check that the classname path is not illegal.
     * @param className full classname of service to load.
     * @return ture if safe path that is not one of the licas key packages.
     */
    protected boolean classNameOK(String className)
    {
        if (className != null) {
            className = className.substring(0, className.lastIndexOf("."));        
            return !classPaths.contains(className.toLowerCase());
        }
        
        return true;
    }
    
    /**
     * Get the list of methods that can be safely called on a secure Auto class.
     * @return the list of safe method names, but might still require passwords.
     */
    protected ArrayList<String> getSecureMethods()
    {
        ArrayList<String> methodNames;              //list of method names
        
        methodNames = publicMethods();
        methodNames.add(MethodConst.INVOKEBEHAVIOUR);
        methodNames.add(MethodConst.MESSAGEREPLY);
        methodNames.add(MethodConst.SETPROCESSSCRIPT);
        methodNames.add(MethodConst.STARTTHREAD);
        methodNames.add(MethodConst.SETSHUTDOWN);
        methodNames.add(MethodConst.CANACCESSNESTED);
        methodNames.add(MethodConst.CANACCESSMETA);
        
        return methodNames;
    }
    
    /**
     * Get the list of methods that that can be freely called, without a password even.
     * @return the list of safe method names, but might still require passwords.
     */
    public ArrayList<String> getPublicMethods()
    {
        return publicMethods();
    }

    /**
     * Get the list of methods that that can be freely called, without a password even.
     * @return the list of safe method names, but might still require passwords.
     */
    private ArrayList<String> publicMethods()
    {
        ArrayList<String> methodNames;                  //list of method names

        methodNames = new ArrayList<>();
        methodNames.add(MethodConst.EXECUTE);
        methodNames.add(MethodConst.CANACCESS);
        methodNames.add(MethodConst.GETPASSWORD);
        methodNames.add(MethodConst.ISSECUREMETHOD);
        methodNames.add(MethodConst.GETSECUREMETHODS);
        methodNames.add(MethodConst.ISPUBLICMETHOD);
        methodNames.add(MethodConst.GETPUBLICMETHODS);

        return methodNames;
    }
}
