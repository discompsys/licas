/*
 * ServiceAdmin.java
 *
 * Created on 30 March 2011
 *
 * Version 1.10.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas;


import org.licas.call.Handle;
import org.licas.def.*;
import org.licas.meta.ServiceMeta;
import org.licas.module.*;
import org.licas.server.LocalServer;
import org.licas.server.esb.ServiceRepository;
import org.licas.service.model.KeywordHandler;
import org.licas.service.model.WorkInfo;
import org.licas.util.Const;
import org.licas.util.ObjectHandler;
import org.licas.util.exception.*;
import org.licas_xml.abs.Element;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.util.*;


/**
 * This class stores admin details for a service, including the metadata description in
 * an {@link AdminInfo} object. Other information includes details of the child services, 
 * keywords list and service contract. Any related metadata in the server's {@link ServiceRepository}
 * is not automatically updated, but would require an update method call from the service itself.
 * This object however creates its metadata dynamically upon request and so it should be up
 * to date, but not automatically synced with the server's.
 * @author Kieran Greer
 */
public class ServiceAdmin
{
    /** The logger */
    private static final Logger logger;

    /** The admin key of the parent service */
    protected String serviceAdminKey;
    
    /** The parent service */
    protected Service service;
    
    /** 
     * A list of services that are child services of this one.
     * Keys are service names of type String and values are the {@link ServiceInfo} objects.
     */
    protected HashMap<String, ServiceInfo> services;
    
    /** 
     * A list of service types that are stored under this service. 
     * Keys are the service types of type String and values are Lists of names of services of that type.
     */
    protected HashMap<String, ArrayList<String>> serviceTypes;
    
    /** The service admin information */
    protected AdminInfo adminInfo;
    
    /** For processing any service-general keyword lists */
    protected KeywordHandler keywordHandler;
    
    /** Stores the contracts for each service level */
    protected ContractManager contractManager;

    /**
     * Type of work protocol for the service - point-to-point, subscribe, or both.
     * This can include other keyword lists specific to the protocol conditions and/or method.
     * This can be {@code null}, when it is assumed that the service has no additional conditions
     * and is accessed point-to-point, or by calling its ID only.
     */
    protected WorkInfo workInfo;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServiceAdmin.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of ServiceAdmin.
     * @param theService the parent service.
     * @param theAdminKey the parent service admin key.
     * @param adminXml the admin xml document. Can be null.
     * @throws java.lang.Exception any error. 
     */
    public ServiceAdmin(Service theService, String theAdminKey, Element adminXml)
            throws Exception
    {
        service = theService;
        serviceAdminKey = theAdminKey;
        initialise(adminXml);
    }
    
    /** 
     * Initialise some values 
     * @throws java.lang.Exception any error. 
     */
    private void initialise(Element adminXml) throws Exception
    {
        resetValues();
        adminInfo = new AdminInfo();
        keywordHandler = new KeywordHandler();
        workInfo = null;
        parseAdminInfo(adminXml);
    }
    
    /**
     * Reset, or clear, the list of stored services info.
     */
    private void resetValues()
    {
        services = new HashMap<>();
        serviceTypes = new HashMap<>();
    }
    
    /**
     * Parse the admin info XML to create the service admin info.
     * @param adminXml the xml-based description of the service.
     * @throws java.lang.Exception any error. 
     */
    private void parseAdminInfo(Element adminXml) throws Exception
    {
        ServiceAdminHandler.parseAdminInfo(adminXml, this);
    }

    /**
     * Parse the adminXml element to determine what information it contains.
     * @param adminXml the metadata adminXml.
     * @throws java.lang.Exception any error.
     */
    private void parseAdminXml(Element adminXml) throws Exception
    {
        ServiceAdminHandler.parseAdminXml(adminXml, this);
    }
    
    /**
     * Create a full metadata description of this service. If this is a wrapper
     * for a legacy object, then ask the server for any stored metadata
     * description and use that if available. It may have been created or initialised
     * from one. If it is derived from {@link Service} then create a new one so
     * that the settings are the most recent.
     * The description describes only this service and no nested services.
     * @param jarFile list of remote jar files if loaded remotely.
     * @param adminKey the unique service key for admin purposes.
     * @return a metadata description of this service.
     * @throws java.lang.Exception any error.
     */
    protected ServiceMeta createServiceMeta(ArrayList<String> jarFile, String adminKey)
            throws Exception
    {
        return ServiceAdminHandler.createServiceMeta(jarFile, adminKey, this);
    }
    
    /**
     * Create a full metadata description of this service.
     * The description describes only this service and no nested services.
     * @param jarFile list of remote jar files if loaded remotely.
     * @param adminKey the unique service key for admin purposes.
     * @return a metadata description of this service.
     * @throws java.lang.Exception any error.
     */
    protected ServiceMeta createFullServiceMeta(ArrayList<String> jarFile, String adminKey)
            throws Exception
    {
        return ServiceAdminHandler.createFullServiceMeta(jarFile, adminKey, this);
    }
    
    /**
     * Create a metadata description of the parent service for the server repository. 
     * The description describes only this service and no nested services.
     * @return a metadata description of this service.
     * @throws java.lang.Exception any error.
     */
    protected ServiceMeta createMetaForRepos() throws Exception
    {
        return ServiceAdminHandler.createMetaForRepos(this);
    }

    /**
     * Return the service or module for the related service name. This method returns
     * a wrapper for the service with limited functionality. It should be used only to
     * allow access to nested services on the called service or for invoking methods.
     * @param serviceName the name of the service you want to retrieve.
     * @param thePassword the password for the service you want to retrieve.
     * @return a wrapper containing the service that is retrieved.
     * @throws org.licas.util.exception.ServiceException for service specific error.
     * @throws java.lang.Exception any other error.
     */
    protected ServiceWrapperDef getService(String serviceName, String thePassword)
        throws ServiceException, Exception
    {
        return serviceWrapper(serviceName, thePassword);
    }

    /**
     * Return the service, module or its wrapper for the related service name. This method
     * requires the admin key as well, so that it can try to return a direct reference to the
     * service object. If the service object is not derived from {@code Service}, then the
     * wrapper is returned. If it is derived from Service, then a direct reference is returned.
     * @param serviceName the name of the service you want to retrieve.
     * @param thePassword the password for the service you want to retrieve.
     * @param adminKey the admin key for the service you want to retrieve.
     * @return the service object if it exists or null if it does not.
     * @throws org.licas.util.exception.ServiceException for service specific error.
     * @throws java.lang.Exception any other error.
     */
    public FrameworkModule getServiceOrWrapper(String serviceName, String thePassword, String adminKey)
        throws ServiceException, Exception
    {
        FrameworkModule theService = null;                    //the service
        ServiceWrapperDef aWrapper;                         //service wrapper

        if (service.getPasswordHandler().hasAdminKey(serviceName) &&
            service.getPasswordHandler().getAdminKey(serviceName).equals(adminKey)) {
            aWrapper = serviceWrapper(serviceName, thePassword);
            if (aWrapper != null) {
                if (aWrapper.storesLegacy()) {
                    //if stores legacy code then cannot return the object, so have ot return the wrapper
                    theService = (Service)aWrapper;
                }
                else {
                    //if stores licas service then can return that directly
                    theService = (Service)aWrapper.getObjService(adminKey);
                }
            }
        }

        return theService;
    }

    /**
     * Return the service or module for the related service name. This method requires
     * the service admin key as well, but then returns a direct reference to the service object,
     * no matter what the object type is.
     * @param serviceName the name of the service you want to retrieve.
     * @param thePassword the password for the service you want to retrieve.
     * @param adminKey the admin key for the service you want to retrieve.
     * @return the service object if it exists or null if it does not.
     * @throws org.licas.util.exception.ServiceException for service specific error.
     * @throws java.lang.Exception any other error.
     */
    public Object getService(String serviceName, String thePassword, String adminKey)
        throws ServiceException, Exception
    {
        ServiceWrapperDef aWrapper;                     //service wrapper
        Object serviceObj;                              //service object

        if (service.getPasswordHandler().hasAdminKey(serviceName) &&
                service.getPasswordHandler().getAdminKey(serviceName).equals(adminKey)) {
            aWrapper = serviceWrapper(serviceName, thePassword);
            serviceObj = aWrapper.getObjService(adminKey);
        }
        else {
            throw new ServiceException("ServiceAdmin.getService: incorrect admin key for " +
                    serviceName);
        }

        return serviceObj;
    }

    /**
     * Return the service wrapper for the related service name.
     * @param serviceName the name of the service.
     * @param thePassword the password to access the service to retrieve.
     * @return the service object or null if no service exists.
     * @throws ServiceException is access to any nested services is blocked.
     * @throws java.lang.Exception any other error.
     */
    private ServiceWrapperDef serviceWrapper(String serviceName, String thePassword)
            throws ServiceException, Exception
    {
        ServiceWrapperDef theService = null;            //the service
        ServiceInfo serviceInfo;                        //service info

        //service is the parent service of this admin
        if (service.canAccessNested()) {
            if (services.containsKey(serviceName)) {
                serviceInfo = services.get(serviceName);
                theService = serviceInfo.getService();

                //wrapper does not have these methods now
                //need to check for wrapper here as well as service
                if (!theService.canAccess(thePassword) &&
                    !theService.canAccessTemp(thePassword) &&
                    !service.canAccess(thePassword) &&
                    !service.canAccessTemp(thePassword)) {
                    theService = null;
                }
            }

            //only allowed one use of a temporary password
            service.getPasswordHandler().getTempPasswords().remove(thePassword);

            return theService;
        }
        else {
            throw new ServiceException("Service " + service.getUUID() +
                    " does not allow access to its nested services.");
        }
    }
    
    /**
     * Remove all child services and modules from this service and terminate their threads.
     * @param adminKey the unique key to protect this service.
     * @throws PasswordException incorrect admin key.
     * @throws java.lang.Exception any other error.
     */
    protected void removeAllServices(String adminKey) throws PasswordException,
            Exception
    {
        String nextAdminKey;                        //next admin key
        ServiceInfo nextServiceInfo;                //next service info
        ServiceDef nextService;                     //next service
        
        try {
            if (serviceAdminKey.equals(adminKey)) {
                for (String key : services.keySet())
                {
                    nextAdminKey = service.getPasswordHandler().getAdminKey(key);
                    nextServiceInfo = services.get(key);
                    nextService = nextServiceInfo.getService();

                    try {
                        if (ModuleHandler.isService(nextService)) {
                            ((Service)nextService).removeAllServices(nextAdminKey);
                        }
                    }
                    catch (Exception ex) {
                        throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                            "removeAllServices", null, ex);
                    }

                    //remove the deleted service's metadata from the server
                    if (ModuleHandler.isService(nextService)) {
                        ((Service)nextService).setShutDown(true, nextAdminKey);
                    }

                    Objects.requireNonNull(LocalServer.getApi(service.getServerPassword())).removeServiceMeta(key, nextAdminKey);
                }
            }
        }
        finally
        {
            services.clear();
            serviceTypes.clear();
        }
    }
    
    /**
     * Remove all child services and modules from this service and terminate their threads.
     * @param serviceIDs id list for service passwords to remove. Should be String key or Element path.
     * @param adminKey the unique key to protect this service.
     * @throws PasswordException incorrect admin key.
     * @throws java.lang.Exception any other error.
     */
    protected void removeAllServices(ArrayList<?> serviceIDs, String adminKey)
            throws PasswordException, Exception
    {
        String nextAdminKey;                        //next admin key
        String serviceID;                           //service ID

        if (serviceAdminKey.equals(adminKey)) {
            for (Object keyObj: serviceIDs)
            {
                serviceID = ObjectHandler.getKey((keyObj));
                for (String key : services.keySet())
                {
                    nextAdminKey = service.getPasswordHandler().getAdminKey(key);
                    if (serviceID.equals(key)) {
                        removeService(key, nextAdminKey, true);
                    }
                }
            }
        }
    }
    
    /**
     * Remove the service or module with the indicated ID from the list.
     * @param serviceUuid the uuid of the child service to remove.
     * @param adminKey the unique key to protect the service.
     * @param stopThread true if stop the thread running.
     * @return true if the service has been removed.
     * @throws java.lang.Exception any error.
     */
    protected boolean removeService(String serviceUuid, String adminKey, boolean stopThread)
            throws Exception
    {
        boolean serviceRemoved;                     //true if the service is removed
        String serviceType;                         //the service type
        ArrayList<String> serviceList;              //services list
        ServiceInfo nextServiceInfo;                //service info
        ServiceDef nextService;                     //the service

        serviceRemoved = false;
        if (services.containsKey(serviceUuid)) {
            nextServiceInfo = services.get(serviceUuid);
            nextService = nextServiceInfo.getService();

            if (nextService.isAdminKey(adminKey)) {
                services.remove(serviceUuid);

                serviceType = nextServiceInfo.getServiceType();
                serviceList = serviceTypes.get(serviceType);
                serviceList.remove(serviceUuid);
                if (serviceList.isEmpty()) serviceTypes.remove(serviceType);

                //remove the deleted service's metadata from the server,
                //if it is a base service, meaning the parent of this is the server itself
                if (ModuleHandler.isServer(service)) {
                    Objects.requireNonNull(LocalServer.getApi(service.getServerPassword())).removeServiceMeta(serviceUuid, adminKey);
                } else {
                    service.serviceLinks.removeChildService(serviceUuid);
                }

                try {
                    if (ModuleHandler.isService(nextService)) {
                        //if thread try to shut down
                        if (stopThread) {
                            try {
                                ((Service) nextService).interrupt(adminKey);
                            } catch (Exception ex) { }
                        }

                        //remove any child services
                        ((Service)nextService).removeAllServices(adminKey);
                    }
                }
                catch (Exception ex) {
                    throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                            "removeAllServices", null, ex);
                }

                serviceRemoved = true;
            }
        }
        
        return serviceRemoved;
    }
    
    /**
     * Remove the service or module with the indicated path from the list.
     * @param servicePath the path to the service.
     * @param adminKey the unique key to protect the service.
     * @param stopThread true if stop the thread running.
     * @return true if the service has been removed.
     * @throws java.lang.Exception any error.
     */
    protected boolean removeService(Element servicePath, String adminKey, boolean stopThread)
            throws Exception
    {
        boolean serviceRemoved;                 //true if the service is removed
        String serviceName;                     //service name

        serviceRemoved = false;
        serviceName = Handle.getFirstServiceHandle(servicePath);

        if (serviceName != null) {
            if (serviceName.equals(service.getUUID())) {
                //if the parent service UUID, then make the call on the parent service
                serviceRemoved = service.getParent().removeServicePath(servicePath, adminKey, stopThread);
            }
            else {
                //otherwise remove from this service
                serviceRemoved = removeService(serviceName, adminKey, true);
            }
        }
        
        return serviceRemoved;
    }

    /**
     * Set the work info description for the message bus.
     * @param theWorkInfo the work info description.
     */
    public void setWorkInfo(WorkInfo theWorkInfo) {
        workInfo = theWorkInfo;
    }

    /**
     * Get all child service or module names.
     * @return all service uuids, of type String.
     */
    public ArrayList<String> getServiceNames()
    {
        ArrayList<String> keys;                 //service uuids

        keys = new ArrayList<>(services.keySet());
        return keys;
    }

    /**
     * Return all child service or module names for the specified service type.
     * @param serviceType the service type.
     * @return the service names for the service types list.
     * @throws LicasException if the service types input is {@code null}.
     */
    public ArrayList<String> getServiceNames(String serviceType) throws LicasException
    {
        ArrayList<String> serviceUuids;                 //service uuids

        serviceUuids = new ArrayList<>();
        if (serviceTypes.containsKey(serviceType))
        {
            serviceUuids = serviceTypes.get(serviceType);
        }
        
        return serviceUuids;
    }
    
    /**
     * Return all child service or module names for a list of service types.
     * @param thisServiceTypes the service types list.
     * @param reciprocal if false return all service names of the service types,
     * if true return all service names of all other types.
     * @return the service names for the service types list.
     * @throws LicasException if the service types input is {@code null}.
     */
    public ArrayList<String> getServiceNames(ArrayList<String> thisServiceTypes, boolean reciprocal)
            throws LicasException
    {
        int i;
        String nextServiceType;                     //next service type
        ArrayList<String> typeKeys;                 //list of service types
        ArrayList<String> serviceUuids;             //service uuids

        serviceUuids = new ArrayList<>();
        if (thisServiceTypes == null)
        {
            throw new LicasException("Requested service types is null.");
        }
        
        if (!reciprocal)
        {
            for (i = 0; i < thisServiceTypes.size(); i++)
            {
                nextServiceType = thisServiceTypes.get(i);
                if (serviceTypes.containsKey(nextServiceType))
                {
                    serviceUuids.addAll(serviceTypes.get(nextServiceType));
                }
            }
        }
        else
        {
            typeKeys = new ArrayList<>(serviceTypes.keySet());
            typeKeys.removeAll(thisServiceTypes);

            for (i = 0; i < typeKeys.size(); i++)
            {
                nextServiceType = typeKeys.get(i);
                if (serviceTypes.containsKey(nextServiceType))
                {
                    serviceUuids.addAll(serviceTypes.get(nextServiceType));
                }
            }
        }

        return serviceUuids;
    }

    /**
     * Return all service types for all stored services.
     * @return all service types.
     */
    public ArrayList<String> getServiceTypes()
    {
        ArrayList<String> keys;                 //service uuids

        keys = new ArrayList<>(serviceTypes.keySet());
        return keys;
    }
    
    /**
     * Get the service type for the named service if it exists.
     * @param serviceName the name of the service to look for.
     * @return the service type if it exists, or null otherwise. 
     */
    public String getServiceType(String serviceName)
    {
        ServiceInfo serviceInfo;                //service info
        
        serviceInfo = services.get(serviceName);
        if (serviceInfo != null) return serviceInfo.getServiceType(); 
        else return null;
    }

    /**
     * Get the class types for all services that are stored.
     * @return the service handles with the class types for the services
     * of this component.
     */
    public HashMap<String, String> getServiceClasses()
    {
        String compoundClass;                           //compound description
        ServiceInfo serviceInfo;                        //service info
        Object nextService;                             //next service
        Class nextObjClass;                             //next object class
        HashMap<String, String> classTypes;             //the class types

        classTypes = new HashMap<>();

        for (String key : services.keySet())
        {
            serviceInfo = services.get(key);
            nextService = serviceInfo.getService();
            compoundClass = nextService.getClass().getName();

            if (nextService instanceof ServiceWrapper)
            {
                nextObjClass = ((ServiceWrapper)nextService).getObjClass();
                if (nextObjClass != null) compoundClass += Const.COLON + nextObjClass.getName();
            }

            classTypes.put(key, compoundClass);
        }

        return classTypes;
    }
    
    /**
     * Set a full admin info description for the service.
     * @param adminXml the full admin description.
     * @throws java.lang.Exception any error.
     */
    protected void setAdminInfo(Element adminXml) throws Exception
    {
        parseAdminXml(adminXml);
    }
    
    /**
     * Get the admin info object itself.
     * @return the value of adminInfo.
     */
    public AdminInfo getAdminInfo()
    {
        return adminInfo;
    }
    
    /**
     * Get the contract manager.
     * @return the value of contractManager.
     */
    public ContractManager getContractManager()
    {
        return contractManager;
    }
    
    /**
     * Get the keyword handler that processes keywords.
     * @return the value of keywordHandler.
     */
    public KeywordHandler getKeywordHandler()
    {
        return keywordHandler;
    }
    
    /**
     * After parsing the instance values, call this to set it to {@code null}.
     */
    public void clearInstanceValues()
    {
        adminInfo.setInstanceValues(null);
    }
    
    /**
     * Get the script part describing actual variable instance values, if one was included.
     * @return the value of instanceValues.
     */
    public Element getInstanceValues()
    {
        return adminInfo.getInstanceValues();
    }
}
