/*
 * Auto.java
 *
 * Created on 28 March 2007
 *
 * Version 2.18.1
 *
 * Copyright (c) Kieran Greer
 *
 */

package org.licas;


import org.licas.autonomic.*;
import org.licas.autonomic.script.AutoEngine;
import org.licas.call.*;
import org.licas.module.BehaviourModule;
import org.licas.module.ModuleHandler;
import org.licas.module.s_module.SM_Auto;
import org.licas.parsers.Parsers;
import org.licas.server.*;
import org.licas.service.DataService;
import org.licas.service.sci.LinkService;
import org.licas.util.*;
import org.licas.util.exception.*;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.Monitor;

import org.dcs.query_process.model.activity.Script_Auto;
import org.dcs.query_process.util.Script_Const;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Objects;
import java.util.Vector;


/**
 * This is the base class for a service with added autonomic or agent-based functionality. 
 * An {@code Auto} class is different to a {@link Service} in the sense that it should try to 
 * run more independently. It can run its own thread to periodically execute its own behaviour.
 * The Auto service can also manage conversations with other services by storing separate communication 
 * IDs for each conversation thread. This is not the strict agent-based protocols, but entirely
 * arbitrary to the service itself. If you want to use an {@link AutonomicManager} with your service, 
 * then you must load an Auto-derived class and not a Service-derived class.
 * <p>
 * When a service is loaded, the {@code server} automatically adds an empty Autonomic Manager 
 * to any Auto-derived service, as a wrapper object. If you then start an Auto derived class’s 
 * thread and execute behaviours; if any monitoring modules are added, they can process the behaviour 
 * results. If you just want to use the more advanced features of an Auto class, you do not need to 
 * add anything else. 
 * <p>
 * The behaviour thread's {@code run} loop implements the main control loop that links with 
 * the empty MAPE slots and so you can use them if needed, by adding specific functionality 
 * to the modules that you might require. Looking at the Auto class should show what methods 
 * you need to implement yourself to create your own autonomic service. The other option is to 
 * invoke the behaviour directly through the {@code invokeBehaviour} method. this can only be
 * used if the main thread is not running.
 * <p>
 * The {@code Auto} class is still abstract however, where you must extend it to add specific
 * behaviour functionality and implement a number of additional methods. See the {@link LinkService}, 
 * for example.
 * @author Kieran Greer
 */
public abstract class Auto extends DataService
{
    /** The logger */
    private static final Logger logger;
    
    /** 
     * Time period between behaviour events. 
     * Allocated a default value of {@link ServiceConst}.{@code BEHAVIOURLOOPSLEEP} milliseconds.
     */
    protected long sleepTime;
    
    /** 
     * Number of behaviour events to execute, then shut-down the service. 
     * If {@code iterations <= 0} then execute continuously.
     */
    protected long iterations;

    /**
     * Module to manage the actions of the behaviour.
     */
    protected BehaviourModule bm;

    /** Auto engine for this service, not the autonomic manager. Can be configured through the admin script. */
    protected AutoEngine autoEngine;
    
    /** The autonomic manager monitoring this service */
    protected AutonomicManager autoManager;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(Auto.class.getName());
        logger.setDebug(false);
    }

    /** 
     * Creates a new instance of Auto.
     * Password and service key set to {@code anon} by default.
     * @throws java.lang.Exception any error.
     */
    public Auto() throws Exception
    {
        super();        
        initialise();
    }
    
    /** 
     * Creates a new instance of Auto.
     * @param thisPassword password to invoke this service.
     * @param thisAdminKey admin key for this service.
     * @throws java.lang.Exception any error.
     */
    public Auto(String thisPassword, String thisAdminKey) throws Exception
    {
        super(thisPassword, thisAdminKey);        
        initialise();
    }
    
    /** 
     * Creates a new instance of Auto.
     * @param thisPassword password to invoke this service.
     * @param thisAdminKey admin key for this service.
     * @param adminXml the admin info or description of this service.
     * @throws java.lang.Exception any error.
     */
    public Auto(String thisPassword, String thisAdminKey, Element adminXml)
            throws Exception
    {
        super(thisPassword, thisAdminKey, adminXml);
        initialise();
    }
    
    /** 
     * Initialise some values.
     * @throws java.lang.Exception any error.
     */
    private void initialise() throws Exception
    {
        String nextValue;
        HashMap<String, Element> additional;        //additional metadata
        
        sleepTime = ServiceConst.BEHAVIOURLOOPSLEEP;
        iterations = 0;
        autoManager = null;
        setAutoEngine();

        additional = serviceAdmin.getAdminInfo().getAdditional();
        if (additional.containsKey(AiConst.PROCESS)) {
            autoEngine.setEventRuleAction(additional.get(AiConst.PROCESS));
        }
        if (additional.containsKey(ServiceConst.TIMER)) {
            nextValue = (additional.get(ServiceConst.TIMER)).getText();
            sleepTime = Long.parseLong(nextValue);
        }
        if (additional.containsKey(AiConst.ITERATIONS)) {
            nextValue = (additional.get(AiConst.ITERATIONS)).getText();
            iterations = Long.parseLong(nextValue);
        }

        setBehaviourModule();
    }

    /**
     * Set the type of behaviour that the control loop uses to evaluate the service.
     * @throws java.lang.Exception any error.
     */
    protected void setBehaviourModule() throws Exception
    {
        bm = ModuleHandler.behaviourModule(this, passwordHandler);
    }

    /**
     * Initialise and create the auto engine.
     */
    protected void setAutoEngine()
    {
        if (autoEngine == null)
        {
            autoEngine = new AutoEngine(this, passwordHandler);
        }
    }

    /**
     * Get the auto engine.
     * @return the value of autoEngine.
     */
    protected AutoEngine getAutoEngine()
    {
        return autoEngine;
    }
    
    /**
     * Set actual values for variable instances if they are defined.
     * <p>
     * {@code NOTE:} you must add this method to your own derived class if you use it,
     * so that the private variables in that class can be accessed. It is ignored
     * unless it gets called through the script initialisation process.
     * @param instanceValues the admin script part that defines instance values.
     * @throws java.lang.Exception any error.
     */
    protected void setInstanceValues(Element instanceValues) throws Exception
    {
        int i;
        String varName;                             //variable name
        Element instanceValue;                      //instance value
        Element nextElem;                           //next element
        Vector<Node> elemList;                      //list of elements
        Field instField;                            //instance field
        Object valueObj;                            //value object
        
        if (instanceValues != null)
        {
            elemList = instanceValues.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                instanceValue = (Element)elemList.get(i);  
                varName = instanceValue.getAttributeValue(Const.NAME);               
                nextElem = instanceValue.getElementChildAtIndex(0);
                valueObj = Parsers.parse(nextElem);

                if (valueObj != null)
                {
                    instField = ReflectionHandler.getInstanceField(this, varName);
                    if (instField != null)
                    {
                        try {
                            instField.set(this, valueObj);
                        }
                        catch (Exception ex) {}
                    }
                }
            }
        }
    }
    
    /**
     * Get the value of the specified variable if it exists.
     * <p>
     * {@code NOTE:} you must add this method to your own derived class if you use it,
     * so that the private variables in that class can be accessed. It is ignored
     * unless it gets called through the script initialisation process.
     * @param varName the name of the variable to check for.
     * @throws java.lang.Exception any error.
     */
    protected Object getInstanceValue(String varName) throws Exception
    {
        int i;
        Field nextField;                            //next field
        Field[] fields;                             //fields from this class
        Object fieldValue;                          //field value

        fieldValue = null;
        if ((varName != null) && !varName.equals(""))
        {
            fields = this.getClass().getDeclaredFields();
            for (i = 0; (fieldValue == null) && (i < fields.length); i++)
            {
                nextField = fields[i];
                if (nextField.getName().equalsIgnoreCase(varName))
                {
                    try {
                        fieldValue = fields[i].get(this);
                    }
                    catch (Exception ex) {
                        fieldValue = null;
                    }
                }
            }

            if (fieldValue == null)
            {
                fields = this.getClass().getFields();
                for (i = 0; (fieldValue == null) && (i < fields.length); i++)
                {
                    nextField = fields[i];
                    if (nextField.getName().equalsIgnoreCase(varName)) {
                        try {
                            fieldValue = fields[i].get(this);
                        }
                        catch (Exception ex) {
                            fieldValue = null;
                        }
                    }
                }
            }
        }

        return fieldValue;
    }
    
    /**
     * Set actual values for serialized variable instances if they are defined.
     * <p>
     * {@code NOTE:} you must add this method to your own derived class if you
     * use it, so that the private variables in that class can be accessed.
     * @param serializeXml the admin script part that defines serialize instance
     * values.
     * @throws java.lang.Exception any error.
     */
    protected void setSerializeValues(Element serializeXml) throws Exception
    {
        int i;
        String varName;                             //variable name
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Vector<Node> elemList;                      //element list
        Field instField;                            //instance field
        Object valueObj;                            //value object

        if (serializeXml != null)
        {
            elemList = serializeXml.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextElem = (Element) elemList.get(i);
                if (nextElem.getName().equals(Const.SERIALISEVALUE))
                {
                    varName = nextElem.getAttributeValue(Const.NAME);
                    if (!varName.equals(MetaConst.ADMIN))
                    {
                        if (nextElem.hasChildren())
                        {
                            nextElem2 = nextElem.getElementChildAtIndex(0);
                            valueObj = Parsers.parse(nextElem2);
                            if (valueObj != null)
                            {
                                instField = ReflectionHandler.getInstanceField(this, varName);
                                if (instField != null)
                                {
                                    try {
                                        instField.set(this, valueObj);
                                    }
                                    catch (Exception ex) {}
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Set or update the auto engine {@link AiConst}.{@code PROCESS} script to execute
     * a (business) process through the script description.
     * @param theScript the auto engine script to execute.
     * @param adminKey the admin key for the service.
     * @return true if set, false if the password is incorrect.
     * @throws java.lang.Exception any error.
     */
    public boolean setProcessScript(Element theScript, String adminKey)  throws Exception
    {
        if (passwordHandler.isAdminKey(adminKey))
        {
            serviceAdmin.getAdminInfo().getAdditional().put(AiConst.PROCESS, theScript);
            autoEngine.setEventRuleAction(serviceAdmin.getAdminInfo().getAdditional().get(AiConst.PROCESS));
            return true;
        }
        
        return false;
    }

    /**
     * Execute a behaviour, such as an evaluation and result.
     * @param messageInfo the message to evaluate.
     * @return the result of executing the behaviour.
     * @throws java.lang.Exception any error.
     */
    protected abstract MessageInfo behaviourAction(MessageInfo messageInfo) throws Exception;


    /**
     * This can be used to execute a single invocation of the service's {@code evaluateBehaviour} method.
     * This is correct if the service is waiting to be invoked and is not running on a thread.
     * @param messageInfo the message with data to evaluate. This is only the values
     * related to the evaluation result, not the whole set of service values.
     * @return the evaluation reply. This is the {@code evaluateBehaviour} {@link MessageInfo}
     * reply object. If this is not one of the basic types, a parser needs to be added to parse
     * the complex object to/from XML.
     * @throws ServiceException if this service's main thread is currently running.
     * @throws java.lang.Exception and error.
     */
    public Object invokeBehaviour(MessageInfo messageInfo) throws ServiceException, Exception
    {
        if ((sm != null) && (sm instanceof SM_Auto))
        {
            return ((SM_Auto)sm).invokeBehaviour(messageInfo);
        }
        else
        {
            throw new ServiceException("Auto class " + getUUID() +
                    " has not been initialised with an appropriate behaviour module.");
        }
    }

    /**
     * This is the default method to start the service thread.
     * This default process periodically executes and evaluates a behaviour.
     */
    public void run()
    {
        long loopCount;                 //number of behaviour executions
        String serverPassword;          //server password

        try
        {
            LoggerHandler.logMessage(logger, LoggerHandler.INFO, "run",
                "Service thread starting: " + getUUID() + ": " + this.getClass().getName());
                
            loopCount = 0;
            while (!getShutDown())
            {
                try 
                {
                    if (!passwordHandler.hasServicePassword(Const.HTTPSERVER))
                    {
                        serverPassword = getServerPassword();
                        if (serverPassword != null) {
                            passwordHandler.addServicePassword(Const.HTTPSERVER, serverPassword);
                        }
                    }
                    
                    try
                    {
                        if (!getShutDown()) {
                            ((SM_Auto)sm).evaluateBehaviour();
                            loopCount++;
                        }
                    }
                    catch (ServiceException se) {
                        //only add a minor entry, as this exception is not always fatal
                        logger.logMessage(LoggerHandler.WARN, "run", se.getMessage());
                    }
                    catch (Exception ex1) {
                        ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "run", null, ex1);
                        setShutDown(true);
                    }
                    finally {
                        if (!getShutDown()) {
                            setShutDown(sleepTime <= 0);
                            if (!getShutDown()) {
                                setShutDown((loopCount >= iterations) &&
                                            (iterations > 0));
                            }
                        }
                        
                        Monitor.getMonitor().release();
                        ThreadHandler.notifyAllEvents();
                        if (!getShutDown()) Thread.sleep(sleepTime);
                    }      
                } 
                catch (InterruptedException iex) {
                    setShutDown(true);
                } 
                catch (Exception ex2) {
                    setShutDown(true);
                    ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "run", null, ex2);
                }

                if (!getShutDown()) {
                    try {
                        setShutDown(Objects.requireNonNull(LocalServer.getApi(getServerPassword())).getServerShutDown());
                    }
                    catch (Exception ex) {
                        setShutDown(true);
                    }
                }
                
                //ask for garbage collection
                if (!getShutDown()) System.gc();
            }
        }
        catch (Exception ex3)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "run", null, ex3);
        }
        finally
        {
            Monitor.getMonitor().release();
            ThreadHandler.notifyAllEvents();
            LoggerHandler.logMessage(logger, LoggerHandler.INFO, "run",
                "Service shutting down: " + getUUID() + ": " + this.getClass().getName());
        }
    }
    
    /**
     * Retrieve and remove the first message on the auto manager's queue with the
     * specified condition - method name, timestamp, etc.
     * @param scriptAuto the script element with a single condition to use.
     * @param adminKey the admin key for this service.
     * @return the message object if one exists, null otherwise.
     * @throws PasswordException if the admin key is incorrect.
     */
    public MessageInfo autoQueueMessage(Script_Auto scriptAuto, String adminKey) throws PasswordException
    {
        if (passwordHandler.isAdminKey(adminKey))
        {
            if (scriptAuto.useOperationName())
            {
                return autoManager.getMessageQueue(adminKey).getAndRemoveNextMessageName(scriptAuto.getOperation());
            }
            else if (scriptAuto.useTimestamp())
            {
                return autoManager.getMessageQueue(adminKey).getAndRemoveNextMessageTime(scriptAuto.getTimestamp());
            }
        }
        else
        {
            throw new PasswordException("Admin key for " + sm.getUUID() + " is incorrect.");
        }
        
        return null;
    }
    
    /**
     * This allows the autonomic manager to ask the parent service to perform some action.
     * @param action to action to perform.
     * @param adminKey the admin key for this service.
     * @throws PasswordException if the admin key is incorrect.
     * @throws ServiceException if a licas service problem occurs.
     * @throws java.lang.Exception any other error.
     */
    public void autoAction(String action, String adminKey) throws PasswordException,
            ServiceException, Exception
    {
        if (passwordHandler.isAdminKey(adminKey))
        {
            if (action.equals(AiConst.ACTION))
            {
                ((SM_Auto)sm).evaluateBehaviour();
            }
        }
        else
        {
            throw new PasswordException("Admin key for " + sm.getUUID() + " is incorrect.");
        }
    }
    
    /**
     * Remove the communication ID reference.
     * @param commID the communication ID.
     */
    protected void removeCommunicationID(String commID)
    {
        if (commID != null)
        {
            super.removeCommunicationID(commID);
        }
    }

    /**
     * This can be used as part of a conversation, for example, to reply to some other method invocation, or even 
     * to start a conversation. The {@code message} object is added to the service queue, wrapped in a {@link MessageInfo} 
     * object, with optional states and conversation protocol. It is also used internally by the communication system to 
     * queue the {@link CallObject} {@link MethodInfo} requests. When accessed through the communication mechanism, 
     * a {@code communicationID} from the client has already been looked for in the (MethodInfo) message object. 
     * That could then be used to identify this particular message, or as part of conversation. 
     * <p>
     * If used internally, the {@code MethodInfo} message is re-packaged with some state information, 
     * before being queued in the {@link AutonomicManager}. The messages are then lifted off the queue in order, 
     * as part of an {@code asynchronous} process. If the parameter is a MessageInfo object itself, it is queued as 
     * is and so its state and other values can be set. This would allow for a conversation protocol, for example.
     * <p>
     * The {@link AutonomicManagerDefault} now records some basic stats for the messages that are received,
     * such as number of calls or message size, as would be the case for any server. It is
     * stored locally to this service, not globally in the server, but the server can query it.
     * There is no other monitoring as default and so messages just get added and removed in order, 
     * without any consideration of their state or content. The state variables are
     * therefore ignored by the default system and the message object is simply stored and 
     * returned again. For example, the {@code evaluateBehaviour} method calls {@code autoManager.getMessage} 
     * to retrieve the next message Object to evaluate. You can change any of this in a derived class.
     * <p>
     * One final important option is in fact to ask the system <i>not</i> to queue the message.
     * If the message parameter is a {@code MessageInfo} object and has a {@code message state} of
     * {@link AiConst}.{@code NOACTION} already added, then it is <i>not added</i> to the message queue.
     * You could add service-specific code to process it further, where this allows for an 
     * immediate response, such as setting a variable value, on the service itself.
     * @param message an object representing the result of the task. Can be null.
     * @return true if processed correctly, or false if there is no autonomic manager.
     * @throws java.lang.Exception any error.
     */
    public boolean messageReply(Object message) throws Exception
    {
        String commID;                          //message id
        String messageState;                    //the message function state
        MessageInfo messageInfo;                //the new message
                
        if (autoManager != null)
        {
            //get current communication id, new message state and add to message queue
            commID = sm.getCommID();
            messageState = getMessageState(message); 

            if (!messageState.equals(AiConst.NOACTION))
            {
                if (message instanceof MessageInfo) {
                    messageInfo = (MessageInfo)message;
                }
                else {
                    messageInfo = new MessageInfo(commID, message);
                }

                messageInfo.setTimeStamp();
                messageInfo.setInOut(Script_Const.INPUT);
                messageInfo.setMessageState(messageState);
                messageInfo.setServiceState(getServiceState(passwordHandler.getAdminKey()));
                messageInfo.setCommID(commID);
                autoManager.addMessage(messageInfo, passwordHandler.getAdminKey());
            }
            
            return true;
        }

        return false;
    }
    
    /**
     * Calculate the current state for the message and related conversation. If this
     * service is involved in conversations with several other services, for example,
     * each conversation can be at a different stage, resulting in a different state
     * for each conversation process. This method should be used to return the current
     * state for the specified conversation. It should be implemented by any derived 
     * class, but only called internally, inside the {@code messageReply} method, for example.
     * <p>
     * This default version checks if the message parameter is a {@link MessageInfo} object.
     * If it is, it returns its {@code getMessageState} method call. If it is not, then it
     * returns the thread state for this service. 
     * @param message an object representing a result from the other service in the
     * conversation. This can represent the result of the last conversation task, 
     * or can be null if no information is required.
     * @return the state of this service relating to the selected conversation.
     */
    protected String getMessageState(Object message)
    {
        if (message instanceof MessageInfo) {
            return ((MessageInfo)message).getMessageState();
        }
        
        return threadAliveState();
    }
    
    /**
     * Set a reference to the autonomic manager monitoring this service.
     * @param thisAutoManager the autonomic manager.
     * @throws java.lang.Exception any error.
     */
    protected void setAutonomicManager(AutonomicManager thisAutoManager) throws Exception
    {
        if (autoManager == null)
        {
            autoManager = thisAutoManager;
            if (sm != null) ((SM_Auto)sm).setAutonomicManager(autoManager);
            else setServiceModule();
        }
    }
    
    /**
     * You must call this method to interrupt the thread.
     * This also interrupts all nested services.
     * @param adminKey the key to identify unique loading of the service.
     * @return true if the service is stopped.
     */
    public boolean interrupt(String adminKey)
    {
        try
        {
            if (!isInterrupted() && isAdminKey(adminKey))
            {
                try {
                    if (autoEngine != null)
                    {
                        autoEngine.getScriptEngine().setIsFinished();
                    }
                } catch (Exception aex) {}
                try {
                    if (autoManager != null)
                    {
                        autoManager.interrupt();
                    }
                } catch (Exception aex2) {}

                try {
                    interrupt();
                    return true;
                }
                catch (Exception ex)
                {}
            }
        } 
        catch (Exception ex) 
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "interrupt", null, ex);
        }
        
        return false;
    }
}
