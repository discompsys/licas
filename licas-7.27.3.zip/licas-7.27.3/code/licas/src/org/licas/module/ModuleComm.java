/*
 * ModuleComm.java
 *
 * Created on 1 October 2019
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module;


/**
 * Communication bridge between protected {@link FrameworkModule} methods and other packages.
 * @author Kieran Greer
 */
public class ModuleComm
{
    /**
     * Get the service module password.
     * @param frameworkModule the service module.
     * @return the service password.
     */
    public static String getPassword(FrameworkModule frameworkModule)
    {
        return frameworkModule.getPasswordHandler().getPassword();
    }

    /**
     * Get the service module admin key.
     * @param frameworkModule the service module.
     * @return the admin key.
     */
    public static String getAdminKey(FrameworkModule frameworkModule)
    {
        return frameworkModule.getPasswordHandler().getAdminKey();
    }

    /**
     * Get the local server password if it is stored.
     * @param frameworkModule the service module.
     * @return the local server password.
     * @throws java.lang.Exception any error.
     */
     public static String getServerPassword(FrameworkModule frameworkModule) throws Exception
     {
         return frameworkModule.getServerPassword();
     }

    /**
     * Indicate to stop the module's service thread. Must be of type
     * {@link ServiceModule} or derived.
     * @param frameworkModule the service module.
     */
    public static void shutDown(FrameworkModule frameworkModule)
    {
        if (ModuleHandler.isServiceModule(frameworkModule)) {
            ((ServiceModule) frameworkModule).setShutDown(true);
        }
    }
}
