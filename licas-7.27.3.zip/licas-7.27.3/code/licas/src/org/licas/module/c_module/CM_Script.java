/*
 * CM_Script.java
 *
 * Created on 9 October 2019
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module.c_module;


import org.licas.PasswordHandler;
import org.licas.Service;
import org.jlog2.*;
import org.licas_xml.abs.Element;

/**
 * This class provides functionality for a service to run an autonomic script.
 */
public abstract class CM_Script extends CM_Auto {

    /** The logger */
    private static final Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(CM_Script.class.getName());
        logger.setDebug(false);
    }

    /**
     * Creates a new instance of CM_Script.
     * @param pService the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public CM_Script(Service pService, PasswordHandler pHandler) throws Exception
    {
        super(pService, pHandler);
    }

    /**
     * Create the policy description that can be used as a default script for initialising the
     * auto engine of this service. This if for the service itself, not any related autonomic
     * manager.
     * @return a policy script to initialise the service with.
     * @throws Exception any error.
     */
    public abstract Element createProcessScript() throws Exception;
}
