/*
 * SM_Script.java
 *
 * Created on 9 October 2019
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module.s_module;


import org.licas.*;
import org.licas.module.c_module.CM_Script;
import org.jlog2.*;
import org.licas_xml.abs.Element;


/**
 * This class provides functionality for a service to run an autonomic script.
 * The methods are in a separate {@link CM_Script} class.
 * @author Kieran Greer
 */
public abstract class SM_Script extends SM_Auto {

    /** The logger */
    private static final Logger logger;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SM_Script.class.getName());
        logger.setDebug(false);
    }

    /**
     * Creates a new instance of ScriptModule.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public SM_Script(Service service, PasswordHandler pHandler) throws Exception
    {
        super(service, pHandler);
    }

    /**
     * Create the policy description that can be used as a default script for initialising the
     * auto engine of this service. This if for the service itself, not any related autonomic
     * manager.
     * @return a policy script to initialise the service with.
     * @throws Exception any error.
     */
    public abstract Element createProcessScript() throws Exception;
}
