/*
 * BM_Script.java
 *
 * Created on 16 October 2019
 *
 * Version 1.0.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module.b_module;


import org.licas.*;
import org.licas.module.HeuristicModule;
import org.licas.module.s_module.SM_Data;
import org.licas.autonomic.script.ActionSequential;
import org.licas.module.BehaviourModule;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.UuidHandler;
import org.licas.util.KeyValue;

import java.util.ArrayList;


/** Behaviour to read and execute an auto script */
public class BM_Script extends BehaviourModule {

    /** The logger */
    private static final Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(BM_Script.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of BM_Script.
     * @param service the service the behaviour is for.
     * @param passwordHandler the service's password handler.
     * @throws java.lang.Exception any error.
     */
    public BM_Script(Auto service, PasswordHandler passwordHandler) throws Exception
    {
        super(service, passwordHandler);
    }

    /**
     * Run the behaviour evaluation.
     * @param messageInfo the Input message to evaluate.
     * @param evaluate heuristic to evaluate the behaviour with.
     * @param sm the service module.
     * @return the evaluation result.
     * @throws java.lang.Exception any error.
     */
    public MessageInfo behaviourAction(MessageInfo messageInfo,
                                       HeuristicModule evaluate,
                                       SM_Data sm) throws Exception
    {
        MessageInfo messageReply;               //message reply
        Object reply;                           //auto event reply

        try
        {
            reply = autoEvent(messageInfo);
            messageReply = new MessageInfo(ServiceComm.getCommID(service), reply);

            return messageReply;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "behaviourAction", null, ex);
        }
    }

    /**
     * Execute a configurable autonomic event, based on the evaluation result.
     * @param autoMessage the message object with the desired evaluation result.
     * Can be {@code null} when a unique commID is created instead. All other variables
     * are taken from the script only.
     * @return the result of the final effector method execution.
     * @throws java.lang.Exception any error.
     */
    protected Object autoEvent(MessageInfo autoMessage) throws Exception
    {
        String commID;                          //communication id
        ArrayList<KeyValue> evalVars;           //variables for the evaluation stage
        ArrayList<KeyValue> effVars;            //variables for the effector stage
        ActionSequential actSeq;                //sequential action

        try {
            //list of variables for evaluating
            evalVars = new ArrayList<>();
            effVars = new ArrayList<>();

            if (autoMessage == null) {
                commID = UuidHandler.getUuid(10);
            }
            else {
                commID = autoMessage.getCommID();
            }

            //execute a standard sequential instruction set on the engine
            actSeq = new ActionSequential();
            actSeq.setEvalVars(evalVars);
            actSeq.setEffVars(effVars);
            return actSeq.sequential(commID, (new AutoComm().getAutoEngine((Auto)service)));
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "autoEvent", null, ex);
        }
    }
}
