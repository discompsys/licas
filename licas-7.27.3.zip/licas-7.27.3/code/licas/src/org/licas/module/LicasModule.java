/*
 * LicasModule.java
 *
 * Created on 12 October 2019
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module;


import org.licas.call.*;
import org.licas.service.JarFactory;
import org.licas.util.*;
import org.licas.util.classloader.LoadObject;
import org.licas_xml.abs.Element;
import org.jlog2.*;

import java.util.ArrayList;


/**
 * This is a base class for all of the licas modules and services. It stores very limited
 * functionality related to threading and object loading and any derived modules do not
 * have to be service-related. Thread is extended to make that functionality available
 * to any derived classes.
 * @author Kieran Greer
 */
public class LicasModule extends Thread
{
    /** The logger */
    private static final Logger logger;


    /** This is the ID of the component */
    protected String uuid;

    /**
     * A list of jar files required to load in this service.
     * Values are jar file paths of type String.
     */
    protected ArrayList<String> jarFile;

    /** To synchronize this service internally on */
    protected final Object syncOn = new Object();


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(LicasModule.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of LicasModule.
     */
    public LicasModule()
    {
        uuid = null;
        jarFile = null;
    }

    /**
     * Create a new instance of the specified object and return. This method also
     * tries to retrieve the object using a remote jar factory.
     * @param theJarUris uris from which the remote object can be loaded, only if needed.
     * @param theClassName the name of the class.
     * @param params initialisation parameters.
     * @return the loaded object.
     * @throws Exception any error.
     */
    public Object loadObject(ArrayList<String> theJarUris, String theClassName, ArrayList<Object> params)
            throws Exception
    {
        int i;
        String nextJarPath;                         //next jar file path
        String newJarPath;                          //new jar file path
        String[] jarUri;                            //parsed jar uri
        Element serverUri;                          //the server uri
        Object serviceObj;                          //the service object
        MethodInfo methodInfo;                      //the method info
        CallObject callObj;                         //to make the remote call
        FileObject fileObject;                      //the returned object

        newJarPath = null;
        callObj = new CallObject();

        if ((theJarUris != null) && !theJarUris.isEmpty() && (JarFactory.getInstance() != null)) {
            i = 0;

            while (i < theJarUris.size())
            {
                nextJarPath = theJarUris.get(i);
                if (UriHandler.isJarfactoryFile(nextJarPath)) {
                    jarUri = UriHandler.getJarFactoryParsed(nextJarPath);
                    theJarUris.remove(i);
                    serverUri = Handle.createNewServerHandle(jarUri[0]);

                    methodInfo = new MethodInfo();
                    methodInfo.setName(MethodConst.GETJARFORSERVICE);
                    methodInfo.setRtnType(FileObject.class.getName());
                    methodInfo.setCallTimeout(600000);
                    methodInfo.setServiceURI(serverUri);
                    methodInfo.setServerPassword(jarUri[1]);
                    methodInfo.setPassword(jarUri[1]);
                    methodInfo.addParam(new ParamInfo(jarUri[2]));
                    fileObject = (FileObject)callObj.call(methodInfo);

                    if (fileObject != null) {
                        newJarPath = JarFactory.getInstance().saveJarFile(fileObject);
                    }
                }
                else {
                    i++;
                }
            }
        }

        if (newJarPath != null) theJarUris.add(newJarPath);
        serviceObj = LoadObject.loadObject(theJarUris, theClassName, params);
        return serviceObj;
    }

    /**
     * Return if the thread is running or not.
     * @return true if running (started and not yet died), false otherwise.
     */
    public String threadAliveState()
    {
        return String.valueOf(this.isAlive());
    }

    /**
     * Set the ID value, but only if it is null, otherwise it is not changed.
     * This method should probably not be called manually as the uuid is
     * automatically set when the service is loaded as the service name.
     * @param thisUUID the ID.
     */
    public void setUUID(String thisUUID)
    {
        if (uuid == null)
        {
            uuid = thisUUID;
        }
    }

    /**
     * Get the unique service ID.
     * @return the value of uuid.
     */
    public String getUUID()
    {
        return uuid;
    }

    /**
     * Set the list of jar files required to load the service,
     * but only if the existing list is null, otherwise it is not changed.
     * @param theJarFile the jar file list. Values are jar paths of type String.
     */
    public void setJarFile(ArrayList<String> theJarFile)
    {
        if (jarFile == null) jarFile = theJarFile;
    }

    /**
     * Get the list of jar files required to load the service.
     * @return the value of jarFile. Values are jar paths of type String.
     */
    public ArrayList<String> getJarFile()
    {
        if (jarFile != null)
        {
            return (ArrayList<String>)jarFile.clone();
        }

        return null;
    }
}
