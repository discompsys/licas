/*
 * SM_Auto.java
 *
 * Created on 9 October 2019
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module.s_module;


import org.licas.MessageInfo;
import org.licas.autonomic.AutonomicManager;
import org.licas.autonomic.script.AutoEngine;
import org.licas.PasswordHandler;
import org.licas.Service;
import org.licas.module.c_module.CM_Auto;
import org.licas.util.exception.ServiceException;
import org.jlog2.*;


/**
 * This class provides functionality for a service to run an autonomic behaviour loop.
 * The methods are in a separate {@link CM_Auto} class.
 * @author Kieran Greer
 */
public class SM_Auto extends SM_Data {

    /** The logger */
    private static final Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SM_Auto.class.getName());
        logger.setDebug(false);
    }

    /**
     * Creates a new instance of SM_Auto.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public SM_Auto(Service service, PasswordHandler pHandler) throws Exception
    {
        super(service, pHandler);
    }

    /**
     * Set the autonomic manager, which is usually set later.
     * @param autoMan the autonomic manager.
     * @throws java.lang.Exception any error.
     */
    public void setAutonomicManager(AutonomicManager autoMan) throws Exception
    {
        ((CM_Auto) cm).setAutonomicManager(autoMan);
    }

    /**
     * Main method to execute the behaviour and evaluate the result, where the input
     * message used is the first message on the autonomic manager's message queue.
     * If the autonomic manager is missing for some reason, the second evaluateBehaviour
     * method is called with a {@code null} parameter. This default version will probably
     * work for general cases. It is based on retrieving the next message on the message queue,
     * performing an action on that, and then monitoring the result by sending the reply
     * through the {@link AutonomicManager} control loop. The control loop is empty
     * by default, but all of these classes have been added to integrate the process
     * with the normal running of the system. Any derived class can override this method
     * or related parts, to change the behaviour and evaluation control loop.
     * @throws ServiceException probably for password or service not found.
     * @throws Exception any error.
     */
    public void evaluateBehaviour() throws ServiceException, Exception
    {
        ((CM_Auto) cm).evaluateBehaviour();
    }

    /**
     * This can be used to execute a single invocation of the service's {@code evaluateBehaviour} method.
     * This is correct if the service is waiting to be invoked and is not running on a thread.
     * This version runs each invocation in a separate thread and also passes the message
     * reply through the autonomic manager.
     * @param messageInfo the message with data to evaluate. This is only the values
     * related to the evaluation result, not the whole set of service values.
     * @return the evaluation reply. This is the {@code evaluateBehaviour} {@link MessageInfo}
     * reply object. If this is not one of the basic types, a parser needs to be added to parse
     * the complex object to/from XML.
     * @throws ServiceException if this service's main thread is currently running.
     * @throws Exception any other error.
     */
    public Object invokeBehaviour(MessageInfo messageInfo) throws ServiceException, Exception
    {
        return ((CM_Auto) cm).invokeBehaviour(messageInfo);
    }

    /**
     * Evaluate a behaviour message by calling {@code behaviourAction} and return the reply.
     * @param inputMessage the data message to evaluate. This can be {@code null}, depending on
     * your requirements, where the message queue is not accessed here.
     * @return the evaluation reply.
     * @throws ServiceException probably for password or service not found.
     * @throws Exception and error.
     */
    public MessageInfo evaluateBehaviour(MessageInfo inputMessage) throws ServiceException, Exception
    {
        return ((CM_Auto) cm).evaluateBehaviour(inputMessage);
    }

    /**
     * Get the auto engine.
     * @return the value of autoEngine.
     */
    public AutoEngine getAutoEngine()
    {
        return ((CM_Auto) cm).getAutoEngine();
    }
}
