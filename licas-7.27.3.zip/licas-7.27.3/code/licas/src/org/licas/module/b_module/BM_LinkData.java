/*
 * BM_LinkData.java
 *
 * Created on 16 October 2019
 *
 * Version 1.2.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module.b_module;

import org.ai_heuristic.eval.EvaluateBase;
import org.ai_heuristic.eval.SimpleMathCompare;
import org.ai_heuristic.eval.metric.MetricDataset;

import org.licas.*;
import org.licas.autonomic.script.ActionSequential;
import org.licas.data.*;
import org.licas.meta.ServiceMeta;
import org.licas.module.*;
import org.licas.module.s_module.SM_Data;
import org.licas.parsers.admin.ServiceMetaParser;
import org.licas.server.LocalServer;
import org.licas.service.DataService;
import org.licas.util.*;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.util.ArrayList;
import java.util.HashMap;


/** Behaviour to cluster and link data based on the service values */
public class BM_LinkData extends BehaviourModule {

    /** The logger */
    private static final Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(BM_LinkData.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of BM_LinkData.
     * @param service the service the behaviour is for.
     * @param passwordHandler the service's password handler.
     * @throws java.lang.Exception any error.
     */
    public BM_LinkData(Auto service, PasswordHandler passwordHandler) throws Exception
    {
        super(service, passwordHandler);
    }

    /**
     * Run the behaviour evaluation.
     * @param messageInfo the Input message to evaluate.
     * @param evaluate heuristic to evaluate the behaviour with.
     * @param sm the service module.
     * @return the evaluation result.
     * @throws java.lang.Exception any error.
     */
    public MessageInfo behaviourAction(MessageInfo messageInfo,
                                       HeuristicModule evaluate,
                                       SM_Data sm) throws Exception
    {
        Element dataElem;                                   //data element
        Element replyElem;                                  //reply element
        HashMap<String, MetricDataset> datasetsToCompare;   //dataset to compare with
        DataQueryModel dataQueryModel;                      //data to evaluate
        MetricDataset md;                                   //dataset value
        MessageInfo evalMessage;                            //message to evaluate
        MessageInfo messageReply = null;                    //message reply
        Object localDataset;                                //local dataset
        Object reply;                                       //auto event reply

        try {
            //make sure an evaluation service is available
            if (evaluate != null) {
                localDataset = service.getData();

                //need first value to compare with, then result updated in the script
                if (((Auto) service).getResultObj() == null) {
                    ((Auto) service).setResultObj(ObjectHandler.valueFromString(((DataService)service).getDataType(),
                            ObjectHandler.getValue(localDataset)));
                }

                //retrieve single dataset for randomly selected service
                //that method also removes the service name from the list
                md = sm.getDataRandomID();

                //can be null if only this service is left
                if (md != null) {
                    //test not compare with self, but then gets removed so do nothing else
                    if (!md.getName().equalsIgnoreCase(service.getUUID())) {
                        //add the query object so heuristic can retrieve
                        datasetsToCompare = new HashMap<>();
                        datasetsToCompare.put(md.getName(), md);

                        if ((messageInfo != null) &&
                                (messageInfo.getMessage() != null) &&
                                DataQueryModel.isDataQuery(messageInfo.getMessage())) {
                            dataQueryModel = (DataQueryModel) messageInfo.getMessage();
                        }
                        else {
                            dataQueryModel = new ComparisonQueryModel();
                            dataQueryModel.setFunctionClass(SimpleMathCompare.class.getName());
                        }

                        if (dataQueryModel.getDataType() == null) {
                            dataQueryModel.setDataType(((Auto) service).getDataType());
                        }

                        if (dataQueryModel.getDataset() == null) {
                            if (MetricDataset.isDataset(localDataset)) {
                                dataQueryModel.setDataset((MetricDataset)localDataset);
                            }
                            else {
                                md = MetricDataset.toDataset(((Auto) service).getDataType(), localDataset);
                                dataQueryModel.setDataset(md);
                            }
                        }

                        //also add the dataset to compare as a parameter
                        dataQueryModel.getParams().put(Const.DATASETS, datasetsToCompare);

                        replyElem = evaluate.evaluate(dataQueryModel);
                        if (!testEnded(replyElem)) {
                            reply = null;
                            messageInfo = new MessageInfo(replyElem);

                            //process the reply - should include the best cluster index and value
                            //can be null
                            if (replyElem != null) {
                                dataElem = XmlHandler.firstWithName(replyElem, Const.DATASET);
                                if (dataElem != null) {
                                    evalMessage = new MessageInfo(messageInfo.getCommID(), dataElem);
                                    reply = autoEvent(evalMessage);
                                }
                            }

                            messageReply = new MessageInfo(sm.getCommID(), reply);
                        }
                        else {
                            //return empty message
                            messageReply = new MessageInfo(sm.getCommID(), null);
                        }
                    }
                }
                else if (service.getShutDown()) {
                    //shutdown indicates end of the test cycles
                    replyElem = XMLFactory.getInstance().createElement(AiConst.TESTENDED);
                    messageReply = new MessageInfo(sm.getCommID(), replyElem);
                }
            }

            return messageReply;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "behaviourAction", null, ex);
        }
    }

    /**
     * Execute a configurable autonomic event, based on the evaluation result.
     * @param autoMessage the message object with the desired evaluation result.
     * @return the result of the final effector method execution.
     * @throws java.lang.Exception any error.
     */
    protected Object autoEvent(MessageInfo autoMessage) throws Exception
    {
        String serviceID;                           //service id
        String dataType;                            //param data type
        String valueStr;                            //value as a string
        Element metaXml;                            //metadata as XML
        Element serviceUri;                         //path to service to link to
        Element dataElem;                           //data element
        ArrayList<KeyValue> evalVars;               //variables for the evaluation stage
        ArrayList<KeyValue> effVars;                //variables for the effector stage
        KeyValue keyValue;                          //key-value pair
        ServiceMeta serviceMeta;                    //service metadata
        ServiceMetaParser metaParser;               //service metadata parser
        ActionSequential actSeq;                    //sequential action
        Object resultObj;                           //result object
        Object difference;                          //difference between the data
        Object reply;                               //event reply

        try {
            reply = null;
            difference = null;

            //set the variables list and then execute a sequence of actions
            dataElem = (Element)autoMessage.getMessage();
            if (dataElem != null) {
                serviceID = dataElem.getAttributeValue(Const.SERVICE);
                if (serviceID != null) {
                    if (dataElem.getAttributeValue(Const.DATATYPE) != null) {
                        dataType = dataElem.getAttributeValue(Const.DATATYPE);
                        valueStr = dataElem.getText();
                        difference = EvaluateBase.valueFromString(dataType, valueStr);
                    }

                    resultObj = ((Auto)service).getResultObj();
                    if (resultObj != null) {
                        try {
                            resultObj = EvaluateBase.valueFromString(((Auto)service).getDataType(),
                                    ((Element)resultObj).getText());
                        }
                        catch (Exception ex) {}
                    }

                    if (difference != null) {
                        //list of variables for evaluating
                        evalVars = new ArrayList<>();
                        keyValue = new KeyValue();
                        keyValue.key = Const.DATATYPE;
                        keyValue.value = ((Auto)service).getDataType();
                        evalVars.add(keyValue);
                        keyValue = new KeyValue();
                        keyValue.key = "difference";
                        keyValue.value = difference;
                        evalVars.add(keyValue);
                        keyValue = new KeyValue();
                        keyValue.key = AiConst.MI_OBJECT;
                        keyValue.value = resultObj;
                        evalVars.add(keyValue);

                        //list of variables for successful effector
                        metaParser = new ServiceMetaParser();
                        metaXml = LocalServer.getApi(ModuleComm.getServerPassword(service)).getServiceMeta(serviceID);
                        serviceMeta = (ServiceMeta) metaParser.parse(metaXml);
                        serviceUri = serviceMeta.serviceUri;

                        effVars = new ArrayList<>();
                        keyValue = new KeyValue();
                        keyValue.key = "serviceID";
                        keyValue.value = serviceID;
                        effVars.add(keyValue);
                        keyValue = new KeyValue();
                        keyValue.key = "serviceUri";
                        keyValue.value = serviceUri;
                        effVars.add(keyValue);
                        keyValue = new KeyValue();
                        keyValue.key = "difference";
                        keyValue.value = difference;
                        effVars.add(keyValue);

                        //execute a standard sequential instruction set on the engine
                        actSeq = new ActionSequential();
                        actSeq.setEvalVars(evalVars);
                        actSeq.setEffVars(effVars);
                        reply = actSeq.sequential(autoMessage.getCommID(), (new AutoComm()).getAutoEngine((Auto)service));
                    }
                }
            }

            return reply;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "autoEvent", null, ex);
        }
    }
}
