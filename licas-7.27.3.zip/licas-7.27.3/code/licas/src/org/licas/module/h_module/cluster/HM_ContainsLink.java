/*
 * HM_ContainsLink.java
 *
 * Created on 3 October 2011
 *
 * Version 1.7.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module.h_module.cluster;


import org.licas.data.*;
import org.licas.module.h_module.HM_Cluster;
import org.licas.service.DataService;
import org.licas.util.*;
import org.ai_heuristic.eval.metric.*;
import org.ai_heuristic.util.AiHeuristicConst;
import org.licas_xml.abs.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.*;

import java.util.*;


/**
 * Provides one implementation of a clustering process. This class can be used to evaluate two values
 * of a simple type (int, float, string) for containment. If the second value is contained in the first
 * value, a boolean-type reply is returned. This is a floating point value of 1.0. So the reply only
 * verifies or not the containment. The parent service can then use this to create a permanent link
 * between itself and the service that the matching dataset belongs to.
 * <p>
 * For an evaluation to be true, it is required that subtract(value1 - value2) returns a result that is
 * neither value1 or value2 and also that value1 is greater than or equal to value2. A positive result
 * is a reply object with a data value of 1.0. A negative result is an empty reply object. See the problem
 * solver package for other examples.
 * @author Kieran Greer
 */
public class HM_ContainsLink extends HM_Cluster
{
    /** The logger */
    private static final Logger logger;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(HM_ContainsLink.class.getName());
        logger.setDebug(false);
    }

    /**
     * Create a new instance of HM_ContainsLink.
     * @throws java.lang.Exception any error.
     */
    public HM_ContainsLink() throws Exception
    {
        super();
    }

    /**
     * Create a new instance of HM_ContainsLink.
     * @param adminXml configuration parameters, including metric type and setup.
     * @throws java.lang.Exception any error.
     */
    public HM_ContainsLink(Element adminXml) throws Exception
    {
        super(adminXml);
    }

    /**
     * Evaluate the behaviour, process, or action.
     * @param dataInfo initialisation dataInfo for the evaluator.
     * @return the evaluation reply.
     * @throws java.lang.Exception and error.
     */
    public Element evaluate(DataQueryModel dataInfo) throws Exception
    {
        int index;                                  //index
        int isLinked;                               //return linked value
        String serviceID;                           //id to link with
        String selectedID;                          //selected service id
        ArrayList<String> serviceIDs;               //list of all service ids
        Element dataElem;                           //data element
        Element reply;                              //the reply
        MetricDataset nextDataset;                  //next dataset
        EvaluateData evaluator;                     //evaluate data
        Object serviceData;                         //selected data
        Object difference;                          //difference between the data
        DataService ds;                             //parent data service

        try
        {
            reply = null;
            ds = (DataService)service;
            evaluator = ds.createEvaluateData(dataInfo, passwordHandler.getAdminKey());
            allData = (HashMap)dataInfo.getParams().get(Const.DATASETS);
            serviceIDs = new ArrayList<>(allData.keySet());
            selectedID = null;

            if (!serviceIDs.isEmpty())
            {
                while ((reply == null) && !serviceIDs.isEmpty())
                {
                    index = rnd.nextInt(serviceIDs.size());
                    serviceID = serviceIDs.remove(index);

                    //check that a link as part of the cluster does not already exist
                    isLinked = alreadyLinkedTo(selectedID);
                    if (isLinked != -1) {
                        nextDataset = allData.get(serviceID);
                        if (nextDataset != null) {
                            serviceData = nextDataset.getFirstValue();

                            //local dataset must be larger than or equal to serviceData for any comparison to be done
                            if (evaluator.mathCompare(dataInfo.getDataType(), dataInfo.getDataset(), serviceData, AiHeuristicConst.GE)) {
                                difference = evaluator.subtract(dataInfo.getDataType(), dataInfo.getDataset(), serviceData);

                                //if difference neither value1 or value2 then value1 contains value2 somewhere
                                if (!(evaluator.mathCompare(dataInfo.getDataType(), dataInfo.getDataset(), difference, AiHeuristicConst.EQ) ||
                                        evaluator.mathCompare(dataInfo.getDataType(), serviceData, difference, AiHeuristicConst.EQ))) {
                                    dataElem = XMLFactory.getInstance().createElement(Const.DATASET);
                                    dataElem.setAttribute(Const.SERVICE, serviceID);
                                    dataElem.setAttribute(Const.DATATYPE, dataInfo.getDataType());
                                    dataElem.setText(String.valueOf(difference));

                                    reply = XMLFactory.getInstance().createElement(Const.RESULT);
                                    reply.addContent(dataElem);
                                    selectedID = serviceID;
                                }
                            }
                        }
                    }
                }
            }

            return reply;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "evaluate", null, ex);
        }
    }
}
