/*
 * FrameworkModule.java
 *
 * Created on 9 October 2019
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module.s_module;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.PasswordHandler;
import org.licas.Service;
import org.licas.module.ControlModule;
import org.licas.module.FrameworkModule;
import org.licas.module.ModuleHandler;
import org.licas.module.DataModule;


/**
 * This class stores the minimal set of service operations for behaviours and module plug-ins.
 * The methods are in a separate {@link FrameworkModule} class in the same package as the {@link Service}
 * class, so that it can access the required Service fields. This is an interface class for a modular setup.
 * @author Kieran Greer
 */
public class SM_Service extends FrameworkModule
{
    /** The logger */
    private static final Logger logger;


    /**
     * This stores the value of the last read communication id, so that
     * it can be identified by any method that is subsequently invoked.
     */
    protected String commID;

    /** This is the control module */
    protected ControlModule cm;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SM_Service.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of SM_Service.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public SM_Service(Service service, PasswordHandler pHandler) throws Exception
    {
        super();
        setServiceDetails(service, pHandler);
        initialise();
        setControlModule();
    }

    /**
     * Initialise some values.
     */
    private void initialise()
    {
        commID = null;
    }

    /**
     * Set the control module.
     * @throws Exception any error.
     */
    protected void setControlModule() throws Exception
    {
        cm = ModuleHandler.controlModule(service, passwordHandler);
    }

    /**
     * Get the local server password if it is stored.
     * @return the local server password.
     * @throws Exception any error.
     */
    public String getServerPassword() throws Exception
    {
        return cm.getServerPassword();
    }

    /**
     * Set the last read communication ID.
     * @param thisCommID the communication ID.
     */
    public void setCommID(String thisCommID)
    {
        commID = thisCommID;
    }

    /**
     * Get the last read communication ID.
     * @return the value of commID.
     */
    public String getCommID()
    {
        return commID;
    }

    /**
     * Set the data module in the behaviour to access the data {@code Resource}.
     * @param theDm the data module.
     */
    public void setDataModule(DataModule theDm)
    {
        cm.setDataModule(theDm);
    }
}
