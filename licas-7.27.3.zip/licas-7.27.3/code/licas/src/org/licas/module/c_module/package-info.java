/**
 * Control-related modules for the service control loop, probably the autonomic control loop,
 * with a behaviour module.
 */
package org.licas.module.c_module;