/*
 * BehaviourModule.java
 *
 * Created on 16 October 2019
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module;


import org.licas.*;
import org.licas.module.s_module.SM_Data;
import org.licas.util.AiConst;
import org.licas_xml.abs.Element;


/**
 * Base class for the specific behaviour and evaluation for autonomous behaviours.
 * @author Kieran Greer
 */
public abstract class BehaviourModule extends FrameworkModule {

    /**
     * Create a new instance of BehaviourModule.
     * @param service the probably {@link Auto}-derived service the behaviour is for.
     * @param passwordHandler the service's password handler.
     * @throws java.lang.Exception any error.
     */
    public BehaviourModule(Auto service, PasswordHandler passwordHandler) throws Exception
    {
        super();
        setServiceDetails(service, passwordHandler);
    }

    /**
     * Run the behaviour evaluation.
     * @param messageInfo the Input message to evaluate.
     * @param evaluate heuristic to evaluate the behaviour with.
     * @param sm the service module.
     * @return the evaluation result.
     * @throws java.lang.Exception any error.
     */
    public abstract MessageInfo behaviourAction(MessageInfo messageInfo,
                                                HeuristicModule evaluate,
                                                SM_Data sm) throws Exception;

    /**
     * Return true if the test has ended.
     * @param reply the evaluation reply.
     * @return true if not {@code null} and indicates the end of the test.
     */
    protected boolean testEnded(Element reply)
    {
        return ((reply != null) && reply.getName().equals(AiConst.TESTENDED));
    }
}
