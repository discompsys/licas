/*
 * SM_Server.java
 *
 * Created on 9 October 2019
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module.s_module;


import org.licas.module.c_module.CM_Server;
import org.licas.server.ESB;
import org.licas.PasswordHandler;
import org.licas.Service;
import org.jlog2.*;


/**
 * This class provides functionality for a server to run an autonomic behaviour loop.
 * The methods are in a separate {@link CM_Server} class in the same package as the {@link ESB}
 * class, so that it can access the required ESB fields. This is an interface class for a modular setup.
 * @author Kieran Greer
 */
public class SM_Server extends SM_Auto {

    /** The logger */
    private static final Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SM_Server.class.getName());
        logger.setDebug(false);
    }

    /**
     * Creates a new instance of ServerModule.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public SM_Server(Service service, PasswordHandler pHandler) throws Exception
    {
        super(service, pHandler);
    }
}
