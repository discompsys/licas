/*
 * ModuleHandler.java
 *
 * Created on 14 July 2014
 *
 * Version 1.10.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module;


import org.licas.*;
import org.licas.autonomic.AutonomicManager;
import org.licas.def.ServiceWrapperDef;
import org.licas.module.b_module.*;
import org.licas.module.b_module.BM_InfoClientPS;
import org.licas.module.c_module.*;
import org.licas.module.h_module.cluster.*;
import org.licas.module.s_module.*;
import org.licas.server.ESB;
import org.licas.service.*;
import org.licas.service.link.*;
import org.licas.service.sci.AiConfig;
import org.licas.service.sci.LinkService;
import org.licas.util.ServiceConst;
import org.licas_xml.abs.Element;


/**
 * This class can be used to store and retrieve the service modules.
 * @author Kieran Greer
 */
public class ModuleHandler {

    /**
     * Return true if the parameter is derived from the {@link LicasModule} object.
     * @param thisObj the object to query.
     * @return true if thisObj is derived from LicasModule, false otherwise.
     */
    public static boolean isLicasModule(Object thisObj)
    {
        return (thisObj instanceof LicasModule);
    }

    /**
     * Return true if the parameter is derived from the {@link FrameworkModule} object.
     * @param thisObj the object to query.
     * @return true if thisObj is derived from FrameworkModule, false otherwise.
     */
    public static boolean isFrameworkModule(Object thisObj)
    {
        return (thisObj instanceof FrameworkModule);
    }

    /**
     * Return true if the parameter is derived from the {@link ServiceModule} object.
     * @param thisObj the object to query.
     * @return true if thisObj is derived from ServiceModule, false otherwise.
     */
    public static boolean isServiceModule(Object thisObj)
    {
        return (thisObj instanceof ServiceModule);
    }

    /**
     * Return true if the parameter is derived from the {@link Service} object.
     * @param thisObj the object to query.
     * @return true if thisObj is derived from Service, false otherwise.
     */
    public static boolean isService(Object thisObj)
    {
        return (thisObj instanceof Service);
    }

    /**
     * Return true if the parameter is derived from the {@link Auto} object.
     * @param thisObj the object to query.
     * @return true if thisObj is derived from Auto, false otherwise.
     */
    public static boolean isAuto(Object thisObj)
    {
        return (thisObj instanceof Auto);
    }

    /**
     * Return true if the parameter is derived from the {@link ESB} object.
     * @param thisObj the object to query.
     * @return true if thisObj is derived from ESB, false otherwise.
     */
    public static boolean isServer(Object thisObj)
    {
        return (thisObj instanceof ESB);
    }

    /**
     * Return true if this module is a service wrapper.
     * @param thisObj the object to query.
     * @return true if a service wrapper, false otherwise.
     */
    public static boolean isWrapper(Object thisObj)
    {
        return (thisObj instanceof ServiceWrapperDef);
    }

    /**
     * Return true if this module is an autonomic manager.
     * @param thisObj the object to query.
     * @return true if derived from {@link AutonomicManager}, false otherwise.
     */
    public static boolean isAutoManager(Object thisObj)
    {
        return (thisObj instanceof AutonomicManager);
    }

    /**
     * Return true if the service module can create and execute a script.
     * @param sModule the service module. Should be script or link data type.
     * @return true if the module can create a script, false otherwise.
     */
    public static boolean isScriptModule(SM_Service sModule)
    {
        return (sModule instanceof SM_Script);
    }

    /**
     * Return a module instance for the service class type. With {@code Service-related}
     * classes, the base class is fully implemented and so the most basic module can always
     * be returned. A closest superclass match is used if a direct match is not available.
     * @param service the service instance.
     * @param pHandler the password handler.
     * @return the appropriate module instance, or basic for unknown type.
     * @throws java.lang.Exception any error.
     */
    public static SM_Service serviceModule(Service service, PasswordHandler pHandler)
            throws Exception
    {
        Class serviceClass;                 //service type
        SM_Service sm;                      //module

        serviceClass = service.getClass();
        while (!serviceClass.getName().equalsIgnoreCase(Service.class.getName())) {
            sm = moduleFromClass(serviceClass, service, pHandler);
            if (sm != null) {
                return sm;
            }
            else {
                serviceClass = serviceClass.getSuperclass();
            }
        }

        //if match not found, return the Service default
        return new SM_Service(service, pHandler);
    }

    /**
     * Return a control instance for the service class type. With {@code Service-related}
     * classes, this might simply be to retrieve some data, but with the {@code Auto-related}
     * classes, the behaviour methods might need to be implemented. Note that the abstract
     * {@code behaviourAction} is still implemented in the service itself and can make use
     * of a {@link BehaviourModule} to evaluate this.
     * @param service the service instance.
     * @param pHandler the password handler.
     * @return the appropriate behaviour instance, or basic for unknown type.
     * @throws java.lang.Exception any error.
     */
    public static ControlModule controlModule(Service service, PasswordHandler pHandler)
            throws Exception
    {
        Class serviceClass;                 //service type
        ControlModule cm;                   //control loop

        serviceClass = service.getClass();
        while (!serviceClass.getName().equalsIgnoreCase(Service.class.getName())) {
            cm = controlFromClass(serviceClass, service, pHandler);
            if (cm != null) {
                return cm;
            }
            else {
                serviceClass = serviceClass.getSuperclass();
            }
        }

        //if match not found, return the Service default
        return new ControlModule(service, pHandler);
    }

    /**
     * Return a behaviour instance for an {@code Auto-related} service. The behaviour
     * needs to be able to carry out the evaluation as part of the {@code behaviourAction}
     * method. It can do this in whole, or in part and has a slightly different interface.
     * @param service the service instance. Must be {@link Auto} or derived.
     * @param pHandler the password handler.
     * @return the appropriate behaviour instance, or basic for unknown type.
     * @throws java.lang.Exception any error.
     */
    public static BehaviourModule behaviourModule(Auto service, PasswordHandler pHandler)
            throws Exception
    {
        Class serviceClass;                 //service type
        BehaviourModule bm;                 //behaviour

        serviceClass = service.getClass();
        while (!serviceClass.getName().equalsIgnoreCase(Service.class.getName())) {
            bm = behaviourFromClass(serviceClass, service, pHandler);
            if (bm != null) {
                return bm;
            }
            else {
                serviceClass = serviceClass.getSuperclass();
            }
        }

        //if match not found, return null
        return null;
    }

    /**
     * Return a data module instance.
     * @param service the service instance.
     * @param pHandler the password handler.
     * @return the appropriate data module.
     * @throws java.lang.Exception any error.
     */
    public static DataModule dataModule(Service service, PasswordHandler pHandler)
            throws Exception
    {
        return new DataModule(service, pHandler);
    }

    /**
     * Return a data module instance.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @param adminDataXml xml description to create the data resource from.
     * @return the appropriate data module.
     * @throws Exception any error.
     */
    public static DataModule dataModule(Service service, PasswordHandler pHandler, Element adminDataXml) throws Exception
    {
        return new DataModule(service, pHandler, adminDataXml);
    }

    /**
     * Return a linking module instance for the linker service type.
     * @param linkType the linker type. For example {@link ServiceConst}.{@code LINKER}.
     * @param service the service instance.
     * @param pHandler the password handler.
     * @return the appropriate linker type.
     * @throws java.lang.Exception any error.
     */
    public static Link linkModuleType(String linkType, Service service, PasswordHandler pHandler)
            throws Exception
    {
        if (linkType.equalsIgnoreCase(ServiceConst.LINKER)) {
            return new Link_M(service, pHandler);
        }

        return null;
    }

    /**
     * Return a module instance for the service type or class.
     * @param serviceClass the service class type the module is for.
     * @param service the service instance.
     * @param pHandler the password handler.
     * @return the appropriate module instance, or {@code null} if not recognised.
     * @throws java.lang.Exception any error.
     */
    protected static SM_Service moduleFromClass(Class serviceClass, Service service, PasswordHandler pHandler)
            throws Exception
    {
        if (serviceClass.getName().equalsIgnoreCase(Service.class.getName())) {
            return new SM_Service(service, pHandler);
        } else if (serviceClass.getName().equalsIgnoreCase(DataService.class.getName())) {
            return new SM_Data(service, pHandler);
        } else if (serviceClass.getName().equalsIgnoreCase(Auto.class.getName())) {
            return new SM_Auto(service, pHandler);
        } else if (serviceClass.getName().equalsIgnoreCase(AutoSecure.class.getName())) {
            return new SM_Auto(service, pHandler);
        } else if (serviceClass.getName().equalsIgnoreCase(ESB.class.getName())) {
            return new SM_Server(service, pHandler);
        } else if (serviceClass.getName().equalsIgnoreCase(ScriptService.class.getName())) {
            return new SM_Auto(service, pHandler);
        } else if (serviceClass.getName().equalsIgnoreCase(LinkService.class.getName())) {
            return new SM_LinkData(service, pHandler);
        } else if (serviceClass.getName().equalsIgnoreCase(InformationService.class.getName())) {
            return new SM_Auto(service, pHandler);
        }

        return null;
    }

    /**
     * Return a behaviour instance for the service class.
     * @param serviceClass the service class type the module is for.
     * @param service the service instance.
     * @param pHandler the password handler.
     * @return the appropriate behaviour instance, or {@code null} if not recognised.
     * @throws java.lang.Exception any error.
     */
    protected static ControlModule controlFromClass(Class serviceClass, Service service, PasswordHandler pHandler)
            throws Exception
    {
        if (serviceClass.getName().equalsIgnoreCase(Service.class.getName())) {
            return new ControlModule(service, pHandler);
        } else if (serviceClass.getName().equalsIgnoreCase(DataService.class.getName())) {
            return new CM_Data(service, pHandler);
        } else if (serviceClass.getName().equalsIgnoreCase(Auto.class.getName())) {
            return new CM_Auto(service, pHandler);
        } else if (serviceClass.getName().equalsIgnoreCase(AutoSecure.class.getName())) {
            return new CM_Auto(service, pHandler);
        } else if (serviceClass.getName().equalsIgnoreCase(ESB.class.getName())) {
            return new CM_Server(service, pHandler);
        } else if (serviceClass.getName().equalsIgnoreCase(ScriptService.class.getName())) {
            return new CM_Auto(service, pHandler);
        } else if (serviceClass.getName().equalsIgnoreCase(LinkService.class.getName())) {
            return new CM_LinkData(service, pHandler);
        } else if (serviceClass.getName().equalsIgnoreCase(InformationService.class.getName())) {
            return new CM_Auto(service, pHandler);
        }

        return null;
    }

    /**
     * Return a behaviour instance for the service class.
     * @param serviceClass the service class type.
     * @param service the service instance.
     * @param pHandler the password handler.
     * @return the appropriate behaviour instance, or {@code null} if not recognised.
     * @throws java.lang.Exception any error.
     */
    protected static BehaviourModule behaviourFromClass(Class serviceClass, Auto service, PasswordHandler pHandler)
            throws Exception
    {
        if (serviceClass.getName().equalsIgnoreCase(ScriptService.class.getName())) {
            return new BM_Script(service, pHandler);
        } else if (serviceClass.getName().equalsIgnoreCase(LinkService.class.getName())) {
            return new BM_LinkData(service, pHandler);
        } else if (serviceClass.getName().equalsIgnoreCase(InformationService.class.getName())) {
            return new BM_InfoClientPS(service, pHandler);
        }

        return null;
    }

    /**
     * Return a likely heuristic module class type for a description.
     * @param heuristicType description of the heuristic features.
     * @return a possible heuristic module class, or {@code null} if not recognised.
     */
    public static String heuristicClass(String heuristicType)
    {
        if (AiConfig.isClusterMethod(heuristicType)) {
            if (AiConfig.isContainsCluster(heuristicType)) {
                return HM_ContainsLink.class.getName();
            } else if (AiConfig.isCompleteCluster(heuristicType)) {
                return HM_CompleteLink.class.getName();
            } else if (AiConfig.isSingleCluster(heuristicType)) {
                return HM_SingleLink.class.getName();
            }
        }

        return null;
    }

    /**
     * Return a likely linking module class type for a description.
     * @param linkMethod description of the function of the linking class, probably
     * created by {@link LinkConfig}.{@code addLinkMethod}.
     * @return the appropriate linker type.
     */
    public static String linkClass(String linkMethod)
    {
        if (LinkConfig.limitMemory(linkMethod) || LinkConfig.canBorrow(linkMethod)) {
            return Link_M.class.getName();
        }
        else if (LinkConfig.includeReserve(linkMethod)) {
            return Link_NM.class.getName();
        }
        else {
            return Link_B.class.getName();
        }
    }
}
