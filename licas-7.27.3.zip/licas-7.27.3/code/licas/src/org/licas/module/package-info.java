/**
 * This package stores a number of modules for the service framework and composition.
 */
package org.licas.module;