/*
 * CM_Data.java
 *
 * Created on 10 October 2019
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module.c_module;


import org.licas.Service;
import org.licas.PasswordHandler;
import org.licas.ServiceSerialize;
import org.licas.call.*;
import org.licas.def.DataServiceDef;
import org.licas.module.ControlModule;
import org.licas.server.LocalServer;
import org.licas.util.*;
import org.licas.util.exception.MethodNotFoundException;
import org.licas.util.exception.PasswordException;
import org.licas.util.exception.ServiceException;
import org.licas_xml.abs.Element;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import org.ai_heuristic.eval.metric.MetricDataset;
import org.ai_heuristic.eval.metric.MetricValue;
import org.licas_xml.abs.XMLFactory;

import java.util.*;


/**
 * This class provides functionality for a service to store and/or evaluate data,
 * or send data to a distributed service.
 */
public class CM_Data extends ControlModule {

    /** The logger */
    private static final Logger logger;


    /** The current list of service ids to try to link to */
    protected ArrayList<String> serviceIDs;

    /** All retrieved datasets */
    protected HashMap<String, MetricDataset> allDatasets;

    /** The evaluation service */
    protected DataServiceDef evaluator;

    /** Random number generator */
    protected Random rnd;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(CM_Data.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of CM_Data.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public CM_Data(Service service, PasswordHandler pHandler)
            throws Exception
    {
        super(service, pHandler);
        initialise();
    }

    /**
     * Initialise some values.
     */
    private void initialise()
    {
        evaluator = null;
        rnd = new Random(new Date().getTime());
        resetValues();
    }

    /**
     * Reset variables for another test run.
     */
    public void resetValues()
    {
        serviceIDs = null;
        allDatasets = null;
    }

    /**
     * This can be used to send data to some service using an XML-based description.
     * <p>
     * @param serviceType the service type to receive the data, typically only one service of the type.
     * @param dataXml full xml-based description of the data.
     * @param otherXml xml-based description of other information that may be added as a second element.
     * @param links true if include linking information.
     * @throws PasswordException incorrect password for the server or mediator service.
     * @throws MethodNotFoundException the mediator does not have the calling method.
     * @throws Exception any other error.
     */
    public void sendDataXML(String serviceType, Element dataXml, Element otherXml, boolean links) throws PasswordException, MethodNotFoundException, Exception
    {

    }

    /**
     * This method can receive a data result as an XML-based description.
     * @param serviceType type of service making the call, for indexing purposes.
     * @param dataInfo full xml-based description of the data.
     * @throws Exception any error.
     */
    public void receiveDataXML(String serviceType, Element dataInfo) throws Exception
    {

    }

    /**
     * Get the current list of active service IDs. If thi is empty, then query the server
     * for a list of running services.
     * @return the value of serviceIDs.
     * @throws java.lang.Exception any error.
     */
    public ArrayList<String> getServiceIDs() throws Exception
    {
        String serverPassword;                      //server password
        ArrayList<String> serviceTypes;             //service types

        if ((serviceIDs == null) || serviceIDs.isEmpty()) {
            serviceTypes = new ArrayList<>();
            serviceTypes.add(getServiceType());
            serverPassword = passwordHandler.getServicePassword(Const.HTTPSERVER);
            serviceIDs = LocalServer.getApi(serverPassword).getServiceNames(serviceTypes);
        }

        return serviceIDs;
    }

    /**
     * Set the dataset for processing.
     * @param thisAllData the whole dataset.
     */
    public void setAllData(HashMap<String, MetricDataset> thisAllData)
    {
        allDatasets = thisAllData;
    }

    /**
     * Retrieve and store all data from a list of running services. Also
     * adds missing passwords if they can be obtained.
     * @return the retrieved data as MetricDataset objects.
     * @throws ServiceException probably for password or service not found.
     * @throws Exception and error.
     */
    public HashMap<String, MetricDataset> getAllData() throws ServiceException, Exception
    {
        int i;
        String serviceID;                               //service id
        String servicePassword;                         //service password
        ArrayList<Object> params;                       //parameters list
        HashMap<String, MetricDataset> linkDatasets;    //service data list
        Element serviceUri;                             //service uri
        MetricDataset metricDataset;                    //next dataset
        MetricValue metricValue;                        //next value
        MethodInfo methodInfo;                          //method info
        CallObject callObject;                          //call object
        Object nextData;                                //next data object

        try {
            linkDatasets = new HashMap<>();
            callObject = new CallObject();

            if (!service.getShutDown()) {
                if (!serviceIDs.isEmpty()) {
                    for (i = 0; i < serviceIDs.size(); i++)
                    {
                        serviceID = serviceIDs.get(i);
                        if (!serviceID.equals(uuid)) {
                            //can be null through the threading and timing
                            if (passwordHandler.hasServicePassword(serviceID)) {
                                servicePassword = passwordHandler.getServicePassword(serviceID);
                            }
                            else {
                                servicePassword = this.getServicePassword(serviceID, null);
                                passwordHandler.addServicePassword(serviceID, servicePassword);
                            }

                            if (servicePassword != null) {
                                serviceUri = Handle.createNewUrlHandle(LocalServer.getServerURL());
                                serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceID));

                                params = new ArrayList<>();
                                methodInfo = MethodFactory.createMethodCall(MethodConst.GETDATA, TypeConst.OBJECT,
                                        serviceUri, params, passwordHandler);

                                nextData = callObject.call(methodInfo);
                                metricValue = MetricValue.toValue(serviceID, dm.getDataType(), nextData);
                                metricDataset = MetricDataset.toDataset(serviceID, dm.getDataType(), metricValue);
                                linkDatasets.put(serviceID, metricDataset);
                            }
                            else {}
                        }
                    }
                }
            }

            return linkDatasets;
        }
        catch (ServiceException se) {
            throw se;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "getAllData", null, ex);
        }
    }

    /**
     * Randomly retrieve the next dataset for evaluation. This is from any
     * service on the current list. This then also removes the service from the
     * list. Use {@code resetServiceIDs} to reset to the full list of other services again.
     * This version calls {@code getValue} that uses the {@code EvaluateBase.valueFromString}
     * method to try to parse a string-based representation of a value into a Java object,
     * which will only automatically work for simple types, or XML.
     * @return the retrieved data as a MetricDataset object.
     * @throws java.lang.Exception any error.
     */
    public MetricDataset getDataRandomID() throws Exception
    {
        int index;                                      //data index
        String serviceID;                               //service id
        String servicePassword;                         //service password
        Element serviceUri;                             //service uri
        MetricDataset metricDataset;                    //next dataset
        MetricValue metricValue;                        //next value
        ArrayList<Object> params;                       //list of params
        MethodInfo methodInfo;                          //method info
        CallObject callObject;                          //call object
        Object nextData;                                //next data object

        try {
            callObject = new CallObject();
            metricDataset = null;

            if (!serviceIDs.isEmpty()) {
                index = rnd.nextInt(serviceIDs.size());
                serviceID = serviceIDs.get(index);
                serviceIDs.remove(serviceID);

                if (!serviceID.equals(uuid)) {
                    //can be null through the threading and timing
                    if (passwordHandler.hasServicePassword(serviceID)) {
                        servicePassword = passwordHandler.getServicePassword(serviceID);
                    }
                    else {
                        servicePassword = this.getServicePassword(serviceID, null);
                        passwordHandler.addServicePassword(serviceID, servicePassword);
                    }

                    if (servicePassword != null) {
                        serviceUri = Handle.createNewUrlHandle(LocalServer.getServerURL());
                        serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(serviceID));

                        params = new ArrayList<>();
                        methodInfo = MethodFactory.createMethodCall(MethodConst.GETDATA, TypeConst.OBJECT, serviceUri,
                                params, passwordHandler);

                        try {
                            //this can be timed-out if there is a queue
                            methodInfo.setCallTimeout((int)TimeConst.MILLIMINUTE);

                            nextData = callObject.call(methodInfo);
                            if (nextData != null) {
                                metricValue = MetricValue.toValue(serviceID, dm.getDataType(), nextData);
                                metricDataset = MetricDataset.toDataset(serviceID, dm.getDataType(), metricValue);
                            }
                        }
                        catch (ServiceException se) {}
                    }
                }
            }
            else {
                service.setShutDown(true, passwordHandler.getAdminKey());
            }

            return metricDataset;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "getDataRandomID", null, ex);
        }
    }
}
