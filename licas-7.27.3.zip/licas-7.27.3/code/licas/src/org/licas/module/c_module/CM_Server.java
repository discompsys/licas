/*
 * CM_Server.java
 *
 * Created on 9 October 2019
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module.c_module;


import org.licas.PasswordHandler;
import org.licas.Service;
import org.jlog2.*;

/**
 * This class provides functionality for a server to run an autonomic loop.
 */
public class CM_Server extends CM_Auto {

    /** The logger */
    private static final Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(CM_Server.class.getName());
        logger.setDebug(false);
    }

    /**
     * Creates a new instance of CM_Server.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public CM_Server(Service service, PasswordHandler pHandler) throws Exception
    {
        super(service, pHandler);
    }
}
