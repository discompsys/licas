/*
 * FrameworkModule.java
 *
 * Created on 9 October 2019
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module;


import org.licas.*;
import org.licas.call.Handle;
import org.licas.def.ServiceDef;
import org.licas.util.*;
import org.licas.util.exception.PasswordException;
import org.jlog2.*;


/**
 * <p>This class stores the minimal set of variables for a service reference, for behaviours and module plug-ins.
 * The full service extends this module with the {@link Service} class, so this is an integrated info object in a
 * full service. If specific variables are not set in this class and the {@code service} variable is used, then where variables
 * overlap, its values are returned instead.</p>
 * <p>This module is not typically added to another {@code Service} as a child service, unless it also extends the
 * {@link ServiceModule} class. These modules are more specifically framework components in the service itself.</p>
 * @author Kieran Greer
 */
public class FrameworkModule extends LicasModule implements ServiceDef
{
    /** The logger */
    private static Logger logger;


    /** The functional service type */
    protected String serviceType;

    /**
     * This stores and compares all passwords used by this module.
     * Probably better to set passwords at source, because password handler can be this or service.
     */
    protected PasswordHandler passwordHandler;

    /**
     * Reference to a {@code Service} object. This can be the service that the
     * module uses, or a parent service if the module is a derived {@code Service} class.
     */
    protected Service service;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(FrameworkModule.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of FrameworkModule. For an external service, you can
     * set the service details later using {@code setServiceDetails}.
     * @throws java.lang.Exception any error.
     */
    public FrameworkModule() throws Exception
    {
        passwordHandler = new PasswordHandler(Const.ANON, Const.ANON);
        initialise();
    }

    /**
     * Creates a new instance of FrameworkModule. For an external service, you can
     * set the service details later using {@code setServiceDetails}.
     * @param password password to initialise the password handler with.
     * @param adminKey admin key to initialise the password handler with.
     * @throws java.lang.Exception any error.
     */
    public FrameworkModule(String password, String adminKey) throws Exception
    {
        passwordHandler = new PasswordHandler(password, adminKey);
        initialise();
    }

    /**
     * Set the service reference for an external service, if not already set.
     * @param service the external (not derived) service.
     * @param passwordHandler the service's psssword handler.
     * @throws Exception any error.
     */
    public void setServiceDetails(Service service, PasswordHandler passwordHandler) throws Exception
    {
        if (this.service == null) {
            this.service = service;
            this.passwordHandler = passwordHandler;
        }
    }

    /**
     * Initialise some values.
     * @throws Exception any error.
     */
    private void initialise() throws Exception
    {
        //functional service type
        serviceType = null;

        //can be service module works for, or parent service if module is a service
        service = null;
    }

    /**
     * Return true if the password allows the calling component to access this component.
     * @param thePassword the password to use.
     * @return true if the entered password is the correct password or
     * there is no password.
     */
    public boolean canAccess(String thePassword)
    {
        boolean isOK;                       //true if OK

        isOK = passwordHandler.canAccess(thePassword);
        if (!isOK && (service != null))
        {
            isOK = service.canAccess(thePassword);
        }

        return isOK;
    }

    /**
     * Return true if the password allows the calling component
     * to access this component by a temporary password.
     * @param thePassword the password to use.
     * @return true if the entered password is the valid.
     */
    public boolean canAccessTemp(String thePassword)
    {
        boolean isOK = false;               //true if can access

        if (thePassword != null)
        {
            isOK = passwordHandler.canAccessTemp(thePassword);
            if (!isOK && (service != null))
            {
                isOK = service.canAccessTemp(thePassword);
            }
        }

        if (passwordHandler.getTempPasswords().contains(thePassword))
            passwordHandler.getTempPasswords().remove(thePassword);

        return isOK;
    }

    /**
     * Return true if the key passed in is this service's admin key.
     * @param theAdminKey the key to check.
     * @return true if this is the service key
     */
    public boolean isAdminKey(String theAdminKey)
    {
        return passwordHandler.isAdminKey(theAdminKey);
    }

    /**
     * Get or ask for the service password, making a remote call if necessary.
     * This method only makes a single call to the other service to ask for the
     * password, with a default yes contract. If the other service does not have to
     * return its password, or requires a different contract, this method will fail.
     * @param serviceUUID the uuid of the service.
     * This should only be the uuid and not the whole serviceUri path.
     * @param serverUrl URL address of a remote server if it needs to be called.
     * Can be null for local server.
     * @return the password for the service to call, or null if there is an error.
     */
    public String getServicePassword(String serviceUUID, String serverUrl)
    {
        try
        {
            return passwordHandler.getServicePassword(serviceUUID, serverUrl);
        }
        catch (Exception ex)
        {
            if (service != null)
            {
                return service.getServicePassword(serviceUUID, serverUrl);
            }
            else {
                return null;
            }
        }
    }

    /**
     * Get the local server password if it is stored.
     * @return the local server password.
     * @throws java.lang.Exception any error.
     */
    protected String getServerPassword() throws Exception
    {
        String descr;                   //error description

        try
        {
            return passwordHandler.getServicePassword(Handle.getLocalServerURI());
        }
        catch (PasswordException ex)
        {
            descr = "The server password can be missing when you are initialising a service." +
                    " If this is the case, fully create the service first, before trying to add" +
                    " a child service to it: ";
            PasswordException pex = new PasswordException(descr + ex.getMessage());
            throw pex;
        }
    }

    /**
     * Set the functional service type, but only if it is currently {@code null}, otherwise
     * it is not changed. This method should probably not be called manually as the service type
     * is automatically set when the service is loaded as the service name.
     * @param thisServiceType the service type.
     */
    public void setServiceType(String thisServiceType)
    {
        if (serviceType == null)
        {
            serviceType = thisServiceType;
        }
    }

    /**
     * Get the functional type for this service.
     * @return the value of serviceType.
     */
    public String getServiceType()
    {
        if ((serviceType == null) && (service != null))
        {
            serviceType = service.getServiceType();
        }

        return serviceType;
    }

    /**
     * Get the password handler.
     * @param adminKey the admin key for the service.
     * @return the value of passwordHandler if the correct admin key, {@code null} otherwise.
     */
    public PasswordHandler getPasswordHandler(String adminKey)
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            return passwordHandler;
        }

        return null;
    }

    /**
     * Get the password handler.
     * @return the value of passwordHandler.
     */
    protected PasswordHandler getPasswordHandler()
    {
        return passwordHandler;
    }
}
