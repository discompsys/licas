/*
 * CM_Auto.java
 *
 * Created on 9 October 2019
 *
 * Version 1.0.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module.c_module;


import org.dcs.query_process.util.Script_Const;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.Monitor;
import org.licas.*;
import org.licas.autonomic.AutonomicManager;
import org.licas.autonomic.script.AutoEngine;
import org.licas.server.LocalServer;
import org.licas.util.Const;
import org.licas.util.ThreadHandler;
import org.licas.util.exception.ServiceException;

import java.util.concurrent.CountDownLatch;


/**
 * This class provides functionality for a service run an autonomic loop.
 */
public class CM_Auto extends CM_Data {

    /** The logger */
    private static final Logger logger;


    /** True if currently busy */
    protected boolean isBusy;

    /** The service's autonomic manager */
    protected AutonomicManager autoManager;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(CM_Auto.class.getName());
        logger.setDebug(false);
    }

    /**
     * Creates a new instance of CM_Auto.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public CM_Auto(Service service, PasswordHandler pHandler) throws Exception
    {
        super(service, pHandler);
        autoManager = null;
        initialise();
    }

    /**
     * Initialise some values.
     */
    private void initialise()
    {
        isBusy = false;
    }

    /**
     * Set the autonomic manager, which is usually set later.
     * @param autoMan the autonomic manager.
     */
    public void setAutonomicManager(AutonomicManager autoMan)
    {
        autoManager = autoMan;
    }

    /**
     * Main method to execute the behaviour and evaluate the result, where the input
     * message used is the first message on the autonomic manager's message queue.
     * If the autonomic manager is missing for some reason, the second evaluateBehaviour
     * method is called with a {@code null} parameter. This default version will probably
     * work for general cases. It is based on retrieving the next message on the message queue,
     * performing an action on that, and then monitoring the result by sending the reply
     * through the {@link AutonomicManager} control loop. The control loop is empty
     * by default, but all of these classes have been added to integrate the process
     * with the normal running of the system. Any derived class can override this method
     * or related parts, to change the behaviour and evaluation control loop.
     * @throws ServiceException probably for password or service not found.
     * @throws Exception any error.
     */
    public void evaluateBehaviour() throws ServiceException, Exception
    {
        MessageInfo nextMessage;                    //next message
        MessageInfo messageReply;                   //message reply

        //if autonomic manager then perform action and set new service state
        //otherwise just execute the behaviour
        if (!isBusy)
        {
            try
            {
                isBusy = true;
                if (autoManager != null)
                {
                    nextMessage = autoManager.getNextMessage(passwordHandler.getAdminKey(), true);
                    messageReply = evaluateBehaviour(nextMessage);

                    //monitor reply
                    if (messageReply != null)
                    {
                        service.setServiceState(messageReply.getServiceState(),
                                passwordHandler.getAdminKey());

                        messageReply.setInOut(Script_Const.FILTER);
                        if (nextMessage != null)
                        {
                            messageReply.setCommID(nextMessage.getCommID());
                        }
                        else
                        {
                            messageReply.setCommID(ServiceComm.getCommID(service));
                        }

                        autoManager.monitor(messageReply, passwordHandler.getAdminKey());
                    }
                }
                else
                {
                    evaluateBehaviour(null);
                }
            }
            finally
            {
                isBusy = false;
            }
        }
    }

    /**
     * This can be used to execute a single invocation of the service's {@code evaluateBehaviour} method.
     * This is correct if the service is waiting to be invoked and is not running on a thread.
     * This version runs each invocation in a separate thread and also passes the message
     * reply through the autonomic manager.
     * @param messageInfo the message with data to evaluate. This is only the values
     * related to the evaluation result, not the whole set of service values.
     * @return the evaluation reply. This is the {@code evaluateBehaviour} {@link MessageInfo}
     * reply object. If this is not one of the basic types, a parser needs to be added to parse
     * the complex object to/from XML.
     * @throws ServiceException if this service's main thread is currently running.
     * @throws Exception any other error.
     */
    public Object invokeBehaviour(MessageInfo messageInfo) throws ServiceException, Exception
    {
        final String theLastID;                             //the last comm ID
        final MessageInfo bInfo;                            //input message
        final Object[] reply = new Object[1];               //reply reference
        final Exception[] tex = new Exception[1];           //thread exception
        final CountDownLatch latch = new CountDownLatch(1);

        try {
            service.setShutDown(false, passwordHandler.getAdminKey());
            isBusy = true;
            theLastID = ServiceComm.getCommID(service);
            reply[0] = null;
            tex[0] = null;

            //monitor and return the reply
            if (!mainThreadRunning()) {
                bInfo = messageInfo;

                Thread thread = new Thread(() -> {
                    MessageInfo messageReply;           //message reply

                    try {
                        messageReply = evaluateBehaviour(bInfo);
                        if (messageReply != null) {
                            //copy reply as auto manager adds list to it
                            reply[0] = messageReply.getMessage();
                            service.setServiceState(messageReply.getServiceState(),
                                    passwordHandler.getAdminKey());

                            messageReply.setInOut(Script_Const.FILTER);
                            if (messageReply.getCommID() == null) {
                                messageReply.setCommID(theLastID);
                            }

                            autoManager.monitor(messageReply, passwordHandler.getAdminKey());
                        }
                    }
                    catch (Exception ex) {
                        tex[0] = ex;
                    }
                    finally {
                        latch.countDown();
                    }
                });
                thread.start();

                latch.await();
                if (tex[0] != null) throw tex[0];
                else return reply[0];
            }
            else {
                throw new ServiceException("Service " + uuid + " is running its main thread." +
                        "\nSo a single invokeBehaviour should be illegal.");
            }
        }
        finally {
            isBusy = false;
        }
    }

    /**
     * Evaluate a behaviour, initialised by an input {@code messageInfo}, with the evaluation logic
     * written in a {@code behaviourAction} method.
     * @param messageInfo the message with initial behaviour details.
     * @return the evaluation reply.
     * @throws ServiceException probably for password or service not found.
     * @throws Exception and error.
     */
    public MessageInfo evaluateBehaviour(MessageInfo messageInfo) throws ServiceException, Exception
    {
        String serverPassword;                          //server password
        MessageInfo messageReply;                       //message reply

        try {
                messageReply = null;
                if (!service.getShutDown()) {
                    //check if server running, because can create and call locally without a server
                    //possibly need to initialise with all passwords first
                    if (LocalServer.hasServer() && !passwordHandler.hasServicePassword(Const.HTTPSERVER)) {
                        serverPassword = getServerPassword();
                        if (serverPassword != null) {
                            passwordHandler.addServicePassword(Const.HTTPSERVER, serverPassword);
                        }
                    }

                    //call the implementation of 'behaviourAction' to get reply
                    try {
                        messageReply = (new AutoComm()).behaviourAction(messageInfo, (Auto)service);
                    }
                    catch (Exception ex2) {
                        service.setShutDown(true, passwordHandler.getAdminKey());
                    }
                    finally {
                        Monitor.getMonitor().release();
                        ThreadHandler.notifyEvents();
                    }
                }

                return messageReply;
        }
        catch (ServiceException se) {
            throw se;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "evaluateBehaviour", null, ex);
        }
    }

    /**
     * Get the auto engine.
     * @return the value of autoEngine.
     */
    public AutoEngine getAutoEngine()
    {
        return (new AutoComm()).getAutoEngine((Auto)service);
    }


    /**
     * Return true if the main thread of this service is currently running.
     * @return true if not new or terminated.
     */
    private boolean mainThreadRunning()
    {
        return !(service.getState().equals(State.NEW) ||
                service.getState().equals(State.TERMINATED) ||
                service.threadAliveState().equalsIgnoreCase("false"));
    }
}
