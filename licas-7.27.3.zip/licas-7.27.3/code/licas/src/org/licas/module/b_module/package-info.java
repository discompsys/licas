/**
 * Behaviour-related modules process and evaluate the service data.
 */
package org.licas.module.b_module;