/*
 * ControlModule.java
 *
 * Created on 16 October 2019
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module;


import org.licas.PasswordHandler;
import org.licas.Service;
import org.licas.server.LocalServer;

import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.util.exception.PasswordException;


/**
 * Base class for the outer control loop and general operations for autonomous behaviours.
 * @author Kieran Greer
 */
public class ControlModule extends FrameworkModule
{
    /** The logger */
    private static final Logger logger;


    /** This is the service data module */
    protected DataModule dm;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ControlModule.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of ControlModule.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public ControlModule(Service service, PasswordHandler pHandler) throws Exception
    {
        super();
        setServiceDetails(service, pHandler);
        initialise();
    }

    /**
     * Initialise some values.
     */
    private void initialise()
    {
        dm = null;
    }

    /**
     * Set the data module to access any data directly.
     * @param theDm the data module.
     */
    public void setDataModule(DataModule theDm)
    {
        dm = theDm;
    }

    /**
     * Get the local server password if it is stored.
     * @return the local server password.
     * @throws PasswordException if the server password is missing.
     * @throws java.lang.Exception any other error.
     */
    public String getServerPassword() throws PasswordException, Exception
    {
        return passwordHandler.getServicePassword(LocalServer.getServerHandle());
    }
}
