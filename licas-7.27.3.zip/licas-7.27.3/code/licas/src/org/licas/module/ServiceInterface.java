/*
 * ServiceInterface.java
 *
 * Created on 16 November 2015
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.Service;
import org.licas.call.Handle;
import org.licas.util.Const;
import org.licas_xml.abs.Element;


/**
 * This can be used as a basis for service interface classes that would extend the {@link Service}
 * class and be used with the implemented services, interfaces and related GUIs. If using
 * autonomic methods, you can extend the {@link AutoInterface} instead.
 * @author Kieran Greer
 */
public abstract class ServiceInterface extends Service
{
    /** The logger */
    private static final Logger logger;
    
    
    /** Full URI for this service, invoked locally */
    protected Element serviceUri;
    
    /** Server URI that this service runs on */
    protected Element serverUri;
    
    /** Local server password */
    protected String serverPassword;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServiceInterface.class.getName());
        logger.setDebug(false);
    }
    
    /** 
     * Creates a new instance of ServiceInterface. 
     * @param serviceUuid uuid of service on server.
     * @param serviceType the service type.
     * @param password of service on server.
     * @param adminKey of service on server.
     * @throws java.lang.Exception any error.
     */
    public ServiceInterface(String serviceUuid, String serviceType, String password, String adminKey) throws Exception
    {
        super(password, adminKey);
        setUUID(serviceUuid);
        setServiceType(serviceType);
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        try
        {
            serviceUri = null;
            serverUri = null;
            serverPassword = null;
            passwordHandler.addServicePassword(getUUID(), passwordHandler.getPassword());
            passwordHandler.addAdminKey(getUUID(), passwordHandler.getAdminKey());
        }
        catch (Exception ex)
        {}
    }
    
    /**
     * Set the service details so that this interface can be called.
     * @param theServiceUrl the full url path to the service that the GUI is for.
     * The server url is constructed from this.
     * @param theServerPassword the password for the local server.
     * @throws java.lang.Exception any error. 
     */
    public void setServiceDetails(Element theServiceUrl, String theServerPassword) throws Exception
    {
        serviceUri = theServiceUrl;
        serverUri = Handle.createNewUrlHandle(Handle.getURL(theServiceUrl));
        serverUri = Handle.addToHandle(serverUri, Handle.asHandleElement(Const.HTTPSERVER));
        
        serverPassword = theServerPassword;        
        if (!passwordHandler.hasServicePassword(serverUri))
            passwordHandler.addServicePassword(serverUri, serverPassword);       
    }
}
