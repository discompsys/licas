/**
 * Module interface for heuristics.
 */
package org.licas.module.h_module;