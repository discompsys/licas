/*
 * DataModule.java
 *
 * Created on 11 October 2019
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module;


import org.licas.*;
import org.licas.service.resource.*;
import org.licas.util.Const;
import org.licas.util.ObjectHandler;
import org.licas_text.util.XmlHtmlHandler;
import org.licas_xml.abs.Element;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.licas_xml.model.XmlHandler;


/** This class can manage the data for a service */
public class DataModule extends FrameworkModule {

    /** The logger */
    private static final Logger logger;


    /** The data type */
    protected String dataType;

    /** The resource to reference the data source */
    protected Resource resource;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(DataModule.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of DataModule.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public DataModule(Service service, PasswordHandler pHandler) throws Exception
    {
        super();
        setServiceDetails(service, pHandler);
        dataType = null;
        resource = null;
    }

    /**
     * Creates a new instance of DataModule.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @param adminDataXml xml description to create the data resource from.
     * @throws Exception any error.
     */
    public DataModule(Service service, PasswordHandler pHandler, Element adminDataXml) throws Exception
    {
        super();
        setServiceDetails(service, pHandler);
        dataType = null;
        resource = null;
        initialiseData(adminDataXml);
    }

    /**
     * Create the data resource.
     * @param adminDataXml description of the resource with data value.
     * @throws java.lang.Exception any error.
     */
    public void initialiseData(Element adminDataXml) throws Exception
    {
        Element nextElem;                       //next element
        Element resourceElem;                   //to parse resources from

        try {
            //parse adminDataXml if not null, to create the resource container
            if (adminDataXml != null) {
                resourceElem = resetXml(adminDataXml);

                //need data type and value list, so maybe nested data element
                if ((resourceElem.getChild(Const.DATATYPE) == null) ||
                        (resourceElem.getChild(Const.VALUE) == null)) {
                    if (resourceElem.getChild(Const.DATA) != null) {
                        resourceElem = resourceElem.getChild(Const.DATA);
                    }
                }

                if (resourceElem.getChild(Const.DATATYPE) != null) {
                    nextElem = resourceElem.getChild(Const.DATATYPE);
                    dataType = nextElem.getText();
                }

                if (resourceElem.getChild(Const.VALUE) != null) {
                    resource = Resource.createResource(dataType, resourceElem);
                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "initialiseData",
                    "", ex);
        }
    }

    /**
     * Reset the XML to remove the coding to a string.
     * @param dataXml the data that may be represented as a string.
     * @return the data converted back into an XML element.
     */
    protected Element resetXml(Element dataXml)
    {
        String text;                        //coded text
        Element rootElem;                   //root element
        Element nextElem;                   //next element

        rootElem = dataXml;

        //if no children, then text coded directly, or value element can be coded
        if (rootElem.hasChildren()) {
            if ((rootElem.getChild(Const.VALUE) != null)) {
                rootElem = rootElem.getChild(Const.VALUE);
            }
        }

        text = rootElem.getText();
        try {
            text = XmlHtmlHandler.decodeXmlTag(text);
            nextElem = XmlHandler.stringToElement(text);
            rootElem.setText("");
            rootElem.addContent(nextElem);
        }
        catch (Exception ex) {}

        return dataXml;
    }


    /**
     * This creates a {@link Resource} to store the data directly. This can be
     * dangerous because it overwrites the existing resource.
     * @param dataType the data type.
     * @param dataObj the data object.
     * @throws java.lang.Exception any error.
     */
    public void setData(String dataType, Object dataObj) throws Exception
    {
        this.dataType = dataType;
        if (dataObj instanceof Element) {
            resource = Resource.createResource(dataType, (Element)dataObj);
        }
        else {
            resource = new ObjResource(dataType, dataObj);
        }
    }

    /**
     * This creates an appropriate {@link Resource} object by parsing the XMl description.
     * This can be dangerous because it overwrites the existing resource.
     * @param dataXml XML description of the data object to store.
     * @throws java.lang.Exception any error.
     */
    public void setData(Element dataXml) throws Exception
    {
        initialiseData(dataXml);
    }

    /**
     * Return true if the data module has no data references.
     * @return true if empty module.
     */
    public boolean isEmpty()
    {
        return dataType == null;
    }

    /**
     * Get the data resource object.
     * @return the value of resource.
     */
    public Resource getResource()
    {
        return resource;
    }

    /**
     * Get the data type.
     * @return the value of dataType.
     */
    public String getDataType()
    {
        return dataType;
    }

    /**
     * Get the whole public data object.
     * @return the resource data.
     * @throws java.lang.Exception any error.
     */
    public Object getData() throws Exception
    {
        return getData(null);
    }

    /**
     * Get the data object part defined by the description.
     * @param infoDescr optional description. Needs to be implemented in the resource.
     * @return the resource data.
     * @throws java.lang.Exception any error.
     */
    public Object getData(Element infoDescr) throws Exception
    {
        return resource.getValue(infoDescr);
    }
}
