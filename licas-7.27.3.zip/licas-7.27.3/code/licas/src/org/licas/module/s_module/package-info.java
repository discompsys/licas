/**
 * Service-related modules with common functionality - retrieve values or the control module.
 */
package org.licas.module.s_module;