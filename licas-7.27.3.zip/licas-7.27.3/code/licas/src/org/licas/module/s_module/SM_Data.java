/*
 * SM_Data.java
 *
 * Created on 9 October 2019
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module.s_module;


import org.jlog2.exception.ExceptionHandler;
import org.licas.Service;
import org.licas.PasswordHandler;
import org.licas.ServiceSerialize;
import org.licas.call.Handle;
import org.licas.call.MethodInfo;
import org.licas.call.ParamInfo;
import org.licas.module.c_module.CM_Data;
import org.licas.server.LocalServer;
import org.licas.service.sci.DataTransfer;
import org.licas.util.Const;
import org.licas.util.MethodConst;
import org.licas.util.TypeConst;
import org.licas.util.exception.MethodNotFoundException;
import org.licas.util.exception.PasswordException;
import org.licas.util.exception.ServiceException;
import org.jlog2.*;

import org.ai_heuristic.eval.metric.MetricDataset;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.util.*;


/**
 * This class provides functionality for a service to store and/or evaluate some data.
 * The methods are in a separate {@link CM_Data} class.
 * @author Kieran Greer
 */
public class SM_Data extends SM_Service {

    /** The logger */
    private static final Logger logger;

    /**
     * Data list sent from other services.
     * Key is the service type and value is the data details, for each service of that type.
     */
    protected HashMap<String, DataTransfer> dataQueue;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SM_Data.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of SM_Data.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public SM_Data(Service service, PasswordHandler pHandler) throws Exception
    {
        super( service, pHandler);
        dataQueue = new HashMap<>();
    }

    /**
     * Reset variables for another test run.
     */
    public void resetValues()
    {
        dataQueue = new HashMap<>();
        ((CM_Data) cm).resetValues();
    }

    /**
     * This can be used to send data to some service using an XML-based description.
     * <p>
     * @param serviceType the service type to receive the data, typically only one service of the type.
     * @param dataXml full xml-based description of the data.
     * @throws PasswordException incorrect password for the server or mediator service.
     * @throws MethodNotFoundException the mediator does not have the calling method.
     * @throws Exception any other error.
     */
    public void dataToService(String serviceType, Element dataXml) throws PasswordException, MethodNotFoundException, Exception
    {
        String serverPassword;                              //server password
        MethodInfo methodInfo;                              //method info

        try {
            if (!passwordHandler.hasServicePassword(Handle.getLocalServerURI())) {
                serverPassword = getServerPassword();
                passwordHandler.addServicePassword(Handle.getLocalServerURI(), serverPassword);
            }

            //if service type exists send the data to it
            serverPassword = passwordHandler.getServicePassword(Const.HTTPSERVER);

            if (LocalServer.getApi(serverPassword).getServiceTypes().contains(serviceType)) {
                methodInfo = new MethodInfo();
                methodInfo.setName(MethodConst.DATAFROMSERVICE);
                methodInfo.setRtnType(TypeConst.VOID);
                methodInfo.setServiceURI(Handle.createServiceHandle(serviceType));
                methodInfo.setServerPassword(serverPassword);
                methodInfo.addParam(new ParamInfo(service.getUUID()));
                methodInfo.addParam(new ParamInfo(service.getServiceType()));
                methodInfo.addParam(new ParamInfo(dataXml));

                LocalServer.getApi(serverPassword).execute(methodInfo);
            }
        }
        catch (PasswordException pe) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "dataToService",
                    null, pe);
        }
        catch (MethodNotFoundException mnfe) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "dataToService",
                    null, mnfe);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "dataToService", null, ex);
        }
    }

    /**
     * This method can receive a data result as an XML-based description and store it in
     * an indexed table.
     * @param serviceUuid the unique id of the service that sent the data, for indexing purposes.
     * @param serviceType service type of the service that sent the data, for indexing purposes.
     * @param dataInfo full xml-based description of the data.
     * @throws java.lang.Exception any error.
     */
    public void dataFromService(String serviceUuid, String serviceType, Element dataInfo) throws Exception
    {
        long time;                                          //current time
        String dataKey;                                     //data key
        LinkedHashMap<String, Element> dataEntries;         //list of data entries
        DataTransfer serviceQueue;                          //service queue

        synchronized(syncOn)
        {
            if ((serviceType != null) && (dataInfo != null))
            {
                if (!dataQueue.containsKey(serviceType))
                {
                    dataQueue.put(serviceType, new DataTransfer());
                }

                serviceQueue = dataQueue.get(serviceType);

                if (!serviceQueue.dataQueue.containsKey(serviceUuid))
                {
                    serviceQueue.dataQueue.put(serviceUuid, new LinkedHashMap<>());
                }

                dataEntries = serviceQueue.dataQueue.get(serviceUuid);
                time = System.currentTimeMillis();
                dataKey = (new Date(time)).toString();

                while (dataEntries.containsKey(dataKey))
                {
                    time += 1000;
                    dataKey = (new Date(time)).toString();
                }

                dataEntries.put(dataKey, dataInfo);
            }
        }
    }

    /**
     * Get the current list of active service IDs. If thi is empty, then query the server
     * for a list of running services.
     * @return the value of serviceIDs.
     * @throws java.lang.Exception any error.
     */
    public ArrayList<String> getServiceIDs() throws Exception
    {
        return ((CM_Data) cm).getServiceIDs();
    }

    /**
     * Set the dataset for processing.
     * @param thisAllData the whole dataset.
     */
    public void setAllData(HashMap<String, MetricDataset> thisAllData)
    {
        ((CM_Data) cm).setAllData(thisAllData);
    }

    /**
     * Retrieve and store all data from a list of running services. Also
     * adds missing passwords if they can be obtained.
     * @return the retrieved data as MetricDataset objects.
     * @throws ServiceException probably for password or service not found.
     * @throws Exception and error.
     */
    public HashMap<String, MetricDataset> getAllData() throws ServiceException, Exception
    {
        return ((CM_Data) cm).getAllData();
    }

    /**
     * Randomly retrieve the next dataset for evaluation. This is from any
     * service on the current list. This then also removes the service from the
     * list. Use {@code resetServiceIDs} to reset to the full list of other services again.
     * This version calls {@code getValue} that uses the {@code EvaluateBase.valueFromString}
     * method to try to parse a string-based representation of a value into a Java object,
     * which will only automatically work for simple types, or XML.
     * @return the retrieved data as a MetricDataset object.
     * @throws Exception and error.
     */
    public MetricDataset getDataRandomID() throws Exception
    {
        return ((CM_Data) cm).getDataRandomID();
    }

    /**
     * Get the current data queue.
     * @return the value of dataQueue.
     */
    public HashMap<String, DataTransfer> getDataQueue()
    {
        return dataQueue;
    }
}
