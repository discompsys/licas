/**
 * Distributed solution modules, where clustering heuristics can create links between services, for example.
 */
package org.licas.module.h_module.cluster;