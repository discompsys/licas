/*
 * ServiceModule.java
 *
 * Created on 16 October 2019
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.Service;


/**
 * Base class for utility modules, similar to utility services, that can be added as child
 * services to another {@link Service}. This class extends the {@link FrameworkModule} with some
 * additional methods to help with thread execution in a full service extending this module.
 * The threading can be ignored, or it can be useful for the behaviours.
 * @author Kieran Greer
 */
public class ServiceModule extends FrameworkModule {
    /** The logger */
    private static final Logger logger;


    /** True if shutdown the service thread */
    protected boolean shutDown;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServiceModule.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of ServiceModule.
     * @throws java.lang.Exception any error.
     */
    public ServiceModule() throws Exception
    {
        super();
        initialise();
    }

    /**
     * Creates a new instance of ServiceModule.
     * @param password password to initialise the password handler with.
     * @param adminKey admin key to initialise the password handler with.
     * @throws java.lang.Exception any error.
     */
    public ServiceModule(String password, String adminKey) throws Exception
    {
        super(password, adminKey);
        initialise();
    }

    /**
     * Initialise some values.
     */
    private void initialise()
    {
        shutDown = false;
    }

    /**
     * You must call this method to interrupt the thread.
     * This also interrupts all nested services.
     * @param adminKey the key to identify unique loading of the service.
     * @return true if the service is stopped.
     */
    public boolean interrupt(String adminKey)
    {
        boolean isOK;                           //true if OK

        isOK = false;
        try
        {
            if (!isInterrupted() && passwordHandler.isAdminKey(adminKey))
            {
                setShutDown(true);
                try
                {
                    if (!isInterrupted()) interrupt();
                }
                catch (Exception ex)
                {}

                isOK = true;
            }
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "interrupt", null, ex);
        }

        return isOK;
    }

    /**
     * Set the shut down variable to value passed in.
     * @param thisShutDown true if shut down, false if keep running.
     */
    protected void setShutDown(boolean thisShutDown)
    {
        shutDown = thisShutDown;
    }

    /**
     * Set the shut down variable to value passed in.
     * @param adminKey the service key of this service.
     * @param thisShutDown true if shut down, false if keep running.
     */
    public void setShutDown(boolean thisShutDown, String adminKey)
    {
        if (passwordHandler.isAdminKey(adminKey))
        {
            shutDown = thisShutDown;
        }
    }

    /**
     * Return the value indicating if this running thread should be shut down.
     * @return the value of shutDown.
     */
    public boolean getShutDown()
    {
        return shutDown;
    }
}
