/*
 * SM_LinkData.java
 *
 * Created on 9 October 2019
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module.s_module;


import org.licas.PasswordHandler;
import org.licas.Service;
import org.licas.MessageInfo;
import org.licas.module.c_module.CM_LinkData;
import org.licas.util.exception.ServiceException;
import org.jlog2.*;
import org.licas_xml.abs.Element;


/**
 * This class provides functionality for a scientific service to store and process data in an autonomic loop.
 * The methods are in a separate {@link CM_LinkData} class.
 * @author Kieran Greer
 */
public class SM_LinkData extends SM_Script {

    /** The logger */
    private static final Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SM_LinkData.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of LinkDataModule.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public SM_LinkData(Service service, PasswordHandler pHandler) throws Exception
    {
        super(service, pHandler);
    }

    /**
     * EvaluateBase a behaviour {@code messageInfo} using the {@code evaluate} service and invoke
     * a resulting action, by calling {@code behaviourAction}.
     * @param messageInfo the message with data to process. It is not used in
     * this implementation, where the data values are retrieved by requests to
     * each service instead.
     * @return the evaluation reply.
     * @throws ServiceException probably for password or service not found.
     * @throws Exception and error.
     */
    public MessageInfo evaluateBehaviour(MessageInfo messageInfo) throws ServiceException, Exception
    {
        return ((CM_LinkData) cm).evaluateBehaviour(messageInfo);
    }

    /**
     * Create the policy description that can be used as a default script for initialising the
     * auto engine of this service. This if for the service itself, not any related autonomic
     * manager.
     * @return a policy script to initialise the service with.
     * @throws Exception any error.
     */
    public Element createProcessScript() throws Exception
    {
        return ((CM_LinkData) cm).createProcessScript();
    }
}
