/*
 * HeuristicModule.java
 *
 * Created on 28 October 2019
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module;


import org.licas.data.DataQueryModel;
import org.licas_xml.abs.Element;


/**
 * Base class for the evaluation heuristics. If the heuristic involves more than 1 evaluation,
 * it can even run off a script.
 * @author Kieran Greer
 */
public abstract class HeuristicModule extends ServiceModule {

    /** Admin element with configuration values */
    protected Element configXml;

    /**
     * Create a new instance of HeuristicModule.
     * @throws java.lang.Exception any error.
     */
    public HeuristicModule() throws Exception
    {
        super();
        configXml = null;
    }

    /**
     * Create a new instance of HeuristicModule.
     * @param adminXml configuration parameters, including metric type and setup.
     * @throws java.lang.Exception any error.
     */
    public HeuristicModule(Element adminXml) throws Exception
    {
        super();
        configXml = adminXml;
    }

    /**
     * Reset variables for another test run.
     */
    public abstract void resetValues();

    /**
     * Evaluate the behaviour, process, or action.
     * @param dataInfo initialisation dataInfo for the evaluator.
     * @return the evaluation reply. This is XML-based and can be transferred
     * to other services, where the tagged elements define the result meaning.
     * Complex objects can be included but would require a parser.
     * @throws java.lang.Exception and error.
     */
    public abstract Element evaluate(DataQueryModel dataInfo) throws Exception;
}
