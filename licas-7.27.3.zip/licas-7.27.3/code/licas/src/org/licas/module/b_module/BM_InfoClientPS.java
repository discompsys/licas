/*
 * BM_InfoClientPS.java
 *
 * Created on 20 October 2019
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module.b_module;


import org.licas.*;
import org.licas.call.*;
import org.licas.module.*;
import org.licas.module.s_module.SM_Data;
import org.licas.server.LocalServer;
import org.licas.server.esb.PublishSubscribe;

import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.licas.service.InformationService;
import org.licas.service.model.KeywordInfo;
import org.licas.service.model.WorkInfo;
import org.licas.util.MethodConst;
import org.licas.util.TypeConst;

import java.util.ArrayList;


/**
 * Behaviour to 'publish' the data from an {@code Information} service to the server so that a client can be
 * informed and sent the result using the {@link PublishSubscribe} system.
 */
public class BM_InfoClientPS extends BehaviourModule {

    /** The logger */
    private static final Logger logger;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(BM_InfoClientPS.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of BM_InfoClientPS.
     * @param service the service the behaviour is for.
     * @param passwordHandler the service's password handler.
     * @throws Exception any error.
     */
    public BM_InfoClientPS(Auto service, PasswordHandler passwordHandler) throws Exception
    {
        super(service, passwordHandler);
    }

    /**
     * Run the behaviour to publish the information to the server.
     * @param messageInfo the Input message to evaluate.
     * @param evaluate heuristic to evaluate the behaviour with.
     *                 Can be null here as simply an info retrieval.
     * @param sm the service module.
     * @return the evaluation result.
     * @throws Exception any error.
     */
    public MessageInfo behaviourAction(MessageInfo messageInfo,
                                       HeuristicModule evaluate,
                                       SM_Data sm) throws Exception
    {
        String data;                            //data to publish
        WorkInfo workInfo;                      //publish work info
        KeywordInfo keywordInfo;                //keyword info
        MethodInfo pubInfo;                     //publish method info
        MethodInfo methodInfo;                  //method info
        CallObject callObj;                     //call object
        MessageInfo messageReply;               //message reply
        Object reply;                           //auto event reply

        try
        {
            data = ((InformationService)service).getSourceInfo(null);

            workInfo = new WorkInfo();
            keywordInfo = new KeywordInfo();
            keywordInfo.getKeywords().addAll((ArrayList)messageInfo.getMessage());
            workInfo.keywordInfo = keywordInfo;
            pubInfo = new MethodInfo();
            pubInfo.setClientURI(service.getFullPath());
            workInfo.methodInfo = pubInfo;
            workInfo.info = data;

            methodInfo = new MethodInfo();
            methodInfo.setClientURI(service.getFullPath());
            methodInfo.setName(MethodConst.PUBLISH);
            methodInfo.setRtnType(TypeConst.BOOLEAN);
            //assumes publish on server reside on
            methodInfo.setServiceURI(LocalServer.getServerHandle());
            methodInfo.setServerPassword(sm.getServerPassword());
            methodInfo.addParam(workInfo);

            callObj = new CallObject();
            reply = callObj.call(methodInfo);

            messageReply = new MessageInfo(reply);
            return messageReply;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "behaviourAction", null, ex);
        }
    }
}
