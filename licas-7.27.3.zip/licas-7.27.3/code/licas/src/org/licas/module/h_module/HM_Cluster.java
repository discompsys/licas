/*
 * HM_Cluster.java
 *
 * Created on 28 October 2019
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.module.h_module;


import org.ai_heuristic.eval.metric.MetricDataset;
import org.licas.module.HeuristicModule;
import org.licas.service.DataService;
import org.licas.util.AiConst;
import org.licas_xml.abs.Element;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.ai_heuristic.functs.Function;
import org.licas_xml.model.XmlHandler;

import java.util.*;


/**
 * Base class for the clustering heuristics. These receive values from distributed services
 * and cluster them with the module's service value.
 * @author Kieran Greer
 */
public abstract class HM_Cluster extends HeuristicModule {
    /** The logger */
    private static final Logger logger;


    /** Number of test run iterations, if specified */
    protected int numberOfIterations;

    /** Datasets from all available services. Key is service ID, value is data object. */
    protected HashMap<String, MetricDataset> allData;

    /** List of service IDs/URIs that are clustered with this service. */
    protected ArrayList<String> clusterURIs;

    /** The evaluation metric */
    protected Function evalMetric;

    /** Random number generator */
    protected Random rnd;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(HM_Cluster.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of HM_Cluster.
     * @throws java.lang.Exception any error.
     */
    public HM_Cluster() throws Exception
    {
        super();
        initialiseValues();
    }

    /**
     * Create a new instance of HM_Cluster.
     * @param adminXml configuration parameters, including metric type and setup.
     * @throws java.lang.Exception any error.
     */
    public HM_Cluster(Element adminXml) throws Exception
    {
        super(adminXml);
        initialiseValues();
    }

    /** Initialise some values */
    private void initialiseValues()
    {
        allData = null;
        evalMetric = null;
        rnd = new Random();
        resetValues();
    }

    /**
     * Reset variables for another test run.
     */
    public void resetValues()
    {
        if (service != null) {
            ((DataService)service).resetValues();
        }
        numberOfIterations = -1;
        clusterURIs = new ArrayList<>();
    }

    /**
     * Return true if the current iterations value is OK with respect to a maximum value.
     * This also updates the iterations value.
     * @param maxIterations the maximum value to compare with.
     * @return true if the current value is OK.
     */
    protected boolean iterationsOK(int maxIterations)
    {
        boolean iterationsOK;                   //true if OK

        //if max iterations is -1 then loop indefinitely
        if (maxIterations > 0) {
            if (numberOfIterations < 0) numberOfIterations = 0;
        }

        //if iterations is -1 then loop indefinitely
        iterationsOK = ((numberOfIterations < 0) || (numberOfIterations < maxIterations));
        if (numberOfIterations >= 0) numberOfIterations++;

        return iterationsOK;
    }

    /**
     * Check for existing links to the selected service, as part of a cluster.
     * @param linkTo the uuid of the service to check for.
     * @return an integer of -1 if the service does not yet exist, 0 if there is no link
     * to the service or its cluster, or 1 if there is a link to the service or its cluster.
     * @throws java.lang.Exception any error.
     */
    protected int alreadyLinkedTo(String linkTo) throws Exception
    {
        int isLinked;                           //return linked value

        //call the linkTo service to make sure that it does not link to the parent service.
        try {
            if (service.hasLinkTo(linkTo)) {
                isLinked = 1;
            }
            else {
                //OK if not consider remote servers
//                if (LocalServer.getApi(getServerPassword()).serverHasService(linkTo))
//                {
                isLinked = 0;
//                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "alreadyLinkedTo",
                    null, ex);
        }

        return isLinked;
    }

    /**
     * Get the evaluation metric type, if initialised with the info in the admin {@code Meta} element.
     * This check can be performed automatically, but the metric info might not be added,
     * when a default metric ({@code Euclidean}) can be used instead.
     * @return the evaluation metric type, if added to the admin document Meta element, or
     * null otherwise.
     * @throws java.lang.Exception any error.
     */
    protected String getMetricType() throws Exception
    {
        String evalType;                        //the evaluation type
        Element psElem;                         //problem solver element
        Element metricElem;                     //metric element

        evalType = null;
        if (configXml != null) {
            psElem = XmlHandler.firstWithName(configXml, AiConst.AISOLVER);

            if (psElem != null) {
                metricElem = psElem.getChild(AiConst.METRICTYPE);

                if (metricElem != null) {
                    evalType = metricElem.getText();
                }
            }
        }

        return evalType;
    }
}
