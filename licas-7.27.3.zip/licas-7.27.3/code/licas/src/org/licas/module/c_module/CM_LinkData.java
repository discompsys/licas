/*
 * CM_LinkData.java
 *
 * Created on 9 October 2019
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.module.c_module;


import org.licas.*;
import org.licas.meta.MetaFactory;
import org.licas.query.LicasQueryConst;
import org.licas.service.sci.LinkService;
import org.licas.util.*;
import org.licas.util.exception.ServiceException;
import org.licas_text.parser.QueryParser;
import org.licas_text.query.QueryMediator;
import org.licas_text.query.model.*;
import org.licas_text.util.QueryConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.Monitor;

import org.ai_heuristic.util.AiHeuristicConst;
import org.dcs.query_process.Script_Factory;
import org.dcs.query_process.model.*;
import org.dcs.query_process.model.activity.*;
import org.dcs.query_process.model.data.*;
import org.dcs.query_process.model.event.Script_Invoke;
import org.dcs.query_process.model.link.*;
import org.dcs.query_process.util.Script_Const;

import java.util.ArrayList;

/**
 * This module provides functionality for a scientific service to link with other
 * services using the cluster algorithms, through the Auto behaviour methods and
 * autonomic script.
 */
public class CM_LinkData extends CM_Script {

    /** The logger */
    private static final Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(CM_LinkData.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of CM_LinkData.
     * @param service the parent service.
     * @param pHandler the parent password handler.
     * @throws Exception any error.
     */
    public CM_LinkData(Service service, PasswordHandler pHandler)
            throws Exception
    {
        super(service, pHandler);
        initialise();
    }

    /**
     * Initialise some values.
     */
    private void initialise()
    {}

    /**
     * Evaluate a behaviour, initialised by an input {@code messageInfo}, with the evaluation logic
     * written in a {@code behaviourAction} method.
     * @param messageInfo the message with initial behaviour details.
     * @return the evaluation reply.
     * @throws Exception and error.
     */
    public MessageInfo evaluateBehaviour(MessageInfo messageInfo) throws Exception
    {
        String serverPassword;                      //server password
        Element endTestReply;                       //end of test
        MessageInfo messageReply;                   //message reply

        try {
            //retrieve all service IDs once, then call services one at a time
            //in a random and distributed way, allowing all services to run together
            getServiceIDs();
            messageReply = null;

            if (!service.getShutDown()) {
                //possibly need to initialise with all passwords first
                if (!passwordHandler.hasServicePassword(Const.HTTPSERVER)) {
                    serverPassword = getServerPassword();
                    if (serverPassword != null) {
                        passwordHandler.addServicePassword(Const.HTTPSERVER, serverPassword);
                    }
                }

                //cluster the existing datasets and link to the closest ones
                try {
                    //invoke the behaviour to cluster on a randomly chosen service dataset
                    messageReply = (new AutoComm()).behaviourAction(messageInfo, (LinkService)service);

                    //if reply is null then can be end of a cycle, so reset
                    if ((messageReply == null) && !service.getShutDown()) {
                        resetValues();
                        getServiceIDs();
                        service.setShutDown(serviceIDs.isEmpty(), passwordHandler.getAdminKey());
                    }
                }
                catch (Exception ex2) {
                    service.setShutDown(true, passwordHandler.getAdminKey());
                }
                finally {
                    Monitor.getMonitor().release();
                    ThreadHandler.notifyEvents();
                }
            }
            else {
                endTestReply = MetaFactory.createMeta(AiConst.TESTENDED);
                messageReply = new MessageInfo(endTestReply);
            }

            return messageReply;
        }
        catch (ServiceException se) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "evaluateBehaviour", null, se);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "evaluateBehaviour", null, ex);
        }
    }

    /**
     * Create the policy description that can be used as a default script for initialising the
     * auto engine of this service. This if for the service itself, not any related autonomic
     * manager.
     * @return a policy script to initialise the service with.
     * @throws Exception any error.
     */
    public Element createProcessScript() throws Exception
    {
        Element policyXml;                              //policy element
        Script_Process scriptModel;                     //process model
        Script_SwitchTrue scriptSwitch;                 //true switch event
        Script_Sequence scriptSequence;                 //sequence event
        Script_Invoke scriptInvoke;                     //invoke event
        Script_Target scriptTarget;                     //target link
        Script_Source s1;                               //source object
        Script_Variable sv1;                            //variable type
        Script_Variable sv2;                            //variable type
        Script_VariableInstance qm1;                    //variable instance
        Script_VariableInstance qm2;                    //variable instance
        Script_VariableInstance qm3;                    //variable instance
        Script_VariableInstance qr1;                    //variable instance
        Script_Method m1;                               //method description
        Script_Method m2;                               //method description
        Script_Method m3;                               //method description
        Script_Method m4;                               //method description
        Script_Method m5;                               //method description
        Element queryXml;                               //query as xml
        Element replyXml;                               //reply as xml
        Element methodXml;                              //method as xml
        ArrayList<String> paramTypes;                   //parameter types
        ArrayList<String> paramNames;                   //parameter names
        QueryModel queryModel;                          //query model
        PatternConstraint patternConstraint;            //pattern constraint
        QueryParser queryParser;                        //query parser

        try
        {
            queryParser = new QueryParser();
            policyXml = MetaFactory.createPolicy();

            scriptModel = (Script_Process) Script_Factory.createNewElement(Script_Const.PROCESS);

            //add the sources
            s1 = (Script_Source) Script_Factory.createNewElement(Script_Const.SOURCE);
            s1.setObjType(Const.OBJECT);
            s1.setValue(QueryMediator.class.getName());
            scriptModel.addSource(s1);

            //add the variables
            sv1 = (Script_Variable)Script_Factory.createNewElement(Script_Const.VARIABLE);
            sv1.setObjType(LicasQueryConst.QUERYMODEL);
            sv1.setValue(Element.class.getName());
            scriptModel.addVariable(sv1);

            //add the variable instances
            qm1 = (Script_VariableInstance)Script_Factory.createNewElement(Script_Const.VARIABLEINSTANCE);
            qm1.setObjType(sv1.getID());
            queryModel = QueryModel.createModel(QueryConst.NOTEXISTS);
            queryXml = queryParser.serialize(queryModel);
            qm1.setValue(queryXml);
            scriptModel.addVariableInstance(qm1);

            qm2 = (Script_VariableInstance)Script_Factory.createNewElement(Script_Const.VARIABLEINSTANCE);
            qm2.setObjType(sv1.getID());
            queryModel = QueryModel.createModel(QueryConst.ASMATHCOMPARE);
            patternConstraint = new PatternConstraint(AiHeuristicConst.LT);
            if (((LinkService)service).getDataType() == null) patternConstraint.setValueType(Const.DATATYPE);
            else patternConstraint.setValueType(((LinkService)service).getDataType());
            ((QueryModelNumerical)queryModel).addQueryConstraint(patternConstraint);
            queryXml = queryParser.serialize(queryModel);
            qm2.setValue(queryXml);
            scriptModel.addVariableInstance(qm2);

            qm3 = (Script_VariableInstance)Script_Factory.createNewElement(Script_Const.VARIABLEINSTANCE);
            qm3.setObjType(sv1.getID());
            queryModel = QueryModel.createModel(QueryConst.ASMATHCOMPARE);
            patternConstraint = new PatternConstraint(AiHeuristicConst.EQ);
            if (((LinkService)service).getDataType() == null) patternConstraint.setValueType(Const.DATATYPE);
            else patternConstraint.setValueType(((LinkService)service).getDataType());
            ((QueryModelNumerical)queryModel).addQueryConstraint(patternConstraint);
            queryXml = queryParser.serialize(queryModel);
            qm3.setValue(queryXml);
            scriptModel.addVariableInstance(qm3);

            qr1 = (Script_VariableInstance)Script_Factory.createNewElement(Script_Const.VARIABLEINSTANCE);
            qr1.setObjType(Element.class.getName());
            replyXml = XMLFactory.getInstance().createElement(QueryConst.OK);
            qr1.setValue(replyXml);
            scriptModel.addVariableInstance(qr1);

            //add the reflection method instances
            m1 = (Script_Method)Script_Factory.createNewElement(Script_Const.METHOD);
            m1.setObjType(Element.class.getName());
            paramTypes = new ArrayList<>();
            paramTypes.add(Element.class.getName());
            paramTypes.add(Object.class.getName());
            paramNames = new ArrayList<>();
            paramNames.add(Const.QUERY);
            paramNames.add(AiConst.MI_OBJECT);
            methodXml = MetaFactory.createMethod(QueryMediator.class, "executeQuery", null, paramTypes, paramNames);
            m1.setValue(methodXml);
            scriptModel.addReflection(m1);

            m2 = (Script_Method)Script_Factory.createNewElement(Script_Const.METHOD);
            m2.setObjType(Element.class.getName());
            paramTypes = new ArrayList<>();
            paramTypes.add(Element.class.getName());
            paramTypes.add(Object.class.getName());
            paramTypes.add(Object.class.getName());
            paramNames = new ArrayList<>();
            paramNames.add(Const.QUERY);
            paramNames.add("difference");
            paramNames.add(AiConst.MI_OBJECT);
            methodXml = MetaFactory.createMethod(QueryMediator.class, "executeQuery", null, paramTypes, paramNames);
            m2.setValue(methodXml);
            scriptModel.addReflection(m2);

            m3 = (Script_Method)Script_Factory.createNewElement(Script_Const.METHOD);
            m3.setObjType(Element.class.getName());
            paramTypes = new ArrayList<>();
            paramTypes.add(Element.class.getName());
            paramNames = new ArrayList<>();
            paramNames.add("serviceUri");
            methodXml = MetaFactory.createMethod(LinkService.class, "addDynamicLink", TypeConst.ARRAYLIST, paramTypes, paramNames);
            m3.setValue(methodXml);
            scriptModel.addReflection(m3);

            m4 = (Script_Method)Script_Factory.createNewElement(Script_Const.METHOD);
            m4.setObjType(Element.class.getName());
            methodXml = MetaFactory.createMethod(LinkService.class, "removeAllPermanentLinks", null, null);
            m4.setValue(methodXml);
            scriptModel.addReflection(m4);

            m5 = (Script_Method)Script_Factory.createNewElement(Script_Const.METHOD);
            m5.setObjType(Element.class.getName());
            paramTypes = new ArrayList<>();
            paramTypes.add(Object.class.getName());
            paramNames = new ArrayList<>();
            paramNames.add("difference");
            methodXml = MetaFactory.createMethod(LinkService.class, "setResultObj", null, paramTypes, paramNames);
            m5.setValue(methodXml);
            scriptModel.addReflection(m5);

            //add the switch event with cases
            scriptSwitch = (Script_SwitchTrue)Script_Factory.createNewElement(Script_Const.SWITCHTRUE);
            scriptModel.addEvent(scriptSwitch);

            //case condition - method variables and effector list if true
            sv2 = (Script_Variable)Script_Factory.createNewElement(Script_Const.VARIABLE, Const.QUERY);
            sv2.setValue(qm1.getID());
            scriptSequence = (Script_Sequence)Script_Factory.createNewElement(Script_Const.SEQUENCE);
            scriptInvoke = (Script_Invoke)Script_Factory.createNewElement(Script_Const.INVOKE);
            scriptInvoke.setOperation(m3.getID());
            scriptSequence.addEvent(scriptInvoke);
            scriptTarget = (Script_Target)Script_Factory.createNewElement(Script_Const.TARGET);
            scriptTarget.setLink(AiConst.THIS);
            scriptInvoke.setLink(scriptTarget);
            scriptInvoke = (Script_Invoke)Script_Factory.createNewElement(Script_Const.INVOKE);
            scriptInvoke.setOperation(m5.getID());
            scriptSequence.addEvent(scriptInvoke);
            scriptTarget = (Script_Target)Script_Factory.createNewElement(Script_Const.TARGET);
            scriptTarget.setLink(AiConst.THIS);
            scriptInvoke.setLink(scriptTarget);
            scriptSwitch.addCase(s1.getID(), m1.getID(), sv2, qr1.getID(), scriptSequence);

            //case condition - method variables and effector list if true
            sv2 = (Script_Variable)Script_Factory.createNewElement(Script_Const.VARIABLE, Const.QUERY);
            sv2.setValue(qm2.getID());
            scriptSequence = (Script_Sequence)Script_Factory.createNewElement(Script_Const.SEQUENCE);
            scriptInvoke = (Script_Invoke)Script_Factory.createNewElement(Script_Const.INVOKE);
            scriptInvoke.setOperation(m4.getID());
            scriptSequence.addEvent(scriptInvoke);
            scriptTarget = (Script_Target)Script_Factory.createNewElement(Script_Const.TARGET);
            scriptTarget.setLink(AiConst.THIS);
            scriptInvoke.setLink(scriptTarget);
            scriptInvoke = (Script_Invoke)Script_Factory.createNewElement(Script_Const.INVOKE);
            scriptInvoke.setOperation(m3.getID());
            scriptSequence.addEvent(scriptInvoke);
            scriptTarget = (Script_Target)Script_Factory.createNewElement(Script_Const.TARGET);
            scriptTarget.setLink(AiConst.THIS);
            scriptInvoke.setLink(scriptTarget);
            scriptInvoke = (Script_Invoke)Script_Factory.createNewElement(Script_Const.INVOKE);
            scriptInvoke.setOperation(m5.getID());
            scriptSequence.addEvent(scriptInvoke);
            scriptTarget = (Script_Target)Script_Factory.createNewElement(Script_Const.TARGET);
            scriptTarget.setLink(AiConst.THIS);
            scriptInvoke.setLink(scriptTarget);
            scriptSwitch.addCase(s1.getID(), m2.getID(), sv2, qr1.getID(), scriptSequence);

            //case condition - method variables and effector list if true
            sv2 = (Script_Variable)Script_Factory.createNewElement(Script_Const.VARIABLE, Const.QUERY);
            sv2.setValue(qm3.getID());
            scriptSequence = (Script_Sequence)Script_Factory.createNewElement(Script_Const.SEQUENCE);
            scriptInvoke = (Script_Invoke)Script_Factory.createNewElement(Script_Const.INVOKE);
            scriptInvoke.setOperation(m3.getID());
            scriptSequence.addEvent(scriptInvoke);
            scriptTarget = (Script_Target)Script_Factory.createNewElement(Script_Const.TARGET);
            scriptTarget.setLink(AiConst.THIS);
            scriptInvoke.setLink(scriptTarget);
            scriptSwitch.addCase(s1.getID(), m2.getID(), sv2, qr1.getID(), scriptSequence);

            policyXml.addContent(scriptModel.toXml());
            return policyXml;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "createPolicyScript",
                    "", ex);
        }
    }
}
