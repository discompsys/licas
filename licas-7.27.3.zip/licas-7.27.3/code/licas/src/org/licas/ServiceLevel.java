/*
 * ServiceLevel.java
 *
 * Created on 28 January 2011
 *
 * Version 1.1.5
 *
 * Copyright (c) 2011 Kieran Greer
 */

package org.licas;


import org.licas.service.model.Contract;
import org.licas.util.MetaConst;
import org.licas.util.TimeConst;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;


/**
 * This is an implementation of the default service level agreement description.
 * This default class always returns a true result to any contract negotiation.
 * @author Kieran Greer
 */
public class ServiceLevel
{
    /** Default time interval of 1 day */
    private static final long INTERVALDEFAULT = TimeConst.MILLIDAY;

    /** The time interval for when a contract becomes out of date */
    private final long timeInterval;

    /** The time that the current contract was proposed or created */
    protected long timeStamp;

    /** The name of the service level */
    protected String serviceLevel;

    /** A list of the current service negotiations */
    protected HashMap<String, ServiceLevel> serviceNegotiations;

    /** The parent contract handler */
    protected ContractManager contractHandler;

    /** This service level's contract */
    protected Contract contract;

    
    /**
     * Create a new instance of ServiceLevel.
     * @param theServiceLevel the service level name.
     * @param theContractHandler the parent contract handler.
     * @param theContract this service level contract.
     */
    public ServiceLevel(String theServiceLevel, ContractManager theContractHandler,
        Contract theContract)
    {
        serviceLevel = theServiceLevel;
        contractHandler = theContractHandler;
        contract = theContract;
        timeInterval = INTERVALDEFAULT;
        initialise();
    }

    /**
     * Create a new instance of ServiceLevel.
     * @param theServiceLevel the service level name.
     * @param theContractHandler the parent contract handler.
     * @param theContract this service level contract.
     * @param thisTimeInterval the time interval for when a contract becomes out of date.
     */
    public ServiceLevel(String theServiceLevel, ContractManager theContractHandler,
        Contract theContract, long thisTimeInterval)
    {
        serviceLevel = theServiceLevel;
        contractHandler = theContractHandler;
        contract = theContract;
        timeInterval = thisTimeInterval;
        initialise();
    }

    /* Initialise some values */
    private void initialise()
    {
        timeStamp = (new Date().getTime());
        serviceNegotiations = new HashMap<>();
    }

    /**
     * Return true if the contract suggested by the client is OK.
     * This implementation only checks if the contract is a default 'yes' contract.
     * @param theContract the contract to process.
     * @return a true if a 'yes' contract, false otherwise.
     */
    public boolean contractIsOK(Contract theContract)
    {
        return Contract.isYesContract(theContract);
    }

    /**
     * Get the time the message was logged at.
     * This should be in the form of milliseconds from {@code Date.getTime()}.
     * @return the time stamp value.
     */
    public long getTimeStamp()
    {
        return timeStamp;
    }

    /**
     * Get the name of the service level.
     * @return the value of serviceLevel.
     */
    public String getServiceLevel()
    {
        return serviceLevel;
    }

    /**
     * Process the negotiation contract suggested by the client.
     * @param clientID the client id.
     * @param theContract the contract to process. This is a wrapper for an
     * XML-based contract description that is arbitrary with some standard elements.
     * @return a reply for the contract proposal.
     * @throws java.lang.Exception any error.
     */
    public Contract contractReply(String clientID, Contract theContract) throws Exception
    {
        ServiceLevel currentContract;                   //the current contract
        ServiceLevel newContract;                       //the new contract
        Contract contractReply;                         //the contract reply

        currentContract = null;
        removeNegotiations();

        if (contractIsOK(theContract)) {
            contractReply = Contract.getTrueContract(serviceLevel, clientID);
        }
        else {
            if (serviceNegotiations.containsKey(clientID)) {
                currentContract = serviceNegotiations.get(clientID);
            }

            contractReply = processThisContract(currentContract, theContract);
            newContract = new ServiceLevel(serviceLevel, contractHandler, contractReply);
            serviceNegotiations.put(clientID, newContract);
        }

        return contractReply;
    }

    /**
     * This can be used as a sort of generic processor of contract. Still to
     * be completed and returns the true contract as default.
     * @param currentContract the result of the current negotiations.
     * @param proposedContract the new client contract proposal.
     * @return the true or OK contract reply as the default for this class.
     * @throws java.lang.Exception any error.
     */
    protected static Contract processThisContract(ServiceLevel currentContract,
            Contract proposedContract) throws Exception
    {
        String clientID;                                //client id
        String serviceLevel;                            //service level

        clientID = Contract.getElementValue(MetaConst.CLIENT, proposedContract);
        if (currentContract != null) serviceLevel = currentContract.getServiceLevel();
        else serviceLevel = Contract.getElementValue(MetaConst.SERVICELEVEL, proposedContract);

        return Contract.getTrueContract(clientID, serviceLevel);
    }

    /**
     * Remove all negotiations for all contracts that are now out of date.
     */
    private void removeNegotiations()
    {
        long currentTime;                           //current time stamp
        long timeDiff;                              //time difference
        String nextKey;                             //next key
        Iterator<String> allKeys;                   //all keys
        ServiceLevel nextContract;                  //the new contract

        currentTime = (new Date().getTime());
        
        allKeys = serviceNegotiations.keySet().iterator();
        while (allKeys.hasNext())
        {
            nextKey = allKeys.next();
            nextContract = serviceNegotiations.get(nextKey);
            timeDiff = currentTime - nextContract.getTimeStamp();
            if (timeDiff > timeInterval) serviceNegotiations.remove(nextKey);
        }
    }
}
