/*
 * FaultManager.java
 *
 * Created on 22 May 2020
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer.
 */

package org.licas.security;


import org.licas.*;
import org.licas.server.ESB;
import org.licas.service.link.Link_NM;
import org.licas.service.spec.LinkSpec;
import org.licas.util.*;

import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.util.ArrayList;


/** This class processes the different fault types passed through the system and adds them to the fault tree */
public class FaultManager {

    /** For logging */
    private static final Logger logger;

    /** The enterprise service bus */
    private final ESB esb;

    /** The server password handler */
    private final PasswordHandler passwordHandler;

    /** The tree structure that stores the fault information */
    private Link_NM faultTree;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(FaultManager.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of FaultManager.
     * @param theESB the server ESB.
     * @param thePasswordHandler the server password handler.
     * @param linkSpec dynamic linking spec for the fault tree.
     * @throws java.lang.Exception any error.
     */
    public FaultManager(ESB theESB, PasswordHandler thePasswordHandler, LinkSpec linkSpec)
            throws Exception {
        esb = theESB;
        passwordHandler = thePasswordHandler;
        initialise(linkSpec);
    }

    /**
     * Initialise some values.
     * @param linkSpec dynamic linking spec for the fault tree.
     * @throws java.lang.Exception any error.
     */
    private void initialise(LinkSpec linkSpec) throws Exception {
        faultTree = new Link_NM(esb, passwordHandler);
        faultTree.setThresholds(linkSpec);
    }

    /**
     * This method should be called to notify the server about a problem or fault.
     * It could also happen automatically through the autonomic manager, for example,
     * but extra coding is required for that. The fault details are read and stored in a tree structure for analysis.
     * Only minimal additional action is taken, such as removing or blocking the offending entity.
     * See the documentation for more details.
     * @param fault a description of the fault.
     */
    public void notifyOfFault(FaultDetails fault)
    {
        String serviceUuid;                         //service uuid
        String serviceKey;                          //service admin key
        String faultType;                           //fault type
        String actionType;                          //action type
        ArrayList<FaultDetails> faultList;          //fault list
        Service nextService;                        //next service

        try {
            faultType = fault.getType();

            if (faultType.equalsIgnoreCase(MetaConst.SERVERFAULT)) {
                //basic server error, add to the fault tree for later analysis
                faultList = new ArrayList<>();
                faultList.add(fault);
                faultTree.addDynamicLinks(faultList, fault.getConceptList());
            }
            else if (faultType.equalsIgnoreCase(MetaConst.SERVICEMISSING)) {
                //service not found, add to the fault tree for later analysis
                faultList = new ArrayList<>();
                faultList.add(fault);
                faultTree.addDynamicLinks(faultList, fault.getConceptList());
            }
            else if (faultType.equalsIgnoreCase(MetaConst.SERVICEACCESS)) {
                //problem accessing the service, check if an action is indicated
                serviceUuid = fault.getKey();
                actionType = fault.getAction();

                if ((serviceUuid != null) && !serviceUuid.equals("") &&
                        (actionType != null) && !actionType.equals("")) {
                    if (passwordHandler.hasAdminKey(serviceUuid)) {
                        serviceKey = passwordHandler.getAdminKey(serviceUuid);

                        if (actionType.equals(AiConst.ACTIONBLOCK)) {
                            esb.blockService(serviceUuid, serviceKey);
                        }
                        else if (actionType.equals(AiConst.ACTIONUNBLOCK)) {
                            esb.unblockService(serviceUuid, serviceKey);
                        }
                        else if (actionType.equals(AiConst.ACTIONSHUTDOWN)) {
                            nextService = (Service) esb.getService(serviceUuid,
                                    passwordHandler.getServicePassword(serviceUuid), serviceKey);
                            try {
                                nextService.clearServices(serviceKey);
                            }
                            catch (Exception ex2) {}

                            nextService.setShutDown(true, serviceKey);
                            esb.removeServiceID(serviceUuid, serviceKey);
                        }
                    }
                }
            }
            else if (faultType.equalsIgnoreCase(MetaConst.METHODFAULT)) {
                //repeated attempts to process the method fails, add to the fault tree for later analysis
                faultList = new ArrayList<>();
                faultList.add(fault);
                faultTree.addDynamicLinks(faultList, fault.getConceptList());
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "notifyOfFault",
                    "", ex);
        }
    }

    /**
     * Get the faults list tree.
     * @return the value of faults.
     */
    public Link_NM getFaultsTree()
    {
        return faultTree;
    }
}
