/*
 * Encryptor.java
 *
 * Created on 5 February 2018
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.security;


import org.jlog2.util.UuidHandler;
import org.licas.parsers.types.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;


/**
 * This can encrypt and decrypt a string message using the 'AES' algorithm. 
 * Note that encryption cannot be done in parts and concatenated together.
 * https://stackoverflow.com/questions/7762771/how-do-i-encrypt-decrypt-a-string-with-another-string-as-a-password
 * @author Kieran Greer
 */
public class Encryption 
{
    /** Algorithm type */
    private static final String ALGORITHM = "AES";

    /**
     * Encrypt a string using a strong aes algorithm. The returned string is also
     * base64 encoded, so use decrypt to reverse the encryption.
     * @param toEncrypt the string to encrypt.
     * @param key the encryption key.
     * @return the encrypted byte string.
     * @throws java.lang.Exception any error.
     */
    public String encrypt(String toEncrypt, Key key) throws Exception 
    {
        try
        {
            Cipher c = Cipher.getInstance(ALGORITHM);
            c.init(Cipher.ENCRYPT_MODE, key);

            byte[] encValue = c.doFinal(toEncrypt.getBytes());
            return Base64.encodeBytes(encValue);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /**
     * Decrypt a string using a strong aes algorithm.
     * @param toDecrypt the string to decrypt.
     * @param key the encryption key.
     * @return the encrypted string.
     * @throws java.lang.Exception any error.
     */
    public String decrypt(String toDecrypt, Key key) throws Exception 
    {
        try
        {
            Cipher c = Cipher.getInstance(ALGORITHM);
            c.init(Cipher.DECRYPT_MODE, key);

            byte[] decValue = Base64.decode(toDecrypt);
            decValue = c.doFinal(decValue);
            return new String(decValue);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /**
     * Generate a unique key to use as the basis for some encryption.
     * @return the encryption key.
     * @throws java.lang.Exception any error.
     */
    public Key generateKey() throws Exception 
    {
        String uuid = UuidHandler.getUuid(16);
        return new SecretKeySpec(uuid.getBytes(), ALGORITHM);
    }
}
