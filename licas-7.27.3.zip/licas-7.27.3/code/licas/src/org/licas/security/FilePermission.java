/*
 * FilePermission.java
 *
 * Created on 2 January 2014
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.security;


import java.util.ArrayList;


/**
 * Stores permissions related to folder or directory access.
 * This is a licas-specific implementation that is a simplified version of Java's default one.
 * @author Kieran
 */
public class FilePermission extends Permission
{
    /** The path to the folder, file or directory */
    public String folderPath;
    
    /** A list of permissions */
    public ArrayList<String> permissions;
    
    
    /** Create a new instance of FilePermission with empty values */
    public FilePermission()
    {
        folderPath = null;
        permissions = new ArrayList<>();
    }
    
    /** 
     * Create a new instance of FilePermission.
     * @param theFolderPath the folder / file / directory path.
     */
    public FilePermission(String theFolderPath)
    {
        folderPath = theFolderPath;
        permissions = new ArrayList<>();
    }
}
