/*
 * SecurityWebManager.java
 *
 * Created on 13 December 2013
 *
 * Version 1.0.3
 *
 * Copyright (c) 2007 Kieran Greer
 */

package org.licas.security;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.util.StringHandler;
import org.licas.util.Const;
import org.licas.util.MetaConst;
import org.licas.util.ServiceConst;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Iterator;


/**
 * This manages permissions to files or resources running on a licas server.
 * This stores and handles permissions separately from the System security manager,
 * but it also tries to use those permissions, as part of the security process.
 * Different to the System security manager, any declared folder automatically
 * assigns to any of its files, or files in any sub-folders, the same permissions.
 * So it is an inclusive permission for all contained files and folders.
 * <p>
 * For direct file retrieval, the process might work as follows:
 * The user types something like: http://127.0.0.1:8080/htmlFolder/file.html
 * The system parses this and gets 'htmlFolder/file.html' as the instruction.
 * It retrieves all of its allowed base directories, adds this and then checks
 * if there is an existing file with that name.
 * If for example, the default C:/DCS/web folder is assumed, it will check if
 * C:/DCS/web/htmlFolder/file.html allowed. If however, you also add something like
 * C:/Users/You/Documents as allowed, then it can look for a file at
 * C:/Users/You/Documents/htmlFolder/file.html as well. The first match will be returned
 * so duplication is not advised. 
 * There is also a {@code websearch} folder inside the {@code web} folder. You can use this
 * to place text documents that you allow to be searched for and analysed for actual content
 * to be matched to. It might be useful for distributed queries, for example.
 * The System security manager might change read/write permissions on this.
 * @author Kieran Greer
 */
public class SecurityWebManager
{
    /** For logging */
    private static final Logger logger;
    
    
    private static final String README = "Licas web folder\n" +
                                    "----------------\n" +
                                    "This is the root folder for placing html or other documents to be\n" +
                                    "retrieved over the web by a browser. Can also include binary files.\n\n\n" +
                                    "websearch folder\n" +
                                    "----------------\n" +
                                    "This is the root folder for distributed querying of document content.\n" +
                                    "The All-in-One GUI query engine can search here and retrieve all\n" +
                                    "text documents in this and any sub-folder and analyse the content\n" +
                                    "to find mathing words or sequences. Place any text files that you\n" +
                                    "want to make available over the web for distributed content searches here.\n\n\n" +
                                    "Kieran Greer\n" +
                                    "kgreer@distributedcomputingsystems.co.uk\n" +
                                    "http://distributedcomputingsystems.co.uk";
    
    /** 
     * Local security or web permissions.
     * Key is the permission type and value is of type PermissionsList.
     */
    private HashMap<String, PermissionsList<String, ?>> swPermissions;
    
    /** The system security manager */
    private SecurityManager sm;
    
    /** Instance of the security manager */
    private static volatile SecurityWebManager instance = null;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(SecurityWebManager.class.getName());
        logger.setDebug(false);
    }


    /** Create a new instance of SecurityWebManager */
    private SecurityWebManager()
    {
        initialise();
    }

    /**
     * Set the instance of the security manager. This is done automatically, so
     * you only need to set if using a different manager. This can only be set
     * if the manager is currently empty.
     * @param swManager the new security web manager.
     */
    public static void setInstance(SecurityWebManager swManager)
    {
        if (instance == null) {
            instance = swManager;
        }
    }

    /**
     * Get the instance of the security manager.
     * @return the single instance of the security manager.
     */
    public static SecurityWebManager getInstance()
    {
        if (instance == null) {
            synchronized (SecurityWebManager.class) {
                if (instance == null) {
                    instance = new SecurityWebManager();
                }
            }
        }

        return instance;
    }
    
    /** Initialise some values */
    private void initialise()
    {
        File webFile;                                   //web file
        FileOutputStream writer;                        //file writer

        sm = System.getSecurityManager();
        swPermissions = new HashMap<>();
        
        //always include the default web location
        addDefaultWebFolderPermission();
        
        try {
            webFile = new File(ServiceConst.WEBHOME);
            if (!webFile.exists()) {
                webFile.mkdir();
            }
            
            webFile = new File(ServiceConst.WEBSEARCHHOME);
            if (!webFile.exists()) {
                webFile.mkdir();
            }
            
            //add readme for info
            webFile = new File(ServiceConst.WEBHOME + "readMe.txt");
            if (!webFile.exists()) {
                writer = new FileOutputStream(webFile);
                writer.write(README.getBytes());
                writer.close();
            }
        }
        catch (Exception ex) {}
    }
    
    /**
     * Clear the permissions list for the specified permissions type. This might
     * perform other operations for default settings.
     * @param permissionsType the permissions type.
     */
    public void clearPermissions(String permissionsType)
    {
        PermissionsList<String, ?> permissionsList;         //permissions list
        
        if (swPermissions.containsKey(permissionsType)) {
            permissionsList = swPermissions.get(permissionsType);
            permissionsList.clear();
        }
    }
    
    /** Add the default permission for the default web folder */
    private void addDefaultWebFolderPermission()
    {
        PermissionsList<String, ?> permissionsList;         //permissions list
        FilePermission filePermission;                      //file permission
        
        if (!swPermissions.containsKey(MetaConst.FILEPERMISSION)) {
            swPermissions.put(MetaConst.FILEPERMISSION, new PermissionsList<>());
        }
        
        permissionsList = swPermissions.get(MetaConst.FILEPERMISSION);
        if (!permissionsList.containsKey(ServiceConst.WEBHOME)) {
            permissionsList.put(ServiceConst.WEBHOME, new FilePermission(ServiceConst.WEBHOME));
        }
        
        filePermission = (FilePermission)permissionsList.get(ServiceConst.WEBHOME);        
        if (!filePermission.permissions.contains(MetaConst.READ)) {
            filePermission.permissions.add(MetaConst.READ);
        }
    }
    
    /**
     * Check if the specified permission allowed. The System security manager is also
     * considered, but the file path should be covered by the licas security manager.
     * @param type the permission type. Currently only MetaConst.FILEPERMISSION.
     * @param key the permission key or description. For a file access, for example,
     * it is the additional file path that gets added to the default folder locations.
     * @param value the permission value. For a folder access for example, it is 
     * the access right - read / write, etc.
     * @return the permission reply if allowed, or null if access is denied.
     */
    public Permission checkPermission(String type, String key, String value)
    {
        boolean allowed;                                    //true if allowed
        String filePath;                                    //full file path
        String nextKey;                                     //next key
        String baseDir;                                     //base directory
        Iterator<String> allKeys;                           //all keys
        PermissionsList<String, ?> permissionsList;         //permissions list
        FilePermission filePermission;                      //file permission
        Permission permissionReply;                         //permission reply
        java.io.FilePermission sPermission;                 //system file permission
        java.io.File nextFile;                              //next file path
        
        allowed = false;
        nextFile = null;
        permissionReply = null;
        
        if (type != null) {
            if (type.equals(MetaConst.FILEPERMISSION)) {
                if (swPermissions.containsKey(type)) {
                    permissionsList = swPermissions.get(type);
                    allKeys = permissionsList.keySet().iterator();
                    
                    //remove starting bracket to make it compatible with base directory concatenation
                    if (key.startsWith("/") || key.startsWith("\\")) key = key.substring(1);
                    
                    //remove any '..' parent dir indicators, so that reverse traversal is not possible
                    key = StringHandler.replaceAll(key, "..", "");
                                           
                    while (!allowed && allKeys.hasNext())
                    {
                        try {
                            nextKey = allKeys.next();
                            baseDir = nextKey;
                            if (!baseDir.endsWith(Const.DIRSEP)) baseDir += Const.DIRSEP;
                            filePath = (baseDir + key);

                            nextFile = new File(filePath);                               
                            if (nextFile.exists()) {
                                //check the System security manager
                                if (sm != null) {
                                    sPermission = new java.io.FilePermission(filePath, value);
                                    sm.checkPermission(sPermission);
                                    allowed = true; 
                                }

                                //then check licas security manager access rights
                                if (!allowed) {
                                    filePermission = (FilePermission)permissionsList.get(nextKey);
                                    allowed = filePermission.permissions.contains(value);
                                }
                            }
                        }
                        catch (Exception ex) {}

                        if (allowed) {
                            permissionReply = new FilePermission(nextFile.getAbsolutePath());
                        }                    
                    }
                } 
            }
        }
        
        return permissionReply;
    }
    
    /**
     * Add a new permission of the specified type. The permission is added locally
     * only. The system security manager might also have the same permission.
     * @param type the permission type. Currently only MetaConst.FILEPERMISSION.
     * @param key the permission key or description. For a folder access for example,
     * it is the folder path.
     * @param value the permission value. For a folder access for example, it is 
     * the access right - read / write, etc.
     * @return true if added OK or it already allowed, false if there is an error.
     */
    public boolean addPermission(String type, String key, String value)
    {
        PermissionsList<String, ?> permissionsList;         //permissions list
        FilePermission filePermission;                      //file permission
        
        if (type != null) {
            if (type.equals(MetaConst.FILEPERMISSION)) {
                if (!swPermissions.containsKey(type)) {
                    swPermissions.put(type, new PermissionsList<>());
                }

                permissionsList = swPermissions.get(type);
                if (!permissionsList.containsKey(key)) {
                    permissionsList.put(key, new FilePermission(key));
                }

                filePermission = (FilePermission)permissionsList.get(key);
                if (!filePermission.permissions.contains(value)) {
                    filePermission.permissions.add(value);
                }
                
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Remove a permission of the specified type. The permission is removed locally
     * only. The system security manager might also have the same permission.
     * @param type the permission type. Currently only MetaConst.FILEPERMISSION.
     * @param key the permission key or description. For a folder access for example,
     * it is the folder path.
     * @param value the permission value. For a folder access for example, it is 
     * the read / write access permission, etc. MetaConst.ALL means to remove the
     * permission completely and not just a specific case.
     * @return true if removed completely, false if it is still a base security manager 
     * permission, even if it has been removed locally.
     */
    public boolean removePermission(String type, String key, String value)
    {
        boolean exists;                                     //true if allowed
        String systemValue;                                 //system value
        PermissionsList<String, ?> permissionsList;         //permissions list
        FilePermission filePermission;                      //file permission
        java.io.FilePermission sPermission;                 //system file permission
        
        exists = false;
        if (type != null) {
            if (type.equals(MetaConst.FILEPERMISSION)) {
                //if it is the default web location, then it cannot be removed
                if (value.equals(MetaConst.WRITE) || !key.equalsIgnoreCase(ServiceConst.WEBHOME)) {
                    //first check if parent security manager already has the permission
                    //then it probably cannot be removed completely
                    if (sm != null) {
                        if (value.equals(MetaConst.ALL)) systemValue = MetaConst.READ;
                        else systemValue = value;                   
                        sPermission = new java.io.FilePermission(key, systemValue);

                        try {
                            sm.checkPermission(sPermission);
                            exists = true;
                        }
                        catch (Exception ex) {
                            try {
                                if (value.equals(MetaConst.ALL)) {
                                    systemValue = MetaConst.WRITE;
                                    sPermission = new java.io.FilePermission(key, systemValue);
                                    sm.checkPermission(sPermission);
                                    exists = true;
                                }
                            }
                            catch (Exception ex2) {}
                        }
                    }

                    //also try to remove locally, but return false if still a system permission
                    permissionsList = swPermissions.get(type);
                    if (permissionsList != null) {
                        if (value.equals(MetaConst.ALL)) {
                            permissionsList.remove(key);
                        }
                        else {
                            filePermission = (FilePermission)permissionsList.get(key);
                            filePermission.permissions.remove(value);
                        }
                    }
                }
                else {
                    exists = true;
                }
            }
        }
        
        return !exists;
    }
    
    /**
     * Get the list of permissions for this security/web manager only. 
     * Any permissions for the parent System SecurityManager are not returned.
     * @return the value of swPermissions.
     */
    public HashMap<String, PermissionsList<String, ?>> getLocalPermissions()
    {
        return swPermissions;
    }
}
