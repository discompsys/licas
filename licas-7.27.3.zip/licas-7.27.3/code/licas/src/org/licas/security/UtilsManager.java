/*
 * UtilsManager.java
 *
 * Created on 30 November 2017
 *
 * Version 1.3.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.security;


import org.jlog2.util.FileLoader;
import org.licas.def.UtilsManagerDef;
import org.licas.util.ServiceConst;

import java.io.File;
import java.util.ArrayList;


/**
 * For managing server resources. To be used internally by the system.
 * @author Kieran Greer
 */
public class UtilsManager implements UtilsManagerDef
{
    /**
     * Check the web folder and delete any temporary files.
     * @param time temp files older than {@code (current - time) milliseconds}, are deleted.
     */
    public void webFolder(long time)
    {
        long fileAge;                       //file age
        
        fileAge = (System.currentTimeMillis() - time);
        emptyTempDir(fileAge);
    }
    
    /** 
     * Empty the temp directory of files.
     * @param fileAge maximum age of file.
     */
    protected void emptyTempDir(long fileAge)
    {
        int i;
        String nextFile;                    //next file
        String filePath;                    //full file path
        ArrayList<String> fileList;         //list of files
        File theFile;                       //the file
        
        try {
            fileList = FileLoader.getFileList(ServiceConst.TEMPDIR);

            for (i = 0; i < fileList.size(); i++)
            {
                nextFile = fileList.get(i);
                if (!nextFile.equalsIgnoreCase("readme.txt")) {
                    filePath = (ServiceConst.TEMPDIR + nextFile);

                    try {
                        theFile = new File(filePath);
                        if (theFile.lastModified() < fileAge) {
                            theFile.delete();
                        }
                    }
                    catch (Exception fex) {}
                }
            }
        }
        catch (Exception ex) {}
    }
}
