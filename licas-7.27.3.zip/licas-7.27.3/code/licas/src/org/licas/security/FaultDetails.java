/*
 * FaultDetails.java
 *
 * Created on 13 January 2017
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.security;


import org.licas.util.ObjectHandler;

import java.util.ArrayList;


/**
 * Structure to store details about a fault or error.
 * @author Kieran Greer
 */
public class FaultDetails 
{
    /** The type of fault */
    protected String faultType;
    
    /** An optional unique key to identify the fault */
    protected String faultID;
    
    /** 
     * An optional reference to the fault object. If {@code faultID} is {@code null}, then
     * the key is determined by {@link ObjectHandler}.{@code getKey()}.
     */
    protected Object reference;
    
    /** Optional text description of the fault event */
    protected String event;
    
    /** Optional text description of a reply action */
    protected String action;
    
    /** Timestamp for the fault */
    protected long timestamp;
    
    /** 
     * A list of concepts to create a descriptive tree from.
     * Should include at least one element that may be the fault type, for example.
     */
    public ArrayList<String> conceptList;
    
    
    /**
     * Create a new instance of FaultDetails
     * @param faultType the fault type.
     * @param faultKey a unique id to represent the fault.
     */
    public FaultDetails(String faultType, String faultKey)
    {
        initialise();
        this.faultType = faultType;
        this.event = faultType;         //same unless changes
        faultID = faultKey;
    }
    
    /**
     * Create a new instance of FaultDetails
     * @param faultType the fault type.
     * @param faultReference some reference to the offending object.
     */
    public FaultDetails(String faultType, Object faultReference)
    {
        initialise();
        this.faultType = faultType;
        this.event = faultType;         //same unless changes
        reference = faultReference;
    }
    
    /** Initialise some values */
    private void initialise()
    {
        faultType = null;
        faultID = null;
        reference = null;
        event = null;
        action = null;
        timestamp = System.currentTimeMillis();
        conceptList = new ArrayList<>();
    }
    
    /**
     * Get the fault type.
     * @return the value of faultType.
     */
    public String getType()
    {
        return faultType;
    }
    
    /**
     * Get the key identifier for the fault.
     * @return the value representing the fault key - {@code faultID}.
     */
    public String getKey()
    {
        try {
            if (faultID != null) {
                return faultID;
            }
            else {
                return ObjectHandler.getKey(reference);
            }
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    /**
     * Get the key identifier for the fault.
     * @return the value representing the fault key - {@code faultID}.
     */
    public Object getReference()
    {
        return reference;
    }
    
    /**
     * Set a description for the fault event.
     * @param thisEvent the fault event.
     */
    public void setEvent(String thisEvent)
    {
        event = thisEvent;
    }
    
    /**
     * Get the fault event. Can be null.
     * @return the value of event.
     */
    public String getEvent()
    {
        return event;
    }
    
    /**
     * Set a description for the reply action.
     * @param thisAction the reply action.
     */
    public void setAction(String thisAction)
    {
        action = thisAction;
    }
    
    /**
     * Get the reply action. Can be null.
     * @return the value of action.
     */
    public String getAction()
    {
        return action;
    }
    
    /**
     * Get the fault timestamp.
     * @return the value of timestamp.
     */
    public long getTimestamp()
    {
        return timestamp;
    }
    
    /**
     * Set the descriptive concept list.
     * @param thisConceptList the descriptive concept list.
     */
    public void setConceptList(ArrayList<String> thisConceptList)
    {
        conceptList = thisConceptList;
    }
    
    /**
     * Get the descriptive concept list.
     * @return the value of conceptList. If empty, then the fault type is returned.
     */
    public ArrayList<String> getConceptList()
    {
        ArrayList<String> cList;                    //concept list
        
        cList = conceptList;
        if ((cList == null) || cList.isEmpty()) {
            cList = new ArrayList<>();
        }

        if (cList.isEmpty() || !cList.get(0).equals(faultType)) {
            cList.add(0, faultType);
        }
        
        return cList;
    }
}
