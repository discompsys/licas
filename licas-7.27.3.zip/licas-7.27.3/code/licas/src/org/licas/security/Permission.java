/*
 * Permission.java
 *
 * Created on 7 January 2014
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.security;


/**
 * Base class for licas-system security permissions.
 * Licas-specific that is a simplified version.
 * @author Kieran
 */
public abstract class Permission 
{
    /** Create a new instance of Permission with empty values */
    public Permission()
    {}
}
