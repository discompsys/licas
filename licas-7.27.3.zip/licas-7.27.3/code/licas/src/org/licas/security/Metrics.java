/*
 * Metrics.java
 *
 * Created on 28 October 2015
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.security;


import org.licas.module.ServiceModule;
import org.licas.util.ObjectHandler;

/**
 * Measurements that the default autonomic manager can make.
 * @author Kieran Greer
 */
public class Metrics
{
    /** Unique ID for the service */
    public String serviceID;

    /** The service type */
    public String serviceType;

    /** Total number of messages received */
    public long messageCount;

    /** Total number of empty messages received */
    public long emptyCount;

    /** Total size of message objects received */
    public long messageSize;


    /** Create a new instance of Metrics */
    public Metrics()
    {
        serviceID = null;
        serviceType = null;
        messageCount = 0;
        emptyCount = 0;
        messageSize = 0;
    }

    /**
     * Add metrics to the values.
     * @param messageObj message object to analyse.
     */
    public void addMetrics(Object messageObj)
    {
        messageCount++;
        if (messageObj != null) {
            messageSize += ObjectHandler.sizeOf(messageObj);
        }
        else {
            emptyCount++;
        }
    }

    /**
     * Create and return an initialised metrics object.
     * @param service the service to initialise the metrics with.
     * @return the metrics object.
     */
    public static Metrics createMetrics(ServiceModule service)
    {
        Metrics metrics;                //the metrics object

        metrics = new Metrics();
        metrics.serviceID = service.getUUID();
        metrics.serviceType = service.getServiceType();
        return metrics;
    }
}
