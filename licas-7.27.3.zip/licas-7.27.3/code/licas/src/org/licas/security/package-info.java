/**
 * Security package for direct HTTP calls to the base server, for example, access rights to the file system.
 */
package org.licas.security;