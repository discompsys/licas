/*
 * PermissionsList.java
 *
 * Created on 2 January 2014
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.security;


import org.licas.util.MetaConst;
import org.licas.util.ServiceConst;

import java.util.HashMap;


/**
 * For storing lists of access permissions specifically.
 * @author Kieran Greer.
 */
public class PermissionsList<String, V> extends HashMap
{
    /** Create a new instance of PermissionsList */
    public PermissionsList()
    {
        super();
    }
    
    /**
     * Clear the permissions list, plus possibly some other operations.
     */
    public void clear()
    {
        FilePermission filePermission;                  //file permission
        Object nextPermission;                          //next permission
        
        nextPermission = null;
        if (containsKey(ServiceConst.WEBHOME)) nextPermission = get(ServiceConst.WEBHOME);       
        super.clear();
        
        //always include the default web location
        if (nextPermission instanceof FilePermission) {
            filePermission = (FilePermission)nextPermission;        
            filePermission.permissions.clear();           
            filePermission.permissions.add(MetaConst.READ);           
            put(ServiceConst.WEBHOME, filePermission);
        }
    }
}
