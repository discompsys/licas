/*
 * ServerMetadata.java
 *
 * Created on 17 September 2010
 *
 * Version 1.3.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.meta;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.Service;
import org.licas.server.esb.ServiceRepository;
import org.licas_xml.abs.Element;

import java.util.ArrayList;


/**
 * This class relates to metadata stored on the server, providing an extra layer
 * of protection over the service metadata repository. This class is used internally
 * by the system and the programmer does not need to program this class for any
 * additional actions. The retrieval process would also typically be password protected 
 * at the server level, with this class stored on a server privately. 
 * @author Kieran Greer
 */
public class ServerMetadata
{
    /** The logger */
    private static final Logger logger;


    /** 
     * Stores the metadata of all services that have loaded onto this server, no matter
     * where they are stored. Any service that is added through the {@link Service} {@code addService} method
     * will automatically have metadata created and added to this repository as part of
     * the process. The metadata that is added is created using the {@link Service} {@code createServiceMeta}
     * method internally, and is by default a description generated through the Java {@code Reflection}
     * classes.
     */
    protected ServiceRepository serviceRepos;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServerMetadata.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of ServerMetadata.
     */
    public ServerMetadata()
    {
        serviceRepos = new ServiceRepository();
    }

    /**
     * Add the metadata for the service.
     * @param theAdminKey the admin service key for the service.
     * @param theServiceMeta the metadata for the service.
     * @return true if added or false if it already exists.
     */
    public boolean addServiceMeta(String theAdminKey, ServiceMeta theServiceMeta)
    {
        try {
            if (!serviceRepos.isStoredService(theServiceMeta.uuid)) {
                return serviceRepos.addServiceMeta(theAdminKey, theServiceMeta);
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "addServiceMeta",
                null, ex);
        }

        return false;
    }
    
    /**
     * Get a subset of the metadata for the service, for info purposes only.
     * @param theServiceID the unique id to define the service.
     * @return the metadata in XML format if it exists or null if it does not.
     * @throws java.lang.Exception any error.
     */
    public Element getServiceMeta(String theServiceID) throws Exception
    {
        try {
            if (serviceRepos.isStoredService(theServiceID)) {
                return serviceRepos.getServiceMeta(theServiceID);
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "getServiceMeta",
                null, ex);
        }

        return null;
    }
    
    /**
     * Get a subset of the metadata for the service, plus other sections.
     * @param theServiceID the unique id to define the service.
     * @param toInclude list of additional meta parts to return.
     * @param serviceObjMeta full description of the service metadata.
     * @return the metadata in XML format if it exists, or null if it does not.
     * @throws java.lang.Exception any error.
     */
    public Element getServiceMeta(String theServiceID, ArrayList<String> toInclude,
            ServiceMeta serviceObjMeta) throws Exception
    {
        try {
            if (serviceRepos.isStoredService(theServiceID)) {
                return serviceRepos.getServiceMeta(theServiceID, toInclude, serviceObjMeta);
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "getServiceMeta",
                null, ex);
        }

        return null;
    }
    
    /**
     * Retrieve just one part of the metadata, not the whole object.
     * @param theServiceID the unique id to define the service.
     * @param toInclude meta part to return.
     * @param serviceObjMeta full description of the service metadata.
     * @return the metadata in XML format if it exists, or null if it does not.
     */
    public Element getServiceMetaPart(String theServiceID, String toInclude, 
            ServiceMeta serviceObjMeta)
    {
        try {
            if (serviceRepos.isStoredService(theServiceID)) {
                return serviceRepos.getServiceMetaPart(theServiceID, toInclude, serviceObjMeta);
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "getServiceMetaPart",
                null, ex);
        }

        return null;
    }

    /**
     * Get the service metadata from the repository.
     * @param theServiceID the unique id to define the service.
     * @param theAdminKey the unique admin key for the service.
     * @return a direct reference to the object itself so that it can be changed.
     */
    public ServiceMeta getServiceMeta(String theServiceID, String theAdminKey)
    {
        try {
            if (serviceRepos.isStoredService(theServiceID)) {
                return serviceRepos.getServiceMeta(theServiceID, theAdminKey);
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "getServiceMeta",
                null, ex);
        }

        return null;
    }

    /**
     * Remove the service metadata from the repository.
     * @param theServiceID the unique id of the service to remove.
     * @param theAdminKey the unique admin key for the service.
     * @return true if the info is removed or false otherwise.
     */
    public boolean removeServiceMeta(String theServiceID, String theAdminKey)
    {
        boolean isOK;                           //true if operation OK
        
        try {
            isOK = false;
            if (serviceRepos.isStoredService(theServiceID)) {
                isOK = serviceRepos.removeServiceMeta(theServiceID, theAdminKey);
            }
            
            return isOK;
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "removeServiceMeta",
                null, ex);
        }

        return false;
    }
    
    /**
     * Return true if the service id is stored for a loaded service.
     * @param theServiceID the unique service id.
     * @return true if registered for a loaded service, false otherwise.
     */
    public boolean isStoredService(String theServiceID)
    {
        return (serviceRepos.isStoredService(theServiceID));
    }
    
    /**
     * Clear all service metadata apart from the server itself.
     */
    public void clearServiceMetadata()
    {
        serviceRepos.clearServiceMetadata();
    }
    
    /**
     * Clear all service metadata for the specified services, apart from the server itself.
     * @param serviceIDs list of service IDs to remove metadata for.
     */
    public void clearServiceMetadata(ArrayList<String> serviceIDs)
    {
        serviceRepos.clearServiceMetadata(serviceIDs);
    }
    
    /**
     * Get a list of all of the service types in the network.
     * @return a list of all of the service types, of type String.
     */
    public ArrayList<String> getServiceTypes()
    {
        return serviceRepos.getServiceTypes();
    }
    
    /**
     * Get a list of all of the service types in the network for a
     * particular category.
     * @param category the category to return service types for.
     * @return a list of all of the service types, of type String.
     */
    public ArrayList<String> getServiceTypes(String category)
    {
        return serviceRepos.getServiceTypes(category);
    }
}
