/*
 * MetaFactoryAI.java
 *
 * Created on 9 April 2014.
 *
 * Version 1.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.meta;


import org.licas.autonomic.AutonomicManager;
import org.licas.autonomic.AutonomicManagerDefault;
import org.licas.util.AiConst;
import org.licas.util.Const;
import org.licas.util.MetaConst;
import org.licas.util.ObjectHandler;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;

import java.util.HashMap;


/**
 * This class can create metadata parts that can be used as part of AI scripts. The script
 * creation is now very closely linked to the {@code query_process} scripting package.
 * @author Kieran Greer
 */
public class MetaFactoryAI 
{
    /** Create a new instance of MetaFactoryAI */
    public MetaFactoryAI()
    {}
    
    /**
     * Create an XML element that can be used as the base part of a script to define 
     * an {@link AutonomicManager} setup. Both parameters can be null, when this script is
     * still useful, as you can then add specific AM module descriptions to it.
     * @param className the class name of the autonomic manager to load. This can be null,
     * when the default {@link AutonomicManagerDefault} version will be used instead.
     * @param jarFile the main jar file if the manager is from an external source. The
     * system should try to also retrieve the jars from an associated {@code lib} folder,
     * but it is better to pack all new classes in a single jar and make that available.
     * This can also be null if the jar already exists or the default version is used.
     * @return an XML element that defines the service to load. This might look like:
     * {@code <Autonomic_Manager><Class_Name>Optional AM class name</Class_Name>
     * <Jar_File>Optional AM jar file path</Jar_File></Autonomic_Manager>}
     */
    public Element createAutonomicManager(String className, String jarFile)
    {
        Element rootElem;                               //root element
        Element nextElem;                               //next element
        
        rootElem = XMLFactory.getInstance().createElement(AiConst.AUTONOMICMANAGER);
        
        if (className != null)
        {
            nextElem = XMLFactory.getInstance().createElement(Const.CLASSNAME);
            nextElem.setText(className);
            rootElem.addContent(nextElem);
        }
        
        if (jarFile != null)
        {
            nextElem = XMLFactory.getInstance().createElement(Const.JARFILEXML);
            nextElem.setText(jarFile);
            rootElem.addContent(nextElem);
        }
        
        return rootElem;
    }
    
    /**
     * Create an XML element that can be used as the base part of a script to define 
     * an {@link AutonomicManagerDefault} setup. The classes used are the default ones
     * and so do not need to be entered.
     * @return an XML element that defines the service to load. This might look like:
     * {@code <Autonomic_Manager><Class_Name>AutonomicManagerDefault</Class_Name>
     * <Jar_File>Null as licas package</Jar_File></Autonomic_Manager>}
     */
    public Element createAutonomicManagerDefault()
    {
        return createAutonomicManager(null, null);
    }
    
    /**
     * Create an XML element that can be used to define one of the {@link AutonomicManager}
     * modules. This should then be added directly to the AM script root element.
     * @param moduleType the module type. Can be {@code AiConst.MONITOR}, {@code AiConst.ANALYZE}, 
     * {@code AiConst.PLAN}, or {@code AiConst.EXECUTE}.
     * @param className the class name of the autonomic module to load. This can be null,
     * when the default version will be used instead.
     * @param jarFile the jar file path if the manager is from an external source.
     * This can also be null if the jar already exists or the default version is used.
     * @param policy the policy script that defines what the module should evaluate and
     * how the module should respond. This is required, but you can use {@link MetaFactory}.{@code createPolicy}
     * to create an empty one.
     * @return an XML element that defines the service to load. This might look like:
     * {@code <Module_Type><Class_Name>Optional module class name</Class_Name>
     * <Jar_File>Optional module jar file path</Jar_File><Policy>Policy script here</Policy></Module_Type>}
     */
    public Element createAM_Module(String moduleType, String className, String jarFile,
            Element policy)
    {
        Element rootElem;                               //root element
        Element nextElem;                               //next element
        
        rootElem = XMLFactory.getInstance().createElement(moduleType);
            
        if (className != null)
        {
            nextElem = XMLFactory.getInstance().createElement(Const.CLASSNAME);
            nextElem.setText(className);
            rootElem.addContent(nextElem);
        }
        
        if (jarFile != null)
        {
            nextElem = XMLFactory.getInstance().createElement(Const.JARFILEXML);
            nextElem.setText(jarFile);
            rootElem.addContent(nextElem);
        }
        
        if (policy != null)
        {
            if (policy.getName().equals(MetaConst.POLICY))
            {
                rootElem.addContent(policy);
            }
            else
            {
                nextElem = XMLFactory.getInstance().createElement(MetaConst.POLICY);
                nextElem.addContent(policy);
                rootElem.addContent(nextElem);
            }
        }
        
        return rootElem;
    }
    
    /**
     * Create an XML element that can be used as part of a script to define a data resource. 
     * This would be the admin script {@code Data} section and it stores a 
     * description of a data type, value and specific action. It is used to initialise 
     * an {@code InformationService} class, for example. The related {@code Resource} object that 
     * stores and retrieves the information gets created from it and might be a best 
     * match guess. If the action is known, then the resource can perform a different
     * type of storage, for example.
     * The returned value is {@code <Data><DataType>dataType</DataType><Value>String or XML infoData</Value>
     * <ActionType>actionType</ActionType></Data>}.
     * @param dataType the data type of the value, or its class name.
     * @param infoData the data itself, can be a String or XML element.
     * @param actionType the type of action to take, if it is an option.
     * @return an XML element that defines the service to load.
     * @throws java.lang.Exception any error.
     */
    public Element createDataAction(String dataType, Object infoData, String actionType) 
            throws Exception
    {
        Element rootElem;                               //root element
        Element nextElem;                               //next element
        
        rootElem = XMLFactory.getInstance().createElement(Const.DATA);
        nextElem = XMLFactory.getInstance().createElement(Const.DATATYPE);
        nextElem.setText(dataType);
        rootElem.addContent(nextElem);
        
        if (infoData != null)
        {
            nextElem = XMLFactory.getInstance().createElement(Const.VALUE);
            if (infoData instanceof Element)
                nextElem.addContent((Element)infoData);
            else
                nextElem.setText(ObjectHandler.getValue(infoData));

            rootElem.addContent(nextElem);
        }
        
        if (actionType != null)
        {
            nextElem = XMLFactory.getInstance().createElement(AiConst.ACTION);
            nextElem.setText(actionType);
            rootElem.addContent(nextElem);
        }
        
        return rootElem;
    }
    
    /**
     * Create an XML element that can be used as part of an admin script to initialise a
     * service that is used with the problem solving classes. The variable input is simple
     * a list of variable types with values, rather like a properties file. Each key-value
     * pair is then made into an XML element and added to a root {@code MetaConst.AISOLVER} element.
     * @param typeValue the variable list. Key is variable name and value is variable value,
     * both of type String.
     * @return an XML element that defines the initialisation parameters.
     */
    public Element createSolver(HashMap<String, String> typeValue)
    {
        String nextValue;                               //next value
        Element rootElem;                               //root element
        Element nextElem;                               //next element
        
        rootElem = XMLFactory.getInstance().createElement(AiConst.AISOLVER);
        
        for (String key: typeValue.keySet())
        {
            nextValue = typeValue.get(key);
            if (nextValue != null) {
                nextElem = XMLFactory.getInstance().createElement(key);
                nextElem.setText(nextValue);
                rootElem.addContent(nextElem);
            }
        }
        
        return rootElem;
    }
}
