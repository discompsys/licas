/*
 * JarFactoryInfo.java
 *
 * Created on 1 May 2012
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.meta.model;


import java.io.File;


/**
 * Stores information for a default jar factory.
 * @author Kieran Greer
 */
public class JarFactoryInfo 
{
    /** The path to the jar factory jar file */
    public String jarFilePath;
    
    /** The class to load for the default jar factory */
    public String factoryClass;
    
    /** True if create an instance of the jar factory */
    public boolean start;
    
    /**
     * Create a new instance of JarFactoryInfo.
     */
    public JarFactoryInfo()
    {
        jarFilePath = null;
        factoryClass = null;
        start = true;
    }
    
    /**
     * Convert this info object into a ModuleInfo type, with information added as
     * appropriate. If there is no file path in this info object, then return null.
     * @return the created module info, or null if the jar file is missing.
     */
    public ModuleInfo toModuleInfo()
    {
        ModuleInfo moduleInfo;                  //module info
        
        moduleInfo = null;
        if ((jarFilePath != null) && !jarFilePath.equals(""))
        {
            moduleInfo = new ModuleInfo();
            moduleInfo.moduleName = (new File(jarFilePath)).getName();
            moduleInfo.filePath = jarFilePath;
        }
        
        return moduleInfo;
    }
}
