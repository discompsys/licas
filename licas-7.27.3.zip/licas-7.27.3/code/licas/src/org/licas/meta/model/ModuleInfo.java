/*
 * ModuleInfo.java
 *
 * Created on 6 February 2012
 *
 * Version 1.2.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.meta.model;

import org.licas.util.classloader.LoadObject;

import java.util.ArrayList;


/**
 * This stores information on a single module reference.
 * @author Kieran Greer
 */
public class ModuleInfo 
{
    /** True if include the module in the current list */
    public boolean include;
    
    /** 
     * The time since 1 January 1970 UTC in milliseconds when the module was added.
     * {@code System.currentTimeMillis()} - this is set automatically during the ModuleInfo initialisation.
     */
    public long timeStamp;
    
    /** The jar file name to represent the module */
    public String moduleName;
    
    /** The full path to the module jar file */
    public String filePath;
    
    /** Third party jar files that this module requires */
    public ArrayList<String> tpJars;
    
    
    /** Create a new instance of ModuleInfo */
    public ModuleInfo()
    {
        include = true;
        timeStamp = System.currentTimeMillis();
        moduleName = null;
        filePath = null;
        tpJars = new ArrayList<>();
    }
    
    /**
     * Convert the stored files paths into a list of jar files paths for loading.
     * @return the list of jar file paths.
     * @throws java.lang.Exception any error.
     */
    public ArrayList<String> filesToJars() throws Exception
    {
        int i;
        String jarUri;                          //jar file path
        ArrayList<String> allJars;              //all jar file paths
        
        allJars = new ArrayList<>();
        jarUri = LoadObject.addJarPrefix(filePath);
        allJars.add(jarUri);
        
        if (tpJars != null) {
            for (i = 0; i < tpJars.size(); i++)
            {
                jarUri = LoadObject.addJarPrefix(tpJars.get(i));
                allJars.add(jarUri);
            }
        }
        
        return allJars;
    }
}
