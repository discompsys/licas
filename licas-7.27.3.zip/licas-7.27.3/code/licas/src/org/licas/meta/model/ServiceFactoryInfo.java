/*
 * ServiceFactoryInfo.java
 *
 * Created on 31 January 2012
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.meta.model;


import java.io.File;


/**
 * Stores information for a default service factory.
 * @author Kieran Greer
 */
public class ServiceFactoryInfo 
{
    /** The path to the service factory jar file */
    public String jarFilePath;
    
    /** The class to load for the default service factory */
    public String factoryClass;
    
    /**
     * Create a new instance of ServiceFactoryInfo.
     */
    public ServiceFactoryInfo()
    {
        jarFilePath = null;
        factoryClass = null;
    }
    
    /**
     * Convert this info object into a ModuleInfo type, with information added as
     * appropriate. If there is no file path in this info object, then return null.
     * @return the created module info, or null if the jar file is missing.
     */
    public ModuleInfo toModuleInfo()
    {
        ModuleInfo moduleInfo;                  //module info
        
        moduleInfo = null;
        if ((jarFilePath != null) && !jarFilePath.equals(""))
        {
            moduleInfo = new ModuleInfo();
            moduleInfo.moduleName = (new File(jarFilePath)).getName();
            moduleInfo.filePath = jarFilePath;
        }
        
        return moduleInfo;
    }
}
