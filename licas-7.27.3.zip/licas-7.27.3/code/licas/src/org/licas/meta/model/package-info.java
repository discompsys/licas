/**
 * Models the metadata used to define instances of specific metadata types.
 */
package org.licas.meta.model;