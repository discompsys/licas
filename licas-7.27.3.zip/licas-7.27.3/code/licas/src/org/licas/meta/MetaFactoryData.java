
/*
 * MetaFactoryData.java
 *
 * Created on 9 April 2014.
 *
 * Version 1.3.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.meta;


import org.licas.util.Const;
import org.licas.util.ObjectHandler;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.util.ArrayList;
import java.util.Vector;


/**
 * This class can create metadata parts that can be used to define data descriptions.
 * @author Kieran Greer
 */
public class MetaFactoryData 
{
    /** Create a new instance of MetaFactoryData */
    public MetaFactoryData()
    {}
    
    /**
     * Create a root Resource Container XML element that can be used as the base of a 
     * script to describe resources to load. It can then be populated with other elements. 
     * This method creates an admin script with just a root element, as in 
     * {@code <Data><DataType>containerType</DataType><Value></Value></Data>}. 
     * You can then add resources to it, for example, by calling 
     * {@code addToContainer(containerXml, createDataTypeValueXml(type, urlPath)}. 
     * Construct this way, because the single resource descriptions
     * should be placed inside of the container's {@code Value} element.
     * @param containerType the type of container to create.
     * @return an XML element that defines the service to load.
     */
    public Element createResourceContainer(String containerType)
    {
        Element rootElem;                               //root element
        Element nextElem;                               //next element
        
        rootElem = XMLFactory.getInstance().createElement(Const.DATA);
        nextElem = XMLFactory.getInstance().createElement(Const.DATATYPE);
        nextElem.setText(containerType);
        rootElem.addContent(nextElem);
        nextElem = XMLFactory.getInstance().createElement(Const.VALUE);
        rootElem.addContent(nextElem);
        
        return rootElem;
    }
    
    /**
     * Add the new XML element to the admin document/script under the appropriate element type.
     * @param scriptXml the current admin document/script. Can use {@code createAdminXML} 
     * to create an empty admin document, for example.
     * @param toAdd the XML element to add to the script.
     * @return true if added, false otherwise.
     */
    public boolean addToContainer(Element scriptXml, Element toAdd)
    {
        return addToContainer(scriptXml, toAdd, null);
    }
    
    /**
     * Add the new XML element to the admin document/script under the appropriate element type.
     * @param scriptXml the current admin document/script. Can use {@code createAdminXML} 
     * to create an empty admin document, for example.
     * @param toAdd the XML element to add to the script.
     * @param resourceID if not null, then a UUID field is added to the {@code toAdd}
     * description and used as the unique resource id.
     * @return true if added, false otherwise.
     */
    public boolean addToContainer(Element scriptXml, Element toAdd, String resourceID)
    {
        Element valueElem;                              //root element
        
        if ((scriptXml != null) && (toAdd != null)) {
            if (resourceID != null) {
                toAdd.setAttribute(Const.UUID, resourceID);
            }
            
            valueElem = scriptXml.getChild(Const.VALUE);
            if (valueElem != null) {
                valueElem.addContent(toAdd);
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Create an XML element that can be used as part of a script to define a data resource. 
     * This would be the admin script {@code Data} section and it stores a 
     * description of a data type and value. The returned value is 
     * {@code <Data><DataType>dataType</DataType><Value>infoData</Value></Data>}
     * @param dataType the data type of the value. Its class name.
     * @param infoData the data itself. If null, only the type is added.
     * @return an XML element that defines the service to load.
     * @throws java.lang.Exception any error.
     */
    public Element createDataTypeValue(String dataType, String infoData) throws Exception
    {
        Element rootElem;                               //root element
        Element nextElem;                               //next element

        rootElem = XMLFactory.getInstance().createElement(Const.DATA);
        nextElem = createDataValue(dataType, infoData);
        rootElem.addContent(nextElem);

        if (dataType != null) {
            nextElem = XMLFactory.getInstance().createElement(Const.DATATYPE);
            nextElem.setText(dataType);
            rootElem.addContent(nextElem);
        }

        return rootElem;
    }
    
    /**
     * Create an XML element that can be used as part of a script to define a data resource. 
     * This would be the admin script {@code Data} section and it stores a 
     * description of a data type and value. The returned value is 
     * {@code <Data><DataType>dataType</DataType><Value><XML infoData></Value></Data>}
     * @param dataType the data type of the value. Its class name.
     * @param infoData the data itself. If null, only the type is added.
     * @return an XML element that defines the service to load.
     * @throws java.lang.Exception any error.
     */
    public Element createDataTypeValue(String dataType, Element infoData) throws Exception
    {
        Element rootElem;                               //root element
        Element nextElem;                               //next element
        
        rootElem = createDataValue(dataType, infoData);
        if (dataType != null) {
            nextElem = XMLFactory.getInstance().createElement(Const.DATATYPE);
            nextElem.setText(dataType);
            rootElem.addContent(nextElem);
        }
        
        return rootElem;
    }
    
    /**
     * Create an XML element that can be used as part of a script to define a data resource. 
     * This would be the admin script {@code Data} section and it stores a 
     * description of a data type and value. The returned value is 
     * {@code <Data><DataType>dataType</DataType><Value>infoData1</Value><Value>infoData2</Value></Data>}
     * @param dataType the data type of the value. Its class name.
     * @param infoData the data itself. This list should be either XML elements or simple
     * types that can be converted directly to Strings. If null, only the type is added.
     * @return an XML element that defines the service to load.
     * @throws java.lang.Exception any error.
     */
    public Element createDataTypeValue(String dataType, ArrayList<?> infoData) throws Exception
    {
        int i;
        Element rootElem;                               //root element
        Element nextElem;                               //next element

        rootElem = XMLFactory.getInstance().createElement(Const.DATA);
        if (infoData != null) {
            for (i = 0; i < infoData.size(); i++)
            {
                nextElem = createDataValue(dataType, infoData.get(i));
                rootElem.addContent(nextElem);
            }
        }

        if (dataType != null) {
            nextElem = XMLFactory.getInstance().createElement(Const.DATATYPE);
            nextElem.setText(dataType);
            rootElem.addContent(nextElem);
        }
        
        return rootElem;
    }
    
    /**
     * Create an XML element that can be used as part of a script to define a data resource. 
     * This would be the admin script {@code Data} section and it stores a 
     * description of a data value only. The returned value is 
     * {@code <Data><Value>String or XML infoData</Value></Data>}
     * @param dataType the data type of the value - its class name. This might be required
     * for serializing the data object into a string, but is not added to the script.
     * Use {@code createDataValueTypeXML} for that.
     * @param infoData the data itself. This can be a String, XML element, or simple
     * type that can be converted directly to a String.
     * @return an XML element that defines the service to load.
     * @throws java.lang.Exception any error.
     */
    protected Element createDataValue(String dataType, Object infoData) throws Exception
    {
        Element rootElem;                               //root element
        Object infoObj;                                 //info object

        rootElem = XMLFactory.getInstance().createElement(Const.VALUE);
        if (infoData != null) {
            infoObj = ObjectHandler.convertParameter(infoData);

            if (ObjectHandler.isElement(infoObj)) {
                rootElem.addContent((Element) infoObj);
            }
            else {
                rootElem.setText(ObjectHandler.valueToString(dataType, infoObj));
            }
        }
        
        return rootElem;
    }
    
    /**
     * Parse the data element type from the service info data description.
     * @param dataXml this is the base data or dataset element with nested elements that include
     * directly, {@link Const}.{@code DATATYPE} or {@code DATASETTYPE}, plus a {@code VALUE} 
     * elements for parsing. If they are missing, a {@code convertParameter} call is 
     * tried on the whole XML object.
     * @return the data type value if the XML element is in the correct format, or
     * null otherwise.
     * @throws java.lang.Exception any error.
     */
    public String getDataType(Element dataXml) throws Exception
    {
        String dataType;                                //the data type
        Element nextElem;                               //next element
        
        dataType = null;
        nextElem = dataXml.getChild(Const.DATATYPE);

        if (nextElem != null) {
            dataType = nextElem.getText();
        }
        else {
            nextElem = dataXml.getChild(Const.DATASETTYPE);
            if (nextElem != null) {
                dataType = nextElem.getText();
            }
        }

        return dataType;
    }
    
    /**
     * Set the data element type from the service info data description.
     * @param dataType the new data type to set the value to.
     * @param dataXml this is the base data or dataset element with nested elements that include
     * directly, {@link Const}.{@code DATATYPE} or {@code DATASETTYPE} elements for parsing.
     * @return true if the element exists and the value was set, false otherwise.
     */
    public boolean setDataType(String dataType, Element dataXml)
    {
        Element nextElem;                               //next element
        
        nextElem = dataXml.getChild(Const.DATATYPE);
        if (nextElem != null) {
            nextElem.setText(dataType);
            return true;
        }
        else {
            nextElem = dataXml.getChild(Const.DATASETTYPE);
            if (nextElem != null) {
                nextElem.setText(dataType);
                return true;
            }
        }

        return false;
    }
    
    /**
     * Parse the root element and store all text content for it and any nested elements.
     * @param rootElem the root element to parse from.
     * @return a full concatenated description of the text content.
     */
    public String innerText(Element rootElem)
    {
        int i;
        StringBuilder innerTxt;                     //inner text
        String nextTxt;                             //next text
        Element nextElem;                           //next element
        Vector<Node> elemList;                      //element list
        
        innerTxt = new StringBuilder();
        nextTxt = rootElem.getText();

        if ((nextTxt != null) && !nextTxt.equals("")) {
            innerTxt.append("\n").append(nextTxt);
        }
        
        elemList = rootElem.getChildren();
        for (i = 0; i < elemList.size(); i++)
        {
            nextElem = (Element)elemList.get(i);
            innerTxt.append("\n").append(innerText(nextElem));
        }
        
        return innerTxt.toString().trim();
    }
}
