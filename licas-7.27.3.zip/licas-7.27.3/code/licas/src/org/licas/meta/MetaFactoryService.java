/*
 * MetaFactoryService.java
 *
 * Created on 21 April 2014
 *
 * Version 1.4.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.meta;


import org.licas.AdminInfo;
import org.licas.Service;
import org.licas.parsers.Parsers;
import org.licas.parsers.admin.AdminParser;
import org.licas.util.Const;
import org.licas.util.MetaConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;


/**
 * This class can create metadata parts that can be used to define the service metadata
 * as it is stored and defined on the server.
 * @author Kieran Greer
 */
public class MetaFactoryService 
{
    /**
     * Create an Admin script that can be used to initialise a service with. 
     * This method creates an admin script, as in {@code <Admin></Admin>} and populates
     * it with the field values of the {@code AdminInfo} object.
     * @param adminInfo an admin document with values to initialise a service with.
     * @return an XML element that defines the service to load.
     * @throws java.lang.Exception any error.
     */
    public static Element createAdmin(AdminInfo adminInfo) throws Exception
    {
        Element rootElem;                           //root element
        AdminParser adminParser;                    //admin info parser
        
        adminParser = new AdminParser();
        rootElem = adminParser.serialize(adminInfo);
        
        return rootElem;
    }
    
    /**
     * Add an {@code Const.UUID} attribute to the base XML element. This will overwrite 
     * any existing attribute.
     * @param xmlElem the element to add the attribute to.
     * @param uuidValue the value of the uuid.
     */
    public static void addUUIDAttribute(Element xmlElem, String uuidValue)
    {
        MetaFactory.addAttribute(xmlElem, Const.UUID, uuidValue);
    }
    
    /**
     * Create an XML element that can be used as part of a script to define a
     * service to dynamically create and load into another one. This is for a single 
     * service instance only and should be added to another script XML section - 
     * {@link Const}.{@code SERVICESTOLOAD}, for example - see the admin user guide.
     * @param serviceUuid the service uuid.
     * @param serviceType the service type.
     * @param serviceClass the service classname.
     * @param jarFiles a list of required jar files.
     * @param params list of constructor parameters for the service. Can be of
     * a simple type, like String, Integer or an XML Element and the service must 
     * know what they represent.
     * {@code <serviceType Name="serviceUUID"><Class_Name>serviceClass</Class_Name>
     * <Jar_Files><Jar_File>Jar file path</Jar_File></Jar_Files>
     * <Ps><Param>String or XML param</Param></Ps></serviceType>}
     * @return an XML element that defines the service to load.
     */
    public Element createLoadService(String serviceUuid, String serviceType, 
            String serviceClass, ArrayList<String> jarFiles, ArrayList<Object> params)
    {
        int i;
        Element rootElem;                               //root element
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        Object nextParam;                               //next parameter
        
        if (jarFiles == null) jarFiles = new ArrayList();
        rootElem = XMLFactory.getInstance().createElement(serviceType);
        rootElem.setAttribute(Const.NAME, serviceUuid);
        nextElem = XMLFactory.getInstance().createElement(Const.CLASSNAME);
        nextElem.setText(serviceClass);
        rootElem.addContent(nextElem);

        nextElem = XMLFactory.getInstance().createElement(Const.JARFILESXML);
        rootElem.addContent(nextElem);

        for (i = 0; i < jarFiles.size(); i++)
        {
            nextElem2 = XMLFactory.getInstance().createElement(Const.JARFILEXML);
            nextElem2.setText((String)jarFiles.get(i));
            nextElem.addContent(nextElem2);
        } 
        
        nextElem = XMLFactory.getInstance().createElement(Const.PARAMETERS);
        rootElem.addContent(nextElem);

        for (i = 0; i < params.size(); i++)
        {
            nextParam = params.get(i);
            nextElem2 = XMLFactory.getInstance().createElement(Const.PARAMETER);
            if (nextParam instanceof Element) nextElem2.addContent((Element)nextParam);
            else nextElem2.setText(String.valueOf(nextParam));
            nextElem.addContent(nextElem2);
        }
        
        return rootElem;
    }
    
    /**
     * Add a new instance value to the instance values section. Create the section first
     * if it is missing.
     * @param valuesXml the instance values section. If null it is created first.
     * @param varName the name of the variable, as written in the class.
     * @param varInstance the actual instance to serializeToString. This will also check if
     * the parser is present for a complex object.
     * {@code <Instance_Values><Instance_Value Name="variableName"><Object_Type Ct="class_type">
     * <Object_Variable>Serialized code</Object_Variable></Object_Type></Instance_Value>
     * </Instance_Values>}
     * @return an XML element that defines the service to load.
     * @throws java.lang.Exception any error.
     */
    public Element createAddInstanceValue(Element valuesXml, String varName, 
            Object varInstance) throws Exception
    {
        Element rootElem;                       //root element
        Element nextElem;                       //next element
        Element paramElem;                      //parameter element
        Element valueElem;                      //value element
        Object elemObj;                         //element or object
        
        if (valuesXml == null) {
            valuesXml = MetaFactory.createMeta(Const.INSTANCEVALUES);
        }
        
        rootElem = XMLFactory.getInstance().createElement(Const.INSTANCEVALUE);       
        rootElem.setAttribute(Const.NAME, varName);
        
        elemObj = Parsers.serializeToElement(varInstance);
        if (elemObj != null) {
            nextElem = (Element)elemObj;
            
            //if parsed parameter element then convert
            if (nextElem.getName().equals(Const.PARAMETERS)) {
                nextElem.setName(Const.OBJECT);
                paramElem = nextElem.getChild(Const.PARAMETER);
                paramElem.detach();
                
                valueElem = paramElem.getChild(Const.VALUE);
                if (valueElem.hasChildren()) {
                    nextElem.addContent(valueElem.getElementChildAtIndex(0));
                }
                else {
                    nextElem.setValue(valueElem.getValue());
                }
            }
        }
        else {
            //need to create the element manually
            elemObj = Parsers.serializeToString(varInstance);
            if (elemObj == null) elemObj = Const.NULL;
            nextElem = XMLFactory.getInstance().createElement(Const.OBJECT);               
            nextElem.setValue((String)elemObj);
        }
        
        MetaFactory.parsedObjTypeAttr(nextElem, varInstance.getClass().getName());
        rootElem.addContent(nextElem);
        valuesXml.addContent(rootElem);
        
        return valuesXml;
    }
    
    /**
     * Add a new instance value to the instance values section. Create the section first
     * if it is missing.
     * @param valuesXml the instance values section. If null it is created first.
     * @param varName the name of the variable, as written in the class.
     * @param varType only add the variable type and leave the value missing. This is
     * then used for later serializations, when the value gets added.
     * {@code <Instance_Values><Instance_Value Name="variableName"><Object_Type Ct="class_type">
     * </Object_Type></Instance_Value></Instance_Values>}
     * @return an XML element that defines the service to load.
     */
    public Element createAddInstanceValue(Element valuesXml, String varName, 
            Class varType)
    {
        Element rootElem;                               //root element
        Element nextElem;                               //next element
        
        if (valuesXml == null) {
            valuesXml = MetaFactory.createMeta(Const.INSTANCEVALUES);
        }
        
        rootElem = XMLFactory.getInstance().createElement(Const.INSTANCEVALUE);       
        rootElem.setAttribute(Const.NAME, varName);
        
        nextElem = XMLFactory.getInstance().createElement(Const.OBJECT);               
        MetaFactory.parsedObjTypeAttr(nextElem, varType.getName());
        rootElem.addContent(nextElem);
        valuesXml.addContent(rootElem);
        
        return valuesXml;
    }
    
    /**
     * Create a list of variable names to be serialized as the service object.
     * @param varNames the list of variables to serialize.
     * @param includeAdmin if true add a {@link MetaConst}.{@code ADMIN} value to
     * indicate to include the admin document information. If true, some
     * admin fields are automatically removed, for safety reasons.
     * @return an XML element that defines the serialized variable list.
     */
    public Element createSerialize(ArrayList varNames, boolean includeAdmin)
    {
        ArrayList<String> toRemove;                 //element to remove
        
        toRemove = Service.defaultAdminToRemove();        
        return createSerialize(varNames, includeAdmin, toRemove);
    }
    
    /**
     * Create a list of variable names to be serialized as the service object.
     * @param varNames the list of variables to serialize.
     * @param includeAdmin if true add a {@link MetaConst}.{@code ADMIN} value to
     * indicate to include the admin document information.
     * @param toRemove if any admin section is indicated here through the XML tag name, 
     * it is removed first. If included, {@code includeAdmin} must also be true.
     * @return an XML element that defines the serialized variable list.
     */
    public Element createSerialize(ArrayList<String> varNames, boolean includeAdmin, ArrayList<String> toRemove)
    {
        int i;
        String varName;                                 //var name
        Element rootElem;                               //root element
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        
        rootElem = XMLFactory.getInstance().createElement(Const.SERIALISEVALUES);
        if (includeAdmin) {
            nextElem = XMLFactory.getInstance().createElement(Const.SERIALISEVALUE);
            nextElem.setAttribute(Const.NAME, MetaConst.ADMIN);
            rootElem.addContent(nextElem);
            
            for (i = 0; i < toRemove.size(); i++)
            {
                varName = toRemove.get(i);
                nextElem2 = XMLFactory.getInstance().createElement(Const.VALUE);
                nextElem2.setAttribute(Const.NAME, varName);
                nextElem.addContent(nextElem2);
            }
        }
        for (i = 0; i < varNames.size(); i++)
        {
            varName = varNames.get(i);
            nextElem = XMLFactory.getInstance().createElement(Const.SERIALISEVALUE);
            nextElem.setAttribute(Const.NAME, varName);
            rootElem.addContent(nextElem);
        }
        
        return rootElem;
    }
    
    /**
     * Get the element representing the meta type for an XML description of a server.
     * @param serverXml a description of the server, probably a {@link Const}.{@code SERVER} element.
     * @param metaType the type of meta to find. Can the the server path {@link Const}.{@code HANDLE} or
     * the server password {@link Const}.{@code META}.
     * @return the element if it is present, or null otherwise.
     */
    public Element serverMeta(Element serverXml, String metaType)
    {
        Element metaXml;                                //meta xml
        Element metaElem;                               //meta element
        
        metaElem = null;
        if (serverXml.getName().equals(Const.SERVER)) {
            if (metaType.equals(MetaConst.PASSWORD) ||
                metaType.equals(Const.SERVICEKEY) &&
                !serverXml.getName().equals(Const.PASSWORDS)) {
                metaXml = serverXml.getChild(Const.PASSWORDS);
            }
            else {
                metaXml = serverXml;
            }
            
            if (metaXml != null) {
                metaElem = metaXml.getChild(metaType);
                if (metaElem != null) {
                    metaElem = (Element)metaElem.clone();
                }
            }
        }
        
        return metaElem;
    }

    /**
     * Return true if the comm ID is coded as a service comm ID.
     * @param commID the communication id.
     * @return true if ends with the service code.
     */
    public boolean isServiceComm(String commID) {
        return commID.endsWith(String.valueOf(":" + Const.SERVICE));
    }

    /**
     * Return true if the comm ID is coded as a fault comm ID.
     * @param commID the communication id.
     * @return true if ends with the fault code.
     */
    public boolean isFaultComm(String commID) {
        return commID.endsWith(String.valueOf(":" + MetaConst.FAULT));
    }

    /**
     * Convert the comm ID into a service comm ID.
     * @param commID the communication id to convert.
     * @return the comm ID with the service code at the end.
     */
    public String asServiceComm(String commID) {
        return (commID + ":" + Const.SERVICE);
    }

    /**
     * Convert the comm ID into a fault comm ID.
     * @param commID the communication id to convert.
     * @return the comm ID with the fault code at the end.
     */
    public String asFaultComm(String commID) {
        return (commID + ":" + MetaConst.FAULT);
    }
}
