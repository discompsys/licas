/**
 * Stores the metadata used by the system, to understand what information each service has, including factory objects to help create metadata descriptions and some base classes.
 */
package org.licas.meta;