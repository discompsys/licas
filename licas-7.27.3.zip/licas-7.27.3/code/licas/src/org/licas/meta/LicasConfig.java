/*
 * LicasConfig.java
 *
 * Created on 28 October 2011
 *
 * Version 1.12.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.meta;


import org.ai_heuristic.model.FactoryInfo;
import org.jlog2.util.FileLoader;
import org.licas.Service;
import org.licas.meta.model.JarFactoryInfo;
import org.licas.meta.model.ModuleInfo;
import org.licas.meta.model.ServiceFactoryInfo;
import org.licas.meta.model.ServiceModuleInfo;
import org.licas.security.SecurityWebManager;
import org.licas.server.model.ServerConfig;
import org.licas.service.DataService;
import org.licas.util.ServiceConst;
import org.licas.util.classloader.LoadObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;


/**
 * This stores all licas configuration information, including service types with
 * their related GUI class name.
 * @author Kieran Greer
 */
public class LicasConfig 
{
    /** The server config details */
    private ServerConfig serverConfig;
    
    /** True if allow class-loading from external jars in this GUI, false otherwise. */
    private boolean extJars;
    
    /** True if show the scientific panels, false otherwise. */
    private boolean scientific;
    
    /** The timeout for a remote method call */
    private int timeout;
    
    /** The graphic horizontal gap factor */
    private int hGapFactor;
    
    /** The graphic vertical gap factor */
    private int vGapFactor;
    
    /** The graphic depth to draw network levels to */
    private int maxNetworkDepth;
    
    /** The graphic maximum number of nodes to draw */
    private int maxNodes;
    
    /** The graphic re-draw delay */
    private int redrawDelay;
    
    
    /** The default service factory */
    private static final ServiceFactoryInfo defaultServiceFactory;
    
    /** The default jar factory */
    private static final JarFactoryInfo defaultJarFactory;
    
    /**
     * References to external module jar files. 
     * Key is the module name and value is of type {@link ModuleInfo}.
     */
    private static final HashMap<String, ModuleInfo> modules;
    
    /**
     * List of default services to load at startup time from this module.
     * Key is the service type and value is of type {@link ServiceModuleInfo}.
     */
    private static final HashMap<String, ServiceModuleInfo> defaultServices;
    
    /** 
     * List of service classes that are for any arbitrary type of use. 
     * This can include loading parsers for complex objects.
     * Key is the service function and value is a hashtable of the related classes. 
     * Key there is the service type and value is a of type {@link FactoryInfo}.
     */
    private static final HashMap<String, HashMap<String, FactoryInfo>> serviceClasses;
    
    
    static
    {
        modules = new HashMap<>();
        serviceClasses = new HashMap<>();
        defaultServices = new HashMap<>();
        
        defaultServiceFactory = new ServiceFactoryInfo();
        defaultJarFactory = new JarFactoryInfo();
    }
    
    /** Create a new instance of LicasConfig */
    public LicasConfig()
    {
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        extJars = true;
        scientific = false;
        timeout = 10000;
        hGapFactor = 10;
        vGapFactor = 5;
        maxNetworkDepth = 5;
        maxNodes = 220;
        redrawDelay = 60;
        
        serverConfig = new ServerConfig();
        SecurityWebManager.getInstance();
        addDefaultGUIs();
    }
    
    /** Add default gui interfaces */
    private void addDefaultGUIs()
    {
        HashMap<String, FactoryInfo> classTypes;        //class types
        FactoryInfo guiInfo;                            //gui info
        
        //add default service interfaces
        classTypes = new HashMap<>();
        guiInfo = new FactoryInfo();
        guiInfo.serviceType = ServiceConst.MESSAGE;
        guiInfo.serviceCategory = ServiceConst.ALLCATEGORIES;
        guiInfo.className = "org.licas.service.gui.MessageServiceJFrame";
        guiInfo.filePath.add(ServiceConst.SERVICESDIR + "licas_services.jar");
        classTypes.put(guiInfo.serviceType, guiInfo);
        guiInfo = new FactoryInfo();
        guiInfo.serviceType = ServiceConst.FILE;
        guiInfo.serviceCategory = ServiceConst.ALLCATEGORIES;
        guiInfo.className = "org.licas.service.gui.FileServiceJFrame";
        guiInfo.filePath.add(ServiceConst.SERVICESDIR + "licas_services.jar");
        classTypes.put(guiInfo.serviceType, guiInfo);
        guiInfo = new FactoryInfo();
        guiInfo.serviceType = ServiceConst.WEBSERVICE;
        guiInfo.serviceCategory = ServiceConst.ALLCATEGORIES;
        guiInfo.className = "org.licas.service.gui.WebServiceJFrame";
        guiInfo.filePath.add(ServiceConst.SERVICESDIR + "licas_services.jar");
        classTypes.put(guiInfo.serviceType, guiInfo);
        guiInfo = new FactoryInfo();
        guiInfo.serviceType = ServiceConst.INFORMATION;
        guiInfo.serviceCategory = ServiceConst.ALLCATEGORIES;
        guiInfo.className = "org.licas.service.gui.InformationServiceJFrame";
        guiInfo.filePath.add(ServiceConst.SERVICESDIR + "licas_services.jar");
        classTypes.put(guiInfo.serviceType, guiInfo);
        guiInfo = new FactoryInfo();
        guiInfo.serviceType = ServiceConst.FEED;
        guiInfo.serviceCategory = ServiceConst.ALLCATEGORIES;
        guiInfo.className = "org.licas.service.gui.FeedServiceJFrame";
        guiInfo.filePath.add(ServiceConst.SERVICESDIR + "licas_services.jar");
        classTypes.put(guiInfo.serviceType, guiInfo);
        guiInfo = new FactoryInfo();
        guiInfo.serviceType = ServiceConst.EMAIL;
        guiInfo.serviceCategory = ServiceConst.ALLCATEGORIES;
        guiInfo.className = "org.licas.service.gui.EmailServiceJFrame";
        guiInfo.filePath.add(ServiceConst.SERVICESDIR + "licas_services.jar");
        classTypes.put(guiInfo.serviceType, guiInfo);
        guiInfo = new FactoryInfo();
        guiInfo.serviceType = ServiceConst.DATAHUB;
        guiInfo.serviceCategory = ServiceConst.ALLCATEGORIES;
        guiInfo.className = "org.licas.service.gui.DataHubJFrame";
        guiInfo.filePath.add(ServiceConst.SERVICESDIR + "licas_services.jar");
        classTypes.put(guiInfo.serviceType, guiInfo);
        guiInfo = new FactoryInfo();
        guiInfo.serviceType = ServiceConst.BEHAVIOURMEDIATOR;
        guiInfo.serviceCategory = ServiceConst.ALLCATEGORIES;
        guiInfo.className = "org.licas.service.gui.BehaviourMediatorJFrame";
        guiInfo.filePath.add(ServiceConst.SERVICESDIR + "licas_services.jar");
        classTypes.put(guiInfo.serviceType, guiInfo);
        guiInfo = new FactoryInfo();
        guiInfo.serviceType = ServiceConst.MESSAGEBOARD;
        guiInfo.serviceCategory = ServiceConst.ALLCATEGORIES;
        guiInfo.className = "org.licas.service.gui.MessageBoardJFrame";
        guiInfo.filePath.add(ServiceConst.SERVICESDIR + "licas_services.jar");
        classTypes.put(guiInfo.serviceType, guiInfo);

        serviceClasses.put(ServiceConst.GUI, classTypes);
    }
    
    /**
     * Return true if the service type is included.
     * @param serviceFunction the function of the class.
     * @param serviceType the service type to check.
     * @return true if the service type is saved with a related function class.
     */
    public boolean containsServiceType(String serviceFunction, String serviceType)
    {
        HashMap<String, FactoryInfo> classTypes;            //class types
        
        if (serviceClasses.containsKey(serviceFunction)) {
            classTypes = serviceClasses.get(serviceFunction);
            return classTypes.containsKey(serviceType);
        }
        
        return false;
    }

    /**
     * Return if the service type already has an associated class for the specified
     * function.
     * @param serviceFunction the function to check for.
     * @param serviceType the type of service to check for.
     * @return true if a GUI interface already exists, false otherwise.
     */
    public boolean serviceHasGui(String serviceFunction, String serviceType)
    {
        HashMap<String, FactoryInfo> classTypes;            //class types

        if (serviceClasses.containsKey(serviceFunction))
        {
            classTypes = serviceClasses.get(serviceFunction);
            return classTypes.containsKey(serviceType);
        }

        return false;
    }

    /**
     * Set the allow external class-loaders option.
     * @param theExtJars true if allow external jar loaders.
     */
    public void setExternalJars(boolean theExtJars)
    {
        extJars = theExtJars;
    }
    
    /**
     * Get the value indicating if allow external class-loaders.
     * @return the value of extJars.
     */
    public boolean getExternalJars()
    {
        return extJars;
    }
    
    /**
     * Set the show scientific panels option.
     * @param theScientific true if show scientific panels.
     */
    public void setScientific(boolean theScientific)
    {
        scientific = theScientific;
    }
    
    /**
     * Get the value indicating to show the scientific panels.
     * @return the value of scientific.
     */
    public boolean getScientific()
    {
        return scientific;
    }
    
    /**
     * Set the time allowed for remote method calls in milliseconds.
     * @param theTimeout the timeout value.
     */
    public void setTimeout(int theTimeout)
    {
        timeout = theTimeout;
    }
    
    /**
     * Get the time allowed for remote method calls, in milliseconds.
     * @return the value of timeout.
     */
    public int getTimeout()
    {
        return timeout;
    }
    
    /**
     * Set the horizontal gap factor for the graphic.
     * @param theHorizGapFactor the horizontal gap factor.
     */
    public void setHorizGapFactor(int theHorizGapFactor)
    {
        hGapFactor = theHorizGapFactor;
    }
    
    /**
     * Get the horizontal gap factor for the network graphic.
     * @return the value of hGapFactor.
     */
    public int getHorizGapFactor()
    {
        return hGapFactor;
    }
    
    /**
     * Set the vertical gap factor for the graphic.
     * @param theVertGapFactor the vertical gap factor.
     */
    public void setVertGapFactor(int theVertGapFactor)
    {
        vGapFactor = theVertGapFactor;
    }
    
    /**
     * Get the vertical gap factor for the network graphic.
     * @return the value of vGapFactor.
     */
    public int getVertGapFactor()
    {
        return vGapFactor;
    }
    
    /**
     * Set the maximum depth that nodes are drawn to.
     * @param theMaxNetworkDepth the maximum network depth.
     */
    public void setMaxNetworkDepth(int theMaxNetworkDepth)
    {
        maxNetworkDepth = theMaxNetworkDepth;
    }
    
    /**
     * Get the maximum depth that nodes are drawn to.
     * @return the value of maxNetworkDepth.
     */
    public int getMaxNetworkDepth()
    {
        return maxNetworkDepth;
    }
    
    /**
     * Set the maximum number of nodes to draw on the graphic.
     * @param theMaxNodes the maximum number of nodes to draw.
     */
    public void setMaxNodes(int theMaxNodes)
    {
        maxNodes = theMaxNodes;
    }
    
    /**
     * Get the maximum number of nodes to draw on the graphic.
     * @return the value of maxNodes.
     */
    public int getMaxNodes()
    {
        return maxNodes;
    }
    
    /**
     * Set the delay time before automatically re-drawing the graphic.
     * @param theRedrawDelay the re-draw delay time, in seconds.
     */
    public void setRedrawDelay(int theRedrawDelay)
    {
        redrawDelay = theRedrawDelay;
    }
    
    /**
     * Get the delay time before automatically re-drawing the network graphic.
     * @return the value of redrawDelay.
     */
    public int getRedrawDelay()
    {
        return redrawDelay;
    }
    
    /**
     * Set the server config details.
     * @param theServerConfig the server config details.
     */
    public void setServerConfig(ServerConfig theServerConfig)
    {
        serverConfig = theServerConfig;
    }
    
    /**
     * Get the server config details.
     * @return the value of serverConfig.
     */
    public ServerConfig getServerConfig()
    {
        return serverConfig;
    }
    
    /**
     * Get the default service factory info.
     * @return the value of defaultServiceFactory.
     */
    public ServiceFactoryInfo getDefaultServiceFactory()
    {
        return defaultServiceFactory;
    }
    
    /**
     * Get the default jar factory info.
     * @return the value of defaultJarFactory.
     */
    public JarFactoryInfo getDefaultJarFactory()
    {
        return defaultJarFactory;
    }
    
    /**
     * Return if the module name with jar postfix is already referenced.
     * @param moduleName the module name only, not the full jar file path.
     * @return true if the module is already references, false otherwise.
     */
    public boolean moduleReferenced(String moduleName)
    {
        return modules.containsKey(moduleName);
    }
    
    /**
     * Get all jar files, either listed with a service or function, or stored in
     * either the services or the modules folders.
     * @return a list of jar file paths.
     * @throws java.lang.Exception any error.
     */
    public ArrayList<String> getAllJarFiles() throws Exception
    {
        int i, j;
        String nextJarFile;                             //next jar file
        String nextDirectory;                           //next directory
        ArrayList<String> jarFilesList;                 //list of jar files
        ArrayList<String> filesList;                    //list of files
        ArrayList<FactoryInfo> factoryInfoList;         //factory info list
        ArrayList serviceList;                          //service list
        ModuleInfo moduleInfo;                          //module info
        ServiceModuleInfo serviceModuleInfo;            //service module info
        FactoryInfo factoryInfo;                        //factory info

        nextDirectory = ServiceConst.SERVICESDIR;
        filesList = FileLoader.getFileList(nextDirectory);
        jarFilesList = new ArrayList<>();

        for (i = 0; i < filesList.size(); i++)
        {
            try {
                nextJarFile = (ServiceConst.SERVICESDIR + filesList.get(i));
                if (LoadObject.isLegalJarFile(nextJarFile)) {
                    nextJarFile = LoadObject.removeJarPrefix(nextJarFile);
                    if (!jarFilesList.contains(nextJarFile)) {
                        jarFilesList.add(nextJarFile);
                    }
                }
            }
            catch (Exception ex) {}
        }
        
        nextDirectory = ServiceConst.MODULESDIR;
        filesList = FileLoader.getFileList(nextDirectory);
        for (i = 0; i < filesList.size(); i++)
        {
            try {
                nextJarFile = (ServiceConst.MODULESDIR + filesList.get(i));
                if (LoadObject.isLegalJarFile(nextJarFile)) {
                    nextJarFile = LoadObject.removeJarPrefix(nextJarFile);
                    if (!jarFilesList.contains(nextJarFile)) {
                        jarFilesList.add(nextJarFile);
                    }
                }
            }
            catch (Exception ex) {}
        }
        
        serviceList = new ArrayList<>(defaultServices.values());
        for (i = 0; i < serviceList.size(); i++)
        {
            serviceModuleInfo = (ServiceModuleInfo)serviceList.get(i);
            try {
                nextJarFile = serviceModuleInfo.filePath.get(0);
                if ((nextJarFile != null) && LoadObject.isLegalJarFile(nextJarFile)) {
                    nextJarFile = LoadObject.removeJarPrefix(nextJarFile);
                    if (!jarFilesList.contains(nextJarFile)) {
                        jarFilesList.add(nextJarFile);
                    }
                }
            }
            catch (Exception ex) {}
        }
        
        serviceList = new ArrayList<>(modules.values());
        for (i = 0; i < serviceList.size(); i++)
        {
            moduleInfo = (ModuleInfo)serviceList.get(i);
            try {
                nextJarFile = moduleInfo.filePath;
                if (LoadObject.isLegalJarFile(nextJarFile)) {
                    nextJarFile = LoadObject.removeJarPrefix(nextJarFile);
                    if (!jarFilesList.contains(nextJarFile)) {
                        jarFilesList.add(nextJarFile);
                    }
                }
            }
            catch (Exception ex) {}
        }
        
        serviceList = new ArrayList<>(serviceClasses.values());
        for (i = 0; i < serviceList.size(); i++)
        {
            factoryInfoList = new ArrayList(((HashMap)serviceList.get(i)).values());
            for (j = 0; j < factoryInfoList.size(); j++)
            {
                factoryInfo = factoryInfoList.get(j);

                if (factoryInfo.hasFilePath()) {
                    try {
                        nextJarFile = factoryInfo.filePath.get(0);
                        if (LoadObject.isLegalJarFile(nextJarFile)) {
                            nextJarFile = LoadObject.removeJarPrefix(nextJarFile);
                            if (!jarFilesList.contains(nextJarFile)) {
                                jarFilesList.add(nextJarFile);
                            }
                        }
                    }
                    catch (Exception ex) {}
                }
            }
        }
        
        return jarFilesList;
    }
    
    /**
     * Get the full jar file path for the specified module name. Default services
     * in the script, for example, only list the module name and not the full path.
     * @param moduleName the jar file name.
     * @return the jar file name with its full path as well.
     */
    private String getJarFile(String moduleName)
    {
        String filePath;                            //jar file path
        ModuleInfo moduleInfo;                      //module info
        
        filePath = null;
        if (modules.containsKey(moduleName)) {
            moduleInfo = modules.get(moduleName);
            filePath = moduleInfo.filePath;
        }

        return filePath;
    }
    
    /**
     * Get the list of all module keys. If default services are included under a
     * different module name, then add that to the list.
     * @return the value of the module key names.
     */
    public ArrayList<String> getModuleKeys()
    {
        ArrayList<String> moduleKeys;                   //list of keys
        
        moduleKeys = new ArrayList<>(modules.keySet());
        servicesToKeys(moduleKeys);
        
        return moduleKeys;
    }
    
    /**
     * Add a new module reference to the modules list.
     * @param moduleInfo the module info object.
     */
    public void addModuleInfo(ModuleInfo moduleInfo)
    {
        modules.put(moduleInfo.moduleName, moduleInfo);
    }
    
    /**
     * Get the full details to the referenced module jar file and dependencies.
     * If default services are included under a different module name, then check that 
     * as well. They will be stored in the default {@code Services} folder location and
     * a temporary {@code ModuleInfo} can be created to return the information.
     * @param moduleName the module name only, not the full jar file path.
     * @return the object the contains the module information.
     */
    public ModuleInfo getModuleInfo(String moduleName)
    {
        if (modules.containsKey(moduleName)) {
            return modules.get(moduleName);
        }
        else {
            return servicesToModule(moduleName);
        }
    }
    
    /**
     * Parse the default services info to get any other module key names.
     * @param moduleKeys list of module key names to add to.
     */
    private void servicesToKeys(ArrayList<String> moduleKeys)
    {
        ServiceModuleInfo serviceInfo;              //service info
        ModuleInfo sModuleInfo;                     //service module info
        
        if (defaultServiceFactory != null) {
            sModuleInfo = defaultServiceFactory.toModuleInfo();
            if (!moduleKeys.contains(sModuleInfo.moduleName)) {
                moduleKeys.add(sModuleInfo.moduleName);
            }
        }
        if (defaultJarFactory != null) {
            sModuleInfo = defaultJarFactory.toModuleInfo();
            if (!moduleKeys.contains(sModuleInfo.moduleName)) {
                moduleKeys.add(sModuleInfo.moduleName);
            }
        }
            
        for (String key: defaultServices.keySet())
        {
            serviceInfo = defaultServices.get(key);
            sModuleInfo = serviceInfo.toModuleInfo();

            if ((sModuleInfo != null) && !moduleKeys.contains(sModuleInfo.moduleName)) {
                moduleKeys.add(sModuleInfo.moduleName);
            }
        }
    }
    
    /**
     * Get the full details to the referenced module jar file, created from the default 
     * services lists. Create a {@code ModuleInfo} description from the first matching name.
     * @param moduleName the module name only, not the full jar file path.
     * @return the object the contains the module information.
     */
    private ModuleInfo servicesToModule(String moduleName)
    {
        String nextKey;                         //next key
        Iterator allKeys;                       //all keys
        ServiceModuleInfo serviceInfo;          //service info
        ModuleInfo moduleInfo;                  //module info
        ModuleInfo sModuleInfo;                 //service module info
        
        moduleInfo = null;
        if (defaultServiceFactory != null) {
            sModuleInfo = defaultServiceFactory.toModuleInfo();
            if ((sModuleInfo != null) && sModuleInfo.moduleName.equals(moduleName)) {
                moduleInfo = sModuleInfo;
            }
        }
        if ((moduleInfo == null) && (defaultJarFactory != null)) {
            sModuleInfo = defaultJarFactory.toModuleInfo();
            if ((sModuleInfo != null) && sModuleInfo.moduleName.equals(moduleName)) {
                moduleInfo = sModuleInfo;
            }
        }
        
        if (moduleInfo == null) {
            allKeys = defaultServices.keySet().iterator();

            while ((moduleInfo == null) && allKeys.hasNext())
            {
                nextKey = (String)allKeys.next();
                serviceInfo = defaultServices.get(nextKey);
                sModuleInfo = serviceInfo.toModuleInfo();
                
                if ((sModuleInfo != null) && sModuleInfo.moduleName.equals(moduleName)) {
                    moduleInfo = sModuleInfo;
                }
            }
        }
        
        return moduleInfo;
    }
    
    /**
     * Remove the module from the list. Also remove any service or interface
     * types associated with it.
     * @param moduleName the module name only, not the full jar file path.
     * @return a list of related service definitions to remove from the main gui.
     */
    public ArrayList<String> removeModuleInfo(String moduleName)
    {
        int i, j;
        String nextKey;                                     //next key
        String nextKey2;                                    //next key
        ArrayList<String> allKeys;                                  //all keys
        ArrayList<String> allKeys2;                                 //all keys
        ArrayList<String> serviceTypes;                             //service types
        HashMap<String, FactoryInfo> classTypes;                                 //class types
        ServiceModuleInfo serviceInfo;                      //service info
        FactoryInfo guiInfo;                                //gui info
        
        serviceTypes = new ArrayList<>();
        if (modules.containsKey(moduleName)) {
            modules.remove(moduleName);           
            allKeys = new ArrayList<>(defaultServices.keySet());

            for (i = 0; i <allKeys.size(); i++)
            {
                nextKey = allKeys.get(i);
                serviceInfo = defaultServices.get(nextKey);
                
                if (serviceInfo.moduleName.equals(moduleName)) {
                    defaultServices.remove(nextKey);
                    serviceTypes.add(nextKey);
                }
            }
            
            allKeys = new ArrayList<>(serviceClasses.keySet());
            for (i = 0; i <allKeys.size(); i++)
            {
                nextKey = allKeys.get(i);
                classTypes = serviceClasses.get(nextKey);
                
                allKeys2 = new ArrayList<>(classTypes.keySet());
                for (j = 0; j < allKeys2.size(); j++)
                {
                    nextKey2 = allKeys2.get(j);
                    guiInfo = classTypes.get(nextKey2);

                    if ((guiInfo != null) && (guiInfo.moduleName != null)) {
                        if (guiInfo.moduleName.equals(moduleName))
                            classTypes.remove(nextKey2);
                    }
                }
                
                if (classTypes.isEmpty()) serviceClasses.remove(nextKey);
            }
        }
        
        return serviceTypes;
    }
    
    /**
     * Add a new service info object for the specified service type. Try to
     * add the full module jar file path first if it is missing.
     * Overwrite any existing entry.
     * @param serviceInfo the service module info.
     */
    public void addServiceInfo(ServiceModuleInfo serviceInfo)
    {
        String jarFile;                         //jar file path

        if (serviceInfo.filePath == null) {
            serviceInfo.filePath = new ArrayList<>();
        }
        if (serviceInfo.filePath.isEmpty()) {
            jarFile = getJarFile(serviceInfo.moduleName);
            if (jarFile != null) serviceInfo.filePath.add(jarFile);
        }
        
        defaultServices.put(serviceInfo.serviceType, serviceInfo);
    }
    
    /**
     * Get the info for the specified service type.
     * @param serviceType the service type.
     */
    public void removeServiceInfo(String serviceType)
    {
        defaultServices.remove(serviceType);
    }
    
    /**
     * Get the info for the specified service type.
     * @param serviceType the service type.
     * @return the full service info object for the service type.
     */
    public ServiceModuleInfo getServiceInfo(String serviceType)
    {
        return defaultServices.getOrDefault(serviceType, null);
    }
    
    /**
     * Get the list of all default services that can be loaded from this module.
     * @return the value of defaultServices.
     */
    public HashMap<String, ServiceModuleInfo> getAllServiceInfo()
    {
        return defaultServices;
    }
    
    /**
     * Add a new class name for the specified service type and function.
     * Overwrite any existing entry.
     * @param serviceFunction the function of the service.
     * @param factoryInfo the interface info.
     */
    public void addInfo(String serviceFunction, FactoryInfo factoryInfo)
    {
        HashMap<String, FactoryInfo> classTypes;        //class types
        
        if (!serviceClasses.containsKey(serviceFunction)) {
            serviceClasses.put(serviceFunction, new HashMap<>());
        }
            
        classTypes = serviceClasses.get(serviceFunction);
        classTypes.put(factoryInfo.serviceType, factoryInfo);
    }
    
    /**
     * Remove class info for the specified service type and function.
     * @param serviceFunction the function of the service.
     * @param factoryInfo the interface info.
     */
    public void removeInfo(String serviceFunction, FactoryInfo factoryInfo)
    {
        HashMap<String, FactoryInfo> classTypes;        //class types

        if (serviceClasses.containsKey(serviceFunction)) {
            classTypes = serviceClasses.get(serviceFunction);
            classTypes.remove(factoryInfo.serviceType);
        }
    }
    
    /**
     * Get the info for the specified service type.
     * @param serviceFunction the function of the service.
     * @param serviceType the service type.
     * @return the full info object for the interface to load.
     */
    public FactoryInfo getInfo(String serviceFunction, String serviceType)
    {
        HashMap<String, FactoryInfo> classTypes;        //class types

        if (serviceClasses.containsKey(serviceFunction)) {
            classTypes = serviceClasses.get(serviceFunction);
            if (classTypes.containsKey(serviceType)) {
                return classTypes.get(serviceType);
            }
        }
 
        return null;
    }
    
    /**
     * Get the list of interface functions that classes are saved for.
     * @return the key set to the service classes lists.
     */
    public ArrayList<String> getAllInfoFunctions()
    {
        return new ArrayList<>(serviceClasses.keySet());
    }
    
    /**
     * Get the list of interface info objects for the stored service types and
     * the specified function.
     * @param serviceFunction the function of the service.
     * @return a list of FactorInfo objects from serviceClasses.
     */
    public HashMap<String, FactoryInfo> getAllInfo(String serviceFunction)
    {
        HashMap<String, FactoryInfo> classTypes;        //class types

        if (serviceClasses.containsKey(serviceFunction)) {
            classTypes = serviceClasses.get(serviceFunction);
            return classTypes;
        }
        
        return null;
    }
    
    /**
     * For backwards compatibility, need to convert some service class names.
     * @param className the class name to check.
     * @return the appropriate version.
     */
    public static String checkClassName(String className)
    {
        String newClassName;                        //new class name
        
        newClassName = className;
        if (newClassName != null) {
            if (newClassName.equals(Service.class.getName()) ||
                newClassName.equals("org.licas.service.model.BasicService")) {
                newClassName = DataService.class.getName();
            }
        }
        
        return ServiceConst.checkClassName(newClassName);
    }
}
