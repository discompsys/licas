/*
 * MetaFactory.java
 *
 * Created on 10 September 2013
 *
 * Version 1.3.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.meta;


import org.licas.parsers.Parsers;
import org.licas.parsers.types.ReflectionParser;
import org.licas.util.*;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Vector;


/**
 * This class can create metadata parts that can be used to define
 * service creation or initialisation.
 * @author Kieran Greer
 */
public class MetaFactory 
{
    /** Meta factory for service meta elements */
    private static final MetaFactoryService factoryService;
    
    /** Meta factory for data elements */
    private static final MetaFactoryData factoryData;
    
    /** Meta factory for AI elements */
    private static final MetaFactoryAI factoryAI;
    
    static
    {
        factoryService = new MetaFactoryService();
        factoryData = new MetaFactoryData();
        factoryAI = new MetaFactoryAI();
    }
    
    /**
     * Create a Policy element that can be used as the base for the policy script, 
     * as in {@code <Policy></Policy>}.
     * @return an XML element that defines the policy element.
     */
    public static Element createPolicy()
    {
        Element rootElem;                               //root element
        
        rootElem = XMLFactory.getInstance().createElement(AiConst.POLICY);
        return rootElem;
    }
    
    /**
     * Create a category element that can be used as part of a script. 
     * This method creates a script with just a category description, 
     * as in {@code <Service_Category>category</Service_Category>}.
     * @param category the category type to add.
     * @return an XML element that defines the service to load.
     */
    public static Element createCategory(String category)
    {
        Element rootElem;                               //root element
        
        rootElem = XMLFactory.getInstance().createElement(Const.SERVICECATEGORY);
        rootElem.setText(category);
        
        return rootElem;
    }
    
    /**
     * Parse the object using reflection, to find the first method that matches the spec and
     * return an XML-based description of it. As no parameters are declared, only the
     * parameter type is returned and different parameter sets cannot be considered.
     * @param toInvoke class of the object to invoke.
     * @param methodName the name of the method to invoke. This is required.
     * @param rtnType the method return type. Can be null for no match.
     * @return an XML-based description of the method to invoke, or null if there was no match.
     */
    public static Element createMethod(Class toInvoke, String methodName, String rtnType)
    {
        return createMethod(toInvoke, methodName, rtnType, null);
    }
    
    /**
     * Parse the object using reflection, to find the method that matches the spec and
     * return an XML-based description of it.
     * @param toInvoke class of the object to invoke.
     * @param methodName the name of the method to invoke. This is required.
     * @param rtnType the method return type. Can be null for no match.
     * @param paramTypes list of parameter types to match to.
     * @param paramNames a list of names that get added to each parameter in order. This also
     * serves to specify the number of required parameters. If null, then the first match
     * is returned and only the parameter type is defined.
     * @return an XML-based description of the method to invoke, or null if there was no match.
     */
    public static Element createMethod(Class toInvoke, String methodName, String rtnType, 
            ArrayList<String> paramTypes, ArrayList<String> paramNames)
    {
        Element rootElem;                               //root element
        Method theMethod;                               //the matching method
        
        rootElem = null;        
        theMethod = ReflectionHandler.retrieveMethod(toInvoke, methodName, rtnType, paramTypes);        
        if (theMethod != null) {
            rootElem = ReflectionParser.methodToXML(theMethod, paramNames);
        }
        
        return rootElem;
    }
    
    /**
     * Parse the object using reflection, to find the method that matches the spec and
     * return an XML-based description of it.
     * @param toInvoke class of the object to invoke.
     * @param methodName the name of the method to invoke. This is required.
     * @param rtnType the method return type. Can be null for no match.
     * @param paramTypes list of parameter types to match to.
     * @return an XML-based description of the method to invoke, or null if there was no match.
     */
    public static Element createMethod(Class toInvoke, String methodName, String rtnType, 
            ArrayList<String> paramTypes)
    {
        Element rootElem;                               //root element
        Method theMethod;                               //the matching method
        
        rootElem = null;
        theMethod = ReflectionHandler.retrieveMethod(toInvoke, methodName, rtnType, paramTypes);        
        if (theMethod != null) {
            rootElem = ReflectionParser.methodToXML(theMethod);
        }
        
        return rootElem;
    }
    
        /**
     * Create an empty Admin XML element that can be used as the base of an admin script. 
     * This method creates an admin script with just a root element, as in {@code <Admin></Admin>}
     * that then needs to be populated with other elements.
     * @return an XML element that defines the service to load.
     */
    public static Element createAdmin()
    {
        Element rootElem;                           //root element
        
        rootElem = XMLFactory.getInstance().createElement(MetaConst.ADMIN);
        return rootElem;
    }
    
    /**
     * Add an attribute to the base XML element that has a {@code attrName} tag and
     * {@code attrValue} value. This will overwrite any existing attribute.
     * @param xmlElem the element to add the attribute to.
     * @param attrName the name of the attribute
     * @param attrValue the value of the attribute.
     */
    public static void addAttribute(Element xmlElem, String attrName, String attrValue)
    {
        xmlElem.setAttribute(attrName, attrValue);
    }
    
    /**
     * Add the new XML element to the admin document/script under the appropriate element type.
     * @param scriptXml the current admin document/script. Can use {@code createAdminXML} 
     * to create an empty admin document, for example.
     * @param toAdd the XML element to add to the script.
     * @return the newly created admin document.
     */
    public static Element add(Element scriptXml, Element toAdd)
    {
        return add(scriptXml, toAdd, null);
    }
    
    /**
     * Add the new XML element to the admin document/script under the appropriate element type.
     * @param scriptXml the current admin document/script. Can use {@code createAdminXML} 
     * to create an empty admin document, for example.
     * @param toAdd the XML element to add to the script.
     * @param type the type of element to add, see the admin user guide spec for examples. 
     * If {@code null}, then the element gets added to {@code scriptXml} directly. If not null, 
     * then its type can be checked for correctness. Currently, the only manual correction is for 
     * {@code MetaConst.AISOLVER} that creates an {@code Const.OTHERMETA} element only and then 
     * adds the new element to that. Otherwise, a child element of {@code scriptXml}, with the
     * the {@code Name} of {@code type} is retrieved and the new element is added to that.
     * If there is no element with that name, it gets added to {@code scriptXml} again.
     * This is related to parsing problem solving scripts.
     * @return the newly created admin document.
     */
    public static Element add(Element scriptXml, Element toAdd, String type)
    {
        Element nextElem;                               //next element
        
        if (scriptXml == null)
        {
            scriptXml = XMLFactory.getInstance().createElement(MetaConst.ADMIN);
        }
        
        if (toAdd != null)
        {
            if (type == null)
            {
                scriptXml.addContent(toAdd);
            }
            else
            {
                if (type.equals(AiConst.AISOLVER))
                {
                    nextElem = XMLFactory.getInstance().createElement(Const.OTHERMETA);
                    nextElem.addContent(toAdd);
                    scriptXml.addContent(nextElem);
                }
                else
                {
                    nextElem = scriptXml.getChild(type);
                    if (nextElem != null) nextElem.addContent(toAdd);
                    else scriptXml.addContent(toAdd);
                }
            }
        }
       
        return scriptXml;
    }
    
    /**
     * Create an XML element that can be used as part of a script to define a
     * parser to dynamically create and use, to parse a specified Java object to 
     * or from XML.
     * @param toParseClass this can be used to define the class type that should be
     * parsed. It can also be null if the invoking object already knows the object to parse.
     * @param parserClass this defines the class type of the parser itself. The parser should
     * probably extend the ParserDef interface, but it does not get added to the default
     * list automatically and so this is optional and implementation-dependent.
     * @param jarFiles a list of jar files if the parser is from an external source.
     * @return an XML element that defines the service to load. This might look like:
     * {@code <Parser><To_Parse_Class>Optional class to parse</To_Parse_Class>
     * <Parser_Class>Parser class name</Parser_Class><Jar_Files><Jar_File>Jar file path</Jar_File>
     * </Jar_Files></Parser>}
     */
    public static Element createParser(String toParseClass, String parserClass, ArrayList<String> jarFiles)
    {
        int i;
        Element rootElem;                               //root element
        Element nextElem;                               //next element
        Element nextElem2;                              //next element
        
        if (jarFiles == null) jarFiles = new ArrayList<>();
        rootElem = XMLFactory.getInstance().createElement(Const.PARSER);
        
        if (toParseClass != null) {
            nextElem = XMLFactory.getInstance().createElement(Const.TOPARSECLASS);
            nextElem.setText(toParseClass);
            rootElem.addContent(nextElem);
        }
        
        nextElem = XMLFactory.getInstance().createElement(Const.PARSERCLASS);
        nextElem.setText(parserClass);
        rootElem.addContent(nextElem);

        nextElem = XMLFactory.getInstance().createElement(Const.JARFILESXML);
        rootElem.addContent(nextElem);

        for (i = 0; i < jarFiles.size(); i++)
        {
            nextElem2 = XMLFactory.getInstance().createElement(Const.JARFILEXML);
            nextElem2.setText(jarFiles.get(i));
            nextElem.addContent(nextElem2);
        }
        
        return rootElem;
    }
    
    /**
     * Create and return an XML element. This method creates an empty element with 
     * the specified name, as in {@code <metaType></metaType>} and is just for convenience.
     * @param metaType the metadata element name.
     * @return the created XML element.
     */
    public static Element createMeta(String metaType)
    {
        Element rootElem;                               //root element
        
        rootElem = XMLFactory.getInstance().createElement(metaType);
        return rootElem;
    }
    
    /**
     * Create an XML element that can be used as part of a script. 
     * This method creates an XML element with the specified name, but then adds 
     * either a string or nested XML to that, depending on what the value is, as in 
     * {@code <metaType>String or Nested XML value</metaType>}.
     * @param metaType the metadata element name.
     * @param metaValue the value for the element. this should be either a String or XML.
     * @return an XML element that defines the service to load.
     */
    public static Element createMetaValue(String metaType, Object metaValue)
    {
        Element rootElem;                               //root element
        
        rootElem = createMeta(metaType);       
        if (metaValue != null)
        {
            if (ObjectHandler.isElement(metaValue))
                rootElem.addContent((Element)metaValue);
            else
                rootElem.setText(String.valueOf(metaValue));
        }
        
        return rootElem;
    }
    
    /**
     * Replace element text values that may be tagged with the equivalent value from the key-value list.
     * @param metaXml the xml script that can have element values with some name.
     * @param valueList a list of {@link KeyValue} objects, where if the key matches any
     * element value, the value is replaced by the KeyValue value, as a String cast.
     */
    public static void replaceValue(Element metaXml, ArrayList<KeyValue> valueList)
    {
        int i;
        KeyValue keyValue;                          //key-value pair
        
        for (i = 0; i < valueList.size(); i++)
        {
            keyValue = valueList.get(i);
            replaceValue(metaXml, keyValue);
        }
    }
    
    /**
     * Replace element text values that may be tagged with the equivalent value from the key-value object.
     * @param metaXml the xml script that can have element values with some name.
     * @param keyValue the key-value to use as the replacement.
     */
    private static void replaceValue(Element metaXml, KeyValue keyValue)
    {
        int i;
        String nextValue;                           //next value
        Element nextElem;                           //next element
        Vector<Node> elemList;                      //list of child elements
        
        if (!metaXml.hasChildren()) {
            nextValue = metaXml.getValue();          
            if ((nextValue != null) && nextValue.equals(keyValue.key)) {
                metaXml.setValue(String.valueOf(keyValue.value));
            }
        }
        else {
            elemList = metaXml.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextElem = (Element)elemList.get(i);
                replaceValue(nextElem, keyValue);
            }
        }
    }
    
    /**
     * Format the XML-based description of a Java Object, to make sure that it will be
     * interpreted correctly by the automatic licas parsers. This involves adding a class name
     * attribute to the base XML element that has a {@code Const.CONVERSIONTYPE} tag. 
     * The conversion type is required for the automatic parsing and should be added to the
     * base element, if the XML description is being created manually. This will overwrite
     * any existing attribute.
     * @param xmlElem the XML-based or parsed description of the Java object.
     * @param className the fully qualified class name of the object that was parsed.
     */
    public static void parsedObjTypeAttr(Element xmlElem, String className)
    {
        MetaFactory.addAttribute(xmlElem, Const.CONVERSIONTYPE, className);
    }
    
    /**
     * Convert the known object to XML using the known parser. This calls 
     * {@code Parsers.serializeToString(...)} to serializeToString the Object to an XML {@code Element} reply.
     * @param theObject the object to parse, including its values. The object must already 
     * be known by {@link Parsers}, including having added its parser.
     * @return the object serialized into an XML-based description, or null if the
     * serialization was not successful.
     * @throws java.lang.Exception any error.
     */
    public static Element objectToXml(Object theObject) throws Exception
    {
        return Parsers.serializeToElement(theObject);
    }
    
    /**
     * Get the meta factory related to service metadata.
     * @return the value of factoryService.
     */
    public static MetaFactoryService getFactoryService()
    {
        return factoryService;
    }
    
    /**
     * Get the meta factory related to data elements.
     * @return the value of factoryData.
     */
    public static MetaFactoryData getFactoryData()
    {
        return factoryData;
    }
    
    /**
     * Get the meta factory related to AI elements.
     * @return the value of factoryAI.
     */
    public static MetaFactoryAI getFactoryAI()
    {
        return factoryAI;
    }
}
