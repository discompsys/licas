/*
 * ServiceModuleInfo.java
 *
 * Created on 16 February 2012
 *
 * Version 1.3
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.meta.model;


import org.ai_heuristic.model.FactoryInfo;

import java.io.File;


/**
 * Stores information for a default service loaded from a module.
 * @author Kieran Greer
 */
public class ServiceModuleInfo extends FactoryInfo
{
    /** 
     * The full path to an icon file that can represent the service type in the GUI.
     * If this is null, then a default image is used instead.
     */
    public String iconFile;
    
    /** 
     * The time since 1 January 1970 UTC in milliseconds when the module was added.
     * {@code System.currentTimeMillis()} - this is set automatically during the {@link ModuleInfo} initialisation.
     */
    public long timeStamp;
    
    /**
     * Create a new instance of ServiceModuleInfo.
     */
    public ServiceModuleInfo()
    {
        super();
        iconFile = null;
        timeStamp = System.currentTimeMillis();
    }
    
    /**
     * Convert this info object into a ModuleInfo type, with information added as
     * appropriate. If there is no file path in this info object, then return null.
     * @return the created module info, or null if the jar file is missing.
     */
    public ModuleInfo toModuleInfo()
    {
        int i;
        String jarFile;                         //first jar file
        ModuleInfo moduleInfo;                  //module info
        
        moduleInfo = null;
        if (!filePath.isEmpty())
        {
            moduleInfo = new ModuleInfo();
            jarFile = filePath.get(0);
            if ((moduleName == null) || moduleName.equals(""))
            {
                moduleName = (new File(jarFile)).getName();
            }
            
            moduleInfo.moduleName = moduleName;
            moduleInfo.filePath = jarFile;

            for (i = 1; i < filePath.size(); i++)
            {
                moduleInfo.tpJars.add(filePath.get(i));
            }
        }
        
        return moduleInfo;
    }
}
