/*
 * ServiceMeta.java
 *
 * Created on 5 December 2008
 *
 * Version 1.9.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.meta;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.AdminInfo;
import org.licas.ServiceLinks;
import org.licas.call.Handle;
import org.licas.parsers.types.ReflectionParser;
import org.licas.service.model.KeywordHandler;
import org.licas.util.Const;
import org.licas.util.ServiceConst;
import org.licas.util.classloader.LoadObject;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.model.XmlHandler;

import java.util.ArrayList;
import java.util.Vector;


/**
 * This is a lightweight description of a service for information purposes. This stores the 
 * information of a service that can be retrieved through reflection of its class type and also
 * some of the admin or other values such as a uuid, path, description, jar file path, 
 * list of nested services and also some linking information. Not all of the fields are
 * always populated, so it is up to the administrator of the service to add whatever 
 * information is required. This might require an admin document being used during initialisation.
 * <p>
 * A Service's {@link AdminInfo} or {@link ServiceLinks} objects also store metadata info that represent
 * the current service's use and associations, and helps to create these descriptive entries. 
 * A ServiceMeta object is not stored permanently, but is created dynamically on request and populated 
 * with information from these objects. 
 * <p>
 * One {@code ServiceMeta} object however is stored permanently on the server in the {@code metadata repository}. 
 * It is added, with the default subset of values, when the service is firstly loaded onto the server and 
 * it is not updated unless the service manually updates it. Linking info would not typically
 * be updated automatically, for example, but an initialisation admin document can be included.
 * <p>
 * The metadata can be retrieved in parts as well, by asking for particular fields, as part of an {@code include} list.
 * These can be defined by: {@link Const}.{@code  UUID }, {@code  SERVICETYPE }, {@code  SERVICEGRADE }, 
 * {@code  SERVICECATEGORY }, {@code  MODULE }, {@code  SERVICEPATH }, {@code  DESCRIPTION }, {@code  KEYWORDS }, {@code  CHILDSERVICES }, 
 * {@code  LINKS }, {@code  ASSOCIATEDLINKS }, {@code  CLASSNAME }, {@code  JARFILE }, {@code  CONSTRUCTORS }, 
 * {@code  METHODS }, {@code  OTHERMETA }, {@code  DATA }, {@code  INSTANCEVALUES }, {@code  PARAMETERS }.
 * Some of these require the admin key for access.
 * @author Kieran Greer
 */
public class ServiceMeta 
{
    /** The logger */
    private static final Logger logger;
    
    
    /** The service uuid */
    public String uuid;
    
    /** The service class */
    public String serviceClass;
    
    /** The service type */
    public String serviceType;
    
    /** The service grade */
    public String serviceGrade;
    
    /** The service category */
    public String serviceCategory;
    
    /** The name of the module that the service class is loaded from */
    public String moduleName;
    
    /** The service URI path */
    public Element serviceUri;
    
    /** A description of the service */
    public Element description;

    /** Any other metadata, such as keywords, etc */
    public Element meta;

    /** Any value-based metadata */
    public Element data;
    
    /** List of variables with or without instance values */
    public Element instanceValues;
    
    /** A list of constructors. Values are in XML format. */
    public ArrayList<Element> constructorMeta;
    
    /** A list of public methods. Values are in XML format. */
    public ArrayList<Element> methodMeta;
    
    /**
     * The name of the jar file(s) that the class can be loaded from.
     * Values are the jar file paths of type String.
     */
    public ArrayList<String> jarFile;
    
    /** The list of keywords relating to any of the concepts */
    public KeywordHandler keywordHandler;
    
    /** 
     * The child service ids. Values are the ids of type String.
     */
    public Element childServiceMeta;
    
    /**
     * The uuids of permanently linked services. This forms the static network structure.
     * Values are the service ids of type String.
     */
    public Element linkServiceMeta;
    
    /**
     * The full paths of services that this service knows about. This is an additional 
     * list to the permanent and dynamic linking lists, for associations that can be 
     * used in any way desired. It can be used, for example, to describe permanent 
     * links or associations between services on different servers. The {@code linkServiceMeta} 
     * structure would typically form the permanent network structure and therefore would 
     * be confined to a single server only.
     */
    public Element serviceAssociations;
    
    /** 
     * Constructor parameters.
     */
    public Element parameters;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServiceMeta.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Create a new instance of ServiceMeta.
     */
    public ServiceMeta()
    {
        initialise();
    }
    
    /**
     * Initialise the service details values.
     */
    private void initialise()
    {
        uuid = null;
        serviceType = null;
        serviceGrade = null;
        serviceClass = null;
        serviceCategory = ServiceConst.ALLCATEGORIES;
        moduleName = null;
        serviceUri = null;
        description = null;
        meta = null;
        data = null;
        instanceValues = null;
        parameters = null;
        
        constructorMeta = new ArrayList<>();
        methodMeta = new ArrayList<>();
        jarFile = new ArrayList<>();
        clearChildAndLinksMeta();
        
        keywordHandler = null;
    }
    
    /** Clear all metadata descriptions for child services or links */
    public void clearChildAndLinksMeta()
    {
        childServiceMeta = null;
        linkServiceMeta = null;
        serviceAssociations = null;
    }    
    
    /**
     * Return true if the this metadata object contains an entry for the specified 
     * metadata part.
     * @param toInclude additional meta parts to include as well as the default part.
     * @return true if the metadata part has an entry of any type, false otherwise.
     */
    public boolean hasMetaForInfo(String toInclude)
    {
        switch (toInclude) {
            case Const.UUID:
                return (uuid != null);
            case Const.SERVICETYPE:
                return (serviceType != null);
            case Const.SERVICEGRADE:
                return (serviceGrade != null);
            case Const.SERVICECATEGORY:
                return (serviceCategory != null);
            case Const.MODULE:
                return (moduleName != null);
            case Const.SERVICEPATH:
                return (serviceUri != null);
            case Const.DESCRIPTION:
                return (description != null);
            case Const.KEYWORDS:
                return ((keywordHandler != null) && !keywordHandler.getKeywordLists().isEmpty());
            case Const.CHILDSERVICES:
                return ((childServiceMeta != null) && childServiceMeta.hasChildren());
            case Const.LINKS:
                return ((linkServiceMeta != null) && linkServiceMeta.hasChildren());
            case Const.ASSOCIATEDLINKS:
                return ((serviceAssociations != null) && serviceAssociations.hasChildren());
            case Const.CLASSNAME:
                return (serviceClass != null);
        }

        if (toInclude.equals(Const.JARFILE))
            return ((jarFile != null) && !jarFile.isEmpty());
        if (toInclude.equals(Const.CONSTRUCTORS))
            return ((constructorMeta != null) && !constructorMeta.isEmpty());
        if (toInclude.equals(Const.METHODS))
            return ((methodMeta != null) && !methodMeta.isEmpty());
        if (toInclude.equals(Const.OTHERMETA))
            return (meta != null);
        if (toInclude.equals(Const.DATA))
            return (data != null);
        if (toInclude.equals(Const.INSTANCEVALUES))
            return (instanceValues != null);
        if (toInclude.equals(Const.PARAMETERS))
            return (parameters != null);
        
        return false;
    }
    
    /**
     * Set the ServiceMeta details.
     * @param theUuid the service uuid.
     * @param theServiceType the service type.
     * @param theServiceGrade the service grade, for example {@link ServiceConst}.{code BASE} or {@code UTILITY}.
     * @param theServiceClass the fully qualified class name of the service the meta describes.
     * @param theServicePath the fully qualified path to the service.
     * @param theJarFile a list of jar files required to load the service.
     * Values are the jar file paths of type String.
     * @return true if the constructors meta is set OK.
     * @throws java.lang.Exception any error.
     */
    public boolean setServiceMeta(String theUuid, String theServiceType, String theServiceGrade, 
            String theServiceClass, Element theServicePath, ArrayList<String> theJarFile) throws Exception
    {
        String theClassName;                        //the class name
        
        uuid = theUuid;
        serviceType = theServiceType;
        serviceGrade = theServiceGrade;
        serviceClass = theServiceClass;
        serviceUri = theServicePath;       
        if (theJarFile != null) jarFile = theJarFile;

        if (serviceClass != null)
        {
            try
            {
                theClassName = ReflectionParser.unformatClassName(serviceClass);
                LoadObject.getClass(theClassName);
            }
            catch (Exception ex)
            {
                ReflectionParser.unformatClassName(serviceClass);
                if (jarFile != null) LoadObject.addLoader(jarFile);
            }
        }
        
        return true;
    }
    
    /**
     * Set the ServiceMeta details.
     * @param theUuid the service uuid.
     * @param theServiceType the service type.
     * @param theServiceGrade the service grade, for example {@link ServiceConst}.{code BASE} or {@code UTILITY}.
     * @param theServiceClass the fully qualified class name of the service the meta describes.
     * @param theServicePath the fully qualified path to the service.
     * @param theJarFile a list of jar files required to load the service.
     * Values are the jar file paths of type String.
     * @param adminInfo admin info with description and other metadata.
     * @return true if the constructors meta is set OK.
     */
    public boolean setServiceMeta(String theUuid, String theServiceType, String theServiceGrade, 
            String theServiceClass, Element theServicePath, ArrayList<String> theJarFile, AdminInfo adminInfo)
    {
        uuid = theUuid;
        serviceType = theServiceType;
        serviceGrade = theServiceGrade;
        serviceClass = theServiceClass;
        serviceUri = theServicePath;
        setAdminInfoMeta(adminInfo);
        if (theJarFile != null) jarFile = theJarFile;
        
        return true;
    }

    /**
     * Set the ServiceMeta details.
     * @param theUuid the service uuid.
     * @param theServiceType the service type.
     * @param theServiceGrade the service grade, for example {@link ServiceConst}.{code BASE} or {@code UTILITY}.
     * @param theServiceClass the fully qualified class name of the service the meta describes.
     * @param theServicePath the fully qualified path to the service.
     * @param theJarFile a list of jar files required to load the service.
     * Values are the jar file paths of type String.
     * @param theConstructors a list of constructor definitions in XML.
     * @param theMethods a list of method definitions in XML.
     * @param adminInfo admin info with description and other metadata.
     * @return true if the constructors meta is set OK.
     */
    public boolean setServiceMeta(String theUuid, String theServiceType, String theServiceGrade, String theServiceClass,
            Element theServicePath, ArrayList<String> theJarFile, ArrayList<Element> theConstructors,
                                  ArrayList<Element> theMethods, AdminInfo adminInfo)
    {
        uuid = theUuid;
        serviceType = theServiceType;
        serviceGrade = theServiceGrade;
        serviceClass = theServiceClass;
        serviceUri = theServicePath;
        setAdminInfoMeta(adminInfo);
        if (theJarFile != null) jarFile = theJarFile;
        constructorMeta = theConstructors;
        methodMeta = theMethods;

        return true;
    }

    /**
     * Set description, other meta and data values passed in by an AdminInfo object.
     * @param adminInfo the admin info object.
     */
    private void setAdminInfoMeta(AdminInfo adminInfo)
    {
        if (adminInfo != null)
        {
            description = adminInfo.getDescription();
            meta = adminInfo.getOtherMeta();
            data = adminInfo.getData();
            instanceValues = adminInfo.getInstanceValues();
        }
    }
    
    /**
     * Retrieve the meta that can be returned for info purposes.
     * @return a new ServiceMeta object with the relevant information.
     */
    public ServiceMeta getMetaForInfo()
    {
        String nextID;                              //next service id
        Element pathClone;                          //copy of the path
        ServiceMeta newServiceMeta;                 //new service meta
        
        newServiceMeta = new ServiceMeta();
        newServiceMeta.uuid = uuid;
        newServiceMeta.serviceType = serviceType;
        newServiceMeta.serviceGrade = serviceGrade;
        newServiceMeta.serviceCategory = serviceCategory;
        newServiceMeta.serviceUri = serviceUri;
        newServiceMeta.description = description;
        newServiceMeta.keywordHandler = keywordHandler;
              
        if (serviceUri != null)
        {
            pathClone = (Element)serviceUri.clone();
            nextID = Handle.getLastServiceHandle(pathClone);
            if (nextID.equals(Const.HTTPSERVER))
            {
                newServiceMeta.serviceUri = pathClone;
            }
        }
        
        return newServiceMeta;
    }
    
    /**
     * Add a meta part to this metadata object from the meta passed in.
     * @param toInclude the section to include
     * @param thisMeta the other metadata object to copy from.
     */
    public void addMetaPart(String toInclude, ServiceMeta thisMeta)
    {
        switch (toInclude) {
            case Const.UUID:
                uuid = thisMeta.uuid;
                break;
            case Const.SERVICETYPE:
                serviceType = thisMeta.serviceType;
                break;
            case Const.SERVICEGRADE:
                serviceGrade = thisMeta.serviceGrade;
                break;
            case Const.SERVICECATEGORY:
                serviceCategory = thisMeta.serviceCategory;
                break;
            case Const.MODULE:
                moduleName = thisMeta.moduleName;
                break;
            case Const.SERVICEPATH:
                serviceUri = thisMeta.serviceUri;
                break;
            case Const.DESCRIPTION:
                description = thisMeta.description;
                break;
            case Const.KEYWORDS:
                setKeywordHandler(thisMeta.keywordHandler);
                break;
            case Const.CHILDSERVICES:
                childServiceMeta = thisMeta.childServiceMeta;
                break;
            case Const.LINKS:
                linkServiceMeta = thisMeta.linkServiceMeta;
                break;
            case Const.ASSOCIATEDLINKS:
                serviceAssociations = thisMeta.serviceAssociations;
                break;
            case Const.CLASSNAME:
                serviceClass = thisMeta.serviceClass;
                break;
            case Const.JARFILE:
                jarFile = thisMeta.jarFile;
                break;
            case Const.CONSTRUCTORS:
                constructorMeta = thisMeta.constructorMeta;
                break;
            case Const.METHODS:
                methodMeta = thisMeta.methodMeta;
                break;
            case Const.OTHERMETA:
                meta = thisMeta.meta;
                break;
            case Const.DATA:
                data = thisMeta.data;
                break;
            case Const.INSTANCEVALUES:
                instanceValues = thisMeta.instanceValues;
                break;
            case Const.PARAMETERS:
                parameters = thisMeta.parameters;
                break;
        }
    }
    
    /**
     * Set the keyword handler for processing all keywords.
     * @param theKeywordHandler the keyword handler.
     */
    public void setKeywordHandler(KeywordHandler theKeywordHandler)
    {
        keywordHandler = theKeywordHandler;
    }
    
    /**
     * Get the keywords metadata lists in XML format.
     * @return the keywords lists in XML format.
     * @throws java.lang.Exception any error.
     */
    public Element getKeywordXml() throws Exception
    {
        if (keywordHandler != null) return keywordHandler.keywordsToXml();
        else return null;
    }
    
    /**
     * Parse the child service metadata and return the text or XML-based descriptions.
     * @return a list of child service IDs or full XML descriptions, or an empty list if there are none.
     */
    public ArrayList<Object> getChildServices()
    {
        int i;
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Vector<Node> elemList;                      //list of elements
        ArrayList<Object> childServices;            //child service list

        childServices = new ArrayList<>();
        if ((childServiceMeta != null) && childServiceMeta.hasChildren()) {
            elemList = childServiceMeta.getChildren();

            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = elemList.get(i);
                if (nextNode instanceof Element) {
                    nextElem = (Element)nextNode;
                    if (nextElem.hasChildren()) {
                        childServices.add(nextElem.getChildren().get(0));
                    }
                    else {
                        childServices.add(nextElem.getText());
                    }
                }
            }
        }
        
        return childServices;
    }
    
    /**
     * Parse the permanent link service XML and return a list of stored IDs.
     * @return a string-based list of linked to service paths, or an empty list 
     * if there are none.
     * @throws java.lang.Exception any error.
     */
    public ArrayList<String> getLinkServices() throws Exception
    {
        int i;
        String pathStr;                             //path as a string
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Element pathElem;                           //path element
        Vector<Node> elemList;                      //list of elements
        ArrayList<String> linkServices;             //linked to service list

        linkServices = new ArrayList<>();
        if ((linkServiceMeta != null) && linkServiceMeta.hasChildren()) {
            elemList = linkServiceMeta.getChildren();

            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = elemList.get(i);
                if (nextNode instanceof Element) {
                    nextElem = (Element)nextNode;
                    if (nextElem.hasChildren()) {
                        pathElem = nextElem.getElementChildAtIndex(0);
                        pathStr = XmlHandler.xmlToString(pathElem);
                    }
                    else {
                        pathStr = nextElem.getText();
                    }
                    
                    linkServices.add(pathStr);
                }
            }
        }
        
        return linkServices;
    }
    
    /**
     * Parse the association link service XML and return a list of stored IDs.
     * @return a list of association service IDs, or an empty list if there are none.
     * @throws java.lang.Exception any error.
     */
    public ArrayList<String> getAssociationServices() throws Exception
    {
        int i;
        String pathStr;                             //path as a string
        Node nextNode;                              //next node
        Element nextElem;                           //next element
        Element pathElem;                           //path element
        Vector<Node> elemList;                      //list of elements
        ArrayList<String> associationServices;      //association service list

        associationServices = new ArrayList<>();
        if ((serviceAssociations != null) && serviceAssociations.hasChildren()) {
            elemList = serviceAssociations.getChildren();

            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = elemList.get(i);
                if (nextNode instanceof Element) {
                    nextElem = (Element)nextNode;

                    if (nextElem.hasChildren()) {
                        pathElem = nextElem.getElementChildAtIndex(0);
                        pathStr = XmlHandler.xmlToString(pathElem);
                    }
                    else {
                        pathStr = nextElem.getText();
                    }
                    
                    associationServices.add(pathStr);
                }
            }
        }
        
        return associationServices;
    }
    
    /**
     * Return a cloned copy of this object.
     * @return an exact copy of this object.
     */
    public Object clone()
    {
        ServiceMeta cloneMeta;                              //cloned service meta
        
        try {
            cloneMeta = new ServiceMeta();
            cloneMeta.uuid = uuid;
            cloneMeta.serviceType = serviceType;
            cloneMeta.serviceGrade = serviceGrade;
            cloneMeta.serviceCategory = serviceCategory;
            cloneMeta.serviceClass = serviceClass;
            cloneMeta.moduleName = moduleName;
            cloneMeta.keywordHandler = keywordHandler;
        
            if (serviceUri != null) {
                cloneMeta.serviceUri = (Element)serviceUri.clone();
            }
            if (description != null) {
                cloneMeta.description = (Element)description.clone();
            }
            if (childServiceMeta != null) {
                cloneMeta.childServiceMeta = (Element)childServiceMeta.clone();
            }
            if (linkServiceMeta != null) {
                cloneMeta.linkServiceMeta = (Element)linkServiceMeta.clone();
            }
            if (serviceAssociations != null) {
                cloneMeta.serviceAssociations = (Element)serviceAssociations.clone();
            }
            if (meta != null) {
                cloneMeta.meta = (Element)meta.clone();
            }
            if (data != null) {
                cloneMeta.data = (Element)data.clone();
            }
            if (instanceValues != null) {
                cloneMeta.instanceValues = (Element)instanceValues.clone();
            }
            if (parameters != null) {
                cloneMeta.parameters = (Element)parameters.clone();
            }
            if ((constructorMeta != null) && (constructorMeta.size() > 0)) {
                cloneMeta.constructorMeta = (ArrayList<Element>)constructorMeta.clone();
            }
            if ((methodMeta != null) && (methodMeta.size() > 0)) {
                cloneMeta.methodMeta = (ArrayList<Element>)methodMeta.clone();
            }
            if (jarFile != null) {
                cloneMeta.jarFile = (ArrayList<String>)jarFile.clone();
            }

            return cloneMeta;
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "clone",
                "", ex);
            
            return null;
        }
    }
}
