/*
 * ServiceComm.java
 *
 * Created on 5 December 2016
 *
 * Version 1.4.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas;


import org.licas.call.MethodInfo;
import org.licas.def.ServiceWrapperDef;

/**
 * Communication bridge between protected {@link Service} methods and other packages.
 * @author Kieran Greer
 */
public class ServiceComm
{
    /**
     * Return true if this service currently stores a conversation with the specified
     * communication ID.
     * @param commID the communication ID to check for.
     * @param service direct reference to the service to invoke.
     * @return true if the communication ID, false otherwise.
     */
    public static boolean hasCommunicationID(String commID, Service service)
    {
        return service.hasCommunicationID(commID);
    }
    
    /**
     * Store the communicationID with the related client URI, stored as a {@link MessageInfo} object
     * with timestamps. The method now also checks the timestamps and removes any 
     * communicationIDs that are older than 3 days.
     * @param communicationID the communication id.
     * @param clientURI the URI/reference for the calling client.
     * @param service direct reference to the service to invoke.
     * @return true if the id is new and can be added, or false if the comm id already 
     * exists, or cannot be added.
     * @throws java.lang.Exception any error.
     */
    public static boolean addCommunicationID(String communicationID, Object clientURI, Service service)
            throws Exception
    {
        return service.addCommunicationID(communicationID, clientURI);
    }
    
    /**
     * Remove the communication ID reference.
     * @param communicationID the communication ID.
     * @param service direct reference to the service to invoke.
     */
    public static void removeCommunicationID(String communicationID, Service service)
    {
        service.removeCommunicationID(communicationID);
    }

    /**
     * Get the client URI associated with a communication ID.
     * @param communicationID the communication ID.
     * @param service direct reference to the service to invoke.
     * @return the clientURI stored in the message info object.
     */
    public static Object getClientURI(String communicationID, Service service)
    {
        return service.getCommunicationClientURI(communicationID);
    }

    /**
     * Get the last read communication ID.
     * @param service the service to query.
     * @return the value of commID.
     */
    public static String getCommID(Service service)
    {
        return service.sm.getCommID();
    }

    /**
     * Store the commID with the related client URI, on the embedded service. Stored as {@link MessageInfo}
     * objects with timestamps. The method now also checks the timestamps and removes any communicationIDs
     * that are older than 3 days.
     * @param communicationID the communication id.
     * @param clientURI the URI/reference for the calling client.
     * @param wrapper direct reference to the service to invoke.
     * @return true if the id is new and can be added, or false if the comm id already
     * exists, or cannot be added.
     * @throws java.lang.Exception any error.
     */
    public static boolean addCommunicationID(String communicationID, Object clientURI, ServiceWrapperDef wrapper)
            throws Exception
    {
        if (wrapper instanceof ServiceWrapper)
            return ((ServiceWrapper)wrapper).addCommunicationID(communicationID, clientURI);
        else
            return ((ServiceWrapperLegacy)wrapper).addCommunicationID(communicationID, clientURI);
    }

    /**
     * Set the service grade or status.
     * @param serviceGrade the service grade.
     * @param wrapper direct reference to the service to invoke.
     */
    public static void setServiceGrade(String serviceGrade, ServiceWrapperDef wrapper)
    {
        if (wrapper instanceof ServiceWrapper)
            ((ServiceWrapper)wrapper).setServiceGrade(serviceGrade);
        else
            ((ServiceWrapperLegacy)wrapper).setServiceGrade(serviceGrade);
    }

    /**
     * Set the password that will allow this service to access the server it runs on.
     * @param thePassword the server password.
     * @param wrapper direct reference to the service to invoke.
     * @throws java.lang.Exception any error.
     */
    public static void setServerPassword(String thePassword, ServiceWrapperDef wrapper) throws Exception
    {
        if (wrapper instanceof ServiceWrapper)
            ((ServiceWrapper)wrapper).setServerPassword(thePassword);
        else
            ((ServiceWrapperLegacy)wrapper).setServerPassword(thePassword);
    }

    /**
     * Set the parent component value. If the parent is the ESB server then it is
     * not added, so only for child services.
     * @param thisParent the parent component representation.
     * @param wrapper direct reference to the service to invoke.
     * @return true if set, false if already set, or try to add server.
     */
    public static boolean setParent(Service thisParent, ServiceWrapperDef wrapper)
    {
        if (wrapper instanceof ServiceWrapper)
            return ((ServiceWrapper)wrapper).setParent(thisParent);
        else
            return ((ServiceWrapperLegacy)wrapper).setParent(thisParent);
    }

    /**
     * Add metric or stat values for the message object. The metrics are added to the
     * base service only, or the service directly loaded onto the ESB, not any utility
     * service, so this firstly traverses back o the base service before adding any stats.
     * @param messageInfo the message info with the message object.
     * @param password the password for this service.
     * @param service the service that adds the metrics.
     * @throws java.lang.Exception any error.
     */
    public static void addMessageMetrics(MethodInfo messageInfo, String password, Service service)
            throws Exception {
        service.addMessageMetrics(messageInfo, password);
    }

    /**
     * Add metric or stat values for the message object. The metrics are added to the
     * base service only, or the service directly loaded onto the ESB, not any utility
     * service, so this firstly traverses back o the base service before adding any stats.
     * @param messageInfo the message info with the message object.
     * @param password the password for this service.
     * @param service the service that adds the metrics.
     */
    public static void addMessageMetrics(MethodInfo messageInfo, String password, ServiceWrapperDef service)
    {
        service.addMetrics(messageInfo, password);
    }
}
