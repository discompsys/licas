/*
 * RestMessage.java
 *
 * Created on 23 April 2016
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.call.rest;


/**
 * This store the REST-style message to make a call with.
 * @author Kieran Greer.
 */
public class RestMessage
{
    /** The endpoint uri */
    public String uri;
    
    /** The query string */
    public String query;
    
    /** Call timeout in seconds */
    public int timeOut;
    
    
    /** Create a new instance of RestMessage */
    public RestMessage()
    {
        uri = null;
        query = null;
        timeOut = 0;
    }
    
    
    /**
     * Convert the REST query description into a single string. As the query can include
     * several terms, it must already be encoded for the http protocol.
     * @return a single string-based description that can be executed.
     */
    public String queryString() 
    {
        String queryStr;                    //the query string
        
        queryStr = "";
        if (uri != null) 
        {
            queryStr += uri;
            if ((query != null) && !query.equals(""))
            {
                if (queryStr.endsWith("/"))
                {
                    queryStr = queryStr.substring(0, queryStr.length()-1);
                }
            }
        }
        if (query != null) 
        {
            queryStr += query;
        }
        
        return queryStr;
    }
}
