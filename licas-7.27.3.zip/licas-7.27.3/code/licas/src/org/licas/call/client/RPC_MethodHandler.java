/*
 * RPC_MethodHandler.java
 *
 * Created on 18 February 2007.
 *
 * Version 1.6
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.call.client;


import org.licas.call.*;
import org.licas.def.RemoteCallDef;
import org.licas.util.*;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;


/**
 * This makes a remote rpc method call. This will make either a blocking or a
 * non-blocking call on a remote server using a remote procedure call mechanism.
 * @author Kieran Greer
 */
public final class RPC_MethodHandler implements RemoteCallDef
{
    /** The logger */
    private static final Logger logger;
            
    
    /** The remote call type, for example Const.XML-RPC, REST or SOAP */
    private final String callType;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(RPC_MethodHandler.class.getName());
        logger.setDebug(false);
    }


    /** 
     * Creates a new instance of RPC_MethodHandler.
     */
    public RPC_MethodHandler()
    {
        callType = Const.XMLRPC;
    }
        
    /**
     * Execute a remote call.
     * @param methodInfo the method call description with all of the required information.
     * @return Object the reply to the call.
     */
    public Object execute(MethodInfo methodInfo) throws Exception
    {
        String replyClass;                      //the reply type
        Object reply;                           //reply to the call
        ClientConnection aHandler;              //client handler
        
        try 
        {
            //make remote http request
            replyClass = methodInfo.getRtnType();

            if (replyClass.equals(TypeConst.VOID)) {
                aHandler = new ClientConnectionAsync();
                aHandler.execute(methodInfo);
                return null;
            } else {
                aHandler = new ClientConnectionBlock();
                reply = aHandler.execute(methodInfo);
                return reply;
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "execute", null, ex);
        }
        finally
        {
            aHandler = null;
        }
    }
    
    /**
     * Get the value indicating the type of remote call.
     * @return the value of callType.
     */
    public String getCallType()
    {
        return callType;
    }
}
