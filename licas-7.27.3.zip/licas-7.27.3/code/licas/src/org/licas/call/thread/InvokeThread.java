/*
 * InvokeThread.java
 *
 * Created on 15 August 2016
 *
 * Version 1.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.call.thread;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.call.CallObject;
import org.licas.call.MethodInfo;


/**
 * Runs a single invocation on a separate thread. This can be executed anywhere under any conditions, 
 * and uses a {@link CallObject} to execute the {@link MethodInfo} method. This can include
 * local or remote types of execution, for example.
 * @author Kieran Greer
 */
public abstract class InvokeThread extends Thread
{
    /** The logger */
    private static final Logger logger;
    
    
    /** True if finished. */
    protected boolean finished;
    
    /** Result of executing the method */
    protected Object result;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(InvokeThread.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Create a new instance of InvokeThread.
     */
    public InvokeThread()
    {
        finished = false;
        result = null;
    }

    /**
     * True if the execution process has finished.
     * @return the value of finished.
     */
    public boolean isFinished()
    {
        return finished;
    }
    
    /**
     * Get the method invocation result.
     * @return the value of result. Can also be null if not completed, or the exception
     * if one is thrown, for example.
     */
    public Object getResult()
    {
        return result;
    }
}
