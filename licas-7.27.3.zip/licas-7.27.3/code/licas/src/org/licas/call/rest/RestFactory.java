/*
 * RestFactory.java
 *
 * Created on 25 April 2016
 *
 * Version 1.3.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.call.rest;


import org.licas.call.*;
import org.licas.call.client.Rest_MethodHandler;
import org.licas.parsers.Parsers;
import org.licas.parsers.types.ArrayParser;
import org.licas.server.ServerMethodHandler;
import org.licas.util.*;
import org.licas.ws.WsMethodInfo;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;
import org.jlog2.*;
import org.jlog2.util.StringHandler;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;


/**
 * Factory object for RESTful-style messages. If you do not set an instance of this 
 * in your main program, then it defaults to this class.
 * @author Kieran Greer
 */
public class RestFactory 
{
    /** The logger */
    private static final Logger logger;
      
    /** Rest factory instance */
    private static volatile RestFactory instance = null;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(RestFactory.class.getName());
        logger.setDebug(false);
    }
    
    /** Create a new instance of RestFactory */
    private RestFactory()
    {}
    
    /**
     * Set the rest factory instance if null.
     * @param thisInstance the factory instance.
     */
    public static void setInstance(RestFactory thisInstance)
    {
        if (instance == null) {
            instance = thisInstance;
        }
    }
    
    /**
     * Get the rest factory instance.
     * @return the value of instance.
     */
    public static RestFactory getInstance()
    {
        if (instance == null) {
            synchronized (RestFactory.class) {
                if (instance == null) {
                    instance = new RestFactory();
                }
            }
        }
        
        return instance;
    }
    
    /**
     * Create a string-based RESTful description to invoke the default GET method on a licas service.
     * @param serviceUri the {@link Handle}-based description of the service uri.
     * @param serverPassword the server password. If null, it defaults to {@link Const}.{@code ANON}.
     * @param servicePassword the service password. If null, it defaults to {@link Const}.{@code ANON}.
     * @return a RestFactory-compatible description of the method details. The first element
     * is the service uri, the second is any additional password parameters.
     */
    public RestMessage createRestGET(Element serviceUri, String serverPassword, String servicePassword)
    {
        String password;                        //password
        String restFul;                         //REST description
        RestMessage restMsg;                    //url and message
        
        restMsg = new RestMessage();
        restMsg.uri = Handle.toShort(serviceUri);
        
        password = (serverPassword == null) ? Const.ANON : serverPassword;
        restFul = (Const.SERVERPASSWORDSHORT + "=" + password);
        password = (servicePassword == null) ? Const.ANON : servicePassword;
        restFul += ("&" + Const.SERVICEPASSWORDSHORT + "=" + password);
        restMsg.query = restFul;
        
        return restMsg;
    }

    /**
     * Create a string-based RESTful description of the contents of the method info.
     * NOTE: the values are encoded here. If there is no server URL, then a web service endpoint
     * address is looked for and a rest version of that is constructed, but this is definitely
     * not reliable/compatible and the method works best with the licas method descriptions.
     * @param methodInfo the method info. Null fields are not included.
     * @return a RestFactory-compatible description of the method details. The first element
     * is the server uri, the second is any additional parameters.
     * @throws UnsupportedEncodingException encoding format not supported. UTF-8.
     */
    public RestMessage createRestMessage(WsMethodInfo methodInfo) throws UnsupportedEncodingException
    {
        RestMessage restMsg;                    //url and message

        if (methodInfo.getServerURL() != null)
        {
            restMsg = restFromLicas(methodInfo);
        }
        else
        {
            restMsg = restFromWs(methodInfo);
        }

        return restMsg;
    }

    /**
     * Create a string-based RESTful description of the contents of the method info.
     * This would be from a licas service that uses the standard fields.
     * @param methodInfo the method info. Null fields are not included.
     * @return a RestFactory-compatible description of the method details. The first element
     * is the server uri, the second is any additional parameters.
     * @throws UnsupportedEncodingException encoding format not supported. UTF-8.
     */
    private RestMessage restFromLicas(WsMethodInfo methodInfo) throws UnsupportedEncodingException
    {
        int i;
        boolean isLicas;                        //true if licas-type of message
        String uuid;                            //uuid
        String password;                        //password
        String name;                            //name
        String value;                           //value
        StringBuilder restFul;                  //REST description
        RestMessage restMsg;                    //url and message
        ParamInfo paramInfo;                    //parameter info
        ArrayList<ParamInfo> params;            //parameters list
        
        restMsg = new RestMessage();
        restMsg.uri = methodInfo.getServerURL();
        
        restFul = new StringBuilder();
        uuid = Handle.getLastServiceHandle((Element)methodInfo.getServiceURI());
        isLicas = (uuid != null);
        
        if (isLicas) {
            restFul.append(Const.SERVICESHORT + "=").append(uuid);
            password = (methodInfo.getServerPassword() == null) ? Const.ANON : methodInfo.getServerPassword();
            restFul.append("&" + Const.SERVERPASSWORDSHORT + "=").append(password);
            password = (methodInfo.getPassword() == null) ? Const.ANON : methodInfo.getPassword();
            restFul.append("&" + Const.SERVICEPASSWORDSHORT + "=").append(password);

            if (methodInfo.getName() != null) {
                restFul.append("&" + Const.METHODNAMESHORT + "=").append(methodInfo.getName());
            }
            if (methodInfo.getServiceRtnType() != null) {
                restFul.append("&" + Const.RETURNTYPESHORT + "=").append(methodInfo.getServiceRtnType());
            }
            if (methodInfo.getCallTimeout() > 0) {
                restFul.append("&" + Const.TIMEOUTSHORT + "=").append(String.valueOf(methodInfo.getCallTimeout()));
            }
            if ((methodInfo.getCommunicationID() != null) && 
                !methodInfo.getCommunicationID().equals(Const.ANON)) {
                restFul.append("&" + Const.COMMIDSHORT + "=").append(methodInfo.getCommunicationID());
            }
        }
        
        params = methodInfo.getParams();
        if (params != null) {
            for (i = 0; i < params.size(); i++)
            {
                paramInfo = params.get(i);
                name = null;

                try {
                    name = paramInfo.getName();
                }
                catch (Exception ex) {}

                if (name == null) {
                    name = (Const.PARAMETERSHORT + String.valueOf(i + 1));
                }

                try {
                    if (Parsers.hasParser(paramInfo.getValue().getClass().getName())) {
                        value = Parsers.serializeToString(paramInfo.getValue());
                    }
                    else {
                        value = ObjectHandler.getValue(paramInfo.getValue());
                    }
                }
                catch (Exception ex) {
                    value = String.valueOf(paramInfo.getValue());
                }

                restFul.append("&").append(name).append("=").append(RestFactory.encode(value));
            }
        }
        
        //if starts with & then remove first symbol
        if (restFul.toString().startsWith("&")) {
            restFul = new StringBuilder(restFul.substring(1));
        }
        restMsg.query = restFul.toString();
        if (methodInfo.getCallTimeout() > 0) {
            restMsg.timeOut = methodInfo.getCallTimeout();
        }
        
        return restMsg;
    }

    /**
     * Create a string-based RESTful description of the contents of the method info.
     * This would be for a web services decription that would use other info fields,
     * but it is probably not correct and REST client conversion for Web Services should not
     * use this method.
     * @param methodInfo the method info. Null fields are not included.
     * @return a RestFactory-compatible description of the method details. The first element
     * is the server uri, the second is any additional parameters.
     * @throws UnsupportedEncodingException encoding format not supported. UTF-8.
     */
    private RestMessage restFromWs(WsMethodInfo methodInfo) throws UnsupportedEncodingException
    {
        int i;
        String name;                            //name
        String value;                           //value
        StringBuilder restFul;                  //REST description
        RestMessage restMsg;                    //url and message
        ParamInfo paramInfo;                    //parameter info
        ArrayList<ParamInfo> params;            //parameters list

        restMsg = new RestMessage();
        restMsg.uri = methodInfo.getSoapEndpointAddress();

        restFul = new StringBuilder();
        if (methodInfo.getName() != null) {
            restFul.append("?action=").append(methodInfo.getName());
        }

        params = methodInfo.getParams();
        if (params != null) {
            for (i = 0; i < params.size(); i++)
            {
                paramInfo = params.get(i);
                name = null;
                try {
                    name = paramInfo.getName();
                }
                catch (Exception ex){}

                if (name == null) {
                    name = (Const.PARAMETERSHORT + String.valueOf(i+1));
                }

                try {
                    if (Parsers.hasParser(paramInfo.getValue().getClass().getName())) {
                        value = Parsers.serializeToString(paramInfo.getValue());
                    }
                    else {
                        value = ObjectHandler.getValue(paramInfo.getValue());
                    }
                }
                catch (Exception ex){
                    value = String.valueOf(paramInfo.getValue());
                }

                restFul.append("&").append(name).append("=").append(RestFactory.encode(value));
            }
        }
        if (methodInfo.getWsUsername() != null) {
            restFul.append("&" + Const.WSUSERNAME + "=").append(RestFactory.encode(methodInfo.getWsUsername()));
        }
        if (methodInfo.getWsPassword() != null) {
            restFul.append("&" + Const.WSPASSWORD + "=").append(RestFactory.encode(methodInfo.getWsPassword()));
        }

        //if starts with & then remove first symbol
        if (restFul.toString().startsWith("&")) {
            restFul = new StringBuilder(restFul.substring(1));
        }

        restMsg.query = restFul.toString();
        return restMsg;
    }
    
    /**
     * Create the client rest method handler.
     * @return a rest handler for the communication mechanism.
     */
    public Rest_MethodHandler createRestMethodHandler()
    {
        return new Rest_MethodHandler();
    }
    
    /**
     * Convert the REST-style message back into a method info object.
     * @param restMessage the rest query.
     * @return a method info object with appropriate parameters filled.
     * @throws java.lang.Exception any error.
     */
    public WsMethodInfo toMethodInfo(RestMessage restMessage) throws Exception
    {
        int i;
        boolean serverAccess;                       //true if server access call
        int index;                                  //index
        String name;                                //param name
        String value;                               //param value
        String type;                                //param type
        String message;                             //rest message
        String nextParam;                           //next parameter
        String nextParamType;                       //next parameter type
        String paramValue;                          //parameter value
        String[] paramTypes;                        //list of parameter types
        ArrayList<String> params;                   //parameters list
        ArrayList<String> dParams;                  //direct call parameters list
        Element serviceUri;                         //service uri
        Element valueXml;                           //value as xml
        ParamInfo paramInfo;                        //param info
        WsMethodInfo methodInfo;                    //method info
        ArrayParser arrayParser;                    //array parser
        Object valueObj;                            //value object
        
        methodInfo = new WsMethodInfo();
        methodInfo.setCallType(Const.REST);

        if (restMessage.timeOut > 0) {
            methodInfo.setCallTimeout(restMessage.timeOut * 1000);  
        }
        
        //set URIs, a bit of guess, but can set server through this as looked for
        serviceUri = Handle.createNewUrlHandle(restMessage.uri);
        methodInfo.setServiceURI(serviceUri);
                
        message = decode(restMessage.query);
        if (message.startsWith("/")) message = message.substring(1);
        if (message.startsWith("?")) message = message.substring(1);
        params = StringHandler.tokenize(message, "&", false);
        paramTypes = null;
         
        message = params.get(0);
        serverAccess = notQueryMessage(message);

        //if direct server call, use the GET method with the file address only
        if (serverAccess) {
            //remove the server access part from the other parameters
            params.remove(0);

            //a web call can still contain other information that is not
            //part of the programmed or written call, so need to filter this first
            if (!ServerMethodHandler.serverRequest(message, methodInfo)) {
                //if not a recognised file type then must be a direct service address call
                //this calls the GET method and assumes a String reply
                //tokenize on the file path separator and only consider the first token
                dParams = StringHandler.tokenize(message, "/", false);

                //can test for a GET method call on a service
                methodInfo.setName(MethodConst.GET);

                //can be default passwords and no parameters
                serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(dParams.get(0)));
                methodInfo.setServiceURI(serviceUri);
                methodInfo.setRtnType(TypeConst.STRING);  
            }
        }

        //additional RESTful-style parameters, might still have these with direct call
        if (!params.isEmpty()) {
            for (i = 0; i < params.size(); i++)
            {
                nextParam = params.get(i);

                index = nextParam.indexOf("=");
                if (index > 0) {
                    //key-value pair required for each & entry
                    name = nextParam.substring(0, index);
                    value = nextParam.substring(index+1);
                    value = XmlHandler.removeElementSpecs(value);

                    //default type but this can be changed with a Const.PARAMTYPESSHORT entry
                    if (name.equalsIgnoreCase(Const.SERVICESHORT)) {
                        serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(value));
                        methodInfo.setServiceURI(serviceUri);
                    }
                    else if (name.equalsIgnoreCase(Const.SERVERPASSWORDSHORT)) {
                        methodInfo.setServerPassword(value);
                    }
                    else if (name.equalsIgnoreCase(Const.SERVICEPASSWORDSHORT)) {
                        methodInfo.setPassword(value);
                    }
                    else if (name.equalsIgnoreCase(Const.METHODNAMESHORT)) {
                        methodInfo.setName(value);
                    }
                    else if (name.equalsIgnoreCase(Const.RETURNTYPESHORT)) {
                        methodInfo.setRtnType(value);
                    }
                    else if (name.equalsIgnoreCase(Const.PARAMTYPESSHORT)) {
                        type = "[Ljava.lang.String;";
                        arrayParser = new ArrayParser();

                        //this should be a vector-style string, such as [v1, v2]
                        paramTypes = (String[])arrayParser.parseToArray(type, value);
                    }
                    else if (name.equalsIgnoreCase(Const.TIMEOUTSHORT)) {
                        methodInfo.setCallTimeout((Integer.parseInt(value) * 1000));
                    }
                    else if (name.equalsIgnoreCase(Const.COMMIDSHORT)) {
                        methodInfo.setCommunicationID(value);
                    }
                    else if (name.equalsIgnoreCase(Const.WSUSERNAMESHORT)) {
                        methodInfo.setWsUsername(value);
                    }
                    else if (name.equalsIgnoreCase(Const.WSPASSWORDSHORT)) {
                        methodInfo.setWsPassword(value);
                    }
                    else {
                        try {
                            valueXml = XmlHandler.stringToElement(value);
                            valueObj = Parsers.parse(valueXml);
                        }
                        catch (Exception ex) {
                            valueObj = Parsers.parse(value);
                        }
                        
                        paramInfo = new ParamInfo();
                        paramInfo.setName(name);
                        paramInfo.setValue(valueObj);
                        methodInfo.addParam(paramInfo);
                    }
                }
            }

            //if parameter types have been declared, then try to convert values to those
            if ((paramTypes != null) && (paramTypes.length > 0)) {
                for (i = 0; (i < paramTypes.length) && (i < methodInfo.getParams().size()); i++)
                {
                    nextParamType = paramTypes[i].trim();
                    paramInfo = methodInfo.getParams().get(i);
                    paramValue = (String)paramInfo.getValue();

                    paramInfo.resetValue();                        
                    paramInfo.setValue(createParamValue(nextParamType, paramValue));
                }
            }
        }
        
        return methodInfo;
    }
      
    /**
     * Create the parameter value object based on the data type and the values described as a string.
     * @param paramType the data type. This needs to be a fully qualified description.
     * @param valueStr the values as a string-based description.
     * @return the value string converted into the appropriate object.
     * @throws java.lang.Exception any error.
     */
    private Object createParamValue(String paramType, String valueStr) throws Exception
    {
        Object objValue;                        //data object
        
        objValue = ObjectHandler.valueFromString(paramType, valueStr);
        return objValue;
    }
    
    /**
     * Return true if the message string cannot be a REST-style query, namely,
     * there are no query key-value pairs.
     * @param message the full rest message.
     * @return true if not a query, there are no {@code =} symbols.
     */
    public boolean notQueryMessage(String message)
    {
        return !message.contains("=");
    }
    
    /**
     * Encode the RestFactory-style query URI, to the application/x-www-form-urlencoded MIME format.
     * @param queryUri the rest-style query to encode.
     * @return the encoded query. Do not encode starting http or https.
     * @throws java.io.UnsupportedEncodingException if the encoding is not supported.
     */
    public static String encode(String queryUri) throws UnsupportedEncodingException
    {
        if (queryUri == null) return null;
        else return URLEncoder.encode(queryUri, "UTF-8");
    }
    
    /**
     * Decode the encoded RestFactory-style query URI, from the application/x-www-form-urlencoded MIME format.
     * @param queryUri the rest-style query to decode.
     * @return the decoded query.
     * @throws java.io.UnsupportedEncodingException if the encoding is not supported.
     */
    public static String decode(String queryUri) throws UnsupportedEncodingException
    {
        if (queryUri == null) return null;
        else return URLDecoder.decode(queryUri, "UTF-8");
    }
}
