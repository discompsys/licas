/*
 * InvokeThread.java
 *
 * Created on 15 August 2016
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.call.thread;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.call.CallObject;
import org.licas.call.MethodInfo;
import org.licas.util.TypeConst;


/**
 * Runs a single invocation of a {@link MethodInfo} object on a separate thread. 
 * This can be executed anywhere under any conditions, and uses a {@link CallObject} to execute 
 * the {@link MethodInfo} method. This can include local or remote types of execution, for example.
 * @author Kieran Greer
 */
public final class InvokeMethod extends InvokeThread
{
    /** The logger */
    private static final Logger logger;
       
    /** Info for the method to invoke */
    private final MethodInfo methodInfo;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(InvokeMethod.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Create a new instance of InvokeMethod.
     * @param thisMethodInfo the method to invoke.
     */
    public InvokeMethod(MethodInfo thisMethodInfo)
    {
        super();
        methodInfo = thisMethodInfo;
    }
    
    /** Execute the method */
    public void run()
    {
        boolean voidReply;                  //true if no reply required
        CallObject callObj;                 //the call object
        
        try {
            result = null;
            callObj = new CallObject();
            voidReply = (methodInfo.getRtnType().equals(TypeConst.VOID));
            
            if (voidReply) {
                callObj.call(methodInfo);
            }
            else {
                result = callObj.call(methodInfo);
            }
        }
        catch (Exception ex) {
            result = ex;
        }
        finally {
            finished = true;
        }
    }
}
