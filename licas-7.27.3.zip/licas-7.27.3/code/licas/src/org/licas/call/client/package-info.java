/**
 * Client message invocation classes.
 */
package org.licas.call.client;