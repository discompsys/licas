/*
 * ParamInfo.java
 *
 * Created on 08 November 2006
 *
 * Version 1.5.1
 *
 * Copyright (c) Kieran Greer
 *
 */

package org.licas.call;


import org.licas.parsers.Parsers;
import org.licas.util.Const;
import org.licas.util.ObjectHandler;
import org.licas.util.TypeConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;

import java.util.ArrayList;
import java.util.Vector;


/**
 * This class stores information relating to a single parameter for a method.
 * The parameter value is stored in a ArrayList called {@code values}. This can be the
 * ArrayList list itself, by specifying the parameter type to be a ArrayList. If the
 * parameter type is something else, then the value object is stored in the first
 * element of the values list only and only the first element is returned when the
 * value is requested. Use {@link TypeConst}.{@code VECTOR} to specify a ArrayList value type. If the
 * value is included in the constructor, {@code new ParamInfo(the_value)}, then it is
 * stored in the first element of the values list and the type can be set later.
 * When using as part of a method call, the {@link MethodHandler} checks the parameter type
 * automatically using the Java {@code instanceof} or {@code getClass()} operators and so the constructor 
 * approach is probably best.
 * @author Kieran Greer
 */
public class ParamInfo 
{   
    /** Parameter name */
    protected String name;
    
    /** Parameter type. Set this before adding a value. */
    protected String type;
    
    /** Parameter value */
    protected Object value;
    
    
    /** Creates a new instance of ParamInfo */
    public ParamInfo() 
    {
        name = null;
        type = null;
        value = null;
    }
    
    /**
     * Creates a new instance of ParamInfo.
     * @param valueObj a value to add to values.
     */
    public ParamInfo(Object valueObj) 
    {
        name = null;
        if (valueObj == null) type = null;
        else type = valueObj.getClass().getName();
        value = valueObj;
    }
    
    /**
     * Set the parameter name.
     * @param theName the parameter name.
     */
    public void setName(String theName)
    {
        name = theName;
    }
    
    /**
     * Get the parameter name.
     * @return the value of name.
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Set the parameter type. This is normally set when setting the value,
     * but if the value is purposely different, the type can be set here instead.
     * @param thisType the parameter type.
     */
    public void setType(String thisType)
    {
        type = thisType;
    }
    
    /**
     * Get the parameter type.
     * @return the value of type.
     */
    public String getType()
    {
        return type;
    }
    
    /** Reset value to be {@code null}. */
    public void resetValue()
    {
        value = null;
    }
    
    /** 
     * Set the value to the parameter passed in. This also sets the value type to what
     * the value is, or null if the value is null.
     * @param thisValue the parameter value.
     */
    public void setValue(Object thisValue)
    {
        setValue(thisValue, true);
    }
    
    /** 
     * Set the value to the parameter passed in. This can also set the value type.
     * @param thisValue the parameter value.
     * @param setType if true then also set the type.
     */
    public void setValue(Object thisValue, boolean setType)
    {
        value = thisValue;
        if (value != null) {
            if (setType) type = value.getClass().getName();
        }
        else {
            type = null;
        }
    }
    
    /** 
     * This sets the parameter value if it is currently {@code null}, or it adds the value
     * to a {@code ArrayList} list if it is not null. This method might be used if values
     * are iteratively added over time, maybe from a GUI interface.
     * <p>
     * If the current {@code value} is not a ArrayList, a ArrayList is created, the current 
     * {@code value} is added to it and then the new {@code thisValue}. This is then set 
     * as the parameter value object. The parameter {@code type} is not changed by this method.
     * @param thisValue the parameter value to set/add.
     */
    public void setAddValue(Object thisValue)
    {
        Object currentValue;                    //current value
        
        if (value == null) {
            value = thisValue;
        }
        else {
            if (!(value instanceof ArrayList)) {
                currentValue = value;
                value = new ArrayList<>();
                ((ArrayList)value).add(currentValue);     
            }
            
            ((ArrayList)value).add(thisValue);
        }
    }
    
    /** 
     * Return the parameter value.
     * @return the value of {@code value}, which can be {@code null}.
     */
    public Object getValue()
    {
        return value;
    }
    
    /**
     * Convert the parameter description to a String.
     * @return the parameter description as a String.
     */
    public String toString()
    {
        String paramStr;                //parameter string
        
        paramStr = ("    " + name + ": " + type + "\n");       
        try {
            paramStr += ("        " + ObjectHandler.getValue(value) + "\n");
        }
        catch (Exception ex) {}
        
        return paramStr;
    }
    
    /**
     * Convert the parameter description to an xml element.
     * @return the parameter description as an xml element.
     * @throws java.lang.Exception any error.
     */
    public Element toElement() throws Exception
    {
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        
        rootElem = XMLFactory.getInstance().createElement(Const.PARAMETER);
        if (name != null)
        {
            nextElem = XMLFactory.getInstance().createElement(Const.NAME);
            nextElem.setText(name);
            rootElem.addContent(nextElem);
        }
        if (type != null)
        {
            nextElem = XMLFactory.getInstance().createElement(Const.TYPE);
            nextElem.setText(type);
            rootElem.addContent(nextElem);
        }        
        if (value != null)
        {
            nextElem = XMLFactory.getInstance().createElement(Const.VALUE);
            nextElem.addContent(Parsers.serializeToElement(value));
            rootElem.addContent(nextElem);
        }
        
        return rootElem;
    }
    
    /**
     * Set the values in this ParamInfo object from the XML-based description.
     * @param rootElem the root element with the specific parameter values.
     * @throws java.lang.Exception any error.
     */
    public void fromElement(Element rootElem) throws Exception
    {
        int i;
        Element nextElem;                           //next element
        Vector<Node> elemList;                      //element list
        
        if (rootElem.getName().equals(Const.PARAMETER)) {
            elemList = rootElem.getChildren();

            for (i = 0; i < elemList.size(); i++)
            {
                nextElem = (Element)elemList.get(i);
                if (nextElem.getName().equals(Const.NAME)) {
                    name = nextElem.getText();
                }
                else if (nextElem.getName().equals(Const.TYPE)) {
                    type = nextElem.getText();
                }
                else if (nextElem.getName().equals(Const.VALUE)) {
                    value = Parsers.parse(nextElem.getElementChildAtIndex(0));
                }
            }
        }
    }
    
    /**
     * Return a clone of this object.
     * @return a clone of this object.
     */
    public Object clone()
    {
        ParamInfo cloneObj;                 //clone object
        
        cloneObj = new ParamInfo();
        cloneObj.name = name;
        cloneObj.type = type;
        cloneObj.value = value;
        
        return cloneObj;
    }
}
