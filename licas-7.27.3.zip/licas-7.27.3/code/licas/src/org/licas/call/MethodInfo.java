/*
 * MethodInfo.java
 *
 * Created on 08 November 2006
 *
 * Version 1.8.4
 *
 * Copyright (c) Kieran Greer
 *
 */

package org.licas.call;


import org.licas.Service;
import org.licas.server.LocalServer;
import org.licas.util.Const;
import org.licas.util.ObjectHandler;
import org.licas.util.TypeConst;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;

import java.util.ArrayList;


/**
 * This class stores information relating to a single method of a service. The
 * full description of the method invocation should be specified in this class.
 * Constructing the correct method call can be time consuming, so there is a
 * method {@link MethodFactory}.{@code createMethodCall} that can construct most method call 
 * descriptions automatically. It will format this object correctly with the appropriate values, 
 * based on the parameter values that are passed in. Care must be taken however, because the
 * passwords must already be saved for the server and service to be invoked. 
 * If it is a utility {@code Linker} service, for example, a password might not be saved directly, 
 * where the parent password is required instead. 
 * <p>
 * Manual construction is therefore also possible and may be safer, as you will automatically
 * enter a value for each required field. Something like the following:
 * <p>
 * methodInfo = new MethodInfo(theService);<br>
 * methodInfo.setName(methodName);<br>
 * methodInfo.setServerURL(serverUrl);<br>
 * methodInfo.setServiceURI(serviceUri);<br>
 * methodInfo.setRtnType(rtnType);<br>
 * methodInfo.setServerPassword(serverPassword);<br>
 * methodInfo.setPassword(servicePassword);<br>
 * methodInfo.addParam(param1);<br>
 * methodInfo.addParam(param2);<br>
 * reply = callObject.call(methodInfo);
 * @author Kieran Greer
 */
public class MethodInfo 
{
    /** The timeout amount for synchronous calls */
    private static final int TIMEOUT = 10000;

    /**
     * Set to greater than 0 if maximum packet size required for passing the data.
     * Default of -1 means that the whole message will be passed in one go.
     * Only relates to remote communication 
     */
    private int packetSize;

    /**
     * The maximum allowed amount of time for a synchronous call.
     * Defaults to 10000 milliseconds.
     */
    private int callTimeout;

    /** True if a remote method call */
    private boolean isRemote;

    /** The remote call type, for example Const.XML-RPC, REST or SOAP */
    private String callType;
    
    /** Method name */
    private String name;
    
    /** Return type class definition, can also be for intermediary calls */
    private String rtnType;

    /** Service return type class definition, only for the service method call */
    private String serviceRtnType;

    /** The password for the server to call */
    private String serverPassword;
    
    /** The password for the component to call */
    private String password;
    
    /** The communication id */
    private String communicationID;
    
    /** Parameters. Values are of type ParamInfo. */
    protected ArrayList<ParamInfo> params;

    /** The calling component uri */
    private Element clientUri;

    /** The server http protocol, ip address plus port */
    private String serverUrl;

    /** The uri or direct reference for the current call path */
    private Object serviceUri;

    /** The uri for the rest of the call path */
    private Element restOfServiceUri;


    /** 
     * Creates a new instance of MethodInfo and sets the {@code clientUri} to the server address 
     * if one is running or {@code null} if one is not running.
     * @throws java.lang.Exception any error.
     */
    public MethodInfo() throws Exception
    {
        if (LocalServer.getServerURL() != null) {
            clientUri = Handle.createNewServerHandle(LocalServer.getServerURL());
        }
        else {
            clientUri = null;
        }
        
        initialise();
    }
    
    /** 
     * Creates a new instance of MethodInfo and sets the {@code clientUri} to the local service path.
     * @param thisService the service making the call.
     * @throws java.lang.Exception any error.
     */
    public MethodInfo(Service thisService) throws Exception
    {
        clientUri = thisService.getFullPath();       
        initialise();
    }
    
    /**
     * Initialise some values.
     */
    private void initialise()
    {
        packetSize = Const.ONEPACKET;
        callTimeout = TIMEOUT;
        isRemote = false;
        callType = Const.XMLRPC;
        name = null;
        rtnType = null;
        serviceRtnType = null;
        serverPassword = Const.ANON;
        password = Const.ANON;
        communicationID = Const.ANON;
        params = new ArrayList<>();
        serverUrl = null;
        serviceUri = null;
        restOfServiceUri = null;
    }

    /**
     * Return true if the method does not return a value.
     * @return true fi the method has a void return type.
     */
    public boolean isVoid() {
        return ((rtnType != null) && rtnType.equals(TypeConst.VOID));
    }

    /**
     * Determine if a remote method call.
     * If service uri is not an element then a local call.
     * Is remote if the client and server or service uris are different.
     */
    public void setIfRemote()
    {
        String serviceUrl;                          //service url
        String clientUrl;                           //client url
        
        //assume remote call unless can be made local
        isRemote = true;
        
        if ((serviceUri == null) || !ObjectHandler.isElement(serviceUri)) {
            isRemote = false;
        }
        else if (clientUri != null) {
            if (serverUrl != null) {
                clientUrl = Handle.getURL(clientUri);               
                if (clientUrl != null) {
                    isRemote = !serverUrl.equals(clientUrl);
                }
            }
            else if (serviceUri != null) {
                serviceUrl = Handle.getURL((Element)serviceUri);
                clientUrl = Handle.getURL(clientUri);
                
                if ((serviceUrl != null) && (clientUrl != null)) {
                    isRemote = !serviceUrl.equals(clientUrl);
                }
            }
        }
    }
    
    /**
     * Update the service uris to have the correct values.
     */
    public void updateServiceURIs()
    {
        if (serviceUri == null)
        {
            serviceUri = restOfServiceUri;
            restOfServiceUri = null;
        }
    }

    /**
     * Set the packet size to the value passed in.
     * @param thePacketSize the packet size, or maximum number of characters in a
     * message transaction.
     */
    public void setPacketSize(int thePacketSize)
    {
        packetSize = thePacketSize;
    }

    /**
     * Get the packet size.
     * @return the value of packetSize.
     */
    public int getPacketSize()
    {
        return packetSize;
    }

    /**
     * Set the maximum allowed amount of time for a synchronous call.
     * This is in milliseconds (thousands of a second), so 10000 equals 10 seconds.
     * @param theCallTimeout the maximum allowed amount of time for a synchronous call.
     */
    public void setCallTimeout(int theCallTimeout)
    {
        callTimeout = theCallTimeout;
    }

    /**
     * Get the maximum allowed amount of time for a synchronous call.
     * This is in milliseconds (thousands of a second), so 10000 equals 10 seconds.
     * @return the value of callTimeout.
     */
    public int getCallTimeout()
    {
        return callTimeout;
    }

    /**
     * Get the value indicating if a remote service method call.
     * @return the value of isRemote.
     */
    public boolean getIsRemote()
    {
        return isRemote;
    }
    
    /**
     * Set the value indicating the type of remote call.
     * @param thisCallType the type of remote call.
     */
    public void setCallType(String thisCallType)
    {
        callType = thisCallType;
    }
    
    /**
     * Get the value indicating the type of remote call.
     * @return the value of callType.
     */
    public String getCallType()
    {
        return callType;
    }
    
    /**
     * Set the method name.
     * @param theName the method name. Can also include service names.
     */
    public void setName(String theName)
    {
        name = theName;
    }
    
    /**
     * Get the method name.
     * @return the value of name.
     */
    public String getName()
    {
        return name;
    }

    /**
     * Set the return type, can also be for intermediary service calls.
     * @param theRtnType the fully qualified class name of the return type.
     */
    public void setRtnType(String theRtnType)
    {
        rtnType = theRtnType;
        if (serviceRtnType == null) serviceRtnType = rtnType;
    }

    /**
     * Get the return type, can also be for intermediary service calls..
     * @return the value of rtnType.
     */
    public String getRtnType()
    {
        return rtnType;
    }
    
    /**
     * Set the service return type, for the service method call only.
     * @param theRtnType the fully qualified class name of the return type.
     */
    public void setServiceRtnType(String theRtnType)
    {
        serviceRtnType = theRtnType;
    }
    
    /**
     * Get the service return type, for the service method call only.
     * @return the value of serviceRtnType.
     */
    public String getServiceRtnType()
    {
        return serviceRtnType;
    }
    
    /**
     * Set the server password.
     * @param theServerPassword the password to allow access to the server to call.
     */
    public void setServerPassword(String theServerPassword)
    {
        serverPassword = theServerPassword;
    }
    
    /**
     * Get the server password.
     * @return the value of serverPassword.
     */
    public String getServerPassword()
    {
        return serverPassword;
    }
    
    /**
     * Set the service password.
     * @param thePassword the password to allow access to the service to call.
     */
    public void setPassword(String thePassword)
    {
        password = thePassword;
    }
    
    /**
     * Get the service password.
     * @return the value of password.
     */
    public String getPassword()
    {
        return password;
    }
    
    /**
     * Set the communication id.
     * @param theCommunicationID a unique id to identify the communication.
     */
    public void setCommunicationID(String theCommunicationID)
    {
        communicationID = theCommunicationID;
    }
    
    /**
     * Get the communication id.
     * @return the value of communicationID.
     */
    public String getCommunicationID()
    {
        return communicationID;
    }
    
    /**
     * Clear the list of method parameters.
     */
    public void clearParams()
    {
        params.clear();
    }
    
    /**
     * Add a method parameter.
     * @param theParam the parameter to add. If it is not of type ParamInfo, then
     * it will be wrapped inside of a ParamInfo object.
     */
    public void addParam(Object theParam)
    {
        ParamInfo nextParam;                                //next parameter
        
        if (theParam instanceof ParamInfo) {
            params.add((ParamInfo)theParam);
        }
        else {
            nextParam = new ParamInfo(theParam);
            params.add(nextParam);
        }
    }
    
    /**
     * Get the parameter with the specified name, case ignored.
     * @param paramName the name of the parameter.
     * @return the parameter object, or null if one does not exist.
     */
    public ParamInfo getParameter(String paramName)
    {
        int i;
        ParamInfo paramInfo;                    //next parameter

        for (i = 0; i < params.size(); i++)
        {
            paramInfo = params.get(i);
            if (paramInfo.getName().equalsIgnoreCase(paramName)) {
                return paramInfo;
            }
        }

        return null;
    }
    
    /**
     * Get the method parameters.
     * @return the value of params. Values are of type ParamInfo.
     */
    public ArrayList<ParamInfo> getParams()
    {
        return params;
    }

    /**
     * Convert the method parameters into a vector of parameter objects.
     * @return the parameter values as a list.
     */
    public ArrayList<Object> getParamValues()
    {
        int i;
        ArrayList<Object> paramObjs;            //parameter object list
        ParamInfo paramInfo;                    //next parameter

        paramObjs = new ArrayList<>();
        for (i = 0; i < params.size(); i++)
        {
            paramInfo = params.get(i);
            paramObjs.add(paramInfo.getValue());
        }

        return paramObjs;
    }

    /**
     * Set the uri for the client service.
     * @param theClientUri the full uri path to the client service.
     */
    public void setClientURI(Element theClientUri)
    {
        clientUri = theClientUri;
    }

    /**
     * Get the full uri path to the client service.
     * @return the value of clientUri.
     */
    public Element getClientURI()
    {
        return clientUri;
    }

    /**
     * Set the url for the server from the full uri address. 
     * This is just the http protocol, ip address plus port and not the whole handle.
     * @param theServerUri the full uri path to the server to call.
     */
    protected void setServerURL(Element theServerUri)
    {
        if (serverUrl == null) {
            serverUrl = Handle.getURL(theServerUri);
            checkServerURL();
        }
    }

    /**
     * Get the http address of the server.
     * @return the value of serverUrl.
     */
    public String getServerURL()
    {
        checkServerURL();
        return serverUrl;
    }

    /** Check the server url format. */
    protected void checkServerURL()
    {
        if ((serverUrl != null) && !serverUrl.endsWith("/")) serverUrl += "/";
    }

    /**
     * Set the uri for the current call path.
     * @param theServiceUri the full uri path for the current call.
     * @throws java.lang.Exception any error.
     */
    public void setServiceURI(Object theServiceUri) throws Exception
    {
        serviceUri = theServiceUri;
        if (ObjectHandler.isElement(theServiceUri)) {
            setServerURL((Element)theServiceUri);
        }
    }
    
    /**
     * Set a direct reference to a service object. This actually calls {@code setServiceURI}
     * as the service setting is now the object itself, but its use is for a direct reference.
     * @param theServiceObj the service object to execute on.
     * @throws java.lang.Exception any error.
     */
    public void setServiceObj(Object theServiceObj) throws Exception
    {
        setServiceURI(theServiceObj);
    }

    /**
     * Get the full current call uri path.
     * @return the value of serviceUri.
     */
    public Object getServiceURI()
    {
        return serviceUri;
    }

    /**
     * Set the uri for the rest of the service call path.
     * @param theServiceUri the full uri path for the rest of the service call.
     */
    public void setRestOfServiceURI(Element theServiceUri)
    {
        restOfServiceUri = theServiceUri;      
        setServerURL(theServiceUri);
        if (serviceUri == null) serviceUri = restOfServiceUri;
    }

    /**
     * Get the full uri path for the rest of the service call.
     * @return the value of serviceUri.
     */
    public Element getRestOfServiceURI()
    {
        return restOfServiceUri;
    }
    
    /**
     * Get the method parameter types as an ordered a list. This is for
     * the actual parameter object instances and not the stored type field.
     * If the value is {@code null}, it is replaced with {@code Object.class}.
     * @return the parameter types as a list.
     */
    public ArrayList<String> objParameterTypes()
    {
        int i;
        String nextType;                        //next type
        ArrayList<String> paramTypes;           //parameter type list
        ParamInfo paramInfo;                    //next parameter

        paramTypes = new ArrayList<>();
        for (i = 0; i < params.size(); i++)
        {
            paramInfo = params.get(i);
            if (!ObjectHandler.isNull(paramInfo.getValue())) {
                nextType = paramInfo.getValue().getClass().getName();
            }
            else {
                nextType = Object.class.getName();
            }
            
            paramTypes.add(nextType);
        }

        return paramTypes;
    }
    
    /**
     * Copy the values from the method info passed in to this object.
     * @param copyInfo the info object to copy.
     */
    public void copyValues(MethodInfo copyInfo)
    {
        packetSize = copyInfo.packetSize;
        callTimeout = copyInfo.callTimeout;
        callType = copyInfo.callType;
        name = copyInfo.name;
        rtnType = copyInfo.rtnType;
        serviceRtnType = copyInfo.serviceRtnType;
        serverPassword = copyInfo.serverPassword;
        password = copyInfo.password;
        communicationID = copyInfo.communicationID;

        clientUri = copyInfo.clientUri;
        restOfServiceUri  = copyInfo.restOfServiceUri;
        serviceUri = copyInfo.serviceUri;
        serverUrl = copyInfo.serverUrl;

        if (copyInfo.params.size() > 0) {
            params = (ArrayList)copyInfo.params.clone();
        }
        else {
            params = copyInfo.params;
        }

        setIfRemote();
    }
    
    /**
     * Return a clone of this MethodInfo object.
     * @return a clone of this object.
     */
    public Object clone()
    {
        int i;
        MethodInfo newMethodInfo;               //new method info
        
        try {
            newMethodInfo = new MethodInfo();

            newMethodInfo.setPacketSize(packetSize);
            newMethodInfo.setCallTimeout(callTimeout);
            newMethodInfo.setCallType(callType);
            newMethodInfo.setName(name);
            newMethodInfo.setRtnType(rtnType);
            newMethodInfo.setServiceRtnType(serviceRtnType);
            newMethodInfo.setServerPassword(serverPassword);
            newMethodInfo.setPassword(password);
            newMethodInfo.setCommunicationID(communicationID);

            if (clientUri != null) {
                newMethodInfo.setClientURI((Element)clientUri.clone());
            }
            if (restOfServiceUri != null) {
                newMethodInfo.setRestOfServiceURI((Element)restOfServiceUri.clone());
            }
            if (ObjectHandler.isElement(serviceUri)) {
                newMethodInfo.setServiceURI(((Element)serviceUri).clone());
            }
            else {
                newMethodInfo.setServiceURI(serviceUri);
            }

            if (params.size() > 0) {
                for (i = 0; i < params.size(); i++)
                {
                    newMethodInfo.addParam(params.get(i));
                }
            }

            newMethodInfo.setIfRemote();
            
            return newMethodInfo;
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    /**
     * Convert the method info to a String.
     * @return the description as a String.
     */
    public String toString()
    {
        int i;
        StringBuilder methodStr;                //description as a string
        ParamInfo nextParam;                    //next parameter
        
        methodStr = new StringBuilder();
        methodStr.append("Method name: ").append(name).append("\n");
        methodStr.append("Method return type: ").append(serviceRtnType).append("\n");
        methodStr.append("Method intermediary return type: ").append(rtnType).append("\n");
        methodStr.append("Server Password: ").append(serverPassword).append("\n");
        methodStr.append("Password: ").append(password).append("\n");

        try {
            methodStr.append("Client uri: ").append(XmlHandler.xmlToString(clientUri)).append("\n");
        } catch (Exception ex) {}

        methodStr.append("Server uri: ").append(serverUrl).append("\n");
        
        try {
            methodStr.append("Service uri: ").append(ObjectHandler.getValue(serviceUri)).append("\n");
        } catch (Exception ex) {}

        try {
            methodStr.append("Rest of service uri: ").append(XmlHandler.xmlToString(restOfServiceUri)).append("\n");
        } catch (Exception ex) {}
        
        methodStr.append("Communication id: ").append(communicationID).append("\n");
        methodStr.append("Packet size: ").append(packetSize).append("\n");
        methodStr.append("Call timeout: ").append(callTimeout).append("\n");

        if (params.size() > 0) {
            for (i = 0; i < params.size(); i++)
            {
                nextParam = params.get(i);
                methodStr.append(nextParam.toString());
            }
        }
        else {
            methodStr.append("No parameters entered\n\n");
        }
        
        return methodStr.toString();
    }
}
