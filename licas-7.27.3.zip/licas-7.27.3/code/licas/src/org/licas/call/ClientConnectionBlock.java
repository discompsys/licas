/*
 * ClientConnectionBlock.java
 *
 * Created on 5 March 2020.
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.call;


import org.licas.parsers.Parsers;
import org.licas.server.model.HttpEntity;
import org.licas.util.*;
import org.licas_internet.util.HttpConst;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.StandardSocketOptions;
import java.net.URL;
import java.nio.channels.SocketChannel;


/**
 * This class manages the connection and thread to process a blocking http client request and reply.
 * This uses the classical blocking model, with Data input and output streams.
 * @author Kieran Greer
 */
public class ClientConnectionBlock extends ClientConnection
{
    /** The logger */
    private final static Logger logger;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ClientConnectionBlock.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of ClientConnectionBlock.
     */
    public ClientConnectionBlock()
    {}

    /**
     * Execute the http blocking client request in a new thread. This will send some data and
     * then wait for a reply, parse the reply and return as an Object.
     * @param methodInfo the method call description with all of the required information.
     * @return Object the reply to the call.
     * @throws Exception any error.
     */
    public Object execute(final MethodInfo methodInfo) throws Exception
    {
        final Boolean[] finished;           //indicates op finished
        final Object[] result;              //stores the result
        final Thread connThread;            //to run the client on

        result = new Object[1];
        result[0] = null;
        finished = new Boolean[1];
        finished[0] = false;

        connThread = new Thread(() -> {
            boolean isVoid;                             //true if no return type
            String uri;                                 //server uri
            String line;                                //message line
            String message;                             //full message to send
            final URL url;                              //the url
            SocketChannel channel;                      //comm channel
            HttpEntity httpEntity;                      //request message
            BufferedReader in;                          //input stream
            DataOutputStream out;                       //output stream
            Object reply;                               //reply to the call

            reply = null;
            channel = null;
            in = null;
            out = null;
            isVoid = false;

            try
            {
                try
                {
                    isVoid = methodInfo.getRtnType().equalsIgnoreCase(TypeConst.VOID);
                    uri = methodInfo.getServerURL();
                    url = new URL(uri);

                    httpEntity = new HttpEntity(Const.XMLRPC, HttpConst.POST);
                    httpEntity.setValue(methodInfo);
                    message = Parsers.serializeToString(httpEntity);

                    //connect to the server
                    channel = connect(url);

                    out = new DataOutputStream(channel.socket().getOutputStream());
                    out.writeBytes(message);
                    out.flush();
                    channel.socket().shutdownOutput();

                    //wait for reply
                    reply = "";
                    in = new BufferedReader(new InputStreamReader(new DataInputStream(channel.socket().getInputStream())));
                    while ((line = in.readLine()) != null) {
                        if (line.equalsIgnoreCase("")) break;
                        reply += line;
                    }
                    channel.socket().shutdownInput();

                    //parse reply back into object and return
                    reply = MethodFactory.parseReply(reply);
                }
                catch (java.net.SocketException soex)
                {
                    throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                            (methodInfo.getServerURL() + ": "), null, soex);
                }
                catch (java.net.SocketTimeoutException stex)
                {
                    //if non-blocking call then ignore, otherwise log error
                    if (isVoid) throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                            (methodInfo.getServerURL() + ": "), null, stex);
                }
                catch (IOException ioex)
                {
                    throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                            (methodInfo.getServerURL() + ": "), null, ioex);
                }
                catch (Exception ex)
                {
                    throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                            (methodInfo.getServerURL() + ": "), null, ex);
                }
                finally
                {
                    if (in != null)
                    {
                        try {
                            in.close();
                        } catch (Exception ex) {}
                    }
                    if (out != null)
                    {
                        try {
                            out.close();
                        } catch (Exception ex) {}

                    }
                    if (channel != null)
                    {
                        try {
                            channel.shutdownInput();
                        } catch (Exception ex) {}

                        try {
                            channel.shutdownOutput();
                        } catch (Exception ex) {}

                        try {
                            channel.close();
                        } catch (Exception ex) {}
                    }
                }

                result[0] = reply;
            }
            catch (Exception ex) {}

            finished[0] = true;
        });
        connThread.start();
        connThread.join();

        return result[0];
    }

    /**
     * Make an asynchronous connection and return the channel.
     * @param url the remote address to connect with.
     * @return new channel connected to the remote address.
     * @throws Exception any error.
     */
    private SocketChannel connect(URL url) throws Exception
    {
        SocketAddress addr;                     //remote address
        SocketChannel channel;                  //the channel

        channel = SocketChannel.open();
        channel.setOption(StandardSocketOptions.SO_RCVBUF, Const.BUFFERSIZE);
        channel.setOption(StandardSocketOptions.SO_REUSEADDR, true);
        channel.setOption(StandardSocketOptions.TCP_NODELAY, true);
        channel.configureBlocking(true);

        addr = new InetSocketAddress(url.getHost(), url.getPort());
        channel.connect(addr);

        return channel;
    }
}
