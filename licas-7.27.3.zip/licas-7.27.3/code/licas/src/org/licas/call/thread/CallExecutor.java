/*
 * CallExecutor.java
 *
 * Created on 30 June 2015
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 *
 */

package org.licas.call.thread;


import org.licas.call.MethodInfo;
import org.licas.util.exception.ServiceException;
import org.licas.util.ServiceConst;
import org.jlog2.*;

import java.util.concurrent.*;


/**
 * This class implements the {@code ExecutorService} interface, to allow execution of
 * the client method on a thread pool.
 * @author Kieran Greer.
 */
public final class CallExecutor 
{
    /** The logger */
    private static final Logger logger;
    
    /** Executes the method calls on a thread pool */
    private final ExecutorService exeService;
    
    /** Single instance of the class */
    private static volatile CallExecutor callExecutor = null;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(CallExecutor.class.getName());
        logger.setDebug(false);       
    }
    
    
    /**
     * Create a new instance of CallExecutor.
     * @param numberOfThreads number of threads in the pool.
     */
    private CallExecutor(int numberOfThreads)
    {
        exeService = Executors.newFixedThreadPool(numberOfThreads);
    }
    
    /** 
     * Create the CallExecutor instance with a default number of threads, for example {@link ServiceConst}.{@code CALLTHREADS}.
     * The executor is created only once and so the number of threads can be set only at the start.
     */
    public static void setInstance()
    {
        if (callExecutor == null) {
            synchronized(CallExecutor.class) {
                if (callExecutor == null) {
                    callExecutor = new CallExecutor(ServiceConst.CALLTHREADS);
                }
            }
        }
    }

    /**
     * Create the CallExecutor instance with the indicated number of threads.
     * The executor is created only once and so the number of threads can be set only at the start.
     * @param numberOfThreads number of threads in the pool.
     */
    public static void setInstance(int numberOfThreads)
    {
        if (callExecutor == null) {
            synchronized(CallExecutor.class) {
                if (callExecutor == null) {
                    callExecutor = new CallExecutor(numberOfThreads);
                }
            }
        }
    }

    /**
     * Get the CallExecutor instance. If {@code null} then a default instance is created.
     * @return the call executor instance.
     */
    public static CallExecutor getInstance()
    {
        if (callExecutor == null) {
            setInstance();
        }

        return callExecutor;
    }
    
    /**
     * Retrieve the correct object and make a call on it.
     * @param methodInfo the method description.
     * @return Object the reply, or null if there is an error.
     * @throws java.lang.Exception any error.
     */
    public Object execute(MethodInfo methodInfo) throws Exception
    {
        CallThread callThread;                  //stores call thread
        FutureTask future;                      //executor reply
         
        try
        {
            callThread = new CallThread(methodInfo);
            future = new FutureTask(callThread);
            exeService.submit(future);

            return future.get();
        }
        catch (ExecutionException e)
        {
            Throwable cause = e.getCause();
            if (cause instanceof ServiceException) {
                return null;
            }
            else {
                throw e;
            }
        }
    }
}
