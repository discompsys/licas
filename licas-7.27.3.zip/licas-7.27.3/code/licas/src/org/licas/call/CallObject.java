/*
 * CallObject.java
 *
 * Created on 18 February 2007
 *
 * Version 1.6.2
 *
 * Copyright (c) Kieran Greer
 *
 */

package org.licas.call;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.call.client.Rest_MethodHandler;
import org.licas.call.thread.CallExecutor;
import org.licas.util.Const;
import org.licas.util.exception.LicasException;
import org.licas.util.exception.ServiceException;


/**
 * This class is used to execute a method call on a local or remote service, or on any Object. 
 * If the services are running on the same server, then the call can be local, through
 * either a direct reference to the service, or through server lookup using the service address. 
 * If the call is remote - to a different server, then a remote method handler is created 
 * that can invoke the remote server with the method invocation instructions.
 * Any other object can also be invoked through {@code Reflection}.
 * <p>
 * The method invocation is now done using the java concurrent classes of 1.5+, 
 * where a {@code Callable} and {@code Future} interfaces are used to execute the 
 * methods on a managed thread pool. This is the main calling mechanism that makes a 
 * single invocation on a single object. See also {@link CallPool} for a managed pool
 * of CallObjects.
 * @author Kieran Greer
 */
public final class CallObject 
{    
    /** The logger */
    private static Logger logger;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(CallObject.class.getName());
        logger.setDebug(false);
    }


    /** Creates a new instance of CallObject */
    public CallObject()
    {}
    
    /**
     * Retrieve the correct communication object and make a call using it. With the mobile
     * platform, {@code REST} communication works best and so it may be necessary to use a
     * {@link Rest_MethodHandler} and parse the String reply. In that case, the operating system
     * would be defined as Android ({@link Const}.{@code OS} = {@code Const.ANDROID}).
     * @param methodInfo the method description.
     * @return the reply as any object.
     * @throws LicasException if the call handle has not been properly constructed.
     * @throws ServiceException probably for password or service not found.
     * @throws java.lang.Exception any other error.
     */
    public Object call(MethodInfo methodInfo) throws LicasException, ServiceException, Exception
    {
        //cannot convert for mobile here, because the call may be a direct reference,
        //and the rest reply is always a string
        return CallExecutor.getInstance().execute(methodInfo);
    }
}
