/*
 * CallPool.java
 *
 * Created on 16 August 2016
 *
 * Version 1.4
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.call;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.autonomic.script.AutoInvoke;
import org.licas.call.thread.InvokeAutoMethod;
import org.licas.call.thread.InvokeMethod;
import org.licas.call.thread.InvokeThread;
import org.licas.util.ThreadHandler;

import java.util.*;


/**
 * This stores a pool of {@link MethodInfo}s allowing for several object or communication
 * invocations to be run at the same time, each run in a separate {@link InvokeThread}. 
 * There is a single execution option, or a timed loop option, for repeating each call. 
 * There is also the option for making a callback to the invoking object, to notify it 
 * when each execution phase has completed. That is - after one complete cycle through 
 * executing each of the methods.
 * @author Kieran Greer
 */
public final class CallPool implements AutoCloseable
{
    /** The logger */
    private static final Logger logger;
    
    
    /** Thread sleep time, in milliseconds (*1000) */
    private int sleepTime;
    
    /** True if shut down the thread. */
    private boolean shutDown;
    
    /** True if started. */
    private boolean started;
    
    /** List of call objects to invoke */
    private final HashMap<String, ?> methodInfos;
    
    /** All call threads */
    private HashMap<String, InvokeThread> callThreads;
    
    /** Result of executing the methods */
    private final HashMap<String, Object> results;
    
    /** Callback method to execute on the main service */
    private final MethodInfo callback;
    
    /** Object to synchronize on */
    private final Object syncOn = new Object();
        
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(CallPool.class.getName());
        logger.setDebug(false);
    }

    
    /**
     * Create a new instance of CallPool. This sets the callback method to null, or
     * does not perform any callback.
     * @param theMethodInfos the list of methods to invoke. The key is a unique identifier
     * and the value is of type {@link MethodInfo}.
     */
    public CallPool(HashMap<String, MethodInfo> theMethodInfos)
    {
        started = false;
        shutDown = false;
        methodInfos = theMethodInfos;
        callThreads = new HashMap<>();
        results = new HashMap<>();
        callback = null;
    }
    
    /**
     * Create a new instance of CallPool.
     * @param theMethodInfos the list of methods to invoke. The key is a unique identifier
     * and the value is of type {@link MethodInfo}.
     * @param theCallback the method to invoke on the parent object after each execution
     * phase.
     */
    public CallPool(HashMap<String, MethodInfo> theMethodInfos, MethodInfo theCallback)
    {
        started = false;
        shutDown = false;
        methodInfos = theMethodInfos;
        callThreads = new HashMap<>();
        results = new HashMap<>();
        callback = theCallback;
    }
    
    /**
     * Perform just one cycle through executing each method and try the callback method 
     * at the end.
     */
    public void executeOnce()
    {
        try {
            executeLoop(-1);
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "executeOnce",
                "", ex);
        }
        finally {
            shutDown();
        }
    }

    /**
     * Perform one cycle through executing each method and try the callback method
     * at the end, then repeat this indefinitely with a timed delay between each
     * execution phase. Note that results are overwritten each execution phase.
     * @param thisSleepTime the time to sleep between each execution phase of all methods.
     */
    public void executeLoop(int thisSleepTime)
    {
        int i;
        String nextKey;                         //next key
        List<String> allKeys;                   //all keys
        Object methodInfo;                      //method type to execute
        InvokeThread toInvoke;                  //call object
        Object result;                          //call result

        sleepTime = thisSleepTime;
        started = true;
        setShutDown(false);

        while (!getShutDown())
        {
            try {
                synchronized (syncOn)
                {
                    callThreads = new HashMap<>();
                    results.clear();

                    for (String key: methodInfos.keySet())
                    {
                        methodInfo = methodInfos.get(key);
                        callThreads.put(key, createThread(methodInfo));
                    }
                }

                synchronized (syncOn)
                {
                    allKeys = new ArrayList<>(callThreads.keySet());
                    for (i = 0; !getShutDown() && (i < allKeys.size()); i++)
                    {
                        nextKey = allKeys.get(i);
                        toInvoke = callThreads.get(nextKey);
                        toInvoke.start();
                    }

                    //join on all threads to wait until all completed
                    for (i = 0; !getShutDown() && (i < allKeys.size()); i++)
                    {
                        nextKey = allKeys.get(i);
                        toInvoke = callThreads.get(nextKey);
                        toInvoke.join();
                    }
                }

                //check that all threads have completed
                for (i = 0; i < allKeys.size(); i++)
                {
                    nextKey = allKeys.get(i);
                    if (callThreads.containsKey(nextKey)) {
                        toInvoke = callThreads.get(nextKey);

                        if (toInvoke.isFinished()) {
                            synchronized (syncOn)
                            {
                                result = toInvoke.getResult();
                                if (result != null) results.put(nextKey, result);
                            }
                        }
                    }
                }

                //try callback method if indicated
                //shutdown relates to current iteration, not an error
                if (!getShutDown()) {
                    tryCallback();
                }

                //check if shutdown or delay
                ThreadHandler.notifyAllEvents();
                if (!getShutDown()) setShutDown(sleepTime <= 0);
                if (!getShutDown()) Thread.sleep(sleepTime);
            }
            catch (Exception ex) {
                shutDown();
                ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "executeLoop",
                        "", ex);
            }
        }
    }
    
    /**
     * If the callback method is not null, try to execute it.
     */
    protected void tryCallback()
    {
        CallObject callObj;
        
        try {
            if (callback != null) {
                callObj = new CallObject();
                callObj.call(callback);
            }
        }
        catch (Exception ex) {}
    }
    
    /**
     * Reset the loop delay time.
     * @param thisSleepTime the time to sleep between execution phases.
     */
    public void resetTimeInterval(int thisSleepTime)
    {
        sleepTime = thisSleepTime;
        setShutDown(sleepTime <= 0);
    }
    
    /**
     * Get the key list for the methods to execute.
     * @return the list of {@code methodInfos} keys. Not the callback method.
     */
    public ArrayList<String> getKeys()
    {
        return new ArrayList<>(methodInfos.keySet());
    }
    
    /**
     * Get the method invocation result for a particular method. This will then also 
     * reset the result value to null once retrieved. If there is no stored result,
     * (or if it was null) then null is returned.
     * @param key the key for the result entry.
     * @return the value of the result. 
     */
    public Object getResult(String key)
    {
        Object result;                      //result to return
        
        result = null;
        synchronized (syncOn)
        {
            if (results.containsKey(key)) {
                result = results.get(key);
                results.remove(key);
            }
        }
        
        return result;
    }
    
    /**
     * Get the full method invocation result set, as a cloned HashMap.
     * @return the value of results. If a reply was null, then the entry will be missing.
     */
    public HashMap<String, Object> getResults()
    {
        synchronized (syncOn)
        {
            if (results != null) {
                return (HashMap)results.clone();
            }
            else {
                return null;
            }
        }
    }
    
    /**
     * Indicates if the loop has started.
     * @return the value of started.
     */
    public boolean getStarted()
    {
        return started;
    }
    
    /**
     * Create the appropriate thread object and return. Can be {@link InvokeMethod} or
     * {@link InvokeAutoMethod}.
     * @param toInvoke the object that is used for the method execution. Can be {@link MethodInfo} or
     * {@link AutoInvoke}.
     * @return the created thread.
     */
    private InvokeThread createThread(Object toInvoke)
    {
        if (toInvoke instanceof AutoInvoke) {
            return new InvokeAutoMethod((AutoInvoke)toInvoke);
        }
        else {
            return new InvokeMethod((MethodInfo)toInvoke);
        }
    }
    
    /**
     * Create a new instance of CallPool and synchronize a loop execution with the
     * construction process. This should be more thread-safe.
     * @param theMethodInfos the list of methods to invoke. The key is a unique identifier
     * and the value is of type {@link MethodInfo}.
     * @param theCallback the method to invoke on the parent object after each execution
     * phase.
     * @param thisSleepTime the time to sleep between each execution phase of all methods.
     * @return the CallPool object, initialised and running.
     */
    public static CallPool syncExecuteLoop(HashMap<String, MethodInfo> theMethodInfos,
                                           MethodInfo theCallback, final int thisSleepTime)
    {
        final CallPool callPool;                //the call pool
        
        try {
            callPool = new CallPool(theMethodInfos, theCallback);
            new Thread(() -> callPool.executeLoop(thisSleepTime)).start();

            //wait for start confirmation
            while (!callPool.getStarted()) Thread.sleep(10);

            return callPool;
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "syncExecuteLoop",
                "", ex);
        }
        
        return null;
    }
    
    /**
     * Create a new instance of CallPool and synchronize a single execution with the
     * construction process. This should be more thread-safe.
     * @param theMethodInfos the list of methods to invoke. The key is a unique identifier
     * and the value is of type {@link MethodInfo}.
     * @param theCallback the method to invoke on the parent object after each execution
     * phase.
     * @return the CallPool object, initialised and running.
     */
    public static CallPool syncExecuteOnce(HashMap<String, MethodInfo> theMethodInfos, MethodInfo theCallback)
    {
        final CallPool callPool;                //the call pool
        
        try {
            callPool = new CallPool(theMethodInfos, theCallback);
            new Thread(callPool::executeOnce).start();

            //wait for start confirmation
            while (!callPool.getStarted()) Thread.sleep(10);

            return callPool;
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "syncExecuteOnce",
                "", ex);
        }
        
        return null;
    }

    /**
     * Shut down the whole CallPool thread.
     */
    public void shutDown()
    {
        shutDown = true;
    }

    /**
     * Set the shut down variable to value passed in.
     * @param thisShutDown true if shut down, false if keep running.
     */
    protected void setShutDown(boolean thisShutDown)
    {
        shutDown = thisShutDown;
    }

    /**
     * Get the current CallPool status.
     * @return the value of shutDown.
     */
    public boolean getShutDown()
    {
        return shutDown;
    }

    /**
     * Clean-up before shutting down the service.
     */
    public void close()
    {
        InvokeThread toInvoke;              //invoke thread
        
        try {
            if (callThreads != null) {
                for (String key: callThreads.keySet())
                {
                    toInvoke = callThreads.get(key);
                    try {
                        toInvoke.interrupt();
                    }
                    catch (Exception ex)
                    {}
                }
            }
        }
        catch (Exception ex) {}
        finally {
            callThreads = null;
        }
    }
}
