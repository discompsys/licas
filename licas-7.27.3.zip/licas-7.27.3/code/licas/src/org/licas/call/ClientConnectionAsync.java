/*
 * ClientConnectionAsync.java
 *
 * Created on 3 March 2020.
 *
 * Version 1.0.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.call;


import org.licas.parsers.Parsers;
import org.licas.server.model.*;
import org.licas.util.*;
import org.licas_internet.util.HttpConst;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.licas_xml.model.XmlHandler;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.StandardSocketOptions;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;


/**
 * This class manages the connection and thread to process a non-blocking http client request and reply.
 * This uses the asynchronous Java {@code nio} classes, with a {@code ByteBuffer} and does not expect a reply from the messags sent.
 * @author Kieran Greer
 */
public class ClientConnectionAsync extends ClientConnection
{
    /** The logger */
    private static final Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ClientConnectionAsync.class.getName());
        logger.setDebug(false);
    }

    
    /**
     * Create a new instance of ClientConnectionAsync.
     */
    public ClientConnectionAsync()
    {}

    /**
     * Execute the http asynchronous client request using the default threading. This will
     * send some data and then return immediately. It is possible to wait for a reply, but that could
     * lead to blocked channels for larger message transactions. For licas, it returns immediately.
     * @param methodInfo the method call description with all of the required information.
     * @return Object the reply to the call.
     * @throws java.lang.Exception any error. 
     */
    public Object execute(MethodInfo methodInfo) throws Exception
    {
        boolean reading;                            //true while reading
        boolean isVoid;                             //true if no return type
        int numBytes;                               //message part size
        byte[] lineBytes;                           //bytes for a line
        byte[] byteMsg;                             //message in bytes
        String uri;                                 //server uri
        String line;                                //message line
        String message;                             //full message to send
        final URL url;                              //the url
        Future<Integer> bytesWrite;                 //bytes written
        Future<Integer> bytesRead;                  //bytes read
        ByteBuffer readBuffer;                      //buffer for request
        ByteBuffer writeBuffer;                     //buffer for reply
        AsynchronousSocketChannel channel;          //comm channel
        HttpEntity httpEntity;                      //request message
        Object reply;                               //reply to the call

        reply = null;  
        channel = null;
        readBuffer = null;
        isVoid = false;

        try {
            isVoid = methodInfo.getRtnType().equalsIgnoreCase(TypeConst.VOID);
            uri = methodInfo.getServerURL();
            url = new URL(uri);
            
            httpEntity = new HttpEntity(Const.XMLRPC, HttpConst.POST);
            httpEntity.setValue(methodInfo);
            message = Parsers.serializeToString(httpEntity);

            //connect to the server
            channel = connect(url);

            //write request to the server channel
            byteMsg = message.getBytes();
            writeBuffer = ByteBuffer.wrap(byteMsg);
            bytesWrite = channel.write(writeBuffer);
            bytesWrite.get();
            channel.shutdownOutput();

            //wait for asynchronous reply
            if (!isVoid) {
                //read the server reply
                readBuffer = ByteBuffer.allocate(Const.BUFFERSIZE);
                bytesRead = channel.read(readBuffer);
                numBytes = bytesRead.get();

                reading = true;
                reply = "";
                while ((numBytes != -1) && reading)
                {
                    // Make sure that we have data to read
                    if (readBuffer.position() > 2) {
                        //make the buffer ready to write
                        readBuffer.flip();

                        //convert the buffer into a line
                        lineBytes = new byte[numBytes];
                        readBuffer.get(lineBytes, 0, numBytes);
                        line = new String(lineBytes);
                        reply += line;

                        //make the buffer ready to read
                        readBuffer.compact();

                        //read the next line
                        bytesRead = channel.read(readBuffer);
                        numBytes = bytesRead.get(10000, TimeUnit.MILLISECONDS);
                    }
                    else {
                        // An empty line signifies the end of the conversation in our protocol
                        reading = false;
                    }
                }

                if (ObjectHandler.isString(reply)) {
                    reply = XmlHandler.removeCoding((String) reply);
                    reply = Parsers.parse((String) reply);

                    if (reply instanceof HttpEntity) {
                        reply = ((HttpEntity) reply).getValue();
                    }
                }
            }
        }
        catch (java.net.SocketException soex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    (String.valueOf(methodInfo.getServerURL()) + ": "), null, soex);
        }
        catch (java.net.SocketTimeoutException stex) {
            //if non-blocking call then ignore, otherwise log error
            if (isVoid) throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                            (String.valueOf(methodInfo.getServerURL()) + ": "), null, stex);
        }
        catch (IOException ioex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    (String.valueOf(methodInfo.getServerURL()) + ": "), null, ioex);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    (String.valueOf(methodInfo.getServerURL()) + ": "), null, ex);
        }
        finally {
            if (readBuffer != null) {
                try {
                    readBuffer.clear();
                } catch (Exception ex)
                {}

            }

            if (channel != null) {
                try {
                    channel.shutdownInput();
                } catch (Exception ex)
                {}

                try {
                    channel.shutdownOutput();
                }
                catch (Exception ex) {}

                try {
                    channel.close();
                }
                catch (Exception ex) {}

                channel = null;
            }
        }
        
        return reply;
    }

    /**
     * Make an asynchronous connection and return the channel.
     * @param url the remote address to connect with.
     * @return new channel connected to the remote address.
     * @throws java.lang.Exception any error.
     */
    private AsynchronousSocketChannel connect(URL url) throws Exception
    {
        SocketAddress addr;                         //remote address
        AsynchronousSocketChannel channel;          //the channel
        Future<Void> connOK;                        //wait for connection

        channel = AsynchronousSocketChannel.open();
        channel.setOption(StandardSocketOptions.SO_RCVBUF, Const.BUFFERSIZE);
        channel.setOption(StandardSocketOptions.SO_REUSEADDR, true);
        channel.setOption(StandardSocketOptions.TCP_NODELAY, true);

        addr = new InetSocketAddress(url.getHost(), (url.getPort()+1));
        connOK = channel.connect(addr);
        connOK.get();

        return channel;
    }
}
