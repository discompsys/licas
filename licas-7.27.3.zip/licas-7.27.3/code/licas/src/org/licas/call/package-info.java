/**
 * Server and client-handling classes for calling or invoking any service through the system.
 */
package org.licas.call;