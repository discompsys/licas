/*
 * MethodFactory.java
 *
 * Created on 25 April 2016
 *
 * Version 1.2.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.call;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.PasswordHandler;
import org.licas.Service;
import org.licas.call.rest.RestFactory;
import org.licas.call.rest.RestMessage;
import org.licas.parsers.Parsers;
import org.licas.server.model.HttpEntity;
import org.licas.service.model.Contract;
import org.licas.util.*;
import org.licas.util.exception.ServiceException;
import org.licas.ws.WsFactory;
import org.licas.ws.WsMethodInfo;
import org.licas.ws.wsdl.model.LicasWsdlModel;
import org.licas.ws.wsdl.model.WsdlParamInfo;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;

import java.util.ArrayList;


/**
 * This factory class can be used to create method info objects for dynamic execution
 * on any of the communication protocols. Note that {@code createMethodCall} can be
 * used on direct object references and also ones that are not {@link Service}-related.
 * So it might be used as a general mechanism for creating a method description to
 * execute through the {@link CallObject} interface, and therefore on a separate thread.
 * <br>
 * The generated object is not guaranteed to be 100% complete, so you will need to check
 * this in your code, in case you need to add other values, but it does reduce the amount of
 * effort you may require to construct the method objects.
 * @author Kieran Greer
 */
public final class MethodFactory 
{
    /** The logger */
    private static final Logger logger;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(MethodFactory.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Creates a new instance of MethodFactory.
     */
    public MethodFactory()
    {}
    

    /**
     * Automatically construct the Reflection method info from the parameter values entered.
     * This might more typically be for a direct reference to an object that is not
     * licas {@link Service}-derived. So any other object, when no passwords are required.
     * @param methodName the name of the method to call.
     * @param returnType the return type for the call.
     * @param objToInvoke the reference to the object to invoke. This should probably be
     * a direct reference to the Object itself and not {@code Service}-derived.
     * @param parameters the parameter list for the method to call.
     * @return the created method info object.
     * @throws java.lang.Exception any error.
     */
    public static MethodInfo createObjectCall(String methodName, String returnType, Object objToInvoke,
            ArrayList<Object> parameters) throws Exception
    {
        return createMethodCall(methodName, returnType, objToInvoke, parameters, null);
    }
    
    /**
     * Automatically construct the RPC-XML/Reflection method call from the parameter values entered.
     * The {@code serviceObj} would typically be a reference to a licas {@link Service}-derived object,
     * but does not have to be.
     * @param methodName the name of the method to call.
     * @param returnType the return type for the call.
     * @param serviceObj the reference to the service to call. This can either be
     * a URI description as an XML element or a direct reference Object.
     * @param parameters the parameter list for the method to call.
     * @param passwordHandler the passwords that are required to make the call.
     * If {@code passwordHandler} is {@code null} then passwords are not checked for, but
     * remote access to any {@code Service}-derived object will require passwords.
     * @return the created method info object.
     * @throws java.lang.Exception any error.
     */
    public static MethodInfo createMethodCall(String methodName, String returnType, Object serviceObj,
            ArrayList<Object> parameters, PasswordHandler passwordHandler) throws Exception
    {
        int i;
        String password;                                //password
        String serverPassword;                          //server password
        String passwordKey;                             //password key
        String serverUri;                               //server uri
        Element serviceUri;                             //service uri
        Element serverElem;                             //server uri element
        Element serviceElem;                            //service uri element
        Contract contract;                              //the contract
        MethodInfo methodInfo;                          //created method info
        MethodInfo methodToCall;                        //method to make a call with
        CallObject callObj;                             //call object

        passwordKey = null;
        password = null;
        serverPassword = null;
        
        methodInfo = new MethodInfo();
        methodInfo.setName(methodName);
        methodInfo.setRtnType(returnType);
        methodInfo.setServiceURI(serviceObj);
        
        try {
            if (ObjectHandler.isString(serviceObj)) {
                try {
                    serviceObj = XmlHandler.stringToElement((String)serviceObj);
                }
                catch (Exception ex) {}
            }
            
            if (ObjectHandler.isElement(serviceObj)) {
                serviceElem = (Element)serviceObj;
                serverUri = Handle.getURL(serviceElem);

                //if password handler not null, then check for passwords
                if (passwordHandler != null) {
                    if (Handle.isServerURI(serviceElem)) {
                        try {
                            password = passwordHandler.getServicePassword(serviceElem);
                            if (password != null) {
                                methodInfo.setPassword(password);
                                methodInfo.setServerPassword(password);
                                serverPassword = password;
                            }
                        }
                        catch (Exception ex) {}
                    }
                    else {
                        try {
                            password = passwordHandler.getServicePassword(serviceElem);
                            if (password != null) {
                                methodInfo.setPassword(password);
                            }
                        }
                        catch (Exception ex) {
                            if (serverUri != null) {
                                try {
                                    //try with full base uri
                                    serviceUri = Handle.createNewUrlHandle(serverUri);
                                    serviceUri = Handle.addToHandle(serviceUri, Handle.asHandleElement(passwordKey));
                                    
                                    password = passwordHandler.getServicePassword(serviceUri);
                                    if (password != null) {
                                        methodInfo.setPassword(password);
                                    }
                                }
                                catch (Exception ex2) {}
                            }
                        }
                    }

                    if (serverPassword == null) {
                        serverElem = Handle.createNewServerHandle(serverUri);

                        serverPassword = passwordHandler.getServicePassword(serverElem);
                        if (serverPassword != null) {
                            methodInfo.setServerPassword(serverPassword);
                        }
                    }

                    if (password == null) {
                        //try to ask the service to call for its password
                        //this uses default values and assumes the password is always returned
                        //if this does not work, negotiation will be required
                        contract = Contract.getYesContract();

                        callObj = new CallObject();
                        methodToCall = new MethodInfo();
                        methodToCall.setName(MethodConst.GETPASSWORD);
                        methodToCall.setRtnType(TypeConst.STRING);
                        methodToCall.setServiceURI(serviceElem);
                        if (serverPassword != null) methodToCall.setServerPassword(serverPassword);
                        methodToCall.addParam(new ParamInfo(Const.ANON));
                        methodToCall.addParam(new ParamInfo(contract));
                        password = (String)callObj.call(methodToCall);

                        if (password != null) {
                            methodInfo.setPassword(password);
                        }
                    }
                }
                
                if (passwordsOK(password, passwordHandler)) {
                    if (parameters != null) {
                        for (i = 0; i < parameters.size(); i++)
                        {
                            methodInfo.addParam(parameters.get(i));
                        }
                    }
                }
                else {
                    throw new ServiceException("Error creating method info - password unavailable");
                }
            }
            else {
                //if direct Object reference then password may not be required
                if (serviceObj instanceof Service) {
                    try {
                        password = passwordHandler.getServicePassword(((Service)serviceObj).getUUID());
                        if (password != null) {
                            methodInfo.setPassword(password);
                        }
                    }
                    catch (Exception ex) {}
                }

                if (passwordsOK(password, passwordHandler) || !(serviceObj instanceof Service)) {
                    if (parameters != null) {
                        for (i = 0; i < parameters.size(); i++)
                        {
                            methodInfo.addParam(parameters.get(i));
                        }
                    }
                }
                else {
                    throw new ServiceException("Error creating method info - password unavailable");
                }
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "createMethodCall",
                null, ex);
        }
        
        return methodInfo;
    }
    
    private static boolean passwordsOK(String password, PasswordHandler passwordHandler)
    {
        return ((passwordHandler == null) || (password != null));
    }
    
    /**
     * Create and return a method info object for invoking a web service using the SOAP protocol.
     * @param operationName the name of the operation to call.
     * @param setRtn true if set the return Object type.
     * @param paramValues if true add the parameter values as {@link WsdlParamInfo} objects.
     * @param wsdlModel the wsdl model that stores the description.
     * @return a web service info object with the appropriate values.
     * @throws java.lang.Exception any error.
     */
    public static WsMethodInfo createSoapCall(String operationName, boolean setRtn,
            boolean paramValues, LicasWsdlModel wsdlModel) throws Exception
    {
        try {
            if (WsFactory.hasInstance()) {
                return WsFactory.getInstance().createSoapCall(operationName, setRtn, 
                        paramValues, wsdlModel);
            }
            
            return null;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "createSoapCall", null, ex);
        }
    }
    
    /**
     * Create and return a method info object for invoking a web service using the SOAP protocol.
     * @param webService the service name.
     * @param operation the name of the operation to call.
     * @param endpointAddress the server endpoint address.
     * @param soapActionUri soap action uri type.
     * @param namespace ontology namespace.
     * @param parameters list of {@link WsdlParamInfo} objects that store parameter types and values.
     * @param setRtn true if set the return Object type.
     * @return a web service info object with the appropriate values.
     * @throws java.lang.Exception any error.
     */
    public static WsMethodInfo createSoapCall(String webService, String operation, String endpointAddress,
        String soapActionUri, String namespace, ArrayList<WsdlParamInfo> parameters, boolean setRtn) throws Exception
    {
        if (WsFactory.hasInstance()) {
            return WsFactory.getInstance().createSoapCall(webService, operation, endpointAddress, 
                soapActionUri, namespace, parameters, setRtn);
        }
        
        return null;
    }
    
    /**
     * Create and return a method info object for invoking a web service using the REST protocol.
     * @param endpointAddress the server endpoint address.
     * @param query the full REST-style query.
     * @return a web service info object with the appropriate values.
     * @throws java.lang.Exception any error.
     */
    public static WsMethodInfo createRestCall(String endpointAddress, String query) throws Exception
    {
        RestMessage restMessage;                    //rest message
        
        restMessage = new RestMessage();
        restMessage.uri = endpointAddress;
        restMessage.query = query;
        
        return RestFactory.getInstance().toMethodInfo(restMessage);
    }
    
    /**
     * Map and set parameter instance values in the related info objects. This works best with
     * a properly configured method object and parameter list, with the following rules:
     * <p>
     * 1. If the {@link ParamInfo} objects of this method do not have names assigned, then 
     * assign the first parameter value in the list to each one.<br>
     * 2. If the {@link ParamInfo} objects of this method do have names try to map to the name.<br>
     * 2.1. If the paramList is a list of {@link KeyValue} objects, then the related name can be mapped.<br>
     * 2.2. If the paramList is a list of objects, then assign the first one again.<br>
     * 3. A null value, evaluated by {@link ObjectHandler}.{@code isNull} will not be added.
     * <p>
     * So if names are tagged, they can be replaced from any position in the list,
     * but if names are missing, the first available value must be used. Safest is to have
     * a {@code paramList} of {@link KeyValue} objects and each {@link MethodInfo} parameter 
     * also assigned an identical name.
     * @param methodInfo the method info that gets its parameter list updated.
     * @param paramList list of parameters, preferably as {@link KeyValue} objects so that 
     * they can be mapped across properly.
     */
    public static void mapToParams(MethodInfo methodInfo, ArrayList<Object> paramList)
    {
        int i, j;
        boolean added;                              //true if added
        String paramName;                           //parameter name
        ArrayList<ParamInfo> params;                //parameters list
        KeyValue nextKeyValue;                      //next key-value pair
        ParamInfo paramInfo;                        //param info
        Object nextParamObj;                        //next parameter object
        
        if (paramList != null) {
            params = methodInfo.getParams();
            for (i = 0; (i < params.size()) && !paramList.isEmpty(); i++)
            {
                paramInfo = params.get(i);
                paramName = paramInfo.getName();
                
                if (paramName == null) {
                    nextParamObj = paramList.get(0);

                    if (nextParamObj instanceof KeyValue) {
                        nextKeyValue = (KeyValue)nextParamObj;
                        paramInfo.setAddValue(nextKeyValue.value);
                    }
                    else if (!ObjectHandler.isNull(nextParamObj)) {
                        paramInfo.setAddValue(nextParamObj);
                    }
                    
                    paramList.remove(0);
                }
                else {
                    added = false;
                    for (j = 0; !added && (j < paramList.size()); j++)
                    {
                        nextParamObj = paramList.get(j);

                        if (nextParamObj instanceof KeyValue) {
                            nextKeyValue = (KeyValue)nextParamObj;
                            if (nextKeyValue.key.equalsIgnoreCase(paramName)) {
                                paramInfo.setAddValue(nextKeyValue.value);
                                paramList.remove(j);
                                added = true;
                            }
                        }
                        else if (!ObjectHandler.isNull(nextParamObj)) {
                            paramInfo.setAddValue(nextParamObj);
                            paramList.remove(j);
                            added = true;
                        }      
                    }
                }
            }
        }
    }

    /**
     * Parse the reply back into n Object and return.
     * @param reply the method reply in some form.
     * @return the method reply after further formatting.
     * @throws java.lang.Exception any error.
     */
    public static Object parseReply(Object reply) throws Exception
    {
        //parse reply back into object and return
        if (ObjectHandler.isString(reply)) {
            reply = XmlHandler.removeCoding((String)reply);
            reply = Parsers.parse((String)reply);
        }
        else if (ObjectHandler.isElement(reply)) {
            reply = Parsers.parse((Element)reply);
        }
        else {
            reply = Parsers.parseObject(reply);
        }

        if (reply instanceof HttpEntity) {
            reply = ((HttpEntity)reply).getValue();
        }

        return reply;
    }
}
