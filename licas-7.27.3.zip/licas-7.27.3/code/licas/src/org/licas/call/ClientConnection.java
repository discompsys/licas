/*
 * ClientConnection.java
 *
 * Created on 3 March 2020.
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.call;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.util.Const;


/**
 * Base class for a blocking or non-blocking http client connection.
 * If the request requires a reply, then it is blocked, or prevented from releasing
 * its thread, until the reply is returned. If the request does not require a reply,
 * recognised by the {@link Const}.{@code VOID} return type in the method, then the
 * request is sent and the method terminates immediately afterwards. If a reply is required,
 * then the call will block all other activity on this thread until it has completed
 * or been timed out.
 * @author Kieran Greer
 */
public abstract class ClientConnection
{
    /** The logger */
    private static final Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ClientConnection.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of ClientConnection.
     */
    public ClientConnection()
    {}

    /**
     * Execute the http asynchronous client request. Can block for reply or return immediately.
     * @param methodInfo the method call description with all of the required information.
     * @return Object the reply to the call.
     * @throws Exception any error.
     */
    public abstract Object execute(MethodInfo methodInfo) throws Exception;
}
