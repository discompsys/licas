/*
 * Rest_MethodHandler
 *
 * Created on 23 April 2016
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.call.client;


import org.licas.call.MethodFactory;
import org.licas.call.MethodInfo;
import org.licas.call.rest.RestFactory;
import org.licas.call.rest.RestMessage;
import org.licas.def.RemoteCallDef;
import org.licas.util.Const;
import org.licas.ws.WsMethodInfo;
import org.licas_internet.ConnectionManager;
import org.licas_internet.util.HttpConst;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;


/**
 * This acts as an interface for making REST-style calls.
 * @author Kieran Greer
 */
public final class Rest_MethodHandler implements RemoteCallDef
{
    /** The logger */
    private static final Logger logger;


    /** The remote call type, for example Const.XML-RPC, REST or SOAP */
    private final String callType;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(Rest_MethodHandler.class.getName());
        logger.setDebug(false);
    }


    /**
     * Creates a new instance of Rest_MethodHandler.
     */
    public Rest_MethodHandler()
    {
        callType = Const.REST;
    }

    /**
     * Execute a soap call. Use this method to pass the dataset in a single call.
     * @param methodInfo the method info that describes the call. Of type {@link WsMethodInfo}.
     * @return the reply to the call as a String.
     * @throws java.lang.Exception any error.
     */
    public Object execute(MethodInfo methodInfo) throws Exception
    {
        RestMessage restMessage;                //rest message
        WsMethodInfo wsMethodInfo;              //method info
        Object reply;                           //method reply
        
        try
        {
            //construct and invoke the rest message
            if (!(methodInfo instanceof WsMethodInfo))
            {
                wsMethodInfo = new WsMethodInfo();
                wsMethodInfo.copyValues(methodInfo);
            }
            else
            {
                wsMethodInfo = (WsMethodInfo)methodInfo;
            }

            restMessage = construct(wsMethodInfo);
            reply = ConnectionManager.sendRequest(HttpConst.URLCONN, restMessage.uri,
                restMessage.query, restMessage.timeOut);

            //parse reply back into object and return
            return MethodFactory.parseReply(reply);
        } 
        catch (Exception ex) 
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "execute", null, ex);
        }
    }
    
    /**
     * Construct a REST-style message from a MethodInfo description.
     * @param methodInfo the method info object to parse.
     * @return the constructed soap message.
     * @throws java.lang.Exception any error.
    */
    public RestMessage construct(WsMethodInfo methodInfo) throws Exception
    {
        try
        {
            return RestFactory.getInstance().createRestMessage(methodInfo);
        } 
        catch (Exception ex) 
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "construct", null, ex);
        }
    }
    
    /**
     * Get the value indicating the type of remote call.
     * @return the value of callType.
     */
    public String getCallType()
    {
        return callType;
    }
}
