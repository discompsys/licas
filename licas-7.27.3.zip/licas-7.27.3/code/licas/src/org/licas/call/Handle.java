/*
 * Handle.java
 *
 * Created on 05 June 2007
 *
 * Version 1.11
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.call;


import org.licas.server.LocalServer;
import org.licas.util.Const;
import org.licas_internet.util.HttpConst;
import org.licas_xml.abs.*;
import org.licas_xml.model.XmlHandler;

import java.net.URL;
import java.util.Vector;


/**
 * This is a helper class for creating the URI descriptions that define each service address
 * running on a licas server. It provides a full description, including the server http address,
 * the service UUID names and an additional method to invoke if required. The description 
 * is stored as XML elements, encapsulated inside of a {@code Handle} element. 
 * <p>
 * An address of a service uniquely defines it and includes a number of parts. The 
 * first part is the URL of the server that is hosting the service. This is stored in a {@code U} 
 * element. Each base service running on a server is then required to have a unique UUID.
 * This is stored in an {@code S} element. Each service nested inside of any other service then
 * has another UUID (not necessarily unique) that is also stored in an {@code S} element. 
 * If the path is for a method invocation, the final element that stores the method name
 * is an {@code M} element. A full path description could look something like 
 * {@code <Handle><U>http://123.4.5.6:8888</U><S>service_1</S><S>service_2</S><M>method</M></Handle>}.
 * <p>
 * This would call the method 'method' on the service 'service_2' nested, or child of 
 * service 'service_1', running on a server at the address http://123.4.5.6:8888.
 * Note also that the {@code M} element is not typically added by the user, but is automatically 
 * added by the system as part of the invocation process. It is declared when the related
 * {@link MethodInfo} object is created. Because of this, a number of the Handle methods are 
 * only used by the automatic calling mechanism and would not need to be used otherwise. 
 * A user would typically only use this class to construct a service path, but all methods
 * are available.
 * <p>
 * Because there is a pre-defined format, this Handle can be used to construct the 
 * address correctly. You need to start by creating the handle, so that the outer
 * {@code Handle} element is added. You can then add to that structure. For example:
 * 1. You can call {@code createBaseServiceHandle} with the UUID of a base service and a full 
 * path description will be returned, including the server address element.
 * Note this this is just for a base service - any child services then need to be
 * added afterwards. Also, a local server needs to be running.
 * 2. The {@code handleToString} method will return the path description as a String,
 * which is useful for key indexes, for example. 
 * <p>
 * You can also construct the full handle path description manually. 
 * 1. Firstly call {@code createNewUrlHandle} with the correct http address. 
 * 2. Then call {@code addToHandle(current_handle, asHandleElement(serviceName))} 
 * to add the service names. 
 * 3. Finally, calling {@code addToHandle(current_handle, asMethodElement(methodName))}
 * will add the method name at the end.
 * <p>
 * There are a number of other methods listed that the system itself might use and
 * so it is not expected that you would need to use all of these methods yourself.
 * @author Kieran Greer
 */
public class Handle 
{     
    /** URL part */
    private static final String URL_PART = "U";
    
    /** Service part */
    private static final String SERVICE_PART = "S";
    
    /** Method part */
    private static final String METHOD_PART = "M";
    
    /** Defines an execute method */
    private static final String EXECUTE = "execute";
    
    
    
    /**
     * Creates a new instance of Handle
     */
    public Handle() {
    }
    
    /**
     * Remove the XML tag names to return a URI description for displaying.
     * @param handleURI a properly formatted URI description, created by this class.
     * @return the path contents without the formatting.
     */
    public static String toShort(String handleURI)
    {
        Element handleElem;                           //handle as an element
        
        try
        {
            handleElem = XmlHandler.stringToElement(handleURI);
            return toShort(handleElem);
        }
        catch (Exception ex)
        {
            return handleURI;
        }
    }
    
    /**
     * Remove the XML tag names to return a URI description for displaying.
     * @param handleURI a properly formatted URI description, created by this class.
     * @return the path contents without the formatting.
     */
    public static String toShort(Element handleURI)
    {
        int i;
        StringBuilder handleStr;                //handle description
        String nextStr;                         //next part
        Element nextElem;                       //next element
        Vector<Node> elemList;                  //list of child elements
        
        handleStr = new StringBuilder();
        try {
            elemList = handleURI.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextElem = (Element)elemList.get(i);
                nextStr = nextElem.getText();               
                if ((i < elemList.size()-1) && !nextStr.endsWith("/")) {
                    nextStr = (nextStr + "/");
                }
                
                handleStr.append(nextStr);
            }
        }
        catch (Exception ex) {
            try {
                handleStr = new StringBuilder(XmlHandler.xmlToString(handleURI));
            }
            catch (Exception ex2) {
                handleStr = new StringBuilder(String.valueOf(handleURI));
            }
        }
        
        return handleStr.toString();
    }
    
    /**
     * Try to re-create a properly formatted XML-based URI description from the 
     * String-based description.
     * @param handleURI the path contents without any XML formatting.
     * @return the path contents contained inside of XML elements, as defined by this class.
     */
    public static Element toFull(String handleURI)
    {
        int index;
        String serviceID;                           //service id
        String ipAddress;                           //ip address
        String httpPart;                            //the http part
        String nextPart;                            //next key part
        Element handleElem;                         //handle element
        
        handleElem = null;
        try
        {
            serviceID = null;  
            if (HttpConst.startsWithHttp(handleURI))
            {
                httpPart = HttpConst.getHttp(handleURI);
                nextPart = HttpConst.removeHttp(handleURI);
            }
            else
            {
                httpPart = HttpConst.HTTP;
                nextPart = handleURI;
            }
            
            index = nextPart.lastIndexOf("/");
            if (index > 0)
            {
                serviceID = nextPart.substring(index+1);
                nextPart = nextPart.substring(0, index+1);
            }
            
            ipAddress = (httpPart + nextPart);
            handleElem = Handle.createNewUrlHandle(ipAddress);
            
            if (serviceID != null)
            {
                handleElem = Handle.addToHandle(handleElem, Handle.asHandleElement(serviceID));
            }
        }
        catch (Exception ex)
        {}
        
        return handleElem;
    }
    
    /**
     * Return true if the uri is a server uri.
     * @param origHandle the original handle of any type.
     * @return true if a server uri of the form {@code <Handle><U>http://123.4.5.6:8888</U><S>httpServer</S></Handle>}.
     */
    public static boolean isServerURI(Element origHandle)
    {
        boolean isServer;                       //true if a server
        
        isServer = hasURL(origHandle);
        if (isServer)
        {
            isServer = ((separatorCount(origHandle) == 0) &&
                getFirstServiceHandle(origHandle).equals(Const.HTTPSERVER));
        }
        
        return isServer;
    }
    
    /**
     * Return true if the uri is for a service with a local ip address - the local server.
     * @param origHandle the original handle of any type.
     * @return true if a server ip address and the handle ip address are the same.
     */
    public static boolean isLocalURI(Element origHandle)
    {
        boolean isLocal;                        //true if local ip address
        String localIP;                         //local ip address
        String serviceIP;                       //service ip address
        
        isLocal = hasURL(origHandle);
        if (isLocal)
        {
            localIP = LocalServer.getServerURL();
            serviceIP = Handle.getURL(origHandle);            
            isLocal = (localIP.equals(serviceIP));
        }
        
        return isLocal;
    }
    
    /**
     * Return true if the method name is the execute method. This is typically 
     * only called by the system.
     * @param methodName the method that should be equal to the {@code EXECUTE} (execute) constant.
     * @return true if the method is the execute method.
     */
    public static boolean isExecuteMethod(String methodName)
    {
        return ((methodName != null) && methodName.equals(EXECUTE));
    }
    
    /**
     * Return true if the method call has a handle separator between two elements
     * of the form service {@code S} or method {@code M}.
     * @param methodCall the method call of any form.
     * @return true if any handle separators exists.
     */
    public static boolean hasHandleSeparator(Element methodCall)
    {
        return (separatorCount(methodCall) > 0);
    }
    
    /**
     * Return true if the uri has a URL part as specified by the {@code U} name.
     * @param origHandle the original handle of any type. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>uuid</S><M>method</M></Handle>}.
     * @return true if the {@code <U>}part exists.
     */
    public static boolean hasURL(Element origHandle)
    {
        Element nextElem;                       //next element
        
        nextElem = origHandle.getChild(URL_PART);
        
        return (nextElem != null);
    }
    
    /**
     * Return true if the method call is a direct call on the current object.
     * This is typically only called by the system.
     * @param methodCall the full method call. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>uuid</S><M>method</M></Handle>}.
     * @return true if call only has one handle separator or less, ignoring the URL
     * part and is not an 'execute' method. True in this case (1 separator).
     */
    protected static boolean isDirectMethodCall(Element methodCall)
    {
        String methodName;                          //method name

        methodName = getMethod(methodCall);
        return ((separatorCount(methodCall) == 0) ||
                ((separatorCount(methodCall) < 2) && !isExecuteMethod(methodName)));
    }
    
    /**
     * Get a string-based description of the handle. This can be useful of key indexes, etc.
     * @param handle the XML handle element.
     * @return the string-based description.
     * @throws java.lang.Exception any error.
     */
    public static String handleToString(Element handle) throws Exception
    {
        if (handle != null) {
            return XmlHandler.xmlToString(handle);
        }

        return null;
    }
    
    /**
     * Create a full service handle, including the server ip address, for the locally
     * running server. This is the most common form of address that is used.
     * @param uuid the uuid of the service to add to the server address, to make a
     * full path description to a base service. If the uuid is already a full URI
     * description, then an XML form of it is returned without any other changes.
     * @return the full handle path description. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>uuid</S></Handle>}.
     */
    public static Element createServiceHandle(String uuid)
    {
        Element serviceUrl;                     //url handle for the service
        
        serviceUrl = null;
        try
        {
            try
            {
                serviceUrl = XmlHandler.stringToElement(uuid);
            }
            catch (Exception ex)
            {
                return createServiceHandle(getLocalServerURI(), uuid);
            }
        }
        catch (Exception ex2) {}
        
        return serviceUrl;
    }
    
    /**
     * Create a full service handle, including the server ip address, for the locally
     * running server. This is the most common form of address that is used.
     * @param uriWithURL a server or service URI handle with the target URL address.
     * @param uuid the uuid of the service to add to the URL address, to make a
     * full path description to a base service.
     * @return the full handle path description. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>uuid</S></Handle>}.
     */
    public static Element createServiceHandle(Element uriWithURL, String uuid)
    {
        Element serviceUrl;                     //url handle for the service
        
        serviceUrl = null;
        try
        {
            serviceUrl = Handle.createNewUrlHandle(Handle.getURL(uriWithURL));
            serviceUrl = Handle.addToHandle(serviceUrl, Handle.asHandleElement(uuid));
        }
        catch (Exception ex) {}
        
        return serviceUrl;
    }
    
    /**
     * Create a new handle spec for a different server uri.
     * @param url the URL address of the server, e.g. http://987.6.5.4:3333.
     * @return the handle spec in XML format, including the default server id.
     * This could look like {@code <Handle><U>http://987.6.5.4:3333</U><S>HttpServer</S></Handle>}.
     */
    public static Element createNewServerHandle(String url)
    {
        Element handle;                             //handle element
        Element uriElem;                            //uri element
        
        handle = XMLFactory.getInstance().createElement(Const.HANDLE);
        
        try
        {
            URL aUrl = new URL(url);
            
            uriElem = XMLFactory.getInstance().createElement(URL_PART);
            uriElem.setText(url);
            handle.addContent(uriElem);
            handle = formatURI(handle);
            
            uriElem = XMLFactory.getInstance().createElement(SERVICE_PART);
            uriElem.setText(Const.HTTPSERVER);
            handle.addContent(uriElem);
        }
        catch (Exception ex)
        {}
        
        return handle;
    }
    
    /**
     * Create a new handle spec with a URL part only.
     * @param url the url address, e.g. http://123.4.5.6:8888.
     * @return the handle spec in XML format. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U></Handle>}.
     */
    public static Element createNewUrlHandle(String url)
    {
        Element handle;                                 //handle element
        Element uriElem;                                //uri element
        
        handle = XMLFactory.getInstance().createElement(Const.HANDLE);
        
        try
        {
            URL aUrl = new URL(url);
            
            uriElem = XMLFactory.getInstance().createElement(URL_PART);
            uriElem.setText(url);
            handle.addContent(uriElem);

            handle = formatURI(handle);
        }
        catch (Exception ex)
        {}
        
        return handle;
    }
    
    /**
     * Create a new handle spec with a service part only.
     * @param serviceUuid the service UUID.
     * @return the handle spec in XML format. This could look like
     * {@code <Handle><S>serviceUuid</S></Handle>}.
     */
    public static Element createNewHandleHandle(String serviceUuid)
    {
        Element handle;                                 //handle element
        Element serviceElem;                            //uri element
        
        handle = XMLFactory.getInstance().createElement(Const.HANDLE);
        serviceElem = XMLFactory.getInstance().createElement(SERVICE_PART);
        serviceElem.setText(serviceUuid);
        handle.addContent(serviceElem);
        
        return handle;
    }
    
    /**
     * Create a new handle spec with a method name part only. This is typically
     * only called by the system.
     * @param methodName the method name.
     * @return the handle spec in XML format. This could look like
     * {@code <Handle><M>methodName</M></Handle>}.
     */
    protected static Element createNewMethodHandle(String methodName)
    {
        Element handle;                                 //handle element
        Element serviceElem;                            //uri element
        
        handle = XMLFactory.getInstance().createElement(Const.HANDLE);
        serviceElem = XMLFactory.getInstance().createElement(METHOD_PART);
        serviceElem.setText(methodName);
        handle.addContent(serviceElem);
        
        return handle;
    }
    
    /**
     * Return a handle with the new element added at the end.
     * @param handle the handle to add to. This is not changed.
     * @param newElement the new handle element. Note that the new element must be 
     * converted into the correct format first using either {@code asUrlElement}, 
     * {@code asHandleElement}, or {@code asMethodElement}, depending on the element type.
     * @return the new Handle element. This could look like
     * {@code <Handle><orig handle>orig handle value</orig handle><?>new element value here</?></Handle>}.
     */
    public static Element addToHandle(Element handle, Element newElement)
    {
        Element newHandle = null;                       //new handle
        
        if (handle != null)
        {
            newHandle = (Element)handle.clone();           
            if (newElement != null)
            {
                newHandle.addContent(newElement);
            }
        }
        
        return newHandle;
    }
    
    /**
     * Return a handle with the new element added to the handle as the first element
     * of the handle.
     * @param handle the handle to add to. This is not changed.
     * @param newElement the new handle element. Note that the new element must be 
     * converted into the correct format first using either {@code asUrlElement}, 
     * {@code asHandleElement}, or {@code asMethodElement}, depending on the element type.
     * @return the new Handle element. This could look like
     * {@code <Handle><?>new element value here</?><orig handle>orig handle value</orig handle></Handle>}.
     */
    public static Element addToHandleFirstElement(Element handle, Element newElement)
    {
        Element newHandle = null;                       //new handle
        
        if (handle != null)
        {
            newHandle = (Element)handle.clone();            
            if (newElement != null)
            {
                newHandle.addContent(0, newElement);
            }
        }
        
        return newHandle;
    }
    
    /**
     * Add the specific execute method name to the handle. This is typically only
     * called by the system.
     * @param handle the handle to add to. This is not changed.
     * @return the handle with the execute method appended. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>uuid</S><M>execute</M></Handle>}.
     */
    protected static Element addExecute(Element handle)
    {
        Element newHandle;                          //new handle
        Element execElem;                           //execute element
        
        execElem = XMLFactory.getInstance().createElement(METHOD_PART);
        execElem.setText(EXECUTE);
        
        newHandle = (Element)handle.clone();
        newHandle.addContent(execElem);
        
        return newHandle;
    }
    
    /**
     * Return the URL part of an address or null if it does not exist.
     * @param address the address of the form {@code <Handle><U>http://123.4.5.6:8888</U><S>uuid</S> ... </Handle>}.
     * @return the url part. This could look like {@code http://123.4.5.6:8888}.
     */
    public static String getURL(Element address)
    {
        String uriStr = null;                   //uri value
        Element uriPart;                        //uri part of xml spec
        Element handleXml;                      //the handle in XML format
        
        
        if (address != null) {
            handleXml = formatURI(address);
            uriPart = handleXml.getChild(URL_PART);
            
            if (uriPart != null) {
                uriStr = uriPart.getValue();
            }
        }
        
        return uriStr;
    }
    
    /**
     * Return the rest of a method call with the first part of any type removed. This
     * is typically only called by the system.
     * @param methodCall a full or partial method call description. This could look like
     * {@code <Handle><?>any handle part</?><S>uuid</S><M>method</M></Handle>}.
     * @return the handle with the first part removed. This could look like
     * {@code <Handle><S>uuid</S><M>method</M></Handle>}
     */
    public static Element getRestOfCall(Element methodCall)
    {
        Node nextNode;                          //next node
        Element newHandle = null;               //new handle
        Vector<Node> elemList;                  //element list
        
        
        if (methodCall != null) {
            newHandle = (Element)methodCall.clone();
            elemList = newHandle.getChildren();
            
            nextNode = elemList.get(0);
            nextNode.detach();
        }
        
        return newHandle;
    }
    
    /**
     * If a local server is running then try to create its default handle.
     * @return the default handle with the local ip address, or null if no server 
     * is running. This could look like {@code <Handle><U>http://123.4.5.6:8888</U><S>HttpServer</S></Handle>}.
     */
    public static Element getLocalServerURI()
    {
        Element serverUrl;      //url handle for the local server
        
        serverUrl = null;
        try
        {
            serverUrl = Handle.createNewUrlHandle(LocalServer.getServerURL());
            serverUrl = Handle.addToHandle(serverUrl, Handle.asHandleElement(Const.HTTPSERVER));
        }
        catch (Exception ex) {}
        
        return serverUrl;
    }
    
    /**
     * Return the whole URI address of the static HTTP server as a String.
     * @return whole URI address.
     * @throws java.lang.Exception any error.
     */
    public static String getLocalServerUriStr() throws Exception
    {
        return XmlHandler.xmlToString(getLocalServerURI());
    }
    
    /**
     * Return the method part of a method call. This is typically only called by
     * the system.
     * @param methodCall the original handle. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>uuid</S><M>method</M></Handle>}.
     * @return the method part. This could look like {@code method}.
     */
    public static String getMethod(Element methodCall)
    {
        String method = null;                   //the method
        Element methodElem;                     //method element
        
        if (methodCall != null)
        {
            methodElem = methodCall.getChild(METHOD_PART);           
            if (methodElem != null) method = methodElem.getValue();
        }
        
        return method;
    }
    
    /**
     * Return the first handle service part value.
     * @param origHandle the original handle. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>uuid1</S><S>uuid2</S></Handle>}.
     * @return the first service part value or null if none exist.
     * This could look like {@code uuid1}.
     */
    public static String getFirstServiceHandle(Element origHandle)
    {
        int i;
        String handle = null;                   //the handle
        Node nextNode;                          //next node
        Element firstService;                   //first service spec
        Vector<Node> elemList;                  //element list

        if (origHandle != null) {
            elemList = origHandle.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = elemList.get(i);

                if (nextNode instanceof Element) {
                    firstService = (Element)nextNode;
                    if (firstService.getName().equals(SERVICE_PART)) {
                        handle = firstService.getValue();
                        break;
                    }
                }
            }
        }
        
        return handle;
    }
    
    /**
     * Return the last handle service part value.
     * @param origHandle the original handle. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>uuid1</S><S>uuid2</S></Handle>}.
     * @return the last service part value or null if none exist.
     * This could look like {@code uuid2}.
     */
    public static String getLastServiceHandle(Element origHandle)
    {
        int i;
        String handle;                          //the handle
        Node nextNode;                          //next node
        Element lastService;                    //last service spec
        Vector<Node> elemList;                  //element list

        handle = null;
        if (origHandle != null) {
            elemList = origHandle.getChildren();
            for (i = (elemList.size()-1); i >= 0; i--)
            {
                nextNode = elemList.get(i);

                if (nextNode instanceof Element) {
                    lastService = (Element)nextNode;
                    if (lastService.getName().equals(SERVICE_PART)) {
                        handle = lastService.getValue();
                        break;
                    }
                }
            }
        }
        
        return handle;
    }

    /**
     * Return the first handle service part value that is not the server, or the only service
     * part if there is only 1 service element.
     * @param origHandle the original handle. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>HttpServer</S><S>uuid1</S><S>uuid2</S></Handle>}.
     * @return the first service part value or null if none exist.
     * This could look like {@code uuid1}.
     */
    public static String getFirstHandleServiceServer(Element origHandle)
    {
        int i;
        boolean firstHandle = true;             //true if first service handle
        String handle = null;                   //the handle
        Node nextNode;                          //next node
        Element firstService;                   //first service spec
        Vector<Node> elemList;                  //element list

        if (origHandle != null) {
            elemList = origHandle.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = elemList.get(i);
                if (nextNode instanceof Element) {
                    firstService = (Element)nextNode;

                    if (firstService.getName().equals(SERVICE_PART)) {
                        handle = firstService.getValue();
                        if (firstHandle && handle.equalsIgnoreCase(Const.HTTPSERVER)) {
                            firstHandle = false;
                        }
                        else {
                            break;
                        }
                    }
                }
            }
        }

        return handle;
    }

    /**
     * Change the first handle service part value that is not the server, or the only service
     * part if there is only 1 service element.
     * @param origHandle the original handle. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>HttpServer</S><S>uuid1</S></Handle>}.
     * @param newID the new service ID to change to, for example {@code newUuid}.
     * @return the sane path with last service part changed. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>HttpServer</S><S>newUuid</S></Handle>}.
     * or the same Handle if there is no service element.
     */
    public static Element changeFirstHandleServiceServer(Element origHandle, String newID)
    {
        int i;
        boolean firstHandle = true;             //true if first service handle
        Node nextNode;                          //next node
        Element firstService;                   //first service spec
        Vector<Node> elemList;                  //element list

        if (origHandle != null) {
            elemList = origHandle.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = elemList.get(i);
                if (nextNode instanceof Element) {
                    firstService = (Element)nextNode;

                    if (firstService.getName().equals(SERVICE_PART)) {
                        if (firstHandle && firstService.getValue().equalsIgnoreCase(Const.HTTPSERVER)) {
                            firstHandle = false;
                        }
                        else {
                            firstService.setValue(newID);
                            break;
                        }
                    }
                }
            }
        }

        return origHandle;
    }
    
    /**
     * Remove the URL part of the handle.
     * @param origHandle the original handle. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>uuid</S></Handle>}.
     * @return the handle with the URL part removed. This could look like
     * {@code <Handle><S>uuid</S></Handle>}.
     */
    public static Element removeURL(Element origHandle)
    {
        Element newHandle = null;               //new handle
        
        if (origHandle != null) {
            newHandle = (Element)origHandle.clone();
            newHandle.removeChild(URL_PART);
        }
        
        return newHandle;
    }
    
    /**
     * Return the whole handle with the first service part removed.
     * @param servicePath the original handle. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>uuid1</S><S>uuid2</S></Handle>}.
     * @return the same handle with the first service part removed. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>uuid2</S></Handle>}.
     */
    public static Element removeFirstServiceHandle(Element servicePath)
    {
        int i;
        int index;                              //index to remove
        Node nextNode;                          //next node
        Element firstService;                   //first service spec
        Element newHandle = null;               //new handle
        Vector<Node> elemList;                  //element list

        if (servicePath != null) {
            index = -1;
            newHandle = (Element)servicePath.clone();
            elemList = newHandle.getChildren();
            
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = elemList.get(i);
                if (nextNode instanceof Element) {
                    firstService = (Element)elemList.get(i);
                    if (firstService.getName().equals(SERVICE_PART)) {
                        index = i;
                        break;
                    }
                }
            }
            
            if (index >= 0) elemList.removeElementAt(index);
        }
        
        return newHandle;
    }
    
    /**
     * Return the whole handle with the last service part removed. This probably makes
     * most sense if there is no method part to the handle.
     * @param servicePath the original handle. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>uuid1</S><S>uuid2</S></Handle>}.
     * @return the same handle with the last service part removed. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>uuid1</S></Handle>}.
     */
    public static Element removeLastServiceHandle(Element servicePath)
    {
        int i;
        int index;                              //index to remove
        Node nextNode;                          //next node
        Element lastService;                    //last service spec
        Element newHandle = null;               //new handle
        Vector<Node> elemList;                  //element list

        if (servicePath != null) {
            index = -1;
            newHandle = (Element)servicePath.clone();
            elemList = newHandle.getChildren();
            
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = elemList.get(i);

                if (nextNode instanceof Element) {
                    lastService = (Element)elemList.get(i);
                    if (lastService.getName().equals(SERVICE_PART)) {
                        index = i;
                    }
                }
            }
            
            if (index >= 0) elemList.removeElementAt(index);
        }
        
        return newHandle;
    }
    
    /**
     * Return a count of the number of handle separators in the method call, ignoring
     * the URL part.
     * @param methodCall a method call of any form. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>uuid1</S><S>uuid2</S><M>method</M></Handle>}.
     * @return a count of the number of handle separators, 2 in this case.
     */
    public static int separatorCount(Element methodCall)
    {
        int i;
        int count = -1;                         //number of separators
        Node nextNode;                          //next node
        Element nextElem;                       //next element
        Vector<Node> elemList;                  //element list

        if (methodCall != null) {
            elemList = methodCall.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextNode = elemList.get(i);

                if (nextNode instanceof Element) {
                    nextElem = (Element)nextNode;                   
                    if (nextElem.getName().equals(SERVICE_PART) ||
                        nextElem.getName().equals(METHOD_PART)) {
                        count++;
                    }
                }
            }
        }
        
        return count;
    }
    
    /**
     * Format the full handle so that the URL part can be compared with other URLs.
     * @param origHandle the original handle. This could look like
     * {@code <Handle><U>http://123.4.5.6:8888</U><S>service_1</S><S>service_2</S></Handle>}.
     * @return the handle with a re-formatted URL. this could look like
     * {@code <Handle><U>http://123.4.5.6:8888/</U><S>service_1</S><S>service_2</S></Handle>}.
     */
    public static Element formatURI(Element origHandle)
    {
        String uriStr;                  //uri value
        Element uriPart;                //uri part of xml spec
        Element handleXml;              //the handle in XML format
        
        if (origHandle != null) {
            handleXml = (Element)origHandle.clone();
            uriPart = handleXml.getChild(URL_PART);
            
            if (uriPart != null) {
                uriStr = uriPart.getValue();
                while (uriStr.endsWith("/")) uriStr = uriStr.substring(0, uriStr.length()-1);
                uriStr += "/";
                
                uriPart.setText(uriStr);
            }
            
            origHandle = handleXml;
        }
        
        return origHandle;
    }
    
    /**
     * Create an XML element to hold the URL handle part.
     * @param url the url address. This could look like {@code http://123.4.5.6:8888}.
     * @return URL handle part only. This could look like {@code <U>http://123.4.5.6:8888</U>}.
     */
    public static Element asUrlElement(String url)
    {
        Element urlElement;             //the url element
        
        urlElement = XMLFactory.getInstance().createElement(URL_PART);
        urlElement.setText(url);
        
        return urlElement;
    }
    
    /**
     * Create an XML element to hold the Service handle part.
     * @param serviceUuid the service name for the next handle path.
     * @return service handle part only. This could look like {@code <S>serviceUuid</S>}.
     */
    public static Element asHandleElement(String serviceUuid)
    {
        Element handleElement;              //the handle element
        
        handleElement = XMLFactory.getInstance().createElement(SERVICE_PART);
        handleElement.setText(serviceUuid);
        
        return handleElement;
    }
    
    /**
     * Create an XML element to hold the Method handle part.
     * @param method the method name.
     * @return method handle part only. This could look like {@code <M>method</M>}.
     */
    public static Element asMethodElement(String method)
    {
        Element methodElement;                  //the method element
        
        methodElement = XMLFactory.getInstance().createElement(METHOD_PART);
        methodElement.setText(method);
        
        return methodElement;
    }
}
