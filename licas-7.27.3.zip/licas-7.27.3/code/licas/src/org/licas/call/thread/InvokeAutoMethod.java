/*
 * InvokeAutoMethod.java
 *
 * Created on 8 January 2018
 *
 * Version 1.0.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.call.thread;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.licas.autonomic.script.AutoInvoke;


/**
 * Runs a single invocation of a {@link AutoInvoke} object on a separate thread. 
 * This is for the autonomic script engine parallel execution process.
 * @author Kieran Greer
 */
public class InvokeAutoMethod extends InvokeThread
{
    /** The logger */
    private static final Logger logger;
       
    /** Info for the method to invoke */
    private final AutoInvoke toInvoke;
    
     
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(InvokeAutoMethod.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Create a new instance of AutoInvokeThread.
     * @param thisInvoke the Auto method to invoke.
     */
    public InvokeAutoMethod(AutoInvoke thisInvoke)
    {
        super();
        toInvoke = thisInvoke;
    }
    
    /** Execute the method */
    public void run()
    {
        try
        {                
            result = toInvoke.invokeMethod();
        }
        catch (Exception ex)
        {
            result = ex;
        }
        finally
        {
            finished = true;
        }
    }
}
