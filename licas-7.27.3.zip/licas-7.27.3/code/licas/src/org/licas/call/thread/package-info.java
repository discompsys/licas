/**
 * Schedules the client-side calling through the {@code java.util.concurrent} classes,
 * or any other method invocations, through the system classes.
 */
package org.licas.call.thread;