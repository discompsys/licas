/**
 * REST-style protocol.
 */
package org.licas.call.rest;