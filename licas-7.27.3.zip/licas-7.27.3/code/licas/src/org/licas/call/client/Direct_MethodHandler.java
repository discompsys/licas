/*
 * Direct_MethodHandler.java
 *
 * Created on 19 April 2018.
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.call.client;


import org.licas.call.MethodInfo;
import org.licas.def.RemoteCallDef;
import org.licas.util.*;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;


/**
 * This makes a direct invocation on the object itself.
 * @author Kieran Greer
 */
public final class Direct_MethodHandler implements RemoteCallDef
{
    /** The logger */
    private static final Logger logger;
            
    
    /** The remote call type, for example Const.OBJECT */
    private final String callType;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(Direct_MethodHandler.class.getName());
        logger.setDebug(false);
    }


    /** 
     * Creates a new instance of Direct_MethodHandler.
     */
    public Direct_MethodHandler()
    {
        callType = Const.OBJECT;
    }
        
    /**
     * Execute a remote call.
     * @param methodInfo the method call description with all of the required information.
     * @return Object the reply to the call.
     */
    public Object execute(MethodInfo methodInfo) throws Exception
    {
        String replyClass;                      //the reply type
        Object reply;                           //reply to the call
        
        try 
        {
            //make remote http request
            replyClass = methodInfo.getRtnType();
            
            if (replyClass.equals(TypeConst.VOID))
            {
                ObjectInvoker.invokeMethod(methodInfo, methodInfo.getServiceURI());
                return null;
            }
            else
            {
                reply = ObjectInvoker.invokeMethod(methodInfo, methodInfo.getServiceURI());
                return reply;
            }
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "execute", null, ex);
        }
        finally
        {}
    }
    
    /**
     * Get the value indicating the type of remote call.
     * @return the value of callType.
     */
    public String getCallType()
    {
        return callType;
    }
}
