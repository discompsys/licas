/*
 * CallHandler.java
 *
 * Created on 11 June 2009
 *
 * Version 1.7
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.call.client;


import org.licas.call.*;
import org.licas.call.rest.RestFactory;
import org.licas.def.RemoteCallDef;
import org.licas.util.*;
import org.licas.ws.WsFactory;
import org.licas.ws.soap.Soap_BaseHandler;
import org.licas_internet.ConnectionManager;
import org.licas_xml.abs.Element;
import org.jlog2.*;


/**
 * This provides general functionality for retrieving the correct object to make a remote call. 
 * The default communication mechanism in licas is an XML-RPC mechanism.
 * If this is indicated then a {@link RPC_MethodHandler} will be returned. Calls to web
 * services can be described in the same way, in classes that extend the licas default 
 * ones. A {@link Rest_MethodHandler} can be used to make REST-style calls on remote sources.
 * If a SOAP web service call is specified, then a {@link Soap_BaseHandler} object can be returned.
 * To use these, you need to set the factory objects in your main code. That is: {@link RestFactory} and
 * {@link WsFactory}.
 * @author Kieran Greer
 */
public final class CallHandler
{
    private static final Logger logger;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(CallHandler.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Get the appropriate object to make a remote communication call with.
     * @param methodInfo the method call description with all of the required information.
     * @return the generated remote communication object.
     */
    public static RemoteCallDef getRemoteCommunicationObject(MethodInfo methodInfo)
    {
        String callType;                            //call type
        RemoteCallDef remoteCommObj;                //remote communication object

        remoteCommObj = null;
        callType = methodInfo.getCallType();

        if (isXMLRPC(callType)) 
        {
            //can be remote or direct call
            if (methodInfo.getServerURL() == null)
            {
                methodInfo.setCallType(Const.OBJECT);
                remoteCommObj = new Direct_MethodHandler();
            }
            else
            {
                remoteCommObj = new RPC_MethodHandler();
            }
        }
        else if (isREST(callType)) 
        {
            //can be remote or direct call
            if (methodInfo.getServerURL() == null)
            {
                methodInfo.setCallType(Const.OBJECT);
                remoteCommObj = new Direct_MethodHandler();
            }
            else {
                remoteCommObj = RestFactory.getInstance().createRestMethodHandler();
            }
        }
        else if (isSOAP(callType)) 
        {
            if (WsFactory.hasInstance())
            {
                remoteCommObj = WsFactory.getInstance().createSoapMethodHandler();
            }
        }
        
        return remoteCommObj;
    }

    /**
     * Return true if the call type is an XML-RPC call.
     * @param callType the call type description.
     * @return true if an XML-RPC call type.
     */
    public static boolean isXMLRPC(String callType)
    {
        return ((callType != null) && callType.equalsIgnoreCase(Const.XMLRPC));
    }
    
    /**
     * Return true if the call type is a SOAP call.
     * @param callType the call type description.
     * @return true if a SOAP call type.
     */
    public static boolean isREST(String callType)
    {
        return ((callType != null) && callType.equalsIgnoreCase(Const.REST));
    }

    /**
     * Return true if the call type is a SOAP call.
     * @param callType the call type description.
     * @return true if a SOAP call type.
     */
    public static boolean isSOAP(String callType)
    {
        return ((callType != null) &&
                (callType.equalsIgnoreCase(Const.SOAP) || callType.equalsIgnoreCase(Const.WSRPC)));
    }
    
    /**
     * Return true if the info object indicates a web service call (REST or SOAP).
     * @param methodInfo the info object to check.
     * @return true if ws info object.
     */
    public static boolean isWsCall(MethodInfo methodInfo)
    {
        return (methodInfo.getCallType().equalsIgnoreCase(Const.REST) ||
                methodInfo.getCallType().equalsIgnoreCase(Const.WSRPC) ||
                methodInfo.getCallType().equalsIgnoreCase(Const.SOAP));
    }
    
    /**
     * Try to call the server to test the connection.
     * @param serverHandle the server uri handle.
     * @return true if connection is OK, false otherwise. Exception returns false.
     */
    public static boolean testServerConnection(Element serverHandle)
    {
        if (serverHandle != null)
        {
            return testServerConnection(serverHandle, Const.ANON);
        }
        
        return false;
    }
    
    /**
     * Try to call the server to test the connection.
     * @param serverHandle the server uri handle.
     * @param serverPassword the server password to use.
     * @return true if connection is OK, false otherwise. Exception returns false.
     */
    public static boolean testServerConnection(Element serverHandle, String serverPassword)
    {
        boolean isOK;                               //true if OK
        String urlAddress;                          //ip address to ping
        MethodInfo methodInfo;                      //method info
        CallObject callObject;                      //the call object
        
        isOK = false;        
        try {
            if (serverHandle != null) {
                callObject = new CallObject();
                urlAddress = Handle.getURL(serverHandle);
                
                //if no password then set to the default
                if ((serverPassword == null) || serverPassword.equals("")) {
                    serverPassword = Const.ANON;
                }
                
                //try to ping first
                if (ConnectionManager.ping(urlAddress)) {
                    //if Ping OK, then try to connect with the server
                    //set method call info and make call on a separate thread
                    methodInfo = new MethodInfo();
                    methodInfo.setName(MethodConst.ISRUNNING);
                    methodInfo.setRtnType(TypeConst.BOOLEAN);
                    methodInfo.setServiceURI(serverHandle);
                    methodInfo.setServerPassword(serverPassword);
                    methodInfo.setPassword(serverPassword);
                    methodInfo.setCallTimeout(20000);
                    isOK = (Boolean)callObject.call(methodInfo);
                }
            }
        }
        catch (Exception ex) {}
        
        return isOK;
    }
    
    /**
     * Ping the ip address and return true if it is reachable.
     * @param ipAddress the address to ping.
     * @return true if reachable, false otherwise.
     */
    public static boolean testPing(String ipAddress)
    {
        return ConnectionManager.ping(ipAddress);
    }
    
    /**
     * Try to call the server to test the connection and then check if a service with
     * the specified name is running and can be invoked. This calls {@code testServerConnection}
     * as part of the process.
     * @param serverURL the server url address.
     * @param serverPassword the server password to use.
     * @param serviceID the service uuid.
     * @param callTimeout allowed reply time in milliseconds.
     * @return true the server is accessible and is running the service, false otherwise.
     */
    public static boolean canInvoke(String serverURL, String serverPassword, String serviceID, int callTimeout)
    {
        boolean isOK;                               //true if OK
        Element serverUri;                          //server uri
        MethodInfo methodInfo;                      //method info
        CallObject callObject;                      //the call object
        
        isOK = false;        
        try {
            serverUri = Handle.createNewServerHandle(serverURL);

            if (testServerConnection(serverUri, serverPassword)) {
                //if asking if can invoke the server itself, return true,
                //otherwise check if a service with the specified name is running
                if (serviceID.equalsIgnoreCase(Const.HTTPSERVER)) {
                    isOK = true;
                }
                else {
                    callObject = new CallObject();

                    //if no password then set to the default
                    if ((serverPassword == null) || serverPassword.equals("")) {
                        serverPassword = Const.ANON;
                    }

                    //if server can be invoked, check if it is running the specified service
                    try {
                        methodInfo = new MethodInfo();
                        methodInfo.setName(MethodConst.HASSERVICE);
                        methodInfo.setRtnType(TypeConst.BOOLEAN);
                        methodInfo.setServiceURI(serverUri);
                        methodInfo.setServerPassword(serverPassword);
                        methodInfo.setPassword(serverPassword);
                        methodInfo.setCallTimeout(callTimeout);
                        methodInfo.addParam(serviceID);
                        isOK = (Boolean) callObject.call(methodInfo);
                    }
                    catch (Exception pwex) {
                        isOK = false;
                    }
                }
            }
        }
        catch (Exception ex) {
            isOK = false;
        }
        
        return isOK;
    }
}
