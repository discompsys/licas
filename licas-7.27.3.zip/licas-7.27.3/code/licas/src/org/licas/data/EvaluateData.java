/*
 * EvaluateData.java
 *
 * Created on 12 November 2015
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.data;


import org.ai_heuristic.def.*;
import org.ai_heuristic.eval.metric.MetricDataset;
import org.ai_heuristic.eval.metric.ReplySet;
import org.ai_heuristic.functs.MathStat;
import org.licas.util.exception.LicasException;


/**
 * Provides one implementation of an evaluation function. This class can be used
 * to interpret a {@link DataQueryModel} object and try to make the appropriate evaluation call.
 * The evaluation can be on a single object, or a comparison between two objects. 
 * The DataQuery should include the data type and also the method to be invoked.
 * If the invocation is on a single object, then only the dataset is required.
 * If it is a comparison then both datasets and the operator as well are required.
 * @author Kieran Greer
 */
public class EvaluateData
{
    /** For distance measurements between simple java types */
    protected FunctionDef mathDistance;

    /** For comparisons of simple java types */
    protected EvaluateMathDef mathCompare;
    
    /** Parameters for constructing the data evaluator */
    protected DataQueryModel dataInfo;
    
    
    /** 
     * Create a new instance of EvaluateData.
     * @param theDataInfo defines what evaluators are used.
     */
    public EvaluateData(DataQueryModel theDataInfo)
    {
        super();
        initialise(theDataInfo);
    }
    
    /** 
     * Initialise some values.
     * @param theDataInfo defines what evaluators are used.
     */
    private void initialise(DataQueryModel theDataInfo)
    {
        mathDistance = null;
        mathCompare = null;
        dataInfo = theDataInfo;
    }

    /**
     * Return true if the data info relates to a comparison function, not a distance one.
     * @return true if implements {@code EvaluateMathDef} and not {@code FunctionMetricDef}.
     */
    public boolean isCompareFunction()
    {
        return ((dataInfo != null) && (dataInfo instanceof ComparisonQueryModel));
    }

    /**
     * Evaluate using the data settings of {@code dataInfo}. This method performs a comparison
     * calculation, where a comparison method compares the dataset with the compareWith dataset
     * in the {@link ComparisonQueryModel} dataInfo object.
     * @return the evaluation result.
     * @throws java.lang.Exception any error.
     */
    public Object evaluate() throws Exception
    {
        if (dataInfo.getFunctionClass() != null)
        {
            if (isCompareFunction() && (((ComparisonQueryModel)dataInfo).getCompareWith() != null))
            {
                if(((ComparisonQueryModel)dataInfo).getCompareWith() == null)
                {
                    checkMathCompare();
                    return mathCompare(dataInfo.getDataType(), dataInfo.getDataset(),
                            ((ComparisonQueryModel)dataInfo).getCompareWith(), ((ComparisonQueryModel)dataInfo).getOperator());
                }
                else
                {
                    checkMathDistance();
                    return evaluate(dataInfo.getDataset());
                }
            }
        }
        else
        {
            return new LicasException("EvaluateData.evaluate(): No function declared in the query model.");
        }

        //if no matching configuration
        return null;
    }

    /**
     * Evaluate the data object directly. Any data values or types must
     * have already have been set in the evaluator and/or data object.
     * @param toEvaluate the object to evaluate.
     * @return the evaluation result, probably a value, not true or false.
     * @throws java.lang.Exception any error.
     */
    public ReplySet evaluate(MetricDataset toEvaluate) throws Exception
    {
        checkMathDistance();
        return mathDistance.evaluate(toEvaluate);
    }

    /**
     * Evaluate the expression.
     * @param valueType the type of the value. This is the object type class name.
     * @param value1 first value.
     * @param value2 second value.
     * @param operator comparison operator - greater than (GT), less than (LT), etc.
     * These are evaluated using a SimpleEvaluate object from the heuristic package.
     * @return true if comparison is true and false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean mathCompare(String valueType, Object value1, Object value2, String operator)
            throws Exception
    {
        checkMathCompare();
        return mathCompare.mathCompare(valueType, value1, value2, operator);
    }

    /**
     * Add the two objects together and return.
     * @param valueType the type of the value.
     * @param value1 first value.
     * @param value2 second value.
     * @return the two values added together. Any error returns {@code null}.
     * @throws java.lang.Exception any error.
     */
    public Object add(String valueType, Object value1, Object value2)
            throws Exception
    {
        checkMathCompare();
        return mathCompare.add(valueType, value1, value2);
    }
    
    /**
     * Subtract the second value from the first and return the result.
     * @param valueType the type of the value.
     * @param value1 first value.
     * @param value2 second value.
     * @return the second value subtracted from the first. Any error returns {@code null}.
     * @throws java.lang.Exception any error.
     */
    public Object subtract(String valueType, Object value1, Object value2)
            throws Exception
    {
        checkMathCompare();
        return mathCompare.subtract(valueType, value1, value2);
    }
    
    /**
     * Multiply the first value by the second and return the result.
     * @param valueType the type of the value.
     * @param value1 first value.
     * @param value2 second value.
     * @return the first value multiplied by the second. Any error returns {@code null}.
     * @throws java.lang.Exception any error.
     */
    public Object multiply(String valueType, Object value1, Object value2)
            throws Exception
    {
        checkMathCompare();
        return mathCompare.multiply(valueType, value1, value2);
    }
    
    /**
     * Divide the first value by the second and return the result.
     * @param valueType the type of the value.
     * @param value1 first value.
     * @param value2 second value.
     * @return the first value divided by the second. Any error returns {@code null}.
     * @throws java.lang.Exception any error.
     */
    public Object divide(String valueType, Object value1, Object value2)
            throws Exception
    {
        checkMathCompare();
        return mathCompare.divide(valueType, value1, value2);
    }
    
    /**
     * Get the absolute value of the value passed in.
     * @param valueType the type of the value.
     * @param value1 first value.
     * @return the absolute (positive) value.
     * @throws java.lang.Exception any error.
     */
    public Object abs(String valueType, Object value1) throws Exception
    {
        return MathStat.abs(valueType, value1);
    }
    
    /**
     * Get the equivalent of the integer numerical value for the data type.
     * @param valueType the type of the value.
     * @param numerical an integer numerical value.
     * @return the equivalent of the numerical value for the data type.
     * @throws java.lang.Exception any error.
     */
    public Object numEquiv(String valueType, int numerical) throws Exception
    {
        return MathStat.numEquiv(valueType, numerical);
    }

    /**
     * Check that the local mathematical evaluator has been created.
     * @throws LicasException if the distance function is missing from {@code dataInfo}.
     * @throws java.lang.Exception any other error.
     */
    private void checkMathDistance() throws LicasException, Exception
    {
        if (dataInfo != null)
        {
            if (!isCompareFunction())
            {
                if (dataInfo.getFunctionClass() != null)
                {
                    mathDistance = dataInfo.distanceFunction();
                }
            }
        }

        if (mathDistance == null)
        {
            throw new LicasException("The distance function should be set in the related data info.");
        }
    }

    /**
     * Check that the local mathematical evaluator has been created.
     * @throws LicasException if the compare function is missing from {@code dataInfo}.
     * @throws java.lang.Exception any other error.
     */
    private void checkMathCompare() throws LicasException, Exception
    {
        if (dataInfo != null)
        {
            if (isCompareFunction())
            {
                if (dataInfo.getFunctionClass() != null)
                {
                    mathCompare = ((ComparisonQueryModel)dataInfo).compareFunction();
                }
            }
        }

        if (mathCompare == null)
        {
            throw new LicasException("The compare function should be set in the related data info.");
        }
    }

    /**
     * Return the comparison function if one can be created from the {@code dataInfo}.
     * @return the mathCompare function, or {@code null} if one cannot be created.
     * @throws java.lang.Exception any error.
     */
    public EvaluateMathDef getMathCompare() throws Exception
    {
        checkMathCompare();
        return mathCompare;
    }
}
