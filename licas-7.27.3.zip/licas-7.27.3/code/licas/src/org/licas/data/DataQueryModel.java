/*
 * DataQueryModel.java
 *
 * Created on 13 November 2015
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.data;


import org.ai_heuristic.def.FunctionMetricDef;
import org.ai_heuristic.eval.metric.MetricDataset;
import org.ai_heuristic.functs.Function;
import org.ai_heuristic.functs.metric.EuclideanDistance;
import org.licas.util.classloader.LoadObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;


/**
 * Query object for defining what an evaluator should evaluate. This version stores a method
 * description and an object to evaluate. Typically, the parent service is invoked with the method
 * details using Reflection and the data object as the target.
 * @author Kieran Greer
 */
public class DataQueryModel
{
    /** The data type */
    protected String dataType;
    
    /** Dataset or object to evaluate */
    protected MetricDataset dataSet;

    /** Comparison evaluator class name, so that it can be created */
    protected String functionClass;

    /** Any other parameters as key-value pairs. The ordering is maintained. */
    protected LinkedHashMap<String, Object> params;
    
    
    /** Create a new instance of DataQueryModel */
    public DataQueryModel()
    {
        dataType = null;
        dataSet = null;
        functionClass = null;
        params = new LinkedHashMap<>();
    }

    /**
     * Create the math comparison object from the stored class name.
     * @return the math comparison object, created using {@link LoadObject}, with an
     * empty constructor.
     * @throws java.lang.Exception any error.
     */
    public Function distanceFunction() throws Exception
    {
        if (functionClass == null) functionClass = EuclideanDistance.class.getName();
        return (Function) LoadObject.loadObject(new ArrayList<>(), functionClass, new ArrayList<>());
    }

    /**
     * Set the class name of the evaluator. For a distance query, the function should
     * implement the {@link FunctionMetricDef} interface, so that its method list is known.
     * @param functionClassname the evaluator class name.
     */
    public void setFunctionClass(String functionClassname)
    {
        functionClass = functionClassname;
    }

    /**
     * Get the class name of the math evaluator.
     * @return the value of mathCompare.
     */
    public String getFunctionClass()
    {
        return functionClass;
    }
    
    /**
     * Set the data type.
     * @param thisDataType the data type.
     */
    public void setDataType(String thisDataType)
    {
        dataType = thisDataType;
    }
    
    /**
     * Get the data type for the data object to be evaluated.
     * @return the value of dataType.
     */
    public String getDataType()
    {
        return dataType;
    }
    
    /**
     * Set the dataset object.
     * @param thisDataSet the dataset object.
     */
    public void setDataset(MetricDataset thisDataSet)
    {
        dataSet = thisDataSet;
    }
            
    /**
     * Get the dataset object.
     * @return the value of dataSet.
     */
    public MetricDataset getDataset()
    {
        return dataSet;
    }
    
    /**
     * Set the additional parameters list.
     * @param theParams the additional parameters as key-value pairs.
     */
    public void setParams(LinkedHashMap<String, Object> theParams)
    {
        params = theParams;
    }
    
    /**
     * Get the additional parameters list.
     * @return the value of params.
     */
    public LinkedHashMap<String, Object> getParams()
    {
        return params;
    }
    
    /**
     * Return true if the data object is an instance of a known data query type.
     * @param dataObj the data object.
     * @return true if a {@code DataQueryModel} or a {@link ComparisonQueryModel}.
     */
    public static boolean isDataQuery(Object dataObj)
    {
        return ((dataObj instanceof DataQueryModel) ||
                (dataObj instanceof ComparisonQueryModel));
    }

    /**
     * Return a deep clone this object.
     * @return a copy of this object.
     */
    public Object clone()
    {
        DataQueryModel queryModel;          //cloned model

        queryModel = new DataQueryModel();
        queryModel.setDataType(dataType);
        queryModel.setDataset(dataSet);
        queryModel.setFunctionClass(functionClass);
        if (params != null) {
            queryModel.params = (LinkedHashMap)params.clone();
        }

        return queryModel;
    }
}
