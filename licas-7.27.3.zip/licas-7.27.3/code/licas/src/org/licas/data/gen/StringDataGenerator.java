/*
 * StringDataGenerator.java
 *
 * Created on 3 March 2009
 *
 * Version 1.3.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.data.gen;


import org.licas.util.Const;
import org.licas.util.TypeConst;
import org.licas_xml.abs.Element;


/**
 * This class can generate random data for testing purposes. A new instance of this
 * class is only able to return random strings. 
 * <p>
 * The generator is seeded with a random number generator seed and a minimum and
 * maximum allowed value. The string that is used to generate each random value also
 * needs to be passed in as a parameter. A random value is then a sub-section of the
 * string, but to be consistent over all generators, it should be seeded with the same
 * value. This information can be passed through methods or through the initialisation 
 * XML script. A random value between min and max is then generated for each new value 
 * instance.
 * @author Kieran Greer
 */
public class StringDataGenerator extends DataGenerator
{
    /** String range of values */
    private String rangeStr;
    
    
    /** 
     * Create a new instance of StringDataGenerator.
     * @param thisDataType the generator data type.
     * @param thisSeed to seed a random number generator.
     * @throws java.lang.Exception any error.
     */
    public StringDataGenerator(long thisSeed, String thisDataType) throws Exception 
    {
        super(thisSeed, thisDataType);
    }
    
    /** 
     * Create a new instance of StringDataGenerator.
     * @param adminXml a script including the value ranges for the data. This
     * would now be a full admin script, with an {@link Const}.{@code PARAMETERS} 
     * section for these values.
     * @throws java.lang.Exception any error.
     */
    public StringDataGenerator(Element adminXml) throws Exception
    {
        super(adminXml);
    }
    
    /**
     * Parse the data generator script to set the appropriate variable values.
     * @param genXml the script to parse
     */
    public void parseGenXml(Element genXml)
    {
        String nextValue;                           //next value
        Element nextElem;                           //next element
        
        if (genXml != null)
        {
            genXml = getBaseElement(genXml);
            nextValue = genXml.getAttributeValue(Const.TYPE);
            dataType = nextValue.trim();

            nextElem = genXml.getChild(Const.MINVALUE);
            minValue = nextElem.getText();
            nextElem = genXml.getChild(Const.MAXVALUE);
            maxValue = nextElem.getText();
            nextElem = genXml.getChild(Const.RANGE);
            rangeStr = nextElem.getText();
            nextElem = genXml.getChild(Const.SEED);
            seed = Long.parseLong(nextElem.getText());
        }
    }
    
    /**
     * Set the range value for data generation.
     * @param thisRange the value. A random string are generated from this.
     */
    public void setRange(String thisRange)
    {
        rangeStr = thisRange;
    }
    
    /**
     * Generate the next data value.
     * @return the next randomly generated data value.
     */
    public Object getNextValue()
    {
        int i;
        int startIndex;                     //start index
        int count;                          //number of characters
        int minCount;                       //minimum count
        int maxCount;                       //maximum count
        char val1;                          //next value
        StringBuilder value;                //the whole value

        value = new StringBuilder();
        minCount = new Double(minValue).intValue();  
        maxCount = new Double(maxValue).intValue();
        count = rnd.nextInt(maxCount + 1);
        if (count < minCount) count = minCount;
        
        startIndex = rnd.nextInt(rangeStr.length() - count + 1);
        for (i = 0; i < count; i++)
        {    
            val1 = rangeStr.charAt(startIndex + i);            
            value.append(val1);
        }
        
        return value.toString();
    }
    
        /**
     * Return true if the data type is allowed by the data generator.
     * Only the String type is allowed for this generator.
     * @param theDataType the data type to check for.
     * @return true if this data generator can generate value of that type.
     */
    protected static boolean dataTypeOK(String theDataType)
    {
        return theDataType.equals(TypeConst.STRING);
    }
}
