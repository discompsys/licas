/**
 * Some basic data generators, for creating random data, mostly for simple data types.
 */
package org.licas.data.gen;