/*
 * DataGenerator.java
 *
 * Created on 3 March 2009
 *
 * Version 1.6.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.data.gen;


import org.licas.service.spec.BehaviourScript;
import org.licas.util.Const;
import org.licas.util.TypeConst;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.XMLFactory;

import java.util.Random;


/**
 * This defines the methods that should be implemented by a data generator.
 * The generator is initialised with a random number generator seed. This is
 * required to be done externally so that multiple instances can have different
 * seed values. If a random number generator is not used, then the value can be null (0).
 * @author Kieran Greer
 */
public abstract class DataGenerator
{
    /** The data type */
    protected String dataType;
    
    /** A seed value that can be used to initialise a random number generator */
    protected long seed;
    
    /** The minimum allowed value */
    protected String minValue;
    
    /** The maximum allowed value */
    protected String maxValue;
    
    /** An admin document might have been passed through the constructor */
    protected Element adminXml;
    
    /** The random number generator */
    protected Random rnd;
    
    /** 
     * Create a new instance of DataGenerator, ignoring the base service features.
     * @param thisDataType the generator data type.
     * @param thisSeed to seed a random number generator. Can be 0 if not used.
     */
    public DataGenerator(long thisSeed, String thisDataType)
    {
        super();
        seed = thisSeed;
        dataType = thisDataType;
        adminXml = null;
        initialise();
    }
    
    /** 
     * Create a new instance of DataGenerator.
     * @param adminXml a script including the value ranges for the data. This
     * would now be a full admin script, with an {@link Const}.{@code PARAMETERS} 
     * section for these values.
     * @throws java.lang.Exception any error.
     */
    public DataGenerator(Element adminXml) throws Exception
    {
        if (adminXml != null) parseGenXml(adminXml);
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        rnd = new Random(seed);
    }
    
    /**
     * Parse the data generator script to set the appropriate variable values.
     * @param genXml the script to parse
     * @throws java.lang.Exception any error.
     */
    public abstract void parseGenXml(Element genXml) throws Exception;
    
    /**
     * Generate the next data value.
     * @return the next randomly generated data value.
     * @throws java.lang.Exception any error.
     */
    public abstract Object getNextValue() throws Exception;
    
    /**
     * Get the base data generator element from the admin document element.
     * @param adminXml the constructor document. Should contain other child elements.
     * @return the base element with the data generator description, if not this one.
     */
    protected Element getBaseElement(Element adminXml)
    {
        Element nextElem;                           //next element
        
        nextElem = adminXml.getChild(Const.PARAMETERS);
        if (nextElem != null)
        {
            adminXml = nextElem;
        }
        nextElem = adminXml.getChild(Const.PARAMETER);
        if (nextElem != null)
        {
            adminXml = nextElem;
        }
        nextElem = adminXml.getChild(Const.DATASETTYPE);
        if (nextElem != null)
        {
            adminXml = nextElem;
        }

        return adminXml;
    }
    
    /**
     * Set the minimum value for data generation.
     * @param thisValue the minimum value. This needs to then be converted
     * to the actual value type.
     */
    public void setMinValue(String thisValue)
    {
        minValue = thisValue;
    }
    
    /**
     * Set the maximum value for data generation.
     * @param thisValue the maximum value. This needs to then be converted
     * to the actual value type.
     */
    public void setMaxValue(String thisValue)
    {
        maxValue = thisValue;
    }
    
    /**
     * Get the data type created by this generator. This could be a simple type
     * or a complex object class name.
     * @return the value of dataType.
     */
    public String getDataType()
    {
        return dataType;
    }
    
    /**
     * This method creates a data generator of the specified type and checks if
     * the data type entered is allowed. Only the default generators can be checked.
     * @param generator the generator class name.
     * @param theDataType the data type class name.
     * @return true if the generator can generate data of the specified type. If
     * the generator is not known, true is returned by default.
     */
    public static boolean isAllowedDataType(String generator, String theDataType)
    {
        if (generator.equalsIgnoreCase(StringDataGenerator.class.getName())) {
            return StringDataGenerator.dataTypeOK(theDataType);
        }
        else if (generator.equalsIgnoreCase(NumberDataGenerator.class.getName())) {
            return NumberDataGenerator.dataTypeOK(theDataType);
        }
        else if (generator.equalsIgnoreCase(ObjectDataGenerator.class.getName())) {
            return ObjectDataGenerator.dataTypeOK(theDataType);
        }
        
        return true;
    }
    
    /**
     * Get the generator class for the specified data type.
     * @param dataType the data type class name.
     * @return the class name of the generator that would create data of the specified
     * type. The {@link ObjectDataGenerator} class is returned if there is no match.
     */
    public static String getGeneratorClass(String dataType)
    {
        if (dataType.equals(TypeConst.STRING)) {
            return StringDataGenerator.class.getName();
        }
        else if (dataType.equals(TypeConst.INTEGER) || dataType.equals(TypeConst.INTEGEROBJ) ||
                dataType.equals(TypeConst.FLOAT) || dataType.equals(TypeConst.FLOATOBJ)) {
            return NumberDataGenerator.class.getName();
        }
        else {
            return ObjectDataGenerator.class.getName();
        }
    }
    
    /**
     * Create an XML script that can be used to initialise an instance of the
     * derived class. This method can create an xml script for the data generators
     * available as part of the base licas package only and assumes no additional
     * initialisation conditions.
     * @param testScript the test script with the config information.
     * @param rndSeed a seed for a random number generator if required. Can be 0.
     * @return an XML script that describes the conditions.
     */
    public static Element conditionsToXml(BehaviourScript testScript, long rndSeed)
    {
        return conditionsToXml(testScript.datasetType, testScript.minValue, testScript.maxValue,
            null, rndSeed);
    }
    
    /**
     * Create an XML script that can be used to initialise an instance of the
     * derived class. This method can create an xml script for the data generators
     * available as part of the base licas package only.
     * @param index a data index can be included for retrieving a string-based data
     * condition from the script, specifically, a {@code testScript.dataConditions} element.
     * @param testScript the test script with the config information.
     * @param rndSeed a seed for a random number generator if required. Can be 0.
     * @return an XML script that describes the conditions.
     */
    public static Element conditionsToXml(int index, BehaviourScript testScript, long rndSeed)
    {
        String dataCondition;
        
        dataCondition = null;
        if ((index >= 0) && !testScript.dataConditions.isEmpty() && 
            (testScript.dataConditions.size() > index)) {
            dataCondition = (testScript.dataConditions.get(index));
        }
        
        return conditionsToXml(testScript.datasetType, testScript.minValue,
                testScript.maxValue, dataCondition, rndSeed);
    }
    
    /**
     * Create an XML script that can be used to initialise an instance of the
     * derived class. This method can create an xml script for the data generators
     * available as part of the base licas package only.
     * @param dataType the data type class name.
     * @param minValue minimum value for the data generator.
     * @param maxValue maximum value for the data generator.
     * @param dataCondition condition under which data can be generated. Can be null 
     * or empty for a default setting.
     * @param rndSeed a seed for a random number generator if required. Can be 0.
     * @return an XML script that describes the conditions.
     */
    public static Element conditionsToXml(String dataType, double minValue, double maxValue,
            String dataCondition, long rndSeed)
    {
        int strLength;                                  //string length
        Element rootElem;                               //root element
        Element nextElem;                               //next element
        
        rootElem = XMLFactory.getInstance().createElement(Const.DATASETTYPE);
        rootElem.setAttribute(Const.TYPE, dataType);
        
        if (dataType.equals(TypeConst.STRING))
        {
            nextElem = XMLFactory.getInstance().createElement(Const.MINVALUE);
            nextElem.setText(String.valueOf(minValue));
            rootElem.addContent(nextElem);
            
            nextElem = XMLFactory.getInstance().createElement(Const.MAXVALUE);
            nextElem.setText(String.valueOf(maxValue));
            rootElem.addContent(nextElem);
            
            nextElem = XMLFactory.getInstance().createElement(Const.RANGE);

            if ((dataCondition != null) && !dataCondition.equals("")) {
                nextElem.setText(dataCondition);
            }
            else {
                //add 3 to give some variability on the subsequently generated values
                //they will be subsets of the generated string value
                strLength = ((int)maxValue * 2);
                if (strLength < ((int)maxValue + 3))
                    strLength = ((int)maxValue + 3);

                nextElem.setText(generateStringRange(strLength));
            }

            rootElem.addContent(nextElem);
            nextElem = XMLFactory.getInstance().createElement(Const.SEED);
            nextElem.setText(String.valueOf(rndSeed));
            rootElem.addContent(nextElem);
        }
        else if (dataType.equals(TypeConst.INTEGER) || dataType.equals(TypeConst.INTEGEROBJ) ||
                dataType.equals(TypeConst.FLOAT) || dataType.equals(TypeConst.FLOATOBJ)) {
            nextElem = XMLFactory.getInstance().createElement(Const.MINVALUE);
            nextElem.setText(String.valueOf(minValue));
            rootElem.addContent(nextElem);
            
            nextElem = XMLFactory.getInstance().createElement(Const.MAXVALUE);
            nextElem.setText(String.valueOf(maxValue));
            rootElem.addContent(nextElem);
            
            nextElem = XMLFactory.getInstance().createElement(Const.SEED);
            nextElem.setText(String.valueOf(rndSeed));
            rootElem.addContent(nextElem);
        }
        
        return rootElem;
    }
    
    /** 
     * Generate the new data range. This is a string-based value.
     * @param stringLength the length of the string to generate.
     * @return a randomly generated sequence of characters.
     */
    public static String generateStringRange(int stringLength)
    {
        int i;
        int rangeLength;                            //string range length
        char val1;                                  //character value
        StringBuilder rangeStr;                     //value range
        Random rnd;                                 //random number generator
            
        //generate the data range
        rnd = new Random();
        rangeStr = new StringBuilder();
        rangeLength = stringLength;

        for (i = 0; i < rangeLength; i++)
        {
            val1 = Character.forDigit(Character.getNumericValue('a') +
                rnd.nextInt(26), Character.MAX_RADIX);

            rangeStr.append(val1);
        }
        
        return rangeStr.toString();
    }
}
