/*
 * ComparisonQueryModel.java
 *
 * Created on 24 November 2015
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.data;


import org.ai_heuristic.def.EvaluateMathDef;
import org.ai_heuristic.eval.SimpleMathCompare;
import org.ai_heuristic.eval.metric.MetricDataset;
import org.licas.util.classloader.LoadObject;

import java.util.ArrayList;


/**
 * Query object for defining what an evaluator should evaluate. This version creates a
 * math comparison operator from its class name and invokes the method on that operator.
 * It therefore requires the two datasets that are being compared and the comparison operator.
 * It should also implement the {@link EvaluateMathDef} interface.
 * @author Kieran Greer
 */
public class ComparisonQueryModel extends DataQueryModel
{
    /** The comparison operator */
    private String operator;
    
    /** Dataset to compare with. Null for single evaluation */
    private MetricDataset compareWith;
       
    
    /** Create a new instance of ComparisonQueryModel */
    public ComparisonQueryModel()
    {
        super();
        operator = null;
        compareWith = null;
    }
    
    /**
     * Create the math comparison object from the stored class name.
     * @return the math comparison object, created using {@link LoadObject}, with an
     * empty constructor.
     * @throws java.lang.Exception any error.
     */
    public EvaluateMathDef compareFunction() throws Exception
    {
        if (functionClass == null) functionClass = SimpleMathCompare.class.getName();
        return (EvaluateMathDef)LoadObject.loadObject(new ArrayList<>(), functionClass, new ArrayList<>());
    }

    /**
     * Set the class name of the evaluator. For a comparison query, the function should
     * implement the {@link EvaluateMathDef} interface, so that its method list is known.
     * @param functionClassname the evaluator class name.
     */
    public void setFunctionClass(String functionClassname)
    {
        functionClass = functionClassname;
    }

    /**
     * Set the comparison operator. {@code Null} for evaluation on single object.
     * @param thisOperator the comparison operator.
     */
    public void setOperator(String thisOperator)
    {
        operator = thisOperator;
    }
    
    /**
     * Get the comparison operator. {@code Null} for single evaluation.
     * @return the value of operator.
     */
    public String getOperator()
    {
        return operator;
    }
    
    /**
     * Set the dataset object to compare with. Null for a single evaluation.
     * @param thisDataSet the dataset object.
     */
    public void setCompareWith(MetricDataset thisDataSet)
    {
        compareWith = thisDataSet;
    }
            
    /**
     * Get the dataset object to compare with.
     * @return the value of compareWith.
     */
    public MetricDataset getCompareWith()
    {
        return compareWith;
    }
}
