/*
 * ObjectDataGenerator.java
 *
 * Created on 28 June 2012
 *
 * Version 1.4.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.data.gen;


import org.jlog2.util.FileLoader;
import org.licas.parsers.Parsers;
import org.licas.util.Const;
import org.licas_text.util.QueryConst;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;


/**
 * This class can generate a java object for testing purposes. A new instance of this
 * class will parse the file specified into a java object, if a parser is available. 
 * @author Kieran Greer
 */
public class ObjectDataGenerator extends DataGenerator
{
    /** The path to a file to parse. */
    protected String urlPath;
    
    
    /** 
     * Create a new instance of ObjectDataGenerator.
     * @param thisDataType the generator data type.
     * @param thisSeed to seed a random number generator. Can be 0 if not used.
     * @throws java.lang.Exception any error.
     */
    public ObjectDataGenerator(long thisSeed, String thisDataType) throws Exception 
    {
        super(thisSeed, thisDataType);
    }
    
    /** 
     * Create a new instance of ObjectDataGenerator.
     * @param adminXml a script including the value ranges for the data. This
     * would now be a full admin script, with an {@link Const}.{@code PARAMETERS} 
     * section for these values.
     * @throws java.lang.Exception any error.
     */
    public ObjectDataGenerator(Element adminXml) throws Exception
    {
        super(adminXml);
    }
    
    /**
     * Parse the data generator script to set the appropriate variable values.
     * @param genXml the script to parse
     */
    public void parseGenXml(Element genXml)
    {
        String nextValue;                           //next value
        Element nextElem;                           //next element
        
        if (genXml != null) {
            genXml = getBaseElement(genXml);
            nextValue = genXml.getAttributeValue(Const.TYPE);
            if (nextValue != null) dataType = nextValue.trim();

            nextElem = genXml.getChild(QueryConst.FILEPATH);
            if (nextElem != null) urlPath = nextElem.getText();
        }
    }
    
    /**
     * Generate the next data value.
     * @return the next randomly generated data value.
     */
    public Object getNextValue() throws Exception
    {
        Object value;                               //the value
        String sourceString;                        //source information
        Element sourceElem;                         //source as an element
        
        sourceString = FileLoader.getInputStream(urlPath);        
        sourceElem = XmlHandler.stringToElement(sourceString);
        value = Parsers.parseObject(dataType, sourceElem);
        
        return value;
    }
    
    /**
     * Set the object data type, or its class name.
     * @param thisDataType the object data type.
     */
    public void setDataType(String thisDataType)
    {
        dataType = thisDataType;
    }
    
    /**
     * Set the file path to the file to parse.
     * @param thisUrlPath the path to the object file to parse.
     */
    public void setUrlPath(String thisUrlPath)
    {
        urlPath = thisUrlPath;
    }
    
        /**
     * Return true if the data type is allowed by the data generator.
     * True for this generator, for any data type.
     * @param theDataType the data type to check for.
     * @return true if this data generator can generate value of that type.
     */
    protected static boolean dataTypeOK(String theDataType)
    {
        return true;
    }
}
