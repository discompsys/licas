/**
 * Data evaluations and models for more complex query operations.
 */
package org.licas.data;