/*
 * NumberDataGenerator.java
 *
 * Created on 28 June 2012
 *
 * Version 1.5.1
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.data.gen;


import org.licas.util.Const;
import org.licas.util.TypeConst;
import org.licas_xml.abs.Element;


/**
 * This class can generate random data for testing purposes. An instance of this
 * class is only able to return random numbers of type {@code Integer} or {@code Float}. 
 * <p>
 * The generator is seeded with a random number generator seed and a minimum and
 * maximum allowed value. this information can be passed through methods or through
 * the initialisation XML script. A random value between min and max is then generated
 * for each new value instance.
 * @author Kieran Greer
 */
public class NumberDataGenerator extends DataGenerator
{
    /** 
     * Create a new instance of NumberDataGenerator.
     * @param thisDataType the generator data type.
     * @param thisSeed to seed a random number generator.
     * @throws java.lang.Exception any error.
     */
    public NumberDataGenerator(long thisSeed, String thisDataType) throws Exception 
    {
        super(thisSeed, thisDataType);
    }
    
    /** 
     * Create a new instance of NumberDataGenerator.
     * @param adminXml a script including the value ranges for the data. This
     * would now be a full admin script, with an {@link Const}.{@code PARAMETERS} 
     * section for these values.
     * @throws java.lang.Exception any error.
     */
    public NumberDataGenerator(Element adminXml) throws Exception
    {
        super(adminXml);
    }
    
    /**
     * Parse the data generator script to set the appropriate variable values.
     * @param genXml the script to parse
     */
    public void parseGenXml(Element genXml)
    {
        String nextValue;                           //next value
        Element nextElem;                           //next element

        if (genXml != null)
        {
            genXml = getBaseElement(genXml);
            nextValue = genXml.getAttributeValue(Const.TYPE);
            dataType = nextValue.trim();

            nextElem = genXml.getChild(Const.MINVALUE);
            minValue = nextElem.getText();
            nextElem = genXml.getChild(Const.MAXVALUE);
            maxValue = nextElem.getText();
            nextElem = genXml.getChild(Const.SEED);
            seed = Long.parseLong(nextElem.getText());
        }
    }
    
    /**
     * Generate the next data value.
     * @return the next randomly generated data value.
     */
    public Object getNextValue()
    {
        int minCount;                               //minimum nextInt
        int maxCount;                               //maximum nextInt
        int nextInt;                                //next integer
        float nextFloat;                            //next float
        
        minCount = new Double(minValue).intValue();
        maxCount = new Double(maxValue).intValue();
        
        if (dataType.equals(TypeConst.INTEGER) || dataType.equals(TypeConst.INTEGEROBJ))
        {
            nextInt = (maxCount-minCount+1);
            if (nextInt < 0) nextInt = 0;
            nextInt = (rnd.nextInt(nextInt) + minCount);
            return new Integer(nextInt);
        }
        else if (dataType.equals(TypeConst.FLOAT) || dataType.equals(TypeConst.FLOATOBJ))
        {
            nextFloat = ((rnd.nextFloat() * (float)(maxCount-minCount)) + (float)minCount);
            return new Float(nextFloat);
        }
        
        return null;
    }
    
    /**
     * Return true if the data type is allowed by the data generator.
     * Only float or integer is allowed for this generator.
     * @param theDataType the data type to check for.
     * @return true if this data generator can generate value of that type.
     */
    protected static boolean dataTypeOK(String theDataType)
    {
        return (theDataType.equals(TypeConst.INTEGER) ||
                theDataType.equals(TypeConst.INTEGEROBJ) ||
                theDataType.equals(TypeConst.FLOAT) ||
                theDataType.equals(TypeConst.FLOATOBJ));
    }
}
