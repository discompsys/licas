/*
 * PublishSubscribeDef.java
 *
 * Created on 30 January 2018.
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.def;


import org.licas.service.model.KeywordInfo;
import org.licas.service.model.WorkInfo;
import org.licas_xml.abs.Element;


/**
 * Interface for a publish-subscribe operation for the ESB server.
 * @author Kieran Greer
 */
public interface PublishSubscribeDef 
{
    /**
     * Subscribe for a service. Each time a service publishes a matching work description
     * any subscriber is sent the {@code WorkInfo} details. An immediate check is done to
     * determine if matching work is available.
     * @param workInfo new client details. It must include the keyword list and the method
     * to reply with.
     * <ol>
     * <li> A list of descriptive keywords and topic to match with.</li>
     * <li> Details of the client method to reply with if a service work matches with the keywords request.</li>
     * </ol>
     * The details method must comply with some specific formatting as follows:
     * <ol>
     * <li>It must include the client URI, as this is what identifies the request.
     * If {@code getClientURI()} is empty, then the request is ignored.</li>
     * <li>It must contain a parameter list of size 1, that is either an {@code Object} or
     * a {@link WorkInfo} object, as that is what will be sent as a reply.</li>
     * <li>The return type must be {@code void} (asynchronous call).
     * </ol>
     * @return true if added as a new request, or false if service request is already
     * registered, via keyword or topic overlap, for example.
     * @throws java.lang.Exception any error.
     */
    boolean subscribe(WorkInfo workInfo) throws Exception;

    /**
     * Un-subscribe for a service.
     * @param keyInfo list of descriptive keywords to uniquely identify the service.
     * @param clientURI the client URI defines the request client.
     * @throws java.lang.Exception any error.
     */
    void unsubscribe(KeywordInfo keyInfo, Element clientURI) throws Exception;

    /**
     * Publish to do work. This triggers a message to all subscribed services each time
     * and any publishing service may publish the same work request any number of times.
     * Only the first published request is saved however and then then sent out each time.
     * @param workInfo full work details, including an optional contract. The method
     * description must include the client URI as this is what identifies the request.
     * If {@code getClientURI()} is empty, then the request is ignored.
     * @return true if added as a new request, or false if work request is already
     * registered, via keyword or topic overlap, for example.
     * @throws java.lang.Exception any error.
     */
    boolean publish(WorkInfo workInfo) throws Exception;

    /**
     * Un-publish to do work.
     * @param keyInfo list of descriptive keywords to uniquely identify the work.
     * @param clientURI the client URI defines the request service.
     * @throws java.lang.Exception any error.
     */
    void unpublish(KeywordInfo keyInfo, Element clientURI) throws Exception;
}
