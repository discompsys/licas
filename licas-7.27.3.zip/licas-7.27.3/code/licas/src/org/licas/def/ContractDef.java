/*
 * Contract.java
 *
 * Created on 13 November 2012
 *
 * Version 1.0
 *
 * Copyright (c) 2011 Kieran Greer
 */


package org.licas.def;

import org.licas_xml.abs.Element;


/**
 * This defines the methods that should be implemented by a contract. A contract
 * is a description of an agreement between services, typically to allow access to
 * a service through passwords and/or to actually carry out the service in question.
 * @author Kieran Greer
 */
public interface ContractDef 
{
    /**
     * Get the negotiation or service contract.
     * @return the stored contract.
     */
    Element getContract();
}
