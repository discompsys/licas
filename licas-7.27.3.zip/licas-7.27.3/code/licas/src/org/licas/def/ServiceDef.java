/*
 * ServiceDef.java
 *
 * Created on 12 October 2019
 *
 * Version 1.1
 *
 * Copyright (c) 2019 Kieran Greer
 */


package org.licas.def;

import org.licas.Service;
import org.licas_xml.abs.Element;

import java.util.ArrayList;


/**
 * This interface contains some methods that a {@link Service} class should have public.
 * @author Kieran Greer
 */
public interface ServiceDef
{
    /**
     * Set the ID value, but only if it is null, otherwise it is not changed.
     * This method should probably not be called manually as the uuid is
     * automatically set when the service is loaded as the service name.
     * @param thisUUID the ID.
     */
    void setUUID(String thisUUID);

    /**
     * Get the unique service ID.
     * @return the unique service id.
     */
    String getUUID();

    /**
     * Set the service type value, but only if it is null, otherwise it is not changed.
     * This method should probably not be called manually as the service type is
     * automatically set when the service is loaded as the service name.
     * @param thisServiceType the service type.
     */
    void setServiceType(String thisServiceType);

    /**
     * Get the service type.
     * @return the service functional type.
     */
    String getServiceType();

    /**
     * Set the list of jar files required to load the service,
     * but only if the existing list is null, otherwise it is not changed.
     * @param theJarFile the jar file list. Values are jar paths of type String.
     */
    void setJarFile(ArrayList<String> theJarFile);

    /**
     * Return true if the wrapped object can be accessed by the password.
     * If the object is of type {@link Service} then its {@code canAccess} method is called,
     * otherwise true is automatically returned. Password protection is assumed for the
     * licas system only. Any wrapped object can still implement a different form of
     * password protection.
     * @param thePassword the password to use.
     * @return true if the wrapped object can be accessed or false otherwise.
     */
    boolean canAccess(String thePassword);

    /**
     * Return true if the password allows the calling component
     * to access this component by a temp password.
     * @param thePassword the password to use.
     * @return true if the entered password is the valid.
     */
    boolean canAccessTemp(String thePassword);

    /**
     * Return true if the key passed in is this service's admin key.
     * @param theAdminKey the key to check.
     * @return true if this is the service key
     */
    boolean isAdminKey(String theAdminKey);
}
