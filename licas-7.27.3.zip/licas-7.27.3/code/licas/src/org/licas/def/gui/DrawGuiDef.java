/*
 * DrawGuiDef.java
 *
 * Created on 30 August 2017
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.def.gui;

import org.licas.meta.ServiceMeta;

import java.util.ArrayList;

/**
 *
 * @author Kieran Greer
 */
public interface DrawGuiDef 
{
    /**
     * Process the metadata using the problem solver algorithm and return a new set 
     * of metadata for the graphical display.
     * @param serviceMeta the metadata to process.
     * @return new set of metadata for the graphical display.
     */
    ArrayList<ServiceMeta> metaView(ArrayList<ServiceMeta> serviceMeta);
}
