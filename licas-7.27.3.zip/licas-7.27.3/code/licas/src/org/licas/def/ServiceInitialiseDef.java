/*
 * ServiceInitialisedef.java
 *
 * Created on 17 January 2014
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.def;


import org.licas.Service;
import org.licas_xml.abs.Element;


/**
 * This defines the default method that gets called to finalise service initialisations.
 * @author Kieran Greer
 */
public interface ServiceInitialiseDef 
{
    /**
     * Finalise the initialisation of the service. This is the default method
     * that gets called to run the process. There does not have to be an implementation
     * of this method, when the initialisation will simply terminate instead.
     * @param servicesXml services to load XML section. So that it can be parsed
     * separately of a base {@link Service} class.
     * @throws java.lang.Exception any error.
     */
    void finaliseInitialisation(Element servicesXml) throws Exception;
}
