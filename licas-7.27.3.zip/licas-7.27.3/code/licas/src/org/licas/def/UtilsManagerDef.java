/*
 * UtilsManagerDef.java
 *
 * Created on 20 December 2017
 *
 * Version 1.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.def;


import org.licas.security.UtilsManager;


/**
 * This defines the methods that should be implemented to allow a {@link UtilsManager} object
 * to manage server resources.
 * @author Kieran Greer
 */
public interface UtilsManagerDef
{
    /**
     * Check the web folder and delete any temporary files.
     * @param time temp files older than {@code (current - time) milliseconds}, are deleted.
     */
    void webFolder(long time);
}
