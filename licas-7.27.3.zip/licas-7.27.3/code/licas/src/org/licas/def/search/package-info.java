/**
 * Some common definition interfaces for (metadata) search classes.
 */
package org.licas.def.search;