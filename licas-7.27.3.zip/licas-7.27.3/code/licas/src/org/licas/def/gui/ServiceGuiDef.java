/*
 * ServiceGuiDef.java
 *
 * Created on 27 October 2011
 *
 * Version 1.4
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.def.gui;


import org.licas_xml.abs.Element;

import java.awt.*;


/**
 * This interface must be implemented by any GUI form that wants to be recognised
 * as a GUI interface to a licas service.
 * @author Kieran Greer
 */
public interface ServiceGuiDef 
{ 
    /**
     * Get the related service's unique id.
     * @return the service's uuid.
     */
    String getID();

    /**
     * Initialise the GUI interface, open it and make it visible for use.
     * @param serviceUuid the uuid of the service the GUI relates to.
     * @param serviceType the type of service the GUI relates to.
     * @param servicePassword the password for calling the service.
     * @param serviceAdminKey the service admin key.
     * @param serviceUrl the full url path to the service that the GUI is for.
     * The server url is constructed from this.
     * @param serverPassword the local server password.    
     * @param theMainGui a reference to the main gui.
     * @throws java.lang.Exception any error. 
     */
    void initialiseAndOpen(String serviceUuid, String serviceType, String servicePassword,
                           String serviceAdminKey, Element serviceUrl, String serverPassword,
                           MainGuiDef theMainGui) throws Exception;
    
    /**
     * Set value indicating if auto-hide the GUI from view.
     * @param thisHide true if hide, false otherwise.
     */
    void setAutoHide(boolean thisHide);
    
    /**
     * Get value indicating if GUI should be auto-hidden.
     * @return the value of hide.
     */
    boolean getAutoHide();
    
    /**
     * Show or hide the GUI depending on conditions.
     * @param px the x-coord of the mouse.
     * @param py the y-coord of the mouse.
     */
    void showHide(int px, int py);
    
    /**
     * Return true if the px-py coord is inside the GUI frame with relation to the whole screen.
     * @param px the px-coord.
     * @param py the py-coord.
     * @return true if inside the gui frame, false otherwise.
     */
    boolean isInside(int px, int py);
    
    /**
     * Get the last recorded location for the GUI.
     * @return the location as a Point.
     */
    Point getLastLocation();
    
    /**
     * Shut the GUI down.
     */
    void closeGui();
}
