/*
 * LicasDocSearchDef.java
 *
 * Created on 22 September 2014
 *
 * Version 1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.def.search;


import org.licas.ServiceLinks;
import org.licas.server.ESB;
import org.licas_text.parser.QueryParser;
import org.licas_text.query.model.QueryModel;
import org.licas_xml.abs.Element;


/**
 * This is an interface for searching over document contents in legal folders.
 * @author Kieran Greer
 */
public interface LicasDocSearchDef
{
    /**
     * Query the server to parse documents to find matching information. To be
     * recognised by the default classes, the root {@code request} element should
     * have the tag name of {@code QueryConst.QUERYMODEL}, or 'Query_Model'. This should
     * then contain a description of the query request. For this default model, the
     * XML request that is passed in needs to be parsed by a {@link QueryParser} parser
     * into a {@link QueryModel} object, of the 'licas_text' package. This is what the 
     * default classes will then evaluate. The documentation describes the different 
     * fields in more detail.
     * @param queryEngine the query engine type.
     * @param callTimeout maximum time allowed for the call (in milliseconds).
     * @param request the query request.
     * @param serverLinks the {@link ESB} links information.
     * @return any suitable matches to the request. These are stored inside of
     * an element for each related service, with attributes to describe the service
     * uuid and type.
     * @throws java.lang.Exception any error.
     */
    Element docSearch(String queryEngine, int callTimeout, Element request,
            ServiceLinks serverLinks) throws Exception;
}
