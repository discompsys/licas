/*
 * ServiceMetaSearchDef.java
 *
 * Created on 6 April 2011
 *
 * Version 1.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.def.search;


import org.licas.ServiceLinks;
import org.licas.server.ESB;
import org.licas.util.exception.LicasException;
import org.licas_text.parser.QueryParser;
import org.licas_text.query.model.QueryModel;
import org.licas_text.util.QueryConst;
import org.licas_xml.abs.Element;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * This is an interface for including your own yellow pages lookup facility to a service.
 * @author Kieran Greer
 */
public interface ServiceMetaSearchDef
{
    /**
     * Get all child service names.
     * @return all service uuids, of type String.
     */
    ArrayList<String> getServiceNames();

    /**
     * Return all child service names for a list of service types.
     * @param thisServiceTypes the service types list.
     * @param reciprocal is false return all service names of the service types,
     * if true return all service names of all other types.
     * @return the service names for the service types list.
     * @throws LicasException if the service types input is {@code null}.
     */
    ArrayList<String> getServiceNames(ArrayList<String> thisServiceTypes, boolean reciprocal) throws LicasException;

    /**
     * Return all service types for all stored services.
     * @return all service types.
     */
    ArrayList<String> getServiceTypes();

    /**
     * Get the class types for all services that are stored.
     * @return the service handles with the class types for the services
     * of this component.
     */
    HashMap<String, String> getServiceClasses();

    /**
     * Query the service metadata to find matching information. To be
     * recognised by the default classes, the root {@code request} element should
     * have the tag name of {@link QueryConst}.{@code QUERYMODEL}, or 'Query_Model'. This should
     * then contain a description of the query request. For this default model, the
     * XML request that is passed in needs to be parsed by a {@link QueryParser} parser
     * into a {@link QueryModel} object, of the 'licas_text' package. This is what the 
     * default classes will then evaluate. The documentation describes the different 
     * fields in more detail.
     * @param queryEngine the query engine type. Required for a distributed query.
     * @param callTimeout maximum time allowed for the call (in milliseconds).
     * @param request the query request.
     * @param serverLinks the {@link ESB} links information.
     * @return any suitable matches to the request. These are stored inside of
     * an element for each related service, with attributes to describe the service
     * uuid and type.
     * @throws java.lang.Exception any error.
     */
    Element metaSearch(String queryEngine, int callTimeout, Element request, ServiceLinks serverLinks)
            throws Exception;
}
