/**
 * Some common definition interfaces that the system uses to identify types of class.
 */
package org.licas.def;