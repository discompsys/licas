/*
 * MainGuiDef.java
 *
 * Created on 9 May 2012
 *
 * Version 1.3
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.def.gui;


/**
 * This interface must be implemented the main licas GUI.
 * @author Kieran Greer
 */
public interface MainGuiDef 
{ 
    /**
     * Get the currently displayed document.
     * @return the document currently displayed in the document text area.
     */
    String getDocument();
    
    /**
     * Register to draw or unregister to draw the main view.
     * @param drawView the component that provides the view to draw.
     * @param reg true if register or false if unregister.
     */
    void registerView(DrawGuiDef drawView, boolean reg);
    
    /**
     * Set the gui indicated to the front of the window order and update main window
     * saved ordering.
     * @param guiKey the key the gui is stored under.
     */
    void setServiceToFront(String guiKey);
    
    /** 
     * Log a message in the main GUI system.
     * @param message the message to log.
     */
    void logMessage(String message);
    
    /** 
     * Log an exception in the main GUI system.
     * @param logLevel the level to log at.
     * @param methodName name of method error created in.
     * @param msg optional additional information.
     * @param ex the exception to log.
     */
    void logException(String logLevel, String methodName, String msg, Exception ex);
}
