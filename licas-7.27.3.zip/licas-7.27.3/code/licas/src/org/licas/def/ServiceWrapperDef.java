/*
 * ServiceWrapperDef.java
 *
 * Created on 27 january 2011
 *
 * Version 1.4
 *
 * Copyright (c) 2011 Kieran Greer
 */


package org.licas.def;

import org.licas.*;
import org.licas.call.MethodInfo;
import org.licas.security.Metrics;
import org.licas.service.model.WorkInfo;
import org.licas_xml.abs.Element;

import java.lang.reflect.Method;
import java.util.ArrayList;


/**
 * This interface contains some methods that a {@link ServiceWrapper} should have public. The
 * wrapper needs to send certain requested information to its parent service, or to a server.
 * The required methods are implemented in the default {@link ServiceWrapper} or {@link ServiceWrapperLegacy}
 * classes. Note that the service now also stores some metrics or the message passed to a service.
 * @author Kieran Greer
 */
public interface ServiceWrapperDef extends ServiceDef
{
    /**
     * Return true if the stored object is legacy code, false if a licas service.
     * @return true if stores a legacy object, not a licas service.
     */
    boolean storesLegacy();

    /**
     * Get the grade for this service.
     * @return the value of serviceGrade.
     */
    String getServiceGrade();

    /**
     * Get the description value. This is just the description and not the full
     * set of admin rules.
     * @return the service description.
     */
    Element getDescription();

    /**
     * Get the fully qualified uuid path back to the first parent object and server.
     * @return the fully qualified path to access this component on the server.
     * @throws java.lang.Exception any error.
     */
    Element getFullPath() throws Exception;

    /**
     * Get the work protocol details for the service.
     * @return the service's {@code workInfo} details.
     */
    WorkInfo getWorkInfo();

    /**
     * Invoke the method on the stored object with the specified parameters.
     * @param theMethod the method to invoke.
     * @param params the parameter list.
     * @return the result of the method invocation.
     * @throws java.lang.Exception any error.
     */
    Object invokeObj(Method theMethod, Object[] params) throws Exception;

    /**
     * Add some metrics values relating to the current message.
     * @param messageObj the message object.
     * @param theAdminKey the admin key for the parent service.
     */
    void addMetrics(MethodInfo messageObj, String theAdminKey);
    
    /**
     * Get the default message/transaction metrics.
     * @return the value of metrics.
     */
    Metrics getMetrics();
    
    /**
     * Copy and set certain settings between the service object and the wrapper.
     * @param parentService the parent of the wrapper.
     * @throws java.lang.Exception any error.
     */
    void copyToService(Object parentService) throws Exception;

    /**
     * Reset the wrapper settings based on the wrapped object if a service.
     */
    void copyFromService();

    /**
     * Get the class type of the stored object.
     * @return the stored object classname.
     */
    Class getObjClass();

    /**
     * Set the wrapped object that is typically derived from {@link Service},
     * but can be a legacy object of any type.
     * @param theObj the value of obj.
     */
    void setObjService(Object theObj);
    
    /**
     * Get the stored object service.
     * @param adminKey the admin key for the object or wrapper.
     * @return the stored object, or null if not the admin key.
     */
    Object getObjService(String adminKey);

    /**
     * Get a list of public methods that can be accessed through the service.
     * @return a list of Reflection method descriptions, not the licas descriptions.
     */
    ArrayList<Method> reflectionMethods();
}
