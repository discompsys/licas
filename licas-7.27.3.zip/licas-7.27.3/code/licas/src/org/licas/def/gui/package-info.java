/**
 * Some common definition interfaces for GUI interface classes.
 */
package org.licas.def.gui;