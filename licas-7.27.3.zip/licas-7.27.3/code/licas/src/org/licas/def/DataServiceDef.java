/*
 * DataServiceDef.java
 *
 * Created on 13 November 2015
 *
 * Version 1.5
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.def;


import org.licas.module.DataModule;
import org.licas.service.resource.*;
import org.licas.util.ServiceConst;
import org.licas.util.exception.*;
import org.licas_xml.abs.Element;


/**
 * This defines the methods that should be implemented by a data service,
 * to communicate the data with other services.
 * @author Kieran Greer
 */
public interface DataServiceDef
{
    /**
     * Reset variables for another test run.
     */
    void resetValues();

    /**
     * Get the data type.
     * @return the data type.
     */
    String getDataType();

    /**
     * Set the value that this service will use as its data source. This method
     * creates an {@link ObjResource} in the {@link DataModule} and stores the value
     * directly.
     * @param thisDataType the data type.
     * @param thisDataObj the data object.
     * @param adminKey the admin key for the service.
     * @return true if set OK, false otherwise.
     * @throws java.lang.Exception any error.
     */
    boolean setData(String thisDataType, Object thisDataObj, String adminKey) throws Exception;

    /**
     * Set the value that this service will use as its data source. This method parses the data
     * XML description to create the appropriate data {@link Resource} in the {@link DataModule}.
     * @param dataXml the data description to parse.
     * @param adminKey the admin key for the service.
     * @return true if set OK, false otherwise.
     * @throws java.lang.Exception any error.
     */
    boolean setData(Element dataXml, String adminKey) throws Exception;

    /**
     * This is used to send the current data and result to a behaviour mediator if one is running.
     * <br>1. The data object is the static metadata {@code Data} entry.
     * <br>2. The result object is retrieved and assumed to be in XMl here.
     * <br>3. This default method also sends link information.
     * <br>The behaviour service can aggregate all of the service info's, to produce graphs or other results.
     * <p>
     * This version sends the data information to a service identified by
     * {@link ServiceConst}.{@code BEHAVIOURMEDIATOR}. It includes the data element
     * of this service, any links that it has formed and also the result of the
     * evaluation process.
     * @param adminKey as it would typically be called internally, it is protected by
     * the service's admin key.
     * @throws PasswordException incorrect password for the server or mediator service.
     * @throws MethodNotFoundException the mediator does not have the calling method.
     * @throws java.lang.Exception any other error.
     */
    void dataXmlBM(String adminKey) throws PasswordException, MethodNotFoundException, Exception;

    /**
     * This is used to send the current data result to a data hub if one is running.
     * The data hub service can aggregate all of the service info's and make it available.
     * <p>
     * This version sends the data information to a service identified by
     * {@link ServiceConst}.{@code DATAHUB}. It includes the data element
     * of this service, any links that it has formed and also the result of the
     * evaluation process.
     * @param adminKey as it would typically be called internally, it is protected by
     * the service's admin key.
     * @throws PasswordException incorrect password for the server or mediator service.
     * @throws MethodNotFoundException the mediator does not have the calling method.
     * @throws java.lang.Exception any other error.
     */
    void dataXmlDH(String adminKey) throws PasswordException, MethodNotFoundException, Exception;
}
