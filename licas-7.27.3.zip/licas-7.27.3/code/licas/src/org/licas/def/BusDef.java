/*
 * BusDef.java
 *
 * Created on 20 April 2020
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.def;


import org.licas.call.MethodInfo;


/**
 * This defines the methods that should be implemented to allow a method invocation on a service.
 * @author Kieran Greer
 */
public interface BusDef
{
    /**
     * Execute a call on the system message bus. This passes the message to a queue on the server
     * from where it gets selected for processing by a service.
     * @param methodInfo the method call description with all of the required information.
     * @return Object the reply to the call.
     * @throws java.lang.Exception any error.
     */
    Object messageBus(MethodInfo methodInfo) throws Exception;
}
