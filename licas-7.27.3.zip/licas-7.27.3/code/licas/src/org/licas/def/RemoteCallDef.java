/*
 * RemoteCallDef.java
 *
 * Created on 11 June 2009
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 */


package org.licas.def;


import org.licas.call.CallObject;
import org.licas.call.MethodInfo;


/**
 * This defines the methods that should be implemented to allow a method invocation on a service,
 * from a local, or one of the remote, communication objects.
 * @author Kieran Greer
 */
public interface RemoteCallDef
{
    /**
     * Execute a remote call. Use this method to pass the dataset in a single call.
     * @param methodInfo the method call description with all of the required information.
     * @return Object the reply to the call.
     * @throws Exception any error.
     */
    Object execute(MethodInfo methodInfo) throws Exception;

    /**
     * Get the value indicating the type of remote call.
     * @return the value of callType.
     */
    String getCallType();
}
