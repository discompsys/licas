/*
 * ServiceSerialize.java
 *
 * Created on 3 September 2015
 *
 * Version 1.5.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas;



import org.licas.def.ServiceDef;
import org.licas.meta.ServiceMeta;
import org.licas.module.ModuleHandler;
import org.licas.parsers.Parsers;
import org.licas.parsers.admin.ServiceMetaParser;
import org.licas.query.LinkQueryConfig;
import org.licas.server.LocalServer;
import org.licas.service.link.Link;
import org.licas.util.*;
import org.licas.util.classloader.LoadObject;
import org.licas.util.exception.ServiceException;
import org.licas_xml.abs.*;
import org.licas_xml.model.XmlHandler;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.FileLoader;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;


/**
 * This can be used to serialize a service to or from XML, using reflection.
 * It can also be configured so that only parts of a service are serialized,
 * when only those parts would then be added to the re-constructed service. This
 * includes most of the admin and metadata objects, including the linking.
 * @author Kieran Greer
 */
public class ServiceSerialize 
{
    /** The logger */
    private static final Logger logger;
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServiceSerialize.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Serialize the service admin info and return as an XML-based description.
     * This version will automatically remove some of the admin meta elements, for
     * safety reasons. Note that only the admin elements are serialized, not any
     * other variables in the service.
     * As well as this, local Service variables such as passwords, or comm IDs are serialized.
     * @param theService the service to serialize.
     * @return an XML representation of all named elements.
     * @throws Exception any error.
     */
    protected Element serviceToXml(Service theService) throws Exception
    {
        ArrayList<String> toSerialize;                  //elements to serialize
        ArrayList<String> toRemove;                     //elements to remove
        
        toSerialize = new ArrayList<>();
        toRemove = new ArrayList<>();
        
        parseSerializeAdmin(theService, toSerialize, toRemove);        
        if (toRemove.isEmpty()) {
            toRemove = Service.defaultAdminToRemove();
        }
        
        return serviceToXml(theService, toRemove, toSerialize);
    }
    
    /**
     * Serialize the full service admin info, minus {@code adminToRemove} and return as an XML-based description.
     * This will create a full admin description and then remove the elements specified
     * in the adminToRemove list. An empty list will serialize everything and therefore is less safe.
     * As well as this, local Service variables such as passwords, or comm IDs are serialized.
     * An additional list specified other service-local variables to serialize and store.
     * @param theService the service to serialize.
     * @param adminToRemove if any section is indicated here through the XML tag name, it is removed first.
     * @param toSerialize list of variable names to serialize.
     * @return an XML representation of all named elements, or null if the admin key is incorrect.
     * @throws Exception any error.
     */
    protected Element serviceToXml(Service theService, ArrayList<String> adminToRemove, ArrayList<String> toSerialize)
            throws Exception
    {
        int i;
        String varName;                             //var name
        String nextKey;                             //next key
        String adminKey;                            //admin key
        Iterator<String> allKeys;                   //key list
        Element serviceXml;                         //full service meta
        Element varInstances;                       //variable instances
        Element varInstance;                        //variable instance
        Element linksElem;                          //links element
        Element serializeElems;                     //serialize elements
        Element serializeElem;                      //serialize element
        Element objElem;                            //object element
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Element nextElem3;                          //next element
        Vector<Node> elemList;                      //element list
        MessageInfo messageInfo;                    //message info
        ServiceMeta serviceMeta;                    //service metadata
        ServiceMetaParser metaParser;               //service meta parser
        ServiceInfo serviceInfo;                    //service info
        ServiceDef childService;                    //child service
        Object varValue;                            //variable value
        Object clientLink;                          //client link
        
        
        if (adminToRemove == null) adminToRemove = new ArrayList<>();
        adminKey = theService.getPasswordHandler().getAdminKey();
        
        //create the full metadata description
        metaParser = new ServiceMetaParser();
        serviceMeta = theService.createMetaFull(theService.getJarFile(), adminKey);
        serviceXml = metaParser.serialize(serviceMeta, false);        
        linksElem = allLinksToXml(theService, true, true);
        if (linksElem.hasChildren()) serviceXml.addContent(linksElem);

        serviceXml.setName(Const.SERVICE);
        serviceXml.removeAttribute(Const.UUID);
        nextElem = XMLFactory.getInstance().createElement(Const.UUID);
        nextElem.setText(theService.getUUID());
        serviceXml.addContent(nextElem);

        //always remove the method definitions
        serviceXml.removeChild(Const.METHODS);
        
        //remove the other metadata as required
        if (adminToRemove.contains(Const.HANDLE)) {
            serviceXml.removeChild(Const.HANDLE);
        }
        if (adminToRemove.contains(MetaConst.PERMANENTLINKSERVICEMETA)) {
            serviceXml.removeChild(MetaConst.PERMANENTLINKSERVICEMETA);
        }
        if (adminToRemove.contains(MetaConst.DYNAMICLINKSERVICEMETA)) {
            serviceXml.removeChild(MetaConst.DYNAMICLINKSERVICEMETA);
        }
        if (adminToRemove.contains(MetaConst.ASSOCIATEDLINKSERVICEMETA)) {
            serviceXml.removeChild(MetaConst.ASSOCIATEDLINKSERVICEMETA);
        }

        if (!adminToRemove.contains(Const.SERVICEPASSWORD)) {
            nextElem = XMLFactory.getInstance().createElement(Const.SERVICEPASSWORD);
            nextElem.setText(theService.getPasswordHandler().getPassword());
            serviceXml.addContent(nextElem);
        }
        if (!adminToRemove.contains(Const.SERVICEKEY)) {
            nextElem = XMLFactory.getInstance().createElement(Const.SERVICEKEY);
            nextElem.setText(theService.getPasswordHandler().getAdminKey());
            serviceXml.addContent(nextElem);
        }
        if (!adminToRemove.contains(Const.SERVICESTATE)) {
            nextElem = XMLFactory.getInstance().createElement(Const.SERVICESTATE);
            nextElem.setText(theService.getServiceState(adminKey));
            serviceXml.addContent(nextElem);
        }
        if (!adminToRemove.contains(Const.METAACCESSALLOWED)) {
            nextElem = XMLFactory.getInstance().createElement(Const.METAACCESSALLOWED);
            nextElem.setText(Boolean.toString(theService.canAccessMeta()));
            serviceXml.addContent(nextElem);
        }
        if (!adminToRemove.contains(Const.NESTEDACCESSALLOWED)) {
            nextElem = XMLFactory.getInstance().createElement(Const.NESTEDACCESSALLOWED);
            nextElem.setText(Boolean.toString(theService.canAccessNested()));
            serviceXml.addContent(nextElem);
        }
        if (!adminToRemove.contains(Const.PASSWORDS)) {
            nextElem = theService.getPasswordHandler().toXml();
            serviceXml.addContent(nextElem);
        }

        //add variable instance values
        if (!adminToRemove.contains(Const.INSTANCEVALUES)) {
            varInstances = serviceXml.getChild(Const.INSTANCEVALUES);
            if (varInstances != null) {
                elemList = varInstances.getChildren();
                for (i  = 0; i < elemList.size(); i++)
                {
                    varInstance = (Element)elemList.get(i);
                    objElem = varInstance.getElementChildAtIndex(0);               
                    varName = varInstance.getAttributeValue(Const.NAME);

                    varValue = theService.getInstanceValue(varName);                
                    if (varValue != null) {
                        objElem.detach();
                        objElem = Parsers.serializeToElement(varValue);
                        varInstance.addContent(objElem);
                    }
                }
            }
        }

        //add serialize variable instance values
        if ((toSerialize != null) && !toSerialize.isEmpty()) {
            serializeElems = XMLFactory.getInstance().createElement(Const.SERIALISEVALUES);
            serviceXml.addContent(serializeElems);
            
            for (i = 0; i < toSerialize.size(); i++)
            {
                varName = toSerialize.get(i);
                serializeElem = XMLFactory.getInstance().createElement(Const.SERIALISEVALUE);
                serializeElem.setAttribute(Const.NAME, varName);
                serializeElems.addContent(serializeElem);

                varValue = theService.getInstanceValue(varName);                   
                if (varValue != null) {
                    objElem = Parsers.serializeToElement(varValue);
                    serializeElem.addContent(objElem);
                }
            }
        }

        //add current communication IDs and related conversation info
        if (!adminToRemove.contains(Const.COMMUNICATIONIDS)) {
            allKeys = theService.messageStore.getCommIDs().iterator();
            if (allKeys.hasNext()) {
                nextElem = XMLFactory.getInstance().createElement(Const.COMMUNICATIONIDS);
                serviceXml.addContent(nextElem);

                while (allKeys.hasNext())
                {
                    nextKey = allKeys.next();
                    messageInfo = theService.messageStore.getCommClient(nextKey);

                    nextElem2 = XMLFactory.getInstance().createElement(Const.COMMUNICATIONID);
                    nextElem2.setAttribute(Const.VALUE, nextKey);
                    nextElem.addContent(nextElem2);

                    nextElem3 = XMLFactory.getInstance().createElement(Const.TIMESTAMP);
                    nextElem3.setText(String.valueOf(messageInfo.getTimeStamp()));
                    nextElem2.addContent(nextElem3);

                    clientLink = messageInfo.getMessage();
                    nextElem3 = XMLFactory.getInstance().createElement(Const.CLIENTURI);
                    nextElem2.addContent(nextElem3);

                    if (ObjectHandler.isElement(clientLink))
                        nextElem3.addContent((Element)clientLink);
                    else if (ObjectHandler.isString(clientLink))
                        nextElem3.setText((String)clientLink);
                    else
                        nextElem3.setText(String.valueOf(clientLink));
                }
            }
        }

        //add full meta descriptions for all child services
        if (!adminToRemove.contains(Const.SERVICES)) {
            nextElem = XMLFactory.getInstance().createElement(Const.SERVICES);
            serviceXml.addContent(nextElem);

            if (!adminToRemove.contains(Const.SERVICESTOLOAD)) {
                nextElem2 = XMLFactory.getInstance().createElement(Const.SERVICESTOLOAD);
                nextElem.addContent(nextElem2);

                //serialize the child services and add
                allKeys = theService.serviceAdmin.services.keySet().iterator();
                while (allKeys.hasNext())
                {
                    nextKey = allKeys.next();
                    serviceInfo = theService.serviceAdmin.services.get(nextKey);
                    childService = serviceInfo.getService();

                    if (ModuleHandler.isService(childService)) {
                        nextElem3 = ((Service)childService).serviceToXml(theService.getPasswordHandler().getAdminKey(nextKey));
                        nextElem2.addContent(nextElem3);
                    }
                }
            }
        }
        
        return serviceXml;
    }
    
    /**
     * If an admin serialize variables section exists, then retrieve and parse.
     * If not, then do not change the input parameter lists.
     * @param theService the service to serialize.
     * @param toSerialize to list the local variables to serialize. This must be
     * an empty initialised list, to be added to.
     * @param adminToRemove to list the admin variables to remove. This must be
     * an empty initialised list, to be added to.
     */
    protected void parseSerializeAdmin(Service theService, ArrayList<String> toSerialize, ArrayList<String> adminToRemove)
    {
        int i, j;
        String nextValue;                       //next value
        Element serializeXml;                   //serialize xml
        Element nextElem;                       //next element
        Element nextElem2;                      //next element
        Vector<Node> elemList;                  //element list
        Vector<Node> elemList2;                 //element list
        
        serializeXml = theService.serviceAdmin.adminInfo.getSerializeValues();
        if (serializeXml != null) {
            elemList = serializeXml.getChildren();
            for (i = 0; i < elemList.size(); i++)
            {
                nextElem = (Element)elemList.get(i);
                if (nextElem.getName().equals(Const.SERIALISEVALUE)) {
                    nextValue = nextElem.getAttributeValue(Const.NAME);
                    if (nextValue.equals(MetaConst.ADMIN)) {
                        elemList2 = nextElem.getChildren();
                        for (j = 0; j < elemList2.size(); j++)
                        {
                            nextElem2 = (Element)elemList2.get(j);
                            if (nextElem2.getName().equals(Const.VALUE)) {
                                nextValue = nextElem.getAttributeValue(Const.NAME);
                                adminToRemove.add(nextValue);
                            }
                        }
                    }
                    else {
                        toSerialize.add(nextValue);
                    }
                }
            }
        }
    }
    
    /**
     * Read the contents of the admin document and re-create the service from it.
     * @param serviceXml a full XML description of the service.
     * @param password parent password, probably the server currently running. Need to
     * use this instead of the stored value if a server.
     * @return the re-created service, probably derived from {@link Service}, but it
     * might be a wrapped object.  
     * @throws java.lang.Exception any error.
     */
    protected Object xmlToService(Element serviceXml, String password) throws Exception
    {
        int i;
        long timeStamp;                             //timestamp
        String thisPassword;                        //this password
        String thisAdminKey;                        //this admin key
        String serviceClass;                        //service class
        String commID;                              //comm id
        String nextValue;                           //next value
        ArrayList<String> jarFiles;                 //list of jar files
        ArrayList<Object> params;                   //parameters list
        Element adminXml;                           //admin document
        Element linksElem;                          //links element
        Element dynamicLinksXml;                    //dynamic links
        Element paramXml;                           //parameters element
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Element nextElem3;                          //next element
        Vector<Node> elemList;                      //list of elements
        Object clientLink;                          //client link
        MessageInfo messageInfo;                    //message info
        Constructor[] constructors;                 //all constructors
        Constructor nextConstructor;                //the next constructor
        Constructor theConstructor;                 //the constructor
        Class[] paramTypes;                         //param types
        Object thisService;                         //this service
        
        //create the full metadata description
        thisService = null;
        serviceClass = null;
        thisPassword = Const.ANON;
        thisAdminKey = Const.ANON;
        adminXml = null;
        jarFiles = new ArrayList<>();
        
        //add service attribute values
        serviceXml.setName(MetaConst.ADMIN);
        nextElem = serviceXml.getChild(Const.CLASSNAME);
        if (nextElem != null) {
            serviceClass = nextElem.getText();
        }
        nextElem = serviceXml.getChild(Const.SERVICEPASSWORD);
        if (nextElem != null) {
            thisPassword = nextElem.getText();
        }       
        nextElem = serviceXml.getChild(Const.SERVICEKEY);
        if (nextElem != null) {
            thisAdminKey = nextElem.getText();
        }
        nextElem = serviceXml.getChild(Const.FILEURI);
        if (nextElem != null) {
            try {
                adminXml = XmlHandler.stringToElement(FileLoader.getInputStream(nextElem.getText()));
            }
            catch (Exception ex)
            {}
        }
        
        elemList = serviceXml.getChildren();
        for (i = 0; i < elemList.size(); i++)
        {
            nextElem = (Element)elemList.get(i);
            if (nextElem.getName().equals(Const.JARFILEXML)) {
                jarFiles.add(nextElem.getValue());
            }
        }
        
        if (serviceClass != null) {
            if (adminXml != null) {
                elemList = (Vector)adminXml.getChildren().clone();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextElem = (Element)elemList.elementAt(i);                    
                    if (serviceXml.getChild(nextElem.getName()) == null) {
                        serviceXml.addChild(nextElem.detach());
                    }
                }
            }
            
            //try to find appropriate constructor and parameter list
            //there can be a Parameters section, or it can be derived, for example
            theConstructor = null;
            constructors = ReflectionHandler.getConstructors(LoadObject.getClass(serviceClass));
            
            params = new ArrayList<>();
            nextElem = serviceXml.getChild(Const.PARAMETERS);
            if (nextElem != null) {
                elemList = (Vector)nextElem.getChildren().clone();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextElem2 = (Element)elemList.get(i);
                    if (nextElem2.hasChildren()) {
                        if (nextElem2.getName().equals(Const.PARAMETER)) {
                            paramXml = nextElem2.getElementChildAtIndex(0);
                            params.add(Parsers.parse(paramXml));
                        }
                        else {
                            params.add(Parsers.parse(nextElem2));
                        }
                    }
                    else {
                        params.add(nextElem2.getText());
                    }
                }
            }
            else {
                if (ObjectHandler.classInstance(Service.class, LoadObject.getClass(serviceClass))) {
                    params.add(thisPassword);
                    params.add(thisAdminKey);
                    params.add(serviceXml);
                }
            }
            
            while ((theConstructor == null) && (params.size() > 0))
            {
                paramTypes = new Class[params.size()];
                for (i = 0; i < params.size(); i++) {
                    paramTypes[i] = params.get(i).getClass();
                }
                
                nextConstructor = ReflectionHandler.getConstructor(constructors, paramTypes);
                if (nextConstructor != null) {
                    theConstructor = nextConstructor;
                }
                else {
                    params.remove(params.size()-1);
                }
            }
            
            //the parameters description might be missing, when cannot load properly
            try {
                thisService = LoadObject.loadObject(jarFiles, serviceClass, 
                    params);
            }
            catch (Exception lex) {
                return null;
            }

            //add any other stored information
            //this will add specific variable values through instance values
            //it will also load the child services, as full services themselves
            if ((thisService != null) && ModuleHandler.isService(thisService)) {
                ((Service)thisService).finaliseInitialisation();
                
                //add passwords if specified
                nextElem = serviceXml.getChild(Const.PASSWORDS);
                if (nextElem != null) {
                    ((Service)thisService).getPasswordHandler().fromXml(nextElem);
                }
                
                //reset local server password to what is currently running
                ((Service)thisService).getPasswordHandler().removeServicePassword(LocalServer.getServerHandle());
                ((Service)thisService).getPasswordHandler().addServicePassword(LocalServer.getServerHandle(), password);
                
                //other local variables
                nextElem = serviceXml.getChild(Const.SERVICESTATE);
                if (nextElem != null) {
                    nextValue = nextElem.getText();
                    ((Service)thisService).setServiceState(nextValue, thisAdminKey);
                }

                nextElem = serviceXml.getChild(Const.METAACCESSALLOWED);
                if (nextElem != null) {
                    nextValue = nextElem.getText();
                    ((Service)thisService).setCanAccessMeta(Boolean.parseBoolean(nextValue), thisAdminKey);
                }

                nextElem = serviceXml.getChild(Const.NESTEDACCESSALLOWED);
                if (nextElem != null) {
                    nextValue = nextElem.getText();
                    ((Service)thisService).setCanAccessNested(Boolean.parseBoolean(nextValue), thisAdminKey);
                }
                
                //add communication ids if specified
                nextElem = serviceXml.getChild(Const.COMMUNICATIONIDS);
                if (nextElem != null) {
                    elemList = nextElem.getChildren();
                    for (i = 0; i < elemList.size(); i++)
                    {
                        nextElem2 = (Element)elemList.get(i);
                        commID = nextElem2.getAttributeValue(Const.VALUE);
                        timeStamp = -1;
                        clientLink = null;
                        
                        nextElem3 = nextElem2.getChild(Const.TIMESTAMP);
                        if (nextElem3 != null) {
                            nextValue = nextElem3.getText();
                            timeStamp = Long.parseLong(nextValue);
                        }

                        nextElem3 = nextElem2.getChild(Const.CLIENTURI);
                        if (nextElem3 != null) {
                            if (nextElem3.hasChildren()) {
                                clientLink = nextElem3.getElementChildAtIndex(0);
                            }
                            else {
                                clientLink = nextElem3.getText();
                            }
                        }
                        
                        //note that 'lastCommID' is arbitrarily set
                        messageInfo = new MessageInfo(commID, clientLink);
                        if (timeStamp > 0) messageInfo.setTimeStamp(timeStamp);
                        if (!((Service)thisService).messageStore.hasCommID(commID)) {
                            ((Service)thisService).messageStore.addCommID(commID, messageInfo);
                            ((Service)thisService).sm.setCommID(commID);
                        }
                    }
                }
                
                //can add the dynamic link references here
                linksElem = serviceXml.getChild(Const.LINKS);
                if ((linksElem != null) && linksElem.hasChildren()) {
                    dynamicLinksXml = linksElem.getChild(MetaConst.DYNAMICLINKSERVICEMETA);
                    if (dynamicLinksXml != null) xmlToDynamicLinks(((Service)thisService), dynamicLinksXml);
                }
            }
        }
        
        //can only add permanent links after all services have been created
        //so a separate call for that is required afterwards
        return thisService;
    }
    
    //*****************************************************************
    // Also serialize and parse the service links of different types.
    //*****************************************************************
    
    /**
     * Return a list of child service uuids.
     * @param theService the parent service.
     * @return an XML representation of the nested service uuids.
     */
    public Element childServiceMetaToXml(Service theService)
    {
        int i;
        ArrayList<String> childServices;            //child services
        Element rootElem;                           //root element
        Element nextElem;                           //next element
        
        rootElem = XMLFactory.getInstance().createElement(MetaConst.CHILDSERVICEMETA);           
        childServices = theService.serviceLinks.childServices;

        if ((childServices != null) && !childServices.isEmpty()) {
            for (i = 0; i < childServices.size(); i++)
            {
                nextElem = XMLFactory.getInstance().createElement(Const.UUID);
                nextElem.setText(childServices.get(i));
                rootElem.addContent(nextElem);
            }
        }
        
        return rootElem;
    }
    
        /**
     * Perform a query over the link paths to return matching sources.
     * @param theService the parent service.
     * @param queryConfig the query configuration.
     * @return a list of source uris that match with the query.
     * @throws java.lang.Exception any error.
     */
    public Element dynamicLinkQuery(Service theService, LinkQueryConfig queryConfig) throws Exception
    {
        String servicePassword;                         //service password
        String serviceKey;                              //service key
        Link linker;                                    //linker service
        Element linkElem;                               //link element
        
        //in case no service is available
        linkElem = XMLFactory.getInstance().createElement(MetaConst.DYNAMICLINKSERVICEMETA);
            
        if (theService.getServiceNames().contains(ServiceConst.LINKER)) {
            servicePassword = theService.getPasswordHandler().getPassword();
            serviceKey = theService.getPasswordHandler().getAdminKey();

            try {
                servicePassword = theService.getPasswordHandler().getServicePassword(ServiceConst.LINKER);
            }
            catch (Exception ex) {}

            try {
                serviceKey = theService.getPasswordHandler().getAdminKey(ServiceConst.LINKER);
            }
            catch (Exception ex) {}

            linker = (Link)theService.getService(ServiceConst.LINKER, servicePassword, serviceKey);            
            if (linker != null) {
                linkElem = linker.linkQuery(queryConfig);
            }
            else {
                linkElem.setText("No linking service is loaded");
            }
        }
        else {
            linkElem.setText("No linking service is loaded");
        }
        
        return linkElem;
    }
    
    /**
     * Return all linked sources in XML format - permanent, dynamic or association.
     * @param theService the parent service.
     * @param allLevels if true, return all 3 levels, if false only return the top link level
     * references.
     * @param includeValues if false, return just the path and source info.
     * If true, include other values as well. 
     * @return an XML representation of all linked sources.
     * @throws Exception any error.
     */
    public Element allLinksToXml(Service theService, boolean allLevels, boolean includeValues) 
            throws Exception
    {
        ArrayList<Object> theLinks;             //the dynamic links
        Element linkElem;                       //link element
        Element allLinks;                       //all links element
        
        allLinks = XMLFactory.getInstance().createElement(Const.LINKS);
        allLinks.setAttribute(Const.UUID, theService.getUUID());
        
        theLinks = theService.serviceLinks.permanentLinks.getAllLinkToService();
        if (!theLinks.isEmpty()) {
            linkElem = permanentLinksToXml(theService);
            allLinks.addContent(linkElem);
        }
        
        if ((theService.serviceLinks.serviceAssociations != null) && 
            !theService.serviceLinks.serviceAssociations.isEmpty()) {
            linkElem = associationLinksToXml(theService);
            allLinks.addContent(linkElem);
        }
        
        linkElem = dynamicLinksToXml(theService, allLevels, includeValues);       
        if (linkElem.hasChildren()) allLinks.addContent(linkElem);
        
        return allLinks;
    }
    
    /**
     * Return all permanent linked sources in XML format.
     * @param theService the parent service.
     * @return an XML representation of all linked sources.
     * @throws Exception any error.
     */
    public Element permanentLinksToXml(Service theService) throws Exception
    {
        int i;
        ArrayList<Object> theLinks;             //the dynamic links
        Element linkElem;                       //link element
        Element nextElem;                       //next link element
        Object nextLink;                        //next link
        
        theLinks = theService.serviceLinks.permanentLinks.getAllLinkToService();
        linkElem = XMLFactory.getInstance().createElement(MetaConst.PERMANENTLINKSERVICEMETA);

        if (!theLinks.isEmpty()) {
            for (i = 0; i < theLinks.size(); i++)
            {
                nextLink = theLinks.get(i);
                nextElem = XMLFactory.getInstance().createElement(Const.LINK);

                if (!(nextLink instanceof Element)) {
                    nextLink = ObjectHandler.getElementPath(nextLink);
                }

                nextElem.addContent((Element)((Element)nextLink).clone());
                linkElem.addContent(nextElem);
            }
        }
        
        return linkElem;
    }
    
    /**
     * Return all association linked sources in XML format.
     * @param theService the parent service.
     * @return an XML representation of all linked sources.
     * @throws Exception any error.
     */
    public Element associationLinksToXml(Service theService) throws Exception
    {
        int i;
        ArrayList<Object> theLinks;                 //the dynamic links
        Element linkElem;                           //link element
        Element nextElem;                           //next link element
        Object nextLink;                            //next link
        
        linkElem = XMLFactory.getInstance().createElement(MetaConst.ASSOCIATEDLINKSERVICEMETA);

        if ((theService.serviceLinks.serviceAssociations != null) && 
            !theService.serviceLinks.serviceAssociations.isEmpty()) {
            theLinks = new ArrayList(theService.serviceLinks.serviceAssociations.values());

            for (i = 0; i < theLinks.size(); i++)
            {
                nextLink = theLinks.get(i);
                nextElem = XMLFactory.getInstance().createElement(Const.LINK);

                if (!(nextLink instanceof Element)) {
                    nextLink = ObjectHandler.getElementPath(nextLink);
                }

                nextElem.addContent((Element)((Element)nextLink).clone());
                linkElem.addContent(nextElem);
            }
        }
        
        return linkElem;
    }
    
    /**
     * Return all dynamic linked sources in XML format.
     * @param theService the parent service.
     * @param allLevels if true, return all 3 levels, if false only return the top link level
     * references.
     * @param includeValues if false, return just the path and source info.
     * If true, include other values as well. 
     * @return an XML representation of all linked sources.
     * @throws Exception any error.
     */
    public Element dynamicLinksToXml(Service theService, boolean allLevels, boolean includeValues) 
            throws Exception
    {
        String servicePassword;                         //service password
        String serviceKey;                              //service key
        Link linker;                                    //linker service
        Element linkElem;                               //link element
        
        //in case no service is available
        linkElem = XMLFactory.getInstance().createElement(MetaConst.DYNAMICLINKSERVICEMETA);
            
        if (theService.getServiceNames().contains(ServiceConst.LINKER)) {
            servicePassword = theService.getPasswordHandler().getPassword();
            serviceKey = theService.getPasswordHandler().getAdminKey();

            try {
                servicePassword = theService.getPasswordHandler().getServicePassword(ServiceConst.LINKER);
            }
            catch (Exception ex) {}

            try {
                serviceKey = theService.getPasswordHandler().getAdminKey(ServiceConst.LINKER);
            }
            catch (Exception ex) {}

            linker = (Link)theService.getService(ServiceConst.LINKER, servicePassword, serviceKey);            
            if (linker != null) {
                //convert the info to XML - 1 element is config, so 2 for any paths
                linkElem = linker.dynamicLinksToXml(allLevels, includeValues);
                if (linkElem.getChildren().isEmpty()) {
                    linkElem.getChildren().clear();
                    linkElem.setText("No dynamic links at present");
                }
            }
            else {
                linkElem.setText("No linking service is loaded");
            }
        }
        else {
            linkElem.setText("No linking service is loaded");
        }
        
        return linkElem;
    }
    
    /**
     * Parse the dynamic links descriptions and add to the service.
     * @param theService the parent service.
     * @param linksXml a full set of dynamic links descriptions for the service.
     * @throws java.lang.Exception any error.
     */
    protected void xmlToDynamicLinks(Service theService, Element linksXml) throws Exception
    {
        String servicePassword;                         //service password
        String serviceKey;                              //service key
        Link linker;                                    //linker service
        
        try {
            if (theService.getServiceNames().contains(ServiceConst.LINKER)) {
                servicePassword = theService.getPasswordHandler().getPassword();
                serviceKey = theService.getPasswordHandler().getAdminKey();

                try {
                    servicePassword = theService.getPasswordHandler().getServicePassword(ServiceConst.LINKER);
                }
                catch (Exception ex) {}

                try {
                    serviceKey = theService.getPasswordHandler().getAdminKey(ServiceConst.LINKER);
                }
                catch (Exception ex) {}

                linker = (Link)theService.getService(ServiceConst.LINKER, servicePassword, serviceKey);            
                if (linker != null) {
                    linker.xmlToDynamicLinks(linksXml);
                }
                else {
                    throw new ServiceException("Service " + theService.getUUID() + " does not have a linking service.");
                }
            }
            else {
                throw new ServiceException("Service " + theService.getUUID() + " does not have a linking service.");
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "xmlToDynamicLinks", null, ex);
        }
    }
    
    /**
     * Serialize the stored passwords list and return as an XML-based description.
     * @param theService the service to parse.
     * @return an XML representation of all passwords, or null if the admin key is incorrect.
     * @throws Exception any error.
     */
    public Element passwordsPlusStateToXml(Service theService) throws Exception
    {
        int i;
        String nextKey;                             //next key
        ArrayList<String> allKeys;                  //all keys
        Element rootElem;                           //root element
        Service nextService;                        //next service
        
        rootElem = XMLFactory.getInstance().createElement(Const.PASSWORDS);

        allKeys = theService.serviceAdmin.getServiceNames();
        for (i = 0; i < allKeys.size(); i++)
        {
            nextKey = allKeys.get(i);
            nextService = (Service)theService.serviceAdmin.getServiceOrWrapper(nextKey,
                    theService.getPasswordHandler().getServicePassword(nextKey),
                    theService.getPasswordHandler().getAdminKey(nextKey));

            //add nested set of passwords
            rootElem.addContent(nextService.passwordsStateToXml(theService.getPasswordHandler().getAdminKey(nextKey)));
        }
        
        return rootElem;
    }
}
