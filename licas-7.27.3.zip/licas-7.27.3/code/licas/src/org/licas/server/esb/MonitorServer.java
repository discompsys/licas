/*
 * MonitorServer.java
 *
 * Created on 5 February 2015
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server.esb;


import org.licas.MessageInfo;
import org.licas.PasswordHandler;
import org.licas.autonomic.MessageQueue;
import org.licas.call.*;
import org.licas.meta.MetaFactory;
import org.licas.module.ServiceModule;
import org.licas.server.*;
import org.licas.server.model.BusEntity;
import org.licas.util.Const;
import org.licas.util.exception.PasswordException;
import org.licas_xml.abs.Element;
import org.jlog2.*;

import java.util.*;


/**
 * This class can be used to perform some resource allocation over the message queue that is
 * built from the http requests.
 * @author Kieran Greer
 */
public class MonitorServer
{
    /** For logging */
    private static final Logger logger;

    /** Maximum number of times an attempt to process a message can fail */
    private static final int MAXFAIL = 100;


    /** The queue of messages to process */
    protected final MessageQueue messageQueue = new MessageQueue();

    /** List of services currently invoked through a message */
    protected ArrayList<String> servicesInvoked;

    /** To retrieve some passwords for service types */
    protected PasswordHandler passwordHandler;

    /** Parent message mediator */
    protected MessageMediator mediator;

    /**
     * Number of times a message is not processed.
     * Key is the unique commID and value is a count of number of times.
     */
    protected HashMap<String, Integer> failCount;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(MonitorServer.class.getName());
        logger.setDebug(false);
    }

    /** 
     * Create a new instance of MonitorServer.
     * @param thePasswordHandler the server password handler.
     * @param theMediator the parent message mediator.
     */
    public MonitorServer(PasswordHandler thePasswordHandler, MessageMediator theMediator)
    {
        passwordHandler = thePasswordHandler;
        mediator = theMediator;
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        servicesInvoked = new ArrayList<>();
        failCount = new HashMap<>();
    }

    /**
     * Return true if there are messages waiting to be processed.
     * @return true if size of the message queue is {@code > 0}.
     */
    public boolean hasMessages() {
        return (messageQueue.queueSize() > 0);
    }

    /**
     * Add the message to the message bus, with the following rules:
     * @param ro message with full {@link ServerHandler} handler details in a {@link BusEntity}.
     * @return true if added, false if there was an error.
     */
    public boolean messageToBus(MessageInfo ro) {
        synchronized (messageQueue) {
            messageQueue.addMessage(ro);
        }

        return true;
    }

    /**
     * Process the queue of messages and return the next one determined by resource allocation.
     * @throws java.lang.Exception any error.
     */
    public void processNextMessage() throws Exception
    {
        int i;
        boolean messageOK;                  //true if message is OK
        String serviceID;                   //id of service to invoke
        ArrayList<String> serviceNames;     //list of allowed service names
        MessageInfo messageInfo;            //message info
        Object messageObj;                  //the message value
        MethodInfo methodInfo;              //method info
        BusEntity bo;                       //message bus object

        //determine the details of the message and try to find a matching service
        //only need the details, not the whole message,
        //then set the id in the message object to the service that accepts the method
        //also store a list commIDs of messages that are rejected
        //if rejected too many times, then set the id to fault to allow the handler to complete
        //and process the message as an error, probably also set service to the server

        synchronized(messageQueue) {
            messageOK = false;

            //calls can be to a specific service or a service type
            for (i = 0; !messageOK && (i < messageQueue.queueSize()); i++) {
                messageInfo = messageQueue.getMessageAt(i);
                if (messageInfo != null) {
                    bo = (BusEntity) messageInfo.getMessage();

                    //determine type or ID, method info already converted to the licas format
                    methodInfo = (MethodInfo) bo.getRequest().getValue();
                    messageObj = methodInfo.getServiceURI();

                    serviceID = null;
                    if (messageObj instanceof ServiceModule) {
                        serviceID = ((ServiceModule) messageObj).getUUID();
                    } else if (messageObj instanceof Element) {
                        serviceID = Handle.getFirstHandleServiceServer(((Element) messageObj));
                    }

                    if (serviceID != null) {
                        serviceID = serviceID.trim();
                        serviceNames = mediator.getServiceNames();

                        if (serviceNames.contains(serviceID)) {
                            //ask specific service to process the message
                            messageOK = acceptPointPoint(serviceID, bo, i);
                        } else {
                            //ask for type of service to process the message
                            serviceNames = mediator.getServiceTypeNames(serviceID);
                            messageOK = acceptSubscribe(serviceNames, bo, i);
                        }
                    }

                    //if not OK, then note message not processed this loop
                    if (!messageOK) {
                        if (!failCount.containsKey(bo.getTicket())) {
                            failCount.put(bo.getTicket(), 1);
                        }
                        else {
                            failCount.put(bo.getTicket(), (failCount.get(bo.getTicket())+1));
                        }
                    }
                }
            }

            //if no message selected, then all current services have been invoked,
            //or no available message for the services not invoked, so reset the
            //invoked list and the next call can select from a larger pool
            if (!messageOK) {
                servicesInvoked.clear();
            }

            //finally, check if some messages have failed too often and remove from the list
            //or, set the id to fault so that the fault system can process it
            //for (Iterator<String> it = failCount.keySet().iterator(); it.hasNext();) {
            for (String s : failCount.keySet()) {
                serviceID = s;
                if (failCount.get(serviceID) > MAXFAIL) {
                    for (i = 0; i < messageQueue.queueSize(); i++) {
                        messageInfo = messageQueue.getMessageAt(i);
                        if (messageInfo != null) {
                            bo = (BusEntity) messageInfo.getMessage();
                            if (bo.getTicket().equalsIgnoreCase(serviceID)) {
                                bo.setID(MetaFactory.getFactoryService().asFaultComm(bo.getTicket()));
                                break;
                            }
                        }
                    }

                    //this removes 'all' messages with that comm ID
                    messageQueue.removeAllMessages(serviceID);
                }
            }
        }
    }

    /**
     * Set the conditions for a point-to-point request to be carried out.
     * @param serviceID uuid of the service to invoke.
     * @param bo bus entity with the message information.
     * @param pos position for the message in the bus queue.
     * @return tue if the message was accepted, false otherwise.
     */
    private boolean acceptPointPoint(String serviceID, BusEntity bo, int pos) {
        boolean messageOK;                  //true if message is OK

        //if not on invoked list can then invoke
        //if not on service names list then remove all to that service and try again
        messageOK = false;
        if (serviceID.equalsIgnoreCase(Const.HTTPSERVER)) {
            //always accept requests to the server
            messageQueue.getAndRemoveMessageAt(pos);
            bo.setID(serviceID);
            messageOK = true;
        }
        else if (!servicesInvoked.contains(serviceID))
        {
            //queue requests to the other services
            servicesInvoked.add(serviceID);
            messageQueue.getAndRemoveMessageAt(pos);

            //this is checked by the server handler and if a service ID is
            //added, the handler tries to invoke the method on that service
            bo.setID(serviceID);
            messageOK = true;
        }

        return messageOK;
    }

    /**
     * Set the conditions for a subscribed service type request to be carried out.
     * @param serviceNames list of services of the type that can accept the request.
     * @param bo bus entity with the message information.
     * @param pos position for the message in the bus queue.
     * @return tue if the message was accepted, false otherwise.
     * @throws PasswordException if the service password is not available.
     */
    private boolean acceptSubscribe(ArrayList<String> serviceNames, BusEntity bo, int pos) throws PasswordException {
        int sIndex;                         //service index
        boolean messageOK;                  //true if message is OK
        String serviceID;                   //id for selected service
        Random rnd;                         //random number generator
        
        //for a simple setup, select services at random until find a good match
        rnd = new Random();
        messageOK = false;

        //if service names are null then set to empty list
        if (serviceNames == null) serviceNames = new ArrayList<>();

        //need match to a type for subscriber to accept
        serviceNames = (ArrayList)serviceNames.clone();

        while (!messageOK && !serviceNames.isEmpty()) {
            sIndex = rnd.nextInt(serviceNames.size());
            serviceID = serviceNames.remove(sIndex);

            //if not on invoked list can then invoke
            //if not on service names list then remove all to that service and try again
            if (!servicesInvoked.contains(serviceID)) {
                servicesInvoked.add(serviceID);
                messageQueue.getAndRemoveMessageAt(pos);

                //this is checked by the server handler and if a service ID is
                //added, the handler tries to invoke the method on that service
                bo.setID(serviceID);

                //as service type has accepted message, it can pass its password for invocation
                MethodInfo methodInfo = (MethodInfo)bo.getRequest().getValue();
                methodInfo.setPassword(passwordHandler.getServicePassword(serviceID));
                messageOK = true;
            }
        }

        return messageOK;
    }

    /**
     * Remove the message with the specified ticket number from the queue.
     * @param ticket unique ticket number, equivalent to the communication ID.
     */
    public void cancelMessage(String ticket) {
        synchronized (messageQueue) {
            messageQueue.removeAllMessages(ticket);
        }
    }
}
