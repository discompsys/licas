/*
 * PacketMessages.java
 *
 * Created on 5 February 2018
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server.model;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.FileLoader;
import org.jlog2.util.UuidHandler;
import org.licas.call.MethodInfo;
import org.licas.parsers.Parsers;
import org.licas.util.Const;
import org.licas.util.ServiceConst;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;

import java.io.DataOutputStream;
import java.util.HashMap;


/**
 * This processes the message lists being sent using packet sizes, saves and re-parses them.
 * @author Kieran Greer
 */
public class PacketMessages 
{
    /** The logger */
    private static final Logger logger;
    
    /** 
     * Stores communication ids with related message packet info for receiving 
     * messages in packets. Keys are the communication ids of type String, while
     * values are the PacketInfo objects.
     */
    protected HashMap<String, PacketInfo> packetMsgs;

    /** To synchronize on */
    protected final Object syncOn = new Object();
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(PacketMessages.class.getName());
        logger.setDebug(true);
    }
    
    /** Create a new instance of PacketMessages */
    public PacketMessages()
    {
        packetMsgs = new HashMap<>();
    }
    
    /**
     * Add the communication id and packet info to the packetInfo structure.
     * @param communicationID the id to identify the communication thread.
     * @param packetSize the maximum size of the packet to send.
     * @return true if the id and the file name are new and the file can be created.
     * @throws java.lang.Exception any error.
     */
    public boolean addPacketCommunicationID(String communicationID, int packetSize) 
            throws Exception
    {
        String fileName;                    //name of the file to write to
        PacketInfo packetInfo;              //next packet info

        synchronized(syncOn)
        {
            if (!packetMsgs.containsKey(communicationID))
            {
                fileName = (UuidHandler.getUuid(10) + ".xml");
                fileName = (ServiceConst.TEMPDIR + fileName);

                packetInfo = new PacketInfo(fileName, packetSize);           
                if (packetInfo.createFile()) 
                {
                    packetMsgs.put(communicationID, packetInfo);
                    return true;
                }
                else 
                {
                    return false;
                }
            }

            return false;
        }
    }
    
    /**
     * Add the message packet to the appropriate file as indicated by the communication id.
     * @param communicationID the id to identify the communication thread.
     * @param packetObject the next part of the message to save.
     * @return true if the packet is successfully added to the file.
     * @throws java.lang.Exception any error.
     */
    public boolean addMessagePacket(String communicationID, String packetObject) 
            throws Exception
    {
        String thePacket;                       //the message packet
        DataOutputStream outputStream;          //output stream
        PacketInfo packetInfo;                  //next packet info
        
        synchronized(syncOn)
        {
            thePacket = new String(org.licas.parsers.types.Base64.decode(packetObject)).trim();
            if (thePacket.startsWith(Const.XMLHEADER))
            {
                thePacket = thePacket.substring(Const.XMLHEADER.length()).trim();
            }
            thePacket = XmlHandler.removeElementSpecs(thePacket);

            if (packetMsgs.containsKey(communicationID))
            {
                packetInfo = packetMsgs.get(communicationID);
                outputStream = packetInfo.getOutputStream();    

                try 
                {
                    outputStream.write(thePacket.getBytes());
                } 
                finally 
                {
                    outputStream.flush();
                }

                return true;
            }

            return false;
        }
    }
    
    /**
     * Call this to indicate that the whole message has been sent and should now be executed.
     * @param communicationID the id to identify the communication thread.
     * @return the parsed method info.
     * @throws java.lang.Exception any error.
     */
    public MethodInfo endOfMessage(String communicationID) throws Exception
    {
        String fileName;                            //file name
        String contents;                            //file contents
        MethodInfo methodInfo;                      //method info
        PacketInfo packetInfo;                      //next packet info
        Element rootElem;                           //root element
        
        synchronized(syncOn)
        {
            packetInfo = null;
            try
            {
                methodInfo = null;
                if (packetMsgs.containsKey(communicationID))
                {
                    packetInfo = packetMsgs.get(communicationID);
                    packetInfo.closeFileWriter();
                    packetInfo.closeFileChannel();

                    fileName = packetInfo.getFileName();
                    contents = FileLoader.getInputStream(fileName);
                    rootElem = XmlHandler.stringToElement(contents);

                    //parse the XML back into objects and call the appropriate method
                    methodInfo = (MethodInfo)Parsers.parse(rootElem);
                }

                return methodInfo;
            }
            catch (Exception ex)
            {
                throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                        "endOfMessage", null, ex);
            }
            finally
            {
                //remove the file and description of it
                packetMsgs.remove(communicationID);                             
                if (packetInfo != null)
                {
                    try
                    {
                        packetInfo.deleteFile();
                    }
                    catch (Exception ex) {}
                }
            }
        }
    }
}
