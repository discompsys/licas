/*
 * PublishSubscribe.java
 *
 * Created on 30 January 2018.
 *
 * Version 1.2.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server.esb;


import org.licas.PasswordHandler;
import org.licas.call.*;
import org.licas.def.PublishSubscribeDef;
import org.licas.service.model.*;
import org.licas.util.*;
import org.licas_text.util.MetaConst;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.util.*;


/**
 * This class records requests for a service from clients and responds with appropriate
 * replies when a service registers it can carry out the request. Requests are submitted
 * in the form of a {@link MethodInfo} description and a {@link KeywordInfo} list of keywords.
 * The method description must include a client URI or it will be rejected. This uniquely
 * defines the service or client. The keyword lists may not overlap for any one client
 * or service. They may not share any keywords, but the topic names can be shared.
 * @author Kieran Greer
 */
public class PublishSubscribe implements PublishSubscribeDef 
{
    /** The logger */
    private static final Logger logger;
    
    
    /**
     * Register of clients wanting a service.
     * Any client can make a different request for any number of services, identified
     * by a unique set of keywords.
     * MethodInfo timeout can be max wait time. Client address to recognise the reply.
     */
    private final HashMap<String, ArrayList<WorkInfo>> clientRegister;
    
    /**
     * Register of services offering work.
     * Any service can register any number of services, identified by a unique set
     * of keywords. Service address to recognise the request.
     */
    private final HashMap<String, ArrayList<WorkInfo>> serviceRegister;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(PublishSubscribe.class.getName());
        logger.setDebug(false);
    }
        
    
    /** Create a new instance of PublishSubscribe */
    public PublishSubscribe()
    {
        clientRegister = new HashMap<>();
        serviceRegister = new HashMap<>();
    }
       
    /**
     * Subscribe for a service. Each time a service publishes a matching work description
     * any subscriber is sent the {@code WorkInfo} details. An immediate check is done to
     * determine if matching work is available.
     * @param workInfo new client details. It must include the keyword list and the method
     * to reply with.
     * <ol>
     * <li> A list of descriptive keywords and topic to match with.</li>
     * <li> Details of the client method to reply with if a service work matches with the keywords request.</li>
     * </ol>
     * The details method must comply with some specific formatting as follows:
     * <ol>
     * <li>It must include the client URI, as this is what identifies the request. 
     * If {@code getClientURI()} is empty, then the request is ignored.</li>
     * <li>It must contain a parameter list of size 1, that is either an {@code Object} or 
     * a {@link WorkInfo} object, as that is what will be sent as a reply.</li>
     * <li>The return type must be {@code void} (asynchronous call). 
     * </ol>
     * @return true if added as a new request, or false if service request is already 
     * registered, via keyword or topic overlap, for example.
     * @throws java.lang.Exception any error.
     */
    public boolean subscribe(WorkInfo workInfo) throws Exception
    {
        boolean isNew;                          //true if new
        String address;                         //unique client address
        KeywordInfo keyInfo;                    //keyword info
        MethodInfo myDetails;                   //method details
        WorkInfo sWorkInfo;                     //service published
        MethodInfo methodInfo;                  //reply method
        CallObject callObj;                     //call object
        
        try
        {
            isNew = false;
            callObj = new CallObject();
            keyInfo = workInfo.keywordInfo;
            myDetails = workInfo.methodInfo;
            
            address = Handle.handleToString(myDetails.getClientURI());
            if (getWorkInfo(address, keyInfo, clientRegister) == null)
            {
                addToRegister(address, workInfo, clientRegister);
                
                sWorkInfo = getWorkInfo(address, workInfo.keywordInfo, serviceRegister);
                if (sWorkInfo != null)
                {
                    methodInfo = (MethodInfo)myDetails.clone(); 
                    methodInfo.setServiceURI(XmlHandler.stringToElement(address));
                    methodInfo.clearParams();
                    methodInfo.addParam(sWorkInfo);
                    callObj.call(methodInfo);
                }
                
                isNew = true;
            }

            return isNew;
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "subscribe", null, ex);
        }
    }
        
    /**
     * Un-subscribe for a service.
     * @param keyInfo list of descriptive keywords to uniquely identify the service.
     * @param clientURI the client URI defines the request client.
     * @throws java.lang.Exception any error.
     */
    public void unsubscribe(KeywordInfo keyInfo, Element clientURI) throws Exception
    {
        try
        {
            removeFromRegister(Handle.handleToString(clientURI), keyInfo, clientRegister);
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "unsubscribe", null, ex);
        }
    }
        
    /**
     * Publish to do work. This triggers a message to all subscribed services each time
     * and any publishing service may publish the same work request any number of times.
     * Only the first published request is saved however and then then sent out each time.
     * @param workInfo full work details, including an optional contract. The method 
     * description must include the client URI as this is what identifies the request. 
     * If {@code getClientURI()} is empty, then the request is ignored.
     * @return true if added as a new request, or false if work request is already 
     * registered, via keyword or topic overlap, for example.
     * @throws java.lang.Exception any error.
     */
    public boolean publish(WorkInfo workInfo) throws Exception
    {
        boolean newRequest;                     //true if new request
        String address;                         //unique client address
        WorkInfo sWorkInfo;                     //service request
        WorkInfo cWorkInfo;                     //client request
        MethodInfo methodInfo;                  //method info
        CallObject callObj;                     //call object

        sWorkInfo = null;
        try {
            newRequest = true;
            callObj = new CallObject();
            
            address = Handle.handleToString(workInfo.methodInfo.getClientURI());            
            if ((sWorkInfo = getWorkInfo(address, workInfo.keywordInfo, serviceRegister)) == null) {
                addToRegister(address, workInfo, serviceRegister);
                sWorkInfo = workInfo;
                newRequest = false;
            }
                                        
            //get all clients with request for this work and send a response
            sWorkInfo.info = workInfo.info;
            for (String key: clientRegister.keySet())
            {
                cWorkInfo = getWorkInfo(key, sWorkInfo.keywordInfo, clientRegister);
                if (cWorkInfo != null) {
                    methodInfo = (MethodInfo)cWorkInfo.methodInfo.clone(); 
                    methodInfo.setServiceURI(XmlHandler.stringToElement(key));
                    methodInfo.clearParams();
                    methodInfo.addParam(sWorkInfo);
                    callObj.call(methodInfo);
                }
            }
            
            return newRequest;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "publish", null, ex);
        }
        finally {
            if (sWorkInfo != null) {
                sWorkInfo.info = null;
            }
        }
    }
        
    /**
     * Un-publish to do work.
     * @param keyInfo list of descriptive keywords to uniquely identify the work.
     * @param clientURI the client URI defines the request service.
     * @throws java.lang.Exception any error.
     */
    public void unpublish(KeywordInfo keyInfo, Element clientURI) throws Exception
    {
        try {
            removeFromRegister(Handle.handleToString(clientURI), keyInfo, serviceRegister);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "unpublish", null, ex);
        }
    }
    
    /**
     * Add the request to do work.
     * @param address unique address for the client.
     * @param workInfo the work request.
     * @param register the register to add to.
     */
    protected void addToRegister(String address, WorkInfo workInfo,
                                 HashMap<String, ArrayList<WorkInfo>> register)
    {
        ArrayList<WorkInfo> requests;           //current requests
        
        if (!register.containsKey(address)) {
            register.put(address, new ArrayList<>());
        }

        requests = register.get(address);
        requests.add(workInfo);
    }
    
    /**
     * Add the request to do work.
     * @param address unique address for the client.
     * @param keyInfo keywords list to identify the work description.
     * @param register the register to add to.
     * @throws java.lang.Exception any error.
     */
    protected void removeFromRegister(String address, KeywordInfo keyInfo, 
            HashMap<String, ArrayList<WorkInfo>> register) throws Exception
    {
        int i;
        KeywordInfo workKeys;                   //work info keys
        WorkInfo workInfo;                      //work info
        ArrayList<WorkInfo> requests;           //current requests
        
        if (register.containsKey(address))
        {
            requests = register.get(address);
            for (i = 0; i < requests.size(); i++)
            {
                workInfo = requests.get(i);
                workKeys = workInfo.keywordInfo;
                
                if (workKeys.matchesWith(keyInfo, MetaConst.ANYSTRUCTURE))
                {
                    requests.remove(i);
                    break;
                }
            }
        }
    }
    
    /**
     * If a work description is already saved under the service address and keyword list then
     * return it, otherwise return null.
     * @param address unique address for the client/service.
     * @param keyInfo list of keywords. None must be present in a currently saved
     * work request by the same service.
     * @param register the register to check.
     * @return true if OK.
     * @throws java.lang.Exception any error.
     */
    protected WorkInfo getWorkInfo(String address, KeywordInfo keyInfo, 
            HashMap<String, ArrayList<WorkInfo>> register) throws Exception
    {
        int i;
        WorkInfo request;                       //the work request
        KeywordInfo workKeyInfo;                //work key info
        ArrayList<WorkInfo> requests;           //current requests

        if ((address != null) && !address.equalsIgnoreCase(Const.ANON))
        {
            if (register.containsKey(address))
            {
                requests = register.get(address);
                for (i = 0; i < requests.size(); i++)
                {
                    request = requests.get(i);
                    workKeyInfo = request.keywordInfo;
                    
                    if (workKeyInfo.getKeywords().isEmpty() ||
                            workKeyInfo.matchesWith(keyInfo, MetaConst.ANYSTRUCTURE))
                    {
                        return request;
                    }
                }
            }
        }  
        
        return null;
    }

    /**
     * Create and return the full method list for publishing a service's information.
     * @param serverUri address for the server to call.
     * @param serverPassword the server password.
     * @param keywords list of keywords to represent the published information.
     * @param replyMethod callback method by the server after publshing.
     * @param pHandler the service password handler.
     * @return a {@link MethodInfo} object to make a server publish invocation with.
     * @throws java.lang.Exception any error.
     */
    public static MethodInfo methodForPublish(Element serverUri, String serverPassword,
                                              KeywordInfo keywords, MethodInfo replyMethod,
                                              PasswordHandler pHandler) throws Exception
    {
        ArrayList<Object> params;                   //parameters list
        WorkInfo workInfo;                          //work description
        MethodInfo publishMethod;                   //publish method

        try {
            if (!pHandler.hasServicePassword(serverUri)) {
                pHandler.addServicePassword(serverUri, serverPassword);
            }

            params = new ArrayList<>();
            workInfo = new WorkInfo();
            workInfo.keywordInfo = keywords;
            workInfo.methodInfo = replyMethod;
            params.add(workInfo);
            publishMethod = MethodFactory.createMethodCall(MethodConst.PUBLISH, TypeConst.BOOLEAN,
                    serverUri, params, pHandler);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "methodForPublish",
                    "", ex);
        }

        return publishMethod;
    }

    /**
     * Create and return the full method list for subscribing to a service's information.
     * @param serverUri address for the server to call.
     * @param serverPassword the server password.
     * @param keywords list of keywords to represent the published information.
     * @param replyMethod callback method by the server, to send the published data to.
     * @param pHandler the service password handler.
     * @return a {@link MethodInfo} object to make a server subscribe invocation with.
     * @throws java.lang.Exception any error.
     */
    public static MethodInfo methodForSubscribe(Element serverUri, String serverPassword,
                                                KeywordInfo keywords, MethodInfo replyMethod,
                                                PasswordHandler pHandler) throws Exception
    {
        ArrayList<Object> params;                   //parameters list
        WorkInfo workInfo;                          //work description
        MethodInfo subscribeMethod;                 //subscribe method

        try {
            if (!pHandler.hasServicePassword(serverUri)) {
                pHandler.addServicePassword(serverUri, serverPassword);
            }

            params = new ArrayList<>();
            workInfo = new WorkInfo();
            workInfo.keywordInfo = keywords;
            workInfo.methodInfo = replyMethod;
            params.add(workInfo);
            subscribeMethod = MethodFactory.createMethodCall(MethodConst.SUBSCRIBE, TypeConst.BOOLEAN,
                    serverUri, params, pHandler);
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "methodForSubscribe",
                    "", ex);
        }

        return subscribeMethod;
    }
}
