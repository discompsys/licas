/*
 * Run_HttpServer.java
 *
 * Created on 19 February 2007
 *
 * Version 1.7.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server;


import org.licas.ServiceAdminHandler;
import org.licas.server.model.*;
import org.licas.service.DefaultServiceFactory;
import org.licas.util.Const;
import org.licas_xml.abs.Element;
import org.jlog2.*;
import org.jlog2.util.UuidHandler;

import java.util.ArrayList;


/**
 * This class runs the HTTP server. You can use this class to start an {@link HttpServer} 
 * object running and also load an {@link ESB} object onto it. This can also be
 * configured with command line arguments passed in as a String[]. The arguments
 * do not all need to be included, but must be added in the following order:
 * 1. Server port to run on.
 * 2. 'Yes' or 'No' https protocol indicator. Yes means {@code https}, no means {@code http}.
 * 3. Password for the server.
 * 4. Service key for the server.
 * 5. A contact address for the server administrator - email or something.
 * 6. 'Yes' or 'No' contract indicator.
 * 7. (Alternative) class name of the class to load as the ESB. If this is not included
 * then the default 'ESB' is loaded. If this is included then it should extend
 * the 'Service' class and have all of the required jar files, etc., locally available 
 * for loading.
 * 8. An alternative representation of the IP address that the server will run on.
 * @author Kieran Greer
 */
public class Run_HttpServer
{    
    /**
     * Creates a new instance of Run_HttpServer.
     * @param args the arguments.
     * @throws java.lang.Exception any error.
     */
    protected Run_HttpServer(String[] args) throws Exception
    {
        runServer(args);
    }
    
    /**
     * Start the HTTP server.
     * @param args initialisation argument - must be the server URL.
     * @throws java.lang.Exception any error.
     */
    protected void runServer(String[] args) throws Exception
    {
        boolean asHttps;                        //true if as https address
        boolean yesContract;                    //true if add a yes contract
        int counter;                            //counter
        int port;                               //server port
        String adminKey;                        //the service key
        String password;                        //the user password
        String esbClass;                        //the ESB class
        String ipAddress;                       //the ip address to run the server on
        String contact;                         //server admin contact address
        ArrayList<Object> params;               //parameters
        Element adminXml;                       //admin xml
        ServerConfig serverConfig;              //server config info
        
        counter = 0;
        System.setProperty("java.net.preferIPv4Stack" , "true");
        port = 8888;
        
        if (args.length > counter) {
            try {
                port = Integer.parseInt(args[counter]);
            }
            catch (Exception ex) {
                counter++;

                if (args.length > counter) {
                    try {
                        port = Integer.parseInt(args[counter]);
                    }
                    catch (Exception ex2) {}
                }
            } 
        } 

        counter++;
        if (args.length > counter)
            asHttps = args[counter].equalsIgnoreCase("yes");
        else
            asHttps = false;

        counter++;
        if (args.length > counter)
            password = args[counter];
        else
            password = Const.ANON;

        counter++;
        if (args.length > counter)
            adminKey = args[counter];
        else
            adminKey = Const.ANON;

        counter++;
        if (args.length > counter)
            contact = args[counter];
        else
            contact = null;

        counter++;
        if (args.length > counter)
            yesContract = args[counter].equalsIgnoreCase("yes");
        else
            yesContract = true;

        counter++;
        if (args.length > counter)
            esbClass = args[counter];
        else
            esbClass = null;

        counter++;
        if (args.length > counter) {
            ipAddress = args[counter];
        }
        else {
            ipAddress = ServerAddress.getLocalHost4Address().getHostAddress();
        }

        try {
            //create the log files
            LoggerFactory.setLoggerFactory(new CustomLoggerFactory());
            new DefaultServiceFactory(UuidHandler.getUuid(25));
        
            //create default admin document
            if (yesContract) adminXml = ServiceAdminHandler.createAdminOnlyContractYes();
            else adminXml = ServiceAdminHandler.createAdminOnlyContractNo();
            
            //start the http server
            serverConfig = new ServerConfig();
            serverConfig.setServerPort(port);
            serverConfig.setServerIP(ipAddress);
            serverConfig.setServerPassword(password);
            serverConfig.setServerAdminKey(adminKey);
            serverConfig.setServerContact(contact);
            serverConfig.setAsHttps(asHttps);
            
            HttpServer.setHttpServer(serverConfig);
            
            //load the enterprise service bus
            if (esbClass == null) {
                LocalServer.getApi(password).setESB(Const.HTTPSERVER, Const.HTTPSERVER, adminXml);
            }
            else {
                params = new ArrayList<>();
                params.add(password);
                params.add(adminKey);
                params.add(adminXml);
                
                LocalServer.getApi(password).setESB(Const.HTTPSERVER, Const.HTTPSERVER, 
                        null, esbClass, params);
            }
            
            LocalServer.getApi(password).startRequestThread(adminKey);
        }
        catch (Exception ex) {
            throw ex;
        }
    }
    
    /**
     * Start the http server running.
     * @param args the command line arguments
     */
    public static void start(String[] args) {
        try {
            new Run_HttpServer(args);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    /**
     * Start the http server running.
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            new Run_HttpServer(args);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
