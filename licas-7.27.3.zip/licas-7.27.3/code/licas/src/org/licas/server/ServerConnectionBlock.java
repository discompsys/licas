/*
 * ServerConnectionBlock.java
 *
 * Created on 5 March 2020
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas.parsers.Parsers;
import org.licas.server.model.HttpEntity;

import java.io.*;
import java.nio.channels.*;


/**
 * This class handles a single HTTP blocking (synchronous) transaction on a separate thread.
 * It uses a {@code Channel} to pass information and a {@link ServerHandler} to process the message.
 */
public class ServerConnectionBlock extends ServerConnection {

    /** For logging */
    private static final Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServerConnectionBlock.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of ServerConnectionBlock.
     * @param theChannel the listener channel.
     * @param timeOut timeout for receiving continuous message.
     * @param serverHandler the server handler that processes the message.
     * @throws Exception any error.
     */
    public ServerConnectionBlock(SocketChannel theChannel, long timeOut, ServerHandler serverHandler)
            throws Exception
    {
        super(theChannel, timeOut, serverHandler);
    }


    /** Start the message processing */
    public void run()
    {
        String line;                                //message line
        StringBuilder message;                      //full message
        HttpEntity request;                         //client request
        HttpEntity response;                        //server response
        BufferedReader in;                          //input stream
        DataOutputStream out;                       //output stream

        in = null;
        out = null;

        try {
            message = new StringBuilder();
            in = new BufferedReader(new InputStreamReader(new DataInputStream(((SocketChannel)channel).socket().getInputStream())));

            line = in.readLine();
            while((line != null) && (line.length() > 0))
            {
                message.append(line);
                line = in.readLine();
            }

            //process the message in a handler
            try {
                if (!message.toString().equals("")) {
                    //decode and convert the string into a http entity
                    request = convertRequest(message.toString().trim());

                    //blocking handler requires a response
                    if (serverHandler.isBlocking()) {
                        //write the reply back to the client
                        response = serverHandler.handle(request);
                        if (response != null) {
                            message = new StringBuilder((httpHeaders(response) + Parsers.serializeToString(response)));
                            out = new DataOutputStream(((SocketChannel)channel).socket().getOutputStream());
                            out.writeBytes(message.toString());
                            out.flush();
                        }
                    }
                    else {
                        serverHandler.handle(request);
                    }
                }
            }
            catch (Exception ex) {
                response = null;
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "run",
                    "", ex);
        }
        finally {
            if (in != null) {
                try {
                    in.close();
                }
                catch (Exception ex) {}
            }

            if (out != null) {
                try {
                    out.close();
                }
                catch (Exception ex) {}
            }

            if (channel != null) {
                try {
                    ((SocketChannel)channel).shutdownInput();
                }
                catch (Exception ex) {}

                try {
                    ((SocketChannel)channel).shutdownOutput();
                }
                catch (Exception ex) {}

                try {
                    channel.close();
                }
                catch (Exception ex) {}

                channel = null;
            }
        }
    }
}
