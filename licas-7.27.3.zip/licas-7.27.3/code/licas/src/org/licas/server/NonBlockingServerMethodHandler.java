/*
 * NonBlockingServerMethodHandler.java
 *
 * Created on 27 December 2010
 *
 * Version 1.7
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server;


import org.licas.call.*;
import org.licas.server.model.BusEntity;
import org.licas.server.model.HttpEntity;
import org.jlog2.*;


/**
 * This class receives the HTTP non-blocking (asynchronous) server request, parses it back into the Java object
 * ({@link MethodInfo} or {@code REST}) and passes that to the appropriate service for execution.
 * @author Kieran Greer
 */
public class NonBlockingServerMethodHandler extends ServerMethodHandler
{
    /** The logger */
    private static final Logger logger;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(NonBlockingServerMethodHandler.class.getName());
        logger.setDebug(false);
    }
        
    /**
     * Create a new instance of NonBlockingServerMethodHandler.
     * @param theAdminKey the server admin key.
     * @throws java.lang.Exception any error.
     */
    public NonBlockingServerMethodHandler(String theAdminKey) throws Exception
    {
        super(theAdminKey);
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        isBlocking = false;
    }

    /**
     * Handle the HTTP request.
     * @param bo the object retrieved from the message bus.
     * @return {@code null}, as non-blocking.
     */
    public HttpEntity handleMethodExecution(BusEntity bo) {
        processServiceCall(bo);
        return null;
    }
}
