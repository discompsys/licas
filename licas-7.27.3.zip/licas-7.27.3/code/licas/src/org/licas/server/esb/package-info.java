/**
 * Functionality of the ESB with regard to internal processing and resources.
 */
package org.licas.server.esb;