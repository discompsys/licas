/*
 * ServerHandler.java
 *
 * Created on 19 March 2014
 *
 * Version 1.3.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server;


import org.licas.server.model.HttpEntity;
import org.jlog2.*;

import java.net.URL;


/**
 * This class provides some base methods for http request handling.
 * @author Kieran Greer
 */
public abstract class ServerHandler
{
    /** The logger */
    private static final Logger logger;


    /** The server password */
    protected String serverPassword;
    
    /** The server admin key */
    protected String adminKey;
    
    /** Local ip address - not currently used */
    protected String localURI;

    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServerHandler.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of ServerHandler.
     * @param theServerPassword the server password.
     * @param theAdminKey the server admin key.
     * @throws java.lang.Exception any error.
     */
    public ServerHandler(String theServerPassword, String theAdminKey) throws Exception
    {
        serverPassword = theServerPassword;
        adminKey = theAdminKey;
        initialise();
    }

    /**
     * Initialise some values.
     * @throws java.lang.Exception any error.
     */
    private void initialise() throws Exception
    {
        localURI = LocalServer.getServerURL();
        localURI = new URL(localURI).getHost();
    }

    /**
     * Handle the HTTP request.
     * @param request the HTTP request.
     * @return the method execution response.
     * @throws java.lang.Exception any error.
     */
    public abstract HttpEntity handle (HttpEntity request) throws Exception;

    
    /**
     * Return true if this handler is blocking, or requires a method reply.
     * @return true if blocking, false if not blocking.
     */
    protected boolean isBlocking()
    {
        return (this instanceof BlockingServerHandler);
    }
}
