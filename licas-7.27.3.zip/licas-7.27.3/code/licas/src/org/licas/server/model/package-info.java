/**
 * Info objects used by the server.
 */
package org.licas.server.model;