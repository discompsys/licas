/*
 * ServerConnection.java
 *
 * Created on 26 February 2020
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server;


import org.jlog2.*;
import org.licas.parsers.Parsers;
import org.licas.server.model.HttpEntity;
import org.licas.util.Const;
import org.licas.util.MethodConst;
import org.licas_internet.util.HttpConst;
import org.licas_text.util.XmlHtmlHandler;
import org.licas_xml.model.XmlHandler;

import java.nio.channels.Channel;
import java.util.ArrayList;
import java.util.Iterator;


/**
 * Base class for runnning a single HTTP transaction on a separate thread.
 * It uses a {@code Channel} to pass information and a {@link ServerHandler} to process the message.
 */
public abstract class ServerConnection implements Runnable {

    /** For logging */
    private static final Logger logger;


    /** Message start and end between HTTP data */
    protected static String HTTPGSTART = "GET /?";
    protected static String HTTPPSTART = "POST /?";
    protected static String HTTPMEND = " HTTP/1.";

    /** The port to listen on */
    protected int port;

    /** Timeout for recieving continuous message */
    protected long timeOut;

    /** The server handler that processes the message */
    protected ServerHandler serverHandler;

    /** The listener channel */
    protected Channel channel;

    /** To synchronize on */
    protected final Object syncOn = new Object();


   static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServerConnection.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of ServerConnection.
     * @param theChannel the listener channel.
     * @param theTimeOut timeout for recieving continuous message.
     * @param theServerHandler the server handler that processes the message.
     * @throws Exception any error.
     */
    public ServerConnection(Channel theChannel, long theTimeOut, ServerHandler theServerHandler) throws Exception
    {
        timeOut = theTimeOut;
        serverHandler = theServerHandler;
        channel = theChannel;
    }

    /**
     * Parse the input request string to re-construct the MethodInfo objects.
     * @param message the request message, an be Xml-RPC, or Rest, for example.
     * @return an HttpEntity with MethodInfo objects or Rest string.
     * @throws java.lang.Exception any error.
     */
    protected HttpEntity convertRequest(String message) throws Exception
    {
        int index;                                  //index
        HttpEntity request;                         //client request
        Object messageObj;                          //message as an Object

        request = null;
        if (!message.equals("")) {
            if (message.startsWith(HTTPGSTART)) {
                message = message.substring(HTTPGSTART.length());
            }
            if (message.startsWith(HTTPPSTART)) {
                message = message.substring(HTTPPSTART.length());
            }

            index = message.indexOf(HTTPMEND);
            if (index > 0) {
                message = message.substring(0, index);
                message = XmlHtmlHandler.decodeXml(message);
                message = XmlHtmlHandler.removeFormatting(message);
                message = XmlHandler.removeElementSpecs(message);
            }

            messageObj = Parsers.parse(message);
            if (messageObj instanceof HttpEntity) {
                request = (HttpEntity)messageObj;
            } else {
                request = new HttpEntity(Const.REST, MethodConst.GET);
                request.setValue(messageObj);
            }
        }

        return request;
    }

    /**
     * Determine of the request is an HTTP-type that requires headers at the start
     * and create them if it does.
     * @param request the message as an HttpEntity.
     * @return http headers if required.
     */
    protected String httpHeaders(HttpEntity request)
    {
        int i;
        String nextValue;                       //next value
        ArrayList<String> valueList;            //value list
        StringBuilder headers;                  //headers

        headers = new StringBuilder();
        if (request.getType().equalsIgnoreCase(Const.REST) ||
                request.getType().equalsIgnoreCase(HttpConst.HTTP)) {
            headers = new StringBuilder(("HTTP/1.1 " + String.valueOf(request.getStatusCode()) + "\r\n"));

            //copy request headers across
            for (String key: request.getHeaders().keySet())
            {
                valueList = request.getHeaders().get(key);

                for (i = 0; i < valueList.size(); i++)
                {
                    nextValue = valueList.get(i);
                    headers.append(key).append(" ").append(nextValue).append("\r\n");
                }
            }

            headers.append("\r\n");
        }

        return headers.toString();
    }
}
