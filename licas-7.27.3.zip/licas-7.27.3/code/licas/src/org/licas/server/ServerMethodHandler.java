/*
 * ServerMethodHandler.java
 *
 * Created on 22 December 2010
 *
 * Version 1.8.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server;


import org.licas.call.*;
import org.licas.call.client.CallHandler;
import org.licas.call.rest.RestFactory;
import org.licas.call.rest.RestMessage;
import org.licas.parsers.types.Base64;
import org.licas.security.*;
import org.licas.server.model.*;
import org.licas.meta.MetaFactory;
import org.licas.util.*;
import org.licas.util.exception.*;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.io.File;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;


/**
 * Base class for the server handler to execute a single method call. A non-blocking call
 * can pass a null response object, which should simply cancel the operation. Any direct
 * server invocation that does not go through the system is assumed to be to the local file 
 * store and therefore requires a blocking call that returns a file result.
 * The class can also parse a restful-style description of the method.
 * @author Kieran Greer
 */
public abstract class ServerMethodHandler
{
    /** The logger */
    private static final Logger logger;

    
    /** True if blocking call */
    protected boolean isBlocking;
    
    /** True if licas xml-rpc parsing */
    protected boolean isXmlRpc;
    
    /** The server service key */
    protected String adminKey;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServerMethodHandler.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Create a new instance of ServerMethodHandler.
     * @param theAdminKey the server admin key.
     * @throws java.lang.Exception any error.
     */
    public ServerMethodHandler(String theAdminKey) throws Exception
    {
        adminKey = theAdminKey;
        initialise();
    }
    
    /** 
     * Initialise some values.
     */
    private void initialise()
    {
        isXmlRpc = true;
    }
    
    /**
     * Handle the HTTP request.
     * @param bo the object retrieved from the message bus.
     * @return the method execution result.
     */
    public abstract HttpEntity handleMethodExecution(BusEntity bo);
    
    
    /**
     * Return true if the message part is likely to be for a local server request,
     * such as retrieve a file, not a service invocation. The {@code methodInfo}
     * object is also updated.
     * @param message the message part to evaluate.
     * @param methodInfo the method info to update with pre-defined values.
     * @return true if likely to be a local server request.
     * @throws java.lang.Exception any error.
     */
    public static boolean serverRequest(String message, MethodInfo methodInfo) throws Exception
    {
        //indicates request to retrieve a file from the server web folder
        if (FileObject.isKnownFile(message)) {
            methodInfo.setName(Const.LOCALFILECALL);
            methodInfo.setServiceURI(message);
            methodInfo.setRtnType(TypeConst.BYTEARRAY);
            return true;
        }
        
        return false;
    }
    
    /**
     * Return true if the method name indicates a local system call, not a method invocation.
     * @param methodName the method name.
     * @return true if processed directly, such as an html file retrieval.
     */
    private boolean isLocalCall(String methodName)
    {
        return methodName.equals(Const.LOCALFILECALL);
    }

    /**
     * Process a direct server call with no service invocation, if it is one.
     * @param methodInfo the full method description.
     * @param response the response http object to return. Can be null.
     * @return the response object with the reply data.
     * @throws java.lang.Exception any error.
     */
    protected boolean processLocalCall(MethodInfo methodInfo, HttpEntity response)
            throws Exception
    {
        String filePath;                            //file path
        String serverPassword;                      //server password
        byte[] loader;                              //to convert to bytes
        File localFile;                             //local file path
        RandomAccessFile raf;                       //to read the file
        Permission permissionReply;                 //permission reply

        try
        {
            //set default of no reply and then update or change as required
            if (response != null)
            {
                response.removeHeaders("Content-Type");
                response.addHeader("Access-Control-Allow-Origin", "*");
                serverPassword = methodInfo.getServerPassword();

                if (isLocalCall(methodInfo.getName()))
                {
                    if (methodInfo.getName().equals(Const.LOCALFILECALL))
                    {
                        filePath = (String) methodInfo.getServiceURI();
                        if (LocalServer.isPassword(serverPassword))
                        {
                            //check for a file name
                            try
                            {
                                permissionReply = SecurityWebManager.getInstance().checkPermission(MetaConst.FILEPERMISSION,
                                        filePath, MetaConst.READ);

                                if (permissionReply instanceof FilePermission)
                                {
                                    localFile = new File(((FilePermission) permissionReply).folderPath);

                                    raf = new RandomAccessFile(localFile, "r");
                                    loader = new byte[(int) raf.length()];
                                    while ((raf.read(loader)) > 0) {
                                    }
                                    raf.close();

                                    response.addHeader("Content-Type", FileObject.contentTypeFromFile(filePath));
                                    response.setStatusCode(HttpURLConnection.HTTP_OK);
                                    response.setValue(MetaFactory.createMetaValue(Const.RESPONSE, new String(loader)));
                                }
                                else {
                                    forbiddenResponse(response);
                                }
                            }
                            catch (Exception ex) {
                                badRequestResponse(response, ex.getMessage());
                            }

                            return true;
                        }
                        else {
                            throw new PasswordException("");
                        }
                    }
                }
            }

            return false;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "processLocalCall", null, ex);
        }
    }

    /**
     * Process a direct server call with no service invocation, if it is one.
     * @param bo the object retrieved from the message bus.
     * @return the response object with the reply data.
     */
    protected HttpEntity processServiceCall(BusEntity bo)
    {
        String autoID;                              //auto uuid
        String mServerPassword;                     //the method server password
        Element handle;                             //auto handle
        Element clientUri;                          //client URI
        MethodInfo methodInfo;                      //request method info
        MethodInfo clonedInfo;                      //cloned method info
        FaultDetails faultDetails;                  //fault details
        HttpEntity request;                         //request object
        HttpEntity response;                        //method execution reply
        HttpServer httpServer;                      //server references
        Object reply;                               //message reply

        request = bo.getRequest();
        response = new HttpEntity(request.getType(), request.getMethod());

        //this is already converted
        methodInfo = (MethodInfo)request.getValue();
        reply = null;

        try {
            if (methodInfo != null) {

                //initialise some values
                clonedInfo = (MethodInfo) methodInfo.clone();
                clientUri = methodInfo.getClientURI();

                //first check for a local or direct method call
                //if local call fails, try licas method call
                if (!processLocalCall(clonedInfo, request)) {
                    reply = Const.NULL;

                    if (clonedInfo != null) {
                        //first check for a local or direct method call
                        //if local call fails, try licas method call
                        mServerPassword = clonedInfo.getServerPassword();

                        if (LocalServer.isPassword(mServerPassword)) {
                            httpServer = HttpServer.getHttpServer(adminKey);
                            if (httpServer != null) {
                                handle = (Element) clonedInfo.getServiceURI();
                                autoID = Handle.getFirstServiceHandle(handle);

                                try {
                                    if (autoID.equals(Const.HTTPSERVER)) {
                                        try {
                                            //indicates a call on the server itself
                                            if (isBlocking) {
                                                reply = httpServer.executeServer(clonedInfo);
                                            }
                                            else {
                                                httpServer.executeServer(clonedInfo);
                                            }
                                        }
                                        catch (ServiceNotFoundException | MethodNotFoundException |
                                                ServiceException | LicasException slmx) {
                                            //can have service path with server name at start
                                            //so try service invocation as well
                                            if (isBlocking) {
                                                reply = httpServer.execute(clonedInfo);
                                            }
                                            else {
                                                httpServer.execute(clonedInfo);
                                            }
                                        }
                                    }
                                    else {
                                        //pass the method to a service for invocation
                                        if (isBlocking) {
                                            reply = httpServer.execute(clonedInfo);
                                        }
                                        else {
                                            httpServer.execute(clonedInfo);
                                        }
                                    }
                                } catch (ServiceNotFoundException | ServiceException | LicasException snx) {
                                    try {
                                        if (clientUri == null) {
                                            clientUri = clonedInfo.getClientURI();
                                        }

                                        faultDetails = new FaultDetails(MetaConst.SERVICEMISSING, clientUri);
                                    }
                                    catch (Exception ex) {
                                        faultDetails = new FaultDetails(MetaConst.SERVICEMISSING,
                                                ObjectHandler.getValue(clonedInfo.getClientURI()));
                                    }

                                    httpServer.notifyOfFault(faultDetails, adminKey);
                                    throw snx;
                                }
                            }
                            else {
                                throw new ServiceException("The Http Server cannot be accessed.");
                            }
                        }
                        else {
                            throw new ServiceException("The Http Server cannot be accessed.");
                        }

                        //method invocation reply, or ignore if null response
                        if (isBlocking) {
                            convertResponse(response, reply);
                        }
                    }
                    else {
                        //no call in the first place
                        convertResponse(response, reply);
                    }
                }
            }
            else {
                //no call in the first place
                convertResponse(response, reply);
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "processServiceCall", null, ex);
        }

        return response;
    }
    
    /**
     * Convert a message request description into a {@link MethodInfo} object.
     * This determines the request type ({@code XML-RPC or REST}) and parses as required.
     * @param request the whole http request.
     * @return the converted request message.
     * @throws java.lang.Exception any error. 
     */
    public MethodInfo convertRequest(HttpEntity request) throws Exception
    {
        String message;                             //message part
        String callType;                            //call type
        String callService;                         //call service
        String logMessage;                          //for logging
        MethodInfo methodInfo;                      //method info

        methodInfo = null;
        message = null;
        callType = "";
        logMessage = "";

        //if REST call then can be a string, or for XML-RPC can be MethodInfo object
        if (request.getValue() != null) {
            if (CallHandler.isXMLRPC(request.getType())) {
                try {
                    methodInfo = (MethodInfo)request.getValue();
                    callType = "XML-RPC REQUEST";
                }
                catch (Exception ex1) {
                    methodInfo = null;
                }
            }
            else {
                try {
                    methodInfo = (MethodInfo)request.getValue();
                    callType = "LOCAL REQUEST";
                }
                catch (Exception ex2) {
                    methodInfo = null;
                }
            }
        }
        
        if (methodInfo == null) {
            isXmlRpc = false;
            if (CallHandler.isREST(request.getType()))
                callType = "RESTFUL REQUEST";
            else
                callType = "HTTP REQUEST";
            
            if (request.getValue().getClass().getName().equalsIgnoreCase(TypeConst.STRING)) {
                try {
                    message = (String)request.getValue();
                }
                catch (Exception ex) {
                    message = null;
                }
            }

            if (message != null) {
                try {
                    methodInfo = parseWebCall(message);
                }
                catch (Exception ex) {
                    methodInfo = null;
                }
            }
        }

        //log the request
        if (methodInfo != null) {
            if (methodInfo.getServiceURI() == null) callService = Const.HTTPSERVER;
            else callService = ObjectHandler.getValue(methodInfo.getServiceURI());

            if (methodInfo.getClientURI() != null) {
                logMessage = ("From Client: " + XmlHandler.xmlToString(methodInfo.getClientURI()));
            }
            else {
                logMessage = ("From Client: client URI not available");
            }
            logMessage += (" : For: " + methodInfo.getName());            
            logMessage += (" : From Service: " + callService);
        }
        
        logger.logMessage(LoggerHandler.INFO, callType, logMessage);       
        return methodInfo;
    }
    
    /**
     * Parse the message string from the web call and return a method info object.
     * @param message the message string to parse.
     * @return the method info object that is created.
     * @throws java.lang.Exception any error.
     */
    private MethodInfo parseWebCall(String message) throws Exception
    {
        MethodInfo methodInfo;                      //method info
        RestMessage restMessage;                    //rest-style message

        try {
            restMessage = new RestMessage();            
            restMessage.uri = LocalServer.getServerURL();
            restMessage.query = message;
            
            methodInfo = RestFactory.getInstance().toMethodInfo(restMessage);            
            return methodInfo;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.WARN, "parseWebCall", null, ex);
        }
    }
    
    /**
     * Configure the response object based on the message reply. If reply is null
     * then non-blocking reply.
     * @param response the response object.
     * @param reply method call reply, or null.
     */
    protected void convertResponse(HttpEntity response, Object reply)
    {
        int index;                              //index
        String dataType;                        //file data type
        String contentType;                     //reply content type
        String replyStr;                        //reply cast to string

        if ((reply != null) && (response != null)) {
            //initially set an OK response and then change depending
            response.setStatusCode(HttpURLConnection.HTTP_OK);
            response.removeHeaders("Content-Type");
            response.addHeader("Access-Control-Allow-Origin", "*");

            //test for server-based call but mostly should be object to add directly
            if (!isXmlRpc && ObjectHandler.isString(reply)) {
                replyStr = (String)reply;

                //HTTP or RESTful may need different processing
                dataType = null;
                index = replyStr.indexOf(Const.SEPCHARS);

                if (index > 0) {
                    dataType = replyStr.substring(0, index+Const.SEPCHARS.length());
                    reply = replyStr.substring(index+Const.SEPCHARS.length());

                    index = dataType.indexOf(Const.SEPCHARS);
                    dataType = dataType.substring(0, index);                
                }
                else {
                    index = replyStr.indexOf(XmlHandler.SEPARATOR);

                    if (index > 0) {
                        dataType = replyStr.substring(0, index+XmlHandler.SEPARATOR.length());
                        reply = replyStr.substring(index+XmlHandler.SEPARATOR.length());

                        index = dataType.indexOf(XmlHandler.SEPARATOR);
                        dataType = dataType.substring(0, index);                
                    }
                }

                //reply from service method invocation, so a parsed method info object
                replyStr = (String)reply;
                if (dataType != null) {
                    contentType = FileObject.contentTypeFromCode(dataType);

                    //always add the default setting if a binary file
                    if (!FileObject.isKnownTextType(contentType)) {
                        response.addHeader("Content-Type", "text/html");
                    }

                    response.addHeader("Content-Type", contentType);
                }
                else {
                    //add the text headers
                    response.addHeader("Content-Type", "text/html");
                    response.addHeader("Content-Type", "text/xml");
                    response.addHeader("Content-Type", "text/plain");
                }
            
                if ((dataType != null) && TypeConst.isBinaryType(dataType)) {
                    response.setStatusCode(HttpURLConnection.HTTP_OK);
                    response.setValue(new String(Base64.decode(replyStr)));
                }
                else {
                    replyStr = XmlHandler.removeElementSpecs(replyStr);

                    if (FileObject.isKnownXmlType(dataType)) {
                        if (!replyStr.startsWith(Const.XMLHEADER)) {
                            replyStr = (Const.XMLHEADER + " " + replyStr);
                        }
                    }
                    
                    response.setValue(replyStr);
                }
            }
            else {
                response.addHeader("Content-Type", "text/xml");
                response.setValue(reply);
            }
        }
        else {
            noContentResponse(response);
        }
    }
    
    /**
     * Set values in the response to indicate a no content reply.
     * @param response the response object.
     */
    protected void noContentResponse(HttpEntity response)
    {
        if (response != null) {
            response.addHeader("Content-Type", "text/plain");
            response.setStatusCode(HttpURLConnection.HTTP_NO_CONTENT);
            response.setValue("");
        }
    }
    
    /**
     * Set values in the response to indicate a forbidden request.
     * @param response the response object.
     */
    protected void forbiddenResponse(HttpEntity response)
    {
        if (response != null) {
            response.addHeader("Content-Type", "text/plain");
            response.setStatusCode(HttpURLConnection.HTTP_FORBIDDEN);
            response.setValue("");
        }
    }
    
    /**
     * Set values in the response to indicate a not found response.
     * @param response the response object.
     */
    protected void notFoundResponse(HttpEntity response)
    {
        if (response != null) {
            response.addHeader("Content-Type", "text/plain");
            response.setStatusCode(HttpURLConnection.HTTP_NOT_FOUND);
            response.setValue("");
        }
    }
    
    /**
     * Set values in the response to indicate a bad request.
     * @param response the response object.
     * @param message an additional message.
     */
    protected void badRequestResponse(HttpEntity response, String message)
    {
        if (response != null) {
            if (message == null) message = "";
            response.removeHeaders("Content-Type");
            response.addHeader("Content-Type", "text/plain");
            response.setStatusCode(HttpURLConnection.HTTP_BAD_REQUEST);
            response.setValue(message);
        }
    }
}
