/*
 * BusEntity.java
 *
 * Created on 21 May 2020
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server.model;


/**
 * Container class for a message bus object.
 * @author Kieran Greer
 */
public class BusEntity
{
    /** Priority values - larger value is higher priority */
    public static int LOW = 1;
    public static int LOWMED = 2;
    public static int MED = 3;
    public static int MEDHIGH = 4;
    public static int HIGH = 5;

    /** Optional priority to allow preferential queuing */
    protected int priority;

    /** A unique ticket number assigned to the request */
    protected String ticket;

    /** A service type to ask to process the message */
    protected String type;

    /** A UUID for a specific service to invoke */
    protected String id;

    /** Message request */
    protected HttpEntity request;


    /**
     * Create a new instance of BusEntity.
     * @param theTicket unique ticket number for the request.
     */
    public BusEntity(String theTicket)
    {
        ticket = theTicket;
        type = null;
        id = null;
        request = null;
        priority = MED;
    }


    /**
     * Get the unique ticket number for this request.
     * @return the value of ticket.
     */
    public String getTicket() {
        return ticket;
    }

    /**
     * Set the type for a service that is being asked to process the message.
     * @param thisType the service type.
     */
    public void setType(String thisType) {
        type = thisType;
    }

    /**
     * Get the type for a service that is being asked to process the message.
     * @return the value of type.
     */
    public String getType()
    {
        return type;
    }

    /**
     * Set the UUID for a specific service that has been selected to process the message.
     * @param thisID the service UUID.
     */
    public void setID(String thisID) {
        id = thisID;
    }

    /**
     * Get the UUID for a specific service that has been selected to process the message.
     * @return the value of id.
     */
    public String getID()
    {
        return id;
    }

    /**
     * Set the http message request to be accepted.
     * @param theRequest the server handler.
     */
    public void setRequest(HttpEntity theRequest) {
        request = theRequest;
    }
    /**
     * Get the http message request to be accepted.
     * @return the value of request.
     */
    public HttpEntity getRequest()
    {
        return request;
    }
}
