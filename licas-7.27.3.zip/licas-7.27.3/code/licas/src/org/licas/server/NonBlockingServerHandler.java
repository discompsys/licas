/*
 * NonBlockingServerHandler.java
 *
 * Created on 17 September 2010
 *
 * Version 1.5
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server;


import org.licas.MessageInfo;
import org.licas.call.*;
import org.licas.meta.MetaFactory;
import org.licas.module.ServiceModule;
import org.licas.security.FaultDetails;
import org.licas.server.model.BusEntity;
import org.licas.server.model.HttpEntity;
import org.licas.util.*;
import org.licas.util.exception.LicasException;
import org.jlog2.*;
import org.jlog2.util.UuidHandler;
import org.jlog2.exception.ExceptionHandler;
import org.licas_xml.abs.Element;

import java.util.concurrent.*;


/**
 * This class handles the HTTP non-blocking (asynchronous) server requests, by passing it to the appropriate service for execution.
 * This class receives the http non-blocking request and tries to process it.
 * @author Kieran Greer
 */
public class NonBlockingServerHandler extends ServerHandler
{
    /** The logger */
    private static final Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(NonBlockingServerHandler.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of NonBlockingServerHandler.
     * @param theServerPassword the server password.
     * @param theAdminKey the service key.
     * @throws java.lang.Exception any error.
     */
    public NonBlockingServerHandler(String theServerPassword, String theAdminKey) 
            throws Exception
    {
        super(theServerPassword, theAdminKey);
    }


    /**
     * Handle the HTTP request.
     * @param request the HTTP request.
     * @return the method execution response.
     * @throws java.lang.Exception any error.
     */
    public HttpEntity handle (HttpEntity request) throws Exception
    {
        String method;                                      //http method
        String serviceID;                                   //id of service to invoke
        String reply;                                       //method reply
        Callable<String> callableTask;                      //callable method
        ScheduledExecutorService scheduler;                 //thread scheduler
        Object messageObj;                                  //the message value
        BusEntity roEntity;                                 //request object information
        MessageInfo ro;                                     //the request object
        MethodInfo methodInfo;                              //method in licas format
        NonBlockingServerMethodHandler serverMethodHandler; //server method handler
        FaultDetails fd;                                    //fault details

        try {
            method = request.getMethod();
            if (!method.equalsIgnoreCase(MethodConst.GET) && !method.equalsIgnoreCase(MethodConst.POST) &&
                    !method.equalsIgnoreCase(MethodConst.HEAD)) {
                throw new LicasException("HttpServer error: " + method + " method not supported");
            }

            //initialise the message processing
            serverMethodHandler = new NonBlockingServerMethodHandler(adminKey);
            methodInfo = serverMethodHandler.convertRequest(request);
            request.setValue(methodInfo);

            //add this handler to the message bus, to be processed in order
            roEntity = new BusEntity(UuidHandler.getUuid(15));
            roEntity.setRequest(request);
            ro = new MessageInfo(roEntity);
            ro.setCommID(roEntity.getTicket());
            LocalServer.getApi(serverPassword).messageToBus(ro, adminKey);

            scheduler = Executors.newSingleThreadScheduledExecutor();
            callableTask = () -> ((BusEntity)ro.getMessage()).getID();

            //timeout is not relevant because the client has already released,
            // but still need to wait for method to be accepted by some service before executing it
            reply = null;
            while (reply == null) {
                Future<String> future = scheduler.schedule(callableTask, ServiceConst.MESSAGESLEEP, TimeUnit.MILLISECONDS);
                reply = future.get();
            }

            //if message cannot be processed then it might be flagged as a fault
            //this can be sent to the server for processing, otherwise, execute as normal
            if (MetaFactory.getFactoryService().isFaultComm(((BusEntity)ro.getMessage()).getID())) {
                fd = new FaultDetails(MetaConst.METHODFAULT, ((BusEntity)ro.getMessage()).getID());

                serviceID = null;
                messageObj = methodInfo.getServiceURI();
                if (messageObj instanceof ServiceModule) {
                    serviceID = ((ServiceModule) messageObj).getUUID();
                }
                else if (messageObj instanceof Element) {
                    serviceID = Handle.getFirstHandleServiceServer(((Element) messageObj));
                }

                if (serviceID != null) {
                    fd.getConceptList().add(serviceID);
                }
                else {
                    fd.getConceptList().add(Const.ANON);
                }

                //add fault details and send to server
                LocalServer.getApi(adminKey).notifyOfFault(fd, adminKey);
            }
            else {
                //first need to change a service type into the id of the accepting service
                messageObj = methodInfo.getServiceURI();
                if (messageObj instanceof Element) {
                    methodInfo.setServiceURI(Handle.changeFirstHandleServiceServer(((Element) messageObj),
                            ((BusEntity)ro.getMessage()).getID()));
                }

                //can now pass the message through the rest of the system to be executed
                serverMethodHandler.handleMethodExecution((BusEntity) ro.getMessage());
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.WARN, "handle", null, ex);
        }

        return null;
    }

    /**
     * Handle the HTTP request.
     * @param roEntity the bus message.
     * @return the method execution response.
     * @throws java.lang.Exception any error.
     */
    public HttpEntity handle (BusEntity roEntity) throws Exception
    {
        String serviceID;                                   //id of service to invoke
        Object messageObj;                                  //the message value
        MessageInfo ro;                                     //the request object
        MethodInfo methodInfo;                              //method in licas format
        NonBlockingServerMethodHandler serverMethodHandler; //server method handler
        FaultDetails fd;                                    //fault details

        try {
            //initialise the message processing
            serverMethodHandler = new NonBlockingServerMethodHandler(adminKey);
            methodInfo = (MethodInfo)roEntity.getRequest().getValue();

            ro = new MessageInfo(roEntity);
            ro.setCommID(roEntity.getTicket());
            LocalServer.getApi(serverPassword).messageToBus(ro, adminKey);

            //timeout is not relevant because the client has already released,
            // but still need to wait for method to be accepted by some service before executing it
            while (((BusEntity)ro.getMessage()).getID() == null)
            {
                Thread.sleep(ServiceConst.MESSAGESLEEP);
            }

            //if message cannot be processed then it might be flagged as a fault
            //this can be sent to the server for processing, otherwise, execute as normal
            if (MetaFactory.getFactoryService().isFaultComm(((BusEntity)ro.getMessage()).getID())) {
                fd = new FaultDetails(MetaConst.METHODFAULT, ((BusEntity)ro.getMessage()).getID());

                serviceID = null;
                messageObj = methodInfo.getServiceURI();
                if (messageObj instanceof ServiceModule) {
                    serviceID = ((ServiceModule) messageObj).getUUID();
                }
                else if (messageObj instanceof Element) {
                    serviceID = Handle.getFirstHandleServiceServer(((Element) messageObj));
                }

                if (serviceID != null) {
                    fd.getConceptList().add(serviceID);
                }
                else {
                    fd.getConceptList().add(Const.ANON);
                }

                //add fault details and send to server
                LocalServer.getApi(adminKey).notifyOfFault(fd, adminKey);
            }
            else {
                //first need to change a service type into the id of the accepting service
                messageObj = methodInfo.getServiceURI();
                if (messageObj instanceof Element) {
                    methodInfo.setServiceURI(Handle.changeFirstHandleServiceServer(((Element) messageObj),
                            ((BusEntity)ro.getMessage()).getID()));
                }

                //can now pass the message through the rest of the system to be executed
                serverMethodHandler.handleMethodExecution((BusEntity) ro.getMessage());
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.WARN, "handle", null, ex);
        }

        return null;
    }
}
