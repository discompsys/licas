/*
 * PacketInfo.java
 *
 * Created on 28 March 2007
 *
 * Version 1.2.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server.model;


import org.jlog2.Logger;
import org.jlog2.LoggerHandler;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.FileLoader;
import org.licas.util.Const;

import java.io.*;


/**
 * This class stores information relating to transferring a message in parts from one 
 * server to another. A message can be converted into a String-based description and then sent 
 * in a single transaction call from one server to another. If the message is very large, then you
 * can decide to send it in parts. The approximate maximum size of a message part can be specified
 * and the message will be split up into strings of this size. Each string can then be sent
 * in separate calls and saved to a file on the receiving server. When all parts have been
 * sent the file can be read and the message converted back into the Java objects.
 * @author Kieran Greer
 */
public class PacketInfo 
{
    /** The logger */
    private static final Logger logger;
    
    /** The maximum size of the allowed packet to send in bytes */
    private int packetSize;
    
    /** The name of the file to write the packets to */
    private String fileName;
    
    /** The file to write to */
    private FileWriter fileWriter;

    /** An input stream */
    private DataInputStream dataInputStream;

    /** An output stream */
    private DataOutputStream dataOutputStream;
    
    
    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(PacketInfo.class.getName());
        logger.setDebug(false);
    }
    
    /**
     * Create a new instance of PacketInfo
     * @param thisFileName the name of the file to write to.
     * @param thisPacketSize the maximum size of the message packet to send.
     */
    public PacketInfo(String thisFileName, int thisPacketSize)
    {
        fileName = thisFileName;
        packetSize = thisPacketSize;
        dataInputStream = null;
        dataOutputStream =  null;
        fileWriter = null;
    }
    
    /**
     * Set the packet size to the value passed in.
     * @param thePacketSize the packet size.
     */
    public void setPacketSize(int thePacketSize)
    {
        packetSize = thePacketSize;
    }
    
    /**
     * Get the packet size.
     * @return the value of packetSize.
     */
    public int getPacketSize()
    {
        return packetSize;
    }
    
    /**
     * Set the file name.
     * @param theFileName the file name.
     */
    public void setFileName(String theFileName)
    {
        fileName = theFileName;
    }
    
    /**
     * Get the file name.
     * @return the value of fileName.
     */
    public String getFileName()
    {
        return fileName;
    }
    
    /**
     * Get the file writer.
     * @return the value of fileWriter.
     */
    public FileWriter getFileWriter()
    {
        return fileWriter;
    }

    /**
     * Create a file with the name of fileName.
     * @return true if the file can be created or false otherwise.
     */
    public boolean createFile()
    {
        try {
            closeFileChannel();
            fileWriter = new FileWriter(fileName);
            return true;
        }
        catch (Exception ex) {
            return false;
        }
    }

    /**
     * Close the file writer.
     * @return true if closed successfully.
     */
    public boolean closeFileWriter()
    {
        try {
            if (fileWriter != null) {
                fileWriter.close();
                fileWriter = null;
            }
            
            return true;
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "closeFileWriter",
                    null, ex);
            
            return false;
        }
    }

    /**
     * Delete the currently stored file.
     */
    public void deleteFile()
    {
        File theFile;                               //the file

        try {
            closeFileChannel();
        }
        catch (Exception ex) {}

        try {
            closeFileWriter();
        }
        catch (Exception ex) {}

        try {
            theFile = new File(fileName);
            theFile.delete();
        }
        catch (Exception ex) {}
    }
    
    /**
     * Get the file connection for the current file.
     * @return the input stream generated from the fileConnection.
     * @throws java.lang.Exception any error.
     */
    public DataInputStream getInputStream() throws Exception
    {
        String filePath;                    //canonical file path

        closeFileWriter();
        if (dataInputStream == null) {
            if (closeFileChannel()) {
                try {
                    filePath = Const.FILEURIPREFIX + fileName;
                    dataInputStream = FileLoader.getDataInputStream(filePath);
                }
                catch (Exception ex) {
                    dataInputStream = null;
                }
                
                if (dataInputStream == null) {
                    try {
                        //if file connection not supported then need to open standard
                        //data input stream, but this will not have a lock on the file
                        dataInputStream = new DataInputStream(new FileInputStream(fileName));
                    }
                    catch (Exception ex) {}
                }
            }
        }
        
        return dataInputStream;
    }

    /**
     * Get the file connection for the current file.
     * @return the output stream generated from the fileConnection.
     */
    public DataOutputStream getOutputStream()
    {
        String filePath;                    //canonical file path

        closeFileWriter();
        if (dataOutputStream == null) {
            if (closeFileChannel()) {
                try {
                    filePath = Const.FILEURIPREFIX + fileName;
                    dataOutputStream = FileLoader.getDataOutputStream(filePath);
                }
                catch (Exception ex) {
                    dataOutputStream = null;
                }
                
                if (dataOutputStream == null) {
                    try {
                        //if file connection not supported then need to open standard
                        //data output stream, but this will not have a lock on the file
                        dataOutputStream = new DataOutputStream(new FileOutputStream(fileName));
                    }
                    catch (Exception ex) {}
                }
            }
        }

        return dataOutputStream;
    }
    
    /**
     * Close the file input channel.
     * @return true if closed successfully.
     */
    public boolean closeFileChannel()
    {
        try {
            if (dataInputStream != null) {
                dataInputStream.close();
                dataInputStream = null;
            }

            if (dataOutputStream != null) {
                dataOutputStream.close();
                dataOutputStream = null;
            }

            return true;
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "closeFileChannel",
                    null, ex);
            
            return false;
        }
    }
}
