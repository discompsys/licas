/*
 * MessageMediator.java
 *
 * Created on 20 April 2020
 *
 * Version 1.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server;


import org.jlog2.util.UuidHandler;
import org.licas.*;
import org.licas.call.*;
import org.licas.def.*;
import org.licas.meta.MetaFactory;
import org.licas.query.LicasQueryConst;
import org.licas.server.esb.MonitorServer;
import org.licas.server.esb.PublishSubscribe;
import org.licas.server.model.BusEntity;
import org.licas.server.model.HttpEntity;
import org.licas.service.model.*;
import org.licas.util.*;
import org.licas.util.exception.*;
import org.licas_xml.abs.Element;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.util.ArrayList;
import java.util.concurrent.*;


/** This class mediates the process of passing messages between the server and the services */
public class MessageMediator extends Thread implements BusDef, PublishSubscribeDef {

    /** For logging */
    private static final Logger logger;

    /** Sleep times for the loop */
    private static final int MAXDELAY = (ServiceConst.MESSAGESLEEP * 50);


    /** To monitor the server resource allocation */
    protected MonitorServer monitorServer;

    /**
     * The publish-subscribe facility for registering and notifying about service work.
     */
    protected PublishSubscribeDef pubSub;

    /**
     * Communication IDs to identify the calling components and replies
     * for stored method results.
     */
    protected MessageStore messageStore;

    /** The parent password handler */
    protected PasswordHandler passwordHandler;

    /** The parent ESB server */
    protected ESB esb;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(MessageMediator.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of MessageMediator.
     * @param theESB the parent ESB server.
     * @param thePasswordHandler the parent password handler.
     * @param theMessageStore the message store.
     */
    public MessageMediator(ESB theESB, PasswordHandler thePasswordHandler, MessageStore theMessageStore)
    {
        esb = theESB;
        passwordHandler = thePasswordHandler;
        messageStore = theMessageStore;
        initialise();
    }

    /**
     * Initialise some values
     */
    private void initialise()
    {
        monitorServer = new MonitorServer(passwordHandler, this);
        pubSub = new PublishSubscribe();
    }

    /**
     * Run the thread loop to process the message bus queue.
     */
    public void run() {
        boolean isOK = true;                        //true if OK
        final int[] sleepTime = new int[1];         //loop delay
        ScheduledExecutorService scheduler;         //the scheduler

        try {
            scheduler = Executors.newSingleThreadScheduledExecutor();
            sleepTime[0] = ServiceConst.MESSAGESLEEP;

            Callable callableTask = () -> {
                if (monitorServer.hasMessages()) {
                    monitorServer.processNextMessage();
                    sleepTime[0] = ServiceConst.MESSAGESLEEP;
                }
                else {
                    sleepTime[0] += ServiceConst.MESSAGESLEEP;
                    if (sleepTime[0] > MAXDELAY) {
                        sleepTime[0] = MAXDELAY;
                    }
                }

                return null;
            };

            while (isOK) {
                scheduler.schedule(callableTask, sleepTime[0], TimeUnit.MILLISECONDS).get();
            }
        }
        catch (Exception ex)
        {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "run", null, ex);
        }
    }

    /**
     * Add the message to the message bus queue for subsequent processing.
     * @param ro the request object to add.
     * @return true if added, false otherwise.
     */
    public boolean messageToBus(MessageInfo ro) {
        return monitorServer.messageToBus(ro);
    }

    /**
     * Remove the message with the specified ticket number from the queue.
     * @param ticket unique ticket number, equivalent to a communication ID.
     */
    public void cancelMessage(String ticket) {
        monitorServer.cancelMessage(ticket);
    }

    /**
     * Get a list of current services on the server that allow ptp comm.
     * @return list of current service IDs.
     * @throws LicasException licas error.
     */
    public ArrayList<String> getServiceNames() throws LicasException {
        ArrayList<String> names;                //list of names

        //create names list
        names = esb.getServiceNamesPermission();
        names.add(Const.HTTPSERVER);

        return names;
    }


    /**
     * Get a list of current services on the server for a service type that allow subscribe comm.
     * @param serviceType the service type to check for.
     * @return list of current service IDs.
     * @throws LicasException licas error.
     */
    public ArrayList<String> getServiceTypeNames(String serviceType) throws LicasException {
        ArrayList<String> types;                //list of types
        ArrayList<String> sTypes;               //selected types
        ArrayList<String> names;                //list of names

        //create types-names list, only for subscribed services
        types = esb.getServiceTypes();
        names = new ArrayList<>();

        if (types.contains(serviceType)) {
            sTypes = new ArrayList<>();
            sTypes.add(serviceType);

            names = esb.getServiceTypeNamesPermission(sTypes);
        }

        return names;
    }

    /**
     * Execute a call on the system message bus. This passes the message to a queue on the server
     * from where it gets selected for processing by a service.
     * @param methodInfo the method call description with all of the required information.
     * @return Object the reply to the call.
     * @throws java.lang.Exception any error.
     */
    public Object messageBus(MethodInfo methodInfo) throws Exception
    {
        String rtnType;                         //method return type
        BlockingServerHandler bsh;              //blocking server handler
        NonBlockingServerHandler nbsh;          //non-blocking server handler
        Object reply = null;                    //method reply

        //have to use the message bus here, so add to bus and wait for reply
        try
        {
            HttpEntity request = new HttpEntity(Const.ANON, Const.ANON);
            request.setValue(methodInfo);
            rtnType = methodInfo.getRtnType();

            //add this handler to the message bus, to be processed in order
            BusEntity roEntity = new BusEntity(UuidHandler.getUuid(15));
            roEntity.setRequest(request);

            if (rtnType.equals(TypeConst.VOID)) {
                //create non-blocking server handler to handle the message process
                nbsh = new NonBlockingServerHandler(passwordHandler.getPassword(),
                        passwordHandler.getAdminKey());

                nbsh.handle(roEntity);
            }
            else {
                //create blocking server handler to handle the message process
                bsh = new BlockingServerHandler(passwordHandler.getPassword(),
                        passwordHandler.getAdminKey());

                request = bsh.handle(roEntity);
                if (request != null) {
                    reply = request.getValue();

                    //need to consider any parsing issues here, before returning
                    if (!ObjectHandler.isNull(reply) && !rtnType.equals(TypeConst.OBJECT)) {
                        if (rtnType.equals(TypeConst.STRING) && !ObjectHandler.isString(reply)) {
                            if (ObjectHandler.isElement(reply)) {
                                reply = XmlHandler.xmlToString((Element) reply);
                                reply = XmlHandler.addStringSpec((String) reply);
                            }
                        }
                    }
                }
            }
        }
        catch (ServiceException se)
        {}
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.WARN, "execute", null, ex);
        }

        return reply;
    }

    /**
     * Execute an asynchronous method on the server, or a service type owned by the server.
     * This method calls {@code executeServerService} to invoke the {@code methodInfo} spec.
     * The asynchronous call does not return a value, thereby freeing the client sooner.
     * After executing the method, it instead saves any reply to a {@code messageStore} under the
     * {@code methodInfo}'s {@code communicationID}.
     * This method forces a return type of {@code Element} on the method it invokes or {@code void} return type.
     * If that is not correct the method to invoke will not be found.
     * @param serviceType the service type on the server.
     * @param methodInfo this is the actual method call as it would be invoked from
     * any place. It requires the correct method name and parameter list.
     * @throws java.lang.Exception any error.
     */
    public void executeServiceTypeAsync(String serviceType, MethodInfo methodInfo) throws Exception
    {
        String rtnType;                         //return type
        Element replyElem;                      //reply element
        String replyID;                         //communication id

        try {
            rtnType = methodInfo.getRtnType();
            if (rtnType.equalsIgnoreCase(TypeConst.VOID)) {
                executeServerService(serviceType, methodInfo);
            } else {
                replyID = methodInfo.getCommunicationID();
                if ((replyID != null) && !replyID.equals(Const.NULL)) {
                    messageStore.addMethodTransit(replyID);
                    replyElem = executeServiceType(serviceType, methodInfo);
                    messageStore.addSavedReply(replyID, replyElem);
                } else {
                    throw new LicasException("Asynchronous message communicationID not set.");
                }
            }
        }
        catch (LicasException liex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.WARN, "executeServiceTypeAsync",
                    null, liex);
        }
        catch (Exception ex) {
            replyID = methodInfo.getCommunicationID();
            if ((replyID != null) && !replyID.equals(Const.NULL)) {
                messageStore.removeReplyID(replyID);
            }

            throw ExceptionHandler.handleException(logger, LoggerHandler.WARN, "executeServiceTypeAsync",
                    null, ex);
        }
    }

    /**
     * Execute a synchronous method on a service type known by the server and probably stored locally.
     * This method calls {@code executeServerService} to invoke the parameter {@code methodInfo} spec.
     * This method forces a return type of {@code Element} on the method it invokes.
     * If that is not correct the method to invoke will not be found.
     * @param serviceType the service type on the server.
     * @param methodInfo this is the actual method description as it would be invoked from
     * any place. It requires the correct method name and parameter list. It is not
     * restricted to the two query types, but the further programming might be required
     * to add other ones. The invoked method is assumed to return XML elements only.
     * @return the reply as an Element.
     * @throws java.lang.Exception any error.
     */
    public Element executeServiceType(String serviceType, MethodInfo methodInfo) throws Exception
    {
        String rtnType;                         //return type
        Element reply;                          //method reply

        reply = null;
        try {
            rtnType = methodInfo.getRtnType();
            if (rtnType.equalsIgnoreCase(TypeConst.VOID)) {
                executeServerService(serviceType, methodInfo);
            } else {
                reply = executeServerService(serviceType, methodInfo);
            }
        }
        catch (PasswordException | MethodNotFoundException pe) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "executeServiceType",
                    null, pe);
        }

        return reply;
    }

    /**
     * Execute a method on the server or a type of service owned by the server.
     * The service password is not required and so the server itself should have
     * more control over the execution of these methods.
     * @param serviceType the service type on the server.
     * @param methodInfo this is the actual method call as it would be made from
     * a remote server. It requires the correct method name and parameter list.
     * The service itself is replaced by a direct reference to one of the specified
     * type, if one exists. The method is assumed to return XML elements only.
     * @return the reply as an Element, or null if a void reply type.
     * @throws java.lang.Exception any error.
     */
    protected Element executeServerService(String serviceType, MethodInfo methodInfo) throws Exception
    {
        final String fServiceType;                              //service type
        final MethodInfo fMethodInfo;                           //method to execute
        final Element[] reply = new Element[1];                 //reply reference
        final Exception[] tex = new Exception[1];               //thread exception
        final CountDownLatch latch = new CountDownLatch(1);     //for synchronization

        fServiceType = serviceType;
        fMethodInfo = methodInfo;
        reply[0] = null;
        tex[0] = null;

        Thread thread = new Thread(() -> {
            try {
                reply[0] = serverServiceThread(fServiceType, fMethodInfo);
            }
            catch (Exception ex) {
                tex[0] = ex;
            }
            finally {
                latch.countDown();
            }
        });
        thread.start();

        latch.await();
        if (tex[0] != null) throw tex[0];
        else return reply[0];
    }

    /**
     * Execute a method on the server or a type of service owned by the server.
     * The service password is not required and so the server itself should have
     * more control over the execution of these methods. It is a kind of function provided
     * by the server for the services that it hosts.
     * @param serviceType the service type on the server.
     * @param methodInfo this is the actual method call as it would be made from
     * a remote server. It requires the correct method name and parameter list.
     * The service itself is replaced by a direct reference to one of the specified
     * type, if one exists. The method is assumed to return XML elements only.
     * @return the reply as an Element, or null if a void reply type.
     * @throws java.lang.Exception any error.
     */
    private Element serverServiceThread(String serviceType, MethodInfo methodInfo) throws Exception
    {
        boolean rtnVoid;                            //true if return type is void

        rtnVoid = methodInfo.getRtnType().equalsIgnoreCase(TypeConst.VOID);
        try {
            if (esb.serverServices.containsKey(serviceType)) {
                if (serviceType.equals(LicasQueryConst.SEARCHMETADATA)) {
                    //Note: no default method to get stats
                    if (rtnVoid) {
                        esb.serverMetaSearch.metaSearch(serviceType, methodInfo.getCallTimeout(),
                                (Element)(methodInfo.getParams().get(0)).getValue(),
                                esb.getServiceLinks(passwordHandler.getAdminKey()));
                    }
                    else {
                        return esb.serverMetaSearch.metaSearch(serviceType, methodInfo.getCallTimeout(),
                                (Element)(methodInfo.getParams().get(0)).getValue(),
                                esb.getServiceLinks(passwordHandler.getAdminKey()));
                    }
                }
                else if (serviceType.equals(LicasQueryConst.SEARCHAUTODATA)) {
                    if (rtnVoid) {
                        esb.autoMetaSearch.autoSearch(serviceType, methodInfo.getCallTimeout(),
                                (Element)(methodInfo.getParams().get(0)).getValue(),
                                esb.getServiceLinks(passwordHandler.getAdminKey()));
                    }
                    else {
                        return esb.autoMetaSearch.autoSearch(serviceType, methodInfo.getCallTimeout(),
                                (Element)(methodInfo.getParams().get(0)).getValue(),
                                esb.getServiceLinks(passwordHandler.getAdminKey()));
                    }
                }
                else if (serviceType.equals(LicasQueryConst.SEARCHWEBFOLDER) ||
                        serviceType.equals(LicasQueryConst.SEARCHALLWEB)) {
                    //Note: no default method to get stats
                    if (rtnVoid) {
                        esb.licasDocSearch.docSearch(serviceType, methodInfo.getCallTimeout(),
                                (Element)(methodInfo.getParams().get(0)).getValue(),
                                esb.getServiceLinks(passwordHandler.getAdminKey()));
                    }
                    else {
                        return esb.licasDocSearch.docSearch(serviceType, methodInfo.getCallTimeout(),
                                (Element)(methodInfo.getParams().get(0)).getValue(),
                                esb.getServiceLinks(passwordHandler.getAdminKey()));
                    }
                }
            }
        }
        catch (PasswordException | MethodNotFoundException pe) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "serverServiceThread",
                    null, pe);
        }

        return null;
    }

    /**
     * Subscribe for a service.
     * @param workInfo new client details. It must include the keyword list and the method
     * to reply with.
     * <ol>
     * <li> A list of descriptive keywords and topic to match with.</li>
     * <li> Details of the client method to reply with if a service work matches with the keywords request.</li>
     * </ol>
     * If {@code getClientURI()} is empty, then the request is ignored. It must also contain
     * a parameter list of size 1, that is either an {@code Object} or a {@link WorkInfo}
     * object, as that is what will be sent as a reply.
     * @return true if service request registered, false if keyword overlap.
     * @throws java.lang.Exception any error.
     */
    public boolean subscribe(WorkInfo workInfo) throws Exception
    {
        try {
            return pubSub.subscribe(workInfo);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "subscribe", null, ex);
        }
    }

    /**
     * Un-subscribe for a service.
     * @param keyInfo list of descriptive keywords to uniquely identify the service.
     * @param clientURI the client URI defines the request client.
     * @throws java.lang.Exception any error.
     */
    public void unsubscribe(KeywordInfo keyInfo, Element clientURI) throws Exception
    {
        try {
            pubSub.unsubscribe(keyInfo, clientURI);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "unsubscribe", null, ex);
        }
    }

    /**
     * Publish to do work.
     * @param workInfo full work details, including an optional contract. The method
     * description must include the client URI as this is what identifies the request.
     * If {@code getClientURI()} is empty, then the request is ignored.
     * @return true if work request registered, false if keyword overlap.
     * @throws java.lang.Exception any error.
     */
    public boolean publish(WorkInfo workInfo) throws Exception
    {
        try {
            return pubSub.publish(workInfo);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "publish", null, ex);
        }
    }

    /**
     * Un-publish to do work.
     * @param keyInfo list of descriptive keywords to uniquely identify the work.
     * @param serviceURI the client URI defines the request service.
     * @throws java.lang.Exception any error.
     */
    public void unpublish(KeywordInfo keyInfo, Element serviceURI) throws Exception
    {
        try {
            pubSub.unpublish(keyInfo, serviceURI);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "unpublish", null, ex);
        }
    }
}
