/*
 * BlockingServerMethodHandler.java
 *
 * Created on 27 December 2010
 *
 * Version 1.10
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server;


import org.licas.call.*;
import org.licas.server.model.*;
import org.jlog2.*;


/**
 * This class receives the HTTP blocking (synchronous) server request, parses it back into the Java object
 * ({@link MethodInfo} or {@code REST}) and passes that to the appropriate service for execution.
 * @author Kieran Greer
 */
public class BlockingServerMethodHandler extends ServerMethodHandler
{
    /** The logger */
    private static final Logger logger;

    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(BlockingServerMethodHandler.class.getName());
        logger.setDebug(false);
    }
        
    /**
     * Create a new instance of BlockingServerMethodHandler.
     * @param theAdminKey the server admin key.
     * @throws java.lang.Exception any error.
     */
    public BlockingServerMethodHandler(String theAdminKey) throws Exception
    {
        super(theAdminKey);
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        isBlocking = true;
    }

    /**
     * Handle the HTTP request.
     * @param bo the object retrieved from the message bus.
     * @return the method execution result.
     */
    public HttpEntity handleMethodExecution(BusEntity bo) {
        return processServiceCall(bo);
    }
}
