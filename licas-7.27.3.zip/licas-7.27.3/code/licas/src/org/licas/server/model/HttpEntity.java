/*
 * HttpEntity.java
 *
 * Created on 27 February 2020
 *
 * Version 1.0
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server.model;


import org.licas.util.Const;

import java.net.HttpURLConnection;
import java.util.*;


/**
 * Container class for an http communication object.
 * @author Kieran Greer
 */
public class HttpEntity
{
    /** 
     * The entity type, with regard to the communication protocol,
     * for example {@link Const}.{@code XMLRPC}, or {@code REST}.
     */
    protected String type;

    /** The protocol method to call */
    protected String method;

    /** Lists of headers, key is the type, value is a list of related values */
    protected HashMap<String, ArrayList<String>> headers;

    /** Message content, can be multiple types */
    protected Object value;

    /** The status code */
    protected int statusCode;

    
    /**
     * Create a new instance of HttpEntity.
     * @param theType the entity protocol type, not null.
     * @param theMethod the protocol method, not null.
     */
    public HttpEntity(String theType, String theMethod)
    {
        type = theType;
        method = theMethod;
        headers = new HashMap<>();
        statusCode = HttpURLConnection.HTTP_OK;
        value = null;
    }
    
    /**
     * Get the communication type, for example {@link Const}.{XMLRPC}.
     * @return the value of type.
     */
    public String getType()
    {
        return type;
    }

    /**
     * Get the protocol method name, Get or Post, for example.
     * @return the value of method.
     */
    public String getMethod()
    {
        return method;
    }

    /**
     * Add a header as a key-value pair.
     * @param key the header name.
     * @param value the header value.
     */
    public void addHeader(String key, String value)
    {
        ArrayList<String> headerList;               //list of headers

        if (!headers.containsKey(key)) {
            headers.put(key, new ArrayList<>());
        }

        headerList = headers.get(key);
        if (!headerList.contains(value)) {
            headerList.add(value);
        }
    }

    /**
     * Remove all headers of the indicated type.
     * @param key the header name or type.
     * @return true if headers of that type were removed.
     */
    public boolean removeHeaders(String key)
    {
        if (headers.containsKey(key))
        {
            headers.remove(key);
            return true;
        }

        return false;
    }

    /**
     * Get a list of all headers.
     * @return the value of headers.
     */
    public HashMap<String, ArrayList<String>> getHeaders()
    {
        return headers;
    }

    /**
     * Set the content value of the entity.
     * @param theValue the value.
     */
    public void setValue(Object theValue)
    {
        value = theValue;
    }

    /**
     * Get the content value of the entity.
     * @return the value of value.
     */
    public Object getValue()
    {
        return value;
    }

    /**
     * Set the http status code.
     * @param theStatusCode the status code.
     */
    public void setStatusCode(int theStatusCode)
    {
        statusCode = theStatusCode;
    }
    
    /**
     * Get the http status code.
     * @return the value of statusCode.
     */
    public int getStatusCode()
    {
        return statusCode;
    }
    
    
    /**
     * Create an HttpEntity of the correct type as defined by the value type.
     * This defaults to HttpEntityObject if the type is not recognised.
     * @param type the communication type.
     * @param method the http method.
     * @param headers optional headers.
     * @param value the content value.
     * @return the appropriate HttpEntity type.
     */
    public static HttpEntity createEntity(String type, String method,
                                          HashMap<String, ArrayList<String>> headers, Object value)
    {
        int i;
        ArrayList<String> headerList;               //header list
        ArrayList<String> newList;                  //header list
        HttpEntity entity;                          //the entity
        
        entity = new HttpEntity(type, method);
        entity.setValue(value);

        if (headers != null) {
            for (String key: headers.keySet() )
            {
                newList = headers.get(key);
                if (!entity.headers.containsKey(key)) {
                    entity.headers.put(key, new ArrayList<>());
                }

                headerList = entity.headers.get(key);
                for (i = 0; i < newList.size(); i++)
                {
                    if (!headerList.contains(newList.get(i))) {
                        headerList.add(newList.get(i));
                    }
                }
            }
        }
        
        return entity;
    }
}
