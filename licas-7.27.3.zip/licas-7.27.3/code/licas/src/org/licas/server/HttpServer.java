/*
 * HttpServer.java
 *
 * Created on 13 April 2007
 *
 * Version 1.20.2
 *
 * Copyright (c) Kieran Greer.
 */

package org.licas.server;


import org.licas.*;
import org.licas.autonomic.*;
import org.licas.call.MethodInfo;
import org.licas.def.ServiceWrapperDef;
import org.licas.meta.ServiceMeta;
import org.licas.module.ModuleHandler;
import org.licas.security.FaultDetails;
import org.licas.security.FaultManager;
import org.licas.server.model.*;
import org.licas.service.JarFactory;
import org.licas.service.link.Link_NM;
import org.licas.service.model.Contract;
import org.licas.service.spec.LinkSpec;
import org.licas.util.*;
import org.licas.util.classloader.LoadObject;
import org.licas.util.exception.*;
import org.licas_internet.ConnectionManager;
import org.licas_xml.abs.Element;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.Monitor;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;


/**
 * A lightweight HTTP server to host server side components. This is not the main
 * class for interacting with the services, but it handles the remote requests
 * received through the HTTP protocol and passes them onto the {@link ESB} class
 * for processing. This base class also stores information on the exact address 
 * that the server is running on and controls both the blocking and non-blocking
 * request threads that receive any remotely sent messages.
 * <p>
 * NOTE: when this is created it also adds a keystore with a default (untrusted)
 * licas certificate.
 * @author Kieran Greer
 */
public class HttpServer implements AutoCloseable
{
    /** The logger */
    private static final Logger logger;


    /** This is the ID of the component */
    protected String uuid = null;
    
    /** This stores and compares all passwords used by this service */
    protected PasswordHandler passwordHandler;
    
    /** True if shutdown the service thread */
    protected boolean shutDown;
    
    /** The server config or setup info */
    protected static ServerConfig serverConfig;
    
    /** The blocking (synchronous) server thread */
    private static BlockingListener blockingListener;
    
    /** The non-blocking (asynchronous) server thread */
    private static NonBlockingListener nonBlockingListener;
    
    /** Process the server uri or ip addresses */
    private static ServerAddress serverAddress = null;


    /** The http server */
    protected static HttpServer httpServer = null;
    
    /** The enterprise service bus wrapper */
    private static ServiceWrapperDef esbWrapper = null;
    
    /** The enterprise service bus */
    private static ESB esb = null;

    /** The fault manager */
    private static FaultManager faultManager;

    /** Java virtual machine version */
    private static String jvm;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(HttpServer.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create an instance of the http server. Either this is the first instance
     * or the admin key is correct for the current instance.
     * @param theServerConfig the server config or setup info.
     * @return true if the instance of the http server is created.
     * @throws java.lang.Exception any error 
     */
    public static boolean setHttpServer(ServerConfig theServerConfig) throws Exception
    {
        if ((httpServer == null) || httpServer.isAdminKey(theServerConfig.getServerAdminKey())) {
            httpServer = new HttpServer(theServerConfig); 
            httpServer.setUUID(Const.HTTPSERVER);    
            ConnectionManager.initSSL_Certs(ServiceConst.CONFIGDIR);
            ConnectionManager.setSSL_Certs();
            return true;
        }
        else {
            return false;
        }
    }
    
    /**
     * Retrieve the static instance of the http server.
     * @param adminKey the server admin key.
     * @return the instance of the http server.
     */
    protected static HttpServer getHttpServer(String adminKey)
    {
        if ((httpServer != null) && (httpServer.isAdminKey(adminKey))) {
            return httpServer;
        }
        else {
            return null;
        }
    }
    
    /**
     * Construct http server object.
     * @param theServerConfig the server config or setup info.
     * @throws java.lang.Exception any error.
     */
    protected HttpServer(ServerConfig theServerConfig) throws Exception
    { 
        passwordHandler = new PasswordHandler(theServerConfig.getServerPassword(), 
                theServerConfig.getServerAdminKey());        
        initialise(theServerConfig);
    }

    /**
     * Initialise values for the server.
     * @param theServerConfig the server config or setup info.
     * @throws java.lang.Exception any error.
     */
    private void initialise(ServerConfig theServerConfig) throws Exception
    {
        try {
            jvm = System.getProperty("java.version");
            if (jvm == null) jvm = "1.8.0";
        }
        catch (Exception ex) {
            jvm = "1.8.0";
        }
        
        shutDown = false;
        serverConfig = theServerConfig;
        LocalServer.setPasswords(serverConfig.getServerPassword(), serverConfig.getServerAdminKey());
        
        serverAddress = new ServerAddress(serverConfig.getServerIP(),
                serverConfig.getServerPort(), serverConfig.getAsHttps());
    }

    /**
     * Initialise the faults model.
     * @throws java.lang.Exception any error.
     */
    private void initialiseFaults() throws Exception
    {
        LinkSpec linkSpec;                          //link spec

        linkSpec = new LinkSpec();
        linkSpec.linkThreshold = (float)0.8;
        linkSpec.monitorThreshold = (float)0.3;
        linkSpec.linkNumber = 100;
        linkSpec.monitorNumber = 100;
        linkSpec.possibleNumber = 100;
        linkSpec.linkIncrement = (float)0.1;
        linkSpec.linkWeightDec = (float)0.5;

        faultManager = new FaultManager(esb, passwordHandler, linkSpec);
    }

    /**
     * Return true if an enterprise service bus is stored and running in this server.
     * @return true if this server is running with all components.
     */
    public boolean isRunning()
    {
        return (esb != null);
    }

    /**
     * Set the ESB and update with the config values. Note that the ESB can only be 
     * added once, at the start of the server initialisation.
     * @param serviceName the service name.
     * @param serviceType the service type.
     * @param adminXml the admin script.
     * @return true if added OK, false otherwise.
     */
    public boolean setESB(String serviceName, String serviceType, Element adminXml)
    {
        ServiceMeta serviceMeta;                    //service metadata
        
        try {
            if (esb == null) {
                esb = new ESB(passwordHandler.getPassword(), passwordHandler.getAdminKey(), adminXml);
                esb.setUUID(serviceName);
                esb.setServiceType(serviceType);
                esb.setServer(this);
                
                esbWrapper = createServiceWrapper(esb, serviceName, serviceType,
                        new ArrayList<>(), adminXml);
                
                //register the esb's metadata with the server
                serviceMeta = esb.createMetaForRepos(passwordHandler.getAdminKey());
                serviceMeta.uuid = serviceName;
                serviceMeta.serviceType = serviceType;
                serviceMeta.serviceUri = esb.getFullPath();
                serviceMeta.serviceClass = esb.getClass().getName();         
                esb.addServiceMeta(passwordHandler.getPassword(), passwordHandler.getAdminKey(), serviceMeta);

                initialiseFaults();
                return true;
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "setESB", "", ex);
        }
        
        return false;
    }
    
    /** 
     * Set the ESB and update with the config values. Note that the ESB can only be 
     * added once, at the start of the server initialisation.
     * @param serviceName the name of the service.
     * @param serviceType the type of the service.
     * @param jarFile the jar files for a remote loading. Values are jar paths
     * of type String.
     * @param className the name of the service class.
     * @param params a list of initialisation parameters.
     * @return true if added OK, false otherwise.
     */
    public boolean setESB(String serviceName, String serviceType, ArrayList<String> jarFile,
            String className, ArrayList<Object> params)
    {
        Element adminXml = null;                    //admin script
        ServiceMeta serviceMeta;                    //service metadata
        
        try {
            if (esb == null) {
                esb = (ESB)LoadObject.loadObject(jarFile, className, params);
                esb.setUUID(serviceName);
                esb.setServiceType(serviceType);
                esb.setServer(this);
                
                if (params.size() > 3) {
                    adminXml = (Element)params.get(2);
                }
                
                esbWrapper = createServiceWrapper(esb, serviceName, serviceType,
                        jarFile, adminXml);
                
                //register the esb's metadata with the server
                serviceMeta = esb.createMetaForRepos(passwordHandler.getAdminKey());
                serviceMeta.uuid = serviceName;
                serviceMeta.serviceType = serviceType;
                serviceMeta.serviceUri = esb.getFullPath();
                serviceMeta.serviceClass = esb.getClass().getName();         
                esb.addServiceMeta(passwordHandler.getPassword(), passwordHandler.getAdminKey(), serviceMeta);

                initialiseFaults();
                return true;
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "setESB", "", ex);
        }
        
        return false;
    }

    /**
     * Return the Enterprise Service Bus stored in this server.
     * @param adminKey the admin key for this server.
     * @return ESB the service manager.
     */
    protected ESB getESB(String adminKey)
    {
        if ((httpServer != null) && httpServer.isAdminKey(adminKey)) {
            return esb;
        }

        return null;
    }

    /**
     * Return true if this server is running a jar factory.
     * @param thePassword the password for this server.
     * @return true if a jar factory is installed.
     */
    protected boolean hasJarFactory(String thePassword)
    {
        if (httpServer.passwordHandler.isPassword(thePassword)) {
            return (JarFactory.getInstance() != null);
        }

        return false;
    }

    /**
     * Get the local server password, which is the ESB password as well.
     * @return the local server password.
     * @throws java.lang.Exception any error.
     */
    protected String getServerPassword() throws Exception
    {
        return passwordHandler.getPassword();
    }
    
    /**
     * Create a service wrapper suitable for storing the service object. This version
     * returns the default autonomic manager, or one described in the admin document.
     * So you should extend this class and overwrite this method to return a different manager.
     * @param theService the service that is wrapped and managed. Must be {@link Auto}-derived.
     * @param serviceName the name of the service.
     * @param serviceType the type of the service.
     * @param jarFiles the jar files for a remote loading. Values are jar paths
     * of type String.
     * @param adminXml an admin document describing the service wrapper. This is
     * probably null, but might be a config and policy script, for example.
     * @return the correct service wrapper type.
     * @throws java.lang.Exception any error.
     */
    protected ServiceWrapperDef createServiceWrapper(Auto theService, String serviceName,
                                                     String serviceType, ArrayList<String> jarFiles,
                                                     Element adminXml) throws Exception
    {
        String className;                           //class name
        ArrayList<String> amJarFiles;               //list of jar files
        ArrayList<Object> params;                   //parameters
        AutonomicManager aWrapper;                  //service wrapper
        Element nextElem;                           //next element
        
        className = null;
        amJarFiles = new ArrayList<>();

        if (adminXml != null) {
            nextElem = adminXml.getChild(Const.CLASSNAME);
            if (nextElem != null) {
                className = nextElem.getText();
                nextElem = adminXml.getChild(Const.JARFILEXML);
                if (nextElem != null) amJarFiles.add(nextElem.getText());
            }

            if (className != null) {
                params = new ArrayList<>();
                params.add(theService);
                params.add(adminXml);
                if (jarFiles != null) amJarFiles.addAll(jarFiles);
                aWrapper = (AutonomicManager)LoadObject.loadObject(amJarFiles, className, params);
            }
            else {
                aWrapper = new AutonomicManagerDefault(theService, adminXml);
            }
        }
        else {
            aWrapper = new AutonomicManagerDefault(theService, adminXml);
        }

        if (!amJarFiles.isEmpty()) {
            aWrapper.setJarFile(amJarFiles);
        }        
        if (serviceName != null) aWrapper.setUUID(serviceName);
        if (serviceType == null) {
            serviceType = Const.SERVICE;
        }

        aWrapper.setServiceType(serviceType);
        aWrapper.copyToService(this);
        if (ModuleHandler.isAutoManager(aWrapper)) {
            aWrapper.start();
        }
        
        return aWrapper;
    }
    
    /**
     * This method should be called to notify the server about a problem or fault.
     * It could also happen automatically through the autonomic manager, for example,
     * but extra coding is required for that. The fault details are read and stored in a tree structure for analysis.
     * Only minimal additional action is taken, such as removing or blocking the offending entity.
     * See the documentation for more details.
     * @param fault a description of the fault.
     * @param adminKey server admin key. If this is incorrect, then the fault is not recorded.
     */
    public void notifyOfFault(FaultDetails fault, String adminKey)
    {
        try {
            if (httpServer != null) {
                if ((esb != null) && passwordHandler.isAdminKey(adminKey)) {
                    //process the fault information
                    faultManager.notifyOfFault(fault);

                    //then add to auto manager loop
                    esb.autoManFault(faultManager.getFaultsTree());
                }
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "notifyOfFault",
                    "", ex);
        }
    }

    /**
     * Get the faults list tree.
     * @param adminKey server admin key.
     * @return the value of faults.
     */
    public Link_NM getFaultsTree(String adminKey)
    {
        if (passwordHandler.isAdminKey(adminKey)) {
            return faultManager.getFaultsTree();
        }

        return null;
    }
    
    /**
     * Return true if the password allows the calling component to access this component.
     * @param thePassword the password to use.
     * @param methodName the method name that needs to be called.
     * @return true if the entered password is the correct password or
     * there is no password.
     */
    public boolean canAccess(String thePassword, String methodName)
    {
        try {
            if (isPublicMethod(methodName)) {
                return true;
            }
            else if (httpServer != null) {
                if (esb != null) {
                    return esb.canAccess(thePassword, methodName);
                }
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "canAccess",
                null, ex);
        }

        return false;
    }
    
    /**
     * Return true if the password allows the calling component to access this component.
     * @param thePassword the password to use.
     * @param theMethod the method that needs to be called.
     * @return true if the entered password is the correct password or
     * there is no password.
     */
    public boolean canAccess(String thePassword, Method theMethod)
    {
        String methodName;                          //the method name

        try {
            methodName = theMethod.getName();
            if (isPublicMethod(methodName)) {
                return true;
            }
            else if (httpServer != null) {
                if (esb != null) {
                    return esb.canAccess(thePassword, methodName);
                }
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "canAccess",
                    null, ex);
        }

        return false;
    }

    /**
     * Start the request thread.
     */
    protected void startRequestThread()
    {
        try {
            //start the synchronous request handler
            if ((blockingListener == null) || blockingListener.threadAliveState().equals("false")) {
                blockingListener = new BlockingListener(serverConfig.getServerPort(), serverConfig.getServerIP(),
                        10000, serverConfig.getServerPassword(), serverConfig.getServerAdminKey());
            }

            if (!blockingListener.isAlive()) {
                blockingListener.initRequestListener();
                blockingListener.start();
            }

            //start the asynchronous request handler
            if ((nonBlockingListener == null) || nonBlockingListener.threadAliveState().equals("false")) {
                nonBlockingListener = new NonBlockingListener((serverConfig.getServerPort()+1), serverConfig.getServerIP(),
                        10000, serverConfig.getServerPassword(), serverConfig.getServerAdminKey());
            }

            if (!nonBlockingListener.isAlive()) {
                nonBlockingListener.initRequestListener();
                nonBlockingListener.start();
            }

            //start the esb monitoring
            try {
                esb.start();
            }
            catch (Exception x) {}

            shutDown = false;
            LoggerHandler.logMessage(logger, LoggerHandler.MESSAGE, "startRequestThread",
                    "Http Server started at: " + getServerURL() +
                            " running Java version " + jvm);
        }
        catch (Exception ex) {
            shutDown();
            LoggerHandler.logMessage(logger, LoggerHandler.MESSAGE, "startRequestThread",
                    "Error starting the Http Server started at: " + getServerURL() +
                            ex.getMessage());
        }
    }

    /**
     * Shut down the request listener threads.
     */
    private void shutDownListenerThread()
    {
        if(nonBlockingListener != null) {
            try {
                nonBlockingListener.shutDownListenerThread();
            }
            catch (Exception ex) {}
            finally {
                nonBlockingListener = null;
            }
        }

        if(blockingListener != null) {
            try {
                blockingListener.shutDownListenerThread();
            }
            catch (Exception ex) {}
            finally {
                blockingListener = null;
            }
        }
    }

    /**
     * Return a value indicating if this server should be shut down.
     * @return a value if the server should be shut down.
     */
    protected boolean getThisShutDown()
    {
        if (shutDown) {
            return true;
        }
        else {
            return esb.getShutDown();
        }
    }

    /** Set the shut down variable to true */
    protected void shutDown()
    {
        shutDown = true;
    }

    /**
     * Shut down the server and stop the request thread.
     * @param theAdminKey the unique key to protect loading/removal of the server.
     * @return true if shut down OK.
     */
    protected boolean shutDown(String theAdminKey)
    {
        try {
            LoggerHandler.logMessage(logger, LoggerHandler.MESSAGE, "shutDown",
                    "Server and listener threads shutting down");

            if (httpServer.isAdminKey(theAdminKey)) {
                shutDown();
                httpServer.shutDownListenerThread();
                httpServer.setShutDown(passwordHandler.getAdminKey());
                esb.setShutDown(true, passwordHandler.getAdminKey());

                try {
                    esb.interrupt(passwordHandler.getAdminKey());
                }
                catch (Exception ex) {}

                Monitor.getMonitor().release();
                httpServer = null;
                esb = null;

                LoggerHandler.logMessage(logger, LoggerHandler.MESSAGE, "shutDown",
                        "Server and listener threads shut down");

                LoggerHandler.logMessage(logger, LoggerHandler.INFO, "shutDown",
                        "HttpServer at " + getServerURL() + " shut down");
            }
            else {
                return false;
            }
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "shutDown",
                    null, ex);
        }

        return true;
    }
    
    /** 
     * Get a server administrator contact address, email or something.
     * @return a server contact address.
     */
    protected String contactInfo()
    {
        String contact;                             //contact address
        
        contact = serverConfig.getServerContact();
        if ((contact != null) && !contact.equals("")) {
            return serverConfig.getServerContact();
        }

        return null;
    }
    
    /**
     * Return the service wrapper for the related service name.
     * This method requires the admin key as well, but then returns a direct reference
     * to the wrapper only. Some methods may be executed on the wrapper and not the service.
     * @param serviceName the name of the service you want to retrieve.
     * @param thePassword the password to access the service you want to retrieve.
     * @param adminKey the admin key for the service you want to retrieve.
     * @return the service object if it exists or null if it does not.
     * @throws org.licas.util.exception.ServiceException for service specific error.
     * @throws java.lang.Exception any other error.
     */
    protected ServiceWrapperDef getServiceWrapper(String serviceName, String thePassword, String adminKey)
        throws ServiceException, Exception
    {
        ServiceWrapperDef aWrapper = null;          //service wrapper
        
        if (serviceName != null) {
            if (serviceName.equals(Const.HTTPSERVER)) {
                if (passwordHandler.getAdminKey().equals(adminKey)) {
                    aWrapper = esbWrapper;
                }
            }
            else {
                if (esb != null) {
                    aWrapper = esb.getServiceWrapper(serviceName, thePassword, adminKey);
                }
            }
        }
        else {
            throw new ServiceException("The service (uuid) name is null.");
        }

        return aWrapper;
    }
    
    /**
     * Get this service's password, depending on the calling component's contract description.
     * By default, a service is assigned a 'yes' contract, meaning that it is open and
     * will always return its password to allow for method invocation. The other default
     * option is a 'no' contract, meaning that there is no negotiation and the password
     * must be known. This can also be changed by adding a different 'sla' contract for
     * each service level in the service. You can therefore override this method 
     * to provide your own checks, using this as a guide.
     * @param clientID the clientID of the calling component.
     * @param clientContract the description of the calling component's contract proposal.
     * @return this overriden method passes the call to the nested {@link ESB} object 
     * that also uses the same password set. The server by default will always or 
     * never return its password.
     * @throws java.lang.Exception any error.
     */
    public String getPassword(String clientID, Contract clientContract) throws Exception
    {
        if (httpServer != null) {
            if (esb != null) {
                return esb.getPassword(clientID, clientContract);
            }
        }
        
        return null;
    }
    
    /**
     * Load a jar file into a file object and return. The jar file must be stored
     * in the default services folder location. It must also be compiled into
     * a single package as no third party jar files will be loaded as well.
     * @param jarName the name of the jar file.
     * @return the created file object.
     * @throws java.lang.Exception any error.
     */
    protected FileObject getJarForService(String jarName) throws Exception
    {
        if (JarFactory.getInstance() != null) {
            try {
                jarName = (new File(jarName)).getName();
            }
            catch (Exception ex) {}
           
            return JarFactory.getInstance().jarToFile(jarName);
        }
        else {
            throw new ServiceException("Jar Factory not loaded.");
        }
    }

    /**
     * Execute the specified method and return the result. This executes on the ESB directly.
     * @param methodInfo the method call description with all of the required information.
     * @return the result of the method execution.
     * @throws java.lang.Exception any error.
     */
    public Object execute(MethodInfo methodInfo) throws Exception
    {
        Object reply;                           //method reply

        try {
            //execute on the ESB services
            if (esb != null) {
                reply = esb.execute(methodInfo, true);
            }
            else {
                throw new LicasException("There is no ESB running on the server.");
            }
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.WARN, "execute",
                    null, new ServiceException(ex.getMessage()));
        }

        return reply;
    }
    
    /**
     * Execute the specified method and return the result. This executes on the HttpServer directly.
     * @param methodInfo the method call description with all of the required information.
     * @return the reply, any object.
     * @throws MethodNotFoundException for a method declaration mismatch.
     * @throws java.lang.Exception any other error.
     */
    protected Object executeServer(MethodInfo methodInfo) throws MethodNotFoundException, Exception {
        Object reply = null;                        //method reply

        //execute on the server classes, try httpserver if esb null or method not found
        if ((esb == null) && (httpServer != null))
        {
            reply = ObjectInvoker.invokeMethod(methodInfo, httpServer);
        }
        else if (esb != null) {
            try
            {
                reply = esb.execute(methodInfo, true);
            }
            catch (Exception ex) {
                reply = ObjectInvoker.invokeMethod(methodInfo, httpServer);
            }
        }
        
        return reply;
    }


    //Copied from Service for base methods

    /**
     * Return true if the key passed in is this service's admin key.
     * @param theAdminKey the key to check.
     * @return true if this is the service key
     */
    protected boolean isAdminKey(String theAdminKey)
    {
        return passwordHandler.isAdminKey(theAdminKey);
    }
    
    /**
     * Set the ID value, but only if it is null, otherwise it is not changed.
     * This method should probably not be called manually as the uuid is
     * automatically set when the service is loaded as the service name.
     * @param thisUUID the ID.
     */
    public void setUUID(String thisUUID)
    {
        if (uuid == null) 
        {
            uuid = thisUUID;
        }
    }
    
    /**
     * Get the ID value.
     * @return the value of uuid.
     */
    public String getUUID()
    {
        return uuid;
    }

    /**
     * Return true if the method is a public method that can be freely called.
     * @param methodName the name of the method.
     * @return true if the method can be freely called.
     */
    public boolean isPublicMethod(String methodName)
    {
        return (!isPrivateMethod(methodName) &&
                (passwordHandler.isPublicMethod(methodName) ||
                getPublicMethods().contains(methodName) ||
                getServerMethods().contains(methodName)));
    }

    /**
     * Return true if the method is a public-level method that should not be accessed externally.
     * @param methodName the name of the method.
     * @return true if the method should not be called.
     */
    protected boolean isPrivateMethod(String methodName)
    {
        return (getPrivateMethods().contains(methodName));
    }

    /**
     * Return true if the method can be freely called without a password.
     * Use by calling {@code isPublicMethod}.
     * @return true if the method can be freely called.
     */
    protected ArrayList<String> getServerMethods()
    {
        ArrayList<String> methodNames;                      //list of method names

        methodNames = new ArrayList<>();
        methodNames.add(MethodConst.ISRUNNING);
        methodNames.add(MethodConst.HASESB);
        methodNames.add(MethodConst.CANACCESS);
        methodNames.add(MethodConst.CONTACTINFO);
        methodNames.add(MethodConst.GETFAULTSTREE);

        return methodNames;
    }

    /**
     * Get the list of methods that can be freely called on a Service in general, 
     * without even requiring a password.
     * @return the list of safe method names, but might still require passwords.
     */
    protected ArrayList<String> getPublicMethods()
    {
        ArrayList<String> methodNames;                  //list of method names
        
        methodNames = new ArrayList<>();
        methodNames.add(MethodConst.EXECUTE);
        methodNames.add(MethodConst.GETPASSWORD);
        methodNames.add(MethodConst.HASSERVICE);
        methodNames.add(MethodConst.GETSERVICENAMES);
        methodNames.add("isPublicMethod");
        methodNames.add("getPublicMethods");
        methodNames.add("getServiceClasses");
        methodNames.add("getLinksFromServices");
        methodNames.add("getLinksToServices");
        methodNames.add("serviceNegotiate");
        
        return methodNames;
    }

    /**
     * Get the list of public-level methods that should not be invoked externally, maybe from an interface.
     * @return the list of public-level method names that should not be accessible externally.
     */
    protected ArrayList<String> getPrivateMethods()
    {
        ArrayList<String> methodNames;                  //list of method names

        methodNames = new ArrayList<>();
        methodNames.add("close");

        return methodNames;
    }
    
    /**
     * Set the shutdown variable to indicate that the thread should be stopped.
     * @param thisAdminKey the service key of this service.
     */
    public void setShutDown(String thisAdminKey)
    {
        if (isAdminKey(thisAdminKey)) shutDown();
    }
    
    //End of copied from Service for base methods
    
    
    /**
     * Return true if the ip address and port compares to the address the server is running on.
     * @param host the host address. Can include 'localhost' or '127.0.0.1'.
     * @param port the port.
     * @return true if the whole address agrees with the server address.
     * @throws java.lang.Exception any error.
     */
    protected boolean checkAddress(String host, int port) throws Exception
    {
        if (serverAddress != null) {
            return serverAddress.checkAddress(host, port);
        }
        else {
            return false;
        }
    }

    /**
     * Return true if the ip address represents a local server.
     * @param theIPAddress the ip address to compare, 127.0.0.1, for example.
     * @return true if a local ipAddress.
     * @throws java.lang.Exception any error.
     */
    protected boolean isLocalIPAddress(String theIPAddress) throws Exception
    {
        if (serverAddress != null) {
            return serverAddress.isLocalIPAddress(theIPAddress);
        }
        else {
            return false;
        }
    }
    
    /**
     * Return the http address of the static http server.
     * @return the server URL address, with ip and port, or null
     * if the server is not running.
     */
    protected static String getServerURL()
    {
        if (serverAddress != null) {
            return serverAddress.getUrlAddress();
        }
        else {
            return null;
        }
    }
    
    /**
     * Clean-up before shutting down the service.
     */
    public void close()
    {
        shutDown();
    }
}
