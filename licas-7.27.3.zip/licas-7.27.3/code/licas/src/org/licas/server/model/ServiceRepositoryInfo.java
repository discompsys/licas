/*
 * ServiceRepositoryInfo.java
 *
 * Created on 22 December 2008
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server.model;

import org.licas.meta.ServiceMeta;
import org.licas.server.esb.ServiceRepository;


/**
 * This class stores the service metadata for a single service, with its admin key. 
 * The metadata stored in the {@link ServiceRepository} is only a static subset, but the 
 * key protects other operations as well and so this class is required.
 * @author Kieran Greer
 */
public class ServiceRepositoryInfo 
{
    /** The service key */
    private final String adminKey;
    
    /** The service metadata */
    private final ServiceMeta serviceMeta;
    
    
    /**
     * Create a new instance of ServiceRepositoryInfo.
     * @param theAdminKey the service key.
     * @param theServiceMeta the service metadata.
     */
    public ServiceRepositoryInfo(String theAdminKey, ServiceMeta theServiceMeta)
    {
        adminKey = theAdminKey;
        serviceMeta = theServiceMeta;
    }
    
    /**
     * Get the service key.
     * @return the value of adminKey.
     */
    public String getAdminKey()
    {
        return adminKey;
    }
    
    /**
     * Get the service metadata.
     * @return the value of serviceMeta.
     */
    public ServiceMeta getServiceMeta()
    {
        return serviceMeta;
    }       
}
