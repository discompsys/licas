/*
 * LocalServer.java
 *
 * Created on 1 February 2017
 *
 * Version 1.5
 *
 * Copyright (c) Kieran Greer.
 */

package org.licas.server;


import org.licas.MessageInfo;
import org.licas.call.*;
import org.licas.def.ServiceWrapperDef;
import org.licas.meta.ServiceMeta;
import org.licas.security.FaultDetails;
import org.licas.security.Metrics;
import org.licas.service.link.Link_NM;
import org.licas.service.model.Contract;
import org.licas.util.*;
import org.licas.util.exception.*;
import org.licas_xml.abs.Element;

import java.lang.reflect.Method;
import java.util.*;


/**
 * API for invoking methods on the {@link HttpServer} or {@link ESB}. These are both
 * admin key protected now and so direct access is more difficult.
 * @author Kieran Greer
 */
public class LocalServer 
{
    /** Set to true when the server admin key is set */
    private static boolean keyset = false;
    
    /** Password for the server */
    private static String password;
    
    /** Admin key for the server */
    private static String adminKey;
    
    /** Static local server instance to use */
    private static final LocalServer localServer;

    /** To synchronize on */
    private final Object syncOn = new Object();


    static
    {
        localServer = new LocalServer();
    }
    
    /** Create a new instance of LocalServer */
    protected LocalServer()
    {}
    
    /**
     * Get the local server instance.
     * @param serverPassword the server password or admin key.
     * @return the local server api instance, or {@code null} if there is an error.
     */
    public static LocalServer getApi(String serverPassword)
    {
        if ((localServer != null) && (password != null) &&
            (password.equals(serverPassword) || 
            ((adminKey != null) && adminKey.equals(serverPassword))))
        {
            return localServer;
        }
        
        return null;
    }
    
    /**
     * Set the password and admin key for accessing the server. Can be set only once.
     * @param thePassword the password for accessing the server.
     * @param theAdminKey the admin key for accessing the server.
     */
    protected static void setPasswords(String thePassword, String theAdminKey)
    {
        if (!keyset) 
        {
            password = thePassword;
            adminKey = theAdminKey;
            keyset = true;
        }
    }
    
    /**
     * Return true if an {@link HttpServer} instance is created.
     * @return true if a server instance has been created, false otherwise.
     */
    public static boolean hasServer()
    {
        try 
        {
            return (getHttpServer() != null);
        }
        catch (Exception ex)
        {
            return false;
        }
    }
    
    /**
     * Return true if an enterprise service bus is stored and running in this server.
     * @return true if this server is running with all components.
     */
    public static boolean isRunning()
    {
        try {
            HttpServer httpServer = getHttpServer();
            if (httpServer != null) {
                return httpServer.isRunning();
            }
        }
        catch (Exception ex) {}
        
        return false;
    }
    
    /** 
     * Get a server administrator contact address, email or something.
     * @return a server contact address.
     */
    public static String contactInfo()
    {
        try {
            HttpServer httpServer = getHttpServer();
            if (httpServer != null) {
                return httpServer.contactInfo();
            }
        }
        catch (Exception ex) {}

        return null;
    }
    
    /**
     * Return true if the ip address represents a local server.
     * @param theIPAddress the ip address to compare, 127.0.0.1, for example.
     * @return true if a local ipAddress.
     */
    public static boolean isLocalIPAddress(String theIPAddress)
    {
        try {
            HttpServer httpServer = getHttpServer();
            if (httpServer != null) {
                return httpServer.isLocalIPAddress(theIPAddress);
            }
        }
        catch (Exception ex) {}
        
        return false;
    }
    
    /**
     * Return true if the password allows the calling component to access this component.
     * @param thePassword the password to use.
     * @param methodName the method name that needs to be called.
     * @return true if the entered password is the correct password or
     * there is no password.
     */
    public boolean canAccess(String thePassword, String methodName)
    {
        HttpServer httpServer;                  //http server
        ESB esb;                                //the service bus

        try {
            httpServer = getHttpServer();
            if (httpServer != null) {
                if (httpServer.isPublicMethod(methodName)) {
                    return true;
                }
                else {
                    esb = getESB();
                    if (esb != null) {
                        return esb.canAccess(thePassword, methodName);
                    }
                }
            }
        }
        catch (Exception ex) {}

        return false;
    }
    
    /**
     * Return true if the password allows the calling component to access this component.
     * @param thePassword the password to use.
     * @param theMethod the method that needs to be called.
     * @return true if the entered password is the correct password or
     * there is no password.
     */
    public boolean canAccess(String thePassword, Method theMethod)
    {
        String methodName;                      //the method name
        HttpServer httpServer;                  //http server
        ESB esb;                                //the service bus

        try {
            methodName = theMethod.getName();
            
            httpServer = getHttpServer();
            if (httpServer != null) {
                if (httpServer.isPublicMethod(methodName)) {
                    return true;
                }
                else {
                    esb = getESB();
                    if (esb != null) {
                        return esb.canAccess(thePassword, methodName);
                    }
                }
            }
        }
        catch (Exception ex) {}

        return false;
    }
    
    /**
     * Get this service's password, depending on the calling component's contract description.
     * By default, a service is assigned a 'yes' contract, meaning that it is open and
     * will always return its password to allow for method invocation. The other default
     * option is a 'no' contract, meaning that there is no negotiation and the password
     * must be known. This can also be changed by adding a different 'sla' contract for
     * each service level in the service. You can therefore override this method 
     * to provide your own checks, using this as a guide.
     * @param clientID the clientID of the calling component.
     * @param clientContract the description of the calling component's contract proposal.
     * @return this overridden method passes the call to the nested {@link ESB} object
     * that also uses the same password set. The server by default will always or 
     * never return its password.
     * @throws java.lang.Exception any error.
     */
    public String getPassword(String clientID, Contract clientContract) throws Exception
    {
        try {
            HttpServer httpServer = getHttpServer();
            if (httpServer != null) {
                return httpServer.getPassword(clientID, clientContract);
            }
        }
        catch (Exception ex) {}
        
        return null;
    }
    
    /**
     * Return true if the ip address and port compares to the address the server is running on.
     * @param host the host address. Can include 'localhost' or '127.0.0.1'.
     * @param port the port.
     * @return true if the whole address agrees with the server address.
     */
    public static boolean checkAddress(String host, int port)
    {
        try {
            HttpServer httpServer = getHttpServer();
            if (httpServer != null) {
                return httpServer.checkAddress(host, port);
            }
        }
        catch (Exception ex) {}
        
        return false;
    }
    
    /**
     * Return the http address of the static http server.
     * @return the server URL address, with ip and port, or null
     * if the server is not running.
     */
    public static String getServerURL()
    {
        try {
            return HttpServer.getServerURL();
        }
        catch (Exception ex) {}
        
        return null;
    }
    
    /**
     * Return the server handle of the static http server.
     * @return the server URI, same as calling {@link Handle}.{@code getLocalServerURI()}.
     */
    public static Element getServerHandle()
    {
        try {
            return Handle.getLocalServerURI();
        }
        catch (Exception ex) {}
        
        return null;
    }
    
    /** 
     * Creates a default instance of ESB and set with the config values. Note that
     * the ESB can be added only once, at the start of the server initialisation.
     * @param serviceName the service name.
     * @param serviceType the service type.
     * @param adminXml the admin info or description of this service.
     * @return true if added OK, false otherwise.
     */
    public boolean setESB(String serviceName, String serviceType, Element adminXml)
    {
        try {
            HttpServer httpServer = getHttpServer();
            if ((httpServer != null) && !hasESB(password)) {
                return httpServer.setESB(serviceName, serviceType, adminXml);
            }
        }
        catch (Exception ex) {}
        
        return false;
    }
    
    /** 
     * Creates a user-defined instance of ESB and set with the config values. Note that
     * the ESB can be added only once, at the start of the server initialisation.
     * @param serviceName the name of the service.
     * @param serviceType the type of the service.
     * @param jarFile the jar files for a remote loading. Values are jar paths
     * of type String.
     * @param className the name of the service class.
     * @param params a list of initialisation parameters.
     * @return true if added OK, false otherwise.
     */
    public boolean setESB(String serviceName, String serviceType, ArrayList<String> jarFile,
            String className, ArrayList<Object> params)
    {
        try {
            HttpServer httpServer = getHttpServer();
            if ((httpServer != null) && !hasESB(password)) {
                return httpServer.setESB(serviceName, serviceType, jarFile, className, 
                        params);
            }
        }
        catch (Exception ex) {}
        
        return false;
    }
    
    /**
     * Start the server request thread.
     * @param adminKey the server admin key.
     * @throws java.lang.Exception any error.
     */
    public void startRequestThread(String adminKey) throws Exception
    {
        if (isAdminKey(adminKey)) {
            HttpServer httpServer = getHttpServer();
            if (httpServer != null) {
                httpServer.startRequestThread();
            }
        }
    }

    /**
     * Add the next message to the message bus, to be returned in order for processing by a service.
     * @param ro the message to add, as the whole request object, that then executes itself and returns the result.
     * @param adminKey admin key to access the server.
     * @return true if the request object is added, false otherwise.
     */
    public boolean messageToBus(MessageInfo ro, String adminKey)
    {
        ESB esb = getESB();

        if (esb != null) {
            return esb.messageToBus(ro, adminKey);
        }

        return false;
    }

    /**
     * Remove the message with the specified ticket number from the queue.
     * @param ticket unique ticket number, equivalent to a communication ID.
     * @param adminKey the server admin key.
     * @return true if cancelled, false otherwise.
     */
    public boolean cancelMessage(String ticket, String adminKey)
    {
        ESB esb = getESB();

        if (esb != null) {
            return esb.cancelMessage(ticket, adminKey);
        }

        return false;
    }
    
    /**
     * Execute the specified method and return the result. This executes on the ESB directly.
     * Note that you can execute on a single instance of a service <b>type</b> by setting the
     * {@code methodInfo.serviceURI} to be something like {@link Handle}.{@code createServiceHandle(serviceType)}.
     * @param methodInfo the method call description with all of the required information.
     * @return the reply, any object.
     * @throws ServiceException for non-critical service related problems,
     * such as if the method password is incorrect.
     * @throws java.lang.Exception any error.
     */
    public Object execute(MethodInfo methodInfo) throws Exception
    {
        String replyClass = methodInfo.getRtnType();
        ESB esb = getESB();
        Object reply = null;
        
        if (esb != null) {
            //execute the method using reflection
            if (replyClass.equals(TypeConst.VOID)) {
                esb.messageBus(methodInfo);
                reply = null;
            }
            else {
                reply = esb.messageBus(methodInfo);
            }
        }
        
        return reply;
    }
    
    /**
     * Return true if the service is a blocked service.
     * @param serviceID the service uuid.
     * @return true if (temporarily) blocked from being accessed, false otherwise.
     */
    public boolean isBlockedService(String serviceID)
    {
        try {
            ESB esb = getESB();

            if (esb != null) {
                return esb.isBlockedService(serviceID);
            }
        }
        catch (Exception ex) {}
        
        return false;
    }
    
    /**
     * Set the {@code allowAddService} variable to allow services to be added.
     * @param adminKey the admin key for this service.
     * @param allow true if reset to allow adding of services, false to reset
     * to block of adding services.
     * @return true if the variable is set (adminKey OK), false otherwise.
     */
    public boolean allowAddService(String adminKey, boolean allow)
    {
        try {
            if (isAdminKey(adminKey)) {
                ESB esb = getESB();

                if (esb != null) {
                    return esb.allowAddService(adminKey, allow);
                }
            }
        }
        catch (Exception ex) {}
        
        return false;
    }
    
    /**
     * Return true if the ESB allows adding services.
     * @param adminKey the admin key for the server.
     * @return true if services can be added, false otherwise.
     */
    public boolean getAllowAddService(String adminKey)
    {
        try {
            if (isAdminKey(adminKey)) {
                ESB esb = getESB();

                if (esb != null) {
                    return esb.getAllowAddService();
                }
            }
        }
        catch (Exception ex) {}
        
        return false;
    }
    
    /**
     * Add a service uuid to the list of root nodes. Note that the service itself
     * must have been added previously. This method is only to declare it a root
     * node in some hierarchical organisation structure.
     * @param theRootNode the uuid of the root service to add.
     * @param adminKey the server admin key.
     * @return true if the node is added or false otherwise.
     */
    public boolean addRootNode(String theRootNode, String adminKey)
    {
        synchronized(syncOn)
        {
            try {
                if (isAdminKey(adminKey)) {
                    ESB esb = getESB();

                    if (esb != null) {
                        return esb.addRootNode(theRootNode, adminKey);
                    }
                }
            }
            catch (Exception ex) { }
        }
        
        return false;
    }
    
    /**
     * Return the service for the related service name. This method requires the 
     * service admin key as well, but then returns a direct reference. A direct reference 
     * to the service itself is returned, no matter what the object type is.
     * @param serviceName the name of the service you want to retrieve.
     * @param thePassword the password for the service you want to retrieve.
     * @param adminKey the admin key for the service you want to retrieve.
     * @return the service object if it exists or null if it does not.
     * @throws org.licas.util.exception.ServiceException for service specific error.
     * @throws java.lang.Exception any other error.
     */
    public Object getService(String serviceName, String thePassword, String adminKey)
        throws ServiceException, Exception
    {
        synchronized(syncOn)
        {
            try {
                ESB esb = getESB();

                if (esb != null) {
                    return esb.getService(serviceName, thePassword, adminKey);
                }
            }
            catch (Exception ex) {}
        }
        
        return null;
    }
    
    /**
     * Add a new service to the ESB but do not start its thread.
     * @param thePassword the password to protect access to this component.
     * @param serviceName the name of the service.
     * @param serviceType the type of the service.
     * @param theService the service.
     * @return true if the service has been added, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean addService(String thePassword, String serviceName, String serviceType,
        Object theService) throws Exception
    {
        synchronized(syncOn)
        {
            try {
                ESB esb = getESB();

                if (esb != null) {
                    return esb.addService(thePassword, serviceName, serviceType, theService);
                }
            }
            catch (Exception ex) {}
        }
        
        return false;
    }
    
    /**
     * Add the metadata for the service.
     * @param thePassword the service password. Register if not already added.
     * @param theAdminKey the admin key for the service. Register if not already added.
     * @param theServiceMeta the metadata for the service.
     * @return true if added OK, false otherwise.
     */
    public boolean addServiceMeta(String thePassword, String theAdminKey, ServiceMeta theServiceMeta)
    {
        synchronized(syncOn)
        {
            try {
                ESB esb = getESB();

                if (esb != null) {
                    esb.addServiceMeta(thePassword, theAdminKey, theServiceMeta);
                    return true;
                }
            }
            catch (Exception ex) {}
        }
        
        return false;
    }
    
    /**
     * Get the metadata for the service from the server repository.
     * @param theServiceID the unique id to define the service.
     * @return the metadata in XML format if it exists or null if it does not.
     * @throws java.lang.Exception any error.
     */
    public Element getServiceMeta(String theServiceID) throws Exception
    {
        synchronized(syncOn)
        {
            ESB esb = getESB();

            if (esb != null) {
                return esb.getServiceMeta(theServiceID);
            }
        }
        
        return null;
    }
    
    /**
     * Get the service metadata from the server repository.
     * @param theServiceID the unique id to define the service.
     * @param theAdminKey the unique admin key for the service.
     * @return a direct reference to the object itself so that it can be changed.
     * @throws java.lang.Exception any error.
     */
    public ServiceMeta getServiceMeta(String theServiceID, String theAdminKey)
            throws Exception
    {
        synchronized(syncOn)
        {
            ESB esb = getESB();

            if (esb != null) {
                return esb.getServiceMeta(theServiceID, theAdminKey);
            }
        }
        
        return null;
    }
    
    /**
     * Remove the service metadata from the server repository.
     * @param theServiceID the unique id of the service to remove.
     * @param theAdminKey the unique admin key for the service.
     * @return true if the info is removed or false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean removeServiceMeta(String theServiceID, String theAdminKey)
            throws Exception
    {
        synchronized(syncOn)
        {
            ESB esb = getESB();

            if (esb != null) {
                return esb.removeServiceMeta(theServiceID, theAdminKey);
            }
        }
        
        return false;
    }
    
    /**
     * Return the service wrapper for the related service name.
     * This method requires the admin key as well, and then returns a direct reference
     * to the wrapper only. Some methods may be executed on the wrapper and not the service.
     * @param serviceName the name of the service you want to retrieve.
     * @param thePassword the password to access the service you want to retrieve.
     * @param adminKey the admin key for the service you want to retrieve.
     * @return the service object if it exists or null if it does not.
     * @throws org.licas.util.exception.ServiceException for service specific error.
     * @throws java.lang.Exception any other error.
     */
    public ServiceWrapperDef getServiceWrapper(String serviceName, String thePassword, 
            String adminKey) throws ServiceException, Exception
    {
        HttpServer httpServer = getHttpServer();
        if (httpServer != null) {
            return httpServer.getServiceWrapper(serviceName, thePassword, adminKey);
        }
        
        return null;
    }
    
    /**
     * Get a list of services running on the ESB. This is public information.
     * @return all service uuids, of type String.
     */
    public ArrayList<String> getServiceNames()
    {
        ArrayList<String> serviceNames;                 //names list
        
        serviceNames = null;
        synchronized(syncOn)
        {
            try {
                ESB esb = getESB();

                if (esb != null) {
                    serviceNames = esb.getServiceNames();
                }
            }
            catch (Exception ex) {}
        }
        
        return serviceNames;
    }
    
    /**
     * Return all child service names for a list of service types.
     * @param thisServiceTypes the service types list.
     * @return the service names for the service types list.
     * @throws LicasException if the service types input is {@code null}.
     */
    public ArrayList<String> getServiceNames(ArrayList<String> thisServiceTypes) throws LicasException
    {
        ArrayList<String> serviceNames;                 //names list
        
        serviceNames = null;
        synchronized(syncOn)
        {
            try {
                ESB esb = getESB();

                if (esb != null) {
                    serviceNames = esb.getServiceNames(thisServiceTypes, false);
                }
            }
            catch (Exception ex) {}
        }
        
        return serviceNames;
    }
    
    /**
     * Return all child service names for a list of service types.
     * @param thisServiceTypes the service types list.
     * @param reciprocal is false return all service names of the service types,
     * if true return all service names of all other types.
     * @return the service names for the service types list.
     * @throws LicasException if the service types input is {@code null}.
     */
    public ArrayList<String> getServiceNames(ArrayList<String> thisServiceTypes, boolean reciprocal)
            throws LicasException
    {
        ArrayList<String> serviceNames;                 //names list
        
        serviceNames = null;
        synchronized(syncOn)
        {
            try {
                ESB esb = getESB();

                if (esb != null) {
                    serviceNames = esb.getServiceNames(thisServiceTypes, reciprocal);
                }
            }
            catch (Exception ex) {}
        }
        
        return serviceNames;
    }
    
    /**
     * Get the service type for the specified service.
     * @param serviceID id of the service to retrieve.
     * @return a list of all of the service types, of type String.
     */
    public String getServiceType(String serviceID)
    {
        String serviceType;                             //types list
        
        serviceType = null;
        synchronized(syncOn)
        {
            try {
                ESB esb = getESB();

                if (esb != null) {
                    serviceType = esb.getServiceType(serviceID);
                }
            }
            catch (Exception ex) {}
        }
        
        return serviceType;
    }
    
    /**
     * Get a list of all of the service types in the network.
     * @return a list of all of the service types, of type String.
     */
    public ArrayList<String> getServiceTypes()
    {
        ArrayList<String> serviceTypes;                     //types list
        
        serviceTypes = null;
        synchronized(syncOn)
        {
            try {
                ESB esb = getESB();

                if (esb != null) {
                    serviceTypes = esb.getServiceTypes();
                }
            }
            catch (Exception ex) {}
        }
        
        return serviceTypes;
    }
    
    /**
     * Get a list of all of the service types in the network for a
     * particular category.
     * @param category the category to return service types for.
     * @return a list of all of the service types, of type String.
     */
    public ArrayList<String> getServiceTypes(String category)
    {
        ArrayList<String> serviceTypes;                     //types list
        
        serviceTypes = null;
        synchronized(syncOn)
        {
            try {
                ESB esb = getESB();
                if (esb != null) {
                    serviceTypes = esb.getServiceTypes(category);
                }
            }
            catch (Exception ex) {}
        }
        
        return serviceTypes;
    }
    
    /**
     * Serialize the stored ESB passwords list and return as an XML-based description.
     * @param adminKey the ESB admin key.
     * @return an XML representation of all passwords, or null if the admin key is incorrect.
     */
    public Element passwordsStateToXml(String adminKey)
    {
        synchronized(syncOn)
        {
            try {
                if (isAdminKey(adminKey)) {
                    ESB esb = getESB();
                    if (esb != null) {
                        return esb.passwordsStateToXml(adminKey);
                    }
                }
            }
            catch (Exception ex) {}
        }
        
        return null;
    }
    
    /**
     * Get a list of all available services' metrics.
     * @param adminKey the admin key for the server.
     * @return the service metric stats, key is the service id.
     */
    public HashMap<String, Metrics> allServiceMetrics(String adminKey)
    {
        synchronized(syncOn)
        {
            if (isAdminKey(adminKey)) {
                ESB esb = getESB();

                if (esb != null) {
                    return esb.allServiceMetrics(adminKey);
                }
            }
        }
        
        return null;
    }

    /**
     * This method should be called to notify the server about a problem or fault.
     * It could also happen automatically through the autonomic manager, for example,
     * but extra coding is required for that. The fault details are read and stored in a tree structure for analysis.
     * Only minimal additional action is taken, such as removing or blocking the offending entity.
     * See the documentation for more details.
     * @param fault a description of the fault.
     * @param adminKey server admin key. If this is incorrect, then the fault is not recorded.
     */
    public void notifyOfFault(FaultDetails fault, String adminKey)
    {
        synchronized(syncOn)
        {
            if (isAdminKey(adminKey)) {
                HttpServer httpServer = getHttpServer();
                if (httpServer != null) {
                    httpServer.notifyOfFault(fault, adminKey);
                }
            }
        }
    }

    /**
     * Get the faults list tree, for display purposes.
     * @param adminKey the admin key for the server.
     * @return the value of faults.
     */
    public Link_NM getFaultsTree(String adminKey)
    {
        synchronized(syncOn)
        {
            if (isAdminKey(adminKey)) {
                HttpServer httpServer = getHttpServer();
                if (httpServer != null) {
                    return httpServer.getFaultsTree(adminKey);
                }
            }
        }

        return null;
    }
    
    /**
     * Return true if the correct password.
     * @param theServerPassword the password to check for.
     * @return true if the correct password.
     */
    public static boolean isPassword(String theServerPassword)
    {
        return password.equals(theServerPassword);
    }
    
    /**
     * Return true if the correct admin key.
     * @param theAdminKey the admin key to check for.
     * @return true if the correct admin key.
     */
    public static boolean isAdminKey(String theAdminKey)
    {
        return adminKey.equals(theAdminKey);
    }
    
    /**
     * Get a reference to the esb object.
     * @return a direct reference to esb.
     */
    private static ESB getESB()
    {
        HttpServer httpServer = getHttpServer();
        if (httpServer != null) {
            return httpServer.getESB(adminKey);
        }
        
        return null;
    }
    
    /**
     * Get a reference to the httpserver object.
     * @return a direct reference to httpserver.
     */
    private static HttpServer getHttpServer()
    {
        return HttpServer.getHttpServer(adminKey);
    }
    
    /**
     * Return true if an enterprise service bus is running on this server.
     * @param thePassword the password for this server.
     * @return true if an ESB has already been loaded.
     */
    public boolean hasESB(String thePassword)
    {
        if (isPassword(thePassword)) {
            return (getESB() != null);
        }
        
        return false;
    }
    
    /**
     * Return true if this server is running a jar factory.
     * @param thePassword the password for this server.
     * @return true if a jar factory is installed.
     */
    public boolean hasJarFactory(String thePassword)
    {
        if (isPassword(thePassword)) {
            try {
                HttpServer httpServer = getHttpServer();
                if (httpServer != null) {
                    return httpServer.hasJarFactory(thePassword);
                }
            }
            catch (Exception ex) {}
        }
        
        return false;
    }
    
    /**
     * Return true if a service with the specified id is running on this server.
     * @param serviceID the service uuid to check for.
     * @return true if a service with that ID is running, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean serverHasService(String serviceID) throws Exception
    {
        ESB esb;                            //the service bus

        try {
            esb = getESB();
            if (esb != null) {
                return esb.hasService(serviceID);
            }
        }
        catch (Exception ex) {}
        
        return false;
    }
    
    /**
     * Return true if a service with the specified type is running on this server.
     * @param serviceType the service type to check for.
     * @return true if a service of that type is running, false otherwise.
     */
    public boolean serverHasServiceType(String serviceType)
    {
        ESB esb;                            //the service bus

        try {
            esb = getESB();
            if (esb != null) {
                return esb.hasServiceType(serviceType);
            }
        }
        catch (Exception ex) {}
        
        return false;
    }
    
    /**
     * Return true if the service id entered relates to a stored service. This relates
     * to metadata stored in the repository and so it might be a utility service or
     * a base service, so it is slightly different to the {@code serverHasService} method.
     * @param serviceID the unique service id.
     * @return true if the related service is stored on this server.
     */
    public boolean isStoredService(String serviceID)
    {
        ESB esb;                            //the service bus

        try {
            esb = getESB();
            if (esb != null) {
                return esb.isStoredService(serviceID);
            }
        }
        catch (Exception ex) {}
        
        return false;
    }
    
    /**
     * Load a jar file into a file object and return. The jar file must be stored
     * in the default services folder location. It must also be compiled into
     * a single package as no third party jar files will be loaded as well.
     * @param jarName the name of the jar file.
     * @return the created file object.
     */
    public FileObject getJarForService(String jarName)
    {
        try {
            HttpServer httpServer = getHttpServer();
            if (httpServer != null) {
                return httpServer.getJarForService(jarName);
            }
        }
        catch (Exception ex) {}
        
        return null;
    }
    
    /**
     * Return a value indicating if the static http server should be shut down.
     * @return a value if the server should be shut down.
     */
    public boolean getServerShutDown()
    {
        try {
            HttpServer httpServer = getHttpServer();
            if (httpServer != null) {
                return httpServer.getThisShutDown();
            }
        }
        catch (Exception ex) {}
        
        return false;
    }
    
    /**
     * Shut down the server and stop the request thread.
     * @param theAdminKey the unique key to protect loading/removal of the server.
     * @return true if shut down OK. 
     */
    public boolean shutDown(String theAdminKey)
    {
        if (isAdminKey(theAdminKey)) {
            try {
                HttpServer httpServer = getHttpServer();
                if (httpServer != null) {
                    return httpServer.shutDown(theAdminKey);
                }
            }
            catch (Exception ex) {}
        }
        
        return false;
    }
}
