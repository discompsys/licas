/*
 * NonBlockingListener.java
 *
 * Created on 17 September 2010
 *
 * Version 1.6.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server;


import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.StandardSocketOptions;
import java.nio.channels.*;
import java.util.concurrent.Executors;


/**
 * This class implements a listener thread for processing non-blocked (asynchronous) HTTP requests.
 * @author Kieran Greer
 */
public class NonBlockingListener extends HttpListener
{
    /** The logger */
    private static final Logger logger;


    /** Asynchronous server channel */
    private AsynchronousServerSocketChannel listener;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(NonBlockingListener.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of NonBlockingListener.
     * @param thePort the port to listen on.
     * @param theIpAddress the ip address to bind to.
     * @param theTimeOut timeout for recieving continuous message.
     * @param theServerPassword the server password.
     * @param theAdminKey the server service key.
     * @throws IOException for input/output error.
     * @throws java.lang.Exception any other error.
     */
    public NonBlockingListener(int thePort, String theIpAddress, long theTimeOut, String theServerPassword, String theAdminKey)
            throws IOException, Exception
    {
        super(thePort, theIpAddress, theTimeOut, theServerPassword, theAdminKey);
    }

    /**
     * Initialise the request listener thread.
     * @throws java.lang.Exception any other error.
     */
    public void initRequestListener() throws Exception
    {
        InetSocketAddress addr;         //socket address

        try {
            shutDown = false;
            addr = new InetSocketAddress(InetAddress.getByName(ipAddress), port);

            listener = AsynchronousServerSocketChannel.open();
            listener.setOption(StandardSocketOptions.SO_REUSEADDR, true);
            listener.bind(addr, 0);
        }
        catch (IOException ioex) {
            shutDown = true;
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "initRequestListener", "",
                    ioex);
        }
        catch (Exception ex) {
            shutDown = true;
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "initRequestListener", "",
                    ex);
        }
    }

    /**
     * Run the thread.
     */
    public void run()
    {
        AsynchronousSocketChannel channel;          //channel

        try
        {
            listenerPool = Executors.newFixedThreadPool(100);
            while (!shutDown)
            {
                if (listener == null) {
                    shutDown = true;
                }
                else if (listener.isOpen()){
                    channel = listener.accept().get();
                    if (channel != null) {
                        listenerPool.execute(new ServerConnectionAsyc(channel, timeOut,
                                new NonBlockingServerHandler(passwordHandler.getPassword(),
                                        passwordHandler.getAdminKey())));
                    } else {
                        Thread.yield();
                    }
                }
                else {
                    shutDown = true;
                }
            }
        } catch (ClosedChannelException | InterruptedException e) {
            shutDown = true;
        }
        catch (IOException e) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "run",
                    "Connection thread error", e);
        }
        catch (Exception e) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "run",
                    "Connection thread error", e);
        }
        finally {
            shutDownListenerThread();
        }
    }

    /** Close the listener down */
    protected void closeListener()
    {
        shutDown = true;
        try {
            if (listener != null) listener.close();
        }
        catch (Exception ex) {}
        finally {
            listener = null;
        }
        try {
            if (listenerPool != null) listenerPool.shutdownNow();
        }
        catch (Exception ex) {}
        finally {
            listenerPool = null;
        }
    }
}
