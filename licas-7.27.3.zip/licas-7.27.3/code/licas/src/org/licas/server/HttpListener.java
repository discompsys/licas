/*
 * HttpListener.java
 *
 * Created on 27 February 2020
 *
 * Version 1.0.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server;


import org.licas.module.ServiceModule;
import org.jlog2.Logger;
import org.jlog2.LoggerHandler;

import java.io.IOException;
import java.util.concurrent.ExecutorService;


/**
 * Base class for a listener thread for processing HTTP requests.
 * @author Kieran Greer
 */
public abstract class HttpListener extends ServiceModule
{
    /** The logger */
    private static final Logger logger;


    /** The port to listen on */
    protected int port;

    /** The IP Address to bond to */
    protected String ipAddress;

    /** Timeout for receiving continuous message */
    protected long timeOut;

    /** Thread pool */
    protected ExecutorService listenerPool;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(HttpListener.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of HttpListener.
     * @param thePort the port to listen on.
     * @param theIpAddress the ip address to bind to.
     * @param theTimeOut timeout for receiving continuous message.
     * @param theServerPassword the server password.
     * @param theAdminKey the server service key.
     * @throws Exception any other error.
     */
    public HttpListener(int thePort, String theIpAddress, long theTimeOut, String theServerPassword, String theAdminKey)
            throws Exception
    {
        super(theServerPassword, theAdminKey);
        port = thePort;
        ipAddress = theIpAddress;
        timeOut = theTimeOut;
    }

    /**
     * Initialise the request listener thread.
     * @throws IOException for input/output error.
     * @throws Exception any other error.
     */
    public abstract void initRequestListener() throws IOException, Exception;

    /** Close the listener down */
    protected abstract void closeListener();

    /**
     * Shut down the request listener thread.
     */
    public void shutDownListenerThread()
    {
        try {
            setShutDown(true);
            closeListener();
            this.interrupt(passwordHandler.getAdminKey());
        } 
        catch (Exception ex) {}
    }
}
