/*
 * BlockingListener.java
 *
 * Created on 17 September 2010
 *
 * Version 1.5.2
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server;



import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.StandardSocketOptions;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.concurrent.Executors;


/**
 * This class implements a listener thread for processing blocked (synchronous) HTTP requests.
 * @author Kieran Greer
 */
public class BlockingListener extends HttpListener
{
    /** The logger */
    private static final Logger logger;


    /** Synchronous server channel */
    protected ServerSocketChannel listener;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(BlockingListener.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of BlockingListener.
     * @param thePort the port to listen on.
     * @param theIpAddress the ip address to bind to.
     * @param theTimeOut timeout for receiving continuous message.
     * @param theServerPassword the server password.
     * @param theAdminKey the server service key.
     * @throws java.lang.Exception any other error.
     */
    public BlockingListener(int thePort, String theIpAddress, long theTimeOut, String theServerPassword, String theAdminKey)
            throws Exception
    {
        super(thePort, theIpAddress, theTimeOut, theServerPassword, theAdminKey);
    }

    /**
     * Initialise the request listener thread.
     * @throws java.lang.Exception any other error.
     */
    public void initRequestListener() throws Exception
    {
        InetSocketAddress addr;         //socket address

        try {
            shutDown = false;
            addr = new InetSocketAddress(InetAddress.getByName(ipAddress), port);

            listener = ServerSocketChannel.open();
            listener.configureBlocking(true);
            listener.setOption(StandardSocketOptions.SO_REUSEADDR, true);
            listener.bind(addr, 0);
        }
        catch (IOException ioex) {
            shutDown = true;
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "initRequestListener", "",
                    ioex);
        }
        catch (Exception ex) {
            shutDown = true;
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "initRequestListener", "",
                    ex);
        }
    }

    /**
     * Run the thread.
     */
    public void run()
    {
        SocketChannel channel;                      //channel

        try {
            listenerPool = Executors.newFixedThreadPool(100);
            while (!shutDown)
            {
                if (listener == null) {
                    shutDown = true;
                }
                else if (listener.isOpen()) {
                    channel = listener.accept();

                    if (channel != null) {
                        listenerPool.execute(new ServerConnectionBlock(channel, timeOut,
                                new BlockingServerHandler(passwordHandler.getPassword(),
                                        passwordHandler.getAdminKey())));
                    }
                    else {
                        Thread.yield();
                    }
                }
                else {
                    shutDown = true;
                }
            }
        }
        catch (ClosedChannelException cle) {
            shutDown = true;
        }
        catch (IOException e) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "run",
                    "Connection thread error", e);
        }
        catch (Exception e) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "run",
                    "Connection thread error", e);
        }
        finally {
            shutDownListenerThread();
        }
    }

    /** Close the listener down */
    protected void closeListener()
    {
        shutDown = true;
        try {
            if (listener != null) listener.close();
        }
        catch (Exception ex) {}
        finally {
            listener = null;
        }
        try {
            if (listenerPool != null) listenerPool.shutdownNow();
        }
        catch (Exception ex) {}
        finally {
            listenerPool = null;
        }
    }
}
