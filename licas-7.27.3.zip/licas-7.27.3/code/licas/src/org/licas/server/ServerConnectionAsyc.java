/*
 * ServerListenerAsync.java
 *
 * Created on 26 February 2020
 *
 * Version 1.1.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server;


import org.jlog2.exception.ExceptionHandler;
import org.licas.server.model.HttpEntity;
import org.jlog2.*;

import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.licas.parsers.Parsers;
import org.licas.util.Const;

/**
 * This class handles a single HTTP non-blocking (asynchronous) transaction on a separate thread.
 * It uses a {@code Channel} to pass information and a {@link ServerHandler} to process the message.
 * Asynchronous is recognised by a {@code void} return type and runs on port '(blocking server port + 1)'.
 */
public class ServerConnectionAsyc extends ServerConnection {

    /** For logging */
    private static final Logger logger;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ServerConnectionAsyc.class.getName());
        logger.setDebug(false);
    }


    /**
     * Create a new instance of ServerListenerAsync.
     * @param theChannel the listener channel.
     * @param timeOut timeout for receiving continuous message.
     * @param serverHandler the server handler that processes the message.
     * @throws java.lang.Exception any error.
     */
    public ServerConnectionAsyc(AsynchronousSocketChannel theChannel, long timeOut, ServerHandler serverHandler) throws Exception
    {
        super(theChannel, timeOut, serverHandler);
    }

    /** Start the message processing */
    public void run()
    {
        boolean reading;                            //true while reading
        int numBytes;                               //message part size
        byte[] lineBytes;                           //bytes for a line
        String line;                                //message line
        StringBuilder message;                      //full message
        Future<Integer> bytesRead;                  //number of bytes read
        ByteBuffer readBuffer;                      //buffer for request
        ByteBuffer writeBuffer;                     //buffer for reply
        HttpEntity request;                         //client request
        HttpEntity response;                        //server response

        try {
            //read the client message
            readBuffer = ByteBuffer.allocate(Const.BUFFERSIZE);
            bytesRead = ((AsynchronousSocketChannel)channel).read(readBuffer);
            numBytes = bytesRead.get();

            reading = true;
            message = new StringBuilder();
            while((numBytes != -1) && reading)
            {
                // Make sure that we have data to read
                if(readBuffer.position() > 2) {
                    //make the buffer ready to write
                    readBuffer.flip();

                    //convert the buffer into a line
                    lineBytes = new byte[numBytes];
                    readBuffer.get(lineBytes, 0, numBytes);
                    line = new String(lineBytes);
                    message.append(line);

                    //make the buffer ready to read
                    readBuffer.compact();

                    //read the next line
                    bytesRead = ((AsynchronousSocketChannel)channel).read(readBuffer);
                    numBytes = bytesRead.get(10000, TimeUnit.MILLISECONDS);
                }
                else {
                    // An empty line signifies the end of the conversation in our protocol
                    reading = false;
                }
            }

            //process the message in a handler
            try {
                if (!message.toString().equals("")) {
                    //decode and convert the string into a http entity
                    request = convertRequest(message.toString());

                    //requestStr = message.substring(message.indexOf(ElementImpl.class.getName())).trim();
                    //request = (HttpEntity) Parsers.parse(requestStr);

                    //blocking handler requires a response
                    //non-blocking just processes the message
                    if (serverHandler.isBlocking()) {
                        //write the reply back to the client
                        response = serverHandler.handle(request);
                        if (response != null) {
                            message = new StringBuilder((httpHeaders(response) + Parsers.serializeToString(response)));

                            //make buffer ready to write
                            writeBuffer = ByteBuffer.wrap(message.toString().getBytes());
                            ((AsynchronousSocketChannel)channel).write(writeBuffer);
                            writeBuffer.get();
                        }
                    }
                    else {
                        serverHandler.handle(request);
                    }
                }
            }
            catch (Exception ex) {
                response = null;
            }
        }
        catch (InterruptedException | ExecutionException | TimeoutException inex) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "run",
                    "", inex);
        }
        catch (Exception ex) {
            ExceptionHandler.handleException(logger, LoggerHandler.WARN, "run",
                    "", ex);
        }
        finally {
            if (channel != null) {
                try {
                    ((AsynchronousSocketChannel)channel).shutdownInput();
                }
                catch (Exception ex) {}

                try {
                    ((AsynchronousSocketChannel)channel).shutdownOutput();
                }
                catch (Exception ex) {}

                try {
                    channel.close();
                }
                catch (Exception ex) {}

                channel = null;
            }
        }
    }
}
