/*
 * ServerAddress.java
 *
 * Created on 17 September 2010
 *
 * Version 1.4
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server.model;


import org.licas.call.Handle;
import org.licas_internet.util.HttpConst;
import org.licas_xml.abs.Element;
import org.licas_xml.model.XmlHandler;

import java.net.*;
import java.util.ArrayList;
import java.util.Enumeration;


/**
 * This stores and processes URI or IP addresses for a server object.
 * @author Kieran Greer
 */
public class ServerAddress
{
    /** The port the server is listening on */
    private int port;
    
    /** Can be either HttpConst.HTTP or httpType */
    private String httpType;

    /** The URL address of the server */
    private Element urlAddress;

    /** The alternative URL addresses */
    private ArrayList<Element> urlAddresses;

    /**
     * Create a new instance of ServerAddress.
     * @param theIpAddress the IP address to start the server on.
     * @param thePort the port to run on.
     * @param asHttps true if add as an https address and not an http address.
     * @throws java.lang.Exception any error.
     */
    public ServerAddress(String theIpAddress, int thePort, boolean asHttps) throws Exception
    {
        initialise(theIpAddress, thePort, asHttps);
    }
    
    /**
     * Initialise some values.
     * @param theIpAddress the IP address to start the server on.
     * @param thePort the port to run on.
     * @param asHttps true if add as an https address and not an http address.
     * @throws java.lang.Exception any error.
     */
    private void initialise(String theIpAddress, int thePort, boolean asHttps) throws Exception
    {
        int i;
        String nextAddress;                 //next address
        String hostAddress;                 //host address
        ArrayList<String> otherAddresses;   //other addresses
        InetAddress hostInet;               //local host address
        
        port = thePort;
        urlAddresses = new ArrayList<>();
        if (asHttps) httpType = HttpConst.HTTPS;
        else httpType = HttpConst.HTTP;
        
        if (theIpAddress != null) {
            hostAddress = httpType + theIpAddress + ":" + port;
            urlAddress = Handle.createNewUrlHandle(hostAddress);
            urlAddresses.add(urlAddress);
            hostAddress = theIpAddress;
        }
        else
        {
            hostInet = getLocalHost4Address();
            hostAddress = httpType + hostInet.getHostAddress() + ":" + port;
            urlAddress = Handle.createNewUrlHandle(hostAddress);
            urlAddresses.add(urlAddress);
            hostAddress = hostInet.getHostAddress();
        }

        otherAddresses = ips(hostAddress);
        for (i = 0; i < otherAddresses.size(); i++)
        {
            nextAddress = otherAddresses.get(i);
            if (!nextAddress.equals(hostAddress)) {
                nextAddress = httpType + nextAddress + ":" + port;
                urlAddress = Handle.createNewUrlHandle(nextAddress);
                urlAddresses.add(urlAddress);
            }
        }     
    }

    /**
     * Return true if the IP address represents a local server.
     * @param theIPAddress the IP address to compare. Note ip not url address.
     * @return true if a local urlAddress.
     * @throws java.lang.Exception any error.
     */
    public boolean isLocalIPAddress(String theIPAddress) throws Exception
    {
        return checkAddress(theIPAddress, port);
    }

    /**
     * Return true if the IP address and port compares to the address the server is running on.
     * @param host the host address. Can include 'localhost' or '127.0.0.1'.
     * @param port the port.
     * @return true if the whole address agrees with the server address.
     * @throws java.lang.Exception any error.
     */
    public boolean checkAddress(String host, int port) throws Exception
    {
        int i;
        boolean matches = false;                //true if matches
        String thisAddress;                     //this address
        String nextAddress;                     //next address

        if (HttpConst.startsWithHttp(host)) thisAddress = host;
        else thisAddress = httpType + host + ":" + port;        
        thisAddress = XmlHandler.xmlToString(Handle.createNewUrlHandle(thisAddress));

        for (i = 0; i < urlAddresses.size(); i++)
        {
            nextAddress = XmlHandler.xmlToString(urlAddresses.get(i));
            if (nextAddress.equals(thisAddress)) {
                matches = true;
                break;
            }
        }

        return matches;
    }

    /**
     * Return the URL address of the static HTTP server.
     * @return the value of urlAddress.
     */
    public String getUrlAddress()
    {
        return Handle.getURL(urlAddress);
    }

    /**
     * This code is third-party from the Internet.
     * Returns an <code>InetAddress</code> object encapsulating what is most
     * likely the machine's LAN IP address.
     * This has been changed to return an ipV4 address only. For any other type
     * you should include the address in startup script.
     * <p>
     * This method is intended for use as a replacement of JDK method
     * <code>InetAddress.getLocalHost</code>, because that method is ambiguous
     * on Linux systems. Linux systems enumerate the loopback network interface
     * the same way as regular LAN network interfaces, but the JDK
     * <code>InetAddress.getLocalHost</code> method does not specify the
     * algorithm used to select the address returned under such circumstances,
     * and will often return the loopback address, which is not valid for
     * network communication. Details
     * <a href="http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4665037">here</a>.
     * <p>
     * This method will scan all IP addresses on all network interfaces on the
     * host machine to determine the IP address most likely to be the machine's
     * LAN address. If the machine has multiple IP addresses, this method will
     * prefer a site-local IP address (e.g. 192.168.x.x or 10.10.x.x, usually
     * IPv4) if the machine has one (and will return the first site-local
     * address if the machine has more than one), but if the machine does not
     * hold a site-local address, this method will return simply the first
     * non-loopback address found (IPv4 or IPv6).
     * <p>
     * If this method cannot find a non-loopback address using this selection
     * algorithm, it will fall back to calling and returning the result of JDK
     * method <code>InetAddress.getLocalHost</code>.
     * <p>
     * @return the first suitable match for a local host address (127.0.0.1).
     * @throws UnknownHostException If the LAN address of the machine cannot be
     * found.
     */
    public static InetAddress getLocalHost4Address() throws UnknownHostException
    {
        NetworkInterface iface;                 //network interface
        InetAddress inetAddr;                   //net address
        InetAddress loopbackAddress;            //local loopback address
        InetAddress candidateAddress;           //candidate address

        try {
            candidateAddress = null;
            loopbackAddress = null;

            // Iterate all NICs (network interface cards)...
            for (Enumeration<NetworkInterface> ifaces = NetworkInterface.getNetworkInterfaces(); ifaces.hasMoreElements();)
            {
                iface = ifaces.nextElement();

                // Iterate all IP addresses assigned to each card...
                for (Enumeration<InetAddress> inetAddrs = iface.getInetAddresses(); inetAddrs.hasMoreElements();)
                {
                    inetAddr = inetAddrs.nextElement();

                    if (inetAddr instanceof Inet4Address) {
                        if (inetAddr.isLoopbackAddress()) {
                            loopbackAddress = inetAddr;
                        }
                        else {
                            if (inetAddr.isSiteLocalAddress()) {
                                // Found non-loopback site-local address. Return it immediately...
                                return inetAddr;
                            }
                            else if (candidateAddress == null) {
                                // Found non-loopback address, but not necessarily site-local.
                                // Store it as a candidate to be returned if site-local address is not subsequently found...
                                candidateAddress = inetAddr;
                                // Note that we don't repeatedly assign non-loopback non-site-local addresses as candidates,
                                // only the first. For subsequent iterations, candidate will be non-null.
                            }
                        }
                    }
                }
            }

            if (candidateAddress != null) {
                // We did not find a site-local address, but we found some other non-loopback address.
                // Server might have a non-site-local address assigned to its NIC (or it might be running
                // IPv6 which deprecates the "site-local" concept).
                // Return this non-loopback candidate address...
                return candidateAddress;
            }
            else if (loopbackAddress != null) {
                return loopbackAddress;
            }

            // At this point, we did not find a non-loopback address.
            // Fall back to returning whatever InetAddress.getLocalHost() returns...
            InetAddress jdkSuppliedAddress = InetAddress.getLocalHost();
            if (jdkSuppliedAddress == null) {
                throw new UnknownHostException("The JDK InetAddress.getLocalHost() method unexpectedly returned null.");
            }

            return jdkSuppliedAddress;
        } 
        catch (Exception e) {
            UnknownHostException unknownHostException = new UnknownHostException("Failed to determine LAN address: " + e);
            unknownHostException.initCause(e);
            throw unknownHostException;
        }
    }
   
    /**
     * Retrieve a list of alternative ip addresses (127.0.0.1) for the local computer.
     * @param hostAddress the current ip adress that the host is running on.
     * Can be null.
     * @return a list of alternative addresses for this computer/server.
     * @throws SocketException network interface exception.
     */
    public static ArrayList<String> ips(String hostAddress) throws SocketException
    {
        String nextAddress;                     //next address
        ArrayList<String> ipAddresses;          //list of ip addresses
        
        ipAddresses = new ArrayList<>();
        Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
        while (interfaces.hasMoreElements()) 
        {
            NetworkInterface interf = interfaces.nextElement();
            Enumeration<InetAddress> inaddresses = interf.getInetAddresses();

            while (inaddresses.hasMoreElements()) 
            {
                InetAddress inet = inaddresses.nextElement();
                if ((inet.getAddress().length == 4)) {
                    if (!inet.isLoopbackAddress()) {
                        nextAddress = inet.getHostAddress();
                        if ((hostAddress == null) || !nextAddress.equals(hostAddress)) {
                            ipAddresses.add(inet.getHostAddress());
                        }
                    }
                }
            }
        }
        
        return ipAddresses;
    }
}
