/*
 * ServerConfig.java
 *
 * Created on 27 September 2014
 *
 * Version 1.0
 *
 * Copyright (C) Kieran Greer
 */

package org.licas.server.model;


import org.licas.util.Const;


/**
 * This stores information relating to a server setup.
 * @author Kieran Greer
 */
public class ServerConfig 
{
    /** The port to start the local server running on */
    private int serverPort;
    
    /** The server ip address */
    private String serverIP;
    
    /** The password for the local server */
    private String serverPassword;
    
    /** The admin key for the local server */
    private String serverAdminKey;
    
    /** Any contact details for the server administrator */
    private String serverContact;
    
    /** If true, cannot access the server without knowing the password first. Default is false. */
    private boolean passwordsRequired;
    
    /** If true, use the https protocol, if false use http. Default is false. */
    private boolean asHttps;
    
    
    /** Create a new instance of ServerConfig */
    public ServerConfig()
    {
        initialise();
    }
    
    /** Initialise some values */
    private void initialise()
    {
        serverPort = 8888;
        serverIP = null;
        serverPassword = Const.ANON;
        serverAdminKey = Const.ANON;
        serverContact = null;
        passwordsRequired = false;
        asHttps = false;
    }
    
    /**
     * Set the port number to run the gui server on.
     * @param theServerPort the port number.
     */
    public void setServerPort(int theServerPort)
    {
        serverPort = theServerPort;
    }
    
    /**
     * Get the port number to run the gui server on.
     * @return the value of serverPort.
     */
    public int getServerPort()
    {
        return serverPort;
    }
    
    /**
     * Set the server ip address.
     * @param theServerIP the server ip address.
     */
    public void setServerIP(String theServerIP)
    {
        serverIP = theServerIP;
    }
    
    /**
     * Get the server ip address.
     * @return the value of serverIP.
     */
    public String getServerIP()
    {
        return serverIP;
    }
    
    /**
     * Set the password for the server method invocation.
     * @param theServerPassword the server password.
     */
    public void setServerPassword(String theServerPassword)
    {
        serverPassword = theServerPassword;
    }
    
    /**
     * Get the password for the server method invocation.
     * @return the value of serverPassword.
     */
    public String getServerPassword()
    {
        return serverPassword;
    }
    
    /**
     * Set the key for server admin changes.
     * @param theServerAdminKey the server admin key.
     */
    public void setServerAdminKey(String theServerAdminKey)
    {
        serverAdminKey = theServerAdminKey;
    }
    
    /**
     * Get the key for server admin changes.
     * @return the value of serverAdminKey.
     */
    public String getServerAdminKey()
    {
        return serverAdminKey;
    }
    
    /**
     * Set the contact details for the server adminisrator.
     * @param theServerContact the administrator contact details.
     */
    public void setServerContact(String theServerContact)
    {
        serverContact = theServerContact;
    }
    
    /**
     * Get the contact details for the server administrator.
     * @return the value of serverContact.
     */
    public String getServerContact()
    {
        return serverContact;
    }
    
    /**
     * Set the passwords required value.
     * @param thisPasswordsRequired if true the server requires the passwords.
     */
    public void setPasswordsRequired(boolean thisPasswordsRequired)
    {
        passwordsRequired = thisPasswordsRequired;
    }
    
    /**
     * Get the passwords required value.
     * @return the value of passwordsRequired.
     */
    public boolean getPasswordsRequired()
    {
        return passwordsRequired;
    }
    
    /**
     * Set the https protocol value.
     * @param thisAsHttps if true for the https protocol, false for http.
     */
    public void setAsHttps(boolean thisAsHttps)
    {
        asHttps = thisAsHttps;
    }
    
    /**
     * Get the https protocol value.
     * @return the value of asHttps.
     */
    public boolean getAsHttps()
    {
        return asHttps;
    }
}
