/*
 * ESB.java
 *
 * Created on 12 February 2007
 *
 * Version 1.21.2
 *
 * Copyright (c) Kieran Greer.
 */

package org.licas.server;


import org.licas.*;
import org.licas.autonomic.*;
import org.licas.call.*;
import org.licas.def.*;
import org.licas.meta.*;
import org.licas.module.*;
import org.licas.parsers.Parsers;
import org.licas.parsers.admin.ServiceMetaParser;
import org.licas.parsers.network.*;
import org.licas.query.*;
import org.licas.security.*;
import org.licas.server.model.PacketMessages;
import org.licas.service.link.Link_NM;
import org.licas.service.model.*;
import org.licas.util.*;
import org.licas.util.classloader.LoadObject;
import org.licas.util.exception.*;
import org.jlog2.*;
import org.jlog2.exception.ExceptionHandler;
import org.jlog2.util.*;

import org.licas_text.def.QueryDef;
import org.licas_xml.abs.Element;
import org.licas_xml.abs.Node;
import org.licas_xml.abs.XMLFactory;
import org.licas_xml.model.XmlHandler;

import java.io.File;
import java.util.*;


/**
 * This is a base class that acts as a lightweight server manager for the loaded services.
 * This is based on an {@code Enterprise Service Bus}, to put it in the context of an SOA architecture.
 * It is derived from a {@link Service} class and so uses all of those methods. In addition,
 * it has new methods for searching over service metadata and managing the method invocation calls.
 * <p>
 * This is stored as a service on an {@link HttpServer} and anything loaded onto the licas server
 * actually gets stored here. This class therefore controls service creation and making method 
 * invocations on them. This class also stores the metadata descriptions in a {@link ServerMetadata} repository. 
 * Remote communications are sent to the HttpServer class through an HTTP protocol that then 
 * passes these onto this class for processing. The HttpServer however still has some methods 
 * that can be queried for server-only requests.
 * <p>
 * Any service that is loaded and registered here is a base service. All services are 
 * contained in a wrapper first, where any {@link Auto}-derived service loaded here is contained by 
 * an {@link AutonomicManager} wrapper. Any non Auto-derived service or any service loaded to
 * some other component does not have an Autonomic Manager, but is wrapped by a {@link ServiceWrapper}
 * instead. As well as the functionality, these extra wrappers provide some levels of security.
 * @author Kieran Greer.
 */
public class ESB extends AutoSecure implements BusDef, PublishSubscribeDef
{
    /** The logger */
    private static final Logger logger;
    
    /** Fault communication id */
    protected static String commFault = MetaFactory.getFactoryService().asFaultComm(Const.HTTPSERVER);
    
    /**
     * The uuids of services that are root nodes in a hierarchical network.
     */
    protected ArrayList<String> rootNodes;
    
    /**
     * List of global services that can be called by any other service and are
     * controlled by the server. Key is the service type and value is a list of service UUIDs.
     */
    protected HashMap<String, ArrayList<String>> serverServices;

    /**
     * A list of services that cannot be accessed because permission is blocked.
     */
    protected ArrayList<String> blockedServices;

    /**
     * Server metrics.
     */
    protected Metrics metrics;


    /**
     * This class mediates the process of passing messages between the server and the services.
     */
    protected MessageMediator messageMediator;

    /**
     * Server utilities manager.
     */
    protected UtilsManagerDef utilsManager;

    /**
     * Metadata repository for registered services.
     */
    protected ServerMetadata serverMetadata;
    
    /**
     * Metadata search facility over the registered services, based on XML pattern matching.
     */
    protected ServerMetaSearch serverMetaSearch;
    
    /**
     * Text document search facility over the allowed folders.
     */
    protected LicasDocSearch licasDocSearch;
    
    /**
     * Stats search facility over the loaded services. 
     * This is based on accumulated stats produced by the autonomic managers.
     */
    protected AutoMetaSearch autoMetaSearch;

    /**
     * Stores communication ids with related message packet info for receiving
     * messages in packets. Keys are the communication ids of type String, while
     * values are the PacketInfo objects.
     */
    protected PacketMessages messagePackets;

    /**
     * Base http server.
     */
    protected HttpServer httpBase;


    static
    {
        // get the logger
        logger = LoggerHandler.getLogger(ESB.class.getName());
        logger.setDebug(true);
    }


    /**
     * Creates a new instance of ESB.
     * @param password the password to access the server with.
     * @param thisAdminKey a unique key to protect loading/removal.
     * @throws java.lang.Exception any error.
     */
    public ESB(String password, String thisAdminKey) throws Exception
    {
        super(password, thisAdminKey);
        initialise();
    }
    
    /** 
     * Creates a new instance of ESB.
     * @param thisPassword the component password.
     * @param thisAdminKey the unique service key.
     * @param adminXml the admin info or description of this service.
     * @throws java.lang.Exception any error.
     */
    public ESB(String thisPassword, String thisAdminKey, Element adminXml)
            throws Exception
    {
        super(thisPassword, thisAdminKey, adminXml);        
        initialise();
    }
    
    /** 
     * Creates a new instance of ESB.
     * @param thisPassword the component password.
     * @param thisAdminKey the unique service key.
     * @param adminXml the admin info or description of this service.
     * @param resManClass the class type for the resource manager. No constructor parameters and
     * jar file must be available.
     * @throws java.lang.Exception any error.
     */
    public ESB(String thisPassword, String thisAdminKey, Element adminXml, String resManClass)
            throws Exception
    {
        super(thisPassword, thisAdminKey, adminXml);        
        initialise();
        
        //load in the new resource manager
        utilsManager = (UtilsManagerDef)LoadObject.loadObject(new ArrayList<>(), resManClass, new ArrayList<>());
    }
    
    /**
     * Initialise some values
     * @throws java.lang.Exception any error.
     */
    private void initialise() throws Exception
    {
        MessageInfo messageInfo;                    //the new message
            
        try
        {
            setServiceGrade(Const.SERVER);
            sleepTime = (TimeConst.MILLISECOND * 10);
            httpBase = null;
            metrics = null;

            blockedServices = new ArrayList<>();
            rootNodes = new ArrayList<>();
            resetServerServices();

            utilsManager = new UtilsManager();
            messagePackets = new PacketMessages();
            serverMetadata = new ServerMetadata();
            serverMetaSearch = new ServerMetaSearch(this, passwordHandler);
            autoMetaSearch = new AutoMetaSearch(this, passwordHandler);
            licasDocSearch = new LicasDocSearch(this, passwordHandler);

            //setup the autonomic manager for fault monitoring                
            if (autoManager != null)
            {
                //pass whole new tree each time
                autoManager.getMessageQueue(passwordHandler.getAdminKey()).removeAllMessages(commFault);

                //to register the fault comm id
                messageInfo = new MessageInfo(commFault, null);
                autoManager.monitor(messageInfo, passwordHandler.getAdminKey());
            }

            //initialise and start the message mediator, to process the message bus queue
            messageMediator = new MessageMediator(this, passwordHandler, messageStore);
            messageMediator.start();
        }
        catch (Exception ex)
        {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "initialise", null, ex);
        }
    }

    /**
     * Return true if this module is a base server module.
     * @return true in this case.
     */
    public boolean isServer()
    {
        return true;
    }

    /**
     * Periodically run some server utility functions to monitor the system state.
     * @param messageInfo the message to evaluate.
     * @return null in this case, as this is only a periodic monitoring check.
     * @throws java.lang.Exception any error.
     */
    protected MessageInfo behaviourAction(MessageInfo messageInfo) throws Exception
    {
        FaultDetails faultDetails;                  //fault details

        try {
            //check the temporary file list in the web folder and delete any out of date
            synchronized(Monitor.getMonitor().getSyncOn())
            {
                utilsManager.webFolder(TimeConst.MILLIDAY);
            }

            //Send the fault tree message to the auto manager to pass through the monitor loop.
            //Note that the auto manager also needs to perform any resulting actions,
            //as defined by a script, but the default setup is an empty loop with no action taken.
            messageInfo = autoManager.getNextMessage(passwordHandler.getAdminKey(), true);
            if (messageInfo != null) {
                autoManager.monitor(messageInfo, passwordHandler.getAdminKey());
            }
        }
        catch (Exception ex) {
            //add to fault queue list for processing
            faultDetails = new FaultDetails(MetaConst.SERVERFAULT, ex.getMessage());
            httpBase.notifyOfFault(faultDetails, passwordHandler.getAdminKey());
        }

        return null;
    }

    /**
     * Set the base http server.
     * @param thisHttpBase the http server.
     * @throws java.lang.Exception any error.
     */
    protected void setServer(HttpServer thisHttpBase) throws Exception
    {
        if (httpBase == null) {
            httpBase = thisHttpBase;
            service = null;
        }
        
        //also set password for local server URI, so stored both as ESB and URI passwords
        passwordHandler.addServicePassword(LocalServer.getServerHandle(), passwordHandler.getPassword());
        passwordHandler.addAdminKey(LocalServer.getServerHandle(), passwordHandler.getAdminKey());
    }
    
    /**
     * Reset the server services list to the initial state.
     */
    private void resetServerServices()
    {
        int i;
        String searchType;                          //default search type
        ArrayList<String> searchTypes;              //list of search types
        
        serverServices = new HashMap<>();
        
        searchTypes = ServiceConst.getServerServiceTypes();
        for (i = 0; i < searchTypes.size(); i++)
        {
            searchType = searchTypes.get(i);
            serverServices.put(searchType, new ArrayList<>());
        }
    }
    
    /**
     * Reset the server services, but only remove info for the specified types.
     * @param serviceTypes list of service types to remove info for.
     */
    private void resetServerServices(ArrayList<String> serviceTypes)
    {
        int i;
        String nextServiceType;                     //next service type
        
        for (i = 0; i < serviceTypes.size(); i++)
        {
            nextServiceType = serviceTypes.get(i);
            serverServices.remove(nextServiceType);
        }
    }

    /**
     * Add the message to the message bus queue for subsequent processing.
     * @param ro the request object to add.
     * @param adminKey the server admin key.
     * @return true if added, false otherwise.
     */
    protected boolean messageToBus(MessageInfo ro, String adminKey) {
        if (passwordHandler.isAdminKey(adminKey)) {
            return messageMediator.messageToBus(ro);
        }

        return false;
    }

    /**
     * Remove the message with the specified ticket number from the queue.
     * @param ticket unique ticket number, equivalent to a communication ID.
     * @param adminKey the server admin key.
     * @return true if cancelled, false otherwise.
     */
    public boolean cancelMessage(String ticket, String adminKey) {
        if (passwordHandler.isAdminKey(adminKey)) {
            messageMediator.cancelMessage(ticket);
            return true;
        }

        return false;
    }

    /**
     * Add metric or stat values for the message object.
     * @param messageInfo the message info with the message object.
     * @param thePassword the service password.
     * @throws java.lang.Exception any error.
     */
    protected void addMessageMetrics(MethodInfo messageInfo, String thePassword)
            throws Exception
    {
        String serviceID;                               //service id
        Object serviceURI;                              //service reference
        ServiceWrapperDef aWrapper;                     //service wrapper

        if (passwordHandler.isPassword(thePassword)) {
            serviceURI = messageInfo.getServiceURI();
            if (ObjectHandler.isElement(serviceURI)) {
                serviceID = Handle.getFirstServiceHandle((Element)serviceURI);

                if (serviceID.equals(Const.HTTPSERVER)) {
                    if (metrics == null) {
                        metrics = Metrics.createMetrics(this);
                    }
                    metrics.addMetrics(messageInfo);
                }
                else {
                    aWrapper = getService(serviceID, thePassword);
                    aWrapper.addMetrics(messageInfo, passwordHandler.getAdminKey(serviceID));
                }
            }
            else if (ModuleHandler.isService(serviceURI)) {
                ServiceComm.addMessageMetrics(messageInfo, thePassword, (Service)serviceURI);
            }
            else if (ModuleHandler.isWrapper(serviceURI)) {
                ServiceComm.addMessageMetrics(messageInfo, thePassword, (ServiceWrapperDef)serviceURI);
            }
        }
    }
    
    /**
     * Add the fault tree to the autonomic manager queue for processing.
     * Remove the existing message if it exists, so there is no repeat.
     * @param message the whole fault tree.
     * @throws java.lang.Exception any error.
     */
    protected void autoManFault(Link_NM message) throws Exception
    {
        MessageInfo messageInfo;                    //the new message
                
        if (autoManager != null) {
            //pass whole new tree each time
            autoManager.getMessageQueue(passwordHandler.getAdminKey()).removeAllMessages(commFault);
            
            //register the tree as a message to process
            messageInfo = new MessageInfo(commFault, message);
            messageInfo.setTimeStamp();
            messageInfo.setServiceState(getServiceState(passwordHandler.getAdminKey()));
            autoManager.addMessage(messageInfo, passwordHandler.getAdminKey());
        }
    }
    
    /**
     * Get the stats for all services.
     * @param adminKey the admin key of this server.
     * @return list of stats objects, one for each service, key is service id.
     */
    public HashMap<String, Metrics> allServiceMetrics(String adminKey)
    {
        int i;
        String serviceID;                           //next service id
        HashMap<String, Metrics> allMetrics;        //all metrics list
        Metrics nextMetric;                         //next metric
        
        allMetrics = new HashMap<>();
        if (passwordHandler.getAdminKey().equals(adminKey)) {
            allMetrics.put(Const.HTTPSERVER, metrics);

            for (i = 0; i < getServiceNames().size(); i++) {
                serviceID = getServiceNames().get(i);

                try {
                    nextMetric = serviceMetrics(serviceID, adminKey);

                    if (nextMetric != null) {
                        allMetrics.put(serviceID, nextMetric);
                    }
                }
                catch (Exception ex)
                {}
            }
        }
        
        return allMetrics;
    }
    
    /**
     * Get the stats for the specified service.
     * @param serviceID the id of the service to retrieve the stats for.
     * @param serverAdminKey the admin key of this server.
     * @return the stats object.
     * @throws PasswordException incorrect admin key.
     * @throws ServiceException service processing error.
     * @throws java.lang.Exception any other error.
     */
    public Metrics serviceMetrics(String serviceID, String serverAdminKey)
            throws PasswordException, ServiceException, Exception
    {
        ServiceWrapperDef serviceWrapper;              //service wrapper
        
        //the server is by right allowed this default information
        if (passwordHandler.getAdminKey().equals(serverAdminKey)) {
            serviceWrapper = getService(serviceID, passwordHandler.getServicePassword(serviceID));
            if (serviceWrapper != null) return serviceWrapper.getMetrics();
        }
        
        return null;
    }
    
    /**
     * Return true if the service is blocked from access.
     * @param serviceID the uuid of the service to check.
     * @return true if blocked from access, false otherwise.
     */
    protected boolean isBlockedService(String serviceID)
    {
        return blockedServices.contains(serviceID);
    }
    
    /**
     * Block the service from being accessed. This only applies to a service
     * running directly on the server.
     * @param serviceUuid the uuid of the service to block.
     * @param adminKey the unique admin key for the service.
     * @return true if blocked, false otherwise.
     * @throws PasswordException incorrect admin key.
     */
    public boolean blockService(String serviceUuid, String adminKey) throws PasswordException
    {
        if (passwordHandler.hasAdminKey(serviceUuid) &&
            passwordHandler.getAdminKey(serviceUuid).equals(adminKey)) {
            if (!blockedServices.contains(serviceUuid)) blockedServices.add(serviceUuid);
            return true;
        }
        
        return false;
    }
    
    /**
     * Unblock the service to re-allow access. This only applies to a service
     * running directly on the server.
     * @param serviceUuid the uuid of the service to unblock.
     * @param adminKey the unique admin key for the service.
     * @return true if unblocked, false otherwise.
     * @throws PasswordException incorrect admin key.
     */
    public boolean unblockService(String serviceUuid, String adminKey) throws PasswordException
    {
        if (passwordHandler.hasAdminKey(serviceUuid) &&
            passwordHandler.getAdminKey(serviceUuid).equals(adminKey)) {
            blockedServices.remove(serviceUuid);
            return true;
        }
        
        return false;
    }

    /**
     * Create a service wrapper for storing the service object. This version returns an
     * autonomic manager if the service object is derived from {@link Auto}, or a service
     * wrapper if it is not. Only base services added to the server can be wrapped with an
     * autonomic manager and then only if they also implement the auto logic. There is a default
     * {@link AutonomicManagerDefault} class with empty monitoring modules, or you can declare
     * a different autonomic manager in your admin document and load those classes instead.
     * @param serviceObj the service object that is wrapped and managed.
     * @param serviceName the name of the service.
     * @param serviceType the type of the service.
     * @param jarFiles the jar files for a remote loading. Values are jar paths
     * of type String.
     * @param adminXml an admin document describing the service wrapper. This is
     * probably empty, but it can declare different manager classes, config or policy scripts,
     * for example.
     * @return the correct service wrapper type.
     * @throws java.lang.Exception any error.
     */
    protected ServiceWrapperDef createServiceWrapper(Object serviceObj, String serviceName,
        String serviceType, ArrayList<String> jarFiles, Element adminXml) throws Exception
    {
        if (ModuleHandler.isAuto(serviceObj)) {
            return httpBase.createServiceWrapper((Auto) serviceObj,
                    serviceName, serviceType, jarFiles, adminXml);
        }
        else {
            return super.createServiceWrapper(serviceObj,
                    serviceName, serviceType, jarFiles, adminXml);
        }
    }
    
    /**
     * Return the service wrapper for the related service name.
     * This method requires the admin key as well, but then returns a direct reference
     * to the wrapper only. Some methods may be executed on the wrapper and not the service.
     * @param serviceName the name of the service you want to retrieve.
     * @param thePassword the password to access the service you want to retrieve.
     * @param adminKey the admin key for the service you want to retrieve.
     * @return the service object if it exists or null if it does not.
     * @throws org.licas.util.exception.ServiceException for service specific error.
     * @throws java.lang.Exception any other error.
     */
    protected ServiceWrapperDef getServiceWrapper(String serviceName, String thePassword, String adminKey)
        throws ServiceException, Exception
    {
        ServiceWrapperDef aWrapper = null;          //service wrapper
        
        if (passwordHandler.hasAdminKey(serviceName)) {
            if (passwordHandler.getAdminKey(serviceName).equals(adminKey)) {
                aWrapper = getService(serviceName, thePassword);
            }
        }

        return aWrapper;
    }
    
    /**
     * Remove all components of the network currently running on this server.
     * @param adminKey the service key for this server.
     * @throws java.lang.Exception any error.
     */
    public void clearNetwork(String adminKey) throws Exception
    {
        int i;
        String nextKey;                             //next key
        ArrayList<String> allKeys;                  //all keys
        Service nextService;                        //next service
        

        if (passwordHandler.getAdminKey().equals(adminKey)) {
            allKeys = getServiceNames();
            for (i = 0; i < allKeys.size(); i++)
            {
                nextKey = allKeys.get(i);
                nextService = (Service)getServiceOrWrapper(nextKey, passwordHandler.getServicePassword(nextKey),
                        passwordHandler.getAdminKey(nextKey));

                nextService.clearServices(passwordHandler.getAdminKey(nextKey));
                nextService.setShutDown(true, passwordHandler.getAdminKey(nextKey));
            }
            
            clearServices(adminKey);
            serverMetadata.clearServiceMetadata();
            rootNodes.clear();
            passwordHandler.reset(passwordHandler.getPassword(), passwordHandler.getAdminKey());
            resetServerServices();
        }
    }
    
    /**
     * Remove all components of the network currently running on this server, but only
     * of the specified service type. This can also specify to only keep services of
     * the specified type.
     * @param serviceTypes list of service types to keep or remove.
     * @param keepRemove if true types to keep, if false types to remove.
     * @param adminKey the service key for this server.
     * @throws java.lang.Exception any error.
     */
    public void clearNetwork(ArrayList<String> serviceTypes, boolean keepRemove, String adminKey)
            throws Exception
    {
        int i;
        String nextKey;                             //next key
        ArrayList<String> allKeys;                  //all keys
        ArrayList<String> allTypes;                 //all types
        Service nextService;                        //next service
        

        if (passwordHandler.getAdminKey().equals(adminKey)) {
            allTypes = serviceAdmin.getServiceTypes();
            allKeys = serviceAdmin.getServiceNames(serviceTypes, keepRemove);
            
            for (i = 0; i < allKeys.size(); i++)
            {
                nextKey = allKeys.get(i);
                nextService = (Service)getServiceOrWrapper(nextKey, passwordHandler.getServicePassword(nextKey),
                        passwordHandler.getAdminKey(nextKey));

                nextService.clearServices(passwordHandler.getAdminKey(nextKey));
                nextService.setShutDown(true, passwordHandler.getAdminKey(nextKey));
                rootNodes.remove(nextKey);
            }
            
            clearServices(allKeys, adminKey);
            serverMetadata.clearServiceMetadata(allKeys);            
            passwordHandler.remove(allKeys);
            
            if (keepRemove) {
                for (i = 0; i < serviceTypes.size(); i++)
                {
                    nextKey = serviceTypes.get(i);
                    allTypes.remove(nextKey);
                }
                
                serviceTypes = allTypes;
            }
            
            resetServerServices(serviceTypes);
        }
    }
    
    /**
     * Return true if the service id is stored for a loaded service.
     * @param theServiceID the unique service id.
     * @return true if registered for a loaded service of false otherwise.
     */
    protected boolean isStoredService(String theServiceID)
    {
        return (serverMetadata.isStoredService(theServiceID));
    }

    /**
     * Execute a call on the system message bus. This passes the message to a queue on the server
     * from where it gets selected for processing by a service.
     * @param methodInfo the method call description with all of the required information.
     * @return Object the reply to the call.
     * @throws java.lang.Exception any error.
     */
    public Object messageBus(MethodInfo methodInfo) throws Exception
    {
        try {
            return messageMediator.messageBus(methodInfo);
        }
        catch (ServiceException se) {
            return null;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.WARN, "execute", null, ex);
        }
    }

    /**
     * Execute an asynchronous method on the server, or a service type known by the server.
     * This method calls {@code executeServerService} to invoke the {@code methodInfo} spec.
     * The asynchronous call does not return a value, thereby freeing the client sooner.
     * After executing the method, it instead saves any reply to a {@code messageStore} under the
     * {@code methodInfo}'s {@code communicationID}. This version forces a return type of {@code Element}
     * on the method it invokes. If that is not correct the method to invoke will not be found.
     * @param serviceType the service type on the server, see {@code executeServiceType}.
     * @param methodInfo this is the actual method call as it would be invoked from
     * any place. It requires the correct method name and parameter list.
     * @throws java.lang.Exception any error.
     */
    public void executeServiceTypeAsync(String serviceType, MethodInfo methodInfo) throws Exception
    {
        messageMediator.executeServiceTypeAsync(serviceType, methodInfo);
    }

    /**
     * Execute a synchronous method on a service type known by the server and probably owned locally.
     * This method calls {@code executeServerService} to invoke the parameter {@code methodInfo} spec.
     * This version forces a return type of {@code Element} on the method it invokes. If that is not
     * correct the method to invoke will not be found.
     * @param serviceType the service type on the server. For example, the server
     * search type is specified as {@link MetaConst}.{@code SEARCHMETADATA}, {@code SEARCHAUTODATA},
     * or {@code SEARCHWEBFOLDER}, {@code SEARCHALLWEB}.
     * A metadata search queries all of the service metadata, and a web folder search queries the
     * server's root web directory for matching text documents.
     * Only services owned by the server are recognised by this method call. To execute on a service
     * type in general, you replace the service name by it's type in the service URI and make a standard
     * call through the system. Then any services subscribed to reply can process the message.
     * @param methodInfo this is the actual method description as it would be invoked from
     * any place. It requires the correct method name and parameter list. It is not
     * restricted to the two search types, but the further programming might be required
     * to add other ones. The invoked method is assumed to return XML elements only.
     * @return the reply as an Element.
     * @throws java.lang.Exception any error.
     */
    public Element executeServiceType(String serviceType, MethodInfo methodInfo) throws Exception
    {
        return messageMediator.executeServiceType(serviceType, methodInfo);
    }

    /**
     * Subscribe to receive information from an {@code Information} service.
     * @param workInfo new client details. It must include the keyword list and the method
     * to reply with.
     * <ol>
     * <li> A list of descriptive keywords and topic to match with.</li>
     * <li> Details of the client method to reply with if a service work matches with the keywords request.</li>
     * </ol>
     * If {@code getClientURI()} is empty, then the request is ignored. It must also contain
     * a parameter list of size 1, that is either an {@code Object} or a {@link WorkInfo}
     * object, as that is what will be sent as a reply.
     * @return true if service request registered, false if keyword overlap.
     * @throws java.lang.Exception any error.
     */
    @Override
    public boolean subscribe(WorkInfo workInfo) throws Exception
    {
        try {
            return messageMediator.subscribe(workInfo);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "subscribe", null, ex);
        }
    }

    /**
     * Un-subscribe from a service.
     * @param keyInfo list of descriptive keywords to uniquely identify the service.
     * @param clientURI the client URI defines the request client.
     * @throws java.lang.Exception any error.
     */
    public void unsubscribe(KeywordInfo keyInfo, Element clientURI) throws Exception
    {
        try {
            messageMediator.unsubscribe(keyInfo, clientURI);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "unsubscribe", null, ex);
        }
    }

    /**
     * Publish to provide information as an {@code Information} service.
     * @param workInfo full work details, including an optional contract. The method
     * description must include the client URI as this is what identifies the request.
     * If {@code getClientURI()} is empty, then the request is ignored.
     * @return true if work request registered, false if keyword overlap.
     * @throws java.lang.Exception any error.
     */
    @Override
    public boolean publish(WorkInfo workInfo) throws Exception
    {
        try {
            return messageMediator.publish(workInfo);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "publish", null, ex);
        }
    }

    /**
     * Un-publish to provide information.
     * @param keyInfo list of descriptive keywords to uniquely identify the work.
     * @param serviceURI the client URI defines the request service.
     * @throws java.lang.Exception any error.
     */
    @Override
    public void unpublish(KeywordInfo keyInfo, Element serviceURI) throws Exception
    {
        try {
            messageMediator.unpublish(keyInfo, serviceURI);
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "unpublish", null, ex);
        }
    }
    
    /**
     * Get the service key for the specified service. This is a child service
     * of the server, or any service running on this server.
     * @param serviceID the id of the service to retrieve the admin key for.
     * @param thisAdminKey the admin key of this server.
     * @return the service key for the requested service.
     * @throws PasswordException incorrect admin key.
     */
    public String getAdminKey(String serviceID, String thisAdminKey) throws PasswordException
    {
        if (passwordHandler.hasAdminKey(serviceID)) {
            if (passwordHandler.getAdminKey().equals(thisAdminKey)) {
                return passwordHandler.getAdminKey(serviceID);
            }
        }
        
        return null;
    }
    
    /**
     * Add the metadata for the service.
     * @param thePassword the service password. Register if not already added.
     * @param theAdminKey the admin key for the service. Register if not already added.
     * @param theServiceMeta the metadata for the service.
     * @return true if added or false if it already exists.
     */
    public boolean addServiceMeta(String thePassword, String theAdminKey, ServiceMeta theServiceMeta)
    {
        boolean isOK;                               //true if OK
        String theUuid;                             //service uuid
        
        isOK = serverMetadata.addServiceMeta(theAdminKey, theServiceMeta);
        if (isOK) {
            theUuid = theServiceMeta.uuid;
            if (theUuid != null) {
                if (!passwordHandler.hasServicePassword(theUuid)) {
                    passwordHandler.addServicePassword(theUuid, thePassword);
                }
                if (!passwordHandler.hasAdminKey(theUuid)) {
                    passwordHandler.addAdminKey(theUuid, theAdminKey);
                }
            }
        }
        
        return isOK;
    }
    
    /**
     * Get a default subset of the metadata for the full service list, for info purposes only.
     * @return the metadata in XML format if it exists or null if it does not.
     * @throws java.lang.Exception any error.
     */
    public Element getAllServiceMeta() throws Exception
    {
        return getAllServiceMeta(getServiceNames());
    }
    
    /**
     * Get a default subset of the metadata for the specified list of services, for info purposes only.
     * @param serviceNames list of services to retrieve.
     * @return the metadata in XML format if it exists or null if it does not.
     * @throws java.lang.Exception any error.
     */
    public Element getAllServiceMeta(ArrayList<String> serviceNames) throws Exception
    {
        int i, j;
        String nextID;                              //next service id
        ArrayList<String> toInclude;                //elements to include
        ArrayList<String> storedMetaIDs;            //ids of stored meta objects
        ArrayList<Object> childServices;            //child services list
        Element fullListElem;                       //full list element
        Element metaElem;                           //metadata element
        ServiceMetaParser metaParser;               //service meta parser
        ServiceMeta serviceMeta;                    //service meta
        
        storedMetaIDs = new ArrayList<>();
        metaParser = new ServiceMetaParser();
        fullListElem = XMLFactory.getInstance().createElement(Const.SERVICES);
            
        //retrieve the service and child metadata
        for (i = 0; i < serviceNames.size(); i++)
        {
            nextID = serviceNames.get(i);
            if ((nextID != null) && !storedMetaIDs.contains(nextID)) {
                storedMetaIDs.add(nextID);
                
                toInclude = new ArrayList<>();
                toInclude.add(Const.CONSTRUCTORS);
                toInclude.add(Const.METHODS);
                toInclude.add(Const.CLASSNAME);
                toInclude.add(Const.CHILDSERVICES);
                toInclude.add(Const.LINKS);

                metaElem = getServiceMeta(nextID, passwordHandler.getAdminKey(nextID), toInclude);
                if (metaElem != null) {
                    serviceMeta = (ServiceMeta)metaParser.parse(metaElem);
                    fullListElem.addContent((Element)metaElem.clone());
                    
                    //also retrieve the child services metadata
                    childServices = serviceMeta.getChildServices();
                    for (j = 0; j < childServices.size(); j++)
                    {
                        nextID = (String)childServices.get(j);

                        metaElem = getServiceMeta(nextID);
                        if (metaElem != null) {
                            fullListElem.addContent(metaElem);
                            storedMetaIDs.add(nextID);
                        }
                    }
                }
            }
        }
 
        return fullListElem;
    }
    
    /**
     * Get a default subset of the metadata for the service, for info purposes only.
     * @param theServiceID the unique id to define the service.
     * @return the metadata in XML format if it exists or null if it does not.
     * @throws java.lang.Exception any error.
     */
    public Element getServiceMeta(String theServiceID) throws Exception
    {
        return serverMetadata.getServiceMeta(theServiceID);
    }
    
    /**
     * Get a default subset of the metadata for the service, plus other sections.
     * This is instead of returning the full metadata description.
     * @param theServiceID the unique id of the service to retrieve metadata for.
     * @param theAdminKey for administrator-level access to the service. The
     * admin key for the server is also allowed here.
     * @param toInclude list of additional meta parts to return. See the {@link ServiceMeta}
     * class for a description of the field names.
     * @return the metadata in XML format if it exists, or null if it does not.
     * @throws java.lang.Exception any error.
     */
    public Element getServiceMeta(String theServiceID, String theAdminKey, ArrayList<String> toInclude)
            throws Exception
    {
        String serviceAdminKey;                     //the service admin key
        Element metaElem;                           //meta element
        FrameworkModule theService;                   //the service
        ServiceMeta serviceMeta;                    //new service meta
        
        metaElem = null;
        serviceAdminKey = theAdminKey;
        if (passwordHandler.getAdminKey().equals(theAdminKey) &&
            !(theServiceID.equals(Const.HTTPSERVER))) {
            serviceAdminKey = passwordHandler.getAdminKey(theServiceID);
        }
        
        if (passwordHandler.getAdminKey().equals(serviceAdminKey) ||
            passwordHandler.getAdminKey(theServiceID).equals(serviceAdminKey)) {
            //can still be this local server
            if (theServiceID.equals(Const.HTTPSERVER)) {
                theService = this;
            }
            else {
                theService = getServiceOrWrapper(theServiceID,
                    passwordHandler.getServicePassword(theServiceID), serviceAdminKey);
            }

            if (ModuleHandler.isService(theService)) {
                serviceMeta = ((Service)theService).createMetaFull(jarFile, serviceAdminKey);
                metaElem = serverMetadata.getServiceMeta(theServiceID, toInclude, serviceMeta);
            }
        }
        
        return metaElem;
    }
    
    /**
     * Retrieve just one part of the metadata description, not the whole object.
     * @param theServiceID the unique id of the service to retrieve metadata for.
     * @param theAdminKey for administrator-level access to the service. The
     * admin key for the server is also allowed here.
     * @param toInclude meta part to return. See the {@link ServiceMeta}
     * class for a description of the field names.
     * @return the metadata in XML format if it exists, or null if it does not.
     * @throws java.lang.Exception any error.
     */
    public Element getServiceMetaPart(String theServiceID, String theAdminKey, String toInclude)
            throws Exception
    {
        int i;
        String serviceAdminKey;                     //the service admin key
        String serviceName;                         //service name
        ArrayList<String> serviceNames;             //list of service names
        Element serviceElem;                        //service element
        Element metaElem;                           //meta element
        FrameworkModule theService;                   //the service
        ServiceMeta serviceMeta;                    //new service meta
        ServiceMetaParser serviceMetaParser;        //service meta parser

        metaElem = null;
        serviceAdminKey = theAdminKey;
        if (passwordHandler.getAdminKey().equals(theAdminKey) &&
            !(theServiceID.equals(Const.HTTPSERVER))) {
            serviceAdminKey = passwordHandler.getAdminKey(theServiceID);
        }
        
        if (passwordHandler.getAdminKey().equals(serviceAdminKey) ||
            passwordHandler.getAdminKey(theServiceID).equals(serviceAdminKey)) {
            //for the ESB, the server part can include other additional info
            if (theServiceID.equals(Const.HTTPSERVER) && toInclude.equals(Const.SERVICES)) {
                serviceMeta = new ServiceMeta();
                serviceMetaParser = new ServiceMetaParser();
                serviceNames = getServiceNames();               
                
                if (!serviceNames.isEmpty()) {
                    serviceMeta.meta = XMLFactory.getInstance().createElement(Const.OTHERMETA);                   
                    for (i = 0; i < serviceNames.size(); i++)
                    {
                        serviceName = serviceNames.get(i);
                        serviceElem = XMLFactory.getInstance().createElement(Const.SERVICE);
                        serviceElem.setAttribute(Const.NAME, serviceName);
                        serviceMeta.meta.addContent(serviceElem);
                    }
                }
                
                metaElem = serviceMetaParser.serialize(serviceMeta);      
            }
            else {
                //can still be this local server
                if (theServiceID.equals(Const.HTTPSERVER)) {
                    theService = this;
                }
                else {
                    theService = getServiceOrWrapper(theServiceID,
                        passwordHandler.getServicePassword(theServiceID), serviceAdminKey);
                }

                if (ModuleHandler.isService(theService)) {
                    serviceMeta = ((Service)theService).createMetaFull(jarFile, serviceAdminKey);
                    metaElem = serverMetadata.getServiceMetaPart(theServiceID, toInclude,
                            serviceMeta);
                }
            }
        }
        
        return metaElem;
    }
    
    /**
     * Get the full service metadata description from the repository.
     * @param theServiceID the unique id of the service meta to retrieve.
     * @param theAdminKey the unique admin key for the service.
     * @return a direct reference to the object itself so that it can be changed.
     * @throws java.lang.Exception any error.
     */
    public ServiceMeta getServiceMeta(String theServiceID, String theAdminKey) throws Exception
    {
        if (
            (theServiceID.equals(Const.HTTPSERVER) && passwordHandler.getAdminKey().equals(theAdminKey)) ||
            (passwordHandler.hasAdminKey(theServiceID) && passwordHandler.getAdminKey(theServiceID).equals(theAdminKey))
            ) {
            return serverMetadata.getServiceMeta(theServiceID, theAdminKey);
        }
        
        return null;
    }
    
    /**
     * Remove the service metadata from the repository.
     * @param theServiceID the unique id of the service to remove.
     * @param theAdminKey the unique admin key for the service.
     * @return true if the info is removed or false otherwise.
     * @throws java.lang.Exception any error.
     */
    protected boolean removeServiceMeta(String theServiceID, String theAdminKey) throws Exception
    {
        if (serverMetadata.removeServiceMeta(theServiceID, theAdminKey)) {
            //traverse through all stored services and ask to remove links
            //to the removed service
            return removeAllLinksTo(theServiceID, theAdminKey);
        }
        
        return false;
    }
    
    /**
     * Return true if the local server password is stored. Must be true here.
     * @return true as this is the server.
     */
    protected boolean hasServerPassword()
    {
        return true;
    }
    
    /**
     * Get the local server password, which is the ESB password as well.
     * @return the local server password.
     * @throws java.lang.Exception any error.
     */
    protected String getServerPassword() throws Exception
    {
        return passwordHandler.getPassword();
    }
    
    /**
     * Remove all non-dynamic links to the specified service from all other services.
     * @param theServiceID the unique id of the service to remove links to.
     * @param theAdminKey the unique admin key for the service to remove links to.
     * @return true if the admin key allows access, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean removeAllLinksTo(String theServiceID, String theAdminKey)
            throws Exception
    {
        int i;
        String serviceUUID;                         //next service id
        String password;                            //service password
        String adminKey;                            //next admin key
        ArrayList<String> serviceIDs;               //all service ids
        Service theService;                         //the service
        
        if (!passwordHandler.hasAdminKey(theServiceID) ||
            passwordHandler.getAdminKey(theServiceID).equals(theAdminKey)) {
            serviceIDs = getServiceNames();

            for (i = 0; i < serviceIDs.size(); i++)
            {
                serviceUUID = serviceIDs.get(i);
                if (!serviceUUID.equalsIgnoreCase(theServiceID)) {
                    password = passwordHandler.getServicePassword(serviceUUID);
                    adminKey = passwordHandler.getAdminKey(serviceUUID);

                    theService = (Service) serviceAdmin.getServiceOrWrapper(serviceUUID, password, adminKey);
                    theService.removeAllLinksTo(theServiceID, adminKey);
                }
            }

            return true;
        }
        
        return false;
    }
    
    /**
     * Get a list of all of the service types in the network.
     * @return a list of all of the service types, of type String.
     */
    public ArrayList<String> getServiceTypes()
    {
        int i;
        String serviceType;                         //service type
        ArrayList<String> serviceTypes;             //service types
        ArrayList<String> serviceTypesPlus;         //service types plus nested?
        
        serviceTypes = super.getServiceTypes();
        serviceTypesPlus = serverMetadata.getServiceTypes();
        
        for (i = 0; i < serviceTypesPlus.size(); i++)
        {
            serviceType = serviceTypesPlus.get(i);
            if (!serviceTypes.contains(serviceType)) {
                serviceTypes.add(serviceType);
            }
        }
        
        return serviceTypes;
    }
    
    /**
     * Get a list of all of the service types in the network for a
     * particular category.
     * @param category the category to return service types for.
     * @return a list of all of the service types, of type String.
     */
    public ArrayList<String> getServiceTypes(String category)
    {
        return serverMetadata.getServiceTypes(category);
    }

    /**
     * Return all registered service names.
     * This method performs a second filtering stage, to return only the services that
     * allow point-to-point access, or have not specified, for a service ID message.
     * @return the service names for the service types list.
     */
    protected ArrayList<String> getServiceNamesPermission()
    {
        int i;
        String serviceID;                       //next service id
        WorkInfo workInfo;                      //work info
        ArrayList<String> serviceNames;         //service names
        ArrayList<String> ptpNames;             //service point-to-point names
        ServiceWrapperDef serviceWrapper;       //the service wrapper

        serviceNames = getServiceNames();
        ptpNames = null;

        if (serviceNames != null) {
            ptpNames = new ArrayList<>();

            //perform a second filter on the work protocol
            for (i = 0; i < serviceNames.size(); i++) {
                serviceID = serviceNames.get(i);

                try {
                    serviceWrapper = getServiceWrapper(serviceID, passwordHandler.getServicePassword(serviceID),
                            passwordHandler.getAdminKey(serviceID));

                    workInfo = serviceWrapper.getWorkInfo();
                    if ((workInfo == null) || workInfo.isPtP()) {
                        ptpNames.add(serviceID);
                    }
                }
                catch (Exception ex) {}
            }
        }

        return ptpNames;
    }

    /**
     * Return all registered service names for a list of service types.
     * This method performs a second filtering stage, to return only the services that
     * allow subscribe access, for a service type message.
     * @param thisServiceTypes the service types list.
     * @return the service names for the service types list.
     * @throws LicasException if the service types input is {@code null}.
     */
    protected ArrayList<String> getServiceTypeNamesPermission(ArrayList<String> thisServiceTypes) throws LicasException
    {
        int i;
        String serviceID;                       //next service id
        WorkInfo workInfo;                      //work info
        ArrayList<String> serviceNames;         //service names
        ArrayList<String> subscribeNames;       //service subscribed names
        ServiceWrapperDef serviceWrapper;       //the service wrapper

        serviceNames = getServiceNames(thisServiceTypes);
        subscribeNames = null;

        if (serviceNames != null) {
            subscribeNames = new ArrayList<>();

            //perform a second filter on the work protocol
            for (i = 0; i < serviceNames.size(); i++) {
                serviceID = serviceNames.get(i);

                try {
                    serviceWrapper = getServiceWrapper(serviceID, passwordHandler.getServicePassword(serviceID),
                            passwordHandler.getAdminKey(serviceID));

                    workInfo = serviceWrapper.getWorkInfo();
                    if ((workInfo != null) && workInfo.isSubscribe()) {
                        subscribeNames.add(serviceID);
                    }
                }
                catch (Exception ex) {}
            }
        }

        return subscribeNames;
    }

    /**
     * Calculate what nodes are root nodes, that is, are not children of any other nodes.
     * @param theAdminKey the admin key for this server.
     */
    public void calculateRootNodes(String theAdminKey)
    {
        int i;
        String serviceUuid;                         //service uuid
        ArrayList<String> serviceUuids;             //service uuids
                
        if (passwordHandler.isAdminKey(theAdminKey)) {
            serviceUuids = getServiceNames();
            rootNodes = (ArrayList)serviceUuids.clone();
            
            for (i = 0; i < serviceUuids.size(); i++)
            {
                serviceUuid = serviceUuids.get(i);
                if (!serviceUuid.equals(Const.HTTPSERVER)) {
                    rootNodes.removeAll(serviceLinks.childServices);
                    rootNodes.removeAll(serviceLinks.getPermanentLinks().getAllLinkToServiceIDs());
                }
            }

            rootNodes.remove(Const.HTTPSERVER);        
        }
    }
    
    /**
     * Add a service uuid to the list of root nodes. Note that the service itself
     * must already be added to the server and this method is only to declare it as
     * a root node in some hierarchical structure.
     * @param theRootNode the uuid of the root service to add.
     * @param theAdminKey the server admin key.
     * @return true if the node is added or false otherwise.
     */
    protected boolean addRootNode(String theRootNode, String theAdminKey)
    {
        if (passwordHandler.isAdminKey(theAdminKey)) {
            if (!rootNodes.contains(theRootNode)) {
                rootNodes.add(theRootNode);
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Remove a service uuid from the list of root nodes. Note that the service itself
     * is not removed. This method is only to remove a root node in some hierarchical 
     * organisation structure.
     * @param theRootNode the root node service uuid.
     * @param theAdminKey the unique key for the service to remove.
     * @return true if the node is removed or false otherwise.
     * @throws PasswordException incorrect admin key.
     */
    public boolean removeRootNode(String theRootNode, String theAdminKey) throws PasswordException
    {
        String rootServiceKey;                      //stored service key
        
        if (passwordHandler.hasAdminKey(theRootNode)) {
            rootServiceKey = passwordHandler.getAdminKey(theRootNode);
            if (rootServiceKey == null) rootServiceKey = passwordHandler.getAdminKey();

            if (rootServiceKey != null) {
                if (rootServiceKey.equals(theAdminKey) && rootNodes.contains(theRootNode)) {
                    rootNodes.remove(theRootNode);
                    return true;
                }
            }
        }
        
        return false;
    }
    
    /**
     * Get a copy list of the root nodes.
     * @param theAdminKey the unique key for the service to add.
     * @return true if the node is added or false otherwise.
     */
    public ArrayList<String> getRootNodes(String theAdminKey)
    {
        if (passwordHandler.isAdminKey(theAdminKey)) {
            return (ArrayList)rootNodes.clone();
        }
        
        return null;
    }
    
    /**
     * Add a new class loader from remote uris.
     * @param thePassword the password to access this server.
     * @param uris a list of remote uris to load the classes from.
     * @throws java.lang.Exception any error.
     * @return true if loader loaded.
     */
    public boolean addLoader(String thePassword, ArrayList<String> uris) throws Exception
    {
        if (canAccess(thePassword)) {
            LoadObject.addLoader(uris);
            return true;
        }
        else {
            return false;
        }
    }
    
    /**
     * Create a new instance of an object, with no initialisation parameters.
     * This loads the related java classes into the system.
     * @param thePassword the password to access this server.
     * @param className the name of the object class to load.
     * @param uris a list of remote uris to load the classes from.
     * @throws java.lang.Exception any error.
     * @return true if loader loaded.
     */
    public boolean addObject(String thePassword, String className, ArrayList<String> uris) throws Exception
    {
        if (canAccess(thePassword)) {
            LoadObject.addLoader(uris);
            LoadObject.getClass(className);
            
            try {
                sm.loadObject(uris, className, new ArrayList<>());
            }
            catch (Exception loe) {}
            
            return true;
        }
        else {
            return false;
        }
    }
    
    /**
     * Add a new parser to the parsers.
     * @param thePassword the password to access this server.
     * @param objectClass the class name of the object to parse.
     * @param parserClass the class name of the parser.
     * @param uris a list of remote uris to load the classes from.
     * @param params any initialisation parameters.
     * @throws java.lang.Exception any error.
     * @return true if parser added.
     */
    public boolean addParser(String thePassword, String objectClass, String parserClass, 
        ArrayList<String> uris, ArrayList<Object> params) throws Exception
    {
        Object theParser;                           //the parser
        
        if (canAccess(thePassword)) {
            //check that the parser can be loaded
            theParser = sm.loadObject(uris, parserClass, params);
            
            if (theParser != null)
                return  Parsers.addParser(objectClass, theParser);
            else
                return false;
        }
        else {
            return false;
        }
    }
    
    /**
     * Remove the parser from the parsers if it exists.
     * @param thePassword the password to access this server.
     * @param objectClass the class name of the object the parser parses.
     * @return true if parser removed.
     */
    public boolean removeParser(String thePassword, String objectClass)
    {
        if (canAccess(thePassword)) {
            return Parsers.removeParser(objectClass);
        }
        else {
            return false;
        }
    }
    
    /**
     * Retrieve a description of the whole network structure in XML format.
     * @param theAdminKey the unique key to allow admin operations on this server.
     * @return a list of XML-based files that describe the network.
     * @throws java.lang.Exception any error.
     */
    public HashMap<String, Element> getServerSOA(String theAdminKey) throws Exception
    {
        SoaParser networkParser;                    //network parser
        
        if (passwordHandler.isAdminKey(theAdminKey)) {
            networkParser = new SoaParser();
            return networkParser.serialize(passwordHandler.getPassword(), passwordHandler.getAdminKey());
        }
        
        return null;
    }
    
    /**
     * Load the network described by the list of XML-based documents onto the server.
     * @param dirPath path to the local directory to read the files from. The network
     * is identified as having a root {@code Const.NETWORK} element, while the links
     * document has a root {@code Const.LINKS} element.
     * @param theAdminKey the unique key to allow admin operations on this server.
     * @return a list of the service ids with related passwords. Keys are the
     * service ids of type string and values are password/service related values
     * of type vector of Objects.
     * @throws java.lang.Exception any error.
     */
    public HashMap<String, ArrayList<String>> loadServerSOA(String dirPath, String theAdminKey) throws Exception
    {
        int i;
        String nextFile;                            //next file contents
        ArrayList<String> filePaths;                //all file paths
        ArrayList<String> fileContent;              //list of read files
        HashMap<String, Element> networkXML;        //list of network files
        File filePath;                              //file path
        Element fileXml;                            //file as an XML element
        
        if (passwordHandler.isAdminKey(theAdminKey)) {
            filePaths = FileLoader.getFileList(dirPath);
            
            fileContent = new ArrayList<>();
            for (i = 0; i < filePaths.size(); i++)
            {
                filePath = new File(dirPath);
                filePath = new File(filePath.getAbsolutePath() + Const.DIRSEP + filePaths.get(i));
                nextFile = FileLoader.getInputStream(filePath.getAbsolutePath());
                fileContent.add(nextFile);
            }
            
            networkXML = new HashMap<>();
            for (i = 0; i < fileContent.size(); i++)
            {
                nextFile = fileContent.get(i);
                try {
                    fileXml = XmlHandler.stringToElement(nextFile);
                    if (fileXml.getName().equals(Const.PASSWORDS))
                        networkXML.put(Const.PASSWORDS, fileXml);
                    else if (fileXml.getName().equals(Const.SERVER))
                        networkXML.put(Const.SERVER, fileXml);
                    else if (fileXml.getName().equals(Const.LINKS))
                        networkXML.put(Const.LINKS, fileXml);
                }
                catch (Exception rfex) {}
            }
            
            return loadServerSOA(networkXML, theAdminKey);
        }
        
        return null;
    }
    
    /**
     * Load the network described by the list of XML-based documents onto the server.
     * @param networkXML an XML description of the network. The network file is 
     * identified as having the key value {@code Const.NETWORK} element, while the links
     * document has a root {@code Const.LINKS} element.
     * @param theAdminKey the unique key to allow admin operations on this server.
     * @return a list of the service ids with related passwords. Keys are the
     * service ids of type string and values are password/service related values
     * of type vector of Objects.
     * @throws java.lang.Exception any error.
     */
    public HashMap<String, ArrayList<String>> loadServerSOA(HashMap<String, Element> networkXML, String theAdminKey)
            throws Exception
    {
        HashMap<String, ArrayList<String>> allPasswords;    //password list created by the parser
        SoaParser soaParser;                                //network parser
        
        allPasswords = null;
        if (passwordHandler.isAdminKey(theAdminKey)) {
            soaParser = new SoaParser();
            allPasswords = soaParser.parse(networkXML, passwordHandler.getPassword(),
                    passwordHandler.getAdminKey());

            passwordHandler.addPasswords(allPasswords);
        }
        
        return allPasswords;
    }
    
    /**
     * Create and load a serialized service from its XML description. Note that if
     * this loads utility services through the script, these will not get registered
     * with the server as they are created before the main service is added.
     * @param serviceXml the full serialized description of the service, typically created
     * by calling {@link Service}.{@code serviceToXml} on the service itself.
     * @param theAdminKey the unique key to allow admin operations on this server.
     * @return true if the services was created and loaded, false otherwise.
     * @throws java.lang.Exception any error.
     */
    public boolean loadServiceFromXml(Element serviceXml, String theAdminKey) throws Exception
    {
        boolean isOK;                               //true if OK
        String lServiceUuid;                        //service uuid
        String lServiceType;                        //service type
        Element nextElem;                           //next element
        Object theService;                          //the service to load
        
        isOK = false;
        if (passwordHandler.isAdminKey(theAdminKey)) {
            lServiceUuid = null;
            lServiceType = null;

            nextElem = serviceXml.getChild(Const.UUID);
            if (nextElem != null) {
                lServiceUuid = nextElem.getText();
            }
            nextElem = serviceXml.getChild(Const.SERVICETYPE);
            if (nextElem != null) {
                lServiceType = nextElem.getText();
            }
            if (lServiceUuid == null) {
                lServiceUuid = serviceXml.getAttributeValue(Const.NAME);
            }
            if (lServiceType == null) {
                lServiceType = serviceXml.getName();
            }
            
            theService = Service.xmlToService(serviceXml, passwordHandler.getPassword());
            if (theService != null) {
                if (theService instanceof Service) {
                    this.addService(passwordHandler.getPassword(), ((Service)theService).getUUID(), 
                        ((Service)theService).getServiceType(), theService);
                }
                else {
                    this.addService(passwordHandler.getPassword(), lServiceUuid, 
                        lServiceType, theService);
                }

                isOK = true;
            }
        }
        
        return isOK;
    }
    
    /**
     * Serialize the stored passwords list and return as an XML-based description.
     * @param adminKey the service admin key.
     * @return an XML representation of all passwords, or null if the admin key is incorrect.
     * @throws Exception any error.
     */
    public Element passwordsStateToXml(String adminKey) throws Exception
    {
        Element rootElem;                           //root element
        ServiceSerialize serviceSerialize;          //service serializer
        
        rootElem = null;
        if (passwordHandler.isAdminKey(adminKey)) {
            serviceSerialize = new ServiceSerialize();
            rootElem = serviceSerialize.passwordsPlusStateToXml(this);
        }
        
        return rootElem;
    }
    
    /**
     * Retrieve a description of the server itself in XML format. This is probably
     * only passwords and links to other servers, so that it can be re-constructed.
     * @param theAdminKey the unique key to allow admin operations on this server.
     * @return a list of XML-based files that describe the network.
     * @throws java.lang.Exception any error.
     */
    public Element getServerDetails(String theAdminKey) throws Exception
    {
        NetworkParser networkParser;                //network parser
        
        if (passwordHandler.isAdminKey(theAdminKey)) {
            networkParser = new NetworkParser();
            return networkParser.serialize(this.getFullPath(), passwordHandler,
                    this.serviceLinks);
        }
        
        return null;
    }
    
    /**
     * Add the details as specified in the xml script to the server. This is probably
     * only links to other servers at the moment.
     * @param serverXml the server description to add.
     * @param theAdminKey the unique key to allow admin operations on this server.
     * @return true if added OK, or false if there was an error.
     * @throws java.lang.Exception any error.
     */
    public boolean loadServerDetails(Element serverXml, String theAdminKey) throws Exception
    {
        int i;
        String nextPassword;                        //next password
        Element metaElem;                           //meta element
        Element linkPathElem;                       //link path element
        Element nextElem;                           //next element
        Element nextElem2;                          //next element
        Vector<Node> elemList;                      //element list
        HashMap<String, Element> serverDetails;     //server details
        NetworkParser networkParser;                //network parser
        
        if (passwordHandler.isAdminKey(theAdminKey)) {
            networkParser = new NetworkParser();
            serverDetails = networkParser.parse(serverXml);
            metaElem = serverDetails.get(MetaConst.META);
            
            if (metaElem != null) {
                elemList = metaElem.getChildren();
                for (i = 0; i < elemList.size(); i++)
                {
                    nextElem = (Element)elemList.get(i);
                    if (nextElem.getName().equals(MetaConst.ASSOCIATEDLINKSERVICEMETA))
                    {
                        linkPathElem = nextElem.getChild(Const.HANDLE);
                        if (linkPathElem != null) {
                            nextElem2 = nextElem.getChild(Const.PASSWORDS);
                            if (nextElem2 != null) {
                                nextElem2 = nextElem2.getChild(Const.PASSWORD);
                                if (nextElem2 != null) {
                                    linkPathElem = (Element)linkPathElem.clone();
                                    nextPassword = nextElem2.getText();
                                    addServiceAssociation(passwordHandler.getAdminKey(), linkPathElem, nextPassword);
                                }
                            }
                        }
                    }
                }
            }
            
            return true;
        }
        
        return false;
    }
    
    /**
     * Add the communication id and packet info to the packetInfo structure.
     * @param communicationID the id to identify the communication thread.
     * @param packetSize the maximum size of the packet to send.
     * @return true if the id and the file name are new and the file can be created.
     * @throws java.lang.Exception any error.
     */
    public boolean addPacketCommunicationID(String communicationID, int packetSize) 
            throws Exception
    {
        return messagePackets.addPacketCommunicationID(communicationID, packetSize);
    }
    
    /**
     * Add the message packet to the appropriate file as indicated by the communication id.
     * @param communicationID the id to identify the communication thread.
     * @param packetObject the next part of the message to save.
     * @return true if the packet is successfully added to the file.
     * @throws java.lang.Exception any error.
     */
    public boolean addMessagePacket(String communicationID, String packetObject) 
            throws Exception
    {
        return messagePackets.addMessagePacket(communicationID, packetObject);
    }
    
    /**
     * Call this to indicate that the whole message has been sent and should now be executed.
     * @param communicationID the id to identify the communication thread.
     * @return the result of executing the method represented by the message.
     * @throws java.lang.Exception any error.
     */
    public Object endOfMessage(String communicationID) throws Exception
    {
        MethodInfo methodInfo;                      //method info
        Object reply;                               //the reply
        
        try {
            if (logger.getDebug()) LoggerHandler.debugMessage(logger, LoggerHandler.INFO, "endOfMessage",
                    ": comm id: " + communicationID);
            
            reply = null;        
            methodInfo = messagePackets.endOfMessage(communicationID);
            if (methodInfo != null) {
                //execute the method to return the reply
                reply = this.execute(methodInfo, true);
            }
            
            return reply;
        }
        catch (Exception ex) {
            throw ExceptionHandler.handleException(logger, LoggerHandler.ERROR,
                    "endOfMessage", null, ex);
        }
    }

    /**
     * Get the query stats.
     * @param queryType the query engine service type on the server.
     * @param adminKey the admin key for the server.
     * @return the reply as an Element.
     * @throws java.lang.Exception any error.
     */
    public Element getStats(String queryType, String adminKey) throws Exception
    {
        ArrayList<String> serviceNames;             //service names
        ArrayList<String> serviceTypes;             //service types
        QueryDef queryEngine;                       //the query engine
        Element statsReply;                         //stats reply
        
        statsReply = null;
        
        try {
            if (passwordHandler.isAdminKey(adminKey)) {
                serviceTypes = new ArrayList<>();
                serviceTypes.add(queryType);
                serviceNames = this.getServiceNames(serviceTypes, false);

                queryEngine = (QueryDef)getService(serviceNames.get(0),
                        passwordHandler.getServicePassword(serviceNames.get(0)),
                        passwordHandler.getAdminKey(serviceNames.get(0)));

                if (queryEngine != null) {
                    statsReply = queryEngine.getStats();
                }
            }
        }
        catch (PasswordException pe) {}
        
        return statsReply;
    }
    
    /**
     * Get the list of methods that can be safely called on a secure server.
     * @return the list of safe method names, but might still require passwords.
     */
    protected ArrayList<String> getSecureMethods()
    {
        ArrayList<String> methodNames;                  //list of method names
        
        //server
        methodNames = super.getSecureMethods();
        methodNames.add(MethodConst.ISRUNNING);
        methodNames.add(MethodConst.GETSERVERDETAILS);
        methodNames.add(MethodConst.GETALLSERVICEMETA);
        methodNames.add(MethodConst.LOADSERVERDETAILS);
        methodNames.add(MethodConst.GETSTATS);
        methodNames.add(MethodConst.GETSERVERSOA);
        methodNames.add(MethodConst.LOADSERVERSOA);
        methodNames.add(MethodConst.AUTOMANMETRICS);
        methodNames.add(MethodConst.LOADSERVICEFROMXML);
        methodNames.add(MethodConst.BLOCKSERVICE);
        methodNames.add(MethodConst.UNBLOCKSERVICE);
        methodNames.add(MethodConst.ADDSERVICEASSOCIATION);
        methodNames.add(MethodConst.REMOVESERVICEASSOCIATION);
        methodNames.add(MethodConst.CALCULATEROOTNODES);
        methodNames.add(MethodConst.ADDROOTNODE);
        methodNames.add(MethodConst.REMOVEROOTNODE);
        methodNames.add(MethodConst.GETROOTNODES);
        methodNames.add(MethodConst.STARTALLTHREADS);
        methodNames.add(MethodConst.STOPALLTHREADS);
        methodNames.add(MethodConst.CLEARNETWORK);
        
        //server - password protected
        methodNames.add(MethodConst.EXECUTESERVICETYPE);
        methodNames.add(MethodConst.EXECUTESERVICETYPEASYNC);
        methodNames.add(MethodConst.ADDPARSER);
        methodNames.add(MethodConst.REMOVEPARSER);
        methodNames.add(MethodConst.ALLOWADDSERVICE);
        methodNames.add(MethodConst.GETALLOWADDSERVICE);
        methodNames.add(MethodConst.ADDPACKETCOMMUNICATIONID);
        methodNames.add(MethodConst.ADDMESSAGEPACKET);
        methodNames.add(MethodConst.ENDOFMESSAGE);
        methodNames.add(MethodConst.SYNCTOASYNC);
        methodNames.add(MethodConst.SYNCTOASYNCTRANSIT);
        methodNames.add(MethodConst.SYNCTOASYNCREPLY);
        methodNames.add(MethodConst.ADDOBJECT);
        methodNames.add(MethodConst.SUBSCRIBE);
        methodNames.add(MethodConst.UNSUBSCRIBE);
        methodNames.add(MethodConst.PUBLISH);
        methodNames.add(MethodConst.UNPUBLISH);
        
        //services
        methodNames.add(MethodConst.ADDSERVICE);
        methodNames.add(MethodConst.ADDDEFAULTSERVICE);
        methodNames.add(MethodConst.REMOVESERVICEID);
        methodNames.add(MethodConst.REMOVESERVICEPATH);
        methodNames.add(MethodConst.ADDSERVICEMETA);
        methodNames.add(MethodConst.HASSERVICE);
        methodNames.add(MethodConst.GETSERVICENAMES);
        methodNames.add(MethodConst.GETSERVICETYPES);
        methodNames.add(MethodConst.GETSERVICENUMBER);
        methodNames.add(MethodConst.GETSERVICEMETA);
        methodNames.add(MethodConst.GETSERVICEMETAPART);
        methodNames.add(MethodConst.REMOVEALLLINKSTO);
               
        return methodNames;
    }

    /**
     * Clean-up before shutting down the service.
     */
    public void close() {
        try {
            if (messageMediator != null) {
                messageMediator.interrupt();
            }
        }
        catch (Exception ex)
        {}

        super.close();
    }
}
