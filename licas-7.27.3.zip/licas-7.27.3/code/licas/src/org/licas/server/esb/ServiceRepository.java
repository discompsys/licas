/*
 * ServiceRepository.java
 *
 * Created on 7 December 2008
 *
 * Version 1.6.1
 *
 * Copyright (c) Kieran Greer
 */

package org.licas.server.esb;


import org.licas.meta.ServiceMeta;
import org.licas.parsers.admin.ServiceMetaParser;
import org.licas.server.model.ServiceRepositoryInfo;
import org.licas.util.Const;
import org.licas.util.ServiceConst;
import org.licas_xml.abs.Element;

import java.util.*;


/**
 * This acts as a repository to store metadata describing services running on the server.
 * The information stored might only be a subset of all metadata information and 
 * it is always a static copy, created and added when the service is registered. 
 * If other metadata is required, then the service itself can be invoked, probably through 
 * an {@code AutoServer getServiceMeta...} method. With appropriate passwords however, the
 * repository metadata can be retrieved and updated.
 * The retrieval process would also typically be password protected at the server level,
 * with this class stored on a server privately.
 * @author Kieran Greer
 */
public class ServiceRepository 
{
    /** 
     * ArrayList of service details. Keys are the unique service ids of type String 
     * and values are the {@link ServiceRepositoryInfo} objects describing the service.
     * The key can also be a service type, e.g. {@code Message} or {@code File}, if the metadata
     * description is a general one.
     */
    protected HashMap<String, ServiceRepositoryInfo> serviceMeta;
    
    /** 
     * ArrayList of service types. Keys are the service class names of type String and
     * values are the {@link ServiceRepositoryInfo} objects describing the service. If the
     * key is a service type instead, e.g. {@code Message} or {@code File}, the type will be removed 
     * if the corresponding metadata object is removed.
     */
    protected HashMap<String, ServiceRepositoryInfo> serviceTypes;
    
    /**
     * Create a new instance of ServiceRepository.
     */
    public ServiceRepository()
    {
        initialise();
    }
    
    /**
     * Initialise some values.
     */
    private void initialise()
    {
        serviceMeta = new HashMap<>();
        serviceTypes = new HashMap<>();
    }
    
    /**
     * Return true if the service id is stored for a loaded service.
     * @param theServiceID the unique service id.
     * @return true if registered for a loaded service of false otherwise.
     */
    public boolean isStoredService(String theServiceID)
    {
        return (serviceMeta.containsKey(theServiceID));
    }
    
    /**
     * Clear all service metadata apart from the server itself.
     */
    public void clearServiceMetadata()
    {
        ServiceRepositoryInfo serverInfo;               //repository info
        
        serverInfo = null;
        if (serviceMeta.containsKey(Const.HTTPSERVER)) {
            serverInfo = serviceMeta.get(Const.HTTPSERVER);
        }
        
        serviceMeta.clear();
        serviceTypes.clear();
        
        if (serverInfo != null) {
            serverInfo.getServiceMeta().clearChildAndLinksMeta();
            serviceMeta.put(Const.HTTPSERVER, serverInfo);
        }
    }
    
    /**
     * Clear all service metadata for the specified services apart from the server itself.
     * @param serviceIDs list of service IDs to remove metadata for.
     */
    public void clearServiceMetadata(ArrayList<String> serviceIDs)
    {
        int i;
        String serviceID;                               //service id
        ServiceRepositoryInfo nextInfo;                 //repository info
        ServiceRepositoryInfo serverInfo;               //repository info
        
        if (!serviceIDs.isEmpty()) {
            serverInfo = null;
            if (serviceMeta.containsKey(Const.HTTPSERVER)) {
                serverInfo = serviceMeta.get(Const.HTTPSERVER);
            }

            for (i = 0; i < serviceIDs.size(); i++)
            {
                serviceID = serviceIDs.get(i);
                serviceMeta.remove(serviceID);
            }

            //also re-add service types info for remaining services
            serviceTypes.clear();
            serviceIDs = new ArrayList<>(serviceMeta.keySet());

            for (i = 0; i < serviceIDs.size(); i++)
            {
                serviceID = serviceIDs.get(i);
                nextInfo = serviceMeta.get(serviceID);

                if (!serviceTypes.containsKey(nextInfo.getServiceMeta().serviceType)) {
                    serviceTypes.put(nextInfo.getServiceMeta().serviceType, nextInfo);
                }
            }

            if (serverInfo != null) {
                serverInfo.getServiceMeta().clearChildAndLinksMeta();
                serviceMeta.put(Const.HTTPSERVER, serverInfo);
            }
        }
    }
    
    /**
     * Get a list of all of the service ids for the related metadata, of type String.
     * @return the list of ids for all stored services.
     */
    public ArrayList<String> getServiceIDs()
    {
        ArrayList<String> serviceIDs;                   //all service ids
        
        serviceIDs = new ArrayList<>(serviceMeta.keySet());
        return serviceIDs;
    }
    
    /**
     * Get an ordered list of all registered service types.
     * @return an ordered list of all service types, of type String.
     */
    public ArrayList<String> getServiceTypes()
    {
        ArrayList<String> sortedList;                   //sorted list of class names
        
        sortedList = new ArrayList<>(serviceTypes.keySet());
        Collections.sort(sortedList);
        
        return sortedList;
    }
    
    /**
     * Get a list of all of the service types in the network for a
     * particular category.
     * @param category the category to return service types for.
     * @return a list of all of the service types, of type String.
     */
    public ArrayList<String> getServiceTypes(String category)
    {
        ArrayList<String> l;                    //list
        ArrayList<String> sortedList;           //sorted list of class names
        ServiceRepositoryInfo nextInfo;         //repository info
        
        sortedList = new ArrayList<>();
        l = getServiceTypes();        

        for (String key: l)
        {
            nextInfo = serviceTypes.get(key);
            if (nextInfo.getServiceMeta().serviceCategory.equals(category) ||
                nextInfo.getServiceMeta().serviceCategory.equals(ServiceConst.ALLCATEGORIES)) {
                sortedList.add(key);
            }
        }
        
        return sortedList;
    }
    
    /**
     * Get the service details for the specified service.
     * @param serviceID the unique id of the service.
     * @return the service meta details in XML format if the service exists.
     * @throws java.lang.Exception any error.
     */
    public Element getServiceMeta(String serviceID) throws Exception
    {
        ServiceMeta theServiceMeta;                         //the service meta
        ServiceMeta newServiceMeta;                         //new service meta
        ServiceMetaParser serviceMetaParser;                //service meta parser
        Element metaElem;                                   //metadata element

        metaElem = null;
        if (serviceMeta.containsKey(serviceID)) {
            serviceMetaParser = new ServiceMetaParser();
            theServiceMeta = serviceMeta.get(serviceID).getServiceMeta();
            newServiceMeta = theServiceMeta.getMetaForInfo();

            //remove some entries if the base server
            if (serviceID.equals(Const.HTTPSERVER)) {
                newServiceMeta.childServiceMeta = null;
            }
            
            metaElem = serviceMetaParser.serialize(newServiceMeta);
        }
        
        return metaElem;
    }
    
    /**
     * Retrieve just one part of the metadata, not the whole object. If this is not
     * available for the server repository, the service can be invoked and asked,
     * but the password is then required.
     * @param serviceID the unique id of the service to retrieve.
     * @param toInclude meta part to return.
     * @param serviceObjMeta full description of the service's metadata to
     * retrieve from.
     * @return the metadata in XML format if it exists, or null if it does not.
     * @throws java.lang.Exception any error.
     */
    public Element getServiceMeta(String serviceID, ArrayList<String> toInclude, ServiceMeta serviceObjMeta)
            throws Exception
    {
        int i;
        String nextPart;                            //next meta part
        ServiceMeta newServiceMeta;                 //new service meta
        ServiceMetaParser serviceMetaParser;        //service meta parser

        if (serviceMeta.containsKey(serviceID)) {
            serviceMetaParser = new ServiceMetaParser();
            newServiceMeta = serviceObjMeta.getMetaForInfo();
            
            for (i = 0; i < toInclude.size(); i++)
            {
                nextPart = toInclude.get(i);
                newServiceMeta.addMetaPart(nextPart, serviceObjMeta);
            }

            return serviceMetaParser.serialize(newServiceMeta);
        }

        return null;
    }
    
    /**
     * Retrieve just one part of the metadata, not the whole object. If this is not
     * available for the server repository, the service can be invoked and asked,
     * but the password is then required.
     * @param serviceID the unique id of the service to retrieve.
     * @param toInclude meta part to return.
     * @param serviceObjMeta full description of the service's metadata to
     * retrieve from.
     * @return the metadata in XML format if it exists, or null if it does not.
     * @throws java.lang.Exception any error.
     */
    public Element getServiceMetaPart(String serviceID, String toInclude, ServiceMeta serviceObjMeta) 
            throws Exception
    {
        ServiceMeta newServiceMeta;                         //new service meta
        ServiceMetaParser serviceMetaParser;                //service meta parser

        if (serviceMeta.containsKey(serviceID))
        {
            serviceMetaParser = new ServiceMetaParser();
            newServiceMeta = new ServiceMeta();
            newServiceMeta.addMetaPart(toInclude, serviceObjMeta);

            return serviceMetaParser.serialize(newServiceMeta);
        }

        return null;
    }
    
    /**
     * Get the service details for the specified service.
     * @param serviceID the unique id of the service to retrieve.
     * @param adminKey the unique admin key for the service.
     * @return a direct reference to the service meta details so that they can be changed.
     */
    public ServiceMeta getServiceMeta(String serviceID, String adminKey)    
    {
        ServiceRepositoryInfo theInfo;                      //repository info
        
        if ((serviceID != null) && serviceMeta.containsKey(serviceID))
        {
            theInfo = serviceMeta.get(serviceID);
            if (theInfo.getAdminKey().equals(adminKey)) {
                return theInfo.getServiceMeta();
            }
        }
        
        return null;
    }
    
    /**
     * Add new service details.
     * @param adminKey the service key.
     * @param theServiceMeta the service metadata.
     * @return true if the details are added or false otherwise.
     */
    public boolean addServiceMeta(String adminKey, ServiceMeta theServiceMeta)
    {
        String serviceType;                                 //the service type
        ServiceRepositoryInfo theInfo;                      //repository info
                
        if (!serviceMeta.containsKey(theServiceMeta.uuid)) {
            theInfo = new ServiceRepositoryInfo(adminKey, theServiceMeta);
            serviceMeta.put(theServiceMeta.uuid, theInfo);  
            
            serviceType = theServiceMeta.serviceType;
            if (serviceType != null) {
                if (!serviceTypes.containsKey(serviceType)) {
                    serviceTypes.put(serviceType, theInfo);
                }
            }
            
            return true;
        }
        
        return false;
    }
    
    /**
     * Remove details about the specified service from the repository. If this
     * is also stored as a service type, remove it from the service type list.
     * @param serviceID the unique id of the service to remove.
     * @param adminKey the unique admin key for the service.
     * @return true if the info is removed or false otherwise.
     */
    public boolean removeServiceMeta(String serviceID, String adminKey)
    {
        ServiceRepositoryInfo theInfo;              //repository info
        
        if (serviceMeta.containsKey(serviceID)) {
            theInfo = serviceMeta.get(serviceID);
            if (theInfo.getAdminKey().equals(adminKey)) {
                serviceMeta.remove(serviceID);
                serviceTypes.remove(serviceID);
                return true;
            }
        }
        
        return false;
    }
}
