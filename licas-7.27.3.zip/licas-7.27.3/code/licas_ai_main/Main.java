/*
 * Main.java
 *
 * Created on 4 May 2011
 *
 * Version 1.3
 *
 * Copyright (c) Kieran Greer
 */

package org.licas_ai_solver_test;


import org.licas.ai_solver.*;
import org.licas.ai_solver.test.TestDef;
import org.licas.PasswordHandler;
import org.licas.exception.ExceptionHandler;
import org.jlog2.*;
import org.licas.ai_solver.parser.ProblemScriptParser;
import org.licas.ai_solver.spec.ProblemScript;
import org.licas.ai_solver.spec.test.TestSpec;
import org.licas.call.Handle;
import org.licas.util.Const;
import org.licas_xml.abs.Element;


/**
 * A main class for running tests using the hyper heuristic framework.
 * @author Kieran Greer
 */
public class Main 
{
    /** For logging */
    private static Logger logger;
       
    static
    {
        try {
            //initialise the logging
            LoggerFactory.setLoggerFactory(new CustomLoggerFactory());
        } catch (Exception ex) {
            System.exit(0);
        }
        
        // get the logger
        logger = LoggerHandler.getLogger(Main.class.getName());
        logger.setDebug(true);
    }
    
    /** Create a new instance of Main */
    public Main() 
    {}
    
    /** 
     * Run a test.
     * @param args command line arguments.
     */
    public void runTest(String args[])
    {
        TestDef runTest;                                //to run a test
        TestSpec testSpec;                              //test specification
        Element serverUri;                              //server uri
        PasswordHandler passwordHandler;                //for storing passwords
        ProblemScript testScript;                       //test script
        ProblemScriptParser testScriptParser;           //test script parser       
        
        try
        {
            passwordHandler = new PasswordHandler(Const.ANON, Const.ANON);
            
            //add passwords for default server and location
            serverUri = Handle.createNewServerUrlHandle("http://127.0.0.1:8888");
            passwordHandler.addServicePassword(serverUri, Const.ANON);
            passwordHandler.addAdminKey(serverUri, Const.ANON);
            
            if ((args != null) && (args.length > 0))
            {
                SolverFactory.setSolverFactory(new DefaultSolverFactory(passwordHandler));
                
                testScriptParser = new ProblemScriptParser(passwordHandler);
                testScript = testScriptParser.parseFile(args[0]);
                
                testSpec = SolverFactory.getInstance().getSolverSpecs().getTestSpec(testScript.solverType);
                testSpec.setTestScript(testScript);
                runTest = SolverFactory.getInstance().getSolverMediators().getTestMediator(testScript.solverType, testScript.serviceType);
                
                if (runTest.configureTest(testSpec))
                {
                    System.out.println(runTest.runTestSet());
                }
                else
                {
                    System.out.println("Could not configure the test properly.");
                }
            }
            else
            {
                System.out.println("Path to the test script file required as command line argument.");
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();

            ExceptionHandler.handleException(logger, LoggerHandler.ERROR, "runTest",
                null, ex);
        }
    }
    
    public static void main(final String args[]) 
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run() {
                new Main().runTest(args);
            }
        });
    }
}